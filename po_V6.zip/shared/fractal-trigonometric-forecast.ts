/**
 * Fractal Trigonometric Forecast — LIVE / non-repainting revision.
 *
 * Important semantic change versus the previous implementation:
 * - the current/forming candle is allowed to influence the CURRENT signal;
 * - rolling ranges used as reference exclude the current candle;
 * - CALL/PUT are based on the current score + live candle evidence;
 * - no signal is delayed by one bar and no future candle is consulted.
 *
 * The public return shape is kept compatible with the existing visual
 * indicator and Hope strategy. `call` / `put` now mean "current candle live
 * signal" rather than "previous-bar threshold crossing".
 */

export interface FractalTrigonometricForecastCandle {
  open: number
  high: number
  low: number
  close: number
}

export interface FractalTrigonometricForecastResult {
  ema13: Array<number | null>
  ema34: Array<number | null>
  visual: Array<number | null>
  predict: Array<number | null>
  call: Array<number | null>
  put: Array<number | null>
  score: Array<number | null>
  trig: Array<number | null>
  /** Directional score normalized to approximately [-1, +1]. */
  liveScore: Array<number | null>
  /** 1 = UP, -1 = DOWN, 0 = neutral. */
  direction: Array<number | null>
}

function nulls(n: number): Array<number | null> {
  return Array<number | null>(n).fill(null)
}

function closes(c: FractalTrigonometricForecastCandle[]): number[] {
  return c.map(x => x.close)
}

function ema(values: number[], period: number): Array<number | null> {
  const out = nulls(values.length)
  if (!values.length || period <= 0 || values.length < period) return out
  const alpha = 2 / (period + 1)
  let prev = values.slice(0, period).reduce((a, b) => a + b, 0) / period
  out[period - 1] = prev
  for (let i = period; i < values.length; i++) {
    prev = alpha * values[i] + (1 - alpha) * prev
    out[i] = prev
  }
  return out
}

/** Rolling high ending at `i`, optionally excluding the current bar. */
function highestPrior(values: number[], i: number, period: number): number | null {
  if (period <= 0 || i < period) return null
  let h = -Infinity
  for (let j = i - period; j < i; j++) h = Math.max(h, values[j])
  return Number.isFinite(h) ? h : null
}

/** Rolling low ending at `i`, optionally excluding the current bar. */
function lowestPrior(values: number[], i: number, period: number): number | null {
  if (period <= 0 || i < period) return null
  let l = Infinity
  for (let j = i - period; j < i; j++) l = Math.min(l, values[j])
  return Number.isFinite(l) ? l : null
}

function clamp(v: number, lo: number, hi: number): number {
  return Math.max(lo, Math.min(hi, v))
}

function safeTanh(v: number): number {
  if (!Number.isFinite(v)) return 0
  return Math.tanh(v)
}

export function computeFractalTrigonometricForecast(
  c: FractalTrigonometricForecastCandle[],
  threshold = 0.45,
  projection = 1.0,
): FractalTrigonometricForecastResult {
  const n = c.length
  const trigThreshold = clamp(Number.isFinite(threshold) ? threshold : 0.45, 0.10, 1.20)
  const phaseProjection = clamp(Number.isFinite(projection) ? projection : 1.0, 0.10, 2.00)
  const PI = Math.PI

  const closeValues = closes(c)
  const highs = c.map(x => x.high)
  const lows = c.map(x => x.low)
  const ema13 = ema(closeValues, 13)
  const ema34 = ema(closeValues, 34)
  const trig = nulls(n)
  const visual = nulls(n)
  const predict = nulls(n)
  const call = nulls(n)
  const put = nulls(n)
  const score = nulls(n)
  const liveScore = nulls(n)
  const direction = nulls(n)

  const periods = [8, 13, 21, 34]
  const weights = [1.00, 1.35, 1.75, 2.15]
  const weightSum = weights.reduce((a, b) => a + b, 0)

  /**
   * Trigonometric wave anchored to the PRIOR range, so the current candle
   * cannot move the reference high/low used to evaluate itself.
   */
  const wave = (i: number, period: number): number | null => {
    if (i < period) return null
    const priorH = highestPrior(highs, i, period)
    const priorL = lowestPrior(lows, i, period)
    if (priorH == null || priorL == null) return null
    const priorRange = priorH - priorL
    if (!(priorRange > 0)) return null

    const pct = clamp((c[i].close - priorL) / priorRange, 0, 1)
    const phase = (pct * 2 - 1) * PI

    if (i < 1) return null
    const prevH = highestPrior(highs, i - 1, period)
    const prevL = lowestPrior(lows, i - 1, period)
    if (prevH == null || prevL == null) return null
    const prevRange = prevH - prevL
    if (!(prevRange > 0)) return null

    const prevPct = clamp((c[i - 1].close - prevL) / prevRange, 0, 1)
    const prevPhase = (prevPct * 2 - 1) * PI
    const phaseDelta = phase - prevPhase
    const projected = phase + phaseDelta * phaseProjection

    // Normalize the raw sin+cos wave so its dominant range is close to [-1, 1].
    return clamp((Math.sin(projected) + Math.cos(projected) * 0.35) / 1.35, -1, 1)
  }

  for (let i = 0; i < n; i++) {
    const waves = periods.map(p => wave(i, p))
    if (waves.some(v => v == null)) continue

    const waveValues = waves as number[]
    const trigValue = waveValues.reduce((sum, v, idx) => sum + v * weights[idx], 0) / weightSum
    trig[i] = trigValue

    // Current-candle price action. This is deliberately based on the forming
    // candle so the signal can react during the live candle.
    const current = c[i]
    const previous = i > 0 ? c[i - 1] : null
    const range = Math.max(current.high - current.low, Number.EPSILON)
    const body = current.close - current.open
    const bodySigned = clamp(body / range, -1, 1)
    const closePos = clamp((current.close - current.low) / range, 0, 1)
    const closeLocation = closePos * 2 - 1

    // Momentum is normalized by the prior multi-scale range instead of the
    // current range alone, making tiny opening candles naturally weak.
    const refHigh = highestPrior(highs, i, 8)
    const refLow = lowestPrior(lows, i, 8)
    const refRange = refHigh != null && refLow != null ? Math.max(refHigh - refLow, Number.EPSILON) : null
    const momentum = previous && refRange != null
      ? safeTanh((current.close - previous.close) / (refRange * 0.25))
      : 0

    let trend = 0
    if (ema13[i] != null && ema34[i] != null) {
      if ((ema13[i] as number) > (ema34[i] as number)) trend = 1
      else if ((ema13[i] as number) < (ema34[i] as number)) trend = -1
    }

    let up = 0
    let down = 0
    for (const w of waveValues) {
      if (w > 0) up += 1
      else if (w < 0) down += 1
    }
    const coherence = up === down ? 0 : up > down ? up / 4 : -(down / 4)

    // FTFP remains the main component, but the signal now has explicit live
    // candle evidence. This reduces "phase says CALL while candle is red"
    // false positives that were common in the previous formulation.
    const scoreValue =
      trigValue * 0.50 +
      bodySigned * 0.18 +
      closeLocation * 0.10 +
      momentum * 0.10 +
      trend * 0.07 +
      coherence * 0.05

    const s = clamp(scoreValue, -1, 1)
    score[i] = s
    liveScore[i] = s

    // Require a minimum amount of live information. At the exact opening
    // tick, body and momentum are ~0, so the indicator intentionally stays
    // neutral instead of pretending to know the candle direction.
    const liveActivity = Math.max(Math.abs(bodySigned), Math.abs(momentum))
    const candleUpEvidence = bodySigned > 0.08 || (momentum > 0.10 && closeLocation > -0.10)
    const candleDownEvidence = bodySigned < -0.08 || (momentum < -0.10 && closeLocation < 0.10)

    if (s >= trigThreshold && candleUpEvidence && liveActivity >= 0.08) {
      direction[i] = 1
      call[i] = current.low
    } else if (s <= -trigThreshold && candleDownEvidence && liveActivity >= 0.08) {
      direction[i] = -1
      put[i] = current.high
    } else {
      direction[i] = 0
    }

    // Visual projections remain available, but are now driven by the same
    // live score that feeds the CALL/PUT marker.
    if (refRange != null) {
      visual[i] = current.close + (s * refRange * 1.25)
      predict[i] = current.close + (trigValue * refRange * 1.00)
    }
  }

  return { ema13, ema34, visual, predict, call, put, score, trig, liveScore, direction }
}
