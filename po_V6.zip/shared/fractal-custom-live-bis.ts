/**
 * Fractal Live Custom BIS — Marubozu-focused companion to Fractal Custom — Live.
 *
 * This is intentionally a separate algorithm. The original Fractal Custom — Live
 * is untouched. BIS only emits on strong, long-body breakout candles (Marubozu
 * style): large real body + very small upper/lower wicks + breakout of the
 * previous lookback range. No future candles are consulted.
 */

export interface FractalCustomLiveBisCandle {
  open: number
  high: number
  low: number
  close: number
}

export interface FractalCustomLiveBisResult {
  up: Array<number | null>
  down: Array<number | null>
}

export interface FractalCustomLiveBisOptions {
  lookback: number
  minBodyRatio: number
  maxWickRatio: number
}

export function computeFractalCustomLiveBis(
  candles: FractalCustomLiveBisCandle[],
  lookback: number,
  minBodyRatio: number,
  maxWickRatio: number,
): FractalCustomLiveBisResult {
  const n = candles.length
  const up = Array<number | null>(n).fill(null)
  const down = Array<number | null>(n).fill(null)
  if (!Number.isFinite(lookback) || !Number.isFinite(minBodyRatio) || !Number.isFinite(maxWickRatio)) {
    return { up, down }
  }
  const k = Math.round(lookback)
  if (k < 1) return { up, down }
  const bodyMin = Number(minBodyRatio)
  const wickMax = Number(maxWickRatio)

  for (let i = k; i < n; i++) {
    let maxH = -Infinity
    let minL = Infinity
    for (let j = 1; j <= k; j++) {
      maxH = Math.max(maxH, candles[i - j].high)
      minL = Math.min(minL, candles[i - j].low)
    }

    const cur = candles[i]
    const range = Math.max(cur.high - cur.low, Number.EPSILON)
    const body = Math.abs(cur.close - cur.open)
    const upperWick = Math.max(0, cur.high - Math.max(cur.open, cur.close))
    const lowerWick = Math.max(0, Math.min(cur.open, cur.close) - cur.low)
    const bodyRatio = body / range
    const upperWickRatio = upperWick / range
    const lowerWickRatio = lowerWick / range

    const isMarubozu = bodyRatio >= bodyMin
      && upperWickRatio <= wickMax
      && lowerWickRatio <= wickMax

    const bullBreakout = cur.close > cur.open && cur.high > maxH
    const bearBreakout = cur.close < cur.open && cur.low < minL

    if (isMarubozu && bullBreakout) up[i] = cur.low
    if (isMarubozu && bearBreakout) down[i] = cur.high
  }

  return { up, down }
}
