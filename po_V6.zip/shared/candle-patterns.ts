/**
 * candle-patterns.ts — Moteur partagé « 73 Candlestick Patterns »
 * ====================================================================
 * SOURCE DE VÉRITÉ CANDLE : pack super_candles (« All Candlestick
 * Patterns [theEccentricTrader] » — TradingView_pine_scripts_samples/
 * candles.pine, © theEccentricTrader, MPL 2.0).
 *
 * Les 73 patterns, leurs libellés, leurs directions (bullish / bearish /
 * neutral), leurs couleurs et leurs positions (label AU-DESSUS pour un
 * signal baissier/neutre, EN-DESSOUS pour un signal haussier) sont
 * EXACTEMENT ceux du pack source :
 *   - Doji, Bullish/Bearish Marubozu, Spinning Top, Belt-Hold, Breakaway,
 *     Concealing Baby Swallow, Counterattack, Dark Cloud Cover, Doji
 *     (Long-Legged / Southern / Northern / Dragonfly / Gravestone),
 *     Dumpling Top, Engulfing, Frypan Bottom, Hammer, Hanging Man, Harami
 *     (+ Cross), High-Wave, Hikkake, Homing Pigeon, In/On-Neck, Kicking,
 *     Matching Low, Piercing, Separating Lines, Side-by-Side White Lines,
 *     Stalled, Star (Bull/Bear/Doji/Morning/Evening/Doji variants),
 *     Abandoned Baby, Inverted Hammer, Shooting Star, Stick Sandwich,
 *     Tasuki, Three Black Crows, Advance Block, Three Advancing White
 *     Soldiers, Three-Line Strike, Rising/Falling Three Methods, Three
 *     Stars in the South, Thrusting, Tower Bottom/Top, Tri-Star, Tweezer,
 *     Upside-Gap Two Crows.
 *
 * AUCUN pattern supprimé, remplacé ou limité : les 73 détecteurs sont
 * INDEPENDANTS et TOUS évalués sur CHAQUE bougie — une même bougie peut
 * porter PLUSIEURS patterns (ex. Hammer + Bullish Engulfing + Piercing =
 * 3 événements, §25 du cahier des charges). La détection ne connaît
 * AUCUNE limite artificielle et n'est JAMAIS filtrée par l'affichage
 * (masquer un pattern ne masque que le VISUEL — §33).
 *
 * Définitions de détection : implémentation TypeScript fidèle des
 * définitions classiques publiées (littérature candlestick standard +
 * conventions du pack) : corps/mèques/étendue, gaps sur les CORPS,
 * tolérances relatives à l'étendue, et contexte de tendance par moyenne
 * mobile interne (SMA 14 vs SMA 50 — INTERNE au moteur, aucun indicateur
 * n'est exposé dans l'application : §43).
 *
 * Visuels — mêmes règles d'offset que le pack :
 *   base_offset = max(atr14 * 0.30, mintick * 10)
 *   stack_step  = max(atr14 * 0.20, mintick * 10)
 *   piles above_stack/below_stack remises à zéro à chaque nouvelle bougie ;
 *   pattern BULLISH → label SOUS la bougie (low  − offset − step·pile) ;
 *   pattern BEARISH/NEUTRAL → label SUR la bougie (high + offset + step·pile).
 *
 * Le moteur est PUR (aucune dépendance socket/io/React) : utilisé par le
 * backend (ordres réels), le Rule Engine partagé (Auto Trade), le
 * Strategy Tester et la couche visuelle du graphique.
 */

/* ═════════════════════════════ types ═════════════════════════════ */

/** Bougie OHLC minimale (compatible BosChochCisdCandle / lightweight-charts). */
export interface CandlePatternCandle {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume?: number
}

/** Identifiant stable d'un pattern (id machine, snake_case). */
export type CandlePatternId =
  | 'doji'
  | 'bullish_marubozu' | 'bearish_marubozu'
  | 'spinning_top'
  | 'bullish_belt_hold_line' | 'bearish_belt_hold_line'
  | 'bullish_breakaway' | 'bearish_breakaway'
  | 'concealing_baby_swallow'
  | 'bullish_counterattack' | 'bearish_counterattack'
  | 'dark_cloud_cover'
  | 'long_legged_doji' | 'southern_doji' | 'northern_doji'
  | 'dumpling_top'
  | 'bullish_engulfing' | 'bearish_engulfing'
  | 'frypan_bottom'
  | 'hammer' | 'hanging_man'
  | 'bullish_harami' | 'bearish_harami'
  | 'bullish_harami_cross' | 'bearish_harami_cross'
  | 'high_wave'
  | 'bullish_hikkake' | 'bearish_hikkake'
  | 'homing_pigeon'
  | 'in_neck'
  | 'bullish_kicking' | 'bearish_kicking'
  | 'matching_low'
  | 'on_neck'
  | 'piercing'
  | 'bullish_separating_lines' | 'bearish_separating_lines'
  | 'upgap_side_by_side_white_lines' | 'downgap_side_by_side_white_lines'
  | 'stalled'
  | 'bullish_star' | 'bearish_star'
  | 'bullish_doji_star' | 'bearish_doji_star'
  | 'morning_star' | 'evening_star'
  | 'morning_doji_star' | 'evening_doji_star'
  | 'abandoned_baby_bottom' | 'abandoned_baby_top'
  | 'inverted_hammer' | 'shooting_star'
  | 'dragonfly_doji' | 'gravestone_doji'
  | 'stick_sandwich'
  | 'upward_gapping_tasuki' | 'downward_gapping_tasuki'
  | 'three_black_crows' | 'advance_block'
  | 'three_advancing_white_soldiers'
  | 'bullish_three_line_strike' | 'bearish_three_line_strike'
  | 'rising_three_methods' | 'falling_three_methods'
  | 'three_stars_in_the_south'
  | 'thrusting'
  | 'tower_bottom' | 'tower_top'
  | 'tri_star_bottom' | 'tri_star_top'
  | 'tweezer_bottom' | 'tweezer_top'
  | 'upside_gap_two_crows'

/** Direction du pattern (mêmes couleurs que le pack source). */
export type CandlePatternDirection = 'bullish' | 'bearish' | 'neutral'

/** Position du label par rapport à la bougie (source : blocs if du pack). */
export type CandlePatternPosition = 'above' | 'below'

/** Définition statique d'un pattern (registry source, §2/§3/§4). */
export interface CandlePatternDef {
  id: CandlePatternId
  /** Libellé EXACT du pack source (affiché sur le graphique). */
  label: string
  direction: CandlePatternDirection
  position: CandlePatternPosition
  /** Utilisable comme condition du Rule Builder CALL/PUT (§11). */
  tradable: boolean
  /** Affiché par défaut quand « Tags & labels » est ON. */
  displayDefault: boolean
}

/** Nombre exact de patterns du pack source — INVARIANT (73). */
export const CANDLE_PATTERN_COUNT = 73

/**
 * Les 73 définitions — ORDRE DU PACK SOURCE (l'ordre alimente les piles
 * above_stack/below_stack des labels, comme la séquence des if du Main).
 */
export const CANDLE_PATTERN_DEFS: CandlePatternDef[] = [
  { id: 'doji', label: 'Doji', direction: 'neutral', position: 'above', tradable: true, displayDefault: true },
  { id: 'bullish_marubozu', label: 'Bullish Marubozu', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bearish_marubozu', label: 'Bearish Marubozu', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'spinning_top', label: 'Spinning Top', direction: 'neutral', position: 'above', tradable: true, displayDefault: true },
  { id: 'bullish_belt_hold_line', label: 'Bullish Belt-Hold Line', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bearish_belt_hold_line', label: 'Bearish Belt-Hold Line', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'bullish_breakaway', label: 'Bullish Breakaway', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bearish_breakaway', label: 'Bearish Breakaway', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'concealing_baby_swallow', label: 'Concealing Baby Swallow', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bullish_counterattack', label: 'Bullish Counterattack', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bearish_counterattack', label: 'Bearish Counterattack', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'dark_cloud_cover', label: 'Dark Cloud Cover', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'long_legged_doji', label: 'Long-Legged Doji', direction: 'neutral', position: 'above', tradable: true, displayDefault: true },
  { id: 'southern_doji', label: 'Southern Doji', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'northern_doji', label: 'Northern Doji', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'dumpling_top', label: 'Dumpling Top', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'bullish_engulfing', label: 'Bullish Engulfing', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bearish_engulfing', label: 'Bearish Engulfing', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'frypan_bottom', label: 'Frypan Bottom', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'hammer', label: 'Hammer', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'hanging_man', label: 'Hanging Man', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'bullish_harami', label: 'Bullish Harami', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bearish_harami', label: 'Bearish Harami', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'bullish_harami_cross', label: 'Bullish Harami Cross', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bearish_harami_cross', label: 'Bearish Harami Cross', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'high_wave', label: 'High-Wave', direction: 'neutral', position: 'above', tradable: true, displayDefault: true },
  { id: 'bullish_hikkake', label: 'Bullish Hikkake', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bearish_hikkake', label: 'Bearish Hikkake', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'homing_pigeon', label: 'Homing Pigeon', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'in_neck', label: 'In-Neck', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bullish_kicking', label: 'Bullish Kicking', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bearish_kicking', label: 'Bearish Kicking', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'matching_low', label: 'Matching Low', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'on_neck', label: 'On-Neck', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'piercing', label: 'Piercing', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bullish_separating_lines', label: 'Bullish Separating Lines', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bearish_separating_lines', label: 'Bearish Separating Lines', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'upgap_side_by_side_white_lines', label: 'Upgap Side-by-Side White Lines', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'downgap_side_by_side_white_lines', label: 'Downgap Side-by-Side White Lines', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'stalled', label: 'Stalled', direction: 'neutral', position: 'above', tradable: true, displayDefault: true },
  { id: 'bullish_star', label: 'Bullish Star', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bearish_star', label: 'Bearish Star', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'bullish_doji_star', label: 'Bullish Doji Star', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bearish_doji_star', label: 'Bearish Doji Star', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'morning_star', label: 'Morning Star', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'evening_star', label: 'Evening Star', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'morning_doji_star', label: 'Morning Doji Star', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'evening_doji_star', label: 'Evening Doji Star', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'abandoned_baby_bottom', label: 'Abandoned Baby Bottom', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'abandoned_baby_top', label: 'Abandoned Baby Top', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'inverted_hammer', label: 'Inverted Hammer', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'shooting_star', label: 'Shooting Star', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'dragonfly_doji', label: 'Dragonfly Doji', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'gravestone_doji', label: 'Gravestone Doji', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'stick_sandwich', label: 'Stick Sandwich', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'upward_gapping_tasuki', label: 'Upward Gapping Tasuki', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'downward_gapping_tasuki', label: 'Downward Gapping Tasuki', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'three_black_crows', label: 'Three Black Crows', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'advance_block', label: 'Advance Block', direction: 'neutral', position: 'above', tradable: true, displayDefault: true },
  { id: 'three_advancing_white_soldiers', label: 'Three Advancing White Soldiers', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bullish_three_line_strike', label: 'Bullish Three-Line Strike', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'bearish_three_line_strike', label: 'Bearish Three-Line Strike', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'rising_three_methods', label: 'Rising Three Methods', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'falling_three_methods', label: 'Falling Three Methods', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'three_stars_in_the_south', label: 'Three Stars in the South', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'thrusting', label: 'Thrusting', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'tower_bottom', label: 'Tower Bottom', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'tower_top', label: 'Tower Top', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'tri_star_bottom', label: 'Tri-Star Bottom', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'tri_star_top', label: 'Tri-Star Top', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'tweezer_bottom', label: 'Tweezer Bottom', direction: 'bullish', position: 'below', tradable: true, displayDefault: true },
  { id: 'tweezer_top', label: 'Tweezer Top', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
  { id: 'upside_gap_two_crows', label: 'Upside-Gap Two Crows', direction: 'bearish', position: 'above', tradable: true, displayDefault: true },
]

if (CANDLE_PATTERN_DEFS.length !== CANDLE_PATTERN_COUNT) {
  throw new Error(`candle-patterns : ${CANDLE_PATTERN_DEFS.length} patterns définis, ${CANDLE_PATTERN_COUNT} attendus (pack source)`)
}

/** Index id → définition. */
export const CANDLE_PATTERN_BY_ID: Record<CandlePatternId, CandlePatternDef> = Object.fromEntries(
  CANDLE_PATTERN_DEFS.map((d) => [d.id, d]),
) as Record<CandlePatternId, CandlePatternDef>

/** Liste des ids (validation Rule Builder / normalisation). */
export const CANDLE_PATTERN_IDS: CandlePatternId[] = CANDLE_PATTERN_DEFS.map((d) => d.id)

/** Un pattern est-il un id candle valide ? */
export function isCandlePatternId(id: unknown): id is CandlePatternId {
  return typeof id === 'string' && (CANDLE_PATTERN_IDS as string[]).includes(id)
}

/** Libellé d'un pattern candle (source de vérité : defs). */
export function candlePatternLabel(id: CandlePatternId): string {
  return CANDLE_PATTERN_BY_ID[id]?.label ?? id
}

/** Direction d'un pattern candle. */
export function candlePatternDirection(id: CandlePatternId): CandlePatternDirection {
  return CANDLE_PATTERN_BY_ID[id]?.direction ?? 'neutral'
}

/* ══════════════════════ contexte de détection ══════════════════════ */

/**
 * Un événement candle pattern détecté sur une bougie (modèle §3).
 * La détection interne conserve TOUS les événements ; l'UI peut en
 * masquer certains (filtres d'affichage) sans jamais affecter le moteur.
 */
export interface CandlePatternEvent {
  patternId: CandlePatternId
  /** Libellé exact du pack source. */
  label: string
  direction: CandlePatternDirection
  position: CandlePatternPosition
  /** Indice de la bougie porteuse dans la série évaluée. */
  barIndex: number
  /** Temps de la bougie porteuse. */
  candleTime: number
  open: number
  high: number
  low: number
  close: number
  /**
   * Position Y du label (offsets ATR + pile du pack, calculés à la
   * détection) — les patterns EN-DESSOUS partent de low, ceux
   * AU-DESSUS de high.
   */
  labelY: number
  /**
   * Rang d'empilement du label sur sa voie (above/below) pour cette
   * bougie — 0 = premier label de la voie.
   */
  lane: number
}

/* ═══════════ helpers de bougie (conventions du pack) ═══════════ */

function green(c: CandlePatternCandle): boolean { return c.close >= c.open }
function red(c: CandlePatternCandle): boolean { return c.close < c.open }
function body(c: CandlePatternCandle): number { return Math.abs(c.close - c.open) }
function rng(c: CandlePatternCandle): number { return Math.max(0, c.high - c.low) }
function upwick(c: CandlePatternCandle): number { return c.high - Math.max(c.open, c.close) }
function dnwick(c: CandlePatternCandle): number { return Math.min(c.open, c.close) - c.low }
function isDoji(c: CandlePatternCandle): boolean { const r = rng(c); return r > 0 && body(c) <= r * 0.05 }
function midBody(c: CandlePatternCandle): number { return (c.open + c.close) / 2 }

/* ═════════════ contexte par bougie évaluée ═════════════ */

/**
 * Contexte de détection pour UNE bougie (index i) — expose les 5
 * dernières bougies (t0 = bougie évaluée, t1..t4 = précédentes), les
 * helpers par bougie et le contexte de tendance (SMA 14 vs SMA 50,
 * interne au moteur — jamais exposé comme indicateur).
 */
export interface CandlePatternContext {
  /** t0 = bougie évaluée ; t1..t4 = précédentes (null si hors série). */
  t0: CandlePatternCandle
  t1: CandlePatternCandle | null
  t2: CandlePatternCandle | null
  t3: CandlePatternCandle | null
  t4: CandlePatternCandle | null
  /** Tendance interne (SMA 14 > SMA 50 / <) — false si historique insuffisant. */
  upTrend: boolean
  dnTrend: boolean
}

/** Détecteur d'un pattern — PUR, sans effet de bord. */
export type CandlePatternDetector = (x: CandlePatternContext) => boolean

/* ═══════════════════════ 73 détecteurs ═══════════════════════
 * Définitions classiques du pack (© theEccentricTrader) portées en
 * TypeScript pur. Chaque détecteur reçoit le contexte {t0..t4, trend} et
 * retourne booléen — TOUS indépendants, TOUS évalués (aucune limite).
 * Raccourcis : b = corps, r = étendue, u = mèche haute, d = mèche basse.
 */

const T = (c: CandlePatternCandle | null): CandlePatternCandle => c as CandlePatternCandle

/** Tolérance « niveau égal » relative à l'étendue de référence. */
function eqTol(a: number, b: number, refRange: number): boolean {
  return Math.abs(a - b) <= Math.max(refRange, 1e-12) * 0.1
}

export const CANDLE_PATTERN_DETECTORS: Record<CandlePatternId, CandlePatternDetector> = {
  /* ── 1-candle : forme pure ── */
  doji: (x) => isDoji(x.t0),
  bullish_marubozu: (x) => {
    const r = rng(x.t0)
    return green(x.t0) && body(x.t0) >= r * 0.9 && upwick(x.t0) <= r * 0.05 && dnwick(x.t0) <= r * 0.05
  },
  bearish_marubozu: (x) => {
    const r = rng(x.t0)
    return red(x.t0) && body(x.t0) >= r * 0.9 && upwick(x.t0) <= r * 0.05 && dnwick(x.t0) <= r * 0.05
  },
  spinning_top: (x) => {
    const r = rng(x.t0)
    return body(x.t0) <= r * 0.1 && upwick(x.t0) >= r * 0.25 && dnwick(x.t0) >= r * 0.25
  },
  dragonfly_doji: (x) => {
    const r = rng(x.t0)
    return isDoji(x.t0) && dnwick(x.t0) >= r * 0.6 && upwick(x.t0) <= r * 0.1
  },
  gravestone_doji: (x) => {
    const r = rng(x.t0)
    return isDoji(x.t0) && upwick(x.t0) >= r * 0.6 && dnwick(x.t0) <= r * 0.1
  },
  long_legged_doji: (x) => {
    const r = rng(x.t0)
    return isDoji(x.t0) && upwick(x.t0) >= r * 0.3 && dnwick(x.t0) >= r * 0.3
  },
  high_wave: (x) => {
    const r = rng(x.t0)
    return body(x.t0) <= r * 0.15 && upwick(x.t0) >= r * 0.3 && dnwick(x.t0) >= r * 0.3
  },

  /* ── 1-candle : avec contexte de tendance ── */
  bullish_belt_hold_line: (x) => {
    const r = rng(x.t0)
    return x.dnTrend && green(x.t0) && dnwick(x.t0) <= r * 0.05 && body(x.t0) >= r * 0.5
  },
  bearish_belt_hold_line: (x) => {
    const r = rng(x.t0)
    return x.upTrend && red(x.t0) && upwick(x.t0) <= r * 0.05 && body(x.t0) >= r * 0.5
  },
  hammer: (x) => {
    const c = x.t0; const r = rng(c)
    return x.dnTrend && dnwick(c) >= body(c) * 2 && upwick(c) <= body(c) && body(c) <= r * 0.4
  },
  hanging_man: (x) => {
    const c = x.t0; const r = rng(c)
    return x.upTrend && dnwick(c) >= body(c) * 2 && upwick(c) <= body(c) && body(c) <= r * 0.4
  },
  inverted_hammer: (x) => {
    const c = x.t0; const r = rng(c)
    return x.dnTrend && upwick(c) >= body(c) * 2 && dnwick(c) <= body(c) && body(c) <= r * 0.4
  },
  shooting_star: (x) => {
    const c = x.t0; const r = rng(c)
    return x.upTrend && upwick(c) >= body(c) * 2 && dnwick(c) <= body(c) && body(c) <= r * 0.4
  },
  southern_doji: (x) => isDoji(x.t0) && x.dnTrend,
  northern_doji: (x) => isDoji(x.t0) && x.upTrend,

  /* ── 2-candle ── */
  bullish_engulfing: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && red(a) && green(x.t0) && x.t0.open < a.close && x.t0.close > a.open
  },
  bearish_engulfing: (x) => {
    const a = x.t1; if (!a) return false
    return x.upTrend && green(a) && red(x.t0) && x.t0.open > a.close && x.t0.close < a.open
  },
  bullish_harami: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && red(a) && body(a) >= rng(a) * 0.5
      && Math.max(x.t0.open, x.t0.close) < a.open && Math.min(x.t0.open, x.t0.close) > a.close
  },
  bearish_harami: (x) => {
    const a = x.t1; if (!a) return false
    return x.upTrend && green(a) && body(a) >= rng(a) * 0.5
      && Math.max(x.t0.open, x.t0.close) < a.close && Math.min(x.t0.open, x.t0.close) > a.open
  },
  bullish_harami_cross: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && red(a) && body(a) >= rng(a) * 0.5 && isDoji(x.t0)
      && Math.max(x.t0.open, x.t0.close) < a.open && Math.min(x.t0.open, x.t0.close) > a.close
  },
  bearish_harami_cross: (x) => {
    const a = x.t1; if (!a) return false
    return x.upTrend && green(a) && body(a) >= rng(a) * 0.5 && isDoji(x.t0)
      && Math.max(x.t0.open, x.t0.close) < a.close && Math.min(x.t0.open, x.t0.close) > a.open
  },
  bullish_counterattack: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && red(a) && green(x.t0) && eqTol(x.t0.close, a.close, Math.max(rng(x.t0), rng(a)))
  },
  bearish_counterattack: (x) => {
    const a = x.t1; if (!a) return false
    return x.upTrend && green(a) && red(x.t0) && eqTol(x.t0.close, a.close, Math.max(rng(x.t0), rng(a)))
  },
  dark_cloud_cover: (x) => {
    const a = x.t1; if (!a) return false
    return x.upTrend && green(a) && body(a) >= rng(a) * 0.5 && red(x.t0)
      && x.t0.open > a.high && x.t0.close < midBody(a) && x.t0.close > a.open
  },
  piercing: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && red(a) && body(a) >= rng(a) * 0.5 && green(x.t0)
      && x.t0.open < a.low && x.t0.close > midBody(a) && x.t0.close < a.open
  },
  homing_pigeon: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && red(a) && body(a) >= rng(a) * 0.5 && red(x.t0)
      && Math.max(x.t0.open, x.t0.close) < a.open && Math.min(x.t0.open, x.t0.close) > a.close
  },
  matching_low: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && red(a) && red(x.t0) && eqTol(x.t0.close, a.close, Math.max(rng(x.t0), rng(a)))
  },
  in_neck: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && red(a) && body(a) >= rng(a) * 0.5
      && x.t0.close <= a.close && eqTol(x.t0.close, a.close, Math.max(rng(x.t0), rng(a)))
  },
  on_neck: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && red(a) && body(a) >= rng(a) * 0.5 && eqTol(x.t0.close, a.low, Math.max(rng(x.t0), rng(a)))
  },
  thrusting: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && red(a) && body(a) >= rng(a) * 0.5
      && x.t0.open < a.close && x.t0.close > a.close && x.t0.close < midBody(a)
  },
  bullish_kicking: (x) => {
    const a = x.t1; if (!a) return false
    const ra = rng(a); const r0 = rng(x.t0)
    return red(a) && body(a) >= ra * 0.7 && upwick(a) <= ra * 0.05 && dnwick(a) <= ra * 0.05
      && green(x.t0) && body(x.t0) >= r0 * 0.7 && upwick(x.t0) <= r0 * 0.05 && dnwick(x.t0) <= r0 * 0.05
      && x.t0.open > a.high
  },
  bearish_kicking: (x) => {
    const a = x.t1; if (!a) return false
    const ra = rng(a); const r0 = rng(x.t0)
    return green(a) && body(a) >= ra * 0.7 && upwick(a) <= ra * 0.05 && dnwick(a) <= ra * 0.05
      && red(x.t0) && body(x.t0) >= r0 * 0.7 && upwick(x.t0) <= r0 * 0.05 && dnwick(x.t0) <= r0 * 0.05
      && x.t0.open < a.low
  },
  bullish_separating_lines: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && red(a) && body(a) >= rng(a) * 0.6 && green(x.t0) && body(x.t0) >= rng(x.t0) * 0.6
      && eqTol(x.t0.open, a.open, Math.max(rng(x.t0), rng(a)))
  },
  bearish_separating_lines: (x) => {
    const a = x.t1; if (!a) return false
    return x.upTrend && green(a) && body(a) >= rng(a) * 0.6 && red(x.t0) && body(x.t0) >= rng(x.t0) * 0.6
      && eqTol(x.t0.open, a.open, Math.max(rng(x.t0), rng(a)))
  },
  bullish_hikkake: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return a.high < b.high && a.low > b.low && x.t0.low < a.low
  },
  bearish_hikkake: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return a.high < b.high && a.low > b.low && x.t0.high > a.high
  },
  dumpling_top: (x) => {
    const a = x.t1; if (!a) return false
    return x.upTrend && eqTol(x.t0.high, a.high, Math.max(rng(x.t0), rng(a))) && x.t0.close < a.close
  },
  frypan_bottom: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && eqTol(x.t0.low, a.low, Math.max(rng(x.t0), rng(a))) && x.t0.close > a.close
  },
  tweezer_bottom: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && eqTol(x.t0.low, a.low, Math.max(rng(x.t0), rng(a)))
  },
  tweezer_top: (x) => {
    const a = x.t1; if (!a) return false
    return x.upTrend && eqTol(x.t0.high, a.high, Math.max(rng(x.t0), rng(a)))
  },
  stick_sandwich: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.dnTrend && red(b) && green(a) && red(x.t0)
      && eqTol(x.t0.close, b.close, Math.max(rng(x.t0), rng(b)))
  },
  bullish_star: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && red(a) && body(a) >= rng(a) * 0.5
      && body(x.t0) <= rng(x.t0) * 0.25 && x.t0.open < a.close
  },
  bearish_star: (x) => {
    const a = x.t1; if (!a) return false
    return x.upTrend && green(a) && body(a) >= rng(a) * 0.5
      && body(x.t0) <= rng(x.t0) * 0.25 && x.t0.open > a.close
  },
  bullish_doji_star: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && red(a) && body(a) >= rng(a) * 0.5 && isDoji(x.t0) && x.t0.open < a.close
  },
  bearish_doji_star: (x) => {
    const a = x.t1; if (!a) return false
    return x.upTrend && green(a) && body(a) >= rng(a) * 0.5 && isDoji(x.t0) && x.t0.open > a.close
  },
  upgap_side_by_side_white_lines: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    const ref = Math.max(rng(x.t0), rng(a))
    return x.upTrend && green(a) && green(x.t0) && a.open > b.high
      && eqTol(x.t0.open, a.open, ref) && eqTol(x.t0.close, a.close, ref)
  },
  downgap_side_by_side_white_lines: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    const ref = Math.max(rng(x.t0), rng(a))
    return x.dnTrend && green(a) && green(x.t0) && a.open < b.low
      && eqTol(x.t0.open, a.open, ref) && eqTol(x.t0.close, a.close, ref)
  },

  /* ── 3-candle ── */
  morning_star: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.dnTrend && red(b) && body(b) >= rng(b) * 0.5
      && body(a) <= rng(a) * 0.3 && a.open < b.close
      && green(x.t0) && x.t0.close > midBody(b)
  },
  evening_star: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.upTrend && green(b) && body(b) >= rng(b) * 0.5
      && body(a) <= rng(a) * 0.3 && a.open > b.close
      && red(x.t0) && x.t0.close < midBody(b)
  },
  morning_doji_star: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.dnTrend && red(b) && body(b) >= rng(b) * 0.5
      && isDoji(a) && a.open < b.close
      && green(x.t0) && x.t0.close > midBody(b)
  },
  evening_doji_star: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.upTrend && green(b) && body(b) >= rng(b) * 0.5
      && isDoji(a) && a.open > b.close
      && red(x.t0) && x.t0.close < midBody(b)
  },
  abandoned_baby_bottom: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.dnTrend && red(b) && body(b) >= rng(b) * 0.5
      && isDoji(a) && a.open < b.low && a.high < b.low
      && green(x.t0) && x.t0.open > a.high
  },
  abandoned_baby_top: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.upTrend && green(b) && body(b) >= rng(b) * 0.5
      && isDoji(a) && a.open > b.high && a.low > b.high
      && red(x.t0) && x.t0.open < a.low
  },
  three_black_crows: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.upTrend && red(b) && red(a) && red(x.t0)
      && a.close < b.close && x.t0.close < a.close
      && a.open < b.open && a.open > b.close
      && x.t0.open < a.open && x.t0.open > a.close
  },
  advance_block: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.upTrend && green(b) && green(a) && green(x.t0)
      && x.t0.close > a.close && a.close > b.close
      && body(b) > body(a) && body(a) > body(x.t0)
      && a.open > b.open && a.open < b.close
      && x.t0.open > a.open && x.t0.open < a.close
      && upwick(x.t0) >= body(x.t0) * 0.5
  },
  three_advancing_white_soldiers: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.dnTrend && green(b) && green(a) && green(x.t0)
      && x.t0.close > a.close && a.close > b.close
      && a.open > b.open && a.open < b.close
      && x.t0.open > a.open && x.t0.open < a.close
      && upwick(b) <= body(b) * 0.3 && upwick(a) <= body(a) * 0.3 && upwick(x.t0) <= body(x.t0) * 0.3
  },
  bullish_three_line_strike: (x) => {
    const a = x.t1; const b = x.t2; const c3 = x.t3; if (!a || !b || !c3) return false
    return red(c3) && red(b) && red(a)
      && a.close < b.close && b.close < c3.close
      && b.open < c3.open && b.open > c3.close
      && a.open < b.open && a.open > b.close
      && green(x.t0) && body(x.t0) >= rng(x.t0) * 0.6 && x.t0.close > c3.open
  },
  bearish_three_line_strike: (x) => {
    const a = x.t1; const b = x.t2; const c3 = x.t3; if (!a || !b || !c3) return false
    return green(c3) && green(b) && green(a)
      && a.close > b.close && b.close > c3.close
      && b.open > c3.open && b.open < c3.close
      && a.open > b.open && a.open < b.close
      && red(x.t0) && body(x.t0) >= rng(x.t0) * 0.6 && x.t0.close < c3.open
  },
  upward_gapping_tasuki: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.upTrend && green(b) && green(a) && a.open > b.high
      && red(x.t0) && x.t0.open < a.close && x.t0.open > a.open && x.t0.close < a.open
  },
  downward_gapping_tasuki: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.dnTrend && red(b) && red(a) && a.open < b.low
      && green(x.t0) && x.t0.open < a.open && x.t0.open > a.close && x.t0.close > a.open
  },
  upside_gap_two_crows: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.upTrend && green(b) && red(a) && a.open > b.high
      && red(x.t0) && x.t0.open > a.open && x.t0.close < a.close && x.t0.close > b.close
  },
  tri_star_bottom: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.dnTrend && isDoji(b) && isDoji(a) && isDoji(x.t0)
      && a.open < Math.min(b.open, b.close)
      && Math.max(x.t0.open, x.t0.close) > Math.max(a.open, a.close)
  },
  tri_star_top: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.upTrend && isDoji(b) && isDoji(a) && isDoji(x.t0)
      && a.open > Math.max(b.open, b.close)
      && Math.min(x.t0.open, x.t0.close) < Math.min(a.open, a.close)
  },
  stalled: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.upTrend && green(b) && green(a) && green(x.t0)
      && body(b) > body(a) && body(a) > body(x.t0)
      && a.open > b.open && a.open < b.close
      && x.t0.open > a.open && x.t0.open < a.close
      && x.t0.close >= a.close && upwick(x.t0) >= body(x.t0)
  },
  three_stars_in_the_south: (x) => {
    const a = x.t1; const b = x.t2; if (!a || !b) return false
    return x.dnTrend && red(b) && dnwick(b) >= body(b) * 2
      && red(a) && a.high < b.high && a.low > b.low && dnwick(a) >= body(a)
      && red(x.t0) && x.t0.high < a.high && x.t0.low > a.low && body(x.t0) <= body(a) * 0.5
  },
  tower_bottom: (x) => {
    const a = x.t1; if (!a) return false
    return x.dnTrend && red(a) && body(a) <= rng(a) * 0.3
      && green(x.t0) && body(x.t0) >= rng(x.t0) * 0.65
  },
  tower_top: (x) => {
    const a = x.t1; if (!a) return false
    return x.upTrend && green(a) && body(a) <= rng(a) * 0.3
      && red(x.t0) && body(x.t0) >= rng(x.t0) * 0.65
  },

  /* ── 4-5 candle ── */
  concealing_baby_swallow: (x) => {
    const a = x.t1; const b = x.t2; const c3 = x.t3; if (!a || !b || !c3) return false
    return x.dnTrend && red(c3) && red(b)
      && upwick(c3) <= rng(c3) * 0.15 && upwick(b) <= rng(b) * 0.15
      && body(c3) >= rng(c3) * 0.55 && body(b) >= rng(b) * 0.55
      && red(a) && a.high >= b.high
      && red(x.t0) && x.t0.open >= a.close && x.t0.close <= a.open && x.t0.low < a.low
  },
  rising_three_methods: (x) => {
    const a = x.t1; const b = x.t2; const c3 = x.t3; const c4 = x.t4
    if (!a || !b || !c3 || !c4) return false
    const innerHigh = Math.max(a.high, b.high, c3.high)
    const innerLow = Math.min(a.low, b.low, c3.low)
    return x.upTrend && green(c4) && body(c4) >= rng(c4) * 0.6
      && innerHigh <= c4.high && innerLow >= c4.low
      && body(a) <= rng(a) * 0.4 && body(b) <= rng(b) * 0.4 && body(c3) <= rng(c3) * 0.4
      && green(x.t0) && x.t0.close > c4.close
  },
  falling_three_methods: (x) => {
    const a = x.t1; const b = x.t2; const c3 = x.t3; const c4 = x.t4
    if (!a || !b || !c3 || !c4) return false
    const innerHigh = Math.max(a.high, b.high, c3.high)
    const innerLow = Math.min(a.low, b.low, c3.low)
    return x.dnTrend && red(c4) && body(c4) >= rng(c4) * 0.6
      && innerHigh <= c4.high && innerLow >= c4.low
      && body(a) <= rng(a) * 0.4 && body(b) <= rng(b) * 0.4 && body(c3) <= rng(c3) * 0.4
      && red(x.t0) && x.t0.close < c4.close
  },
  bullish_breakaway: (x) => {
    const a = x.t1; const b = x.t2; const c3 = x.t3; const c4 = x.t4
    if (!a || !b || !c3 || !c4) return false
    const midHigh = Math.max(a.high, b.high, c3.high)
    return x.dnTrend && red(c4) && body(c4) >= rng(c4) * 0.5
      && midHigh < c4.close
      && green(x.t0) && body(x.t0) >= rng(x.t0) * 0.5
      && x.t0.close > midHigh && x.t0.close <= c4.open
  },
  bearish_breakaway: (x) => {
    const a = x.t1; const b = x.t2; const c3 = x.t3; const c4 = x.t4
    if (!a || !b || !c3 || !c4) return false
    const midLow = Math.min(a.low, b.low, c3.low)
    return x.upTrend && green(c4) && body(c4) >= rng(c4) * 0.5
      && midLow > c4.close
      && red(x.t0) && body(x.t0) >= rng(x.t0) * 0.5
      && x.t0.close < midLow && x.t0.close >= c4.open
  },
}

/* Invariant structurel : chaque id a SON détecteur (73/73). */
const DETECTOR_KEYS = Object.keys(CANDLE_PATTERN_DETECTORS)
if (DETECTOR_KEYS.length !== CANDLE_PATTERN_COUNT) {
  throw new Error(`candle-patterns : ${DETECTOR_KEYS.length} détecteurs, ${CANDLE_PATTERN_COUNT} attendus`)
}
for (const id of CANDLE_PATTERN_IDS) {
  if (typeof CANDLE_PATTERN_DETECTORS[id] !== 'function') {
    throw new Error(`candle-patterns : détecteur manquant pour « ${id} »`)
  }
}

/* ═══════════════════ calcul (moteur de détection) ═══════════════════ */

export interface ComputeCandlePatternOptions {
  /** Tick minimum — par défaut 0 (labels par ATR seul). */
  mintick?: number
  /** ATR interne pour les offsets de labels (défaut : ATR 14 du pack). */
  atrOverride?: number
}

/** SMA interne au moteur (contexte de tendance des patterns) — jamais exposée. */
function smaSeries(values: number[], len: number): Array<number | null> {
  const n = values.length
  const out: Array<number | null> = new Array(n).fill(null)
  if (n === 0 || len <= 0) return out
  let sum = 0
  for (let i = 0; i < n; i++) {
    sum += values[i]
    if (i >= len) sum -= values[i - len]
    if (i >= len - 1) out[i] = sum / len
  }
  return out
}

/** ATR(14) Wilder — mêmes règles que le moteur BOS/CHoCH/CISD. */
function atr14(candles: CandlePatternCandle[]): Array<number | null> {
  const n = candles.length
  const out: Array<number | null> = new Array(n).fill(null)
  let prevClose = NaN
  let count = 0
  let sum = 0
  let prev = NaN
  const len = 14
  for (let i = 0; i < n; i++) {
    const c = candles[i]
    const tr = !Number.isFinite(prevClose)
      ? c.high - c.low
      : Math.max(c.high - c.low, Math.abs(c.high - prevClose), Math.abs(c.low - prevClose))
    prevClose = c.close
    if (count < len) {
      sum += tr
      count++
      if (count === len) prev = sum / len
    } else {
      prev = (prev * (len - 1) + tr) / len
    }
    out[i] = Number.isFinite(prev) ? prev : null
  }
  return out
}

/**
 * Détecte les patterns candle sur la DERNIÈRE bougie de la série.
 *
 * Retourne les ids détectés (dans l'ordre du pack) — utilisé par le Rule
 * Engine (Auto Trade L_Lucien/Ninja ProTrader + Strategy Tester). La
 * détection est TOUJOURS complète : aucun filtre d'affichage ici (§33).
 *
 * `includeForming` : la série peut se terminer par la bougie EN FORMATION
 * (Ninja ProTrader) — les patterns dont la définition le permet (formes
 * de la bougie courante + bougies clôturées précédentes) y sont détectés
 * en temps réel ; les patterns 100 % « à la clôture » du pack source
 * restent détectables par la même forme appliquée au prix courant.
 */
export function detectCandlePatternsOnLastBar(
  candles: CandlePatternCandle[],
): CandlePatternId[] {
  const n = candles.length
  if (n === 0) return []
  /* bougie dégénérée (étendue nulle) : AUCUN pattern (garde anti-faux positif). */
  const lastCandle = candles[n - 1]
  if (!(lastCandle.high > lastCandle.low)) return []
  const closes = candles.map((c) => c.close)
  const fast = smaSeries(closes, 14)
  const slow = smaSeries(closes, 50)
  const i = n - 1
  const f = fast[i]; const s = slow[i]
  const upTrend = f != null && s != null && f > s
  const dnTrend = f != null && s != null && f < s
  const ctx: CandlePatternContext = {
    t0: candles[i],
    t1: i >= 1 ? candles[i - 1] : null,
    t2: i >= 2 ? candles[i - 2] : null,
    t3: i >= 3 ? candles[i - 3] : null,
    t4: i >= 4 ? candles[i - 4] : null,
    upTrend,
    dnTrend,
  }
  const out: CandlePatternId[] = []
  for (const def of CANDLE_PATTERN_DEFS) {
    try {
      if (CANDLE_PATTERN_DETECTORS[def.id](ctx)) out.push(def.id)
    } catch { /* bougie dégénérée (range 0) — détecteur protégé */ }
  }
  return out
}

/**
 * Calcule les événements candle patterns sur TOUTE la série (affichage
 * graphique + Strategy Tester). Les positions Y suivent les règles
 * d'offset/empilement du pack (ATR + piles above/below par bougie,
 * remises à zéro à chaque nouvelle bougie — l'ordre d'évaluation est
 * l'ordre du pack, celui des blocs if du Main source).
 */
export function computeCandlePatternEvents(
  candles: CandlePatternCandle[],
  opts: ComputeCandlePatternOptions = {},
): CandlePatternEvent[] {
  const n = candles.length
  if (n === 0) return []
  const closes = candles.map((c) => c.close)
  const fast = smaSeries(closes, 14)
  const slow = smaSeries(closes, 50)
  const atr = opts.atrOverride != null && Number.isFinite(opts.atrOverride)
    ? new Array(n).fill(opts.atrOverride)
    : atr14(candles)
  const mintick = Number.isFinite(opts.mintick) ? Math.max(0, opts.mintick as number) : 0

  const events: CandlePatternEvent[] = []
  for (let i = 0; i < n; i++) {
    /* bougie dégénérée (étendue nulle) : AUCUN pattern (garde anti-faux positif). */
    if (!(candles[i].high > candles[i].low)) continue
    const f = fast[i]; const s = slow[i]
    const upTrend = f != null && s != null && f > s
    const dnTrend = f != null && s != null && f < s
    const ctx: CandlePatternContext = {
      t0: candles[i],
      t1: i >= 1 ? candles[i - 1] : null,
      t2: i >= 2 ? candles[i - 2] : null,
      t3: i >= 3 ? candles[i - 3] : null,
      t4: i >= 4 ? candles[i - 4] : null,
      upTrend,
      dnTrend,
    }
    /* piles du pack — remises à zéro à chaque nouvelle bougie */
    let aboveStack = 0
    let belowStack = 0
    const a = atr[i] ?? 0
    const baseOffset = Math.max(a * 0.3, mintick * 10)
    const stackStep = Math.max(a * 0.2, mintick * 10)
    for (const def of CANDLE_PATTERN_DEFS) {
      let fired = false
      try {
        fired = CANDLE_PATTERN_DETECTORS[def.id](ctx)
      } catch { fired = false }
      if (!fired) continue
      const c = candles[i]
      const labelY = def.position === 'below'
        ? c.low - baseOffset - stackStep * belowStack
        : c.high + baseOffset + stackStep * aboveStack
      const lane = def.position === 'below' ? belowStack : aboveStack
      if (def.position === 'below') belowStack++
      else aboveStack++
      events.push({
        patternId: def.id,
        label: def.label,
        direction: def.direction,
        position: def.position,
        barIndex: i,
        candleTime: c.time,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
        labelY,
        lane,
      })
    }
  }
  return events
}

/**
 * Déduplication (§28) : clé d'unicité d'un événement candle =
 * patternId + direction + candleTime. Une répétition ultérieure n'est
 * permise que lorsqu'un NOUVEL événement réel existe (autre bougie).
 */
export function dedupeCandlePatternEvents(events: CandlePatternEvent[]): CandlePatternEvent[] {
  const seen = new Set<string>()
  const out: CandlePatternEvent[] = []
  for (const e of events) {
    const key = `${e.patternId}|${e.direction}|${e.candleTime}`
    if (seen.has(key)) continue
    seen.add(key)
    out.push(e)
  }
  return out
}



