/**
 * signal-label-manager.ts — Gestionnaire centralisé des labels de signaux
 * (§25-§29) — COLLISION-FREE.
 * ====================================================================
 * Reçoit les événements (ICT du moteur BOS/CHoCH/CISD + les 73 patterns
 * candle du pack source) et produit un LAYOUT prêt au rendu :
 *
 *   - DÉDUPLICATION (§28) : clé type + direction + candleTime +
 *     referenceLevel (BOS : swing cassé) / patternId + direction +
 *     candleTime (candles) — une répétition n'est permise que pour un
 *     NOUVEL événement réel ;
 *   - GROUPAGE (§25) : les événements d'une même bougie/voie se
 *     regroupent en BADGES COMPACTS (« ENGULFING · HAMMER ») — jamais
 *     de superposition, chaque élément reste lisible ;
 *   - VOIES (lanes) : empilement vertical par bougie et par côté
 *     (above/below), offsets ATR/mintick identiques au pack ;
 *   - PRIORITÉ (§27) : 1. BOS/CHoCH/CISD · 2. ICT setups ·
 *     3. Candlestick · 4. Swings · 5. Liquidity · 6. Context ;
 *   - LIVE (§29) : les événements de la bougie EN FORMATION portent le
 *     préfixe « LIVE · » et sont MIS À JOUR (clés stables, réutilisation
 *     des objets) — jamais recréés à chaque tick ;
 *   - PERFORMANCE (§26) : cache interne par clé — les appels répétés
 *     réutilisent les mêmes objets de layout (aucune explosion, aucun
 *     re-rendu inutile du DOM/Canvas).
 *
 * Le manager est PUR vis-à-vis de la détection : il ne filtre QUE des
 * éléments d'affichage (les filtres de visibilité s'appliquent à la
 * SORTIE — §33 : masquer n'empêche jamais la détection).
 */

import type { BosChochCisdEvent } from './bos-choch-cisd'
import type { CandlePatternEvent } from './candle-patterns'
import { SIGNAL_DISPLAY_PRIORITY, type SignalCategory, type SignalDirection } from './signal-registry'

/* ═══════════════════════════ types ═══════════════════════════ */

/** Un badge du layout final (regroupe 1..N événements d'une même voie). */
export interface SignalLabelBadge {
  /** Clé de DÉDUPLICATION stable (bar|side|classe|contenu trié). */
  key: string
  /** Indice de la bougie porteuse. */
  barIndex: number
  /** Temps de la bougie porteuse. */
  time: number
  /** Côté : 'below' (haussier) | 'above' (baissier/neutre). */
  side: 'above' | 'below'
  /** Voie d'empilement (0 = premier badge de la bougie/côté). */
  lane: number
  /** Texte compact du badge (ex. « ENGULFING · HAMMER »). */
  text: string
  /** Ids des signaux regroupés (détections réelles). */
  ids: string[]
  /** Couleur du badge (palette professionnelle §30). */
  color: string
  /** Priorité d'affichage (1 = la plus haute). */
  priority: number
  /** true = événements de la bougie EN FORMATION (préfixe LIVE ·). */
  live: boolean
  /** Classe du badge (structure | candle | other). */
  klass: 'structure' | 'candle' | 'other'
}

/** Palette professionnelle (§30) — contrastes suffisants, rien de criard. */
export const SIGNAL_BADGE_COLORS = {
  bullish: '#089981',
  bearish: '#F23645',
  neutral: '#64748b',
  structure: '#2962FF',
}

/** Entrée d'événement normalisée pour le manager. */
export interface SignalLabelEventInput {
  /** Id stable du signal (label pack ou patternId). */
  id: string
  /** Libellé court affiché dans le badge. */
  label: string
  category: SignalCategory
  direction: SignalDirection
  /** Indice de la bougie porteuse. */
  barIndex: number
  /** Temps de la bougie porteuse. */
  time: number
  /** Côté d'affichage. */
  side: 'above' | 'below'
  /** Niveau de référence (ligne cassée — clé de dédup BOS). */
  referenceLevel?: number
}

/** Convertit les événements BOS/CHoCH/CISD du moteur en entrées manager. */
export function bosEventsToLabelInputs(events: BosChochCisdEvent[], liveBarIndex: number | null): SignalLabelEventInput[] {
  return events.map((e) => ({
    id: e.label,
    label: e.label.replace(' ', ' ').toUpperCase().replace('BOS ', 'BOS ').replace('CHOCH ', 'CHoCH '),
    category: 'STRUCTURE' as SignalCategory,
    direction: (e.dir === 'up' ? 'bullish' : 'bearish') as SignalDirection,
    barIndex: e.barIndex,
    time: e.time,
    side: e.dir === 'up' ? ('below' as const) : ('above' as const),
    referenceLevel: e.linePrice,
    ...(liveBarIndex != null && e.barIndex === liveBarIndex ? { live: true } : {}),
  })) as SignalLabelEventInput[]
}

/** Convertit les événements candle (73 patterns) en entrées manager. */
export function candleEventsToLabelInputs(events: CandlePatternEvent[], liveBarIndex: number | null): SignalLabelEventInput[] {
  return events.map((e) => ({
    id: e.patternId,
    label: shortCandleLabel(e.label),
    category: 'CANDLE' as SignalCategory,
    direction: e.direction as SignalDirection,
    barIndex: e.barIndex,
    time: e.candleTime,
    side: e.position === 'below' ? ('below' as const) : ('above' as const),
    ...(liveBarIndex != null && e.barIndex === liveBarIndex ? { live: true } : {}),
  })) as SignalLabelEventInput[]
}

/** Libellé compact d'un pattern candle (badge multi-patterns §25). */
export function shortCandleLabel(label: string): string {
  return label
    .replace(/^Bullish /, '')
    .replace(/^Bearish /, '')
    .replace('White Lines', '')
    .replace(/ {2,}/g, ' ')
    .trim()
    .toUpperCase()
}

/* ═══════════════════════════ manager ═══════════════════════════ */

export interface SignalLabelLayoutOptions {
  /** Indice de la bougie EN FORMATION (badges LIVE ·) — null si n/a. */
  liveBarIndex?: number | null
  /** Filtre de visibilité par signal (§33 — AFFICHAGE SEUL). */
  isSignalVisible?: (id: string, category: SignalCategory, direction: SignalDirection) => boolean
}

/**
 * SignalLabelManager — produit le layout des badges à partir des
 * événements. Instance À CONSERVER entre les frames (cache par clé —
 * §26/§29 : les badges LIVE sont mis à jour, pas recréés).
 */
export class SignalLabelManager {
  /** Cache des badges par clé — réutilisation des objets. */
  private badgeCache = new Map<string, SignalLabelBadge>()

  clear(): void {
    this.badgeCache.clear()
  }

  /**
   * Construit le layout : déduplication → filtrage VISUEL → groupage en
   * badges par (bougie, côté, classe) → voies d'empilement.
   */
  layout(events: SignalLabelEventInput[], opts: SignalLabelLayoutOptions = {}): SignalLabelBadge[] {
    const visible = (e: SignalLabelEventInput): boolean =>
      opts.isSignalVisible ? opts.isSignalVisible(e.id, e.category, e.direction) : true

    /* 1. DÉDUPLICATION (§28) — type + direction + candleTime + référence. */
    const seen = new Set<string>()
    const deduped: SignalLabelEventInput[] = []
    for (const e of events) {
      const key = `${e.id}|${e.direction}|${e.time}|${e.referenceLevel != null ? e.referenceLevel.toFixed(6) : ''}`
      if (seen.has(key)) continue
      seen.add(key)
      deduped.push(e)
    }

    /* 2. FILTRAGE VISUEL (§33 — n'affecte jamais la détection amont). */
    const shown = deduped.filter(visible)
    if (shown.length === 0) return []

    /* 3. GROUPAGE par (bougie, côté, classe) — badges compacts (§25). */
    type Group = {
      barIndex: number
      time: number
      side: 'above' | 'below'
      klass: 'structure' | 'candle' | 'other'
      items: SignalLabelEventInput[]
      live: boolean
    }
    const groups = new Map<string, Group>()
    const classOf = (c: SignalCategory): 'structure' | 'candle' | 'other' =>
      c === 'STRUCTURE' ? 'structure' : c === 'CANDLE' ? 'candle' : 'other'
    for (const e of shown) {
      const klass = classOf(e.category)
      const gk = `${e.barIndex}|${e.side}|${klass}`
      let g = groups.get(gk)
      if (!g) {
        g = { barIndex: e.barIndex, time: e.time, side: e.side, klass, items: [], live: false }
        groups.set(gk, g)
      }
      g.items.push(e)
      if (opts.liveBarIndex != null && e.barIndex === opts.liveBarIndex) g.live = true
    }

    /* 4. BADGES — tri par priorité (§27) dans le badge, voies par bougie. */
    const laneCounters = new Map<string, number>()
    const badges: SignalLabelBadge[] = []
    for (const g of groups.values()) {
      g.items.sort((a, b) => {
        const pa = SIGNAL_DISPLAY_PRIORITY[a.category] ?? 6
        const pb = SIGNAL_DISPLAY_PRIORITY[b.category] ?? 6
        if (pa !== pb) return pa - pb
        return a.id.localeCompare(b.id)
      })
      const ids = g.items.map((e) => e.id)
      const texts = g.items.map((e) => e.label)
      const dedupTexts = [...new Set(texts)]
      const key = `${g.barIndex}|${g.side}|${g.klass}|${dedupTexts.join('·')}`
      /* réutilisation d'objet (§26) — mise à jour IN PLACE des badges LIVE. */
      const cached = this.badgeCache.get(key)
      const badge: SignalLabelBadge = cached ?? {
        key, barIndex: g.barIndex, time: g.time, side: g.side, lane: 0,
        text: '', ids: [], color: SIGNAL_BADGE_COLORS.neutral, priority: 6, live: false, klass: g.klass,
      }
      badge.barIndex = g.barIndex
      badge.time = g.time
      badge.side = g.side
      badge.ids = ids
      badge.text = dedupTexts.join(' · ')
      badge.live = g.live
      badge.priority = Math.min(...g.items.map((e) => SIGNAL_DISPLAY_PRIORITY[e.category] ?? 6))
      /* couleur du badge : direction dominante (structure > candle). */
      const dirCount = { bullish: 0, bearish: 0, neutral: 0 }
      for (const e of g.items) dirCount[e.direction] = (dirCount[e.direction] ?? 0) + 1
      if (g.klass === 'structure') badge.color = SIGNAL_BADGE_COLORS.structure
      else if (dirCount.bullish >= dirCount.bearish && dirCount.bullish >= (dirCount.neutral ?? 0)) badge.color = SIGNAL_BADGE_COLORS.bullish
      else if (dirCount.bearish > 0 && dirCount.bearish >= (dirCount.neutral ?? 0)) badge.color = SIGNAL_BADGE_COLORS.bearish
      else badge.color = SIGNAL_BADGE_COLORS.neutral
      if (!cached) this.badgeCache.set(key, badge)
      /* voie : une par (bougie, côté) — ordre = priorité des classes. */
      const laneKey = `${g.barIndex}|${g.side}`
      const lane = laneCounters.get(laneKey) ?? 0
      badge.lane = lane
      laneCounters.set(laneKey, lane + 1)
      badges.push(badge)
    }

    /* 5. TRI : bougie puis priorité de classe puis voie. */
    badges.sort((a, b) =>
      a.barIndex - b.barIndex
      || (a.side === 'below' ? -1 : 1) - (b.side === 'below' ? -1 : 1)
      || a.priority - b.priority
      || a.lane - b.lane,
    )

    /* GC du cache : oublier les badges disparus (stabilité mémoire). */
    if (this.badgeCache.size > 4000) {
      const liveKeys = new Set(badges.map((b) => b.key))
      for (const k of this.badgeCache.keys()) {
        if (!liveKeys.has(k)) this.badgeCache.delete(k)
      }
    }
    return badges
  }

  /** Nombre de badges en cache (diagnostic performance). */
  get cachedBadgeCount(): number { return this.badgeCache.size }
}
