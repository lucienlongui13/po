/**
 * bos-choch-cisd.ts — Moteur partagé « BOS, CHoCH and CISD »
 * ====================================================================
 * Port TypeScript FIDÈLE du pack Pine v6 de PiracyChecker :
 *   Main.pine (« BOS, CHoCH and CISD [PiracyChecker] »)
 *   + libs/PubLibSwing/3 + PubLibTrend/3 + PubLibUtility/2
 *   + PubLibCandleTrend/2 (import transitif de PubLibSwing)
 *
 * Ce moteur est LA source unique de vérité pour :
 *   - la stratégie Auto Trade « bos_choch_cisd » (front : adaptateur
 *     Strategy Tester ; backend : ordres réels sur bougies clôturées) ;
 *   - la couche visuelle du graphique (labels + lignes d'événements +
 *     lignes de tendance) pilotée par les RÉGLAGES DU PACK.
 *
 * Sémantique Pine reproduite à l'identique :
 *   gc()  = close >= open          (bougie verte — PubLibCandleTrend)
 *   rc()  = close < open           (bougie rouge)
 *   sh()  = gc()[1] and rc()       (swing high : verte puis rouge)
 *   sl()  = rc()[1] and gc()       (swing low  : rouge puis verte)
 *   shp(n)/slp(n) = ta.valuewhen(sh()/sl(), max/min(high|low, high|low[1]), n)
 *   shpbi/slpbi    = idem sur l'indice de barre du point de swing
 *   ut()  = slp(0) > slp(1)        (uptrend : swing lows ascendants)
 *   dt()  = shp(0) < shp(1)        (downtrend : swing highs descendants)
 *   bos_up   = gc and ut and close > shp(0) and close[1] < shp(0)
 *   bos_down = rc and dt and close < slp(0) and close[1] > slp(0)
 *   choch_up = gc and dt and close > shp(0) and close < shp(1) and close[1] < shp(0)
 *   choch_dn = rc and ut and close < slp(0) and close > slp(1) and close[1] > slp(0)
 *   cisd_up  = gc and close > shp(0) and close[1] < shp(0)
 *   cisd_dn  = rc and close < slp(0) and close[1] > slp(0)
 *   (na → comparaison fausse, comme en Pine)
 *
 * Visuels — mêmes règles que le pack :
 *   base_offset = max(atr14 * 0.30, mintick * 10)
 *   stack_step  = max(atr14 * 0.20, mintick * 10)
 *   piles above_stack/below_stack remises à zéro à chaque nouvelle bougie ;
 *   événement UP  → label SOUS la bougie (low  − offset − step·pile)
 *   événement DOWN→ label SUR la bougie  (high + offset + step·pile)
 *   ordre de traitement des if Pine : bos_up, bos_down, choch_up,
 *   choch_down, cisd_up, cisd_down (l'ordre alimente les piles) ;
 *   GC par le pack : 80 labels / famille, 80 lignes d'événement /
 *   famille, 50 lignes de tendance / sens (uptrend/downtrend).
 *
 * Validation : scripts/test-bos-choch-cisd.ts compare ce port, bougie par
 * bougie, avec l'exécution du VRAI pack Pine par le moteur piner.
 *
 * v19 — CONFIRMATION PAR LA BOUGIE PRÉCÉDENTE (switch Auto Trade) :
 *   evaluateBosChochCisdOrderRules / evaluateBosChochCisd acceptent
 *   { confirmPreviousCandle } : ON → un CALL ▲ (BOS/CHoCH/CISD Up) n'est
 *   émis que si la bougie PRÉCÉDANT la bougie signalée est BAISSIÈRE
 *   (close < open) ; un PUT ▼ (BOS/CHoCH/CISD Down) que si elle est
 *   HAUSSIÈRE (close > open). Doji = neutre (aucune confirmation). Refus →
 *   HOLD avec reason explicite. Défaut OFF — comportement inchangé.
 *
 * v22 — CANDLES VALIDATION (règles utilisateur par combinaison) :
 *   chaque règle CALL/PUT porte un champ `candlesValidation` (ex. "RGRR",
 *   R = Rouge, G = Vert — max 5 caractères). Au moment où la combinaison
 *   est émise, le programme vérifie les N dernières bougies CLÔTURÉES dans
 *   l'ordre DU PLUS RÉCENT AU PLUS ANCIEN : la règle "RGRR" exige que la
 *   bougie la plus récente clôturée soit Rouge, la précédente Verte, puis
 *   Rouge, Rouge. La bougie EN FORMATION n'est JAMAIS validée — la
 *   validation commence à la bougie clôturée qui la précède :
 *     - L_Lucien ProTrader (signal à la clôture) : la bougie signalée EST
 *       la bougie clôturée la plus récente → règle[0] = bougie signalée ;
 *     - Ninja ProTrader (signal avant clôture) : le dernier élément du
 *       tableau est la bougie EN FORMATION → l'ancre de validation est la
 *       bougie clôturée précédente (option validationSkipForming).
 *   gc/rc étant exclusifs, un doji (close === open) compte comme VERTE
 *   (gc = close >= open) — même rendu que lightweight-charts.
 *   Règle vide = aucune validation (l'ordre suit la combinaison seule).
 *
 * v23 — VÉRIFICATION CISD (swing intact + confirmation par signal combiné) :
 *   les combinaisons CISD Up / CISD Down ont un bon winRate mais une
 *   faiblesse capable de conséquences graves sur le solde (cassure profonde
 *   sans confirmation structurelle). Dorénavant, pour TOUTE règle dont les
 *   alertes contiennent « CISD Up » ou « CISD Down » (L_Lucien ProTrader,
 *   Ninja ProTrader et Strategy Tester) :
 *     1. Signal CISD Up SEUL (sans BOS Up / CHoCH Up sur la bougie) : le
 *        programme vérifie que le SWING HIGH le plus proche — celui que le
 *        CISD franchit — n'a pas été VIOLÉ depuis sa formation (aucune
 *        bougie intermédiaire n'a dépassé son niveau, ni mèche ni clôture) ;
 *        swing intact → la séquence est ARMÉE (aucun ordre) et attend le
 *        signal SUIVANT ; swing violé → refus explicite, aucune séquence ;
 *     2. signal SUIVANT = combiné BOS Up + CISD Up ou CHoCH Up + CISD Up
 *        (BOS/CHoCH embarquent toujours CISD dans ce moteur) → l'ordre
 *        CALL ▲ est placé ; tout autre signal suivant consomme la
 *        séquence sans ordre ;
 *     3. un signal combiné SANS CISD vérifié préalable (ex. cassure
 *        profonde d'entrée de jeu) est REFUSÉ — c'est précisément la
 *        protection demandée contre les pertes graves.
 *   Miroir exact pour CISD Down : swing low intact → séquence armée →
 *   combiné BOS Down + CISD Down ou CHoCH Down + CISD Down → PUT ▼.
 *   La vérification est ACTIVE en permanence (aucun réglage) mais
 *   uniquement lorsque l'appelant fournit un état de garde
 *   (options.cisdGuard) : les règles sans alerte CISD et les appels sans
 *   état conservent le comportement v22 à l'identique.
 *
 * v24 — ÉTAPES DE VÉRIFICATION CISD OPTIONNELLES (cases à cocher) :
 *   chaque étape de la v23 devient configurable par l'utilisateur
 *   (panneau Auto Trade, partagée L_Lucien ProTrader / Ninja ProTrader /
 *   Strategy Tester) via CisdGuardConfig :
 *     - up / down            : active/désactive la vérification pour les
 *                              combinaisons CISD Up (resp. Down). Désactivée
 *                              → retour au comportement v22 (ordre direct
 *                              sur la seule combinaison d'alertes) ;
 *     - swingMode             : 'intact' (défaut v23 — arme si le swing
 *                              high/low le plus proche n'a PAS été violé)
 *                              ou 'violated' (arme si le swing a ÉTÉ violé
 *                              — sweep de liquidité détecté) ;
 *     - confirmBosUp / confirmChochUp (CALL ▲) et confirmBosDown /
 *       confirmChochDown (PUT ▼) : quelles combinaisons de confirmation
 *       sont ACCEPTÉES à l'étape 3 (BOS + CISD et/ou CHoCH + CISD).
 *   Défaut = v23 intégral (tout coché, swing intact, BOS et CHoCH acceptés).
 *   Sans configuration (handle sans config), comportement v23 à l'identique.
 *
 * v25 — LIBERTÉ TOTALE SUR LE SWING + « remaining Time Before Candle
 *   Closure » (switch PAR combinaison CALL/PUT, L_Lucien ProTrader et
 *   Ninja ProTrader) :
 *     - swingMode 'none' : les cases « Swing NON violé » ET « Swing
 *       VIOLÉ » peuvent être TOUTES DÉCOCHÉES — l'étape de vérification
 *       du swing est IGNORÉE : un CISD seul arme la séquence sans aucune
 *       exigence sur le swing (détail « swing non vérifié — étape
 *       ignorée ») ;
 *     - règle portant le switch remaining : l'expiration de l'ordre =
 *       TEMPS RESTANT avant la clôture de la bougie qui reçoit le signal
 *       (compteur de bougie, ex. 00:18 restant → 18 s). Le switch, une
 *       fois ON, REMPLACE le champ Expiration : sans horloge fournie NI
 *       expiration statique de secours → HOLD documenté ; avec repli
 *       statique → expiration statique ; avec horloge → expiration
 *       dynamique (clamp ≥ 3 s).
 *
 * v26 — INTÉGRATION DES 73 CANDLESTICK PATTERNS (pack source super_candles
 *   « All Candlestick Patterns [theEccentricTrader] ») :
 *   les règles CALL/PUT acceptent des conditions MIXTES — alertes du pack
 *   (BOS/CHoCH/CISD) ET patterns candle (shared/candle-patterns.ts, 73
 *   détecteurs) dans une même règle, en logique AND (§12 : TOUTES les
 *   conditions doivent être satisfaites, JAMAIS un OR). Exemple : CALL =
 *   BOS Up + Bullish Engulfing. La détection candle se fait sur la bougie
 *   évaluée (clôturée pour L_Lucien, EN FORMATION pour Ninja si la
 *   définition le permet). Expiration par règle en MODES : 'seconds'
 *   (hérité), 'candles' (expiryCandles — le Strategy Tester l'utilise
 *   directement ; l'adaptation broker convertit en secondes = candles ×
 *   timeframeSeconds, UNIQUEMENT au niveau broker), 'remaining' (v25).
 *   COMPATIBILITÉ ARRIÈRE (§32) : une ancienne règle « BOS Up +
 *   expirationSeconds: 60 » fonctionne à l'identique ; une règle mixte
 *   « BOS Up + Bullish Engulfing + expirationMode candles (3) » également.
 */

/* ═══════════════════════════════ types ═══════════════════════════════ */

import {
  CANDLE_PATTERN_IDS,
  candlePatternLabel,
  detectCandlePatternsOnLastBar,
  type CandlePatternId,
} from './candle-patterns'

export interface BosChochCisdCandle {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume?: number
}

export type BosChochCisdLabelSize = 'Tiny' | 'Small' | 'Normal' | 'Large' | 'Huge' | 'Auto'

/**
 * Réglages — les MÊMES paramètres que le pack Pine (groupes « Labels » et
 * « Alerts », mêmes libellés, mêmes valeurs par défaut).
 */
export type BosChochCisdOrderAlert =
  | 'BOS Up'
  | 'BOS Down'
  | 'CHoCH Up'
  | 'CHoCH Down'
  | 'CISD Up'
  | 'CISD Down'

/**
 * v26 — Condition d'une règle : alerte du pack BOS/CHoCH/CISD OU id d'un
 * des 73 candlestick patterns du pack source (§7/§8/§11). Logique AND
 * entre toutes les conditions d'une règle (§12).
 */
export type BosChochCisdOrderCondition = BosChochCisdOrderAlert | CandlePatternId

/** v26 — Mode d'expiration d'une règle. */
export type BosChochCisdExpirationMode = 'seconds' | 'candles' | 'remaining'

export interface BosChochCisdOrderRule {
  id: string
  /** Conditions AND de la règle (alertes pack + patterns candle). */
  alerts: BosChochCisdOrderCondition[]
  /**
   * Expiration en SECONDES (mode 'seconds', champ historique v21 — une
   * règle sans expiration utilisateur est invalide, aucun ordre).
   * Conservé tel quel pour la compatibilité arrière (§32).
   */
  expirationSeconds?: number
  /**
   * v22 — « Candles Validation » : règle de validation des bougies
   * (ex. "RGRR", R = Rouge, G = Vert — max 5 caractères, lue de la bougie
   * clôturée la plus récente à la plus ancienne). Vide/absent = aucune
   * validation : l'ordre est placé sur la seule combinaison d'alertes.
   */
  candlesValidation?: string
  /**
   * v26 — mode d'expiration : 'seconds' (défaut si expirationSeconds
   * présent), 'candles' (expirationCandles utilisé directement par le
   * Strategy Tester ; broker = candles × timeframeSeconds), 'remaining'
   * (v25 — temps restant avant clôture de la bougie qui reçoit le signal).
   */
  expirationMode?: BosChochCisdExpirationMode
  /** v26 — expiration en NOMBRE DE BOUGIES (mode 'candles'). */
  expirationCandles?: number
  /**
   * v25 — switch « remaining Time Before Candle Closure » : une fois ON,
   * REMPLACE le champ Expiration — l'expiration de l'ordre devient le
   * temps restant avant la clôture de la bougie du signal.
   */
  remainingTimeBeforeClosure?: boolean
}

export const BCC_ORDER_ALERTS: BosChochCisdOrderAlert[] = [
  'BOS Up', 'BOS Down', 'CHoCH Up', 'CHoCH Down', 'CISD Up', 'CISD Down',
]

/** v26 — Toutes les conditions valides d'une règle (6 alertes + 73 candles). */
export const BCC_ORDER_CONDITIONS: string[] = [...BCC_ORDER_ALERTS, ...CANDLE_PATTERN_IDS]

/** v26 — Une condition est-elle valide (alerte pack ou pattern candle) ? */
export function isBosChochCisdOrderCondition(v: unknown): v is BosChochCisdOrderCondition {
  return typeof v === 'string' && BCC_ORDER_CONDITIONS.includes(v)
}

export const DEFAULT_BOS_CHOCH_CISD_ORDER_RULES: {
  callRules: BosChochCisdOrderRule[]
  putRules: BosChochCisdOrderRule[]
} = {
  // Aucune règle préconfigurée : l'utilisateur doit explicitement choisir
  // les alertes ET l'expiration avant qu'un ordre BOS/CHoCH/CISD soit autorisé.
  callRules: [],
  putRules: [],
}

function normalizeOrderRule(rule: Partial<BosChochCisdOrderRule>, index: number, prefix: 'call' | 'put'): BosChochCisdOrderRule | null {
  // v26 — conditions MIXTES : alertes du pack (BOS/CHoCH/CISD) et patterns
  // candle (73) sont toutes valides, en logique AND (§12).
  const alerts = Array.isArray(rule.alerts)
    ? rule.alerts.filter(isBosChochCisdOrderCondition)
    : []
  const uniqueAlerts = [...new Set(alerts)]
  if (uniqueAlerts.length === 0) return null
  const id = typeof rule.id === 'string' && rule.id.trim() ? rule.id.trim() : `${prefix}-${index + 1}`
  // v22 — Candles Validation sanitizée (R/G uniquement, max 5, majuscules).
  const candlesValidation = normalizeCandlesValidation(rule.candlesValidation)
  // v25/v26 — MODES d'expiration :
  //   'remaining' : le switch remainingTimeBeforeClosure REMPLACE le champ
  //                Expiration — la règle est valide SANS valeur statique ;
  //   'candles'  : expirationCandles ∈ [1, 50] exigé ;
  //   'seconds'  : expirationSeconds ∈ [3, 86400] exigé (champ historique
  //                v21 — une règle sans expiration utilisateur est
  //                invalide, aucun ordre : aucun retour silencieux à 60 s).
  const mode: BosChochCisdExpirationMode = rule.remainingTimeBeforeClosure
    ? 'remaining'
    : rule.expirationMode === 'candles' || (rule.expirationMode == null && rule.expirationCandles != null && rule.expirationSeconds == null)
      ? 'candles'
      : 'seconds'
  const rawCandles = Number(rule.expirationCandles)
  const rawSeconds = Number(rule.expirationSeconds)
  if (mode === 'remaining') {
    if (rawSeconds >= 3 && rawSeconds <= 86400) {
      // repli statique explicite conservé (utilisé si aucune horloge fournie)
      return { id, alerts: uniqueAlerts, expirationMode: 'remaining', remainingTimeBeforeClosure: true, expirationSeconds: Math.round(rawSeconds), ...(candlesValidation ? { candlesValidation } : {}) }
    }
    return { id, alerts: uniqueAlerts, expirationMode: 'remaining', remainingTimeBeforeClosure: true, ...(candlesValidation ? { candlesValidation } : {}) }
  }
  if (mode === 'candles') {
    if (!Number.isFinite(rawCandles) || rawCandles < 1 || rawCandles > 50) return null
    return { id, alerts: uniqueAlerts, expirationMode: 'candles', expirationCandles: Math.round(rawCandles), ...(candlesValidation ? { candlesValidation } : {}) }
  }
  if (!Number.isFinite(rawSeconds) || rawSeconds < 3 || rawSeconds > 86400) return null
  return { id, alerts: uniqueAlerts, expirationMode: 'seconds', expirationSeconds: Math.round(rawSeconds), ...(candlesValidation ? { candlesValidation } : {}) }
}

export function normalizeBosChochCisdOrderRules(
  callRules: unknown,
  putRules: unknown,
): { callRules: BosChochCisdOrderRule[]; putRules: BosChochCisdOrderRule[] } {
  const normalize = (value: unknown, prefix: 'call' | 'put') =>
    Array.isArray(value)
      ? value.map((r, i) => normalizeOrderRule((r ?? {}) as Partial<BosChochCisdOrderRule>, i, prefix)).filter((r): r is BosChochCisdOrderRule => r != null)
      : []
  const callsProvided = Array.isArray(callRules)
  const putsProvided = Array.isArray(putRules)
  const calls = normalize(callRules, 'call')
  const puts = normalize(putRules, 'put')
  return {
    callRules: callsProvided ? calls : DEFAULT_BOS_CHOCH_CISD_ORDER_RULES.callRules.map((r) => ({ ...r, alerts: [...r.alerts] })),
    putRules: putsProvided ? puts : DEFAULT_BOS_CHOCH_CISD_ORDER_RULES.putRules.map((r) => ({ ...r, alerts: [...r.alerts] })),
  }
}

export interface BosChochCisdSettings {
  /* Groupe « Labels » (visuels) */
  bosUpLabelColour: string
  bosDownLabelColour: string
  chochUpLabelColour: string
  chochDownLabelColour: string
  cisdUpLabelColour: string
  cisdDownLabelColour: string
  textColour: string
  labelSize: BosChochCisdLabelSize
  /* Groupe « Alerts » — quels événements déclenchent ordres/alertes.
   * Dans le pack ce sont les toggles d'alerte TradingView (défaut OFF) ;
   * en stratégie Auto Trade ils sélectionnent les événements tradés. */
  bosUpAlert: boolean
  bosDownAlert: boolean
  chochUpAlert: boolean
  chochDownAlert: boolean
  cisdUpAlert: boolean
  cisdDownAlert: boolean
  /** Règles de placement Auto Trade : chaque combinaison déclenche son propre ordre/expiration. */
  callRules: BosChochCisdOrderRule[]
  putRules: BosChochCisdOrderRule[]
  /**
   * v26 — Règles PROPRES à Ninja ProTrader (§31 : les paramètres
   * Ninja et L_Lucien ne se mélangent PAS). Absentes au chargement →
   * MIGRATION : copie des règles partagées (comportement historique
   * préservé, puis divergence possible par l'utilisateur).
   */
  ninjaCallRules?: BosChochCisdOrderRule[]
  ninjaPutRules?: BosChochCisdOrderRule[]
  /** v24 — étapes de vérification CISD optionnelles (cases à cocher du
   * panneau Auto Trade — partagées L_Lucien / Ninja / Strategy Tester).
   * Défaut = v23 intégral. */
  cisdGuard: CisdGuardConfig
}

/** Couleurs nommées Pine v6 (valeurs piner/TradingView — parité exacte). */
export const TV_GREEN = '#4CAF50'
export const TV_RED = '#F23645'
export const TV_ORANGE = '#FF9800'
export const TV_BLUE = '#2962FF'
export const TV_WHITE = '#FFFFFF'

/** Valeurs par défaut — pack Pine, à une exception documentée : les 6
 * toggles Alerts passent à ON pour que la stratégie trade dès sa sélection
 * (dans le pack ils ne contrôlent que les alertes TradingView, OFF par
 * défaut). */
export const BOS_CHOCH_CISD_DEFAULT_SETTINGS: BosChochCisdSettings = {
  bosUpLabelColour: TV_GREEN,
  bosDownLabelColour: TV_RED,
  chochUpLabelColour: TV_ORANGE,
  chochDownLabelColour: TV_ORANGE,
  cisdUpLabelColour: TV_BLUE,
  cisdDownLabelColour: TV_BLUE,
  textColour: TV_WHITE,
  labelSize: 'Normal',
  bosUpAlert: true,
  bosDownAlert: true,
  chochUpAlert: true,
  chochDownAlert: true,
  cisdUpAlert: true,
  cisdDownAlert: true,
  callRules: DEFAULT_BOS_CHOCH_CISD_ORDER_RULES.callRules,
  putRules: DEFAULT_BOS_CHOCH_CISD_ORDER_RULES.putRules,
  // v24 — cases à cocher « Vérification CISD » : défaut = v23 intégral
  // (littéral inline : DEFAULT_CISD_GUARD_CONFIG est déclaré plus bas).
  cisdGuard: {
    up: true,
    down: true,
    swingMode: 'intact',
    confirmBosUp: true,
    confirmChochUp: true,
    confirmBosDown: true,
    confirmChochDown: true,
  },
}

export type BosChochCisdEventKind = 'bos' | 'choch' | 'cisd'
export type BosChochCisdDirection = 'up' | 'down'

/** Ligne de tendance structurelle (swing→swing, trait plein). */
export interface BosChochCisdTrendLine {
  fromBarIndex: number
  fromPrice: number
  toBarIndex: number
  toPrice: number
  /** 'uptrend' → verte (swing lows) ; 'downtrend' → rouge (swing highs). */
  kind: 'uptrend' | 'downtrend'
}

/** Un événement BOS/CHoCH/CISD, avec toute sa charge visuelle. */
export interface BosChochCisdEvent {
  kind: BosChochCisdEventKind
  dir: BosChochCisdDirection
  /** Libellé exact du pack : 'BOS Up', 'CHoCH Down', 'CISD Up', … */
  label: string
  barIndex: number
  /** Temps de la bougie (passé tel quel par l'appelant — ms dans l'app). */
  time: number
  close: number
  high: number
  low: number
  /** Position Y du label (règles d'offset/empilement du pack). */
  labelY: number
  /** Niveau de la ligne d'événement (prix du swing cassé). */
  linePrice: number
  /** Début de la ligne d'événement (barre du swing cassé). */
  lineFromBarIndex: number
  /** Couleur de la ligne d'événement : verte (up) / rouge (down). */
  lineColour: string
  /** Ligne de tendance structurelle associée (règles du pack), sinon null. */
  trendLine: BosChochCisdTrendLine | null
}

/** Résultat complet du calcul (événements + état des swings/tendances). */
export interface BosChochCisdResult {
  events: BosChochCisdEvent[]
  /** Dernier swing high/low (occ 0) et précédent (occ 1) — null si absent. */
  swingHighPrice: number | null
  swingLowPrice: number | null
  swingHighPrice1: number | null
  swingLowPrice1: number | null
  uptrend: boolean
  downtrend: boolean
}

/** Signal de trading produit par la stratégie (dernière bougie clôturée). */
export interface BosChochCisdSignal {
  action: 'CALL' | 'PUT' | 'HOLD'
  matchedRuleId?: string
  /** v22 — règle Candles Validation appliquée par la combinaison (ex. "RGRR"), si définie et validée. */
  matchedRuleValidation?: string
  expirationSeconds?: number
  /** v26 — mode d'expiration résolu de la règle ('seconds' par défaut). */
  expirationMode?: BosChochCisdExpirationMode
  /** v26 — expiration en bougies de la règle (mode 'candles'). */
  expirationCandles?: number
  /** v26 — conditions de la règle : alertes pack ET patterns candle. */
  matchedRuleConditions?: string[]
  /** 0-1 — force perçue (BOS 0.85 > CHoCH 0.80 > CISD 0.75). */
  confidence: number
  reason: string
  /** Événements ACTIFS (toggles ON) sur la bougie évaluée. */
  events: string[]
  /** Temps de la bougie évaluée (garde anti re-trade côté backend). */
  candleTime: number
  /**
   * v23 — confirmation CISD portée par l'ordre : séquence « CISD vérifié
   * (swing intact) PUIS signal combiné ». Présente uniquement pour les
   * ordres issus d'une combinaison CISD confirmée (libellés d'ordre).
   */
  cisdConfirmation?: {
    direction: 'up' | 'down'
    /** Temps de la bougie qui a armé la séquence (CISD vérifié, swing intact). */
    armedCandleTime: number
    /** Niveau du swing high (up) / swing low (down) vérifié intact. */
    swingPrice: number
    /** Alertes du signal combiné qui a confirmé (ex. ["BOS Up", "CISD Up"]). */
    confirmedBy: string[]
    /** v24/v25 — exigence swing au moment de l'armement ('intact' par défaut). */
    swingMode?: 'intact' | 'violated' | 'none'
  }
}

/** v24 — Configuration des étapes de vérification CISD (cases à cocher). */
export interface CisdGuardConfig {
  /** Étape 1-3 ACTIVES pour les combinaisons CISD Up (CALL ▲). */
  up: boolean
  /** Étape 1-3 ACTIVES pour les combinaisons CISD Down (PUT ▼). */
  down: boolean
  /**
   * Exigence sur le swing au CISD seul : 'intact' (défaut v23) |
   * 'violated' | 'none' (v25 — les deux cases décochées : l'étape de
   * vérification du swing est IGNORÉE, le CISD seul arme la séquence).
   */
  swingMode: 'intact' | 'violated' | 'none'
  /** CALL ▲ : accepter « BOS Up + CISD Up » comme signal de confirmation. */
  confirmBosUp: boolean
  /** CALL ▲ : accepter « CHoCH Up + CISD Up » comme signal de confirmation. */
  confirmChochUp: boolean
  /** PUT ▼ : accepter « BOS Down + CISD Down » comme signal de confirmation. */
  confirmBosDown: boolean
  /** PUT ▼ : accepter « CHoCH Down + CISD Down » comme signal de confirmation. */
  confirmChochDown: boolean
}

/** Défaut v24 = comportement v23 intégral (protection maximale). */
export const DEFAULT_CISD_GUARD_CONFIG: CisdGuardConfig = {
  up: true,
  down: true,
  swingMode: 'intact',
  confirmBosUp: true,
  confirmChochUp: true,
  confirmBosDown: true,
  confirmChochDown: true,
}

/**
 * v24/v25 — Sanitise une configuration partielle : seuls les champs valides
 * sont retenus (booléens stricts, swingMode ∈ {'intact','violated','none'}) ;
 * tout champ absent/invalid retombe sur le défaut v23.
 */
export function normalizeCisdGuardConfig(partial?: Partial<CisdGuardConfig> | null): CisdGuardConfig {
  const d = DEFAULT_CISD_GUARD_CONFIG
  if (!partial || typeof partial !== 'object') return { ...d }
  const b = (v: unknown, def: boolean): boolean => (typeof v === 'boolean' ? v : def)
  const rawSwing = (partial as Record<string, unknown>).swingMode
  const swingMode = rawSwing === 'violated' ? 'violated' : rawSwing === 'none' ? 'none' : 'intact'
  return {
    up: b((partial as Record<string, unknown>).up, d.up),
    down: b((partial as Record<string, unknown>).down, d.down),
    swingMode,
    confirmBosUp: b((partial as Record<string, unknown>).confirmBosUp, d.confirmBosUp),
    confirmChochUp: b((partial as Record<string, unknown>).confirmChochUp, d.confirmChochUp),
    confirmBosDown: b((partial as Record<string, unknown>).confirmBosDown, d.confirmBosDown),
    confirmChochDown: b((partial as Record<string, unknown>).confirmChochDown, d.confirmChochDown),
  }
}

export interface ComputeBosChochCisdOptions {
  /** Tick minimum — par défaut dérivé des bougies (comme le moteur Pine). */
  mintick?: number
}

/* ═══════════════════════════ helpers internes ═══════════════════════════ */

/** ATR(14) Wilder — reproduction exacte de ta.atr de piner/TradingView. */
function atrSeries(highs: number[], lows: number[], closes: number[], len = 14): Array<number | null> {
  const n = highs.length
  const out: Array<number | null> = new Array(n).fill(null)
  let prevClose = NaN
  let count = 0
  let sum = 0
  let prev = NaN
  for (let i = 0; i < n; i++) {
    const tr = !Number.isFinite(prevClose)
      ? highs[i] - lows[i]
      : Math.max(highs[i] - lows[i], Math.abs(highs[i] - prevClose), Math.abs(lows[i] - prevClose))
    prevClose = closes[i]
    if (count < len) {
      sum += tr
      count++
      if (count === len) prev = sum / len
    } else {
      prev = (prev * (len - 1) + tr) / len
    }
    out[i] = Number.isFinite(prev) ? prev : null
  }
  return out
}

/**
 * Tick minimum observé — heuristique en ligne (miroir de deriveMintick du
 * moteur Pine : médiane des 5 plus petits deltas close→close, plancher
 * pow10, repli sur les décimales du prix, clamp ≤ 0.5 % du prix).
 */
function deriveMintickInline(candles: BosChochCisdCandle[]): number {
  const sample = candles.slice(-400)
  if (sample.length < 3) return 0
  const deltas: number[] = []
  for (let i = 1; i < sample.length; i++) {
    const d = Math.abs(sample[i].close - sample[i - 1].close)
    if (d > 1e-12 && Number.isFinite(d)) deltas.push(d)
  }
  let tick = 0
  if (deltas.length >= 8) {
    deltas.sort((a, b) => a - b)
    const probe = deltas.slice(0, Math.min(5, deltas.length))
    tick = probe[Math.floor(probe.length / 2)]
  }
  if (!(tick > 0)) {
    let decimals = 0
    for (const c of sample.slice(-80)) {
      const s = String(c.close)
      const dot = s.indexOf('.')
      if (dot >= 0) decimals = Math.max(decimals, s.length - dot - 1)
    }
    tick = Number(`1e-${decimals}`)
  }
  const lastPrice = Math.abs(sample[sample.length - 1].close) || 1
  return Math.min(tick, lastPrice * 0.005)
}

/* ═══════════════════════════ calcul complet ═══════════════════════════ */

/**
 * Calcule les événements BOS/CHoCH/CISD sur la série de bougies
 * CLÔTURÉES — sémantique Pine identique au pack (na → comparaison fausse,
 * valuewhen borné par la barre courante, piles remises à zéro par bougie).
 */
export function computeBosChochCisd(
  candles: BosChochCisdCandle[],
  options: ComputeBosChochCisdOptions = {},
): BosChochCisdResult {
  const n = candles.length
  const empty: BosChochCisdResult = {
    events: [],
    swingHighPrice: null,
    swingLowPrice: null,
    swingHighPrice1: null,
    swingLowPrice1: null,
    uptrend: false,
    downtrend: false,
  }
  if (n === 0) return empty

  const mintick = options.mintick != null && options.mintick > 0
    ? options.mintick
    : deriveMintickInline(candles)

  /* ── swings (valuewhen) : listes ordonnées des points de swing ──
   * sh() = gc()[1] and rc() ; le swing high porte max(high, high[1]). */
  interface SwingPoint { barIndex: number; price: number; swingBarIndex: number }
  const swingHighs: SwingPoint[] = []
  const swingLows: SwingPoint[] = []
  const isSh: boolean[] = new Array(n).fill(false)
  const isSl: boolean[] = new Array(n).fill(false)
  for (let i = 0; i < n; i++) {
    const c = candles[i]
    const gc = c.close >= c.open
    const rc = c.close < c.open
    if (i >= 1) {
      const gcPrev = candles[i - 1].close >= candles[i - 1].open
      const rcPrev = candles[i - 1].close < candles[i - 1].open
      if (gcPrev && rc) {
        isSh[i] = true
        const takeCurrent = c.high >= candles[i - 1].high
        swingHighs.push({
          barIndex: i,
          price: takeCurrent ? c.high : candles[i - 1].high,
          swingBarIndex: takeCurrent ? i : i - 1,
        })
      }
      if (rcPrev && gc) {
        isSl[i] = true
        const takeCurrent = c.low <= candles[i - 1].low
        swingLows.push({
          barIndex: i,
          price: takeCurrent ? c.low : candles[i - 1].low,
          swingBarIndex: takeCurrent ? i : i - 1,
        })
      }
    }
  }

  /* ── séries ATR pour les offsets visuels ── */
  const highs = candles.map((c) => c.high)
  const lows = candles.map((c) => c.low)
  const closes = candles.map((c) => c.close)
  const atr = atrSeries(highs, lows, closes, 14)

  /* ── parcours barre par barre (ordre des if du pack) ── */
  const events: BosChochCisdEvent[] = []
  /**
   * Pousse un événement.
   *  - level : point de swing cassé (ligne d'événement pointillée).
   *  - trendFrom/trendTo : extrémités de la ligne de tendance structurelle
   *    (règles du pack — bosUp/chochDown : swing lows occ1→occ0 en VERT ;
   *    bosDown/chochUp : swing highs occ1→occ0 en ROUGE).
   */
  const pushEvent = (
    kind: BosChochCisdEventKind,
    dir: BosChochCisdDirection,
    i: number,
    level: SwingPoint,
    trendKind: 'uptrend' | 'downtrend' | null,
    trendFrom: SwingPoint | null,
    trendTo: SwingPoint | null,
  ) => {
    const c = candles[i]
    const a = atr[i]
    const baseOffset = Math.max((a ?? 0) * 0.30, mintick * 10)
    const stackStep = Math.max((a ?? 0) * 0.20, mintick * 10)
    const label = dir === 'up'
      ? `${kind === 'bos' ? 'BOS' : kind === 'choch' ? 'CHoCH' : 'CISD'} Up`
      : `${kind === 'bos' ? 'BOS' : kind === 'choch' ? 'CHoCH' : 'CISD'} Down`
    const labelY = dir === 'up'
      ? c.low - baseOffset - stackStep * belowStack
      : c.high + baseOffset + stackStep * aboveStack
    events.push({
      kind,
      dir,
      label,
      barIndex: i,
      time: c.time,
      close: c.close,
      high: c.high,
      low: c.low,
      labelY,
      linePrice: level.price,
      lineFromBarIndex: level.swingBarIndex,
      lineColour: dir === 'up' ? TV_GREEN : TV_RED,
      trendLine: trendKind != null && trendFrom != null && trendTo != null
        ? {
          fromBarIndex: trendFrom.swingBarIndex,
          fromPrice: trendFrom.price,
          toBarIndex: trendTo.swingBarIndex,
          toPrice: trendTo.price,
          kind: trendKind,
        }
        : null,
    })
  }

  let aboveStack = 0
  let belowStack = 0
  let shCursor = 0
  let slCursor = 0

  for (let i = 0; i < n; i++) {
    /* piles remises à zéro à chaque nouvelle bougie (barstate.isnew) */
    aboveStack = 0
    belowStack = 0

    /* occ 0 / occ 1 courants (valuewhen borné par la barre i) */
    while (shCursor + 1 < swingHighs.length && swingHighs[shCursor + 1].barIndex <= i) shCursor++
    while (slCursor + 1 < swingLows.length && swingLows[slCursor + 1].barIndex <= i) slCursor++
    const sh0 = swingHighs.length > 0 && swingHighs[0].barIndex <= i
      ? swingHighs[Math.min(shCursor, swingHighs.length - 1)] : null
    const sh1 = sh0 != null && shCursor >= 1 ? swingHighs[shCursor - 1] : null
    const sl0 = swingLows.length > 0 && swingLows[0].barIndex <= i
      ? swingLows[Math.min(slCursor, swingLows.length - 1)] : null
    const sl1 = sl0 != null && slCursor >= 1 ? swingLows[slCursor - 1] : null

    const c = candles[i]
    const gc = c.close >= c.open
    const rc = c.close < c.open
    const closePrev = i >= 1 ? candles[i - 1].close : null

    /* tendances — ut() = slp(0) > slp(1) ; dt() = shp(0) < shp(1) */
    const ut = sl0 != null && sl1 != null && sl0.price > sl1.price
    const dt = sh0 != null && sh1 != null && sh0.price < sh1.price

    /* événéments (na → faux) */
    const crossUp = sh0 != null && closePrev != null && c.close > sh0.price && closePrev < sh0.price
    const crossDown = sl0 != null && closePrev != null && c.close < sl0.price && closePrev > sl0.price

    const bosUp = gc && ut && crossUp
    const bosDown = rc && dt && crossDown
    const chochUp = gc && dt && crossUp && sh1 != null && c.close < sh1.price
    const chochDown = rc && ut && crossDown && sl1 != null && c.close > sl1.price
    const cisdUp = gc && crossUp
    const cisdDown = rc && crossDown

    /* ordre EXACT des if du Main.pine (les piles se remplissent dans
     * cet ordre) : bos_up, bos_down, choch_up, choch_down, cisd_up,
     * cisd_down. Lignes de tendance (règles du pack — le SENS suit la
     * ligne dessinée, PAS la direction de l'événement) :
     *   bos_up     + uptrend   → swing lows  occ1→occ0 (VERT)
     *   bos_down   + downtrend → swing highs occ1→occ0 (ROUGE)
     *   choch_up   + downtrend → swing highs occ1→occ0 (ROUGE)
     *   choch_down + uptrend   → swing lows  occ1→occ0 (VERT)
     *   cisd_*     → aucune. */
    if (bosUp) {
      pushEvent('bos', 'up', i, sh0!, ut ? 'uptrend' : null, ut ? sl1 : null, ut ? sl0 : null)
      belowStack++
    }
    if (bosDown) {
      pushEvent('bos', 'down', i, sl0!, dt ? 'downtrend' : null, dt ? sh1 : null, dt ? sh0 : null)
      aboveStack++
    }
    if (chochUp) {
      pushEvent('choch', 'up', i, sh0!, dt ? 'downtrend' : null, dt ? sh1 : null, dt ? sh0 : null)
      belowStack++
    }
    if (chochDown) {
      pushEvent('choch', 'down', i, sl0!, ut ? 'uptrend' : null, ut ? sl1 : null, ut ? sl0 : null)
      aboveStack++
    }
    if (cisdUp) {
      pushEvent('cisd', 'up', i, sh0!, null, null, null)
      belowStack++
    }
    if (cisdDown) {
      pushEvent('cisd', 'down', i, sl0!, null, null, null)
      aboveStack++
    }
  }

  /* état final (tendances / swings courants) */
  let swingHighPrice: number | null = null
  let swingLowPrice: number | null = null
  let swingHighPrice1: number | null = null
  let swingLowPrice1: number | null = null
  if (swingHighs.length > 0) swingHighPrice = swingHighs[swingHighs.length - 1].price
  if (swingHighs.length > 1) swingHighPrice1 = swingHighs[swingHighs.length - 2].price
  if (swingLows.length > 0) swingLowPrice = swingLows[swingLows.length - 1].price
  if (swingLows.length > 1) swingLowPrice1 = swingLows[swingLows.length - 2].price
  const uptrend = swingLowPrice != null && swingLowPrice1 != null && swingLowPrice > swingLowPrice1
  const downtrend = swingHighPrice != null && swingHighPrice1 != null && swingHighPrice < swingHighPrice1

  return { events, swingHighPrice, swingLowPrice, swingHighPrice1, swingLowPrice1, uptrend, downtrend }
}

/* ════════════════════ évaluation trading (stratégie) ════════════════════ */

/** Confiance par type d'événement (BOS > CHoCH > CISD). */
const KIND_CONFIDENCE: Record<BosChochCisdEventKind, number> = {
  bos: 0.85,
  choch: 0.80,
  cisd: 0.75,
}

/** Toggle du pack correspondant à un événement. */
export function eventToggleKey(e: { kind: BosChochCisdEventKind; dir: BosChochCisdDirection }): keyof BosChochCisdSettings {
  if (e.kind === 'bos') return e.dir === 'up' ? 'bosUpAlert' : 'bosDownAlert'
  if (e.kind === 'choch') return e.dir === 'up' ? 'chochUpAlert' : 'chochDownAlert'
  return e.dir === 'up' ? 'cisdUpAlert' : 'cisdDownAlert'
}

/* ── v19 — Confirmation par la bougie précédente (switch Auto Trade) ── */

/** Options d'évaluation communes aux deux chemins de la stratégie. */
export interface ConfirmPreviousCandleOptions {
  /**
   * v19 — Confirmation par la bougie PRÉCÉDENT la bougie signalée :
   *   - CALL ▲ (BOS Up / CHoCH Up / CISD Up)  → la bougie précédente doit
   *     être BAISSIÈRE (close < open) ;
   *   - PUT ▼ (BOS Down / CHoCH Down / CISD Down) → la bougie précédente
   *     doit être HAUSSIÈRE (close > open).
   * Une doji (close === open) est NEUTRE : elle ne confirme NI un CALL NI
   * un PUT. S'il n'y a pas de bougie précédente (1re bougie de la série),
   * la confirmation est refusée. Défaut : false (comportement inchangé).
   */
  confirmPreviousCandle?: boolean
  /**
   * v22 — Candles Validation : true = le DERNIER élément du tableau de
   * bougies est la bougie EN FORMATION (Ninja ProTrader) → la validation
   * commence à la bougie CLÔTURÉE qui la précède (la bougie en formation
   * n'est JAMAIS validée). Défaut : false — le dernier élément est la
   * bougie signalée CLÔTURÉE (L_Lucien ProTrader) → règle[0] = bougie
   * signalée.
   */
  validationSkipForming?: boolean
  /**
   * v23 — Vérification CISD (swing intact + confirmation par signal
   * combiné) : fournir un état de garde pour l'ACTIVER. Les règles dont les
   * alertes contiennent CISD Up / CISD Down ne placent alors PLUS d'ordre
   * direct : CISD seul vérifie le swing le plus proche et arme la séquence
   * (aucun ordre) ; l'ordre ne part que sur le signal SUIVANT s'il est le
   * combiné BOS + CISD ou CHoCH + CISD de la même direction. Sans état,
   * comportement v22 inchangé.
   */
  cisdGuard?: CisdGuardHandle
  /**
   * v24 — Configuration des étapes de vérification CISD (cases à cocher
   * du panneau Auto Trade) : up/down (activation par direction), swingMode
   * ('intact' | 'violated' | 'none' — v25 : 'none' ignore l'étape swing)
   * et combinaisons de confirmation acceptées (BOS/CHoCH par direction).
   * Défaut = v23 intégral.
   */
  cisdGuardConfig?: Partial<CisdGuardConfig>
  /**
   * v26 — Durée (s) d'UNE bougie du timeframe courant — fournie par
   * l'appelant (backend / Strategy Tester). Utilisée UNIQUEMENT pour
   * convertir l'expiration « candles » en secondes au niveau de
   * l'ADAPTATION BORKER (§17) : expirationSeconds = candles × tf.
   */
  timeframeSeconds?: number
  /**
   * v25 — Horloge de bougie : secondes RESTANTES avant la clôture de la
   * bougie qui reçoit le signal (compteur 00:18 → 18). Fournie par
   * l'appelant (backend temps réel / simulation Tester). Résout
   * l'expiration des règles « remaining Time Before Candle Closure ».
   */
  candleClockSeconds?: number
}

/** Vrai si la bougie est baissière (close < open strictement). */
export function isBearishCandle(c: BosChochCisdCandle): boolean {
  return c.close < c.open
}

/** Vrai si la bougie est haussière (close > open strictement). */
export function isBullishCandle(c: BosChochCisdCandle): boolean {
  return c.close > c.open
}

/**
 * v19 — Vérifie la bougie précédant la bougie signalée contre la direction
 * de l'ordre projeté. Retourne un diagnostic complet (confirmée ou non, avec
 * le détail pour le reason du signal — l'utilisateur voit POURQUOI l'ordre
 * a été refusé dans le panneau Auto Trade « Latest signal »).
 */
export function checkPreviousCandleConfirmation(
  candles: BosChochCisdCandle[],
  action: 'CALL' | 'PUT',
): { confirmed: boolean; detail: string } {
  const n = candles.length
  const fmt = (v: number) => {
    const abs = Math.abs(v)
    if (abs >= 1000) return v.toFixed(2)
    if (abs >= 1) return v.toFixed(4)
    return v.toFixed(5)
  }
  if (n < 2) {
    return {
      confirmed: false,
      detail: 'aucune bougie précédente disponible pour confirmer le signal',
    }
  }
  const prev = candles[n - 2]
  if (action === 'CALL') {
    if (isBearishCandle(prev)) {
      return { confirmed: true, detail: `bougie précédente baissière (close ${fmt(prev.close)} < open ${fmt(prev.open)}) — confirmation CALL ▲ OK` }
    }
    const kind = isBullishCandle(prev) ? 'haussière' : 'neutre (doji)'
    return { confirmed: false, detail: `bougie précédente ${kind} (close ${fmt(prev.close)}, open ${fmt(prev.open)}) — CALL ▲ exige une bougie baissière` }
  }
  if (isBullishCandle(prev)) {
    return { confirmed: true, detail: `bougie précédente haussière (close ${fmt(prev.close)} > open ${fmt(prev.open)}) — confirmation PUT ▼ OK` }
  }
  const kind = isBearishCandle(prev) ? 'baissière' : 'neutre (doji)'
  return { confirmed: false, detail: `bougie précédente ${kind} (close ${fmt(prev.close)}, open ${fmt(prev.open)}) — PUT ▼ exige une bougie haussière` }
}

/* ── v22 — Candles Validation (règles utilisateur par combinaison) ── */

/** Longueur maximale d'une règle Candles Validation (5 dernières bougies). */
export const CANDLES_VALIDATION_MAX_CANDLES = 5

/**
 * Sanitise une règle Candles Validation : majuscules, seuls R et G sont
 * conservés, tronquée à 5 caractères. "rg%xr" → "RGR". Tout ce qui n'est
 * pas R/G (espaces, chiffres, accents…) est ignoré silencieusement — le
 * champ est court et tapé à la main, la règle équivalente la plus proche
 * est préférée à un rejet dur.
 */
export function normalizeCandlesValidation(raw: unknown): string {
  if (typeof raw !== 'string') return ''
  return raw.toUpperCase().replace(/[^RG]/g, '').slice(0, CANDLES_VALIDATION_MAX_CANDLES)
}

/** Résultat d'une Candles Validation (diagnostic complet pour le reason). */
export interface CandlesValidationResult {
  validated: boolean
  /** Règle attendue, sanitizée ("" = aucune règle → toujours validé). */
  expected: string
  /** Couleurs réelles observées, de la plus récente à la plus ancienne. */
  actual: string
  detail: string
}

/** Couleur d'une bougie pour la validation : R = close < open, G = close >= open. */
export function candleColorChar(c: BosChochCisdCandle): 'R' | 'G' {
  return c.close < c.open ? 'R' : 'G'
}

/**
 * v22 — Vérifie une règle Candles Validation contre les bougies CLÔTURÉES.
 *
 * La règle (ex. "RGRR") est lue DU PLUS RÉCENT AU PLUS ANCIEN : le 1er
 * caractère s'applique à la bougie clôturée la plus récente (l'ancre), le
 * 2e à celle d'avant, etc. La bougie EN FORMATION n'est jamais validée :
 *
 *   - L_Lucien ProTrader : passer les bougies clôturées seules — l'ancre
 *     est la DERNIÈRE du tableau (= la bougie signalée, tout juste clôturée) ;
 *   - Ninja ProTrader : passer les bougies clôturées + la bougie EN
 *     FORMATION en DERNIER et activer `skipLast: true` — l'ancre devient
 *     l'avant-dernière (= la dernière bougie CLÔTURÉE).
 *
 * Une règle plus longue que l'historique disponible n'est PAS validée
 * (refus explicite, jamais de troncature de la règle).
 */
export function checkCandlesValidation(
  candles: BosChochCisdCandle[],
  validation: string,
  opts: { skipLast?: boolean } = {},
): CandlesValidationResult {
  const expected = normalizeCandlesValidation(validation)
  if (!expected) {
    return { validated: true, expected: '', actual: '', detail: 'aucune règle Candles Validation (combinaison seule)' }
  }
  const n = candles.length
  // Ancre = bougie clôturée la plus récente validée par la règle.
  const anchor = opts.skipLast ? n - 2 : n - 1
  const need = expected.length
  if (anchor < 0 || anchor - (need - 1) < 0) {
    const available = Math.max(0, anchor + 1)
    return {
      validated: false,
      expected,
      actual: '',
      detail: `règle ${expected} exige ${need} bougie(s) clôturée(s) — seulement ${available} disponible(s)`,
    }
  }
  const chars: string[] = []
  for (let k = 0; k < need; k++) {
    chars.push(candleColorChar(candles[anchor - k]))
  }
  const actual = chars.join('')
  const validated = actual === expected
  return {
    validated,
    expected,
    actual,
    detail: validated
      ? `Candles Validation ${expected} ✓ (bougies ${actual}, de la plus récente à la plus ancienne)`
      : `Candles Validation ${expected} ✗ — bougies réelles ${actual || '—'} (de la plus récente à la plus ancienne)`,
  }
}

/* ── v23 — Vérification CISD : swing intact + confirmation par signal combiné ── */

/**
 * Séquence CISD armée (en attente du signal combiné de confirmation).
 * Portée par l'état de garde, un par asset et par stratégie.
 */
export interface CisdGuardArmed {
  direction: 'up' | 'down'
  /** Temps de la bougie qui a armé la séquence (CISD vérifié, swing intact). */
  candleTime: number
  /** Niveau du swing high (up) / swing low (down) vérifié intact. */
  swingPrice: number
  /** Indice de la bougie du swing dans la série évaluée à l'armement. */
  swingBarIndex: number
  /** v24/v25 — exigence swing au moment de l'armement ('intact' par défaut). */
  swingMode?: 'intact' | 'violated' | 'none'
}

/** Verdict de la garde CISD pour la bougie évaluée. */
export interface CisdGuardVerdict {
  /**
   * 'none'           : bougie sans événement (ou garde inactive) ;
   * 'armed'          : CISD seul + swing intact → séquence ARMÉE, attente ;
   * 'swing-violated' : CISD seul mais swing déjà violé → refus, rien ;
   * 'confirmed'      : signal combiné attendu → l'ordre peut partir ;
   * 'refused'        : signal combiné SANS séquence armée → refus ;
   * 'withdrawn'      : armement intra-bougie retiré (l'événement a
   *                     disparu de la bougie en formation — Ninja).
   */
  transition: 'none' | 'armed' | 'swing-violated' | 'confirmed' | 'refused' | 'withdrawn'
  /** true uniquement pour transition 'confirmed' avec direction cohérente. */
  orderAllowed: boolean
  direction: 'up' | 'down' | null
  /** Détail humain (reason / diagnostics). */
  detail: string
  armedCandleTime?: number
  swingPrice?: number
  /** v24/v25 — exigence swing au moment de l'armement ('intact' par défaut). */
  swingMode?: 'intact' | 'violated' | 'none'
  /** Alertes du signal combiné qui a confirmé (transition 'confirmed'). */
  confirmedBy?: string[]
}

/** État de garde CISD (muté par updateCisdGuard — un par asset/stratégie). */
export interface CisdGuardState {
  armed: CisdGuardArmed | null
  /** Idempotence : dernière bougie traitée + événements + verdict en cache. */
  lastBarTime: number | null
  lastEventsKey: string | null
  lastVerdict: CisdGuardVerdict | null
}

/** Poignée passée aux évaluations pour activer la vérification CISD. */
export interface CisdGuardHandle {
  state: CisdGuardState
  /** v24 — configuration des étapes (cases à cocher du panneau Auto Trade).
   * Absente/partielle → défaut v23 intégral (tout coché, swing intact). */
  config?: Partial<CisdGuardConfig>
}

/** Crée un état de garde CISD vierge. */
export function createCisdGuardState(): CisdGuardState {
  return { armed: null, lastBarTime: null, lastEventsKey: null, lastVerdict: null }
}

/**
 * v23 — Swing HIGH intact ? Le swing high (niveau `swingPrice`, formé à
 * l'indice `swingBarIndex`) est VIOLÉ si une bougie intermédiaire — entre sa
 * formation et la bougie signal (exclusive) — a dépassé son niveau
 * (high > swingPrice : mèche OU clôture — un « sweep » de liquidité).
 * Les bougies du swing elles-mêmes sont ≤ swingPrice par construction.
 */
export function checkSwingHighIntact(
  candles: BosChochCisdCandle[],
  swingBarIndex: number,
  swingPrice: number,
  signalBarIndex: number,
): { intact: boolean; violationBarIndex: number | null } {
  for (let k = Math.max(0, swingBarIndex + 1); k <= signalBarIndex - 1; k++) {
    if (candles[k].high > swingPrice) return { intact: false, violationBarIndex: k }
  }
  return { intact: true, violationBarIndex: null }
}

/** v23 — Miroir bas : swing LOW intact (low < swingPrice = violation). */
export function checkSwingLowIntact(
  candles: BosChochCisdCandle[],
  swingBarIndex: number,
  swingPrice: number,
  signalBarIndex: number,
): { intact: boolean; violationBarIndex: number | null } {
  for (let k = Math.max(0, swingBarIndex + 1); k <= signalBarIndex - 1; k++) {
    if (candles[k].low < swingPrice) return { intact: false, violationBarIndex: k }
  }
  return { intact: true, violationBarIndex: null }
}

function fmtPrice(v: number): string {
  const abs = Math.abs(v)
  if (abs >= 1000) return v.toFixed(2)
  if (abs >= 1) return v.toFixed(4)
  return v.toFixed(5)
}

/**
 * v23 — Machine à états de la vérification CISD, appelée à CHAQUE évaluation
 * de la dernière bougie (clôturée pour L_Lucien, en formation pour Ninja).
 *
 * Le moteur garantit que BOS Up / CHoCH Up embarquent toujours CISD Up (et
 * l'inverse pour Down) : un signal « combiné BOS Up + CISD Up ou CHoCH Up +
 * CISD Up » est exactement une bougie portant BOS Up ou CHoCH Up. Les
 * événements UP et DOWN ne coexistent jamais sur une même bougie (gc/rc
 * exclusifs) — la direction d'une bougie à événements est non ambiguë.
 *
 * v24 — `config` (cases à cocher du panneau Auto Trade) :
 *   - up/down désactivés → la garde est INACTIVE pour cette direction
 *     (transition 'none') : les règles CISD de cette direction ordonnent
 *     directement, comme en v22 ;
 *   - swingMode 'violated' → la séquence s'arme si le swing le plus proche
 *     a ÉTÉ violé (sweep de liquidité) et refuse s'il est intact ;
 *   - confirmBosUp/confirmChochUp (resp. Down) : seuls les combinés cochés
 *     confirment — un combiné décoché consomme la séquence sans ordre.
 *
 * Transitions (par bougie à événements) :
 *   CISD Up SEUL      → swing dans l'état exigé ? ARMÉ : REFUS (swing non conforme) ;
 *   BOS/CHoCH Up + CISD Up → armé(up) antérieur ET combiné ACCEPTÉ ?
 *                          CONFIRMÉ (ordre) : REFUS ;
 *   (miroir exact pour Down ; tout signal suivant non confirmatoire
 *   consomme la séquence sans ordre).
 *
 * Robustesse :
 *   - IDEMPOTENCE par bougie : même (temps, événements) → verdict en cache,
 *     aucune double transition (re-évaluations du polling) ;
 *   - GAP : si des bougies entières ont été sautées depuis la dernière
 *     évaluation (redémarrage, asset momentanément désélectionné, garde
 *     maxPositions…), l'armement est réputé périmé et annulé ;
 *   - RETRAIT INTRA-BOUGIE (Ninja) : si la bougie qui a armé ne porte
 *     plus l'événement (flicker), l'armement est retiré ;
 *   - MÊME BOUGIE : l'armement et sa confirmation doivent être DEUX
 *     signaux distincts (armedCandleTime < bougie de confirmation).
 */
export function updateCisdGuard(
  state: CisdGuardState,
  candles: BosChochCisdCandle[],
  fired: BosChochCisdEvent[],
  configInput?: Partial<CisdGuardConfig> | null,
): CisdGuardVerdict {
  const config = normalizeCisdGuardConfig(configInput)
  const n = candles.length
  const none: CisdGuardVerdict = { transition: 'none', orderAllowed: false, direction: null, detail: '' }
  if (n === 0) return none
  const signalBarIndex = n - 1
  const barTime = candles[signalBarIndex].time

  /* GAP — des bougies ont été sautées depuis la dernière évaluation :
   * l'armement est périmé (des signaux intermédiaires ont pu être manqués). */
  const prevBarTime = n >= 2 ? candles[n - 2].time : null
  if (state.armed && prevBarTime != null && state.lastBarTime != null && state.lastBarTime < prevBarTime) {
    state.armed = null
  }

  const eventsKey = fired.map((e) => e.label).join('|')

  /* IDEMPOTENCE — même bougie, mêmes événements : verdict en cache.
   * (La config est stable entre deux évaluations d'une même bougie : le
   * backend réinitialise les états de garde au changement de cases.) */
  if (state.lastBarTime === barTime && state.lastEventsKey === eventsKey && state.lastVerdict) {
    return state.lastVerdict
  }

  let verdict: CisdGuardVerdict

  if (fired.length === 0) {
    if (state.armed && state.armed.candleTime === barTime) {
      /* RETRAIT INTRA-BOUGIE : l'événement qui a armé a disparu (Ninja). */
      state.armed = null
      verdict = {
        transition: 'withdrawn',
        orderAllowed: false,
        direction: null,
        detail: 'armement CISD retiré — l’événement a disparu de la bougie en formation',
      }
    } else {
      verdict = none
    }
  } else {
    const dir = fired[0].dir
    const labels = new Set(fired.map((e) => e.label))
    const dirTxt = dir === 'up' ? 'Up' : 'Down'
    const structLabels = dir === 'up' ? ['BOS Up', 'CHoCH Up'] : ['BOS Down', 'CHoCH Down']
    const isCombined = structLabels.some((l) => labels.has(l))
    const dirEnabled = dir === 'up' ? config.up : config.down

    if (!dirEnabled) {
      /* v24 — ÉTAPES DÉCOCHÉES pour cette direction : la garde reste
       * neutre (aucun armement, aucune consommation) — c'est le MOTEUR
       * (evaluateBosChochCisdOrderRules) qui laisse passer l'ordre direct. */
      verdict = {
        transition: 'none',
        orderAllowed: false,
        direction: null,
        detail: `vérification CISD ${dirTxt} désactivée (case décochée) — les combinaisons CISD ${dirTxt} placent leurs ordres directement`,
      }
    } else if (!isCombined) {
      /* CISD SEUL → vérification du swing le plus proche (celui que le
       * CISD franchit : linePrice / lineFromBarIndex de l'événement). */
      const cisdEvent = fired.find((e) => e.kind === 'cisd' && e.dir === dir) ?? fired[0]
      const check = dir === 'up'
        ? checkSwingHighIntact(candles, cisdEvent.lineFromBarIndex, cisdEvent.linePrice, signalBarIndex)
        : checkSwingLowIntact(candles, cisdEvent.lineFromBarIndex, cisdEvent.linePrice, signalBarIndex)
      const swingTxt = dir === 'up' ? 'swing high' : 'swing low'
      /* v24 — swingMode : 'intact' (défaut v23) arme si NON violé ;
       * 'violated' arme si le swing a ÉTÉ balayé (sweep de liquidité).
       * v25 — 'none' : les deux cases sont décochées — l'étape de
       * vérification du swing est IGNORÉE : le CISD seul arme la
       * séquence sans aucune exigence sur le swing. */
      const wantViolated = config.swingMode === 'violated'
      const skipSwing = config.swingMode === 'none'
      const swingConforms = skipSwing ? true : wantViolated ? !check.intact : check.intact
      const acceptTxt = acceptedCombosText(dir, config)
      if (swingConforms) {
        state.armed = {
          direction: dir,
          candleTime: barTime,
          swingPrice: cisdEvent.linePrice,
          swingBarIndex: cisdEvent.lineFromBarIndex,
          swingMode: skipSwing ? 'none' : wantViolated ? 'violated' : 'intact',
        }
        verdict = {
          transition: 'armed',
          orderAllowed: false,
          direction: dir,
          armedCandleTime: barTime,
          swingPrice: cisdEvent.linePrice,
          swingMode: skipSwing ? 'none' : wantViolated ? 'violated' : 'intact',
          detail: skipSwing
            ? `CISD ${dirTxt} vérifié — swing ${swingTxt} ${fmtPrice(cisdEvent.linePrice)} NON VÉRIFIÉ (étape ignorée : « Swing NON violé » et « Swing VIOLÉ » toutes décochées) — EN ATTENTE du prochain signal : ordre uniquement s’il est le combiné ${acceptTxt}`
            : wantViolated
              ? `CISD ${dirTxt} vérifié — ${swingTxt} ${fmtPrice(cisdEvent.linePrice)} VIOLÉ avant le signal (sweep de liquidité — mode « swing violé » coché) — EN ATTENTE du prochain signal : ordre uniquement s’il est le combiné ${acceptTxt}`
              : `CISD ${dirTxt} vérifié — ${swingTxt} ${fmtPrice(cisdEvent.linePrice)} intact (aucune violation depuis sa formation) — EN ATTENTE du prochain signal : ordre uniquement s’il est le combiné ${acceptTxt}`,
        }
      } else {
        state.armed = null
        verdict = {
          transition: 'swing-violated',
          orderAllowed: false,
          direction: dir,
          swingPrice: cisdEvent.linePrice,
          detail: wantViolated
            ? `CISD ${dirTxt} REFUSÉ — ${swingTxt} ${fmtPrice(cisdEvent.linePrice)} INTACT alors que le mode exige un swing VIOLÉ (case « swing violé » cochée) — aucune séquence en attente, aucun ordre`
            : `CISD ${dirTxt} REFUSÉ — ${swingTxt} ${fmtPrice(cisdEvent.linePrice)} VIOLÉ avant le signal (bougie ${candles[check.violationBarIndex ?? 0].time} a dépassé le niveau) — aucune séquence en attente, aucun ordre`,
        }
      }
    } else {
      /* SIGNAL COMBINÉ (BOS/CHoCH + CISD) → confirmation ? */
      /* v24 — seules les combinaisons COCHÉES confirment (confirmBosUp /
       * confirmChochUp, resp. Down) ; un combiné décoché consomme la
       * séquence sans ordre. */
      const acceptedCombo = fired.some((e) => e.kind !== 'cisd' && comboAccepted(e.label, config))
      if (state.armed && state.armed.direction === dir && state.armed.candleTime < barTime && acceptedCombo) {
        const confirmedBy = fired.filter((e) => e.kind !== 'cisd').map((e) => e.label)
        const armedTime = state.armed.candleTime
        const swingPrice = state.armed.swingPrice
        const armedMode = state.armed.swingMode ?? config.swingMode
        state.armed = null // consommé par le signal confirmatoire
        verdict = {
          transition: 'confirmed',
          orderAllowed: true,
          direction: dir,
          armedCandleTime: armedTime,
          swingPrice,
          swingMode: armedMode,
          confirmedBy,
          detail: `CISD ${dirTxt} confirmé — CISD ${dirTxt} vérifié à la bougie ${armedTime} (${dir === 'up' ? 'swing high' : 'swing low'} ${fmtPrice(swingPrice)} ${armedMode === 'violated' ? 'violé' : armedMode === 'none' ? 'non vérifié (étape ignorée)' : 'intact'}), confirmé par [${confirmedBy.join(' + ')}]`,
        }
      } else if (state.armed && state.armed.direction === dir && state.armed.candleTime < barTime && !acceptedCombo) {
        const confirmedBy = fired.filter((e) => e.kind !== 'cisd').map((e) => e.label)
        state.armed = null // consommé par un signal non confirmatoire
        verdict = {
          transition: 'refused',
          orderAllowed: false,
          direction: dir,
          detail: `signal combiné [${fired.map((e) => e.label).join(' + ')}] NON ACCEPTÉ comme confirmation — combinaisons cochées : ${acceptedCombosText(dir, config)} — la séquence armée est consommée sans ordre`,
        }
      } else {
        state.armed = null // consommé sans ordre (direction opposée / rien)
        verdict = {
          transition: 'refused',
          orderAllowed: false,
          direction: dir,
          detail: `signal combiné [${fired.map((e) => e.label).join(' + ')}] SANS CISD ${dirTxt} vérifié préalable — séquence exigée : CISD ${dirTxt} avec ${dir === 'up' ? 'swing high' : 'swing low'} ${config.swingMode === 'violated' ? 'VIOLÉ' : 'intact'} PUIS le combiné ${acceptedCombosText(dir, config)} — aucun ordre`,
        }
      }
    }
  }

  state.lastBarTime = barTime
  state.lastEventsKey = eventsKey
  state.lastVerdict = verdict
  return verdict
}

/** v24 — Le combiné structural de cette étiquette est-il coché ? */
function comboAccepted(label: string, config: CisdGuardConfig): boolean {
  if (label === 'BOS Up') return config.confirmBosUp
  if (label === 'CHoCH Up') return config.confirmChochUp
  if (label === 'BOS Down') return config.confirmBosDown
  if (label === 'CHoCH Down') return config.confirmChochDown
  return false
}

/** v24 — Texte des combinaisons de confirmation cochées pour une direction. */
function acceptedCombosText(dir: 'up' | 'down', config: CisdGuardConfig): string {
  const parts: string[] = []
  if (dir === 'up') {
    if (config.confirmBosUp) parts.push('BOS Up + CISD Up')
    if (config.confirmChochUp) parts.push('CHoCH Up + CISD Up')
    if (parts.length === 0) return 'AUCUN (toutes les cases CALL ▲ sont décochées — aucun ordre ne peut confirmer)'
    return `${parts.join(' ou ')} (CALL ▲)`
  }
  if (config.confirmBosDown) parts.push('BOS Down + CISD Down')
  if (config.confirmChochDown) parts.push('CHoCH Down + CISD Down')
  if (parts.length === 0) return 'AUCUN (toutes les cases PUT ▼ sont décochées — aucun ordre ne peut confirmer)'
  return `${parts.join(' ou ')} (PUT ▼)`
}

/** Règle concernée par la vérification CISD (au moins une alerte CISD). */
export function ruleRequiresCisdGuard(rule: { alerts: BosChochCisdOrderCondition[] }): boolean {
  return rule.alerts.includes('CISD Up') || rule.alerts.includes('CISD Down')
}

/**
 * Évalue la DERNIÈRE bougie clôturée de la série et produit le signal de
 * la stratégie Auto Trade :
 *   événement UP actif (toggle ON)   → CALL
 *   événement DOWN actif (toggle ON) → PUT
 *   sinon                            → HOLD (avec le contexte structurel)
 * gc/rc étant exclusifs, UP et DOWN ne peuvent pas coexister sur la même
 * bougie — la direction est toujours non ambiguë.
 */
export function evaluateBosChochCisdOrderRules(
  candles: BosChochCisdCandle[],
  callRulesInput: unknown,
  putRulesInput: unknown,
  options: ConfirmPreviousCandleOptions = {},
): BosChochCisdSignal {
  const n = candles.length
  if (n === 0) return { action: 'HOLD', confidence: 0, reason: 'BOS/CHoCH/CISD : aucune bougie', events: [], candleTime: 0 }
  const last = candles[n - 1]
  const res = computeBosChochCisd(candles)
  const fired = res.events.filter((e) => e.barIndex === n - 1)
  const firedLabels = [...new Set(fired.map((e) => e.label))]
  /* v26 — DÉTECTION CANDLE (73 patterns) sur la bougie évaluée : la bougie
   * clôturée pour L_Lucien, la bougie EN FORMATION pour Ninja (la forme
   * au prix courant — §7). AUCUN filtre d'affichage ici (§33) : les
   * patterns masqués sur le graphique restent des conditions actives. */
  const firedPatterns = detectCandlePatternsOnLastBar(candles)
  const firedPatternLabels = firedPatterns.map((p) => candlePatternLabel(p))
  const firedConditions: string[] = [...firedLabels, ...firedPatternLabels]
  const { callRules, putRules } = normalizeBosChochCisdOrderRules(callRulesInput, putRulesInput)

  /* v23 — VÉRIFICATION CISD : la machine à états est mise à jour sur CHAQUE
   * bougie évaluée (clôturée L_Lucien / en formation Ninja), AVANT le
   * filtrage des règles — les transitions (armement, confirmation, refus,
   * consommation) suivent le flux des SIGNAUX, pas des règles. La garde
   * n'est active que si l'appelant fournit un état.
   * v24 — la CONFIG (options.cisdGuard.config ou options.cisdGuardConfig)
   * définit quelles étapes sont actives : direction décochée → la machine
   * reste neutre pour elle et les règles ordonnent DIRECTEMENT (v22). */
  const cisdGuardConfig = options.cisdGuard
    ? normalizeCisdGuardConfig(options.cisdGuard.config ?? options.cisdGuardConfig)
    : null
  const cisdVerdict = options.cisdGuard?.state
    ? updateCisdGuard(options.cisdGuard.state, candles, fired, cisdGuardConfig)
    : null

  const fmt = (v: number) => {
    const abs = Math.abs(v)
    if (abs >= 1000) return v.toFixed(2)
    if (abs >= 1) return v.toFixed(4)
    return v.toFixed(5)
  }

  /* v26 — Matching MIXTE (§12, logique AND stricte) : chaque condition de
   * la règle doit être présente sur la bougie — alerte du pack dans
   * firedLabels OU pattern candle dans firedPatterns. AUCUN OR. */
  const conditionFired = (cond: BosChochCisdOrderCondition): boolean =>
    (BCC_ORDER_ALERTS as string[]).includes(cond)
      ? firedLabels.includes(cond)
      : firedPatterns.includes(cond as CandlePatternId)

  const candidates = [
    ...callRules.map((rule, index) => ({ action: 'CALL' as const, rule, index })),
    ...putRules.map((rule, index) => ({ action: 'PUT' as const, rule, index })),
  ].filter(({ rule }) => rule.alerts.every((alert) => conditionFired(alert)))
    .sort((a, b) => {
      const specificity = b.rule.alerts.length - a.rule.alerts.length
      if (specificity !== 0) return specificity
      return a.index - b.index
    })

  const top = candidates[0]
  if (!top) {
    /* v23 — lorsqu'une règle CISD existe dans la configuration, le détail de
     * la vérification CISD est documenté même sans correspondance de règle
     * (ex. CISD Up armé mais seules des règles BOS Up + CISD Up existent). */
    const cisdNote = cisdVerdict && (cisdVerdict.transition === 'armed' || cisdVerdict.transition === 'swing-violated')
      ? ` — ${cisdVerdict.detail}`
      : ''
    return {
      action: 'HOLD',
      confidence: 0,
      reason: firedConditions.length
        ? `BOS/CHoCH/CISD : alertes présentes [${firedConditions.join(' + ')}] mais aucune règle CALL/PUT ne correspond (toutes les conditions AND non satisfaites)${cisdNote}`
        : `BOS/CHoCH/CISD : aucune alerte sur la bougie ${last.time}`,
      events: firedConditions,
      candleTime: last.time,
    }
  }

  const matchingTop = candidates.filter((c) => c.rule.alerts.length === top.rule.alerts.length)
  const conflicting = matchingTop.find((c) => c.action !== top.action)
  if (conflicting) {
    /* §13 — CONFLIT CALL/PUT : même spécificité des deux côtés → HOLD,
     * jamais d'arbitrage arbitraire. */
    return {
      action: 'HOLD',
      confidence: 0,
      reason: `BOS/CHoCH/CISD : conflit de règles sur [${firedConditions.join(' + ')}] — règles CALL et PUT de même spécificité correspondent`,
      events: firedConditions,
      candleTime: last.time,
    }
  }

  const bestEvent = fired.find((e) => top.rule.alerts.includes(e.label as BosChochCisdOrderAlert))
  const confidence = bestEvent ? KIND_CONFIDENCE[bestEvent.kind] : 0.75

  /* v23 — VÉRIFICATION CISD (porte sur TOUTE règle contenant une alerte
   * CISD Up / CISD Down — L_Lucien ProTrader, Ninja ProTrader et Strategy
   * Tester) : la combinaison ne place PLUS d'ordre direct.
   *   - CISD SEUL sur la bougie : swing intact → séquence ARMÉE (aucun
   *     ordre — attente du prochain signal) ; swing violé → refus ;
   *   - signal COMBINÉ (BOS + CISD ou CHoCH + CISD) : ordre UNIQUEMENT si
   *     une séquence de MÊME direction a été armée au signal précédent —
   *     c'est la protection demandée contre les cassures profondes sans
   *     confirmation (les « graves conséquences sur le solde »).
   * v24 — CASES À COCHER : la vérification ne porte QUE sur les directions
   * COCHÉES (cisdGuard.up / cisdGuard.down) ; une direction décochée
   * retrouve le comportement v22 (ordre direct sur la combinaison).
   * Les règles sans alerte CISD ne sont pas affectées. */
  let cisdConfirmed: CisdGuardVerdict | null = null
  let cisdDirectNote = ''
  if (cisdVerdict && cisdGuardConfig && ruleRequiresCisdGuard(top.rule)) {
    const want: 'up' | 'down' = top.rule.alerts.includes('CISD Up') ? 'up' : 'down'
    const dirEnabled = want === 'up' ? cisdGuardConfig.up : cisdGuardConfig.down
    if (!dirEnabled) {
      /* v24 — étapes décochées pour cette direction : ordre DIRECT (v22). */
      cisdDirectNote = ` — vérification CISD ${want === 'up' ? 'Up' : 'Down'} désactivée : ordre direct sur la combinaison`
    } else if (cisdVerdict.transition === 'confirmed' && cisdVerdict.direction === want) {
      cisdConfirmed = cisdVerdict
    } else {
      const prefix = cisdVerdict.transition === 'armed'
        ? `séquence CISD ${cisdVerdict.direction === 'up' ? 'Up' : 'Down'} ARMÉE — aucun ordre sur ce signal`
        : `REFUSÉ par la vérification CISD`
      return {
        action: 'HOLD',
        confidence: 0,
        reason: `BOS/CHoCH/CISD : ${top.rule.id} [${top.rule.alerts.join(' + ')}] — ${prefix} — ${cisdVerdict.detail}`,
        events: firedLabels,
        candleTime: last.time,
        matchedRuleId: top.rule.id,
      }
    }
  }

  /* v19 — Confirmation par la bougie précédente (switch Auto Trade) :
   * CALL ▲ exige une bougie BAISSIÈRE avant la bougie signalée ; PUT ▼
   * exige une bougie HAUSSIÈRE. Refus → HOLD (aucun ordre), la bougie
   * n'est pas consommée par la garde anti re-trade. */
  if (options.confirmPreviousCandle) {
    const check = checkPreviousCandleConfirmation(candles, top.action)
    if (!check.confirmed) {
      return {
        action: 'HOLD',
        confidence: 0,
        reason: `BOS/CHoCH/CISD : signal ${top.action === 'CALL' ? 'CALL ▲' : 'PUT ▼'} (${top.rule.alerts.join(' + ')}) REFUSÉ par la confirmation de bougie — ${check.detail}`,
        events: firedLabels,
        candleTime: last.time,
      }
    }
  }

  /* v22 — CANDLES VALIDATION (règle de la combinaison) : au moment où la
   * combinaison est émise, les N dernières bougies CLÔTURÉES sont vérifiées
   * (du plus récent au plus ancien). La bougie en formation n'est JAMAIS
   * validée : `validationSkipForming` (Ninja ProTrader) ancre la règle sur
   * la dernière bougie CLÔTURÉE lorsque le dernier élément du tableau est
   * la bougie en formation. Refus → HOLD (aucun ordre), la bougie n'est pas
   * consommée par la garde anti re-trade. */
  const validationRule = normalizeCandlesValidation(top.rule.candlesValidation)
  let validationDetail = ''
  if (validationRule) {
    const v = checkCandlesValidation(candles, validationRule, {
      skipLast: options.validationSkipForming === true,
    })
    if (!v.validated) {
      return {
        action: 'HOLD',
        confidence: 0,
        reason: `BOS/CHoCH/CISD : signal ${top.action === 'CALL' ? 'CALL ▲' : 'PUT ▼'} (${top.rule.id} : [${top.rule.alerts.join(' + ')}]) REFUSÉ — ${v.detail}`,
        events: firedLabels,
        candleTime: last.time,
        matchedRuleId: top.rule.id,
        matchedRuleValidation: validationRule,
      }
    }
    validationDetail = v.detail
  }

  /* v25/v26 — RÉSOLUTION DE L'EXPIRATION de la règle :
   *   'seconds'   → expirationSeconds (validée par la normalisation) ;
   *   'candles'   → expirationCandles (le Strategy Tester l'utilise
   *                 directement) + conversion broker candles × tf (si tf
   *                 fournie — §17 : conversion UNIQUEMENT ici, jamais dans
   *                 le moteur de backtest) ;
   *   'remaining' → horloge de bougie (options.candleClockSeconds, le
   *                 compteur 00:18 → 18 s) ; clamp ≥ 3 s (contrat broker) ;
   *                 SANS horloge : repli sur l'expiration statique de la
   *                 règle si définie, sinon HOLD DOCUMENTÉ (jamais un ordre
   *                 avec une expiration non définie). */
  const ruleMode: BosChochCisdExpirationMode = top.rule.remainingTimeBeforeClosure
    ? 'remaining'
    : top.rule.expirationMode === 'candles' ? 'candles' : 'seconds'
  let resolvedSeconds: number | null =
    ruleMode === 'seconds' && typeof top.rule.expirationSeconds === 'number' ? top.rule.expirationSeconds : null
  let resolvedCandles: number | null =
    ruleMode === 'candles' && typeof top.rule.expirationCandles === 'number' ? top.rule.expirationCandles : null
  let expirationDetail = ''
  if (ruleMode === 'candles') {
    const tf = Number(options.timeframeSeconds)
    if (Number.isFinite(tf) && tf >= 1) {
      resolvedSeconds = Math.max(3, Math.round((resolvedCandles as number) * tf))
      expirationDetail = ` — expiration ${resolvedCandles} bougie(s) (${resolvedSeconds} s au broker, ${tf} s/bougie)`
    } else {
      expirationDetail = ` — expiration ${resolvedCandles} bougie(s) (mode Candles — le Strategy Tester l'utilise directement)`
    }
  } else if (ruleMode === 'remaining') {
    const clock = Number(options.candleClockSeconds)
    if (Number.isFinite(clock) && clock > 0) {
      resolvedSeconds = Math.max(3, Math.floor(clock))
      expirationDetail = ` — remaining Time Before Candle Closure : ${resolvedSeconds} s (compteur de la bougie ${Math.floor(clock)} s restant → expiration dynamique)`
    } else if (typeof top.rule.expirationSeconds === 'number' && top.rule.expirationSeconds >= 3) {
      resolvedSeconds = top.rule.expirationSeconds
      expirationDetail = ` — remaining Time Before Candle Closure : AUCUNE horloge fournie — repli sur l'expiration statique ${resolvedSeconds} s de la règle`
    } else {
      /* HOLD DOCUMENTÉ — jamais un ordre avec expiration non définie. */
      return {
        action: 'HOLD',
        confidence: 0,
        reason: `BOS/CHoCH/CISD : signal ${top.action === 'CALL' ? 'CALL ▲' : 'PUT ▼'} (${top.rule.id} : [${top.rule.alerts.join(' + ')}]) REFUSÉ — switch « remaining Time Before Candle Closure » actif mais AUCUNE horloge fournie et AUCUNE expiration statique de secours — aucun ordre possible`,
        events: firedConditions,
        candleTime: last.time,
        matchedRuleId: top.rule.id,
        matchedRuleConditions: top.rule.alerts,
      }
    }
  } else {
    expirationDetail = ` — expiration ${resolvedSeconds} s`
  }

  return {
    action: top.action,
    confidence,
    matchedRuleId: top.rule.id,
    ...(validationRule ? { matchedRuleValidation: validationRule } : {}),
    expirationSeconds: resolvedSeconds ?? undefined,
    expirationMode: ruleMode,
    ...(resolvedCandles != null ? { expirationCandles: resolvedCandles } : {}),
    matchedRuleConditions: top.rule.alerts,
    ...(cisdConfirmed ? {
      cisdConfirmation: {
        direction: cisdConfirmed.direction as 'up' | 'down',
        armedCandleTime: cisdConfirmed.armedCandleTime as number,
        swingPrice: cisdConfirmed.swingPrice as number,
        confirmedBy: cisdConfirmed.confirmedBy ?? [],
        swingMode: cisdConfirmed.swingMode ?? 'intact',
      },
    } : {}),
    reason: `${top.action === 'CALL' ? 'CALL ▲' : 'PUT ▼'} — règle ${top.rule.id} : [${top.rule.alerts.join(' + ')}] présente(s) dans [${firedConditions.join(' + ')}]${expirationDetail} — niveau ${bestEvent ? `${bestEvent.label} ${fmt(bestEvent.linePrice)}` : 'confluence'}${options.confirmPreviousCandle ? ' — confirmé par la bougie précédente' : ''}${validationDetail ? ` — ${validationDetail}` : ''}${cisdConfirmed ? ` — ${cisdConfirmed.detail}` : ''}${cisdDirectNote}`,
    events: firedConditions,
    candleTime: last.time,
  }
}

export function evaluateBosChochCisd(
  candles: BosChochCisdCandle[],
  settings: Partial<BosChochCisdSettings> = {},
  options: ConfirmPreviousCandleOptions = {},
): BosChochCisdSignal {
  const s = { ...BOS_CHOCH_CISD_DEFAULT_SETTINGS, ...settings }
  const n = candles.length
  if (n === 0) {
    return { action: 'HOLD', confidence: 0, reason: 'BOS/CHoCH/CISD : aucune bougie', events: [], candleTime: 0 }
  }
  const last = candles[n - 1]
  const res = computeBosChochCisd(candles)

  /* événements de la dernière bougie, filtrés par les toggles */
  const fired = res.events.filter((e) => e.barIndex === n - 1)
  const active = fired.filter((e) => Boolean(s[eventToggleKey(e)]))

  const fmt = (v: number) => {
    const abs = Math.abs(v)
    if (abs >= 1000) return v.toFixed(2)
    if (abs >= 1) return v.toFixed(4)
    return v.toFixed(5)
  }
  const trendTxt = res.uptrend ? 'tendance haussière (swing lows ascendants)'
    : res.downtrend ? 'tendance baissière (swing highs descendants)'
    : 'structure neutre'

  if (active.length > 0) {
    const dir = active[0].dir
    const conf = Math.max(...active.map((e) => KIND_CONFIDENCE[e.kind]))
    const labels = active.map((e) => e.label)
    /* v19 — Confirmation par la bougie précédente (chemin toggles) : même
     * règle que le chemin règles CALL/PUT — CALL ▲ exige une bougie
     * baissière avant la bougie signalée, PUT ▼ une bougie haussière. */
    if (options.confirmPreviousCandle) {
      const check = checkPreviousCandleConfirmation(candles, dir === 'up' ? 'CALL' : 'PUT')
      if (!check.confirmed) {
        return {
          action: 'HOLD',
          confidence: 0,
          reason: `BOS/CHoCH/CISD : signal ${dir === 'up' ? 'CALL ▲' : 'PUT ▼'} (${labels.join(' + ')}) REFUSÉ par la confirmation de bougie — ${check.detail}`,
          events: [],
          candleTime: last.time,
        }
      }
    }
    const reasons: string[] = []
    for (const e of active) {
      if (e.kind === 'bos') {
        reasons.push(e.dir === 'up'
          ? `BOS Up — cassure du swing high ${fmt(e.linePrice)} dans une ${trendTxt}`
          : `BOS Down — cassure du swing low ${fmt(e.linePrice)} dans une ${trendTxt}`)
      } else if (e.kind === 'choch') {
        reasons.push(e.dir === 'up'
          ? `CHoCH Up — retournement : cassure du swing high ${fmt(e.linePrice)} sous le précédent ${fmt(res.swingHighPrice1 ?? e.linePrice)}`
          : `CHoCH Down — retournement : cassure du swing low ${fmt(e.linePrice)} au-dessus du précédent ${fmt(res.swingLowPrice1 ?? e.linePrice)}`)
      } else {
        reasons.push(e.dir === 'up'
          ? `CISD Up — changement d'état de livraison : clôture ${fmt(e.close)} > swing high ${fmt(e.linePrice)}`
          : `CISD Down — changement d'état de livraison : clôture ${fmt(e.close)} < swing low ${fmt(e.linePrice)}`)
      }
    }
    return {
      action: dir === 'up' ? 'CALL' : 'PUT',
      confidence: conf,
      reason: reasons.join(' · '),
      events: labels,
      candleTime: last.time,
    }
  }

  if (fired.length > 0) {
    /* événements présents mais tous désactivés par les toggles */
    const off = fired.map((e) => e.label).join(', ')
    return {
      action: 'HOLD',
      confidence: 0,
      reason: `BOS/CHoCH/CISD : ${off} sur la bougie mais tous les toggles correspondants sont OFF`,
      events: [],
      candleTime: last.time,
    }
  }

  return {
    action: 'HOLD',
    confidence: 0,
    reason: `BOS/CHoCH/CISD : aucun événement — ${trendTxt}, swing high ${res.swingHighPrice != null ? fmt(res.swingHighPrice) : '—'}, swing low ${res.swingLowPrice != null ? fmt(res.swingLowPrice) : '—'}`,
    events: [],
    candleTime: last.time,
  }
}

/* ══════════════════ visuels (limites du pack) ══════════════════ */

/** Limites GC du pack : labels/lignes par famille et lignes tendance. */
export const PACK_LABELS_PER_FAMILY = 80
export const PACK_EVENT_LINES_PER_FAMILY = 80
export const PACK_TREND_LINES_PER_KIND = 50

export interface BosChochCisdVisuals {
  /** Derniers ≤80 labels par famille (BOS/CHoCH/CISD). */
  labels: Array<BosChochCisdEvent & { familyColour: string }>
  /** Dernières ≤80 lignes d'événement par famille. */
  eventLines: Array<{ event: BosChochCisdEvent; colour: string }>
  /** Dernières ≤50 lignes de tendance par sens. */
  trendLines: BosChochCisdTrendLine[]
}

/**
 * Extrait les éléments visuels (labels + lignes) avec les limites du pack :
 * exactement ce que Main.pine garde à l'écran (array.shift au-delà de
 * 80/80/50). Les couleurs des labels viennent des réglages.
 */
export function computeBosChochCisdVisuals(
  candles: BosChochCisdCandle[],
  settings: Partial<BosChochCisdSettings> = {},
  options: ComputeBosChochCisdOptions = {},
): BosChochCisdVisuals {
  const s = { ...BOS_CHOCH_CISD_DEFAULT_SETTINGS, ...settings }
  const res = computeBosChochCisd(candles, options)

  const familyColour = (e: BosChochCisdEvent): string => {
    if (e.kind === 'bos') return e.dir === 'up' ? s.bosUpLabelColour : s.bosDownLabelColour
    if (e.kind === 'choch') return e.dir === 'up' ? s.chochUpLabelColour : s.chochDownLabelColour
    return e.dir === 'up' ? s.cisdUpLabelColour : s.cisdDownLabelColour
  }

  /* GC par famille : garder les DERNIERS éléments (ordre chronologique),
   * SANS déduplication — le pack dessine réellement deux lignes identiques
   * quand deux événements partagent la même paire de swings. */
  const byFamily = new Map<string, BosChochCisdEvent[]>()
  for (const e of res.events) {
    const arr = byFamily.get(e.kind) ?? []
    arr.push(e)
    byFamily.set(e.kind, arr)
  }
  const kept = new Set<BosChochCisdEvent>()
  for (const [, arr] of byFamily) {
    for (const e of arr.slice(-PACK_LABELS_PER_FAMILY)) kept.add(e)
  }

  const labels = res.events
    .filter((e) => kept.has(e))
    .map((e) => ({ ...e, familyColour: familyColour(e) }))

  const eventLines = labels.map((e) => ({ event: e as BosChochCisdEvent, colour: e.lineColour }))

  const upTrend = res.events.filter((e) => e.trendLine?.kind === 'uptrend').slice(-PACK_TREND_LINES_PER_KIND)
  const downTrend = res.events.filter((e) => e.trendLine?.kind === 'downtrend').slice(-PACK_TREND_LINES_PER_KIND)
  const trendLines: BosChochCisdTrendLine[] = [...upTrend, ...downTrend].map((e) => e.trendLine!)

  return { labels, eventLines, trendLines }
}
