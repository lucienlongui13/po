/**
 * Body Imbalance (Gap) — live, non-repainting detector.
 *
 * Definition used by the requested strategy:
 *   • Previous candle body = [min(open, close), max(open, close)].
 *   • Previous bullish + previous body HIGH < current body LOW → bullish imbalance → CALL.
 *   • Previous bearish + previous body LOW > current body HIGH → bearish imbalance → PUT.
 *
 * The CURRENT candle is allowed to be the forming candle, so the condition can
 * trigger intrabar as soon as its body separates from the previous body.
 */

export interface BodyImbalanceCandle {
  time?: number
  open: number
  high: number
  low: number
  close: number
}

export type BodyImbalanceDirection = 'up' | 'down' | null

export interface BodyImbalanceSignal {
  detected: boolean
  direction: BodyImbalanceDirection
  action: 'CALL' | 'PUT' | 'HOLD'
  previousTime: number
  currentTime: number
  previousOpen: number
  previousClose: number
  currentOpen: number
  currentClose: number
  previousBodyTop: number
  previousBodyBottom: number
  currentBodyTop: number
  currentBodyBottom: number
  gapTop: number
  gapBottom: number
  gapSize: number
  reason: string
}

function finite(v: unknown): v is number {
  return typeof v === 'number' && Number.isFinite(v)
}

export function bodyBounds(c: BodyImbalanceCandle): { top: number; bottom: number } | null {
  const open = Number(c.open)
  const close = Number(c.close)
  if (!finite(open) || !finite(close)) return null
  return { top: Math.max(open, close), bottom: Math.min(open, close) }
}


export interface BodyImbalanceTickSignal {
  detected: boolean
  direction: 'up' | 'down' | null
  action: 'CALL' | 'PUT' | 'HOLD'
  previousTime: number
  currentTime: number
  previousBodyTop: number
  previousBodyBottom: number
  currentOpen: number
  currentPrice: number
  currentBodyTop: number
  currentBodyBottom: number
  gapTop: number
  gapBottom: number
  gapSize: number
  reason: string
}

/**
 * Tick-level BODY-vs-BODY trigger.
 *
 * The current candle is still forming, therefore its live body is:
 *   [min(currentOpen, livePrice), max(currentOpen, livePrice)]
 *
 * A signal is valid only when the WHOLE current body is separated from the
 * previous closed body:
 *   previous bullish + currentBodyBottom > previousBodyTop => CALL
 *   previous bearish + currentBodyTop < previousBodyBottom => PUT
 *
 * This is intentionally stricter than `livePrice > previousBodyTop` /
 * `livePrice < previousBodyBottom`, which can create false signals when the
 * current candle opened inside the previous body.
 */
export function evaluateBodyImbalanceAtPrice(
  previous: BodyImbalanceCandle | null,
  currentTime: number,
  currentPrice: number,
  current?: { currentOpen: number },
): BodyImbalanceTickSignal {
  const currentOpen = Number(current?.currentOpen)
  const hold: BodyImbalanceTickSignal = {
    detected: false,
    direction: null,
    action: 'HOLD',
    previousTime: Number(previous?.time ?? 0),
    currentTime,
    previousBodyTop: 0,
    previousBodyBottom: 0,
    currentOpen: finite(currentOpen) ? currentOpen : 0,
    currentPrice,
    currentBodyTop: finite(currentOpen) ? Math.max(currentOpen, currentPrice) : currentPrice,
    currentBodyBottom: finite(currentOpen) ? Math.min(currentOpen, currentPrice) : currentPrice,
    gapTop: 0,
    gapBottom: 0,
    gapSize: 0,
    reason: 'No tick-level body imbalance',
  }

  if (!previous || !finite(currentPrice) || currentPrice <= 0) return hold
  if (!finite(currentOpen) || currentOpen <= 0) return { ...hold, reason: 'Invalid current candle open' }

  const pb = bodyBounds(previous)
  if (!pb) return { ...hold, reason: 'Invalid previous candle body' }

  const currentBodyTop = Math.max(currentOpen, currentPrice)
  const currentBodyBottom = Math.min(currentOpen, currentPrice)
  const prevBullish = previous.close > previous.open
  const prevBearish = previous.close < previous.open

  if (prevBullish && currentBodyBottom > pb.top) {
    const gapBottom = pb.top
    const gapTop = currentBodyBottom
    return {
      ...hold,
      detected: true,
      direction: 'up',
      action: 'CALL',
      previousBodyTop: pb.top,
      previousBodyBottom: pb.bottom,
      currentBodyTop,
      currentBodyBottom,
      gapTop,
      gapBottom,
      gapSize: gapTop - gapBottom,
      reason: `Bullish body gap: current body bottom ${currentBodyBottom} > previous body top ${pb.top} → CALL immédiat`,
    }
  }

  if (prevBearish && currentBodyTop < pb.bottom) {
    const gapTop = pb.bottom
    const gapBottom = currentBodyTop
    return {
      ...hold,
      detected: true,
      direction: 'down',
      action: 'PUT',
      previousBodyTop: pb.top,
      previousBodyBottom: pb.bottom,
      currentBodyTop,
      currentBodyBottom,
      gapTop,
      gapBottom,
      gapSize: gapTop - gapBottom,
      reason: `Bearish body gap: current body top ${currentBodyTop} < previous body bottom ${pb.bottom} → PUT immédiat`,
    }
  }

  return {
    ...hold,
    previousBodyTop: pb.top,
    previousBodyBottom: pb.bottom,
    currentBodyTop,
    currentBodyBottom,
    reason: prevBullish
      ? `Waiting: current body bottom ${currentBodyBottom} <= previous bullish body top ${pb.top}`
      : prevBearish
        ? `Waiting: current body top ${currentBodyTop} >= previous bearish body bottom ${pb.bottom}`
        : 'Previous candle is doji — no direction',
  }
}

export function evaluateBodyImbalance(candles: BodyImbalanceCandle[]): BodyImbalanceSignal {
  const hold: BodyImbalanceSignal = {
    detected: false,
    direction: null,
    action: 'HOLD',
    previousTime: 0,
    currentTime: 0,
    previousOpen: 0,
    previousClose: 0,
    currentOpen: 0,
    currentClose: 0,
    previousBodyTop: 0,
    previousBodyBottom: 0,
    currentBodyTop: 0,
    currentBodyBottom: 0,
    gapTop: 0,
    gapBottom: 0,
    gapSize: 0,
    reason: 'No body imbalance',
  }

  if (candles.length < 2) return hold
  const prev = candles[candles.length - 2]
  const cur = candles[candles.length - 1]
  const pb = bodyBounds(prev)
  const cb = bodyBounds(cur)
  if (!pb || !cb) return { ...hold, reason: 'Invalid OHLC/body values' }

  const prevBullish = prev.close > prev.open
  const prevBearish = prev.close < prev.open
  const previousTime = Number(prev.time ?? 0)
  const currentTime = Number(cur.time ?? 0)

  if (prevBullish && pb.top < cb.bottom) {
    const gapBottom = pb.top
    const gapTop = cb.bottom
    return {
      detected: true,
      direction: 'up',
      action: 'CALL',
      previousTime,
      currentTime,
      previousOpen: prev.open,
      previousClose: prev.close,
      currentOpen: cur.open,
      currentClose: cur.close,
      previousBodyTop: pb.top,
      previousBodyBottom: pb.bottom,
      currentBodyTop: cb.top,
      currentBodyBottom: cb.bottom,
      gapTop,
      gapBottom,
      gapSize: gapTop - gapBottom,
      reason: `Bullish body imbalance: previous body high ${pb.top} < current body low ${cb.bottom} → CALL`,
    }
  }

  if (prevBearish && pb.bottom > cb.top) {
    const gapTop = pb.bottom
    const gapBottom = cb.top
    return {
      detected: true,
      direction: 'down',
      action: 'PUT',
      previousTime,
      currentTime,
      previousOpen: prev.open,
      previousClose: prev.close,
      currentOpen: cur.open,
      currentClose: cur.close,
      previousBodyTop: pb.top,
      previousBodyBottom: pb.bottom,
      currentBodyTop: cb.top,
      currentBodyBottom: cb.bottom,
      gapTop,
      gapBottom,
      gapSize: gapTop - gapBottom,
      reason: `Bearish body imbalance: previous body low ${pb.bottom} > current body high ${cb.top} → PUT`,
    }
  }

  if (prev.open === prev.close) return { ...hold, previousTime, currentTime, reason: 'Previous candle is a doji — no direction' }

  return {
    ...hold,
    previousTime,
    currentTime,
    previousOpen: prev.open,
    previousClose: prev.close,
    currentOpen: cur.open,
    currentClose: cur.close,
    previousBodyTop: pb.top,
    previousBodyBottom: pb.bottom,
    currentBodyTop: cb.top,
    currentBodyBottom: cb.bottom,
    reason: 'No non-overlapping body gap',
  }
}

/** Scan history and return body-imbalance zones from recent adjacent candles. */
export function findBodyImbalances(candles: BodyImbalanceCandle[], maxZones = 24): BodyImbalanceSignal[] {
  const out: BodyImbalanceSignal[] = []
  if (candles.length < 2) return out
  const start = Math.max(1, candles.length - Math.max(1, maxZones * 3))
  for (let i = start; i < candles.length; i++) {
    const signal = evaluateBodyImbalance(candles.slice(0, i + 1))
    if (signal.detected && signal.gapSize > 0) out.push(signal)
  }
  return out.slice(-maxZones)
}
