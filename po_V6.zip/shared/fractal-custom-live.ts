/**
 * Canonical Fractal Custom — Live algorithm.
 *
 * This is the single source of truth used by the visual indicator and by
 * backend trading strategies that need the exact same fractal signal.
 * No future candles are consulted.
 */

export interface FractalCustomLiveCandle {
  open: number
  high: number
  low: number
  close: number
}

export interface FractalCustomLiveResult {
  up: Array<number | null>
  down: Array<number | null>
}

export function computeFractalCustomLive(
  candles: FractalCustomLiveCandle[],
  period: number,
  strictness: number,
): FractalCustomLiveResult {
  const n = candles.length
  const k = Math.max(1, Math.round(period))
  const up = Array<number | null>(n).fill(null)
  const down = Array<number | null>(n).fill(null)

  for (let i = k; i < n; i++) {
    let maxH = -Infinity
    let minL = Infinity
    for (let j = 1; j <= k; j++) {
      maxH = Math.max(maxH, candles[i - j].high)
      minL = Math.min(minL, candles[i - j].low)
    }

    const cur = candles[i]
    const prev = candles[i - 1]
    const bull = strictness
      ? cur.low <= minL && cur.close >= cur.open
      : cur.close > prev.close && cur.low <= minL
    const bear = strictness
      ? cur.high >= maxH && cur.close <= cur.open
      : cur.close < prev.close && cur.high >= maxH

    if (bull) up[i] = cur.low
    if (bear) down[i] = cur.high
  }

  return { up, down }
}
