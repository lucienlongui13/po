/**
 * signal-registry.ts — SIGNAL_REGISTRY central (§4/§5/§6)
 * ====================================================================
 * Registre UNIQUE de tous les signaux du projet : événements ICT du
 * moteur partagé (BOS/CHoCH/CISD) + les 73 candlestick patterns du pack
 * source. Les chaînes ne sont plus dispersées : chaque signal est
 * décrit une seule fois ici (id, label, catégorie, direction, nature,
 * tradable, displayDefault).
 *
 * CLASSIFICATION (§6) — chaque événement est classé :
 *   nature 'SIGNAL'  : peut déclencher un CALL/PUT via le Rule Builder ;
 *   nature 'LEVEL'   : niveau de prix (jamais un CALL/PUT automatique) ;
 *   nature 'CONTEXT' : contexte de marché (jamais un CALL/PUT).
 * Un LEVEL ou un CONTEXT ne DEVIENT JAMAIS automatiquement un ordre —
 * seuls les signaux `tradable` sont proposés comme conditions du Rule
 * Builder CALL/PUT (§11).
 *
 * EXTENSIBILITÉ ICT (§5) : les signaux ICT non encore émis par le moteur
 * courant (BISI, SIBI, OB, Breaker, MB, Po3, Judas, SMT, AMD, DRT,
 * Premium/Discount, HH/HL/LH/LL, BSL/SSL…) sont ENREGISTRÉS avec
 * `available: false` — ils apparaissent grisés dans les filtres de
 * visibilité (classification complète, §23) mais ne sont ni détectés ni
 * proposés au Rule Builder tant que leur moteur n'existe pas. Les
 * Killzones NE SONT PAS réintroduits (§43).
 *
 * SÉPARATION DISPLAY / TRADING (§33) : les filtres d'affichage vivent
 * ici côté TYPES/normalisation, mais la VISIBILITÉ n'influence JAMAIS
 * la détection — un signal masqué reste utilisable par Auto Trade et le
 * Strategy Tester.
 */

import {
  CANDLE_PATTERN_DEFS,
  type CandlePatternDirection,
  type CandlePatternId,
} from './candle-patterns'

/* ═══════════════════════════ types ═══════════════════════════ */

/** Groupes de visibilité (§23 — miroir des groupes du cahier des charges). */
export type SignalCategory =
  | 'STRUCTURE'      // BOS / CHoCH / CISD
  | 'IMBALANCE'      // BISI / SIBI / VI / GI / CE
  | 'BLOCKS'         // OB / Breaker / Mitigation
  | 'SWINGS'         // HH / HL / LH / LL / Swing High / Swing Low
  | 'LIQUIDITY'      // BSL / SSL / Old High / Old Low / Purged
  | 'DRT'            // DRT / 75 / 50 / 25 / Premium / Discount
  | 'PO3'            // Po3 Buy/Sell / Judas / Midnight Open
  | 'SMT'            // SMT Bullish / Bearish
  | 'AMD'            // Accumulation / Manipulation / Distribution
  | 'CANDLE'         // 73 candlestick patterns

/** Nature de l'événement (§6). */
export type SignalNature = 'SIGNAL' | 'LEVEL' | 'CONTEXT'

/** Direction du signal. */
export type SignalDirection = 'bullish' | 'bearish' | 'neutral'

/** Entrée du registry. */
export interface SignalRegistryEntry {
  /** Id machine (alerte BOS ou patternId candle). */
  id: string
  /** Libellé affiché (label exact du pack source). */
  label: string
  category: SignalCategory
  direction: SignalDirection
  nature: SignalNature
  /** Utilisable comme condition du Rule Builder CALL/PUT. */
  tradable: boolean
  /** Visible par défaut quand « Tags & labels » est ON. */
  displayDefault: boolean
  /** Émis par le moteur actuel (false = classé mais non détecté). */
  available: boolean
}

/** Priorité d'affichage (§27) : 1 = le plus prioritaire. */
export const SIGNAL_DISPLAY_PRIORITY: Record<SignalCategory, number> = {
  STRUCTURE: 1,
  IMBALANCE: 2,
  BLOCKS: 2,
  SWINGS: 4,
  LIQUIDITY: 5,
  DRT: 5,
  PO3: 5,
  SMT: 5,
  AMD: 6,
  CANDLE: 3,
}

/* ═══════════════════════ construction du registry ═══════════════════════ */

function structure(id: string, label: string, direction: SignalDirection): SignalRegistryEntry {
  return { id, label, category: 'STRUCTURE', direction, nature: 'SIGNAL', tradable: true, displayDefault: true, available: true }
}

/** Signal ICT enregistré mais NON détecté par le moteur actuel (§5). */
function future(id: string, label: string, category: SignalCategory, direction: SignalDirection, nature: SignalNature): SignalRegistryEntry {
  return { id, label, category, direction, nature, tradable: nature === 'SIGNAL', displayDefault: false, available: false }
}

function candleEntry(def: (typeof CANDLE_PATTERN_DEFS)[number]): SignalRegistryEntry {
  return {
    id: def.id,
    label: def.label,
    category: 'CANDLE',
    direction: def.direction as SignalDirection,
    nature: 'SIGNAL',
    tradable: def.tradable,
    displayDefault: def.displayDefault,
    available: true,
  }
}

/**
 * SIGNAL_REGISTRY — l'ordre est l'ordre d'affichage des groupes :
 * STRUCTURE (6) → IMBALANCE → BLOCKS → SWINGS → LIQUIDITY → DRT → PO3 →
 * SMT → AMD → CANDLE (73).
 */
export const SIGNAL_REGISTRY: SignalRegistryEntry[] = [
  /* STRUCTURE — moteur actuel (6, disponibles) */
  structure('BOS Up', 'BOS Up', 'bullish'),
  structure('BOS Down', 'BOS Down', 'bearish'),
  structure('CHoCH Up', 'CHoCH Up', 'bullish'),
  structure('CHoCH Down', 'CHoCH Down', 'bearish'),
  structure('CISD Up', 'CISD Up', 'bullish'),
  structure('CISD Down', 'CISD Down', 'bearish'),

  /* IMBALANCE — non détectés par le moteur actuel */
  future('BISI', 'BISI', 'IMBALANCE', 'bullish', 'SIGNAL'),
  future('SIBI', 'SIBI', 'IMBALANCE', 'bearish', 'SIGNAL'),
  future('BISI Rebalanced', 'BISI Rebalanced', 'IMBALANCE', 'bullish', 'SIGNAL'),
  future('SIBI Rebalanced', 'SIBI Rebalanced', 'IMBALANCE', 'bearish', 'SIGNAL'),
  future('VI Up', 'VI Up', 'IMBALANCE', 'bullish', 'SIGNAL'),
  future('VI Down', 'VI Down', 'IMBALANCE', 'bearish', 'SIGNAL'),
  future('GI Up', 'GI Up', 'IMBALANCE', 'bullish', 'SIGNAL'),
  future('GI Down', 'GI Down', 'IMBALANCE', 'bearish', 'SIGNAL'),
  future('CE', 'CE', 'IMBALANCE', 'neutral', 'CONTEXT'),

  /* BLOCKS — non détectés */
  future('OB Up', 'OB Up', 'BLOCKS', 'bullish', 'SIGNAL'),
  future('OB Down', 'OB Down', 'BLOCKS', 'bearish', 'SIGNAL'),
  future('OB Up+', 'OB Up+', 'BLOCKS', 'bullish', 'SIGNAL'),
  future('OB Down+', 'OB Down+', 'BLOCKS', 'bearish', 'SIGNAL'),
  future('OB Up Retest', 'OB Up Retest', 'BLOCKS', 'bullish', 'SIGNAL'),
  future('OB Down Retest', 'OB Down Retest', 'BLOCKS', 'bearish', 'SIGNAL'),
  future('Breaker Up', 'Breaker Up', 'BLOCKS', 'bullish', 'SIGNAL'),
  future('Breaker Down', 'Breaker Down', 'BLOCKS', 'bearish', 'SIGNAL'),
  future('Breaker Up Retest', 'Breaker Up Retest', 'BLOCKS', 'bullish', 'SIGNAL'),
  future('Breaker Down Retest', 'Breaker Down Retest', 'BLOCKS', 'bearish', 'SIGNAL'),
  future('MB Up', 'MB Up', 'BLOCKS', 'bullish', 'SIGNAL'),
  future('MB Down', 'MB Down', 'BLOCKS', 'bearish', 'SIGNAL'),
  future('MB Up Retest', 'MB Up Retest', 'BLOCKS', 'bullish', 'SIGNAL'),
  future('MB Down Retest', 'MB Down Retest', 'BLOCKS', 'bearish', 'SIGNAL'),

  /* SWINGS — non détectés */
  future('HH', 'HH', 'SWINGS', 'bullish', 'LEVEL'),
  future('HL', 'HL', 'SWINGS', 'bullish', 'LEVEL'),
  future('LH', 'LH', 'SWINGS', 'bearish', 'LEVEL'),
  future('LL', 'LL', 'SWINGS', 'bearish', 'LEVEL'),
  future('Swing High', 'Swing High', 'SWINGS', 'neutral', 'LEVEL'),
  future('Swing Low', 'Swing Low', 'SWINGS', 'neutral', 'LEVEL'),

  /* LIQUIDITY — non détectés */
  future('BSL', 'BSL', 'LIQUIDITY', 'bullish', 'LEVEL'),
  future('SSL', 'SSL', 'LIQUIDITY', 'bearish', 'LEVEL'),
  future('Old High', 'Old High', 'LIQUIDITY', 'neutral', 'LEVEL'),
  future('Old Low', 'Old Low', 'LIQUIDITY', 'neutral', 'LEVEL'),
  future('Liquidity Pool', 'Liquidity Pool', 'LIQUIDITY', 'neutral', 'LEVEL'),
  future('Buystops Purged', 'Buystops Purged', 'LIQUIDITY', 'bullish', 'SIGNAL'),
  future('Sellstops Purged', 'Sellstops Purged', 'LIQUIDITY', 'bearish', 'SIGNAL'),

  /* DRT — non détectés */
  future('DRT', 'DRT', 'DRT', 'neutral', 'LEVEL'),
  future('DRH', 'DRH', 'DRT', 'neutral', 'LEVEL'),
  future('DRL', 'DRL', 'DRT', 'neutral', 'LEVEL'),
  future('DRT 75', 'DRT 75', 'DRT', 'neutral', 'LEVEL'),
  future('DRT 50', 'DRT 50', 'DRT', 'neutral', 'LEVEL'),
  future('DRT 25', 'DRT 25', 'DRT', 'neutral', 'LEVEL'),
  future('Premium', 'Premium', 'DRT', 'bearish', 'LEVEL'),
  future('Discount', 'Discount', 'DRT', 'bullish', 'LEVEL'),

  /* PO3 — non détectés */
  future('Po3 Buy', 'Po3 Buy', 'PO3', 'bullish', 'SIGNAL'),
  future('Po3 Sell', 'Po3 Sell', 'PO3', 'bearish', 'SIGNAL'),
  future('Judas Swing Up', 'Judas Swing Up', 'PO3', 'bullish', 'SIGNAL'),
  future('Judas Swing Down', 'Judas Swing Down', 'PO3', 'bearish', 'SIGNAL'),
  future('Midnight Open', 'Midnight Open', 'PO3', 'neutral', 'CONTEXT'),

  /* SMT — non détectés */
  future('SMT Bullish', 'SMT Bullish', 'SMT', 'bullish', 'SIGNAL'),
  future('SMT Bearish', 'SMT Bearish', 'SMT', 'bearish', 'SIGNAL'),

  /* AMD — non détectés */
  future('AMD Accumulation', 'AMD Accumulation', 'AMD', 'neutral', 'CONTEXT'),
  future('AMD Manipulation', 'AMD Manipulation', 'AMD', 'neutral', 'CONTEXT'),
  future('AMD Distribution', 'AMD Distribution', 'AMD', 'neutral', 'CONTEXT'),

  /* CANDLE — les 73 patterns du pack source (tous disponibles) */
  ...CANDLE_PATTERN_DEFS.map(candleEntry),
]

/** Index id → entrée. */
export const SIGNAL_REGISTRY_BY_ID: Record<string, SignalRegistryEntry> = Object.fromEntries(
  SIGNAL_REGISTRY.map((s) => [s.id, s]),
)

/** Les ids utilisables comme condition du Rule Builder (§11). */
export function tradableSignalIds(): string[] {
  return SIGNAL_REGISTRY.filter((s) => s.available && s.tradable).map((s) => s.id)
}

/** Entrée d'un id (null si inconnu). */
export function getRegistryEntry(id: string): SignalRegistryEntry | null {
  return SIGNAL_REGISTRY_BY_ID[id] ?? null
}

/** Libellé d'affichage d'un id de condition du Rule Builder. */
export function signalLabel(id: string): string {
  return SIGNAL_REGISTRY_BY_ID[id]?.label ?? id
}

/** Un id de condition est-il un pattern candle ? */
export function isCandleCondition(id: string): id is CandlePatternId {
  const e = SIGNAL_REGISTRY_BY_ID[id]
  return e?.category === 'CANDLE'
}

/** Conditions groupées pour le selector du Rule Builder (§11). */
export function tradableConditionsByCategory(): Array<{ category: SignalCategory; entries: SignalRegistryEntry[] }> {
  const out: Array<{ category: SignalCategory; entries: SignalRegistryEntry[] }> = []
  for (const cat of ['STRUCTURE', 'CANDLE'] as SignalCategory[]) {
    out.push({ category: cat, entries: SIGNAL_REGISTRY.filter((s) => s.category === cat && s.available && s.tradable) })
  }
  return out
}

/* ═══════════════ filtres de visibilité (§22-24, §33) ═══════════════ */

/** Taille des labels (§29) — défaut Large. */
export type SignalLabelSize = 'Small' | 'Normal' | 'Large' | 'Huge'

/** Groupes repliables de l'UI de filtres. */
export const SIGNAL_CATEGORY_ORDER: SignalCategory[] = [
  'STRUCTURE', 'IMBALANCE', 'BLOCKS', 'SWINGS', 'LIQUIDITY', 'DRT', 'PO3', 'SMT', 'AMD', 'CANDLE',
]

export const SIGNAL_CATEGORY_LABELS: Record<SignalCategory, string> = {
  STRUCTURE: 'STRUCTURE',
  IMBALANCE: 'IMBALANCE',
  BLOCKS: 'BLOCKS',
  SWINGS: 'SWINGS',
  LIQUIDITY: 'LIQUIDITY',
  DRT: 'DRT',
  PO3: 'PO3',
  SMT: 'SMT',
  AMD: 'AMD',
  CANDLE: 'CANDLE PATTERNS',
}

/** Réglages d'affichage des signaux (persistés — §31). */
export interface SignalDisplayFilters {
  /** SWITCH MASTER (§22) — OFF : AUCUN tag visuel. */
  showLabels: boolean
  /** Taille des labels (§29) — défaut Large. */
  labelSize: SignalLabelSize
  /** Visibilité par groupe (true = visible). */
  groups: Partial<Record<SignalCategory, boolean>>
  /** Visibilité par signal (true = visible) — absents = displayDefault. */
  signals: Record<string, boolean>
  /** CANDLE — masters par direction (§23). */
  candleMasters: { bullish: boolean; bearish: boolean; neutral: boolean }
}

export const DEFAULT_SIGNAL_DISPLAY: SignalDisplayFilters = {
  showLabels: false,
  labelSize: 'Large',
  groups: { STRUCTURE: true, CANDLE: true },
  signals: {},
  candleMasters: { bullish: true, bearish: true, neutral: true },
}

/**
 * Normalise des filtres partiels (localStorage/migration) vers une forme
 * complète — les champs absents retombent sur le DÉFAUT, jamais sur
 * « tout masqué ».
 */
export function normalizeSignalDisplayFilters(raw: unknown): SignalDisplayFilters {
  const d = DEFAULT_SIGNAL_DISPLAY
  if (!raw || typeof raw !== 'object') return { ...d, groups: { ...d.groups }, signals: {}, candleMasters: { ...d.candleMasters } }
  const r = raw as Partial<SignalDisplayFilters>
  const size = ['Small', 'Normal', 'Large', 'Huge'].includes(r.labelSize as string) ? r.labelSize as SignalLabelSize : d.labelSize
  const groups: Partial<Record<SignalCategory, boolean>> = {}
  if (r.groups && typeof r.groups === 'object') {
    for (const cat of SIGNAL_CATEGORY_ORDER) {
      const v = (r.groups as Record<string, unknown>)[cat]
      if (typeof v === 'boolean') groups[cat] = v
    }
  }
  const signals: Record<string, boolean> = {}
  if (r.signals && typeof r.signals === 'object') {
    for (const [k, v] of Object.entries(r.signals as Record<string, unknown>)) {
      if (typeof v === 'boolean' && SIGNAL_REGISTRY_BY_ID[k]) signals[k] = v
    }
  }
  const cm = r.candleMasters && typeof r.candleMasters === 'object'
    ? r.candleMasters as Partial<{ bullish: boolean; bearish: boolean; neutral: boolean }>
    : ({} as Partial<{ bullish: boolean; bearish: boolean; neutral: boolean }>)
  return {
    showLabels: typeof r.showLabels === 'boolean' ? r.showLabels : d.showLabels,
    labelSize: size,
    groups: Object.keys(groups).length > 0 ? groups : { ...d.groups },
    signals,
    candleMasters: {
      bullish: typeof cm.bullish === 'boolean' ? cm.bullish : true,
      bearish: typeof cm.bearish === 'boolean' ? cm.bearish : true,
      neutral: typeof cm.neutral === 'boolean' ? cm.neutral : true,
    },
  }
}

/**
 * Un signal est-il VISIBLE à l'écran ? (§22/§23/§33 — AFFICHAGE SEUL :
 * la détection et le Rule Engine ne consultent JAMAIS cette fonction.)
 *
 *   master OFF            → rien (même pas les groupes cochés) ;
 *   groupe OFF            → aucun signal du groupe ;
 *   candle master OFF     → aucun pattern de cette direction ;
 *   signal OFF individuel → ce pattern seul est masqué.
 */
export function isSignalVisible(filters: SignalDisplayFilters, entry: { id: string; category: SignalCategory; direction: SignalDirection }): boolean {
  if (!filters.showLabels) return false
  const groupVisible = filters.groups[entry.category]
  if (groupVisible === false) return false
  if (entry.category === 'CANDLE') {
    const dir = entry.direction as CandlePatternDirection
    if (dir === 'bullish' && !filters.candleMasters.bullish) return false
    if (dir === 'bearish' && !filters.candleMasters.bearish) return false
    if (dir === 'neutral' && !filters.candleMasters.neutral) return false
  }
  const own = filters.signals[entry.id]
  if (typeof own === 'boolean') return own
  const reg = SIGNAL_REGISTRY_BY_ID[entry.id]
  return reg ? reg.displayDefault : true
}

/* ═══════════════════════ presets d'affichage (§24) ═══════════════════════ */

export type SignalDisplayPreset =
  | 'show_all' | 'hide_all' | 'minimal' | 'balanced' | 'full'
  | 'structure_only' | 'ict_only' | 'candle_only' | 'swings_only' | 'liquidity_only'

export const SIGNAL_DISPLAY_PRESETS: SignalDisplayPreset[] = [
  'show_all', 'hide_all', 'minimal', 'balanced', 'full',
  'structure_only', 'ict_only', 'candle_only', 'swings_only', 'liquidity_only',
]

/**
 * Applique un preset — les presets ne modifient QUE l'affichage (jamais
 * la détection ni les règles). Le master switch et la taille restent
 * inchangés (le preset porte sur les filtres).
 */
export function applySignalDisplayPreset(current: SignalDisplayFilters, preset: SignalDisplayPreset): SignalDisplayFilters {
  const allGroups = (v: boolean): Partial<Record<SignalCategory, boolean>> =>
    Object.fromEntries(SIGNAL_CATEGORY_ORDER.map((c) => [c, v])) as Partial<Record<SignalCategory, boolean>>
  const base: SignalDisplayFilters = {
    ...current,
    groups: { ...current.groups },
    signals: { ...current.signals },
    candleMasters: { ...current.candleMasters },
  }
  switch (preset) {
    case 'show_all':
      return { ...base, groups: allGroups(true), signals: {}, candleMasters: { bullish: true, bearish: true, neutral: true } }
    case 'hide_all':
      return { ...base, groups: allGroups(false), signals: {}, candleMasters: { bullish: false, bearish: false, neutral: false } }
    case 'minimal':
      return { ...base, groups: { ...allGroups(false), STRUCTURE: true }, signals: {}, candleMasters: { bullish: true, bearish: true, neutral: true } }
    case 'balanced':
      return { ...base, groups: { ...allGroups(false), STRUCTURE: true, CANDLE: true, SWINGS: true }, signals: {}, candleMasters: { bullish: true, bearish: true, neutral: false } }
    case 'full':
      return { ...base, groups: allGroups(true), signals: {}, candleMasters: { bullish: true, bearish: true, neutral: true } }
    case 'structure_only':
      return { ...base, groups: { ...allGroups(false), STRUCTURE: true }, signals: {}, candleMasters: { bullish: false, bearish: false, neutral: false } }
    case 'ict_only':
      return { ...base, groups: { ...allGroups(false), STRUCTURE: true, IMBALANCE: true, BLOCKS: true, LIQUIDITY: true, DRT: true, PO3: true, SMT: true, AMD: true }, signals: {}, candleMasters: { bullish: false, bearish: false, neutral: false } }
    case 'candle_only':
      return { ...base, groups: { ...allGroups(false), CANDLE: true }, signals: {}, candleMasters: { bullish: true, bearish: true, neutral: true } }
    case 'swings_only':
      return { ...base, groups: { ...allGroups(false), SWINGS: true }, signals: {}, candleMasters: { bullish: false, bearish: false, neutral: false } }
    case 'liquidity_only':
      return { ...base, groups: { ...allGroups(false), LIQUIDITY: true }, signals: {}, candleMasters: { bullish: false, bearish: false, neutral: false } }
  }
}
