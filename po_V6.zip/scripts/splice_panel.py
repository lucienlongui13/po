#!/usr/bin/env python3
"""Splice the new MergedConditionsTab into signal-strategy-panel.tsx,
replacing the old ConditionsTab block (which also contained a pre-existing
syntax error `.map((, label])`)."""
import sys

PANEL = '/home/z/my-project/src/components/trading/signal-strategy-panel.tsx'
NEW = '/home/z/my-project/scripts/new_merged_tab.txt'

with open(PANEL, encoding='utf-8') as f:
    content = f.read()
with open(NEW, encoding='utf-8') as f:
    new_block = f.read()

start_marker = '/* ────────────────────────────────────────────────────────── onglet conditions */'
end_marker = '/* ────────────────────────────────────────────────────────── onglet stop / rejet */'

start = content.find(start_marker)
end = content.find(end_marker)
if start == -1 or end == -1 or end <= start:
    print('ERROR: markers not found', start, end)
    sys.exit(1)

content = content[:start] + new_block + content[end:]

with open(PANEL, 'w', encoding='utf-8') as f:
    f.write(content)

print('OK: replaced ConditionsTab with MergedConditionsTab')
print('new length:', len(content))
