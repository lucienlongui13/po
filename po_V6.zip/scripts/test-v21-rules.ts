/**
 * test-v21-rules.ts — v21 : tests dédiés aux 4 nouvelles règles.
 * ==============================================================
 *
 * 1. « Stay on Forex OTC Only » — classification isForexOtcAsset :
 *    - paires Forex OTC (CADJPY_otc, AUDUSD_OTC…) → true ;
 *    - métaux (XAUUSD_otc), cryptos (BTCUSD_otc), actions (#AAPL_otc),
 *      indices, actifs non-OTC (EURUSD) → false ;
 *    - CROISEMENT COMPLET avec le catalogue réel (183 actifs du HAR) :
 *      toutes les entrées type « currency » + suffixe _otc → true ;
 *      toutes les entrées commodity / cryptocurrency / index / stock → false.
 *
 * 2. Filtrage forexOtcOnly du moteur Auto Switch (payout-guard) :
 *    - pickReplacementCandidate(true) ignore XAUUSD_otc 92 % et choisit
 *      la paire Forex OTC 92 % ;
 *    - evaluatePayoutGuard avec forexOtcOnly → décision vers Forex OTC ;
 *    - AUCUN candidat Forex OTC + forexOtcOnly → PAS de remplacement.
 *
 * 3. Persistance : stayOnForexOtcOnly survit à la sanitization/save de
 *    session-persistence (re-login / redémarrage backend).
 *
 * 4. Vérifications sources :
 *    - BACKEND : plus d'EURUSD_otc codé en dur (DEFAULT_CONFIG.market = '',
 *      pas de fallback || 'EURUSD_otc'), AUTOMATIC_RELOGIN_MS = 1 h (plus de
 *      garde-fou 10 min), événement force-frontend-refresh émis sur chaque
 *      auto-switch (2 chemins de switchAssetAndRefresh + multi) et chaque
 *      re-login, ensureStartupAssetSelection présent et câblé au login,
 *      set-config gère stayOnForexOtcOnly, runPayoutGuard passe forexOtcOnly ;
 *    - FRONTEND : page.tsx ne force PLUS selectMarket(EURUSD_otc) après
 *      authentification (cause racine du bug refresh), switch UI
 *      « Stay on Forex OTC Only » présent sous Auto-switch assets, listener
 *      force-frontend-refresh → window.location.reload, DEFAULT_CONFIG
 *      sans marché codé en dur.
 *
 * Exécution : node --import tsx scripts/test-v21-rules.ts
 */
import * as fs from 'node:fs';
import * as path from 'node:path';
import {
  isForexOtcAsset,
  isPayoutTarget,
  pickReplacementCandidate,
  evaluatePayoutGuard,
  createPayoutGuardState,
  type PayoutSnapshot,
} from '../mini-services/iqoption-backend/payout-guard.js';
import {
  sanitizePersistedSession,
} from '../mini-services/iqoption-backend/session-persistence.js';
import { MARKETS_CATALOG } from '../mini-services/iqoption-backend/markets-catalog.js';

let pass = 0, fail = 0;
function ok(cond: boolean, label: string) {
  if (cond) { pass++; console.log(`  ✓ ${label}`); }
  else { fail++; console.error(`  ✗ ${label}`); }
}

const HERE = path.dirname(new URL(import.meta.url).pathname);
const ROOT = path.resolve(HERE, '..');
const read = (p: string) => fs.readFileSync(path.join(ROOT, p), 'utf-8');

async function main(): Promise<void> {
  // ══════════════════════════════════════════════════════════════════
  console.log('\n═══ v21 — 1. Classification « Forex OTC » (isForexOtcAsset) ═══');

  ok(isForexOtcAsset('CADJPY_otc') === true, 'CADJPY_otc → Forex OTC (exemple utilisateur)');
  ok(isForexOtcAsset('AUDUSD_OTC') === true, 'AUDUSD_OTC (majuscules) → Forex OTC (exemple utilisateur)');
  ok(isForexOtcAsset('audusd_otc') === true, 'audusd_otc (minuscules) → Forex OTC');
  ok(isForexOtcAsset('EURUSD_otc') === true, 'EURUSD_otc → Forex OTC');
  ok(isForexOtcAsset('USDJPY_OTC') === true, 'USDJPY_OTC → Forex OTC');
  ok(isForexOtcAsset('GBPUSD_otc') === true, 'GBPUSD_otc → Forex OTC');
  ok(isForexOtcAsset('USDBRL_otc') === true, 'USDBRL_otc → Forex OTC (exotique)');
  ok(isForexOtcAsset('XAUUSD_otc') === false, 'XAUUSD_otc (OR) → PAS Forex OTC');
  ok(isForexOtcAsset('XAGUSD_otc') === false, 'XAGUSD_otc (ARGENT) → PAS Forex OTC');
  ok(isForexOtcAsset('BTCUSD_otc') === false, 'BTCUSD_otc (crypto) → PAS Forex OTC');
  ok(isForexOtcAsset('ETHUSD_otc') === false, 'ETHUSD_otc (crypto) → PAS Forex OTC');
  ok(isForexOtcAsset('#AAPL_otc') === false, '#AAPL_otc (action) → PAS Forex OTC');
  ok(isForexOtcAsset('JPN225') === false, 'JPN225 (indice, non-OTC) → PAS Forex OTC');
  ok(isForexOtcAsset('SP500_otc') === false, 'SP500_otc (indice — pas 6 lettres) → PAS Forex OTC');
  ok(isForexOtcAsset('EURUSD') === false, 'EURUSD (sans suffixe _otc) → PAS Forex OTC');
  ok(isForexOtcAsset('') === false, 'chaîne vide → false');
  ok(isForexOtcAsset('XAUOTC_otc') === false, 'XAUOTC_otc (code fictif non-fiat) → false');
  ok(isForexOtcAsset('USDXAU_otc') === false, 'USDXAU_otc (quote = or) → false');

  // Croisement COMPLET avec le catalogue réel (183 actifs du HAR).
  const currencyOtc = MARKETS_CATALOG.filter(m => m.type === 'currency' && /_otc$/i.test(m.name));
  const currencyOtcOk = currencyOtc.filter(m => isForexOtcAsset(m.name));
  ok(currencyOtc.length > 55 && currencyOtcOk.length === currencyOtc.length,
    `catalogue : ${currencyOtcOk.length}/${currencyOtc.length} paires « currency » OTC classées Forex OTC`);
  if (currencyOtcOk.length !== currencyOtc.length) {
    const missed = currencyOtc.filter(m => !isForexOtcAsset(m.name)).map(m => m.name);
    console.error('    MANQUANTES :', missed.slice(0, 12).join(', '));
  }
  const nonCurrency = MARKETS_CATALOG.filter(m => m.type && m.type !== 'currency');
  const nonCurrencyBad = nonCurrency.filter(m => isForexOtcAsset(m.name));
  ok(nonCurrency.length > 70 && nonCurrencyBad.length === 0,
    `catalogue : 0/${nonCurrency.length} actifs non-currency (métaux/crypto/indices/actions) classés Forex OTC`);
  if (nonCurrencyBad.length > 0) console.error('    FAUX POSITIFS :', nonCurrencyBad.map(m => m.name).slice(0, 12).join(', '));

  // ══════════════════════════════════════════════════════════════════
  console.log('\n═══ v21 — 2. Auto Switch : filtrage « Stay on Forex OTC Only » ═══');

  const payouts: Record<string, PayoutSnapshot> = {
    'XAUUSD_otc': { payout: 92, isOpen: true },   // or 92 % — AVANT alphabétiquement
    'GBPUSD_otc': { payout: 92, isOpen: true },   // Forex OTC 92 %
    'CADJPY_otc': { payout: 92, isOpen: true },    // Forex OTC 92 %
    'EURUSD_otc': { payout: 56, isOpen: true },   // payout < 92
    'BTCUSD_otc': { payout: 92, isOpen: true },   // crypto 92 %
    'NZDJPY_otc': { payout: 92, isOpen: false }, // marché fermé → inéligible
  };
  const active = ['EURUSD_otc'];

  // Sans le filtre : XAUUSD_otc (alphabétiquement 1er) serait choisi.
  const freePick = pickReplacementCandidate(active, payouts, {}, 1000, 0, false);
  ok(freePick?.asset === 'BTCUSD_otc' || freePick?.asset === 'XAUUSD_otc',
    `sans filtre → candidat alphabétiquement premier (obtenu ${freePick?.asset ?? 'AUCUN'})`);
  // Avec le filtre : uniquement une paire Forex OTC.
  const forexPick = pickReplacementCandidate(active, payouts, {}, 1000, 0, true);
  ok(forexPick?.asset === 'CADJPY_otc' || forexPick?.asset === 'GBPUSD_otc',
    `Stay on Forex OTC Only ON → CADJPY_otc/GBPUSD_otc uniquement (obtenu ${forexPick?.asset ?? 'AUCUN'})`);

  // Que des candidats NON Forex → aucun remplacement.
  const payoutsNonForex: Record<string, PayoutSnapshot> = {
    'EURUSD_otc': { payout: 56, isOpen: true },
    'XAUUSD_otc': { payout: 92, isOpen: true },
    'BTCUSD_otc': { payout: 92, isOpen: true },
  };
  ok(pickReplacementCandidate(['EURUSD_otc'], payoutsNonForex, {}, 1000, 0, true) === null,
    'Stay on Forex OTC Only ON + aucun candidat Forex OTC 92 % → AUCUN switch');

  // evaluatePayoutGuard : forexOtcOnly respecté de bout en bout (cooldown 0
  // pour ne pas bloquer la décision dans le test).
  const st = createPayoutGuardState();
  const baseInput = {
    mode: 'single' as const,
    activeAssets: ['EURUSD_otc'],
    focus: 'EURUSD_otc',
    payouts,
    openPositionsByAsset: { 'EURUSD_otc': 0 },
    lastOrderWinByAsset: { 'EURUSD_otc': true },
    now: 1000,
    config: { swapCooldownMs: 0, maxSwapsPerHour: 12 },
  };
  const dFree = evaluatePayoutGuard(st, baseInput);
  const dForex = evaluatePayoutGuard(st, { ...baseInput, forexOtcOnly: true });
  ok(dFree.length === 1 && (dFree[0].to === 'BTCUSD_otc' || dFree[0].to === 'XAUUSD_otc'),
    `evaluatePayoutGuard sans filtre → cible ${dFree[0]?.to} (non contrainte)`);
  ok(dForex.length === 1 && (dForex[0].to === 'CADJPY_otc' || dForex[0].to === 'GBPUSD_otc'),
    `evaluatePayoutGuard forexOtcOnly → cible Forex OTC (obtenu ${dForex[0]?.to ?? 'AUCUN'})`);

  // Compat : isPayoutTarget inchangé (92 exact).
  ok(isPayoutTarget(92) === true && isPayoutTarget(91.9) === false && isPayoutTarget(95) === false,
    'isPayoutTarget : 92 ✓ · 91,9 ✗ · 95 ✗ (règle == 92 % inchangée)');

  // ══════════════════════════════════════════════════════════════════
  console.log('\n═══ v21 — 3. Persistance de stayOnForexOtcOnly ═══');

  const persisted = sanitizePersistedSession({
    version: 3,
    savedAt: Date.now(),
    mode: 'single',
    assets: ['CADJPY_otc'],
    focus: 'CADJPY_otc',
    config: {
      autoTradeEnabled: true,
      autoSwitchAssets: true,
      stayOnForexOtcOnly: true,
      maxMartingaleSteps: 4,
    },
  });
  ok(persisted?.config?.stayOnForexOtcOnly === true,
    'sanitizePersistedSession conserve stayOnForexOtcOnly=true');
  const persistedOff = sanitizePersistedSession({
    version: 3, savedAt: 1, mode: 'single', assets: ['CADJPY_otc'], focus: 'CADJPY_otc',
    config: { stayOnForexOtcOnly: false },
  });
  ok(persistedOff?.config?.stayOnForexOtcOnly === false,
    'sanitizePersistedSession conserve stayOnForexOtcOnly=false');
  const persistedNoField = sanitizePersistedSession({
    version: 3, savedAt: 1, mode: 'single', assets: ['CADJPY_otc'], focus: 'CADJPY_otc',
    config: {},
  });
  ok(persistedNoField?.config?.stayOnForexOtcOnly === undefined,
    'absence de stayOnForexOtcOnly → undefined (défaut OFF)');

  // ══════════════════════════════════════════════════════════════════
  console.log('\n═══ v21 — 4. Vérifications sources BACKEND ═══');

  const idx = read('mini-services/iqoption-backend/index.ts');

  ok(/market: '',\n/.test(idx), "DEFAULT_CONFIG.market = '' (plus d'asset codé en dur)");
  ok(!/\|\| 'EURUSD_otc'/.test(idx), "plus de fallback || 'EURUSD_otc' nulle part");
  ok(/stayOnForexOtcOnly: false,/.test(idx), 'DEFAULT_CONFIG.stayOnForexOtcOnly = false (OFF par défaut)');
  ok(/stayOnForexOtcOnly\?: boolean;/.test(idx), 'StrategyConfig.stayOnForexOtcOnly déclaré');

  ok(/const AUTOMATIC_RELOGIN_MS = 60 \* 60 \* 1000;/.test(idx),
    'AUTOMATIC_RELOGIN_MS = 60 × 60 × 1000 (re-login toutes les 1 h)');
  ok(!/RELOGIN_MAX_WAIT_GAIN_MS/.test(idx),
    'garde-fou 10 min SUPPRIMÉ — le re-login attend strictement le GAIN');
  ok(/session\.openedDeals\.length > 0/.test(idx) && /session\.lastSettledWin === false/.test(idx),
    'verrous re-login : aucun ordre en cours + dernier ordre = GAIN');

  const ffrEmitCount = (idx.match(/io\.emit\('force-frontend-refresh'/g) ?? []).length;
  const ffrMentionCount = (idx.match(/force-frontend-refresh/g) ?? []).length;
  ok(ffrEmitCount >= 4 && ffrMentionCount >= ffrEmitCount,
    `événement force-frontend-refresh : ${ffrEmitCount} émissions io.emit (auto-switch mono + multi + re-login) + ${ffrMentionCount - ffrEmitCount} référence(s) code`);
  ok(/io\.emit\('force-frontend-refresh', \{ reason: 'relogin'/.test(idx),
    "re-login complet → force-frontend-refresh (reason: 'relogin')");
  ok(/io\.emit\('force-frontend-refresh', \{ reason: 'auto-switch', from: fromAsset, to: nextAsset/.test(idx),
    "switchAssetAndRefresh (mono ET multi) → force-frontend-refresh (reason: 'auto-switch')");
  ok(/io\.emit\('force-frontend-refresh', \{ reason: 'auto-switch', from: d\.from, to: d\.to/.test(idx),
    'runPayoutGuard chemin MULTI → force-frontend-refresh');

  ok(/async function ensureStartupAssetSelection/.test(idx),
    'ensureStartupAssetSelection : sélection aléatoire 92 % au démarrage');
  ok(/void ensureStartupAssetSelection\(io\);/.test(idx),
    'login sans session restaurée → ensureStartupAssetSelection câblé');
  ok(/PO_STARTUP_RANDOM_ASSET === '0'/.test(idx),
    'PO_STARTUP_RANDOM_ASSET=0 désactive la sélection (tests E2E)');
  ok(/Math\.floor\(Math\.random\(\) \* candidates\.length\)/.test(idx),
    'sélection ALÉATOIRE uniforme parmi les assets 92 %');
  ok(/isPayoutTarget\(a\.payout\)/.test(idx),
    'candidats démarrage : payout == 92 % (même tolérance que l\u2019Auto Switch)');

  ok(/forexOtcOnly: session\.config\.stayOnForexOtcOnly === true,/.test(idx),
    'runPayoutGuard transmet forexOtcOnly depuis la config');
  ok(/if \(typeof data\.stayOnForexOtcOnly === 'boolean'\)/.test(idx),
    'set-config gère le switch Stay on Forex OTC Only (+ persistance)');

  // ══════════════════════════════════════════════════════════════════
  console.log('\n═══ v21 — 5. Vérifications sources FRONTEND ═══');

  const page = read('src/app/page.tsx');
  ok(!/autoSelectedMarketRef/.test(page),
    'page.tsx : effet autoSelectedMarketRef SUPPRIMÉ (fin du selectMarket(EURUSD_otc) forcé)');
  ok(!/po\.selectMarket\(po\.defaultConfig\.market\)/.test(page),
    'page.tsx : plus de sélection forcée du défaut après authentification');
  ok(/Stay on Forex OTC Only/.test(page),
    'page.tsx : switch « Stay on Forex OTC Only » présent');
  ok(/po\.setConfig\(\{ stayOnForexOtcOnly: !\(status\?\.config\?\.stayOnForexOtcOnly === true\) \}\)/.test(page),
    'page.tsx : le switch toggle stayOnForexOtcOnly via set-config');
  // Le switch doit être placé APRÈS le bloc Auto-switch assets.
  const autoSwitchPos = page.indexOf('Auto-switch assets');
  const forexPos = page.indexOf('Stay on Forex OTC Only');
  ok(autoSwitchPos >= 0 && forexPos > autoSwitchPos,
    'page.tsx : « Stay on Forex OTC Only » placé SOUS « Auto-switch assets »');

  const hook = read('src/hooks/use-pocket-option.ts');
  ok(/market: '',\n/.test(hook), "use-pocket-option : DEFAULT_CONFIG.market = '' (défaut retiré)");
  ok(/socket\.on\('force-frontend-refresh'/.test(hook),
    "use-pocket-option : listener socket 'force-frontend-refresh'");
  ok(/window\.location\.reload\(\)/.test(hook),
    'use-pocket-option : le listener recharge la page (window.location.reload)');
  ok(/stayOnForexOtcOnly\?: boolean/.test(hook),
    'SessionConfig.stayOnForexOtcOnly déclaré côté frontend');

  // ══════════════════════════════════════════════════════════════════
  console.log('\n═══ v21 — 6. Non-régression : garde E2E PO_STARTUP_RANDOM_ASSET ═══');
  const e2eGuards = [
    'mini-services/iqoption-backend/tests/test-auto-switch-rule-e2e.mjs',
    'mini-services/iqoption-backend/tests/test-bos-choch-cisd-martingale-e2e.mjs',
    'mini-services/iqoption-backend/tests/test-bos-choch-cisd-multi-e2e.mjs',
    'mini-services/iqoption-backend/tests/test-confirm-candle-cap-e2e.mjs',
    'mini-services/iqoption-backend/tests/test-martingale-tie-refund-e2e.mjs',
  ];
  for (const t of e2eGuards) {
    ok(read(t).includes("PO_STARTUP_RANDOM_ASSET: '0'"), `${path.basename(t)} : sélection aléatoire neutralisée`);
  }

  console.log(`\n═══ RÉSULTAT : ${pass} ✓ / ${fail} ✗ ═══`);
  if (fail > 0) process.exit(1);
}

void main();
