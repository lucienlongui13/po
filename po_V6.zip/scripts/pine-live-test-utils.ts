/**
 * pine-live-test-utils.ts — shared harness for the v1.9 alignment test suite.
 *
 * Provides deterministic synthetic datasets, the spec §19 Alignment Probe
 * script, and store/coordinator waiting helpers. Node-runnable via tsx
 * (localStorage persistence is inert outside the browser).
 */
import { usePineStore } from '../src/lib/pine-store'
import { pineCoordinator } from '../src/lib/pine-executor'

export interface TestCandle {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

/** Deterministic M1-style dataset with per-index price variation. */
export function makeCandles(
  count: number,
  opts: { startTime?: number; tfSec?: number; base?: number; tick?: number } = {},
): TestCandle[] {
  const { startTime = 1789439220, tfSec = 60, base = 1.15803, tick = 0.00001 } = opts
  const out: TestCandle[] = []
  let price = base
  for (let i = 0; i < count; i++) {
    price += (Math.round(Math.sin(i / 3) * 40 + Math.cos(i / 11) * 25) * tick) * 8
    const o = price
    const c = price + Math.round(Math.sin(i / 2) * 30) * tick * 4
    out.push({
      time: startTime + i * tfSec,
      open: o,
      high: Math.max(o, c) + 12 * tick,
      low: Math.min(o, c) - 9 * tick,
      close: c,
      volume: 100 + i,
    })
  }
  return out
}

/** Bar timestamp (sec) of index `i` in a makeCandles dataset. */
export function timeOfIndex(i: number, opts: { startTime?: number; tfSec?: number } = {}): number {
  const { startTime = 1789439220, tfSec = 60 } = opts
  return startTime + i * tfSec
}

/** The spec §19 probe: plot + marker + label + bar_index, all at once.
 * max_labels_count=500 mirrors TradingView's declaration — the runtime GCs
 * drawing objects beyond that budget (default 50), which is standard Pine
 * semantics, NOT a pipeline bug. */
export const ALIGNMENT_PROBE_SRC = `//@version=6
indicator("Alignment Probe", overlay=true, max_labels_count=500)
signal = bar_index % 10 == 0
plotshape(signal, style=shape.triangleup, location=location.belowbar, color=color.lime)
label.new(bar_index, low, str.tostring(bar_index))
`

/** Drawings anchor probe: line + box created at fixed bar indexes. */
export const ANCHOR_PROBE_SRC = `//@version=6
indicator("Anchor Probe 2", overlay=true)
if bar_index == 40
    box.new(35, high, 60, low)
if bar_index == 45
    line.new(45, high, 55, low)
`

export const EMA_CROSS_SRC = `//@version=6
indicator("EMA Cross Probe", overlay=true)
fast = ta.ema(close, 9)
slow = ta.ema(close, 21)
buy = ta.crossover(fast, slow)
plot(fast, "Fast EMA", color=color.blue)
plot(slow, "Slow EMA", color=color.orange)
plotshape(buy, title="BUY", style=shape.triangleup, location=location.belowbar, color=color.lime, size=size.tiny)
`

export const RSI_PANE_SRC = `//@version=6
indicator("RSI Pane Probe", overlay=false)
r = ta.rsi(close, 14)
plot(r, "RSI", color=color.purple)
hline(70, "Overbought")
hline(30, "Oversold")
`

export const HIST_SRC = `//@version=6
indicator("Hist Probe", overlay=true)
plot(volume, style=plot.style_histogram, color=color.new(color.blue, 40))
`

export const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms))

/** Reset store + coordinator to a pristine state between scenarios. */
export function resetPineState(): void {
  const st = usePineStore.getState()
  for (const s of st.scripts) st.removeScript(s.id)
  usePineStore.setState({
    scripts: [],
    activeId: null,
    settingsRev: 0,
    dataset: { revision: 0, asset: '', timeframe: 0, lastBarTime: 0, barCount: 0 },
  })
  pineCoordinator.resetForTests()
  pineCoordinator.setRunnerForTests(null)
}

/** Register a script in the store (enabled) and return its id. */
export function addScript(source: string, name: string): string {
  return usePineStore.getState().addScript(source, name)
}

/** Wait until the store predicate holds (subscribes to every set()). */
export function waitForStore(pred: () => boolean, timeoutMs = 8000, label = 'predicate'): Promise<void> {
  return new Promise((resolve, reject) => {
    if (pred()) return resolve()
    let unsub: (() => void) | null = null
    const timer = setTimeout(() => {
      unsub?.()
      reject(new Error(`timeout (${timeoutMs}ms) waiting for ${label}`))
    }, timeoutMs)
    unsub = usePineStore.subscribe(() => {
      if (pred()) {
        clearTimeout(timer)
        unsub?.()
        resolve()
      }
    })
  })
}

/** Wait until the coordinator is fully idle (no batch running, none pending). */
export async function waitForIdle(timeoutMs = 8000): Promise<void> {
  const t0 = Date.now()
  for (;;) {
    const s = pineCoordinator.stats()
    if (!s.executing && !s.queued) return
    if (Date.now() - t0 > timeoutMs) throw new Error(`timeout waiting for coordinator idle (stats=${JSON.stringify(s)}`)
    await sleep(20)
  }
}

/** Every ENABLED script's envelope carries exactly `rev` (atomic commit). */
export function allScriptsAtRevision(rev: number): boolean {
  const scripts = usePineStore.getState().scripts.filter((s) => s.enabled)
  return scripts.length > 0 && scripts.every((s) => s.envelope?.revision === rev)
}

export function storeScript(id: string) {
  return usePineStore.getState().scripts.find((s) => s.id === id)
}

/** Tiny assertion helpers (repo test style). */
export function makeChecker() {
  let pass = 0
  let fail = 0
  const failures: string[] = []
  const ok = (name: string, cond: boolean, extra = '') => {
    if (cond) {
      pass++
      console.log(`  ✓ ${name}`)
    } else {
      fail++
      failures.push(name)
      console.log(`  ✗ ${name}${extra ? ` — ${extra}` : ''}`)
    }
  }
  const finish = (suite: string) => {
    console.log(`\n${suite}: ${pass} passed, ${fail} failed${fail ? `\nFAILED: ${failures.join(' | ')}` : ''}`)
    if (fail > 0) process.exitCode = 1
  }
  return { ok, finish, get pass() { return pass }, get fail() { return fail } }
}
