#!/bin/bash
# Dump full pineCandles + drawing props from the live app
cd /home/z/my-project
agent-browser eval '(() => {
  const dbg = window.__pineChartDebug;
  if (!dbg) return "no hook";
  const candles = dbg.getCandles();
  const scripts = dbg.getScripts().filter(s => s.enabled && s.result);
  const s0 = scripts[0];
  if (!s0) return "no active script result";
  const lines = s0.result.drawings.filter(d => d.kind === "line").slice(0, 8);
  const labels = s0.result.drawings.filter(d => d.kind === "label").slice(0, 8);
  return JSON.stringify({
    candleCount: candles.length,
    firstCandles: candles.slice(0, 6),
    lastCandles: candles.slice(-3),
    candlePriceStats: {
      minLow: Math.min(...candles.map(c => c.low)),
      maxHigh: Math.max(...candles.map(c => c.high)),
    },
    pineBars: s0.result._times.length,
    lines, labels,
  }, null, 1);
})()' 2>&1 | tail -80
