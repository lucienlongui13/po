#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v1.11.sh — Livraison v1.11 « BOS, CHoCH & CISD en stratégie »
#
# Le besoin : convertir l'indicateur du pack pine_full_pack.zip
# (« BOS, CHoCH and CISD [PiracyChecker] », Pine v6 + 4 librairies) en
# STRATÉGIE dans la section Auto Trade — avec les visuels et TOUS les
# réglages du pack.
#
# Le correctif v1.11 :
#   1. MOTEUR PARTAGÉ shared/bos-choch-cisd.ts — port TypeScript fidèle
#      du pack (swings sh/sl + prix shp/slp valuewhen + tendances ut/dt +
#      6 événements + visuels avec offsets ATR/piles + GC 80/80/50),
#      VALIDÉ bougie par bougie contre le VRAI pack exécuté par piner
#      (44/44 — positions Y à écart nul) ;
#   2. STRATÉGIE AUTO TRADE complète : dropdown backend + adaptateur
#      Strategy Tester + ordres réels sur bougies clôturées avec garde
#      un-ordre-par-bougie ;
#   3. VISUELS sur le graphique : overlay canvas (labels + lignes
#      d'événement pointillées + lignes de tendance pleines), monté dès
#      la sélection de la stratégie ;
#   4. RÉGLAGES DU PACK dans le panneau Auto Trade : 7 couleurs + taille
#      + 6 toggles Alerts (persistés localStorage + config backend).
#
# Sortie : /home/z/my-project/download/pine_v6_engine_v1.11.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v1.11"
FOLDER=pine_v6_engine_v1.11
OUT="$ROOT/download/pine_v6_engine_v1.11.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (mêmes exclusions que v1.0→v1.10) ─────────────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude 'upload/' \
  --exclude 'download/' \
  --exclude 'tool-results/' \
  --exclude '.stage-v1.1/' \
  --exclude '.stage-v1.2/' \
  --exclude '.stage-v1.3/' \
  --exclude '.stage-v1.4/' \
  --exclude '.stage-v1.5/' \
  --exclude '.stage-v1.6/' \
  --exclude '.stage-v1.7/' \
  --exclude '.stage-v1.8/' \
  --exclude '.stage-v1.9/' \
  --exclude '.stage-v1.10/' \
  --exclude '.stage-v1.11/' \
  --exclude 'skills/' \
  --exclude 'bun.lock' \
  --exclude '*.tmp' \
  --exclude 'bun-error.log' \
  --exclude '.env.local' \
  --exclude 'tsconfig.tsbuildinfo' \
  --exclude 'next-env.d.ts' \
  --exclude '*.log' \
  --exclude '.logs/' \
  --exclude 'v12_*.png' \
  --exclude 'scripts/*.png' \
  --exclude 'scripts/diag/' \
  --exclude 'scripts/e2e-v18-*.png' \
  --exclude 'scripts/e2e-v110-*.png' \
  --exclude 'scripts/e2e-v111-*.png' \
  --exclude 'scripts/vlm_*.json' \
  --exclude 'scripts/search*.json' \
  --exclude 'scripts/e2e-v18-probe.txt' \
  --exclude 'db/' \
  "$ROOT/" "$STAGE/$FOLDER/"

# ── WaveScope v5 + guide réglages (inclus depuis v1.3) ────────────────────
cp "$ROOT/download/wavescope_ict_v5.pine" "$STAGE/$FOLDER/wavescope_ict_v5.pine"
cp "$ROOT/download/GUIDE-REGLAGES-V5.md" "$STAGE/$FOLDER/GUIDE-REGLAGES-V5.md"

# ── Le pack fourni par l'utilisateur (EXEMPLE + référence de la stratégie) ─
mkdir -p "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies/libs"
cp "$ROOT/upload/pine_full_pack_extracted/pine_full_pack/Main.pine" \
   "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies/Main.pine"
cp "$ROOT/upload/pine_full_pack_extracted/pine_full_pack/libs/"*.pine \
   "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies/libs/"

# ── Docs techniques incluses ──────────────────────────────────────────────
cp "$ROOT/README-PINE-LIVE-ALIGNMENT.md" "$STAGE/$FOLDER/README-PINE-LIVE-ALIGNMENT.md"
cp "$ROOT/README-V1.11-BOS-CHOCH-CISD-AUTOTRADE.md" \
   "$STAGE/$FOLDER/README-V1.11-BOS-CHOCH-CISD-AUTOTRADE.md"

# ── L'indicateur 2BARBL v1.10, prêt à coller (toujours inclus) ─────────────
cp "$ROOT/TradingView_pine_scripts_samples/2barbl_r11_v3.pine" \
   "$STAGE/$FOLDER/Two-Bar-Break-Line-Alerts-R1.1.pine"

# ── Zip DEFLATE lisible par l'importeur de librairies du projet ───────────
mkdir -p "$STAGE/EXEMPLE-Pack-Multi-Librairies/libs"
cp "$ROOT/upload/pine_full_pack_extracted/pine_full_pack/Main.pine" \
   "$STAGE/EXEMPLE-Pack-Multi-Librairies/Main.pine"
cp "$ROOT/upload/pine_full_pack_extracted/pine_full_pack/libs/"*.pine \
   "$STAGE/EXEMPLE-Pack-Multi-Librairies/libs/"
(cd "$STAGE" && zip -qr "$FOLDER/EXEMPLE-Pack-Multi-Librairies.zip" "EXEMPLE-Pack-Multi-Librairies")
rm -rf "$STAGE/EXEMPLE-Pack-Multi-Librairies"

# ── Vérifications d'intégrité ─────────────────────────────────────────────
echo "── Vérifications ──"
for marker in \
  "shared/bos-choch-cisd.ts" \
  "src/lib/bos-choch-cisd-settings.ts" \
  "src/components/trading/chart/bos-choch-cisd-overlay.tsx" \
  "mini-services/iqoption-backend/bos-choch-cisd-strategy.ts"; do
  [ -f "$STAGE/$FOLDER/$marker" ] && echo "  ✓ $marker" || { echo "  ✗ MANQUANT: $marker"; exit 1; }
done
count_bos=$(grep -c "bos_choch_cisd" "$STAGE/$FOLDER/mini-services/iqoption-backend/index.ts" || true)
echo "  marqueurs bos_choch_cisd backend index.ts : $count_bos"
[ "$count_bos" -ge 8 ] || { echo "  ✗ dispatch backend incomplet"; exit 1; }
count_adapter=$(grep -c "bosChochCisdAdapter" "$STAGE/$FOLDER/src/lib/autotrade-strategies.ts" || true)
echo "  marqueurs adaptateur : $count_adapter"
[ "$count_adapter" -ge 1 ] || { echo "  ✗ adaptateur absent"; exit 1; }
count_overlay=$(grep -c "bosChochCisdActive" "$STAGE/$FOLDER/src/components/trading/chart/chart-workspace.tsx" || true)
echo "  marqueurs câblage chart : $count_overlay"
[ "$count_overlay" -ge 1 ] || { echo "  ✗ overlay non monté"; exit 1; }
count_panel=$(grep -c "BosChochCisdFields" "$STAGE/$FOLDER/src/components/trading/auto-trade-panel.tsx" || true)
echo "  marqueurs panneau réglages : $count_panel"
[ "$count_panel" -ge 2 ] || { echo "  ✗ champs de réglages absents"; exit 1; }
[ -f "$STAGE/$FOLDER/README-V1.11-BOS-CHOCH-CISD-AUTOTRADE.md" ] && echo "  ✓ README V1.11"
[ -f "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies.zip" ] && echo "  ✓ zip exemple pack"

# ── Empaquetage final ─────────────────────────────────────────────────────
(cd "$STAGE" && zip -qr "$FOLDER.zip" "$FOLDER")
mv "$STAGE/$FOLDER.zip" "$OUT"
rm -rf "$STAGE"

echo ""
echo "════ Livraison ════"
unzip -t "$OUT" > /dev/null && echo "  intégrité zip OK"
du -h "$OUT"
find "$(dirname "$OUT")" -maxdepth 1 -name "$FOLDER.zip" -exec unzip -l {} \; | tail -2
echo "  sortie : $OUT"
