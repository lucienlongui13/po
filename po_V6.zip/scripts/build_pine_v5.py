#!/usr/bin/env python3
"""
Construit wavescope_ict_v5.pine à partir de wavescope_ict_v4.pine :
  1. En-tête v5 + zones SL/TP en arrière-plan (le fond SL/TP de la v2,
     recalculé en continu) + étiquettes TP 🎯 / SL ✕
  2. TITRE UNIQUE pour chaque input (couleurs/épaisseurs inline) → le menu
     Réglages affiche des noms clairs et les clés d'override sont stables
  3. Nouvelle ligne « TP / SL » dans le tableau de bord
  4. Tout le moteur v4 (ZigZag Auto ×ATR, richesse v2, pièges, projection)
     est conservé à l'identique.
"""
import re
import sys
from pathlib import Path

DL = Path('/home/z/my-project/download')
SRC = DL / 'wavescope_ict_v4.pine'
DST = DL / 'wavescope_ict_v5.pine'

src = SRC.read_text(encoding='utf-8')
lines = src.split('\n')

# ─────────────────────────────────────────────────────────────
# 1. Ligne indicator + bloc d'en-tête
# ─────────────────────────────────────────────────────────────
old_ind = lines[1]
assert old_ind.startswith('indicator("WaveScope'), f"ligne 2 inattendue : {old_ind[:60]}"
lines[1] = ('indicator("WaveScope — ICT / SMC v5 (Zones SL/TP & Réglages)", '
            'shorttitle="WaveScope ICT v5", overlay=true, calc_on_every_tick=true, '
            'max_lines_count=500, max_labels_count=500, max_boxes_count=500, max_bars_back=500)')

# Le bloc de commentaires v4 va de la ligne 4 (idx 3) à la ligne 40 (idx 39)
i_groupes = next(i for i, l in enumerate(lines) if 'GROUPES (Réglages)' in l)
header_end = None
for i in range(i_groupes, 3, -1):
    if lines[i].startswith('// ═'):
        header_end = i  # ligne ═ finale du bloc (idx)
        break
assert header_end is not None

NEW_HEADER = '''// ═══════════════════════════════════════════════════════════════
// WAVESCOPE v5 — ICT / SMART MONEY CONCEPTS — ÉDITION « SL/TP & RÉGLAGES »
// Basée sur la v2 conforme au livre « The Market's Secret Language »
// (Akash Gul) — toute la conformité ICT/SMC est conservée.
//
// NOUVEAUTÉS v5 (par rapport à la v4 « Richesse & Contrôle ») :
//  1. ZONES SL / TP EN ARRIÈRE-PLAN : fond ROUGE entre le prix et le
//     niveau d'invalidation (pool de liquidité opposé), fond VERT entre
//     le prix et la cible — recalculés à chaque barre, avec étiquettes
//     « TP 🎯 BSL … » / « SL ✕ SSL … ». Ce sont les arrière-plans SL/TP
//     de la v2, en version dynamique et réglable.
//  2. CHAQUE PARAMÈTRE PORTE UN NOM UNIQUE : le menu Réglages (bouton
//     ⚙ « Réglages » dans Pine v6 Engine — ou fenêtre Paramètres de
//     TradingView) affiche désormais chaque couleur/épaisseur par son
//     nom (plus aucune entrée « (2) », « (3) »). Depth / Deviation /
//     Backstep, 3 modes (Auto ×ATR, %, points), cases à cocher par
//     structure, 27 couleurs, 11 épaisseurs : TOUT est modifiable et
//     appliqué immédiatement au graphique.
//  3. TABLEAU DE BORD : nouvelle ligne « TP / SL » (cible + invalidation
//     du trade en cours) en plus de « ZigZag — N pivots • seuil
//     effectif » qui permet de VÉRIFIER en direct que les réglages
//     sont bien appliqués.
//  4. TOUT LE RESTE EST CONSERVÉ : ZigZag Auto (×ATR) par défaut,
//     richesse v2 (structure interne, MIT, sessions, compteurs élevés),
//     bannière « TENDANCE À SUIVRE », pièges retail (ch.3), lignes de
//     tendance auto, projection ICT, scénario + confluences /6, temps
//     réel (calc_on_every_tick), conformité ICT/SMC de la v2.
// ═══════════════════════════════════════════════════════════════'''.split('\n')

lines[3:header_end] = NEW_HEADER
src = '\n'.join(lines)

# ─────────────────────────────────────────────────────────────
# 2. Titres uniques pour les inputs inline (couleurs / épaisseurs)
# ─────────────────────────────────────────────────────────────
TITLES = {
    'bullColor':       'Couleur haussière (ZigZag)',
    'bearColor':       'Couleur baissière (ZigZag)',
    'zzWidth':         'Épaisseur du ZigZag',
    'intBullColor':    'Couleur haussière interne',
    'intBearColor':    'Couleur baissière interne',
    'intWidth':        'Épaisseur du zigzag interne',
    'chochColor':      'Couleur BOS/CHoCH/MSS',
    'breakWidth':      'Épaisseur des cassures',
    'trendLineWidth':  'Épaisseur des tendances',
    'trapColor':       'Couleur des pièges retail',
    'projectionColor': 'Couleur de la projection',
    'projWidth':       'Épaisseur de la projection',
    'liqColor':        'Couleur BSL/SSL',
    'liqWidth':        'Épaisseur des liquidités',
    'eqLiqColor':      'Couleur EQH/EQL',
    'sessionColor':    'Couleur de session',
    'fvgBullColor':    'Couleur FVG haussier',
    'fvgBearColor':    'Couleur FVG baissier',
    'fvgBorderWidth':  'Épaisseur des FVG',
    'obBullColor':     'Couleur OB haussier',
    'obBearColor':     'Couleur OB baissier',
    'obBorderWidth':   'Épaisseur des OB',
    'breakerColor':    'Couleur des Breakers',
    'levelColor':      'Couleur des niveaux (OTE/équilibre)',
    'premiumColor':    'Couleur zone premium',
    'discountColor':   'Couleur zone discount',
    'oteWidth':        'Épaisseur de l\'OTE',
    # titres initialement dupliqués entre groupes → clés piner uniques
    'breakLineStyle':  'Style des cassures',
    'liqLineStyle':    'Style des liquidités',
    'fvgFillTransp':   'Transparence fond FVG',
    'obFillTransp':    'Transparence fond OB',
    'locFillTransp':   'Transparence premium/discount',
    'oteFillTransp':   'Transparence OTE',
}

for varname, title in TITLES.items():
    # input.x(default, "<titre>", ...) — default peut contenir des virgules
    # imbriquées (color.rgb(0, 230, 118)) → on traverse les parenthèses.
    pat = re.compile(
        rf'^({varname}\s*=\s*input\.(?:color|int|float|string)\((?:[^()"]|"[^"]*"|\([^()]*\))*?,\s*)("[^"]*")(,)',
        re.M)
    matches = pat.findall(src)
    assert len(matches) == 1, f"{varname}: {len(matches)} correspondance(s) (attendu 1)"
    src = pat.sub(lambda m: f'{m.group(1)}"{title}"{m.group(3)}', src, count=1)

# ─────────────────────────────────────────────────────────────
# 3. Nouveaux inputs ZONES SL / TP (après showTargetLabel)
# ─────────────────────────────────────────────────────────────
ANCHOR_INPUTS = 'showTargetLabel  = input.bool(true, "Étiquette cible 🎯", group=G_LOC)\n'
assert src.count(ANCHOR_INPUTS) == 1
SLTP_INPUTS = ANCHOR_INPUTS + '''
// ── v5 : ZONES SL / TP (arrière-plans du trade en cours) ──
showSLTPZones   = input.bool(true, "Zones SL / TP en arrière-plan", group=G_LOC, inline="sltp", tooltip="v5 : fond ROUGE entre le prix courant et le niveau d'invalidation (SL) + fond VERT entre le prix et la cible (TP). Recalculés à chaque barre : ce sont les arrière-plans SL/TP de la v2, en dynamique et réglables.")
slZoneColor     = input.color(color.rgb(255, 61, 87), "Couleur zone SL", group=G_LOC, inline="sltp", tooltip="Couleur de l'arrière-plan Stop Loss (rouge par défaut).")
tpZoneColor     = input.color(color.rgb(0, 230, 118), "Couleur zone TP", group=G_LOC, inline="sltp", tooltip="Couleur de l'arrière-plan Take Profit (vert par défaut).")
sltpTransp      = input.int(82, "Transparence SL/TP", minval=0, maxval=100, group=G_LOC, inline="sltp", tooltip="0 = fond opaque, 100 = fond invisible.")
sltpWidth       = input.int(14, "Largeur des zones (barres)", minval=4, maxval=100, group=G_LOC, tooltip="Largeur horizontale (en barres) des rectangles SL/TP autour du prix courant.")
showSLTPLabels  = input.bool(true, "Étiquettes SL ✕ / TP 🎯", group=G_LOC, tooltip="Étiquettes posées sur les bords des zones : « TP 🎯 BSL 1.14231 » et « SL ✕ SSL 1.13892 ».")
'''
src = src.replace(ANCHOR_INPUTS, SLTP_INPUTS, 1)

# ─────────────────────────────────────────────────────────────
# 4. Vars des zones SL / TP (après var label targetLabel)
# ─────────────────────────────────────────────────────────────
ANCHOR_VARS = 'var label  targetLabel = na\n'
assert src.count(ANCHOR_VARS) == 1
SLTP_VARS = ANCHOR_VARS + '''var box   tpZoneBox  = na
var box   slZoneBox  = na
var label tpZoneLbl  = na
var label slZoneLbl  = na
var string sltpText  = "—"
var color  sltpCol   = na
'''
src = src.replace(ANCHOR_VARS, SLTP_VARS, 1)

# ─────────────────────────────────────────────────────────────
# 5. Bloc ZONES SL / TP (après la section CIBLES)
# ─────────────────────────────────────────────────────────────
ANCHOR_TGT = '''else
    targetPrice := na
    targetText := "—"
    if not na(targetLabel)
        label.delete(targetLabel)
        targetLabel := na
'''
assert src.count(ANCHOR_TGT) == 1

SLTP_BLOCK = ANCHOR_TGT + '''
// ───────────────────── ZONES SL / TP (v5) ─────────────────────
// Arrière-plans du trade ICT en cours. TP = cible de liquidité la plus
// proche dans le sens de la tendance (déjà calculée ci-dessus). SL = pool
// de liquidité OPPOSÉ le plus proche (invalidation structurelle), à défaut
// le bord opposé de l'OTE, à défaut le dernier pivot opposé.
float slLvl = na
string slTxt = ""
if extS.trend == 1
    if array.size(sslPools) > 0
        for i = 0 to array.size(sslPools) - 1
            LiqPool p = array.get(sslPools, i)
            if not p.swept and p.price < close and (na(slLvl) or p.price > slLvl)
                slLvl := p.price
                slTxt := "SSL"
    if array.size(eqlPools) > 0
        for i = 0 to array.size(eqlPools) - 1
            LiqPool p = array.get(eqlPools, i)
            if not p.swept and p.price < close and (na(slLvl) or p.price > slLvl)
                slLvl := p.price
                slTxt := "EQL"
    if na(slLvl) and not na(oteLvlBot) and oteLvlBot < close
        slLvl := oteLvlBot
        slTxt := "OTE"
    if na(slLvl) and not na(extS.activeLowPrice) and extS.activeLowPrice < close
        slLvl := extS.activeLowPrice
        slTxt := "HL"
else if extS.trend == -1
    if array.size(bslPools) > 0
        for i = 0 to array.size(bslPools) - 1
            LiqPool p = array.get(bslPools, i)
            if not p.swept and p.price > close and (na(slLvl) or p.price < slLvl)
                slLvl := p.price
                slTxt := "BSL"
    if array.size(eqhPools) > 0
        for i = 0 to array.size(eqhPools) - 1
            LiqPool p = array.get(eqhPools, i)
            if not p.swept and p.price > close and (na(slLvl) or p.price < slLvl)
                slLvl := p.price
                slTxt := "EQH"
    if na(slLvl) and not na(oteLvlTop) and oteLvlTop > close
        slLvl := oteLvlTop
        slTxt := "OTE"
    if na(slLvl) and not na(extS.activeHighPrice) and extS.activeHighPrice > close
        slLvl := extS.activeHighPrice
        slTxt := "LH"

bool sltpOK = showSLTPZones and extS.trend != 0 and not na(tgt) and not na(slLvl) and math.abs(tgt - close) > syminfo.mintick and math.abs(slLvl - close) > syminfo.mintick and tgt != slLvl

if sltpOK
    int zLeft = math.max(bar_index - sltpWidth, 0)
    int zRight = bar_index + 1
    float tpTop = math.max(close, tgt)
    float tpBot = math.min(close, tgt)
    float slTop = math.max(close, slLvl)
    float slBot = math.min(close, slLvl)
    if na(tpZoneBox)
        tpZoneBox := box.new(zLeft, tpTop, zRight, tpBot, xloc=xloc.bar_index, border_color=color.new(tpZoneColor, 45), border_width=1, bgcolor=color.new(tpZoneColor, sltpTransp))
    else
        box.set_lefttop(tpZoneBox, zLeft, tpTop)
        box.set_rightbottom(tpZoneBox, zRight, tpBot)
        box.set_bgcolor(tpZoneBox, color.new(tpZoneColor, sltpTransp))
    if na(slZoneBox)
        slZoneBox := box.new(zLeft, slTop, zRight, slBot, xloc=xloc.bar_index, border_color=color.new(slZoneColor, 45), border_width=1, bgcolor=color.new(slZoneColor, sltpTransp))
    else
        box.set_lefttop(slZoneBox, zLeft, slTop)
        box.set_rightbottom(slZoneBox, zRight, slBot)
        box.set_bgcolor(slZoneBox, color.new(slZoneColor, sltpTransp))
    sltpText := "TP " + str.tostring(tgt, format.mintick) + "  •  SL " + str.tostring(slLvl, format.mintick)
    sltpCol := extS.trend == 1 ? tpZoneColor : tpZoneColor
    if showSLTPLabels
        string tpLblTxt = "TP 🎯 " + tgtTxt + " " + str.tostring(tgt, format.mintick)
        string slLblTxt = "SL ✕ " + (str.length(slTxt) > 0 ? slTxt + " " : "") + str.tostring(slLvl, format.mintick)
        if na(tpZoneLbl)
            tpZoneLbl := f_tag(zRight, tgt, tpLblTxt, tpZoneColor, eventTextSize)
        else
            f_tag_update(tpZoneLbl, zRight, tgt, tpLblTxt)
        if na(slZoneLbl)
            slZoneLbl := f_tag(zRight, slLvl, slLblTxt, slZoneColor, eventTextSize)
        else
            f_tag_update(slZoneLbl, zRight, slLvl, slLblTxt)
    else
        if not na(tpZoneLbl)
            label.delete(tpZoneLbl)
            tpZoneLbl := na
        if not na(slZoneLbl)
            label.delete(slZoneLbl)
            slZoneLbl := na
else
    if not na(tpZoneBox)
        box.delete(tpZoneBox)
        tpZoneBox := na
    if not na(slZoneBox)
        box.delete(slZoneBox)
        slZoneBox := na
    if not na(tpZoneLbl)
        label.delete(tpZoneLbl)
        tpZoneLbl := na
    if not na(slZoneLbl)
        label.delete(slZoneLbl)
        slZoneLbl := na
    sltpText := "—"
    sltpCol := na
'''
src = src.replace(ANCHOR_TGT, SLTP_BLOCK, 1)

# ─────────────────────────────────────────────────────────────
# 6. Panneau : titre v5 + ligne « TP / SL » + marge de lignes
# ─────────────────────────────────────────────────────────────
assert src.count('f_pad("WAVESCOPE ICT v4")') == 1
src = src.replace('f_pad("WAVESCOPE ICT v4")', 'f_pad("WAVESCOPE ICT v5")', 1)

ANCHOR_ROW = '''        table.cell(statusPanel, 0, r, f_pad("Cible"), text_color=mutedText, bgcolor=panelBackground, text_size=f_text_size(sz), text_halign=text.align_left)
        table.cell(statusPanel, 1, r, f_pad(targetText), text_color=levelColor, bgcolor=panelBackground, text_size=f_text_size(sz), text_halign=text.align_right)
        r += 1
'''
assert src.count(ANCHOR_ROW) == 1
TPSL_ROW = ANCHOR_ROW + '''        table.cell(statusPanel, 0, r, f_pad("TP / SL"), text_color=mutedText, bgcolor=panelBackground, text_size=f_text_size(sz), text_halign=text.align_left)
        table.cell(statusPanel, 1, r, f_pad(sltpText), text_color=na(sltpCol) ? mutedText : sltpCol, bgcolor=panelBackground, text_size=f_text_size(sz), text_halign=text.align_right)
        r += 1
'''
src = src.replace(ANCHOR_ROW, TPSL_ROW, 1)

# marge : 26 → 30 lignes de tableau (nouvelle ligne TP/SL + entrée légende)
assert src.count('table.new(f_panel_pos(panelPositionInput), 2, 26,') == 1
src = src.replace('table.new(f_panel_pos(panelPositionInput), 2, 26,',
                  'table.new(f_panel_pos(panelPositionInput), 2, 30,', 1)

# entrée de légende pour les zones SL/TP
ANCHOR_LEG = '''            table.cell(statusPanel, 0, r, f_pad("●"), text_color=trapColor, bgcolor=panelBackground, text_size=f_text_size(sz))
            table.cell(statusPanel, 1, r, f_pad("Pièges retail — stop hunts (jaune)"), text_color=mutedText, bgcolor=panelBackground, text_size=f_text_size(sz), text_halign=text.align_left)
            r += 1
'''
assert src.count(ANCHOR_LEG) == 1
LEG_ROW = ANCHOR_LEG + '''            table.cell(statusPanel, 0, r, f_pad("●"), text_color=slZoneColor, bgcolor=panelBackground, text_size=f_text_size(sz))
            table.cell(statusPanel, 1, r, f_pad("Zones SL ✕ (rouge) / TP 🎯 (vert) — v5"), text_color=mutedText, bgcolor=panelBackground, text_size=f_text_size(sz), text_halign=text.align_left)
            r += 1
            table.cell(statusPanel, 0, r, f_pad("●"), text_color=tpZoneColor, bgcolor=panelBackground, text_size=f_text_size(sz))
            table.cell(statusPanel, 1, r, f_pad("Zone Take Profit (fond vert)"), text_color=mutedText, bgcolor=panelBackground, text_size=f_text_size(sz), text_halign=text.align_left)
            r += 1
'''
src = src.replace(ANCHOR_LEG, LEG_ROW, 1)

DST.write_text(src, encoding='utf-8')

# ─────────────────────────────────────────────────────────────
# VALIDATIONS
# ─────────────────────────────────────────────────────────────
out = DST.read_text(encoding='utf-8')
errors = []

# a) plus aucun input sans titre
untitled = re.findall(r'^\w+\s*=\s*input\.(?:color|int|float)\([^,]+,\s*""', out, re.M)
if untitled:
    errors.append(f'inputs sans titre restants : {len(untitled)}')

# b) titres uniques (clés d'override piner)
titles = re.findall(r'^\w+\s*=\s*input\.(?:color|int|float|bool|string|session)\([^,]+,\s*"([^"]+)"', out, re.M)
dupes = {t for t in titles if titles.count(t) > 1}
if dupes:
    errors.append(f'titres dupliqués : {dupes}')

# c) guillemets équilibrés par ligne
for i, l in enumerate(out.split('\n'), 1):
    if l.strip().startswith('//'):
        continue
    if l.count('"') % 2 != 0:
        errors.append(f'ligne {i} : guillemets non équilibrés')

# d) marqueurs v5 présents
for marker in ['WAVESCOPE ICT v5', 'showSLTPZones', 'tpZoneBox', 'slZoneBox', 'f_pad("TP / SL")',
               'Couleur haussière (ZigZag)', 'Zones SL / TP en arrière-plan', 'sltpWidth']:
    if marker not in out:
        errors.append(f'marqueur absent : {marker}')

# e) la richesse v4 est intacte
for marker in ['zzDepth', 'zzDeviation', 'zzBackstep', 'PIÈGE RETAIL', 'TENDANCE À SUIVRE',
               'f_update_developing', 'showInternal', 'showMitigation', 'showBreaker',
               'maxLiquidity', 'fvgMaxCount', 'obMaxCount']:
    if marker not in out:
        errors.append(f'richesse v4 perdue : {marker}')

# f) nombre de lignes
n = len(out.split('\n'))
print(f"✓ wavescope_ict_v5.pine écrit : {n} lignes, {len(out)} octets")
print(f"  inputs titrés : {len(titles)} (tous uniques : {not dupes})")

if errors:
    print('\n✗ ERREURS :')
    for e in errors:
        print('  -', e)
    sys.exit(1)
print('✓ Toutes les validations passent.')
