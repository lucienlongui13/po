/**
 * test-pine-alignment.ts — v1.8 regression suite.
 *
 * Guards the three root causes fixed in v1.8:
 *  1. `syminfo.mintick` must NEVER run at Piner's 0.01 default on FX-sized
 *     symbols → deriveMintick() + runPineScript auto-derivation. The historic
 *     bug: Market-Structure labels floated 10–30 cents away from the candles.
 *  2. Overlay-script drawings must stay glued to the candle price range
 *     (alignment invariant measured on the real 2242-bar dataset).
 *  3. alert()/alertcondition() events must surface with a resolvable bar time
 *     when the script's alert inputs are enabled.
 */
import { runPineScript, deriveMintick, type PineExecutionResult } from '../src/lib/pine-engine'
import { importLibraryBundle } from '../src/lib/pine-libraries'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'

let PASS = 0, FAIL = 0
const ok = (name: string, cond: boolean, extra = '') => {
  if (cond) { PASS++; console.log(`  ✓ ${name}`) }
  else { FAIL++; console.log(`  ✗ ${name}${extra ? ` — ${extra}` : ''}`) }
}

const LIB_DIR = 'upload/piracy_extracted/Market_structures_scripts'
const MAIN_SRC = readFileSync(join(LIB_DIR, 'Main.pine'), 'utf8')

// ── synthetic datasets per asset class ──────────────────────────────
function makeFx(count: number, base = 1.15803, tick = 0.00001) {
  const out = []
  let price = base
  for (let i = 0; i < count; i++) {
    price += (Math.round((Math.sin(i / 3) * 40 + Math.cos(i / 11) * 25)) * tick) * 8
    const o = price, c = price + Math.round(Math.sin(i / 2) * 30) * tick * 4
    out.push({
      time: 1789439220 + i * 60,
      open: o, high: Math.max(o, c) + 12 * tick, low: Math.min(o, c) - 9 * tick, close: c,
      volume: 100 + i,
    })
  }
  return out
}

function makeJpy(count: number) {
  const out = []
  let price = 150.123
  for (let i = 0; i < count; i++) {
    price += Math.round(Math.sin(i / 4) * 30) * 0.001 * 6
    const o = price, c = price + Math.round(Math.cos(i / 3) * 20) * 0.001 * 4
    out.push({
      time: 1789439220 + i * 60,
      open: o, high: Math.max(o, c) + 0.004, low: Math.min(o, c) - 0.003, close: c,
      volume: 100 + i,
    })
  }
  return out
}

function makeGold(count: number) {
  const out = []
  let price = 2400.12
  for (let i = 0; i < count; i++) {
    price += Math.round(Math.sin(i / 5) * 20) * 0.01 * 5
    const o = price, c = price + Math.round(Math.cos(i / 4) * 15) * 0.01 * 4
    out.push({
      time: 1789439220 + i * 60,
      open: o, high: Math.max(o, c) + 0.09, low: Math.min(o, c) - 0.07, close: c,
      volume: 100 + i,
    })
  }
  return out
}

async function main() {
  console.log('── 1. deriveMintick per asset class ──')
  const fx = makeFx(400)
  const jpy = makeJpy(400)
  const gold = makeGold(400)
  const mt = deriveMintick(fx as any)
  ok(`FX 5-digit → 1e-5 (got ${mt})`, mt != null && mt >= 1e-5 && mt < 1e-4)
  const mtJpy = deriveMintick(jpy as any)
  ok(`JPY 3-digit → 0.001 (got ${mtJpy})`, mtJpy != null && mtJpy >= 0.001 && mtJpy < 0.01)
  const mtGold = deriveMintick(gold as any)
  ok(`XAU 2-digit → 0.01 (got ${mtGold})`, mtGold != null && mtGold >= 0.01 && mtGold < 0.1)
  ok('short dataset → undefined (no wrong guess)', deriveMintick(fx.slice(0, 2) as any) === undefined)

  console.log('── 2. runPineScript auto-derives mintick (alignment invariant) ──')
  // Real dataset: 2242 M1 EURUSD_otc candles (campaign capture)
  const raw = JSON.parse(readFileSync('scripts/dataset-eurusd-m1.json', 'utf8')) as any[]
  const dataset = (Array.isArray(raw) ? raw : raw.candles ?? raw.data ?? []).map((c: any) => ({
    time: Number(c.time) * (Number(c.time) > 1e12 ? 1 : 1),
    open: Number(c.open), high: Number(c.high), low: Number(c.low), close: Number(c.close),
    volume: Number(c.volume ?? 0),
  }))
  ok(`dataset loaded (${dataset.length} bars)`, dataset.length > 1000)

  importLibraryBundle([
    { name: 'libs/PubLibCandleTrend.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibCandleTrend.pine'), 'utf8') },
    { name: 'libs/PubLibSwing.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibSwing.pine'), 'utf8') },
    { name: 'libs/PubLibTrend.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibTrend.pine'), 'utf8') },
    { name: 'libs/PubLibUtility.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibUtility.pine'), 'utf8') },
    { name: 'Main.pine', source: MAIN_SRC },
  ])

  // 2a. WITHOUT explicit mintick — the engine must derive it itself (v1.8 fix)
  const resAuto = await runPineScript(MAIN_SRC, dataset as any, { symbol: 'EURUSD_otc', timeframe: '1' })
  ok('Main.pine executes (auto mintick)', resAuto.ok, resAuto.ok ? '' : JSON.stringify(resAuto.error).slice(0, 200))
  if (resAuto.ok) {
    const r = resAuto.result
    const prices: number[] = []
    for (const d of r.drawings) {
      if (d.kind === 'line') prices.push(d.y1, d.y2)
      else if (d.kind === 'label' && d.y != null) prices.push(d.y)
      else if (d.kind === 'box') prices.push(d.top, d.bottom)
    }
    const minLow = Math.min(...dataset.map(c => c.low))
    const maxHigh = Math.max(...dataset.map(c => c.high))
    const dMin = Math.min(...prices), dMax = Math.max(...prices)
    // the invariant: drawings hug the candles (ATR-scaled offsets, ≤ 1 % of price)
    const tolerance = (maxHigh - minLow) * 3 + maxHigh * 0.01
    ok(
      `drawings glued to candles: [${dMin.toFixed(5)}, ${dMax.toFixed(5)}] vs candles [${minLow.toFixed(5)}, ${maxHigh.toFixed(5)}]`,
      dMin >= minLow - tolerance && dMax <= maxHigh + tolerance,
    )
    // the historic bug produced offsets of exactly ±0.1×n — assert they're gone
    const badOffset = prices.some(p => Math.abs(p - 1.1575) >= 0.05 && Math.abs(Math.abs(p - 1.1575) % 0.1) < 1e-9)
    ok('no 0.1-mintick-default offsets (historic bug absent)', !badOffset)
    ok(`drawings produced (${r.drawings.length})`, r.drawings.length > 50)
  }

  // 2b. explicit mintick still wins
  const resExplicit = await runPineScript(MAIN_SRC, dataset as any, { symbol: 'EURUSD_otc', timeframe: '1', mintick: 0.00001 })
  ok('explicit mintick path still works', resExplicit.ok)

  console.log('── 3. Alerts surface with resolvable times ──')
  // enable the six alert bool inputs by title (piner input keys)
  const alertInputs: Record<string, boolean> = {
    'BOS Up Alert': true, 'BOS Down Alert': true,
    'CHoCH Up Alert': true, 'CHoCH Down Alert': true,
    'CISD Up Alert': true, 'CISD Down Alert': true,
  }
  const resAlerts = await runPineScript(MAIN_SRC, dataset.slice(-600) as any, {
    symbol: 'EURUSD_otc', timeframe: '1', inputs: alertInputs,
  })
  ok('executes with alert inputs ON', resAlerts.ok)
  if (resAlerts.ok) {
    const alerts = resAlerts.result.alerts
    ok(`alert events collected (${alerts.length})`, alerts.length > 0)
    ok('every alert carries a resolvable bar time',
      alerts.length > 0 && alerts.every(a => a.time != null && a.time > 1.7e12))
    ok('alert messages non-empty', alerts.every(a => a.message.length > 0))
    const times = resAlerts.result._times
    ok('alert times map into the dataset window',
      alerts.every(a => a.time! >= times[0] - 1 && a.time! <= times[times.length - 1] + 1))
  }

  console.log('── 4. Non-overlay script normalization (pane routing inputs) ──')
  const rsiSrc = `//@version=6
indicator("RSI pane probe", overlay=false)
r = ta.rsi(close, 14)
plot(r, "RSI", color=color.purple)
hline(30, "OS")
hline(70, "OB")
`
  const resRsi = await runPineScript(rsiSrc, dataset as any, { symbol: 'EURUSD_otc', timeframe: '1' })
  ok('RSI script executes', resRsi.ok)
  if (resRsi.ok) {
    const r: PineExecutionResult = resRsi.result
    ok('overlay=false detected', r.overlay === false)
    ok('plots present', r.plots.length === 1)
    ok('hlines present (30/70)', r.hlines.length === 2 && r.hlines.some(h => h.price === 30) && r.hlines.some(h => h.price === 70))
    ok('plot data aligned to _times', r.plots[0].data.length === r._times?.length)
  }

  console.log('── 5. Float-condition coercion (piner patch) ──')
  // theEccentricTrader pattern scripts pass swing PRICES (float/na) as
  // ta.valuewhen conditions — Pine coerces na→false. Before the v1.8
  // patch-package fix, piner treated the na OBJECT as truthy and every
  // pattern script silently produced zero output.
  const coerceSrc = `//@version=6
indicator("coerce probe", overlay=true)
raw = close[1] > open[1] and close < open ? high : na
t1 = raw ? 1 : 0
vw = ta.valuewhen(raw, raw, 0)
bs = ta.barssince(raw)
label.new(bar_index, high, str.tostring(t1) + "|" + str.tostring(vw) + "|" + str.tostring(bs), style=label.style_label_down)
`
  const coerceRes = await runPineScript(coerceSrc, fx as any, { symbol: 'EURUSD_otc', timeframe: '1' })
  ok('coercion probe executes', coerceRes.ok)
  if (coerceRes.ok) {
    // fx dataset: bars move by sin patterns — down-bars after up-bars exist
    const labels = coerceRes.result.drawings.filter((d) => d.kind === 'label') as Array<{ text: string }>
    const parsed = labels.map((l) => l.text.split('|'))
    const t1s = parsed.map((p) => Number(p[0]))
    const vws = parsed.map((p) => Number(p[1]))
    const bss = parsed.map((p) => Number(p[2]))
    ok('ternary coerces float condition (0/1 only)', t1s.every((v) => v === 0 || v === 1))
    const swingBars = t1s.filter((v) => v === 1).length
    ok(`swing bars detected (${swingBars})`, swingBars > 3)
    // THE FIX: valuewhen must persist the last swing price on non-swing bars
    const nonSwingVw = vws.filter((v, i) => t1s[i] === 0)
    ok('valuewhen persists last swing price on na-condition bars (patch applied)',
      nonSwingVw.length > 0 && nonSwingVw.every((v) => Number.isFinite(v) && v > 0),
      `got: ${nonSwingVw.slice(0, 4).join(',')}`)
    // barssince must count from the last swing bar (finite on later bars)
    const tailBs = bss.slice(-6)
    ok('barssince counts bars since last swing (finite)', tailBs.every((v) => Number.isFinite(v)))
  }

  // pattern scripts (theEccentricTrader family) must produce output now
  const patternSrc = readFileSync('TradingView_pine_scripts_samples/pattern_2.pine', 'utf8')
  const patternRes = await runPineScript(patternSrc, dataset as any, { symbol: 'EURUSD_otc', timeframe: '1' })
  ok('pattern_2 (Double Top) produces drawings', patternRes.ok && patternRes.result.drawings.length > 0,
    patternRes.ok ? `${patternRes.result.drawings.length} drawings` : JSON.stringify(patternRes.error).slice(0, 120))
  if (patternRes.ok) {
    ok('pattern_2 alerts fire (alert() with float-gated conditions)',
      patternRes.result.alerts.length > 0, `${patternRes.result.alerts.length} alerts`)
  }

  console.log(`\n════ test-pine-alignment : ${PASS} ✓ · ${FAIL} ✗ ════`)
  if (FAIL > 0) process.exit(1)
}

main().catch((e) => { console.error('SUITE FAILURE', e); process.exit(1) })
