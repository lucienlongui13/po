/**
 * heal-caches.ts — Auto-guérison des caches 90 j contaminés.
 *
 * Applique purgePriceOutliers() aux fichiers candles_*.json existants et
 * réécrit les fichiers propres sur disque. Utilisé :
 *   1. pour nettoyer les caches du sandbox (validation sur données réelles) ;
 *   2. comme documentation du mécanisme (en production, la purge est
 *      AUTOMATIQUE au chargement — initializeCandleHistoryCache).
 */
import { readFileSync, writeFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { CandleHistoryCache } from '../mini-services/iqoption-backend/candle-history-cache'

const dir = join(process.cwd(), 'mini-services/iqoption-backend/candle-cache')
const files = readdirSync(dir).filter((f) => f.startsWith('candles_') && f.endsWith('.json'))

let totalPurged = 0
for (const f of files) {
  const m = f.match(/^candles_(.+)_S(\d+)\.json$/)
  if (!m) continue
  const period = Number(m[2])
  // L'actif authentique vit DANS le fichier (le nom de fichier le sanitize,
  // ex. #TSLA_otc → _TSLA_otc — comme en production).
  let asset: string | null = null
  try {
    asset = JSON.parse(readFileSync(join(dir, f), 'utf-8')).asset ?? null
  } catch { asset = null }
  if (!asset) { console.log(`∅ ${f} — illisible/vide`); continue }
  const cache = new CandleHistoryCache(asset, period, dir)
  if (!cache.load()) { console.log(`∅ ${f} — illisible/vide`); continue }
  const before = cache.size()
  const purged = cache.purgePriceOutliers()
  if (purged > 0) {
    cache.save(true)
    console.log(`🧹 ${f}: ${purged}/${before} bougies contaminantes PURGÉES → ${cache.size()} bougies saines`)
  } else {
    console.log(`✓ ${f}: propre (${before} bougies)`)
  }
  totalPurged += purged
}
console.log(`\nTOTAL: ${totalPurged} bougies contaminantes supprimées sur ${files.length} fichiers`)
