/**
 * try-ws-demo-refill.mjs — tente le refill du solde DÉMO via événements
 * WebSocket Pocket Option (candidats connus du protocole reverse-engineered).
 */
import sdkModule from '../mini-services/iqoption-backend/pocket-option-sdk/src/index.js';
const { PocketOptionClient } = sdkModule;

const EMAIL = 'longuilcn@gmail.com';
const PASSWORD = 'Jean-Paul@#1964';

async function main() {
  const client = new PocketOptionClient({
    credentials: { email: EMAIL, password: PASSWORD },
    mode: 'demo',
    region: 'eu',
    debug: false,
    authTimeout: 30000,
  });
  client.on('balance', (b) => console.log('[balance]', JSON.stringify({ isDemo: b.isDemo, balance: b.balance })));

  const session = await client.connect();
  console.log('connecté, uid=', session.uid, 'demoBalance=', session.demoBalance, session.currency);

  const transport = client.transport;
  if (!transport || typeof transport.send !== 'function') {
    console.log('transport inaccessible');
    process.exit(1);
  }

  // Candidats d'events de refill démo (protocole PO reverse-engineered)
  const candidates = [
    ['demo_balance_reset', {}],
    ['resetDemoBalance', {}],
    ['changeDemoBalance', { balance: 10000 }],
    ['demoReset', { balance: 10000 }],
    ['successupdateDemoBalance', { balance: 10000 }],
  ];
  for (const [ev, payload] of candidates) {
    try {
      transport.send(ev, payload);
      console.log('envoyé:', ev);
    } catch (e) {
      console.log('échec envoi:', ev, e.message);
    }
    await new Promise(r => setTimeout(r, 2500));
  }

  // Vérifie le solde après les tentatives
  const balances = client.account?.getBalances?.();
  console.log('balances finales:', JSON.stringify(balances ?? null));
  try { client.destroy(); } catch { /* ignore */ }
  process.exit(0);
}

main().catch(e => { console.error('FATAL:', e.message); process.exit(1); });
