/**
 * test-v22-candles-validation.ts — v22 : Candles Validation + Ninja ProTrader.
 * ============================================================================
 *
 * 1. CANDLES VALIDATION (règle par combinaison, ex. « RGRR ») :
 *    - sanitize : R/G uniquement, majuscules, max 5 caractères ;
 *    - sémantique : lue de la bougie CLÔTURÉE la plus récente à la plus
 *      ancienne (règle[0] = ancre) ; doji (close === open) = VERTE
 *      (gc = close >= open, même rendu que lightweight-charts) ;
 *    - L_Lucien ProTrader (signal à la clôture) : l'ancre EST la bougie
 *      signalée (dernière du tableau) ;
 *    - Ninja ProTrader (signal avant clôture) : le dernier élément du
 *      tableau est la bougie EN FORMATION → l'ancre est la bougie CLÔTURÉE
 *      précédente (validationSkipForming) ;
 *    - règle plus longue que l'historique → refus explicite ;
 *    - règle vide = aucune validation ;
 *    - refus → HOLD avec reason « REFUSÉ » + motifs (règle, bougies réelles).
 *
 * 2. NINJA PROTRADER (copie conforme de L_Lucien ProTrader) :
 *    - détection AVANT la clôture : l'événement BOS/CHoCH/CISD se déclenche
 *      sur la bougie EN FORMATION (prix temps réel) alors que la même
 *      bougie non clôturée est invisible pour L_Lucien ;
 *    - garde anti re-trade : UN ordre par bougie en formation ;
 *    - bougie en formation absente / incohérente → HOLD explicite.
 *
 * 3. STRATEGY TESTER (backtest) :
 *    - conversion expiration (s) → NOMBRE DE BOUGIES (TF courant) ;
 *    - libellé d'ordre : stratégie + combinaison + règle de validation.
 *
 * Exécution : npx tsx scripts/test-v22-candles-validation.ts
 */
import {
  evaluateBosChochCisdOrderRules,
  normalizeCandlesValidation,
  checkCandlesValidation,
  normalizeBosChochCisdOrderRules,
  computeBosChochCisd,
  type BosChochCisdCandle,
} from '../shared/bos-choch-cisd.js'
import {
  evaluateNinjaProTraderStrategy,
  markNinjaProTraderTraded,
  resetNinjaProTraderState,
} from '../mini-services/iqoption-backend/ninja-protrader-strategy.js'
import {
  evaluateBosChochCisdStrategy,
  markBosChochCisdTraded,
  resetBosChochCisdState,
} from '../mini-services/iqoption-backend/bos-choch-cisd-strategy.js'
import {
  expirySecondsToCandles,
  buildLucienBacktestOrderLabel,
} from '../src/lib/lucien-backtest.js'
import { ReplayEngine } from '../src/lib/replay-engine.js'

let pass = 0, fail = 0
function ok(cond: boolean, label: string, detail = ''): void {
  if (cond) { pass++; console.log(`  ✓ ${label}${detail ? ' — ' + detail : ''}`) }
  else { fail++; console.error(`  ✗ ${label}${detail ? ' — ' + detail : ''}`) }
}

/* ══════════════ helpers bougies ══════════════ */

let t = 1_700_000_000
const mk = (open: number, close: number, high: number, low: number) => {
  t += 60
  return { open, close, high, low, volume: 100, time: t }
}

/** Série structurelle dont la DERNIÈRE bougie est une cassure BOS Up + CISD Up
 * (reprise du fixture validé de test-bos-choch-cisd-strategy.ts). */
function buildBreakSeries(): BosChochCisdCandle[] {
  return [
    mk(10, 10.8, 11, 9.9),      // 0 verte
    mk(10.8, 10.2, 12, 10.1),   // 1 rouge → sh(1)=12
    mk(10.2, 10.9, 11.1, 10),   // 2 verte → sl(2)=10
    mk(10.9, 10.4, 11.2, 10.2), // 3 rouge → sh(3)=11.2
    mk(10.4, 10.6, 10.7, 10.3), // 4 verte → sl(4)=10.2 → uptrend
    mk(10.6, 12.5, 12.6, 10.5), // 5 verte : cassure 11.2 → BOS Up + CISD Up
  ]
}

async function main() {
  console.log('══ v22 — Candles Validation + Ninja ProTrader ══\n')

  /* ── 1. sanitize de la règle ── */
  console.log('[1] normalizeCandlesValidation — R/G, majuscules, max 5')
  {
    ok(normalizeCandlesValidation('') === '', 'vide → vide')
    ok(normalizeCandlesValidation(undefined) === '', 'undefined → vide')
    ok(normalizeCandlesValidation('RGRR') === 'RGRR', 'RGRR intact')
    ok(normalizeCandlesValidation('rgrr') === 'RGRR', 'minuscules → majuscules')
    ok(normalizeCandlesValidation('r g-r') === 'RGR', 'caractères invalides retirés (r g-r → RGR)')
    ok(normalizeCandlesValidation('RG%X2') === 'RG', 'chiffres/symboles retirés (RG%X2 → RG)')
    ok(normalizeCandlesValidation('RGRRGG') === 'RGRRG', 'tronquée à 5 (RGRRGG → RGRRG)')
    ok(normalizeCandlesValidation('123') === '', 'que des invalides → vide')
    ok(normalizeCandlesValidation('grg') === 'GRG', 'grg → GRG')
  }

  /* ── 2. sémantique de checkCandlesValidation ── */
  console.log('\n[2] checkCandlesValidation — ancre, ordre, doji, skipLast')
  {
    // Couleurs (du plus ancien au plus récent) : R, G, R, R, G
    const candles = [
      mk(10, 9.9, 10.1, 9.8),    // R
      mk(10, 10.4, 10.5, 9.9),   // G
      mk(10.4, 10.1, 10.5, 10),  // R
      mk(10.1, 10.0, 10.4, 9.9), // R
      mk(10.0, 10.6, 10.7, 9.9), // G  ← ancre (la plus récente clôturée)
    ]
    // Règle lue du plus récent au plus ancien : G(anchor), R, R, G
    ok(checkCandlesValidation(candles, 'GRRG').validated === true, 'GRRG validé (G,R,R,G du + récent au + ancien)',
      checkCandlesValidation(candles, 'GRRG').actual)
    ok(checkCandlesValidation(candles, 'RRRG').validated === false, 'RRRG refusé (l’ancre réelle est G)',
      `attendu RRRG / réel ${checkCandlesValidation(candles, 'RRRG').actual}`)
    ok(checkCandlesValidation(candles, 'GRR').validated === true, 'règle courte GRR (3 bougies) validée')
    ok(checkCandlesValidation(candles, '').validated === true, 'règle vide = aucune validation')
    // doji → G (gc = close >= open)
    const withDoji = [...candles, mk(10.5, 10.5, 10.8, 10.2)]
    ok(checkCandlesValidation(withDoji, 'DG'.replace('D', 'G')).validated === true && checkCandlesValidation(withDoji, 'R').validated === false,
      'doji (close === open) compte comme VERTE, jamais rouge')
    // skipLast : le dernier élément est la bougie EN FORMATION (jamais validée)
    const forming = mk(10.6, 11.0, 11.1, 10.5) // bougie en formation ( verte en cours)
    const closed = [...candles]                 // 5 bougies clôturées ci-dessus
    const all = [...closed, forming]
    // Sans skipLast : ancre = forming (G attendu). Avec skipLast : ancre = G(closed[4]) puis R,R
    ok(checkCandlesValidation(all, 'G', { skipLast: true }).validated === true,
      'skipLast ancre la DERNIÈRE BOUGIE CLÔTURÉE (G) — la formation est ignorée')
    ok(checkCandlesValidation(all, 'GRR', { skipLast: true }).validated === true,
      'skipLast : G,R,R sur les clôturées')
    // règle plus longue que l'historique
    const short = [mk(10, 10.2, 10.3, 9.9), mk(10.2, 10.1, 10.4, 10)]
    const tooLong = checkCandlesValidation(short, 'RGRRR')
    ok(tooLong.validated === false && tooLong.detail.includes('exige'), 'règle > historique → refus explicite', tooLong.detail)
  }

  /* ── 3. L_Lucien ProTrader — la bougie signalée EST l'ancre ── */
  console.log('\n[3] L_Lucien ProTrader — validation incluant la bougie signalée')
  {
    resetBosChochCisdState()
    const candles = buildBreakSeries()
    // Couleurs c0..c5 : G, R, G, R, G, G(signal) → validation [c5,c4,c3] = G,G,R
    const rules = (validation?: string) => ({
      callRules: [{ id: 'call-1', alerts: ['BOS Up' as const], expirationSeconds: 30, ...(validation ? { candlesValidation: validation } : {}) }],
      putRules: [],
    })
    const noVal = evaluateBosChochCisdOrderRules(candles, rules().callRules, rules().putRules, {})
    ok(noVal.action === 'CALL', 'sans validation → CALL (BOS Up sur la bougie signalée)')
    const ggr = evaluateBosChochCisdOrderRules(candles, rules('GGR').callRules, rules('GGR').putRules, {})
    ok(ggr.action === 'CALL' && ggr.matchedRuleValidation === 'GGR',
      'règle GGR (bougie signalée G, précédente G, avant R) → CALL', ggr.reason.slice(0, 110))
    ok(ggr.reason.includes('GGR ✓'), 'reason documente la validation appliquée')
    const bad = evaluateBosChochCisdOrderRules(candles, rules('RGRR').callRules, rules('RGRR').putRules, {})
    ok(bad.action === 'HOLD' && bad.reason.includes('REFUSÉ'),
      'règle RGRR (bougie signalée G ≠ R) → HOLD REFUSÉ', bad.reason.slice(0, 130))
    ok(bad.reason.includes('bougies réelles'), 'reason montre les couleurs réelles observées')
    // intégré via evaluateBosChochCisdStrategy (chemin backend)
    const viaStrategy = evaluateBosChochCisdStrategy(candles, 'EURUSD_otc', {}, rules('GGR'), {})
    ok(viaStrategy.action === 'CALL', 'chemin stratégie backend : GGR → CALL')
    const viaStrategyBad = evaluateBosChochCisdStrategy(candles, 'EURUSD_otc', {}, rules('RGR').callRules.length ? rules('RGR') : rules('RGR'), {})
    ok(viaStrategyBad.action === 'HOLD', 'chemin stratégie backend : RGR → HOLD')
    // normalize garde la validation
    const norm = normalizeBosChochCisdOrderRules(rules('rgr').callRules, [])
    ok(norm.callRules.length === 1 && norm.callRules[0].candlesValidation === 'RGR',
      'normalizeBosChochCisdOrderRules sanitise ET garde candlesValidation (rgr → RGR)')
    const normEmpty = normalizeBosChochCisdOrderRules([{ id: 'x', alerts: ['BOS Up'], expirationSeconds: 30 }], [])
    ok(normEmpty.callRules[0].candlesValidation === undefined, 'absence de validation → champ absent (rétro-compatible)')
  }

  /* ── 4. Ninja ProTrader — détection AVANT la clôture ── */
  console.log('\n[4] Ninja ProTrader — signal sur la bougie EN FORMATION')
  {
    resetNinjaProTraderState()
    resetBosChochCisdState()
    // Bougies CLÔTURÉES 0..4 (la cassure n'a PAS encore eu lieu) + bougie en
    // formation dont le prix courant (11.5) a DÉJÀ franchi le swing high 11.2.
    const closed = buildBreakSeries().slice(0, 5) // 0..4, dernières closes 10.6 < 11.2
    const forming = mk(10.6, 11.5, 11.6, 10.5)   // en formation, close temps réel 11.5 > 11.2
    const rules = {
      callRules: [{ id: 'call-ninja', alerts: ['BOS Up' as const], expirationSeconds: 30 }],
      putRules: [],
    }
    // L_Lucien sur les bougies clôturées seules : aucune cassure → HOLD.
    const lucien = evaluateBosChochCisdStrategy(closed, 'EURUSD_otc', {}, rules, {})
    ok(lucien.action === 'HOLD', 'L_Lucien ne voit PAS la cassure (bougies clôturées seules) — HOLD')
    // Ninja : la bougie en formation casse le swing high → CALL AVANT clôture.
    const ninja = evaluateNinjaProTraderStrategy(closed, forming, 'EURUSD_otc', rules, {})
    ok(ninja.action === 'CALL', 'Ninja détecte la cassure AVANT la clôture → CALL', ninja.reason.slice(0, 110))
    ok(ninja.candleTime === forming.time, 'candleTime = bougie EN FORMATION (garde ninja)')
    ok(ninja.matchedRuleId === 'call-ninja', 'règle call-ninja appariée')
    ok(ninja.expirationSeconds === 30, 'expiration de la règle (30 s) reprise à l’identique')
    // Événements réels sur la bougie en formation
    const computed = computeBosChochCisd([...closed, forming])
    const firedOnForming = computed.events.filter((e) => e.barIndex === 5).map((e) => e.label)
    ok(firedOnForming.includes('BOS Up') && firedOnForming.includes('CISD Up'),
      'événements BOS Up + CISD Up sur la bougie en formation', firedOnForming.join(' + '))
    // Sans bougie en formation → HOLD explicite
    const noForming = evaluateNinjaProTraderStrategy(closed, null, 'EURUSD_otc', rules, {})
    ok(noForming.action === 'HOLD' && noForming.reason.includes('aucune bougie en formation'),
      'aucune bougie en formation → HOLD explicite')
    // Bougie en formation incohérente (temps <= dernière clôturée)
    const badForming = evaluateNinjaProTraderStrategy(closed, { ...closed[4] }, 'EURUSD_otc', rules, {})
    ok(badForming.action === 'HOLD' && badForming.reason.includes('incohérente'),
      'bougie en formation incohérente → HOLD explicite')
    // Garde anti re-trade : UN ordre par bougie en formation
    markNinjaProTraderTraded('EURUSD_otc', forming.time)
    const again = evaluateNinjaProTraderStrategy(closed, forming, 'EURUSD_otc', rules, {})
    ok(again.action === 'HOLD' && again.reason.includes('déjà tradée'),
      'garde ninja : la bougie en formation déjà tradée → HOLD')
    // Reset sélectif
    resetNinjaProTraderState('EURUSD_otc')
    const afterReset = evaluateNinjaProTraderStrategy(closed, forming, 'EURUSD_otc', rules, {})
    ok(afterReset.action === 'CALL', 'resetNinjaProTraderState(asset) ré-arme la bougie en formation')
    // Isolation par asset
    markNinjaProTraderTraded('EURUSD_otc', forming.time)
    const other = evaluateNinjaProTraderStrategy(closed, forming, 'GBPUSD_otc', rules, {})
    ok(other.action === 'CALL', 'garde ninja ISOLÉE par asset (GBPUSD indépendant)')
    resetNinjaProTraderState()
  }

  /* ── 5. Ninja + Candles Validation (ancre = dernière CLÔTURÉE) ── */
  console.log('\n[5] Ninja ProTrader — Candles Validation ancrée sur la dernière bougie clôturée')
  {
    resetNinjaProTraderState()
    const closed = buildBreakSeries().slice(0, 5) // couleurs G,R,G,R,G (c0..c4)
    const forming = mk(10.6, 11.5, 11.6, 10.5)   // verte, en formation
    const rules = (validation?: string) => ({
      callRules: [{ id: 'call-ninja', alerts: ['BOS Up' as const], expirationSeconds: 30, ...(validation ? { candlesValidation: validation } : {}) }],
      putRules: [],
    })
    // Ninja : ancre = c4 (G), puis c3 (R), c2 (G) → « GRG » validé.
    const good = evaluateNinjaProTraderStrategy(closed, forming, 'EURUSD_otc', rules('GRG'), {})
    ok(good.action === 'CALL' && good.matchedRuleValidation === 'GRG',
      'Ninja + GRG (c4=G, c3=R, c2=G — bougies CLÔTURÉES) → CALL', good.reason.slice(0, 120))
    ok(good.reason.includes('GRG ✓'), 'reason documente la validation ninja')
    // LA MÊME règle sur L_Lucien (bougie signalée c5 incluse) échoue : preuve
    // que les ancres diffèrent (L_Lucien valide c5,c4,c3 = G,G,R).
    const lucienSeries = buildBreakSeries() // 0..5 avec c5 signal
    const lucienSame = evaluateBosChochCisdOrderRules(lucienSeries, rules('GRG').callRules, rules('GRG').putRules, {})
    ok(lucienSame.action === 'HOLD' && lucienSame.reason.includes('REFUSÉ'),
      'contraste sémantique : la MÊME règle GRG est REFUSÉE par L_Lucien (ancre = bougie signalée G ≠ G... [G,G,R] ≠ G,R,G)',
      lucienSame.reason.slice(0, 130))
    // Règle impossible → HOLD
    const impossible = evaluateNinjaProTraderStrategy(closed, forming, 'EURUSD_otc', rules('RRRRR'), {})
    ok(impossible.action === 'HOLD' && impossible.reason.includes('REFUSÉ'),
      'règle impossible (RRRRR) → HOLD REFUSÉ')
    resetNinjaProTraderState()
  }

  /* ── 6. Confirmation bougie précédente (v19) reste compatible ── */
  console.log('\n[6] v19 « Confirmation bougie précédente » inchangée')
  {
    const closed = buildBreakSeries().slice(0, 5)
    const forming = mk(10.6, 11.5, 11.6, 10.5)
    const rules = {
      callRules: [{ id: 'call-ninja', alerts: ['BOS Up' as const], expirationSeconds: 30 }],
      putRules: [],
    }
    // c4 (dernière clôturée avant la formation) est VERTE → un CALL exige
    // une bougie baissière → refus.
    const refused = evaluateNinjaProTraderStrategy(closed, forming, 'EURUSD_otc', rules, { confirmPreviousCandle: true })
    ok(refused.action === 'HOLD' && refused.reason.includes('confirmation de bougie'),
      'Ninja + confirmCandle ON : bougie clôturée précédente verte → CALL refusé', refused.reason.slice(0, 120))
  }

  /* ── 7. Strategy Tester — expiration en bougies + libellé ── */
  console.log('\n[7] Strategy Tester — expiration (s) → bougies + libellé d’ordre')
  {
    ok(expirySecondsToCandles(60, 30) === 2, '60 s sur S30 → 2 bougies')
    ok(expirySecondsToCandles(5, 5) === 1, '5 s sur S5 → 1 bougie')
    ok(expirySecondsToCandles(45, 30) === 2, '45 s sur S30 → 2 bougies (arrondi)')
    ok(expirySecondsToCandles(3, 60) === 1, '3 s sur M1 → 1 bougie (plancher)')
    ok(expirySecondsToCandles(300, 60) === 5, '300 s sur M1 → 5 bougies')
    // Libellé d'ordre (stratégie + combinaison + validation)
    const sig = evaluateBosChochCisdOrderRules(
      buildBreakSeries(),
      [{ id: 'call-1', alerts: ['BOS Up' as const], expirationSeconds: 60, candlesValidation: 'GGR' }],
      [],
      {},
    )
    const label = buildLucienBacktestOrderLabel(sig, [
      { id: 'call-1', alerts: ['BOS Up' as const], expirationSeconds: 60, candlesValidation: 'GGR' },
    ])
    ok(sig.action === 'CALL', 'signal CALL pour le libellé')
    ok(label.includes('L_Lucien ProTrader'), 'libellé porte la stratégie', label)
    ok(label.includes('call-1') && label.includes('BOS Up'), 'libellé porte la combinaison (id + alertes)')
    ok(label.includes('validation GGR'), 'libellé porte la règle de validation')
    const noRuleLabel = buildLucienBacktestOrderLabel({ ...sig, matchedRuleId: undefined }, [])
    ok(noRuleLabel.includes('—'), 'libellé sans règle appariée → « — » (jamais vide)')
    // ReplayEngine.placeSim porte le libellé sur l'ordre simulé
    const replay = new ReplayEngine()
    const series = buildBreakSeries().map((c) => ({ time: c.time, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume }))
    replay.start(series, series.length - 1, 1000)
    const sim = replay.placeSim('call', 1, 2, 92, label)
    ok(sim != null && sim.label === label, 'placeSim reporte le libellé sur l’ordre simulé')
    const manual = replay.placeSim('put', 1, 1, 92, 'Manuel · Order panel')
    ok(manual != null && (manual.label ?? '').includes('Manuel'), 'ordre manuel : libellé « Manuel · Order panel »')
    replay.stop()
  }

  /* ── 8. Registre des stratégies backend (source: index.ts) ── */
  console.log('\n[8] Sources backend — stratégie ninja enregistrée + libellés trade-opened')
  {
    const fs = await import('node:fs')
    const src = fs.readFileSync('mini-services/iqoption-backend/index.ts', 'utf8')
    ok(src.includes("{ id: 'ninja_protrader', name: 'Ninja ProTrader'"), 'AUTO_TRADE_STRATEGIES contient Ninja ProTrader')
    ok(src.includes('evaluateNinjaProTraderStrategy'), 'runStrategyIterationForAsset route vers le moteur Ninja')
    ok(src.includes('markNinjaProTraderTraded'), 'garde ninja branchée à l’acceptation du signal')
    ok(src.includes('resetNinjaProTraderState();'), 'reset ninja sur set-auto-strategy / set-auto-config')
    ok(src.includes("session.config.strategyId === 'ninja_protrader') ? 500 : 1000"), 'polling Ninja = 500 ms (avant clôture)')
    ok(src.includes('orderLabel'), 'libellé d’ordre construit (PatternTradeSignal.orderLabel)')
    ok((src.match(/label: patternSignal\?\.orderLabel/g) ?? []).length >= 1, 'trade-opened auto-trade porte le libellé')
    ok(src.includes("label: 'Manuel · Order panel'"), 'ordre manuel live : libellé présent')
    ok(src.includes('snapshot.formingCandle'), 'Ninja évalue la bougie en formation du snapshot')
    // Frontend
    const panel = fs.readFileSync('src/components/trading/auto-trade-panel.tsx', 'utf8')
    ok(panel.includes('Candles Validation'), 'panneau Auto Trade : champ « Candles Validation » par combinaison')
    ok(panel.includes("NINJA_PROTRADER_STRATEGY_ID = 'ninja_protrader'"), 'export NINJA_PROTRADER_STRATEGY_ID')
    const overlay = fs.readFileSync('src/components/trading/chart/trade-markers-overlay.tsx', 'utf8')
    ok(overlay.includes('p.label &&'), 'carte d’ordre sur le graphique rend le libellé')
    const backtest = fs.readFileSync('src/components/trading/chart/backtest-panel.tsx', 'utf8')
    ok(backtest.includes('lucienBacktester'), 'Strategy Tester : section stratégie auto L_Lucien ProTrader')
    ok(backtest.includes('o.label ?? \'—\''), 'table des trades : colonne Label')
  }

  console.log(`\n══ RÉSULTAT : ${pass}/${pass + fail} vérifications ${fail === 0 ? 'OK ✓' : 'ÉCHEC ✗'} ══`)
  if (fail > 0) process.exit(1)
}

main().catch((e) => {
  console.error('FATAL:', e)
  process.exit(1)
})
