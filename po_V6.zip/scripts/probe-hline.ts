import { compileAsync, Engine, ArrayFeed } from '@heyphat/piner'
const src = `
//@version=6
indicator("RSI probe", overlay=false)
r = ta.rsi(close, 14)
plot(r, "RSI", color=color.purple)
hline(30, "OS")
hline(70, "OB")
`
const bars = []
let p = 1.157
for (let i = 0; i < 100; i++) {
  const o = p; p += Math.sin(i / 7) * 0.0004
  bars.push({ time: 1789439220000 + i * 60000, open: o, high: Math.max(o, p) + 0.0001, low: Math.min(o, p) - 0.0001, close: p, volume: 10 })
}
const main = async () => {
const compiled: any = await compileAsync(src, { libraries: [], resolveLibrary: () => undefined })
const engine: any = new Engine(compiled, new ArrayFeed(bars) as any, undefined)
await engine.run({ symbol: 'EURUSD_otc', timeframe: '1' })
console.log('plots:', engine.outputs.plots.size, '| hlines:', JSON.stringify([...engine.outputs.hlines.values()].map((h: any) => ({ id: h.id, price: h.price }))))
console.log('candle prices: 1.156 … 1.158 — hlines at 30/70 would stretch the MAIN chart 2600x')

}
main().catch((e) => { console.error(e); process.exit(1) })
