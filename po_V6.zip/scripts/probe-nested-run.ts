/**
 * Full-run probe: execute the user's Main.pine (BOS/CHoCH/CISD) through the
 * piner Engine on the captured dataset, mirroring runPineScript's plumbing,
 * and count the visual outputs (labels, lines, alerts).
 */
import { compileAsync, Engine, ArrayFeed } from '@heyphat/piner'
import { readFileSync } from 'node:fs'

const base = '/home/z/my-project/upload/market_structures_extracted/Market_structures_scripts'
const main = readFileSync(`${base}/Main.pine`, 'utf8')
const swing = readFileSync(`${base}/libs/PubLibSwing.pine`, 'utf8')
const trend = readFileSync(`${base}/libs/PubLibTrend.pine`, 'utf8')
const utility = readFileSync(`${base}/libs/PubLibUtility.pine`, 'utf8')

const candleTrend = `//@version=6
library('PubLibCandleTrend')
export gc() => close >= open
export rc() => close < open
`

const registry = [
  { key: 'PiracyChecker/PubLibSwing/3', source: swing },
  { key: 'PiracyChecker/PubLibTrend/3', source: trend },
  { key: 'PiracyChecker/PubLibUtility/2', source: utility },
  { key: 'PiracyChecker/PubLibCandleTrend/2', source: candleTrend },
]

interface Candle { time: number; open: number; high: number; low: number; close: number; volume: number }
const raw = JSON.parse(readFileSync('/home/z/my-project/scripts/dataset-eurusd-m1.json', 'utf8'))
const candles: Candle[] = (raw.candles ?? raw).map((c: any) => ({
  time: Number(c.time) * 1000,
  open: Number(c.open), high: Number(c.high), low: Number(c.low), close: Number(c.close),
  volume: Number(c.volume) || 0,
}))
console.log('dataset candles:', candles.length)

async function run() {
  const compiled = await compileAsync(main, { libraries: registry })
  const feed = new ArrayFeed(candles)
  const engine = new Engine(compiled as any, feed as any)
  const t0 = Date.now()
  await engine.run({ symbol: 'EURUSD_otc', timeframe: '1' })
  console.log('run OK in', Date.now() - t0, 'ms')

  const outputs = (engine as any).outputs ?? {}
  const drawings = (engine as any).drawings ?? []
  const kinds: Record<string, number> = {}
  for (const d of drawings) kinds[d.type] = (kinds[d.type] ?? 0) + 1
  console.log('plots:', outputs.plots?.length ?? 0, '· markers:', outputs.markers?.length ?? 0, '· alerts:', outputs.alerts?.length ?? 0)
  console.log('drawings:', drawings.length, JSON.stringify(kinds))
  const alerts = outputs.alerts ?? []
  if (alerts.length) console.log('sample alert:', JSON.stringify(alerts[alerts.length - 1]).slice(0, 200))
}

run().catch((err) => console.log('RUN FAILED:', err?.message?.slice(0, 500)))
