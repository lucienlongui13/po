#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# E2E — Test complet du menu de Réglages + script WaveScope v5
# dans l'app Pine v6 Engine (le moteur piner exact de l'utilisateur).
# Tout se déroule en UNE commande car la plateforme tue les processus
# d'arrière-plan entre les appels d'outils.
# ═══════════════════════════════════════════════════════════════════
cd /home/z/my-project
SHOTS=scripts
step() { echo ""; echo "════════ $1 ════════"; }
shot() { agent-browser screenshot "$SHOTS/$1" >/dev/null 2>&1 && echo "📸 $1"; }

# ── 1. Backend ──
step "1. Démarrage du backend"
pkill -f backend-supervisor 2>/dev/null; pkill -f "tsx index.ts" 2>/dev/null; sleep 1
setsid nohup bash scripts/backend-supervisor.sh >> backend.log 2>&1 &
sleep 16
curl -s -m 3 http://localhost:3030/health && echo " ← backend OK" || { echo "✗ backend mort"; exit 1; }

# ── 2. Login ──
step "2. Connexion démo"
agent-browser reload >/dev/null 2>&1
sleep 6
agent-browser find role button click --name "Login with Pocket Option" >/dev/null 2>&1
sleep 16
agent-browser snapshot -i -c 2>/dev/null | head -8
if agent-browser snapshot -i -c 2>/dev/null | grep -q "PINE SCRIPT"; then
  echo "✓ App principale atteinte"
else
  echo "… écran intermédiaire — inspection"
  agent-browser snapshot -i -c 2>/dev/null | head -20
fi
shot v5_e2e_01_main_app.png

# ── 3. Ouvrir l'éditeur Pine ──
step "3. Ouverture de l'éditeur Pine"
agent-browser find role button click --name "PINE SCRIPT" >/dev/null 2>&1
sleep 3
if agent-browser snapshot -i -c 2>/dev/null | grep -qi "Pine Script"; then
  echo "✓ Éditeur ouvert"
else
  echo "… tentative via bouton flottant"
  agent-browser eval "document.querySelectorAll('button').forEach(b=>{if(b.textContent.includes('PINE SCRIPT'))b.click()})" >/dev/null 2>&1
  sleep 3
fi
shot v5_e2e_02_editor.png

# ── 4. Coller le script v5 dans le textarea (fetch depuis /public) ──
step "4. Chargement du script v5"
agent-browser eval "
(async () => {
  const src = await (await fetch('/wavescope_ict_v5.pine')).text();
  const ta = document.querySelector('textarea');
  if (!ta) return 'TEXTAREA INTROUVABLE';
  const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
  setter.call(ta, src);
  ta.dispatchEvent(new Event('input', { bubbles: true }));
  return 'SOURCE INJECTÉE: ' + src.length + ' caractères';
})()" 2>&1 | tail -1
sleep 2
shot v5_e2e_03_source.png

# ── 5. Exécuter ──
step "5. Exécution du script (Run)"
agent-browser eval "document.querySelectorAll('button').forEach(b=>{if(/^(Run|Add \/ Run)$/.test(b.textContent.trim()))b.click()})" >/dev/null 2>&1
sleep 14
echo "— Console de l'éditeur :"
agent-browser eval "
(() => {
  const blocks = [...document.querySelectorAll('div')].filter(d => d.className && String(d.className).includes && String(d.className).includes('font-semibold') && /drawing object/.test(d.textContent));
  return blocks.length ? blocks[0].textContent : 'PAS ENCORE DE RÉSULTAT';
})()" 2>&1 | tail -1
shot v5_e2e_04_run.png

# ── 6. Ouvrir le menu Réglages ──
step "6. Ouverture du menu Réglages"
agent-browser eval "document.querySelectorAll('button').forEach(b=>{if(b.textContent.includes('Réglages'))b.click()})" >/dev/null 2>&1
sleep 4
REGL=$(agent-browser eval "
(() => {
  const t = document.body.textContent;
  const m = t.match(/(\d+) paramètres/);
  return m ? 'PANNEAU OUVERT: ' + m[1] + ' paramètres' : 'PANNEAU ABSENT';
})()" 2>&1 | tail -1)
echo "$REGL"
shot v5_e2e_05_reglages.png
echo "— Groupes visibles :"
agent-browser eval "
(() => {
  const groups = [...document.querySelectorAll('div')].filter(d => d.textContent && /^[1-9]\./.test(d.textContent.trim()) && d.textContent.length < 90 && d.querySelector('span'));
  return groups.map(g => g.textContent.trim()).slice(0, 12).join(' | ');
})()" 2>&1 | tail -1

# ── 7. Vérifier le compteur de dessins AVANT/après toggle ──
step "7. Test d'un réglage : décocher le ZigZag"
COUNT_BEFORE=$(agent-browser eval "
(() => {
  const blocks = [...document.querySelectorAll('div')].filter(d => d.className && String(d.className).includes('font-semibold') && /drawing object/.test(d.textContent));
  const m = blocks[0] ? blocks[0].textContent.match(/(\d+) drawing object/) : null;
  return m ? m[1] : '0';
})()" 2>&1 | tail -1 | tr -d '"')
echo "Dessins avant : $COUNT_BEFORE"

# fermer le panneau réglages, puis rouvrir l'éditeur si besoin et décocher
agent-browser eval "
(() => {
  const inputs = [...document.querySelectorAll('input[type=checkbox]')];
  const target = inputs.find(cb => {
    const row = cb.closest('div');
    return row && row.textContent.includes('ZigZag : afficher');
  });
  if (target) { target.click(); return 'CHECKBOX ZIGZAG DÉCOCHÉE'; }
  return 'CHECKBOX INTROUVABLE';
})()" 2>&1 | tail -1
sleep 5
shot v5_e2e_06_zigzag_off.png

# fermer les panneaux pour relire la console de l'éditeur
agent-browser eval "
(() => {
  // ferme la modale Réglages (bouton X le plus haut z)
  const modals = [...document.querySelectorAll('div')].filter(d => d.className && String(d.className).includes('z-\\[75\\]'));
  if (modals.length) { const x = modals[0].querySelector('button[title], button'); if (x) x.click(); }
  return 'modale fermée';
})()" >/dev/null 2>&1
sleep 2
COUNT_AFTER=$(agent-browser eval "
(() => {
  const blocks = [...document.querySelectorAll('div')].filter(d => d.className && String(d.className).includes('font-semibold') && /drawing object/.test(d.textContent));
  const m = blocks[0] ? blocks[0].textContent.match(/(\d+) drawing object/) : null;
  return m ? m[1] : '0';
})()" 2>&1 | tail -1 | tr -d '"')
echo "Dessins après (ZigZag OFF) : $COUNT_AFTER"
if [ "$COUNT_BEFORE" != "$COUNT_AFTER" ] && [ "$COUNT_BEFORE" != "0" ]; then
  echo "✅✅✅ LE MENU DE RÉGLAGES FONCTIONNE : $COUNT_BEFORE → $COUNT_AFTER dessins"
else
  echo "⚠ vérification manuelle nécessaire (compteur inchangé)"
fi
shot v5_e2e_07_apres_toggle.png

# ── 8. Vérifier la persistance (localStorage) ──
step "8. Persistance des réglages"
agent-browser storage local get pine-scripts-v1 2>&1 | head -c 400; echo

echo ""
echo "══════════════════ RÉSULTAT E2E ══════════════════"
echo "Voir captures : scripts/v5_e2e_*.png"
