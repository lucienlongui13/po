#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v17.sh — Livraison v17 « État neutre Tie/Refund (P&L = 0) »
#
# Le besoin (message utilisateur) : « Lorsqu'une position se termine sans
# gain ni perte (P&L = 0$, statut Tie ou Refund), le programme l'interprète
# actuellement comme une perte et incrémente la mise suivante. Comportement
# attendu : 1. Gain → réinitialiser la mise au montant initial ;
# 2. Perte → incrémenter la mise selon le multiplicateur défini ;
# 3. Remboursement/Égalité (Push/Tie/P&L = 0) → conserver le niveau de mise
# courant pour l'ordre suivant. »
#
# Les correctifs v17 :
#   1. asset-contexts.ts — moteur de mises TROIS états : BettingOutcome
#      ('win' | 'loss' | 'push'), updateBettingAfterResult('push') = NO-OP
#      (l'index consecutiveLosses/fibIndex ne bouge PAS), applyDealResult
#      compte les pushes à part (ni wins ni losses) ;
#   2. classifySettledOutcome() — classification du règlement broker :
#      profit NET > 0 → win ; < 0 → loss ; = 0 avec signature de clôture
#      réelle (UUID/asset/closeTime) → push (Tie/Refund) ; les placeholders
#      dégradés (id 0, asset vide) restent hors chemin (inattribuables) ;
#   3. index.ts — deal_closed + watchdog de règlement : classification trois
#      états partout (chemin direct UUID, rattachement par empreinte, cache
#      broker), logs « TIE ⟲ (remboursé, mise conservée) », trade-closed
#      porte le champ `outcome`, stats W/L/T (pushes) exposées au panneau ;
#   4. Anti-ghost renforcé (WinWin) — un règlement SANS AUCUN horodatage
#      (openTime ET closeTime absents — signature du fantôme 5ed07a66 du
#      JSONL réel 2026-09-08) ne peut plus régler un pending par empreinte :
#      le marché driftant pouvait amener le prix courant sur l'ancre du
#      fantôme « 15 pips hors marché » → faux WIN. 4× 31/31 après fix.
#   5. Mock broker (tests) : outcomeScript accepte 'tie' (alias push/refund/
#      draw) — closePrice === openPrice, profit NET = 0, mise remboursée,
#      enveloppe successcloseOrder { profit: mise, deals: [deal NET 0] }.
#
# Validation (spéc. utilisateur, base 1$, ×2) :
#   - CAS 1 : O1 (1$) remboursé → O2 = 1$ (AU LIEU de 2$) ✓ E2E réel ;
#   - CAS 2 : O1 1$ perdu → O2 2$ perdu → O3 4$ remboursé → O4 = 4$
#     (MAINTENUE) → O4 perdu → O5 = 8$ ✓ E2E réel ;
#   - séquence E2E complète 1 → 1 → 2 → 4 → 4 → 8 (24/24) ;
#   - unitaire 46 ✓ : Fibonacci (fibIndex inchangé), isolation multi-assets,
#     compat booléenne, classifier, empreinte du Tie (close === open).
# Non-régression : streak 12 ✓ · expiry-martingale 39 ✓ · strategy 22 ✓ ·
# Partie A 29 ✓ · multi-assets 144 ✓ · bos-martingale-e2e 17/17 ·
# winwin-e2e 31/31 (×4) · bos-multi-e2e 20/20 · tsc root 0 · backend 3
# préexistantes v14 (fichiers non modifiés).
#
# Sortie : /home/z/my-project/download/pine_v6_engine_v17_tie_refund_neutral_state.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v17"
FOLDER=pine_v6_engine
OUT="$ROOT/download/pine_v6_engine_v17_tie_refund_neutral_state.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (structure identique au zip v16) ──────────────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude '.logs/' \
  --exclude '*.log' \
  --exclude 'winwinlogs.jsonl' \
  --exclude 'mini-services/iqoption-backend/data/backend-session.json' \
  --exclude 'mini-services/iqoption-backend/data/candle-cache/' \
  --exclude 'db/' \
  "$ROOT/pine_v6_engine/" "$STAGE/$FOLDER/"

# ── README de la version v17 ─────────────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.6-V17-TIE-REFUND-NEUTRAL-STATE.md" <<'EOF'
# Pine v6 Engine — v17 « État neutre Tie/Refund (P&L = 0) »

## Le problème que vous avez constaté

Quand une position se termine **sans gain ni perte** (P&L = 0 $ — statut
Tie ou Refund), le programme l'interprétait comme une **perte** et
incrémentait la mise suivante. Un trade neutre faisait donc avancer la
Martingale à tort.

## La spécification (implémentée à la lettre)

| Résultat du trade | Effet sur la suite de mises |
|---|---|
| **Gain (Win)** — P&L > 0 | Réinitialiser la mise au **montant initial** |
| **Perte (Loss)** — P&L < 0 | **Incrémenter** la mise selon le multiplicateur défini |
| **Remboursement/Égalité (Push/Tie)** — P&L = 0 | **Conserver le niveau de mise courant** pour l'ordre suivant — l'index de la suite de mises ne bouge PAS |

Exemple (base 1 $, multiplicateur ×2) :
`1 $ → LOSS → 2 $ → LOSS → 4 $ → TIE → 4 $ (maintenue) → LOSS → 8 $`.

## Les correctifs

1. **Moteur de mises trois états** (`asset-contexts.ts`) — nouveau type
   `BettingOutcome = 'win' | 'loss' | 'push'` :
   - `updateBettingAfterResult(ctx, 'push')` = **no-op** : ni
     `consecutiveLosses` ni `fibIndex` ne bougent (Martingale ET Fibonacci) ;
   - `applyDealResult()` compte les pushes à part (`stats.pushes`) — un
     Tie n'est **ni un win ni un loss** ; compatibilité conservée : les
     anciens appels booléens `true/false` restent win/loss.
2. **Classification du règlement broker** (`classifySettledOutcome`) :
   profit NET > 0 → `win` ; < 0 → `loss` ; **= 0 avec signature de clôture
   réelle** (UUID d'ouverture, asset ou closeTime — capture réelle
   2026-09-17 : `successcloseOrder.deals[0]` et le cache
   `updateClosedDeals` portent toujours ces champs) → `push`. Les
   placeholders dégradés (id 0, asset vide) restent `loss` côté logs et
   sont de toute façon inattribuables — ils n'atteignent jamais le moteur.
3. **Intégration complète** (`index.ts`) : les TROIS chemins de règlement
   (événement `deal_closed` direct par UUID, rattachement par empreinte,
   watchdog sur le cache broker) classifient en trois états ; les logs
   affichent `TIE ⟲ (remboursé, mise conservée)` ; l'événement
   `trade-closed` porte le champ `outcome` ; les stats du panneau Auto
   Trade exposent `pushes` (format `3W/2L/1T`).
4. **Anti-ghost renforcé (WinWin)** — un règlement sans AUCUN horodatage
   (signature exacte des deals fantômes du cache broker observés dans le
   JSONL réel : faux WIN +0.78 sans openTime/closeTime) ne peut plus régler
   un pending par empreinte. Avant ce durcissement, le marché driftant
   (+3 pips/15 s en RGG) finissait par traverser l'ancre « 15 pips hors
   marché » du fantôme → faux résultat WIN sur un ordre en vol (race
   préexistante, exhumée par la validation v17, 4× 31/31 après fix).
5. **Mock broker (tests)** : `outcomeScript` accepte `'tie'` (alias
   `'push'`/`'refund'`/`'draw'`) — `closePrice === openPrice` (égalité
   exacte), profit NET = 0, mise remboursée (retour total = mise).

## La preuve (E2E sur le VRAI backend + broker)

Cas de validation exigés, base 1 $, martingale ×2, S5, règles BOS 3 s
(`tests/test-martingale-tie-refund-e2e.mjs`, chemins réels
`successcloseOrder` avec UUID + profit NET) :

- **Cas 1 — remise à niveau simple** : Ordre 1 (1 $) → Remboursé (0 $) →
  **Ordre 2 = 1 $** (au lieu d'incrémenter à 2 $) ✓
- **Cas 2 — séquence progressive** : Ordre 1 (1 $) perdu → Ordre 2 (2 $)
  perdu → Ordre 3 (4 $) remboursé (0 $) → **Ordre 4 = 4 $ (maintenue)** →
  Ordre 4 perdu → **Ordre 5 = 8 $** ✓
- Séquence intégrale observée : **1 → 1 → 2 → 4 → 4 → 8** (24/24
  vérifications : P&L des Ties = 0, `outcome: 'push'`, streak jamais
  incrémenté par un Tie, stats 0W/3L/2T, expiration = règle 3 s, aucun
  règlement fantôme).

Tests unitaires (`scripts/test-martingale-tie-push.ts`, 46 ✓) :
classifier (profit > 0 / < 0 / = 0 réel / = 0 dégradé), Fibonacci
(fibIndex inchangé sur push), isolation multi-assets (un push EURUSD ne
touche jamais XAUUSD), rattachement par empreinte d'un Tie (close ===
open → direction cohérente), compatibilité booléenne des anciens appels.

## Comment re-vérifier vous-même

```bash
# 1. Installer et démarrer le backend
cd mini-services/iqoption-backend && npm install && npm run dev

# 2. Test unitaire trois états (46 vérifications)
cd ../.. && npx tsx scripts/test-martingale-tie-push.ts

# 3. Test E2E sur le VRAI backend + faux broker (24 vérifications)
cd mini-services/iqoption-backend && node tests/test-martingale-tie-refund-e2e.mjs
```

## Non-régression (toutes exécutées sur cette livraison)

| Test | Résultat |
|---|---|
| `scripts/test-martingale-streak.ts` | 12 ✓ / 0 ✗ |
| `scripts/test-bos-choch-cisd-expiry-martingale.ts` | 39 ✓ / 0 ✗ |
| `tests/test-bos-choch-cisd-strategy.ts` | 22 ✓ / 0 ✗ |
| `scripts/test-bos-choch-cisd.ts` Partie A | 29 ✓ / 0 ✗ (Partie B : pack Pine absent de l'environnement) |
| `tests/test-multi-assets.ts` | 144 OK / 0 échec |
| `tests/test-bos-choch-cisd-martingale-e2e.mjs` | 17/17 ✓ |
| `tests/test-winwin-e2e.mjs` | 31/31 ✓ (×4 exécutions consécutives) |
| `tests/test-bos-choch-cisd-multi-e2e.mjs` | 20/20 ✓ |
| `scripts/test-martingale-tie-push.ts` (NOUVEAU) | 46 ✓ / 0 ✗ |
| `tests/test-martingale-tie-refund-e2e.mjs` (NOUVEAU) | 24/24 ✓ |
| `tsc --noEmit` (root) | 0 erreur |
| `tsc --noEmit` (backend) | 3 erreurs préexistantes v14 (fichiers non modifiés) |
EOF

# ── Zippage ───────────────────────────────────────────────────────────────
cd "$STAGE"
zip -qr "$OUT" "$FOLDER"
cd "$ROOT"
rm -rf "$STAGE"

echo "─ Livraison v17 ─────────────────────────────────────────────"
echo "Zip      : $OUT"
echo "Taille   : $(du -h "$OUT" | cut -f1)"
echo "Fichiers : $(unzip -l "$OUT" | tail -1 | awk '{print $2}')"
echo "Intégrité: $(unzip -t "$OUT" > /dev/null && echo OK || echo ÉCHEC)"
