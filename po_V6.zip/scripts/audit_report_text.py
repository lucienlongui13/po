# -*- coding: utf-8 -*-
"""Corps de texte du rapport d'audit (français) — chapitres 1 à 10."""

CH1_INTRO = [
"""Ce rapport vérifie, règle par règle, la conformité du script Pine v6 « WaveScope — ICT / SMC Suite »
aux concepts ICT / Smart Money tels qu'ils sont définis dans le livre « The Market's Secret Language »
d'Akash Gul (202 pages, 9 chapitres). L'objectif de l'utilisateur étant une conformité « à la lettre »,
chaque règle détectable sur graphique a été extraite du livre, confrontée au code ligne par ligne, puis
classée en cinq verdicts : conforme, partiel, écart, manquant ou non applicable. Quarante et une règles
ont été évaluées, couvrant la structure de marché, la liquidité, les order blocks, les fair value gaps,
les zones premium / discount et les cibles.""",
"""Le verdict global est nuancé. Sur les 41 règles, la version originale du script en respecte 23 à la
lettre : la mécanique BOS / CHoCH est fidèle au livre, les pools BSL / SSL et la détection des sweeps
avec rejet sont exactes, la définition des FVG sur trois bougies est correcte, et surtout les order
blocks ne sont créés qu'aux événements structurels — un point que le livre présente comme la condition
numéro un de validité d'un OB. En revanche, un bug critique de robustesse (boucles non gardées sur des
tableaux vides, avec risque d'erreur « index out of bounds » à l'exécution) et neuf écarts ou absences
par rapport à la lettre du livre ont été identifiés : order blocks tracés sur les mèches au lieu du
corps, breaker block non conforme à la définition du livre, MSS posé sans déplacement, mitigation non
marquée au retest, zone OTE absente, blocs de mitigation absents, PDH / PDL absents, iFVG jamais
invalidés et confluences (sweep, FVG, volume) non notées.""",
"""La version 2 jointe à ce rapport corrige l'intégralité de ces points : les seize modifications
appliquées au script couvrent le bug critique, les trois défauts techniques secondaires et les neuf
écarts ou absences relevés. Après correction, 36 règles sur 41 sont respectées à la lettre ; les cinq
restantes sont documentées et hors du périmètre naturel d'un indicateur graphique : le raffinement
multi-unités de temps natif, le biais automatique lié à la localisation, le placement du stop-loss et
le ratio de risque relèvent de la couche « signaux et exécution » de l'application (Strategy Tester,
Auto Trade), et la bande d'équilibre autour du 50 % est conservée comme simple choix d'affichage
documenté. Les chapitres suivants détaillent chaque règle, chaque écart et chaque correction."""
]

CH2_INTRO = [
"""L'audit repose sur deux sources : le livre « The Market's Secret Language » d'Akash Gul, fourni au
format PDF (202 pages), et le script Pine « wavescope_ict.pine » (853 lignes, version 6). Le texte du
livre a été intégralement extrait puis lu chapitre par chapitre, avec une attention particulière aux
chapitres 2 à 8 qui contiennent les règles opérationnelles : phases AMD, structure de marché (BOS,
CHoCH, MSS), liquidité (BSL, SSL, IRL, ERL, equal highs / lows, sweeps et stop hunts), order blocks et
leurs variantes (breakers, blocs de mitigation, checklist de haute probabilité), fair value gaps et
iFVG, zones premium / discount et OTE, et enfin la checklist de confirmation de trade du chapitre 7.
Les citations utilisées dans ce rapport sont reprises mot à mot de la version anglaise du livre.""",
"""Chaque règle extraite a ensuite été confrontée au code du script, fonction par fonction : la détection
des pivots et le nommage des swings (f_swing_name, f_update_structure), les événements structurels
(f_update_breaks), les pools de liquidité et leur balayage (f_add_pool, f_process_pools, f_check_equal),
les order blocks (f_create_ob, f_process_ob), les FVG (f_process_fvg), la localisation premium /
discount et les cibles. Le comportement de chaque bloc a été reconstitué à la main, barre par barre,
pour vérifier la sémantique exacte (par exemple : qu'est-ce qui se passe lors d'une vraie cassure d'un
pool, ou au premier retest d'un order block). Un point de sémantique du langage Pine — le comportement
des boucles « for i = 0 to N-1 » sur tableaux vides — a été vérifié par recherche documentaire, la
documentation officielle TradingView confirmant le motif de garde recommandé.""",
"""Deux limites doivent être signalées. D'une part, l'audit est statique : le script n'a pas été compilé
sur TradingView, les vérifications syntaxiques ont donc été conduites par analyse du code (structure
des boucles, ordre de définition des fonctions, doublons, indentations, cohérence des types), ce qui
ne remplace pas une exécution réelle ; il est recommandé de charger la version 2 dans l'éditeur Pine
avant toute utilisation en conditions réelles. D'autre part, certaines règles du livre décrivent des
processus de décision du trader (confirmations d'entrée, gestion du risque) et non des objets
graphiques : elles sont classées « non applicables » pour un indicateur et font l'objet de
recommandations au chapitre 10 pour leur implémentation côté application."""
]

CH3_INTRO = [
"""La structure de marché est le socle du livre : une tendance haussière se définit par une séquence de
sommets et creux ascendants (HH / HL), une tendance baissière par des creux et sommets descendants
(LL / LH), et toute invalidation passe par la cassure d'un point structurel. Le script WaveScope
implémente cette mécanique de façon fidèle : les pivots externes (sensibilité 8 par défaut) et internes
(sensibilité 3) alimentent un zigzag double, les étiquettes HH / HL / LH / LL sont attribuées par
comparaison au swing précédent du même type, et la confirmation des cassures se fait par clôture —
ce qui correspond à la discipline de confirmation que le livre exige avant de valider un breakout.""",
"""Le BOS et le CHoCH respectent également la lettre du livre : le BOS étiquette les cassures dans le
sens de la tendance (continuation), le CHoCH les cassures du dernier creux majeur en tendance
haussière ou du dernier sommet majeur en tendance baissière (premier signal de renversement). La
double structure interne / externe reflète la distinction du livre entre structure majeure et structure
mineure, que le chapitre 7 utilise pour les confirmations d'entrée sur unités de temps inférieures.""",
"""Le seul écart sérieux concernait le MSS (Market Structure Shift). Le livre est explicite : « This
combination — a structural break and a liquidity grab — is what sets an MSS apart from a regular
pullback », et « displacement validates the MSS. Without it, the move lacks credibility ». Or le script
original posait l'étiquette MSS sur chaque renversement interne, sans aucune condition de déplacement
ni de sweep préalable — un renversement sans impulsion était donc présenté comme un MSS, ce qui va
contre la lettre du chapitre 3. La version 2 corrige ce point : un renversement interne n'est labellisé
MSS que si la bougie de cassure montre un déplacement (corps supérieur ou égal au seuil paramétrable
de 1,5 ATR) ; dans le cas contraire, l'événement est étiqueté iCHoCH, ce qui en fait un simple
changement de caractère interne. La combinaison sweep + MSS reste visible sur le graphique par la
coexistence de l'étiquette SWEEP / RAID et du label MSS, permettant la lecture combinée que décrit
le livre."""
]

CH4_INTRO = [
"""La liquidité est le cœur du modèle ICT présenté par le livre : « Liquidity is the fuel for every
move ». Le script couvre les mécaniques essentielles de façon fidèle. Les pools BSL sont placés au
niveau des swing highs actifs et les pools SSL sous les swing lows, exactement comme le livre les
définit (stops des positions opposées + ordres de breakout). Les equal highs / equal lows sont détectés
par clustering avec une tolérance en ATR — le livre demandant « two or more swing highs or lows at
approximately the same level ». La définition du sweep est particulièrement fidèle : mèche au-delà du
niveau mais clôture en deçà, c'est-à-dire exactement la fausse cassure avec rejet que le livre décrit
comme « not a true breakdown, but rather a strategic sweep ». Les raids des niveaux égaux (EQH / EQL)
sont étiquetés RAID, et les mèches de rejet sont marquées REJ dès qu'elles représentent 60 % de la
bougie, en cohérence avec les « wick rejections » du chapitre 3. La distinction IRL / ERL est présente
à travers les pools internes (structure mineure) et externes (structure majeure).""",
"""Deux points manquaient par rapport à la lettre du livre. D'une part, le chapitre 3 liste les zones de
liquidité à surveiller : swing highs / lows, supports / résistances, round numbers, « previous day
high/low » et « session high/low (London, New York) ». Le script offrait les sessions mais pas les
PDH / PDL ; la version 2 les ajoute, sous forme de lignes journalières confirmées (calcul en daily
avec décalage d'une période, sans repaint) et les intègre à la recherche de cible. Les round numbers
et la liquidité de trendline restent recommandés (chapitre 10). D'autre part, le livre consacre une
section entière à l'analyse des volumes pour confirmer les sweeps (« High Volume Spikes + Reversal »,
« Lack of Continuation Volume ») ; la version 2 introduit une option de confirmation par volume
(suffixe +V sur les étiquettes SWEEP / RAID quand le volume dépasse 1,3 fois sa moyenne 20 barres),
laissée désactivée par défaut car certains marchés (forex spot en particulier) ne fournissent pas de
volume fiable.""",
"""Un défaut technique important a également été corrigé dans cette zone du code : en cas de vraie
cassure (clôture au-delà du niveau), le pool n'était jamais marqué comme balayé et sa ligne s'étendait
indéfiniment, ce qui contredisait la logique même de consommation de liquidité. La version 2 distingue
proprement le sweep (fausse cassure avec rejet, ligne en pointillés et croix) de la consommation
(cassure réelle, ligne arrêtée en trait plein grisé)."""
]

CH5_INTRO = [
"""Les order blocks constituent le chapitre le plus exigeant du livre, et c'est aussi là que le script
original montrait le plus d'écarts par rapport à la lettre. Commençons par les points conformes. La
définition de base est respectée : l'OB haussier est la dernière bougie baissière avant une impulsion
haussière (et inversement pour l'OB baissier), trouvée par recherche rétroactive depuis la cassure. Le
point le plus fort du script est l'ancrage structurel : les order blocks ne sont créés qu'aux
événements BOS / CHoCH / MSS, ce qui applique strictement la règle du livre « Ensure a Break of
Structure (BOS) or Change of Character (CHoCH) [...] If there's no BOS or CHoCH, the Order Block is
likely weak or unconfirmed ». La ligne des 50 % (Mean Threshold) est tracée sur chaque zone, conforme
au « 50% Mean Threshold Rule » du chapitre 4.""",
"""Trois écarts majeurs ont été corrigés. Premièrement, le livre impose de tracer la zone sur le corps
de la bougie : « Draw a rectangle around the body of that last bearish candle » et « The body is more
reliable than the wick, as it represents the actual trading range » ; le script utilisait l'étendue
haute / basse complète, mèches comprises. La version 2 trace la zone sur le corps par défaut
(l'étendue complète reste disponible via une option). Deuxièmement, le livre distingue l'OB frais
(« unmitigated », à fort potentiel) de l'OB déjà retesté (« mitigated », affaibli) ; le script
confondait mitigation et invalidation. La version 2 marque le premier retest (fond éclairci, bordure
pointillée, croix sur l'étiquette) et ne supprime la zone qu'en cas d'invalidation par clôture
au-delà. Troisièmement, le breaker block : le livre définit le breaker comme « the candle or zone that
caused the break » — par exemple, quand un OB baissier est cassé vers le haut, la dernière bougie
baissière avant la cassure devient le breaker haussier ; le script se contentait de recolorer l'OB
invalidé. La version 2 implémente la définition du livre : une zone BKR distincte est créée à partir
de la bougie à l'origine de la cassure, étendue vers la droite avec sa ligne CE 50 %, marquée au
retest et supprimée si invalidée.""",
"""Enfin, deux concepts absents ont été ajoutés. Les blocs de mitigation (chapitre 4) : lorsqu'un CHoCH
externe se produit et que le prix n'a pas réussi à casser le dernier swing en clôture (échec de
swing), la dernière bougie opposée avant le renversement devient une zone MIT, conformément au
scénario « price fails to create lower low » + CHoCH du livre. Et la checklist de haute probabilité
(étapes 3, 4 et 6) est maintenant matérialisée sur chaque étiquette d'OB : +SWP si un sweep est
survenu dans les 12 dernières barres, +FVG si un fair value gap actif recouvre la zone, +VOL si le
volume de la bougie d'origine dépasse 1,5 fois sa moyenne — permettant d'un coup d'œil de repérer les
OB « institutionnels » que le livre qualifie de haute probabilité."""
]

CH6_INTRO = [
"""Le traitement des fair value gaps était le module le plus conforme du script original. La définition
sur trois bougies est exacte : gap haussier quand le plus bas de la troisième bougie est supérieur au
plus haut de la première (« the wick of the third candle does not fully overlap with the wick of the
first »), gap baissier dans le cas symétrique, avec un filtre de taille minimale en ATR pour écarter
les micro-gaps. Les zones sont dessinées avec la couleur de leur direction et étendues vers la
droite, la ligne CE 50 % matérialise le midpoint d'entrée recommandé par le livre (« entering a buy
position either at the midpoint of the FVG or near the lower boundary »), et le mécanisme d'inversion
iFVG est présent : quand le gap est traversé, il se recolore dans le sens opposé, devenant
support-résistance inversé, conformément au chapitre 5.""",
"""Deux améliorations ont été apportées pour coller à la lettre du livre. La première concerne la
mitigation progressive : le livre décrit le retour du prix dans le gap comme le rebalancement de
l'inefficacité (« price tends to revisit the FVG to fill in the imbalance ») ; or le script ne
distinguait pas le simple retour dans le gap de sa traversée complète. La version 2 marque le premier
retour dans la zone (bordure pointillée) et réserve l'inversion iFVG à la traversée complète du gap.
La deuxième concerne l'invalidation des iFVG : le livre précise que « if price rises past the top of
the iFVG zone, it's invalid and should no longer be used » ; les zones inversées restaient auparavant
affichées indéfiniment. La version 2 gèle toute zone iFVG dont le bord opposé est dépassé en clôture
(extension arrêtée, fond grisé, ligne CE stoppée).""",
"""Enfin, la confluence FVG + OB — que le livre présente comme l'une des combinaisons les plus
puissantes (« When a Fair Value Gap appears immediately after or within an Order Block [...] this dual
confirmation strengthens the likelihood of a price reaction ») — est maintenant détectée
explicitement : tout order block recouvert par un FVG actif reçoit l'étiquette +FVG, ce qui permet de
repérer directement les zones d'entrée convergentes que le chapitre 5 appelle « overlap zone »."""
]

CH7_INTRO = [
"""Le chapitre 6 du livre définit la localisation du prix dans le range de négociation (dealing range)
comme un pilier : au-dessus de 50 % le prix est en premium (cher, défavorable aux achats), en dessous
il est en discount (bon marché, défavorable aux ventes), et les institutions accumulent en discount
pour distribuer en premium. Le script respecte ce principe : le range est construit sur les swings
actifs de la structure externe, la position de la clôture est affichée (PREMIUM / DISCOUNT) au
tableau de bord et les zones sont matérialisées par deux blocs de couleur autour de la ligne des
50 %. Le livre ajoute que les entrées optimales se situent plus profondément dans le retracement,
entre 61,8 % et 78,6 % — la zone OTE (Optimal Trade Entry), avec un niveau intermédiaire autour de
70,5 %. Ce pilier était totalement absent du script original : la version 2 trace la zone OTE sur le
dealing range dans le sens de la tendance (mesurée depuis le haut du range en tendance haussière,
depuis le bas en tendance baissière), affiche les trois niveaux et ajoute une ligne « DANS OTE » au
tableau de bord lorsque le prix s'y trouve.""",
"""Une réserve documentée : le script ajoute une bande d'équilibre de ±5 % autour du 50 %, dans laquelle
le prix est étiqueté EQUILIBRIUM. Le livre divise strictement le range en deux moitiés, sans zone
neutre ; cette bande est donc un choix d'affichage du script original, conservé en version 2 parce
qu'il est réglable (de 1 à 20 %) et utile pour éviter les étiquettes trop volatiles autour du
milieu — mais il est important de le savoir : au sens strict du livre, tout prix au-dessus de 50 %
est en premium. Les cibles, enfin, respectent l'esprit du chapitre 7 : la cible dynamique est le
prochain pool de liquidité non balayé (BSL / SSL / EQH / EQL) dans le sens de la tendance, le high /
low de session, et désormais les PDH / PDL. Le placement du stop-loss et le ratio de risque 1:2 à
1:3 du livre ne relèvent pas d'un indicateur : ils sont classés non applicables et renvoyés à la
couche d'exécution de l'application."""
]

CH8_INTRO = [
"""Au-delà de la conformité aux règles du livre, l'audit a relevé quatre défauts techniques, dont un
critique. Le bug critique concerne les boucles non gardées : cinq fonctions du script original
parcouraient des tableaux avec la forme « for i = 0 to array.size(arr) - 1 » sans vérifier que le
tableau n'est pas vide. Or en Pine, quand array.size renvoie 0, la boucle devient « for i = 0 to -1 »,
et comme le pas par défaut est -1 lorsque la valeur de départ est supérieure à la valeur d'arrivée,
la boucle s'exécute en comptant à rebours (dont une itération avec i = 0) et array.get(arr, 0) sur
un tableau vide déclenche une erreur d'exécution « index out of bounds ». La documentation officielle
de TradingView illustre d'ailleurs la parade canonique : « for i = 0 to (array.size(a) == 0 ? na :
array.size(a) - 1) ». Ces tableaux (pools de liquidité, order blocks, FVG) démarrent vides au début
de l'historique, le risque était donc réel dès les premières barres. Fait révélateur, l'auteur avait
correctement gardé deux autres boucles (f_check_equal avec « if n >= 2 », f_create_ob avec « if
lookback >= 1 »), mais pas celles-là.""",
"""Les trois autres défauts sont décrits dans le tableau ci-dessous : la liquidité jamais consommée en
cas de vraie cassure (lignes de pools s'étendant à l'infini), les iFVG jamais invalidés, et un code
mort avant suppression de boîte. Tous sont corrigés en version 2. Il convient de rappeler la limite
méthodologique : l'audit est statique et le script n'a pas été compilé sur TradingView ; la version 2
a fait l'objet d'une vérification statique complète (boucles gardées, ordre de définition des
fonctions, absence de doublons, cohérence des indentations et des signatures), mais un chargement
dans l'éditeur Pine reste l'étape finale de validation recommandée avant toute utilisation."""
]

CH9_INTRO = [
"""La version 2 du script (« wavescope_ict_v2_conforme.pine », 1 152 lignes contre 853 à l'original)
applique seize modifications, toutes tracées dans le tableau ci-dessous avec leur localisation dans
le code, leur nature (sécurité, correction, alignement ou ajout) et la référence exacte du livre qui
la justifie. Les choix d'implémentation ont systématiquement privilégié la lettre du livre lorsque
l'interprétation pouvait varier : zone d'order block sur le corps de la bougie, breaker construit à
partir de la bougie ayant causé la cassure, MSS conditionné au déplacement, zone OTE mesurée dans le
sens de la tendance. Chaque ajout est assorti d'un réglage (tous activés par défaut, conformes au
livre) et documenté dans l'en-tête du script, de façon à ce que la traçabilité règle par règle reste
lisible directement dans le code.""",
"""Les nouveaux marqueurs visuels ont été choisis pour rester sobres et cohérents avec l'existant :
étiquettes BKR pour les breakers et MIT pour les blocs de mitigation, suffixes +SWP / +FVG / +VOL
pour les confluences des order blocks, suffixe +V pour les sweeps confirmés par volume, croix sur
les étiquettes des zones retestées, bordures pointillées pour les zones mitigées. Le tableau de bord
gagne une ligne OTE et les cibles intègrent les PDH / PDL. Aucun comportement conforme du script
original n'a été supprimé : la structure double, le zigzag en développement, les sessions, la
validation des cassures par clôture et l'ensemble des réglages existants sont inchangés.""",
"""Trois réglages méritent une mention particulière. L'option « OB zone on candle body » est activée
par défaut parce que le livre l'impose, mais peut être désactivée pour retrouver l'étendue complète
(mèches), utile sur les marchés très volatils où les corps sont fins. L'option « volume-confirmed
sweeps » est désactivée par défaut : le volume n'est pas fiable sur tous les marchés (le forex spot
en particulier), et le livre lui-même le présente comme une confirmation, jamais comme une condition.
Enfin la sensibilité du MSS (seuil de déplacement à 1,5 ATR) reprend le seuil par défaut des bougies
de déplacement déjà présentes dans le script, ce qui garantit la cohérence entre les deux modules."""
]

CH10_INTRO = [
"""Après la version 2, la conformité résiduelle se concentre sur cinq points, tous hors du périmètre
naturel d'un indicateur graphique. Le raffinement multi-unités de temps (chercher l'OB sur H1 puis
l'entrée sur M5) nécessite soit deux instances de l'indicateur, soit un mécanisme de contexte HTF
natif ; c'est une amélioration possible du script mais surtout une architecture à prévoir dans
l'application. Le biais automatique lié à la localisation (n'acheter qu'en discount / OTE, ne vendre
qu'en premium) et la confirmation d'entrée (bougies d'englobement, CHoCH interne sur unité inférieure,
divergences) sont des règles de décision du chapitre 7 : elles appartiennent à la couche signaux de
l'application (Signal Strategy et Auto Trade). Le placement du stop-loss (sous l'OB ou sous le
sweep) et le ratio de risque minimal de 1:2 à 1:3 avec un risque de 1 à 2 % du capital relèvent du
Strategy Tester, où les travaux déjà planifiés (mise de base, martingale, vitesses de replay X40 /
X80, test des stratégies de l'Auto Trade) s'inscrivent exactement dans cette logique. Enfin, les
round numbers et la liquidité de trendline, mentionnés au chapitre 3 comme zones de liquidité à
surveiller, restent à ajouter — ce sont des ajouts simples et recommandés pour la version 3.""",
"""Pour l'intégration dans le programme (moteur Pine v6 Engine, graphiques lightweight-charts), la
recommandation est de ne pas porter le script tel quel mais d'importer ses règles de détection comme
socle du moteur de conditions : la version 2 formalise précisément, sous forme testable, les objets
du livre (sweeps avec rejet, order blocks sur corps avec états frais / mitigé / invalidé, breakers,
blocs de mitigation, FVG partiels et iFVG invalidés, zone OTE, cibles de liquidité). Ces détecteurs
peuvent alimenter directement les cartes de conditions haussières / baissières et la checklist de
confluence du chapitre 7 : un signal CALL ne serait émis que si structure en BOS haussier, sweep récent,
OB +FVG en discount et prix en OTE sont réunis — la « haute probabilité » du livre devenant alors un
score de confluence mesurable et backtestable dans le Strategy Tester.""",
"""En usage direct sur TradingView, trois précautions s'imposent. Charger d'abord la version 2 dans
l'éditeur Pine pour valider la compilation (l'audit étant statique, une exécution réelle reste le
contrôle final). Vérifier ensuite les réglages par défaut au regard du marché traité : l'option
volume est sans objet sur les indices synthétiques sans volume fiable, et la sensibilité externe
peut être abaissée sur les unités de temps courtes. Enfin, garder à l'esprit la clause du livre
elle-même : les concepts ICT / SMC sont probabilistes, aucune configuration — même strictement
conforme — ne garantit un trade gagnant ; la gestion du risque (1-2 % par trade, ratio 1:3) reste
la condition non négociable de rentabilité à long terme."""
]

# Statistiques pour les encadrés du chapitre 1
STATS = [
    ("41", "règles du livre évaluées"),
    ("23 / 41", "conformes dans la version d'origine"),
    ("36 / 41", "conformes après la version 2"),
    ("4", "défauts techniques corrigés (dont 1 critique)"),
    ("16", "modifications appliquées au script"),
    ("9", "concepts du livre ajoutés en v2"),
]

# Tableau de synthèse par module (ch.1)
T_SYNTHESE = [
    ("Structure de marché (BOS / CHoCH / MSS / structure interne)", "5/6", "6/6", "MSS aligné sur le déplacement"),
    ("Liquidité (BSL / SSL / EQH / EQL / sweeps / IRL-ERL / PDH-PDL / volumes)", "7/9", "9/9", "PDH/PDL et volumes ajoutés"),
    ("Order Blocks (définition / corps / mitigation / breaker / confluences)", "3/11", "9/11", "Corps, breaker livre, MIT, tags de confluence ; MTF resté partiel"),
    ("Fair Value Gaps (définition / remplissage / iFVG / confluence)", "5/7", "7/7", "Mitigation partielle et confluence +FVG"),
    ("Premium / Discount / OTE / cibles", "3/8", "5/8", "OTE ajouté ; bande d'équilibre documentée ; SL et RR renvoyés à l'application"),
]
