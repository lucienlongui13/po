#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v1.10.sh — Livraison v1.10 « Compatibilité Pine v1–v4 »
#
# Le besoin : exécuter des indicateurs écrits en Pine Script v3 (comme
# « Two Bar Break Line Alerts R1.1 » de JustUncleL) TELS QUELS, collés depuis
# TradingView. Le moteur (piner) est un moteur v6 : les scripts v1–v4
# utilisent des builtins pré-namespace qui échouaient silencieusement.
#
# Le correctif v1.10 :
#   1. COUCHE DE MISE À NIVEAU TRANSPARENTE (src/lib/pine-upgrade.ts) :
#      study()→indicator(), builtins nus (sma/ema/macd/min/cum…) → ta.*/math.*,
#      couleurs nues → color.*, style=stepline → plot.style_*,
#      isintraday/interval → timeframe.*, input(..., type=) nettoyé,
#      transp= → color.new, iff() → ternaire, arité rising/falling v3 ;
#      transformation string/comment-aware, préservation des lignes,
#      v5/v6 JAMAIS touchés ;
#   2. PATCH PINER #1 — division entière : Pine définit int/int → int
#      (tronqué) ; piner faisait une division flottante JS (21/2 = 10.5) →
#      ta.wma(close, len/2) retournait na POUR TOUJOURS (HullMA cassé) ;
#   3. PATCH PINER #2 — égalité bool↔int : `alert_bar == 1` (série bool)
#      retournait toujours false (égalité stricte JS) → statistiques BO
#      noires jamais affichées.
#
# Sortie : /home/z/my-project/download/pine_v6_engine_v1.10.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v1.10"
FOLDER=pine_v6_engine_v1.10
OUT="$ROOT/download/pine_v6_engine_v1.10.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (mêmes exclusions que v1.0→v1.9) ─────────────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude 'upload/' \
  --exclude 'download/' \
  --exclude 'tool-results/' \
  --exclude '.stage-v1.1/' \
  --exclude '.stage-v1.2/' \
  --exclude '.stage-v1.3/' \
  --exclude '.stage-v1.4/' \
  --exclude '.stage-v1.5/' \
  --exclude '.stage-v1.6/' \
  --exclude '.stage-v1.7/' \
  --exclude '.stage-v1.8/' \
  --exclude '.stage-v1.9/' \
  --exclude '.stage-v1.10/' \
  --exclude 'skills/' \
  --exclude 'bun.lock' \
  --exclude '*.tmp' \
  --exclude 'bun-error.log' \
  --exclude '.env.local' \
  --exclude 'tsconfig.tsbuildinfo' \
  --exclude 'next-env.d.ts' \
  --exclude '*.log' \
  --exclude '.logs/' \
  --exclude 'v12_*.png' \
  --exclude 'scripts/*.png' \
  --exclude 'scripts/diag/' \
  --exclude 'scripts/e2e-v18-*.png' \
  --exclude 'scripts/e2e-v110-*.png' \
  --exclude 'scripts/vlm_*.json' \
  --exclude 'scripts/search*.json' \
  --exclude 'scripts/e2e-v18-probe.txt' \
  --exclude 'db/' \
  "$ROOT/" "$STAGE/$FOLDER/"

# ── WaveScope v5 + guide réglages (inclus depuis v1.3) ────────────────────
cp "$ROOT/download/wavescope_ict_v5.pine" "$STAGE/$FOLDER/wavescope_ict_v5.pine"
cp "$ROOT/download/GUIDE-REGLAGES-V5.md" "$STAGE/$FOLDER/GUIDE-REGLAGES-V5.md"

# ── Pack d'exemple (celui fourni par l'utilisateur) pour test immédiat ────
mkdir -p "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies/libs"
cp "$ROOT/upload/piracy_extracted/Market_structures_scripts/Main.pine" \
   "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies/Main.pine"
cp "$ROOT/upload/piracy_extracted/Market_structures_scripts/libs/"*.pine \
   "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies/libs/"

# ── Doc technique v1.9 (l'alignement live reste d'actualité) ───────────────
cp "$ROOT/README-PINE-LIVE-ALIGNMENT.md" "$STAGE/$FOLDER/README-PINE-LIVE-ALIGNMENT.md"

# ── L'indicateur demandé, prêt à coller (avec la correction colorup=lime) ──
cp "$ROOT/TradingView_pine_scripts_samples/2barbl_r11_v3.pine" \
   "$STAGE/$FOLDER/Two-Bar-Break-Line-Alerts-R1.1.pine"

# ── README des fonctionnalités v1.10 ──────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.10-PINE-V3-COMPAT.md" <<'EOF'
# Pine v6 Engine — v1.10 « Compatibilité Pine v1–v4 »

## Ce que cette version apporte

**Vous demandiez** : faire fonctionner l'indicateur
« **Two Bar Break Line Alerts R1.1** » de JustUncleL (Pine Script **v3**,
copié tel quel depuis TradingView). Il fonctionne maintenant **verbatim** :
ligne MA colorée (HullMA), lignes de breakout rouges/vertes en escalier,
flèches vertes/rouges, barres jaunes/noires des statistiques Binary Options,
triangles de stats en bas du graphique, et toutes les alertes
(Break Line BUY/SELL, Trend UP/Down).

Fichier prêt à coller inclus : `Two-Bar-Break-Line-Alerts-R1.1.pine`
(une seule retouche par rapport à votre collage : `colorup=line` →
`colorup=lime` — « line » n'est pas une couleur dans Pine ; le script
original publie `lime`, la touche M/N a glissé).

## Pourquoi ça ne marchait pas

Le moteur d'exécution (piner) est un moteur **Pine v6**. Les scripts v1–v4
utilisent l'ancien langage pré-namespace, et l'échec était **silencieux** :

- `sma()`, `ema()`, `macd()`, `min()`, `cum()`… sans préfixe ne résolvent
  rien → les séries produites sont **na** sans aucune erreur ;
- `study()`, les couleurs nues (`red`, `lime`…), `style=stepline`,
  `isintraday`, `interval`, `input(..., type=integer)` ne compilent pas ;
- et deux bugs du moteur lui-même, visibles sur TOUT script (v5/v6 aussi) :
  - **division entière** : Pine définit `21/2 = 10` ; le moteur renvoyait
    `10.5` → `ta.wma(close, len/2)` (HullMA) retournait na pour toujours ;
  - **égalité bool↔int** : `alert_bar == 1` (série bool) était toujours
    false → les barres noires des stats BO n'apparaissaient jamais.

## Le correctif

1. **`src/lib/pine-upgrade.ts`** — couche de mise à niveau transparente
   v1–v4 → v6, appliquée AVANT compilation, dans `runPineScript()`,
   `getPineInputSchema()` et `inspectPineSource()` :

   | v1–v4 (collé)                  | v6 (exécuté)                     |
   |--------------------------------|----------------------------------|
   | `study("titre", overlay=true)` | `indicator("titre", overlay=true)` |
   | `sma/ema/wma/vwma/macd/min/max/round/sqrt/exp/cos/cum/barssince/change…` | `ta.*` / `math.*` |
   | `red / lime / gray…`           | `color.red / color.lime…`        |
   | `style=stepline`               | `style=plot.style_stepline`       |
   | `isintraday`, `interval`       | `timeframe.isintraday`, `timeframe.multiplier` |
   | `input(8, type=integer, …)`    | `input(8, …)` (type inféré)       |
   | `transp=50`                    | `color.new(couleur, 50)`          |
   | `iff(a, b, c)`                 | `(a ? b : c)`                     |
   | `rising(14)`                   | `ta.rising(close, 14)`            |
   | `security(...)`                | `request.security(...)`           |

   La transformation respecte chaînes et commentaires (les titres contenant
   « sma » ou « red » ne sont pas touchés), préserve le numéro des lignes
   (les messages d'erreur restent justes), et **ne touche jamais** un script
   déjà en v5/v6.

2. **Patches piner** (`patches/@heyphat+piner+0.13.0.patch`, appliqués
   automatiquement au `npm install` via postinstall) : division entière
   conforme Pine + coercition bool↔int pour l'égalité (sémantique v3).

## Utilisation

Collez simplement n'importe quel script TradingView (v3, v4, v5 ou v6) dans
l'éditeur Pine et cliquez Run — la version est détectée automatiquement
(`//@version=3` en tête de fichier, ou `study()` pour les plus anciens).
Le panneau Réglages se remplit correctement (types, min/max, listes
déroulantes — 24 réglages pour 2BARBL).

## Vérification (correspondance TradingView)

Sur le dataset réel EURUSD M1 (2242 bougies), le moteur est comparé **barre
par barre** à une ré-implémentation indépendante de l'indicateur :

- HullMA(21) : 2218 valeurs identiques (écart max < 1e-9) ;
- lignes Top/Bottom Breakout : identiques barre par barre ;
- **230 flèches** = 118 achats + 112 ventes, positions EXACTES ;
- 688 alertes (230 Break Line + 118 BUY + 112 SELL + 228 Trend) ;
- 167 barres BO colorées : positions jaunes/noir exactes ;
- panneau Réglages : 24 inputs typés avec options.

```
npx tsx scripts/test-pine-v3-compat.ts     # 43 tests : transformation + moteur + sémantique
npx tsx scripts/compat-sweep.ts            # 23 scripts TradingView : 18 ✓ (5 échecs pré-existants documentés)
npx tsx scripts/test-pine-alignment.ts     # 27 ✓   ─ non-régression v1.8
npx tsx scripts/test-pine-timestamp-mapping.ts   # 30 ✓ ─ non-régression v1.9
npx tsx scripts/test-pine-live-alignment.ts      # 28 ✓
bash scripts/e2e-v110-2barbl.sh            # 5 ✓ — le script v3 s'exécute dans l'app
```

Non-régression complète : libraries (50), engine-libs (21), martingale (12),
stop/rejet (17), log trades (21), CALL/PUT (9), new-bar-shift (8),
stale-result (13), multiscript (15), drawing-anchor (16), adaptateurs —
tout passe. `tsc` 0 erreur, build production OK, e2e navigateur v1.8 : 7/7.

## Lancer sur Termux

```bash
unzip pine_v6_engine_v1.10.zip
cd pine_v6_engine_v1.10
npm install --no-audit --no-fund   # le postinstall applique les patches piner
./start-dev.sh
```
EOF

# ── ZIP du pack d'exemple (prêt à importer pour tester) ───────────────────
(cd "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies" && zip -qr9 "$STAGE/EXEMPLE-Pack-Multi-Librairies.zip" .)
mv "$STAGE/EXEMPLE-Pack-Multi-Librairies.zip" "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies.zip"

# ── Création du zip ───────────────────────────────────────────────────────
rm -f "$OUT"
(cd "$STAGE" && zip -qr9 "$OUT" "$FOLDER")

# ── Vérification ──────────────────────────────────────────────────────────
echo "=== Archive créée : $OUT ==="
du -h "$OUT"
unzip -l "$OUT" | tail -1
echo "=== Fichiers clés présents ==="
unzip -l "$OUT" | grep -E 'pine-upgrade|README-V1.10|Two-Bar-Break-Line|EXEMPLE-Pack|wavescope_ict_v5|GUIDE-REGLAGES-V5|2barbl_r11|test-pine-v3-compat|patch-piner-intdiv' | awk '{print $1, $4}'
echo "=== Marqueurs de fonctionnalités (vérification rapide) ==="
unzip -p "$OUT" "$FOLDER/src/lib/pine-upgrade.ts" | grep -c 'upgradeLegacyPine' | xargs echo "couche de mise à niveau (>=1 attendu) :"
unzip -p "$OUT" "$FOLDER/src/lib/pine-engine.ts" | grep -c 'effectivePineSource' | xargs echo "câblage moteur (>=4 attendus) :"
unzip -p "$OUT" "$FOLDER/patches/@heyphat+piner+0.13.0.patch" | grep -c 'idiv' | xargs echo "patch division entière (>=6 attendus) :"
unzip -p "$OUT" "$FOLDER/patches/@heyphat+piner+0.13.0.patch" | grep -c 'boolean' | xargs echo "patch égalité bool (>=2 attendus) :"
unzip -p "$OUT" "$FOLDER/package.json" | grep -c 'patch-package' | xargs echo "postinstall patch-package (>=2 attendus) :"
unzip -p "$OUT" "$FOLDER/TradingView_pine_scripts_samples/2barbl_r11_v3.pine" | grep -c 'colorup=lime' | xargs echo "script 2BARBL corrigé (1 attendu) :"
unzip -t "$OUT" > /dev/null && echo "=== Intégrité zip OK ==="

# Nettoyage du staging
rm -rf "$STAGE"
