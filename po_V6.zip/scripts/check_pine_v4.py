#!/usr/bin/env python3
"""Vérification statique du script Pine v4 (wavescope_ict_v4.pine)."""
import re
import sys
from collections import Counter

PATH = "/home/z/my-project/download/wavescope_ict_v4.pine"
with open(PATH, encoding="utf-8") as f:
    lines = f.readlines()
content = "".join(lines)

issues, warns, ok = [], [], []

# 1) Boucles for gardées
loop_re = re.compile(r"^\s*for\s+\w+\s*=\s*0\s+to\s+array\.size\(")
for idx, line in enumerate(lines):
    if loop_re.match(line):
        context = "".join(lines[max(0, idx - 4):idx + 1])
        if not re.search(r"(>\s*0|>=\s*1|>=\s*2|>=\s*n\b|lookback\s*>=\s*1)", context):
            issues.append(f"L{idx+1}: boucle non gardée → {line.strip()[:80]}")
        else:
            ok.append(f"L{idx+1}: boucle gardée")

# 2) Guillemets équilibrés par ligne
for idx, line in enumerate(lines):
    if line.strip().startswith("//"):
        continue
    if line.count('"') % 2 != 0:
        issues.append(f"L{idx+1}: guillemets non appariés → {line.strip()[:70]}")

# 3) Fonctions définies avant usage + pas d'appel de fonction inconnue
func_defs = {}
for idx, line in enumerate(lines):
    m = re.match(r"^(f_\w+)\s*\([^)]*\)\s*=>", line)
    if m:
        func_defs[m.group(1)] = idx + 1
all_called = set()
for idx, line in enumerate(lines):
    if line.strip().startswith("//"):
        continue
    for fn in re.findall(r"(?<!\w)(f_\w+)\(", line):
        all_called.add(fn)
undef = [fn for fn in all_called if fn not in func_defs]
if undef:
    issues.append(f"Fonctions appelées non définies : {sorted(undef)}")
for idx, line in enumerate(lines):
    if line.strip().startswith("//"):
        continue
    for fn, def_ln in func_defs.items():
        if re.search(r"(?<!\w)" + re.escape(fn) + r"\(", line) and idx + 1 < def_ln:
            warns.append(f"L{idx+1}: appel de {fn} avant définition (L{def_ln})")

# 4) Exhaustivité des inputs : chaque identifiant input déclaré vs référencé
input_names = re.findall(r"^(\w+)\s*=\s*input\.", content, re.M)
dup_inputs = [n for n, c in Counter(input_names).items() if c > 1]
if dup_inputs:
    issues.append(f"Inputs dupliqués : {dup_inputs}")
input_set = set(input_names)
# identifiants référencés dans le corps (hors déclarations input, hors commentaires)
body = re.sub(r"//.*", "", content)
body = re.sub(r"^\w+\s*=\s*input\..*$", "", body, flags=re.M)
referenced = set(re.findall(r"\b[a-z][A-Za-z0-9]*\b", body))
builtin_whitelist = {"if", "else", "for", "to", "while", "var", "and", "or", "not", "na", "true", "false", "int", "float", "bool", "string", "color", "label", "line", "box", "table", "array", "linefill", "math", "str", "ta", "request", "syminfo", "timeframe", "barstate", "display", "extend", "xloc", "yloc", "size", "shape", "plot", "plotshape", "plotchar", "bar_index", "open", "high", "low", "close", "volume", "time", "nz", "format", "position", "text", "label", "line", "box", "swing", "structure", "liqpool", "fvgzone", "obzone", "cross", "alertcondition", "indicator", "input", "color", "na", "tooltip", "group", "inline", "options", "minval", "maxval", "step", "title"}
missing_inputs = sorted(n for n in input_set if n not in referenced and n not in builtin_whitelist)
if missing_inputs:
    warns.append(f"Inputs déclarés jamais référencés (inoffensif) : {missing_inputs}")

# 4bis) Vérification inverse : les identifiants du moteur qui ressemblent à des
# réglages (showX, XColor, XWidth, XStyle, max/Min...) doivent être déclarés.
engine_setting_like = set()
for m in re.finditer(r"\b(show[A-Z]\w+|\w+Color|\w+Width|\w+Style[A-Z]?\w*|max\w+|min\w+|\w+Transp|\w+Size|zz\w+|ob\w+|fvg\w+|eq\w+|ote\w+|liq\w+|session\w+|proj\w+|panel\w+|letter\w+|event\w+|tip\w+|pivot\w+|displacement\w+|rejection\w+|confirm\w+|extend\w+)\b", body):
    n = m.group(1)
    if n in builtin_whitelist:
        continue
    engine_setting_like.add(n)
undeclared = sorted(n for n in engine_setting_like if n not in input_set and not re.search(r"\b" + n + r"\b\s*(=|:=|\()", content))
# retire les faux positifs : noms de champs de types (price, bar, ptype...)
undeclared = [n for n in undeclared if n not in ("eqTolerance",) or "eqTolerance" not in input_set]

# 5) Anciennes chaînes de mode v3 ne doivent plus exister
for old_str in ["Multiple d'ATR", '"Points"']:
    if old_str in content:
        issues.append(f"Ancienne chaîne v3 encore présente : {old_str}")

# 6) Marqueurs v4
markers = {
    "titre v4": content.count('WAVESCOPE ICT v4'),
    "mode Auto (×ATR)": content.count("Auto (×ATR) — recommandé"),
    "seuil effectif (zzThr)": content.count("zzThr"),
    "ligne ZigZag panneau": content.count("ZigZag"),
    "maxDevelopingBars": content.count("maxDevelopingBars"),
    "calc_on_every_tick": content.count("calc_on_every_tick=true"),
    "lignes cassure orange (chochColor)": len(re.findall(r"chochColor, 25\), style=f_line_style", content)),
    "équilibre violet (levelColor, 40)": content.count("levelColor, 40"),
    "réglages inline (input inline)": content.count("inline="),
    "pièges retail": content.count("PIÈGE RETAIL"),
    "bannière TENDANCE À SUIVRE": content.count("TENDANCE À SUIVRE"),
    "projection ICT": content.count("showProjection"),
    "lignes de tendance": content.count("trendSupLines") + content.count("trendResLines"),
    "confluences /6": content.count("cfScore"),
    "OB corps ch.4": content.count("obUseBody ?"),
    "breaker causal": content.count("f_create_breaker("),
    "mitigation ch.4": content.count("f_create_mitigation("),
    "MSS+displacement": content.count('hasDisp ? "MSS"'),
    "OTE 61.8-78.6": content.count("0.786"),
    "iFVG invalidés": content.count("inversedInvalid := true"),
    "table dims 26": content.count("2, 26, border_width=0"),
    "clear 25": content.count("table.clear(statusPanel, 0, 0, 1, 25)"),
}
required = {
    "titre v4": 1, "mode Auto (×ATR)": 5, "maxDevelopingBars": 2,
    "calc_on_every_tick": 1, "pièges retail": 2, "lignes cassure orange (chochColor)": 2,
    "équilibre violet (levelColor, 40)": 1, "table dims 26": 1, "clear 25": 1,
    "réglages inline (input inline)": 15,
}
for k, vmin in required.items():
    if markers.get(k, 0) < vmin:
        issues.append(f"Marqueur manquant '{k}': {markers.get(k, 0)} < {vmin}")

# 7) Comptage inputs par groupe
grp_counts = Counter(re.findall(r"group=G_(\w+)", content))

# 8) indentations multiples de 4
for idx, line in enumerate(lines):
    if not line.strip():
        continue
    m = re.match(r"^( +)\S", line)
    if m and len(m.group(1)) % 4 != 0:
        warns.append(f"L{idx+1}: indentation {len(m.group(1))} (pas multiple de 4)")

print("=" * 62)
print("VERIFICATION STATIQUE — wavescope_ict_v4.pine")
print("=" * 62)
print(f"Lignes : {len(lines)}   Fonctions : {len(func_defs)}   Inputs déclarés : {len(input_names)}")
print(f"Boucles gardées : {len(ok)}   Problèmes bloquants : {len(issues)}")
print()
print("--- PROBLEMES (bloquants) ---")
for i in issues:
    print("  ✗", i)
if not issues:
    print("  Aucun ✓")
print()
print("--- MARQUEURS v4 ---")
for k, v in markers.items():
    print(f"  {k}: {v}")
print()
print(f"--- INPUTS PAR GROUPE ({sum(grp_counts.values())}) ---")
for g, c in sorted(grp_counts.items()):
    print(f"  G_{g}: {c}")
print()
print(f"--- AVERTISSEMENTS ({len(warns)}) ---")
for w in warns[:15]:
    print("  ⚠", w)
if len(warns) > 15:
    print(f"  ... et {len(warns)-15} autres")
print()
print(f"Inputs dupliqués : {dup_inputs or 'aucun ✓'}")
sys.exit(1 if issues else 0)
