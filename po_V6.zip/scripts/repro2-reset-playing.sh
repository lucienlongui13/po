#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# REPRO 2 — RESET TRADES pendant la lecture X80 (sans pause)
# (le navigateur est déjà logué, replay ~467/1001, config martingale ON)
# ═══════════════════════════════════════════════════════════════════
cd /home/z/my-project
step() { echo ""; echo "════════ $1 ════════"; }
shot() { agent-browser screenshot "scripts/$1" >/dev/null 2>&1 && echo "📸 $1"; }

step "1. Reprise de la lecture X80"
agent-browser eval "
(() => {
  const b = document.querySelector('button[title=\"Play\"]');
  if (b) { b.click(); return 'PLAY'; }
  return 'PAS DE BOUTON PLAY (déjà en lecture ?)';
})()" 2>&1 | tail -1

step "2. Accumulation de trades (25 s)…"
sleep 25
agent-browser eval "
(() => {
  const t = document.body.textContent;
  const rows = document.querySelectorAll('table tbody tr').length;
  const stats = (t.match(/Trades\s*(\d+) \((\d+)W \/ (\d+)L/g) || [])[0] || '?';
  const bars = (t.match(/(\d+\/\d+) bars/) || [])[1] || '?';
  return 'AVANT reset → bars=' + bars + ' | lignes=' + rows + ' | ' + stats;
})()" 2>&1 | tail -1
shot repro2_01_avant_reset.png

step "3. RESET TRADES PENDANT LA LECTURE"
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('RESET TRADES'));
  if (!b) return 'BOUTON INTROUVABLE';
  b.click(); return 'RESET CLIQUÉ (lecture en cours)';
})()" 2>&1 | tail -1
sleep 2
agent-browser eval "
(() => {
  const rows = document.querySelectorAll('table tbody tr').length;
  const noTrades = document.body.textContent.includes('No simulated trades yet');
  return '+2s APRÈS reset → lignes=' + rows + ' | placeholder vide=' + (noTrades ? 'OUI' : 'NON');
})()" 2>&1 | tail -1
shot repro2_02_reset_plus_2s.png

step "4. Et 12 s plus tard (lecture X80 toujours en cours)…"
sleep 12
agent-browser eval "
(() => {
  const t = document.body.textContent;
  const rows = document.querySelectorAll('table tbody tr').length;
  const stats = (t.match(/Trades\s*(\d+) \((\d+)W \/ (\d+)L/g) || [])[0] || '?';
  const bars = (t.match(/(\d+\/\d+) bars/) || [])[1] || '?';
  const noTrades = t.includes('No simulated trades yet');
  return '+14s APRÈS reset → bars=' + bars + ' | lignes=' + rows + ' | placeholder vide=' + (noTrades ? 'OUI' : 'NON') + ' | ' + stats;
})()" 2>&1 | tail -1
shot repro2_03_reset_plus_14s.png

# pause pour analyse
agent-browser eval "
(() => {
  const b = document.querySelector('button[title=\"Pause\"]');
  if (b) { b.click(); return 'PAUSE'; }
  return '—';
})()" 2>&1 | tail -1
echo "══ REPRO 2 TERMINÉE ══"
