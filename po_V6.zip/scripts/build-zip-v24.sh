#!/bin/bash
# ════════════════════════════════════════════════════════════════════════
# build-zip-v24.sh — Livraison v24 « Étapes de vérification CISD
# OPTIONNELLES (cases à cocher) » (L_Lucien ProTrader + Ninja ProTrader
# + Strategy Tester).
# ════════════════════════════════════════════════════════════════════════
#
# MISSION v24 (demande utilisateur) :
#   « j'aimerais que ces étapes soient optionnelles — l'utilisateur a le
#     droit de choisir s'il veut activer les étapes de vérification et
#     validation CISD UP et CISD Down comme dans les cases à cocher.
#     L'utilisateur pourra aussi cocher s'il veut vérifier que le swing
#     high ou low est violé tout comme pas violé. Il peut aussi choisir
#     entre BOS Up + CISD Up ou CHoCH Up + CISD Up (cas d'un CALL) ou
#     encore entre BOS Down + CISD Down ou CHoCH Down + CISD Down (cas
#     d'un PUT). »
#
# Implémentation :
#   1. MOTEUR PARTAGÉ (shared/bos-choch-cisd.ts) — CisdGuardConfig
#      (up/down/swingMode/confirmBosUp/confirmChochUp/confirmBosDown/
#      confirmChochDown) + DEFAULT_CISD_GUARD_CONFIG (v23 intégral) +
#      normalizeCisdGuardConfig ; updateCisdGuard(config) : direction
#      décochée → garde neutre, swingMode 'violated' → arme sur sweep,
#      combos cochées seules confirment (combiné décoché = séquence
#      consommée sans ordre) ; evaluateBosChochCisdOrderRules laisse
#      passer l'ordre DIRECT (v22) pour une direction décochée ;
#      cisdConfirmation porte le swingMode d'armement.
#   2. WRAPPERS BACKEND (bos-choch-cisd-strategy.ts / ninja-protrader-
#      strategy.ts) : options.cisdGuardConfig passée à la poignée de
#      garde (PAR ASSET).
#   3. BACKEND index.ts : clés plates cisdGuard* dans StrategyConfig +
#      DEFAULT_CONFIG (v23) + set-auto-config (validation, reset des
#      séquences armées au changement) + auto-trade-status.cisdGuard +
#      strategy-state bosChochCisd.cisdGuard + libellés « swing …
#      intact/violé » et « CISD … direct (vérification désactivée) » +
#      restauration snapshot sanitisée.
#   4. PERSISTANCE : session-persistence.ts sanitise les 7 clés
#      cisdGuard* (re-login / redémarrage).
#   5. FRONTEND : hook use-pocket-option (statut + set-auto-config) ;
#      réglages localStorage (fusion profonde, partagé avec le Strategy
#      Tester) ; backtester applique les cases en temps réel (reset de
#      la séquence au changement, miroir du backend).
#   6. UI (auto-trade-panel.tsx) : bloc « Vérification CISD — étapes
#      optionnelles » : cases d'activation par direction, choix swing
#      NON violé / VIOLÉ, cases des combinaisons CALL ▲ (BOS/CHoCH) et
#      PUT ▼ (BOS/CHoCH), tableau récapitulatif des 3 étapes,
#      avertissements de configuration.
#
# Validation : tsc root 0 · tsc backend 0 · tsc SDK 0 · next build PASS
# (6/6) · test-v24-cisd-guard-config (NOUVEAU) 85 ✓ ·
# test-v24-cisd-config-e2e (NOUVEAU, vrai backend + faux broker S5) 42/42 ✓
# · test-v23-cisd-guard 96 ✓ · test-v23-cisd-e2e 31/31 ✓ · v22 unitaire
# 68 ✓ · v22-ninja-e2e 20/20 ✓ · bos-martingale-e2e 17/17 ✓ ·
# confirm-candle-cap-e2e 24/24 ✓ · auto-switch-rule-e2e 20/20 ✓ ·
# v21-rules-e2e 28/28 ✓ · multi-e2e 20/20 ✓ · tie-refund-e2e 24/24 ✓ ·
# v21-rules 61 ✓ · multi-assets ✓ · v63-features ✓ · v63-integration ✓ ·
# bos-strategy 22 ✓ · martingale-streak 12 ✓ · bos-expiry-martingale 39 ✓ ·
# confirm-candle-cap 59 ✓ · smart-stream-hardening PASS.
#
# Sortie : /home/z/my-project/download/pine_v6_engine_v24_cisd_guard_options.zip
# ════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v24"
FOLDER=pine_v6_engine
OUT="$ROOT/download/pine_v6_engine_v24_cisd_guard_options.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (structure identique aux zips v15-v23) ──────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude '.logs/' \
  --exclude '*.log' \
  --exclude 'winwinlogs.jsonl' \
  --exclude 'tsconfig.tsbuildinfo' \
  --exclude 'mini-services/iqoption-backend/data/backend-session.json' \
  --exclude 'mini-services/iqoption-backend/data/candle-cache/' \
  --exclude 'mini-services/iqoption-backend/e2e-*.log' \
  --exclude 'db/' \
  "$ROOT/pine_v6_engine/" "$STAGE/$FOLDER/"

# ── READMEs des versions précédentes (chaîne documentaire conservée) ────
unzip -q -o "$ROOT/download/pine_v6_engine_v23_cisd_swing_confirmation.zip" \
  "pine_v6_engine/README-V1.7-V23-CISD-SWING-CONFIRMATION.md" \
  "pine_v6_engine/README-V1.6-V22-NINJA-CANDLES-VALIDATION.md" \
  "pine_v6_engine/README-V1.6-V21-FINAL-RULES.md" \
  "pine_v6_engine/README-V1.6-V20-FINAL-FIXES.md" -d "$STAGE/"

# ── README de la version v24 ─────────────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.8-V24-CISD-GUARD-OPTIONS.md" <<'EOF'
# Pine v6 Engine — v24 « Étapes de vérification CISD optionnelles »

## Vos règles, vos cases à cocher

La v23 a introduit la vérification CISD (swing intact + confirmation
par signal combiné) **toujours active**. La v24 rend **chaque étape
OPTIONNELLE** : c'est vous qui choisissez, case par case, dans le
panneau **Auto Trade** (bloc « Vérification CISD — étapes optionnelles »,
sous le titre de la stratégie). La configuration est **partagée** par
L_Lucien ProTrader, Ninja ProTrader et le Strategy Tester.

```
┌────────────────────────────────────────────────────────────────────┐
│ Vérification CISD — étapes optionnelles                           │
│                                                                    │
│  [✓] Vérifier CISD UP            [✓] Vérifier CISD DOWN           │
│                                                                    │
│  Étape 1 — état du swing au CISD seul :                            │
│  [✓] Swing NON violé   [ ] Swing VIOLÉ                            │
│                                                                    │
│  Étape 3 — signal suivant accepté (confirmations) :                │
│  [✓] CALL ▲ · BOS Up + CISD Up     [✓] CALL ▲ · CHoCH Up + CISD Up │
│  [✓] PUT ▼ · BOS Down + CISD Down   [✓] PUT ▼ · CHoCH Down + CISD Down │
│                                                                    │
│  ┌──────────────┬───────────────────────┬───────────────────────┐ │
│  │ Étape        │ CISD UP               │ CISD DOWN             │ │
│  ├──────────────┼───────────────────────┼───────────────────────┤ │
│  │ 1. CISD seul │ swing high non violé  │ swing low non violé   │ │
│  │ 2. Swing conf│ séquence ARMÉE        │ séquence ARMÉE        │ │
│  │ 3. Signal su│ BOS/CHoCH … → CALL ▲  │ BOS/CHoCH … → PUT ▼   │ │
│  └──────────────┴───────────────────────┴───────────────────────┘ │
└────────────────────────────────────────────────────────────────────┘
```

## Les trois familles de cases

### 1. Activation par direction — « Vérifier CISD UP » / « Vérifier CISD DOWN »

- **Cochée (défaut)** : la protection v23 complète — un CISD seul
  n'ordonne JAMAIS, il arme une séquence ; l'ordre ne part qu'au
  signal combiné suivant ;
- **Décochée** : retour au comportement **v22** — les combinaisons CISD
  de cette direction (ex. `[CISD Up]` ou `[BOS Up + CISD Up]`) placent
  leurs ordres **directement**, sans vérification du swing ni attente
  de confirmation. Les libellés d'ordre portent alors
  « **CISD Up direct (vérification désactivée)** ».

Les deux directions sont indépendantes : vous pouvez protéger les PUT
tout en laissant les CALL directs, ou l'inverse.

### 2. État du swing — « Swing NON violé » / « Swing VIOLÉ »

Au moment du CISD seul (étape 1), le programme vérifie le swing le plus
proche — celui que le CISD franchit :

- **Swing NON violé (défaut v23)** : la séquence s'arme si AUCUNE
  bougie intermédiaire (mèche ou clôture) n'a dépassé le niveau depuis
  sa formation ;
- **Swing VIOLÉ** : la séquence s'arme si le swing a AU CONTRAIRE été
  balayé (**sweep de liquidité**) avant le signal — un style de
  détection d'absorption de liquidité. Un swing intact est alors
  refusé (« INTACT alors que le mode exige un swing VIOLÉ »).

Le mode s'applique aux deux directions (le libellé d'ordre documente
l'état constaté : « swing 1.20304 intact » ou « swing 1.20304 violé »).

### 3. Combinaisons de confirmation — étape 3

Après l'armement, quel signal suivant a le droit de déclencher l'ordre ?

- **CALL ▲** : cochez `BOS Up + CISD Up` et/ou `CHoCH Up + CISD Up` ;
- **PUT ▼** : cochez `BOS Down + CISD Down` et/ou `CHoCH Down + CISD Down`.

Un signal combiné **décoché** qui arrive après l'armement **consomme la
séquence sans ordre** (refus « NON ACCEPTÉ comme confirmation »). Si
vous décochez les deux combinaisons d'une direction, aucune séquence de
cette direction ne pourra jamais être confirmée — le panneau vous le
signale explicitement.

## Comportement détaillé

| Situation | Case cochée (v23) | Case décochée (v22) |
|---|---|---|
| CISD Up seul, swing intact | ARMÉE — aucun ordre, attente | **CALL ▲ immédiat** |
| CISD Up seul, swing violé | REFUS (mode « non violé ») | **CALL ▲ immédiat** |
| Combiné BOS/CHoCH après armement | ordre CALL ▲ si combo coché | **CALL ▲ immédiat** |
| Combiné d'emblée (cassure profonde) | REFUS — protection du solde | **CALL ▲ immédiat** |

- **Ninja ProTrader** : les cases s'appliquent à l'identique — décochée,
  l'ordre part **pendant** la bougie CISD (avant clôture) ; cochée, la
  séquence armement → confirmation reste exigée ;
- **Strategy Tester** : le backtesting applique les MÊMES cases en
  temps réel (toute modification s'applique immédiatement) ;
- **Changement de cases** : les séquences armées en cours sont
  **réinitialisées** (elles vivaient sous l'ancienne configuration) —
  miroir du comportement backend ;
- **Persistance** : les cases survivent au re-login / redémarrage
  (snapshot session + localStorage) ; « Reset pack » les restaure au
  défaut v23 intégral.

## Libellés d'ordre (v24)

```
… · CISD Up confirmé (armé bougie 1790112375, swing 1.2038 intact)
… · CISD Up confirmé (armé bougie 1790112595, swing 1.2019 violé)   ← mode « swing violé »
… · CISD Up direct (vérification désactivée)                        ← case UP décochée
```

## Validation

```bash
# 1. Installer et démarrer
npm install && cd mini-services/iqoption-backend && npm install

# 2. Typecheck + build
cd ../.. && npx tsc --noEmit && npx next build

# 3. Nouveautés v24
npx tsx scripts/test-v24-cisd-guard-config.ts      # 85 ✓
cd mini-services/iqoption-backend
node tests/test-v24-cisd-config-e2e.mjs           # 42/42 (vrai backend + faux broker)

# 4. Non-régression
npx tsx scripts/test-v23-cisd-guard.ts             # 96 ✓
node tests/test-v23-cisd-e2e.mjs                   # 31/31
node tests/test-v22-ninja-e2e.mjs                  # 20/20
```

Dans l'application :
- **Auto Trade → L_Lucien ProTrader** : décochez « Vérifier CISD UP »
  → un ordre CISD Up part immédiatement (libellé « direct ») ; cochez
  « Swing VIOLÉ » → les CISD sur swing intact sont refusés ;
- **Auto Trade → Ninja ProTrader** : mêmes cases, ordre avant clôture ;
- **Replay → Strategy Tester** : le backtest suit les cases en temps
  réel — comparez le winRate avec/sans protection avant de trader en
  réel.
EOF

cd "$STAGE"
zip -qr "$OUT" "$FOLDER"
cd "$ROOT"
rm -rf "$STAGE"
echo "─ Livraison v24 ─────────────────────────────────────────────"
echo "Zip      : $OUT"
echo "Taille   : $(du -h "$OUT" | cut -f1)"
echo "Fichiers : $(unzip -l "$OUT" | tail -1 | awk '{print $2}')"
echo "Intégrité: $(unzip -t "$OUT" > /dev/null && echo OK || echo ÉCHEC)"
sha256sum "$OUT"
md5sum "$OUT"
