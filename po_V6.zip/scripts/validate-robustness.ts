/**
 * validate-robustness.ts — Secondary validation (NOT used for tuning).
 *
 * 20 additional trades with fresh seeds + horizon variants (20/25/30/35),
 * same regime-script grammar. Confirms the production model is not
 * over-fitted to the official 10-trade set.
 */
import { smartTraderProjection, smartTraderProjectionV0 } from '../src/lib/smart-trader-projection.js'
import {
  genSeries, swingExtremes, runTrade, summarize, HORIZON,
  type TradeCase, type CandleLike, type ModelLike,
} from './eval-smart-trader-lib.js'

const mk = (id: number, seed: number, start: number, sigma: number, segs: any[], now: number, horizon = HORIZON): TradeCase =>
  ({ id, name: `V${id}`, gen: { seed, start, sigma, segs }, nowOffset: now })

const CASES: TradeCase[] = [
  // trend continuations (fresh seeds)
  mk(1, 1101, 1.0850, 0.00042, [{ kind: 'range', bars: 120 }, { kind: 'trendUp', bars: 200 }, { kind: 'trendUp', bars: 90 }], 320),
  mk(2, 1102, 1.2010, 0.00040, [{ kind: 'range', bars: 110 }, { kind: 'trendDown', bars: 210 }, { kind: 'trendDown', bars: 90 }], 320),
  mk(3, 1103, 0.9820, 0.00038, [{ kind: 'range', bars: 90 }, { kind: 'trendUp', bars: 230 }, { kind: 'trendUp', bars: 80 }], 310),
  mk(4, 1104, 0.6650, 0.00035, [{ kind: 'range', bars: 130 }, { kind: 'trendDown', bars: 180 }, { kind: 'trendDown', bars: 90 }], 300),
  // retraces after impulse
  mk(5, 1105, 0.9820, 0.00038, [{ kind: 'range', bars: 100 }, { kind: 'trendUp', bars: 220 }, { kind: 'range', bars: 90, kappa: 0.02, span: 150 }], 330),
  mk(6, 1106, 0.6650, 0.00035, [{ kind: 'range', bars: 100 }, { kind: 'trendDown', bars: 220 }, { kind: 'range', bars: 90, kappa: 0.02, span: 150 }], 330),
  mk(7, 1107, 1.2010, 0.00040, [{ kind: 'range', bars: 90 }, { kind: 'trendUp', bars: 240 }, { kind: 'range', bars: 80, kappa: 0.02, span: 150 }], 325),
  // squeeze breakouts
  mk(8, 1108, 1.0500, 0.00045, [{ kind: 'range', bars: 150 }, { kind: 'squeeze', bars: 190 }, { kind: 'breakoutUp', bars: 60 }], 345),
  mk(9, 1109, 0.8150, 0.00044, [{ kind: 'range', bars: 150 }, { kind: 'squeeze', bars: 190 }, { kind: 'breakdown', bars: 60 }], 345),
  mk(10, 1110, 0.9510, 0.00041, [{ kind: 'range', bars: 160 }, { kind: 'squeeze', bars: 170 }, { kind: 'breakdown', bars: 70 }], 325),
  // ranges + reversal
  mk(11, 1111, 1.3100, 0.00030, [{ kind: 'range', bars: 340 }], 285),
  mk(12, 1112, 0.7420, 0.00028, [{ kind: 'range', bars: 340 }], 285),
  mk(13, 1113, 0.9510, 0.00040, [{ kind: 'trendUp', bars: 300 }, { kind: 'squeeze', bars: 130 }, { kind: 'trendDown', bars: 60 }], 435),
  mk(14, 1114, 1.1310, 0.00050, [{ kind: 'trendDown', bars: 300 }, { kind: 'squeeze', bars: 130 }, { kind: 'trendUp', bars: 60 }], 435),
  // horizon variants
  mk(15, 1115, 1.0850, 0.00042, [{ kind: 'range', bars: 120 }, { kind: 'trendUp', bars: 200 }, { kind: 'trendUp', bars: 90 }], 320, 20),
  mk(16, 1116, 0.6650, 0.00035, [{ kind: 'range', bars: 100 }, { kind: 'trendDown', bars: 220 }, { kind: 'range', bars: 90, kappa: 0.02, span: 150 }], 330, 20),
  mk(17, 1117, 1.0500, 0.00045, [{ kind: 'range', bars: 150 }, { kind: 'squeeze', bars: 190 }, { kind: 'breakoutUp', bars: 60 }], 345, 40),
  mk(18, 1118, 0.8150, 0.00044, [{ kind: 'range', bars: 150 }, { kind: 'squeeze', bars: 190 }, { kind: 'breakdown', bars: 60 }], 345, 40),
  mk(19, 1119, 1.2010, 0.00040, [{ kind: 'range', bars: 110 }, { kind: 'trendDown', bars: 210 }, { kind: 'trendDown', bars: 90 }], 320, 25),
  mk(20, 1120, 0.9820, 0.00038, [{ kind: 'range', bars: 100 }, { kind: 'trendUp', bars: 220 }, { kind: 'range', bars: 90, kappa: 0.02, span: 150 }], 330, 35),
]

function evalModel(name: string, model: ModelLike) {
  const results = []
  for (const tc of CASES) {
    try {
      const r = runTrade(tc, model)
      if (r) results.push(r)
    } catch (e) {
      console.log(`  case ${tc.id}: ${e instanceof Error ? e.message : String(e)}`)
    }
  }
  const s = summarize(results)
  console.log(` ${name}: ${s.wins}/${s.total} strict = ${s.strictWR.toFixed(1)}% | issued ${s.wins}/${s.issued} = ${s.issuedWR.toFixed(1)}% | WAIT ${s.waits}`)
  return s
}

console.log('=== SECONDARY VALIDATION (20 fresh-seed trades + horizon variants) ===')
const v2 = evalModel('v2 (production)', smartTraderProjection)
evalModel('v0 (baseline) ', smartTraderProjectionV0)
console.log('')

// Directional accuracy by family (v2)
const fams: Array<[string, number[]]> = [
  ['trend continuation', [1, 2, 3, 4, 15, 19]],
  ['retrace/bounce     ', [5, 6, 7, 16, 20]],
  ['squeeze breakout   ', [8, 9, 10, 17, 18]],
  ['range / reversal   ', [11, 12, 13, 14]],
]
for (const [name, ids] of fams) {
  const rs = v2.results.filter(r => ids.includes(r.id))
  const w = rs.filter(r => r.win).length
  const t = rs.length
  console.log(`  ${name}: ${w}/${t}`)
}

// Perf smoke test: 200 consecutive calls on a 400-bar series
{
  const series = genSeries({ seed: 1115, start: 1.085, sigma: 0.00042, segs: [{ kind: 'range', bars: 120 }, { kind: 'trendUp', bars: 200 }, { kind: 'trendUp', bars: 90 }] })
  const visible = series.slice(0, 321)
  const anchors = swingExtremes(visible, 45)
  const t0 = performance.now()
  for (let i = 0; i < 200; i++) smartTraderProjection(visible, HORIZON, anchors.hi, anchors.lo)
  const dt = performance.now() - t0
  console.log(`\n Perf: 200 calls × 321 candles in ${dt.toFixed(1)} ms (${(dt / 200).toFixed(2)} ms/call)`)
}
