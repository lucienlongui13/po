import { runPineScript } from '../src/lib/pine-engine.ts'
import { readFileSync } from 'node:fs'

function makeCandles(n, seed0) {
  const bars = []
  let price = 100
  let seed = seed0
  const rand = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648 }
  for (let i = 0; i < n; i++) {
    // Pure sine: equal peaks and equal troughs, slow period, tiny noise
    const target = 100 + Math.sin(i / 20) * 3
    const open = price
    const close = target + (rand() - 0.5) * 0.05
    const high = Math.max(open, close) + rand() * 0.02
    const low = Math.min(open, close) - rand() * 0.02
    bars.push({ time: 1_700_000_000 + i * 60, open, high, low, close, volume: 100 })
    price = close
  }
  return bars
}

for (const name of ['pattern_1.pine', 'pattern_2.pine', 'pattern_4.pine', 'pattern_5.pine', 'pattern_6.pine', 'pattern_7.pine', 'pattern_8.pine']) {
  const source = readFileSync(`TradingView_pine_scripts_samples/${name}`, 'utf8')
  const candles = makeCandles(1500, 42)
  const res = await runPineScript(source, candles, { symbol: 'X', timeframe: '1' })
  if (res.ok) {
    const types = {}
    for (const d of res.result.drawings) types[d.kind] = (types[d.kind] ?? 0) + 1
    console.log(`${name}: OK — drawings=${JSON.stringify(types)} alerts=${res.result.alerts.length}`)
  } else {
    console.log(`${name}: ${res.error.stage}: ${res.error.message.slice(0, 70)}`)
  }
}
