/**
 * compat-sweep.ts — run EVERY user-provided TradingView sample script through
 * the engine (real 2242-bar dataset) and report ok/error + output profile.
 * Guards the "all different kind of scripts from TradingView are compatible"
 * requirement. Overlay=false scripts are expected to produce pane-routable
 * outputs (plots/hlines); overlay=true produce drawings/plots glued to price.
 */
import { runPineScript, deriveMintick } from '../src/lib/pine-engine'
import { importLibraryBundle } from '../src/lib/pine-libraries'
import { readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'

const SAMPLES = 'TradingView_pine_scripts_samples'
const LIB_DIR = 'upload/piracy_extracted/Market_structures_scripts'

// register the example pack libraries (some samples import them)
importLibraryBundle([
  { name: 'libs/PubLibCandleTrend.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibCandleTrend.pine'), 'utf8') },
  { name: 'libs/PubLibSwing.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibSwing.pine'), 'utf8') },
  { name: 'libs/PubLibTrend.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibTrend.pine'), 'utf8') },
  { name: 'libs/PubLibUtility.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibUtility.pine'), 'utf8') },
  { name: 'Main.pine', source: readFileSync(join(LIB_DIR, 'Main.pine'), 'utf8') },
])

const raw = JSON.parse(readFileSync('scripts/dataset-eurusd-m1.json', 'utf8')) as any[]
const dataset = (Array.isArray(raw) ? raw : raw.candles ?? raw.data ?? []).map((c: any) => ({
  time: Number(c.time), open: Number(c.open), high: Number(c.high), low: Number(c.low), close: Number(c.close),
  volume: Number(c.volume ?? 0),
}))

const mintick = deriveMintick(dataset as any)
console.log(`dataset: ${dataset.length} bars · derived mintick: ${mintick}`)
console.log('')

const files = readdirSync(SAMPLES).filter((f) => f.endsWith('.pine')).sort()
let pass = 0, fail = 0
async function main() {
for (const f of files) {
  const src = readFileSync(join(SAMPLES, f), 'utf8')
  try {
    const res = await runPineScript(src, dataset as any, { symbol: 'EURUSD_otc', timeframe: '1' })
    if (res.ok) {
      pass++
      const r = res.result
      const profile = [
        r.overlay ? 'overlay' : 'PANE',
        `${r.drawings.length}dw`,
        `${r.plots.length}pl`,
        `${r.markers.length}mk`,
        `${r.hlines.length}hl`,
        `${r.alerts.length}al`,
      ].join(' ')
      // alignment sanity for overlay drawings
      let glue = ''
      if (r.overlay && r.drawings.length) {
        const prices: number[] = []
        for (const d of r.drawings) {
          if (d.kind === 'line') prices.push(d.y1, d.y2)
          else if (d.kind === 'label' && d.y != null) prices.push(d.y)
          else if (d.kind === 'box') prices.push(d.top, d.bottom)
        }
        if (prices.length) {
          const minLow = Math.min(...dataset.map(c => c.low))
          const maxHigh = Math.max(...dataset.map(c => c.high))
          const tol = (maxHigh - minLow) * 3 + maxHigh * 0.02
          const dMin = Math.min(...prices), dMax = Math.max(...prices)
          const glued = dMin >= minLow - tol && dMax <= maxHigh + tol
          glue = glued ? '· glued ✓' : `· RANGE? [${dMin.toFixed(4)}, ${dMax.toFixed(4)}] vs candles [${minLow.toFixed(4)}, ${maxHigh.toFixed(4)}]`
        }
      }
      console.log(`  ✓ ${f.padEnd(24)} ${profile} ${glue}`)
    } else {
      fail++
      console.log(`  ✗ ${f.padEnd(24)} ${res.error.stage}: ${res.error.message.slice(0, 90)}`)
    }
  } catch (e) {
    fail++
    console.log(`  ✗ ${f.padEnd(24)} THROW: ${String(e).slice(0, 90)}`)
  }
}

console.log(`\n════ compat sweep : ${pass} ✓ · ${fail} ✗ / ${files.length} scripts ════`)
if (fail > 0) process.exit(1)
}
main().catch((e) => { console.error('SWEEP FAILURE', e); process.exit(1) })
