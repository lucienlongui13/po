/**
 * campaign-orchestrator.mjs — Campagne de tests réels L_Lucien ProTrader (v19).
 * ====================================================================
 * Mission utilisateur (2026-09-20) :
 *   - Login identifiants test par défaut (codés en dur, mode démo)
 *   - Toutes les combinaisons CALL ▲ / PUT ▼ (BOS/CHoCH/CISD Up/Down)
 *   - 2 vagues d'expiration par timeframe (ex. S5 : 5 s puis 10 s)
 *   - 40 ordres par timeframe, 2 assets OTC (EURUSD_otc + GBPUSD_otc)
 *   - Mise de base 10, martingale ACTIVE (garde-fou maxMartingaleSteps 5),
 *     confirmation bougie précédente OFF
 *   - Rapport JSON complet : attribution ordre→combinaison (matchedRuleId),
 *     règlements, payouts, martingale, solde.
 *
 * Exécution (détaché conseillé) :
 *   node scripts/campaign-orchestrator.mjs --tf 5 --expiry1 5 --expiry2 10 \
 *     --orders 40 --out /tmp/campaign-s5.json
 */
import { io } from 'socket.io-client';
import { spawn } from 'node:child_process';
import * as fs from 'node:fs';
import * as net from 'node:net';
import * as path from 'node:path';

/* ── CLI ── */
const args = process.argv.slice(2);
const arg = (name, def) => {
  const i = args.indexOf(`--${name}`);
  return i >= 0 && args[i + 1] != null ? args[i + 1] : def;
};
const TF = Number(arg('tf', 5));                    // timeframe bougies (s)
const TARGET_ORDERS = Number(arg('orders', 40));
const EXP1 = Number(arg('expiry1', 5));             // expiration vague 1 (s)
const EXP2 = Number(arg('expiry2', 10));            // expiration vague 2 (s)
const OUT = arg('out', `/tmp/campaign-s${TF}.json`);
const ASSETS = arg('assets', 'EURUSD_otc,GBPUSD_otc').split(',');
const BASE = Number(arg('base', 10));
const MAX_STEPS = Number(arg('max-steps', 5));      // garde-fou martingale
const MAX_MINUTES = Number(arg('max-minutes', 45)); // mur d'horloge
const REUSE_BACKEND = args.includes('--reuse-backend');
const PROGRESS = arg('progress', `/tmp/campaign-s${TF}.progress.log`);
// --rules "p-bos:10" ou "c-bos,c-cisd:20" ou "all" (défaut : les 6 combinaisons)
const RULES_FILTER = arg('rules', 'all');

const URL = 'http://127.0.0.1:3030';
const EMAIL = 'longuilcn@gmail.com';               // identifiants par défaut (page.tsx)
const PASSWORD = 'Jean-Paul@#1964';
const BACKEND_DIR = path.resolve(process.cwd(), 'mini-services/iqoption-backend');
const ROOT_DIR = path.resolve(process.cwd());

const sleep = ms => new Promise(r => setTimeout(r, ms));
const hhmmss = ts => new Date(ts).toISOString().slice(11, 19);
const now = () => Date.now();

function progress(obj) {
  const line = JSON.stringify({ ts: new Date().toISOString(), ...obj });
  fs.appendFileSync(PROGRESS, line + '\n');
  console.log(`[${hhmmss(now())}] ${JSON.stringify(obj)}`);
}

/* ═══════════════ Règles : 6 combinaisons, 1 alerte chacune ═══════════════ */
const ALL_COMBOS = [
  { id: 'c-bos', alerts: ['BOS Up'] },
  { id: 'c-choch', alerts: ['CHoCH Up'] },
  { id: 'c-cisd', alerts: ['CISD Up'] },
  { id: 'p-bos', alerts: ['BOS Down'] },
  { id: 'p-choch', alerts: ['CHoCH Down'] },
  { id: 'p-cisd', alerts: ['CISD Down'] },
];
function activeCombos() {
  if (RULES_FILTER === 'all') return ALL_COMBOS.map(c => ({ ...c }));
  return RULES_FILTER.split(',').map(tok => tok.trim()).filter(Boolean).map(tok => {
    const [id, exp] = tok.split(':');
    const base = ALL_COMBOS.find(c => c.id === id);
    if (!base) throw new Error(`règle inconnue: ${id}`);
    return { ...base, fixedExp: exp != null ? Number(exp) : null };
  });
}
const rulesAt = (exp) => {
  const combos = activeCombos().map(c => ({ id: c.id, alerts: c.alerts, expirationSeconds: c.fixedExp ?? exp }));
  return {
    callRules: combos.filter(c => c.id.startsWith('c-')),
    putRules: combos.filter(c => c.id.startsWith('p-')),
  };
};

/* ═══════════════ Backend lifecycle ═══════════════ */
function portOpen(port) {
  return new Promise(res => {
    const s = net.connect({ port, host: '127.0.0.1', timeout: 1200 }, () => { s.destroy(); res(true); });
    s.on('error', () => res(false));
    s.on('timeout', () => { s.destroy(); res(false); });
  });
}

let spawnedChild = null;
async function ensureBackend() {
  if (await portOpen(3030)) { progress({ phase: 'backend', msg: 'backend déjà actif sur :3030 (réutilisé)' }); return; }
  const out = fs.openSync(`/tmp/backend-campaign-s${TF}.log`, 'a');
  spawnedChild = spawn(process.execPath, ['--import', 'tsx', 'index.ts'], {
    cwd: BACKEND_DIR, detached: true, stdio: ['ignore', out, out],
  });
  spawnedChild.unref();
  progress({ phase: 'backend', msg: `backend démarré (pid ${spawnedChild.pid})` });
  for (let i = 0; i < 40; i++) { await sleep(1000); if (await portOpen(3030)) return; }
  throw new Error('backend non prêt après 40 s');
}

/* ═══════════════ État de la campagne ═══════════════ */
const state = {
  campaignStartTs: null,
  login: null,
  startBalance: null,
  balance: null,
  balanceTimeline: [],
  orders: new Map(),        // dealId → order
  pendingSignals: new Map(),// asset → dernier signal non-hold (attribution)
  signals: [],               // tous les strategy-state non-hold (stats fréquence)
  settlements: [],          // trade-closed bruts
  logs: [],                 // logs backend filtrés (diagnostic + réparation)
  wave: 1,
  wave2Applied: false,
  stopped: false,
  finalStatus: null,
};

function attributedOrder(dealId) { return state.orders.get(dealId); }

function save(extra = {}) {
  const report = {
    when: new Date().toISOString(),
    config: {
      timeframe: `S${TF}`, targetOrders: TARGET_ORDERS, assets: ASSETS,
      base: BASE, maxMartingaleSteps: MAX_STEPS, confirmCandle: false,
      betting: 'martingale', wave1Expiry: EXP1, wave2Expiry: EXP2,
      email: EMAIL, mode: 'demo', strategy: 'l_lucien_protrader',
    },
    login: state.login,
    startBalance: state.startBalance,
    balance: state.balance,
    balanceTimeline: state.balanceTimeline,
    orders: [...state.orders.values()],
    signals: state.signals,
    settlements: state.settlements,
    logs: state.logs,
    finalStatus: state.finalStatus,
    ...extra,
  };
  fs.writeFileSync(OUT, JSON.stringify(report, null, 2));
}

/* ═══════════════ Main ═══════════════ */
async function main() {
  fs.writeFileSync(PROGRESS, '');
  progress({ phase: 'start', msg: `campagne S${TF} — ${TARGET_ORDERS} ordres, vagues exp ${EXP1}s→${EXP2}s, base ${BASE}, martingale cap ${MAX_STEPS}, confirmation OFF` });

  await ensureBackend();
  const socket = io(URL, { transports: ['websocket'], path: '/', reconnection: false, timeout: 10000 });

  /* ── Monitoring passif ── */
  socket.on('status', (s) => {
    if (s?.balance != null && typeof s.balance === 'object') {
      state.balance = s.balance.amount;
      state.balanceTimeline.push({ ts: now(), balance: s.balance.amount, currency: s.balance.currency });
    }
  });
  socket.on('log', (ev) => {
    const m = String(ev?.message ?? '');
    if (/signal accepted|trade opened|trade result|martingale|BLOCKED|bloqué|auto-trade|expiration|AUTO-RELOGIN|error|refusé/i.test(m)) {
      state.logs.push({ ts: ev?.ts ?? now(), level: ev?.level, message: m });
      if (state.logs.length < 4000) { /* garde mémoire */ }
    }
  });
  socket.on('strategy-state', (st) => {
    if (!st || !st.asset) return;
    if (st.strategyId && st.strategyId !== 'l_lucien_protrader') return;
    const action = st.action;
    if (action && action !== 'hold') {
      const sig = {
        ts: now(), asset: st.asset, action,
        matchedRuleId: st.matchedRuleId ?? null,
        events: st.events ?? (st.bosChochCisd?.events ?? []),
        expiry: st.bosChochCisd?.orderExpirationSeconds ?? null,
        reason: st.reason ?? '',
      };
      state.pendingSignals.set(st.asset, sig);
      state.signals.push(sig);
    }
  });
  socket.on('trade-opened', (ev) => {
    const dealId = String(ev?.deal?.id ?? '');
    if (!dealId) return;
    if (state.campaignStartTs == null || now() < state.campaignStartTs) return;
    const existing = state.orders.get(dealId);
    if (existing) {
      if (ev?.source === 'l_lucien_protrader') existing.source = 'l_lucien_protrader';
      if (ev?.expirationSeconds != null) existing.expirationSeconds = ev.expirationSeconds;
      if (ev?.source && !existing.sources.includes(ev.source)) existing.sources.push(ev.source);
      return;
    }
    const pending = state.pendingSignals.get(ev?.asset);
    const fresh = pending && now() - pending.ts < 6000;
    const isStrategy = ev?.source === 'l_lucien_protrader';
    if (!isStrategy && !fresh) return; // ordre manuel/hors campagne — ignoré
    const sig = fresh ? pending : null;
    if (sig) state.pendingSignals.delete(ev.asset);
    const o = {
      n: state.orders.size + 1, dealId, ts: now(), asset: ev?.asset,
      action: ev?.deal?.action ?? sig?.action, amount: Number(ev?.deal?.amount ?? 0),
      openPrice: ev?.deal?.openPrice, expirationSeconds: ev?.expirationSeconds ?? null,
      source: ev?.source, sources: [ev?.source],
      matchedRuleId: sig?.matchedRuleId ?? null, events: sig?.events ?? [],
      reason: sig?.reason ?? null, signalTs: sig?.ts ?? null,
      settled: false, result: null, profit: null, payoutPct: null, settleTs: null,
    };
    state.orders.set(dealId, o);
    progress({ phase: 'order', n: o.n, asset: o.asset, action: o.action, amount: o.amount, expiry: o.expirationSeconds, rule: o.matchedRuleId, wave: state.wave });
  });
  socket.on('trade-closed', (ev) => {
    const dealId = String(ev?.deal?.id ?? '');
    if (!dealId) return;
    const profit = Number(ev?.profit ?? 0);
    const result = profit > 0 ? 'WIN' : profit < 0 ? 'LOSS' : 'TIE';
    state.settlements.push({ ts: now(), asset: ev?.asset, dealId, profit, isWin: !!ev?.isWin, result, action: ev?.deal?.action });
    const o = state.orders.get(dealId);
    if (o && !o.settled) {
      o.settled = true; o.result = result; o.profit = profit; o.settleTs = now();
      if (result === 'WIN') o.payoutPct = Number(((profit / o.amount) * 100).toFixed(1));
      progress({ phase: 'settle', n: o.n, asset: o.asset, result, profit, payout: o.payoutPct, balance: state.balance });
    }
  });

  /* ── 1. Connexion ── */
  const connected = await new Promise(r => {
    socket.once('connect', () => r(true));
    socket.once('connect_error', () => r(false));
    setTimeout(() => r(false), 12000);
  });
  if (!connected) { progress({ phase: 'fatal', msg: 'backend injoignable' }); save({ fatal: 'backend unreachable' }); process.exit(1); }

  /* ── 2. Login (identifiants par défaut, mode démo) ── */
  progress({ phase: 'login', msg: `login ${EMAIL} (demo)` });
  const loginResult = await new Promise(r => {
    socket.once('login-result', r);
    socket.emit('login', { email: EMAIL, password: PASSWORD, mode: 'demo' });
    setTimeout(() => r({ ok: false, error: 'timeout 90s' }), 90000);
  });
  if (!loginResult?.ok) {
    progress({ phase: 'fatal', msg: `login échoué: ${JSON.stringify(loginResult)}` });
    save({ fatal: 'login failed', loginResult }); process.exit(1);
  }
  state.login = { uid: loginResult.user_id, mode: loginResult.mode, resumed: !!loginResult.resumed };
  progress({ phase: 'login', msg: `OK uid=${loginResult.user_id} mode=${loginResult.mode}` });

  // Purge du burst de règlements de sessions précédentes + récupération solde
  await sleep(15000);
  state.startBalance = state.balance;
  progress({ phase: 'login', msg: `solde départ ${state.startBalance} (devise ${state.balanceTimeline[0]?.currency ?? '?'})` });

  /* ── 3. Timeframe ── */
  progress({ phase: 'config', msg: `timeframe S${TF} (candleSize=${TF}, cooldown 3s)` });
  socket.emit('set-config', { candleSize: TF, cooldownSeconds: 3 });
  await sleep(800);

  /* ── 4. Assets ── */
  progress({ phase: 'config', msg: `sélection assets ${ASSETS.join(' + ')}` });
  const selected = await new Promise(r => {
    socket.once('assets-selected', r);
    socket.emit('select-assets', { mode: 'multi', assets: ASSETS });
    setTimeout(() => r({ ok: false, error: 'timeout 30s' }), 30000);
  });
  if (!selected?.ok) { progress({ phase: 'fatal', msg: `select-assets échoué: ${JSON.stringify(selected)}` }); save({ fatal: 'select-assets failed', selected }); process.exit(1); }
  progress({ phase: 'config', msg: `assets actifs ${JSON.stringify(selected.assets)} focus=${selected.focus}` });
  await sleep(12000); // warm-up streams + historique bougies

  /* ── 5. Stratégie ── */
  socket.emit('set-auto-strategy', { strategyId: 'l_lucien_protrader' });
  await sleep(1000);

  /* ── 6. Config mises + règles (vague 1) ── */
  // Reset ceinture+bretelles des streaks hérités : fixed → martingale remet à 0.
  socket.emit('set-auto-config', { bettingStrategy: 'fixed' });
  await sleep(600);
  socket.emit('set-auto-config', {
    bettingStrategy: 'martingale',
    baseAmount: BASE,
    maxMartingaleSteps: MAX_STEPS,
    bosChochCisdConfirmCandle: false,           // confirmation bougie précédente OFF
    bosChochCisdBosUp: true, bosChochCisdBosDown: true,
    bosChochCisdChochUp: true, bosChochCisdChochDown: true,
    bosChochCisdCisdUp: true, bosChochCisdCisdDown: true,
    bosChochCisdCallRules: rulesAt(EXP1).callRules,
    bosChochCisdPutRules: rulesAt(EXP1).putRules,
  });
  socket.emit('set-config', { margin: String(BASE), bettingStrategy: 'martingale', cooldownSeconds: 3 });
  await sleep(800);

  /* ── 7. Vérification config ── */
  const status1 = await new Promise(r => {
    socket.once('auto-trade-status', r);
    socket.emit('get-auto-status');
    setTimeout(() => r(null), 8000);
  });
  const cfgOk = status1 && status1.strategyId === 'l_lucien_protrader' && status1.bettingStrategy === 'martingale'
    && Number(status1.baseAmount) === BASE && status1.maxMartingaleSteps === MAX_STEPS
    && status1.bosChochCisdConfirmCandle === false;
  progress({ phase: 'config', msg: `vérif config: strategy=${status1?.strategyId} betting=${status1?.bettingStrategy} base=${status1?.baseAmount} cap=${status1?.maxMartingaleSteps} confirm=${status1?.bosChochCisdConfirmCandle} → ${cfgOk ? 'OK' : 'ÉCHEC'}` });
  if (!cfgOk) { save({ fatal: 'bad config', status1 }); process.exit(1); }

  /* ── 8. ACTIVATION ── */
  const autoOn = await new Promise(r => {
    socket.once('auto-trade-status', r);
    socket.emit('set-auto-trade', { enabled: true });
    setTimeout(() => r(null), 10000);
  });
  if (!autoOn?.enabled) { progress({ phase: 'fatal', msg: 'auto-trade non activé' }); save({ fatal: 'auto-trade not enabled', autoOn }); process.exit(1); }
  state.campaignStartTs = now();
  progress({ phase: 'run', msg: `CAMPAGNE ACTIVE — cible ${TARGET_ORDERS} ordres (vague 1/2 : ${EXP1}s → ${EXP2}s)` });

  /* ── 9. Boucle de surveillance ── */
  const deadline = now() + MAX_MINUTES * 60 * 1000;
  let lastProgress = 0;
  while (true) {
    const orders = [...state.orders.values()];
    const placed = orders.length;
    const settled = orders.filter(o => o.settled).length;

    // Bascule vague 2 à mi-course
    if (!state.wave2Applied && placed >= Math.ceil(TARGET_ORDERS / 2)) {
      state.wave2Applied = true; state.wave = 2;
      socket.emit('set-auto-config', {
        bosChochCisdCallRules: rulesAt(EXP2).callRules,
        bosChochCisdPutRules: rulesAt(EXP2).putRules,
      });
      progress({ phase: 'wave', msg: `VAGUE 2 — expiration ${EXP2}s appliquée (${placed} ordres placés)` });
    }

    // Arrêt : cible atteinte ou mur d'horloge
    if (!state.stopped && (placed >= TARGET_ORDERS || now() > deadline)) {
      state.stopped = true;
      const reason = placed >= TARGET_ORDERS ? 'cible atteinte' : `timeout ${MAX_MINUTES} min`;
      progress({ phase: 'stop', msg: `ARRÊT (${reason}) à ${placed} ordres — suspension PAR ASSET (boucle vivante) + drain` });
      for (const a of ASSETS) socket.emit('set-auto-trade', { enabled: false, asset: a });
      // Drain des règlements en vol
      const drainUntil = now() + 75000;
      while (now() < drainUntil) {
        await sleep(3000);
        const rem = [...state.orders.values()].filter(o => !o.settled).length;
        if (rem === 0) break;
      }
      socket.emit('set-auto-trade', { enabled: false });
      const fs2 = await new Promise(r => {
        socket.once('auto-trade-status', r);
        socket.emit('get-auto-status');
        setTimeout(() => r(null), 8000);
      });
      state.finalStatus = fs2;
      break;
    }

    if (placed === 0 && now() - state.campaignStartTs > 10 * 60 * 1000) {
      progress({ phase: 'fatal', msg: 'AUCUN ordre après 10 min — abandon' });
      for (const a of ASSETS) socket.emit('set-auto-trade', { enabled: false, asset: a });
      socket.emit('set-auto-trade', { enabled: false });
      save({ fatal: 'no orders after 10 minutes' });
      process.exit(1);
    }

    if (now() - lastProgress > 15000) {
      lastProgress = now();
      progress({ phase: 'progress', placed, settled, wave: state.wave, balance: state.balance, elapsedS: Math.round((now() - state.campaignStartTs) / 1000) });
      save();
    }
    await sleep(1000);
  }

  /* ── 10. Résumé + rapport ── */
  const orders = [...state.orders.values()].sort((a, b) => a.ts - b.ts);
  const cell = {};
  for (const o of orders) {
    const key = `${o.matchedRuleId ?? '?'}|${o.expirationSeconds ?? '?'}s`;
    cell[key] = cell[key] ?? { n: 0, win: 0, loss: 0, tie: 0, payouts: [] };
    cell[key].n++;
    if (o.result === 'WIN') { cell[key].win++; if (o.payoutPct) cell[key].payouts.push(o.payoutPct); }
    else if (o.result === 'LOSS') cell[key].loss++;
    else if (o.result === 'TIE') cell[key].tie++;
  }
  const perAsset = {};
  for (const o of orders) {
    perAsset[o.asset] = perAsset[o.asset] ?? { orders: 0, amounts: [], results: [] };
    perAsset[o.asset].orders++;
    perAsset[o.asset].amounts.push(o.amount);
    perAsset[o.asset].results.push(o.result ?? '?');
  }
  const totalProfit = orders.reduce((s, o) => s + (o.profit ?? 0), 0);
  progress({ phase: 'done', msg: `${orders.length} ordres, P&L ${totalProfit.toFixed(2)}, solde ${state.startBalance} → ${state.balance}` });
  save({ summary: { totalOrders: orders.length, settled: orders.filter(o => o.settled).length, wins: orders.filter(o => o.result === 'WIN').length, losses: orders.filter(o => o.result === 'LOSS').length, ties: orders.filter(o => o.result === 'TIE').length, totalProfit, startBalance: state.startBalance, endBalance: state.balance, cells: cell, perAsset } });

  socket.close();
  // Si ce processus a démarré le backend, il le laisse TOURNER (réutilisable
  // par la campagne suivante — les streaks seront reset par fixed→martingale).
  process.exit(0);
}

main().catch(e => { progress({ phase: 'fatal', msg: String(e?.stack ?? e) }); save({ fatal: String(e) }); process.exit(1); });
