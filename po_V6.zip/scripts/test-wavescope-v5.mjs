/**
 * Test WaveScope v5 avec le moteur piner (LE moteur de l'app Pine v6 Engine).
 *  PHASE 1 : exécution par défaut (dessins, ZigZag, zones SL/TP)
 *  PHASE 2 : overrides d'inputs → preuve que le menu Réglages fonctionne
 *  PHASE 3 : données multi-jours (PDH/PDL) + variations de réglages
 */
import { compile, Engine, ArrayFeed } from '@heyphat/piner'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'

const DL = join(import.meta.dirname, '../download')

// ── Bougies synthétiques EURUSD_otc S5 multi-jours ──
function makeS5Candles(n = 1600, start = Date.now() - n * 5000, stepMs = 5000) {
  const bars = []
  let price = 1.14000
  let seed = 20260912
  const rand = () => {
    seed = (seed * 1103515245 + 12345) % 2147483648
    return seed / 2147483648
  }
  let regime = 1
  let regimeLeft = 0
  let trend = 1
  for (let i = 0; i < n; i++) {
    if (regimeLeft <= 0) {
      regime = Math.floor(rand() * 3)
      regimeLeft = 20 + Math.floor(rand() * 60)
      trend = rand() < 0.5 ? -1 : 1
    }
    regimeLeft--
    const vol = [0.00004, 0.00009, 0.00018][regime]
    const drift = trend * vol * (0.15 + rand() * 0.6)
    const shock = (rand() - 0.5) * 2 * vol
    const open = price
    const close = open + drift + shock
    const wick = vol * (0.3 + rand() * 1.1)
    const high = Math.max(open, close) + wick * rand()
    const low = Math.min(open, close) - wick * rand()
    bars.push({ time: start + i * stepMs, open, high, low, close, volume: Math.round(300 + rand() * 1200) })
    price = close
  }
  return bars
}

function colorToString(c) {
  if (c == null) return 'null'
  if (typeof c === 'string') return c
  if (typeof c === 'object') {
    if (typeof c.hex === 'string') return c.hex
    if (typeof c.css === 'string') return c.css
    if (c.r !== undefined) return `rgb(${c.r},${c.g},${c.b})`
    return JSON.stringify(c)
  }
  return String(c)
}

const TAGS = {
  SL: /255,\s*61,\s*87|FF3D57/i,
  TP: /0,\s*230,\s*118|00E676/i,
}

async function run(name, source, bars, inputs) {
  const res = { name, ok: false, error: null, counts: {}, zz: 0, slBoxes: 0, tpBoxes: 0, slLabels: 0, tpLabels: 0, pdh: 0, texts: [] }
  let compiled
  try {
    compiled = compile(source)
    res.schema = compiled.metadata.inputs
  } catch (err) {
    res.error = `COMPILE: ${err.message}`
    return res
  }
  try {
    const feed = new ArrayFeed(bars.map((b) => ({ ...b })))
    const engine = new Engine(compiled, feed, inputs ? { inputs } : undefined)
    await engine.run({ symbol: 'EURUSD_otc', timeframe: '5S', mintick: 0.00001 })
    for (const d of engine.drawings ?? []) {
      res.counts[d.type] = (res.counts[d.type] ?? 0) + 1
      if (d.type === 'line') {
        const col = colorToString(d.props?.color)
        if (TAGS.TP.test(col) || TAGS.SL.test(col)) res.zz++
      }
      if (d.type === 'box') {
        const bg = colorToString(d.props?.bgcolor)
        const border = colorToString(d.props?.border_color)
        if (TAGS.SL.test(bg) || TAGS.SL.test(border)) res.slBoxes++
        if (TAGS.TP.test(bg) || TAGS.TP.test(border)) res.tpBoxes++
      }
      if (d.type === 'label') {
        const txt = String(d.props?.text ?? '')
        if (txt.startsWith('TP') || txt.includes('TP 🎯')) res.tpLabels++
        if (txt.startsWith('SL') || txt.includes('SL ✕')) res.slLabels++
        if (txt.includes('PDH') || txt.includes('PDL')) res.pdh++
        if (res.texts.length < 30 && /^(TP|SL)/.test(txt)) res.texts.push(txt)
      }
    }
    res.ok = true
    res.total = (engine.drawings ?? []).length
    return res
  } catch (err) {
    res.error = `RUNTIME: ${err.message}`
    return res
  }
}

function line(r) {
  if (!r.ok) return `  ✗ ${r.name}: ${r.error}`
  return `  ✓ ${r.name}: ${r.total} drawings ${JSON.stringify(r.counts)} | ZigZag=${r.zz} | SLboxes=${r.slBoxes} TPboxes=${r.tpBoxes} | SLlbl=${r.slLabels} TPlbl=${r.tpLabels} | PDH/PDL=${r.pdh}${r.texts.length ? ' | ' + r.texts.slice(0, 4).join(' / ') : ''}`
}

const bars = makeS5Candles()
console.log(`Bougies S5 multi-jours : ${bars.length} barres (${(bars.length * 5 / 86400).toFixed(1)} jours)`)
const v5 = readFileSync(join(DL, 'wavescope_ict_v5.pine'), 'utf8')
const v4 = readFileSync(join(DL, 'wavescope_ict_v4.pine'), 'utf8')

// ═══ PHASE 1 ═══
console.log('\n════════ PHASE 1 : EXÉCUTION PAR DÉFAUT ════════')
const r4 = await run('v4 (référence)', v4, bars)
console.log(line(r4))
const r5 = await run('v5 (nouvelle)', v5, bars)
console.log(line(r5))

// ═══ PHASE 2 ═══
console.log('\n════════ PHASE 2 : LE MENU DE RÉGLAGES (overrides) ════════')
const schema = r5.schema ?? []
const titled = schema.filter((i) => i.title?.trim())
console.log(`Schéma v5 : ${schema.length} inputs, ${titled.length} titrés, ${schema.length - titled.length} sans titre`)
const key = (re) => titled.find((i) => re.test(i.title))?.key
const K = {
  showZZ: key(/ZigZag\s*: afficher/i),
  showZZ2: key(/ZigZag : afficher/),
  dev: key(/Deviation\s*—\s*mouvement/i),
  depth: key(/Depth\s*—\s*barres/i),
  bull: key(/Couleur haussière \(ZigZag\)/i),
  sltp: key(/Zones SL \/ TP en arrière-plan/i),
  slCol: key(/Couleur zone SL/i),
  slLbl: key(/Étiquettes SL/i),
  zones: key(/Zones SL/),
  width: key(/Largeur des zones/i),
  showLiq: key(/BSL \/ SSL \(liquidité externe\)/i),
}
console.log('Clés :', JSON.stringify(K))

// A) zones SL/TP OFF
if (K.sltp) {
  const ra = await run('v5 + [Zones SL/TP = OFF]', v5, bars, { [K.sltp]: false })
  console.log(line(ra))
  console.log(`   ${ra.slBoxes + ra.tpBoxes === 0 && r5.slBoxes + r5.tpBoxes > 0 ? '✓ RÉGLAGE APPLIQUÉ (zones disparues)' : '✗ sans effet !'}`)
}

// B) couleur zone SL → bleu
if (K.slCol) {
  const rb = await run('v5 + [Couleur zone SL = bleu]', v5, bars, { [K.slCol]: '#2962FF' })
  const blue = /2962FF/i
  let blueBoxes = 0
  try {
    const compiled = compile(v5)
    const feed = new ArrayFeed(bars.map((b) => ({ ...b })))
    const engine = new Engine(compiled, feed, { inputs: { [K.slCol]: '#2962FF' } })
    await engine.run({ symbol: 'EURUSD_otc', timeframe: '5S', mintick: 0.00001 })
    for (const d of engine.drawings ?? []) if (d.type === 'box' && (blue.test(colorToString(d.props?.bgcolor)) || blue.test(colorToString(d.props?.border_color)))) blueBoxes++
  } catch {}
  console.log(`  v5 + [Couleur zone SL = bleu] → ${blueBoxes} boîte(s) bleue(s) ${blueBoxes > 0 ? '✓ input.color zone APPLIQUÉ' : '✗ couleur ignorée'}`)
}

// C) ZigZag OFF
if (K.showZZ || K.showZZ2) {
  const kk = K.showZZ || K.showZZ2
  const rc = await run('v5 + [ZigZag = OFF]', v5, bars, { [kk]: false })
  console.log(line(rc))
  console.log(`   ${rc.zz === 0 && r5.zz > 0 ? '✓ RÉGLAGE APPLIQUÉ (zigzag disparu)' : '✗ sans effet !'}`)
}

// D) deviation extrême
if (K.dev) {
  const rd = await run('v5 + [Deviation = 50]', v5, bars, { [K.dev]: 50 })
  console.log(line(rd))
  console.log(`   ${rd.zz < r5.zz ? `✓ RÉGLAGE APPLIQUÉ (${r5.zz} → ${rd.zz} jambes)` : '✗ sans effet !'}`)
}

// E) depth
if (K.depth) {
  const re = await run('v5 + [Depth = 30]', v5, bars, { [K.depth]: 30 })
  console.log(line(re))
  console.log(`   ${re.zz !== r5.zz ? `✓ RÉGLAGE APPLIQUÉ (${r5.zz} → ${re.zz} jambes)` : '✗ sans effet !'}`)
}

// F) largeur des zones
if (K.width) {
  const rf = await run('v5 + [Largeur zones = 60]', v5, bars, { [K.width]: 60 })
  console.log(line(rf))
}

// ═══ PHASE 3 ═══
console.log('\n════════ PHASE 3 : RÉSUMÉ ════════')
console.log(`v5 défaut : ${r5.total} drawings | ZigZag ${r5.zz} jambes | zones SL ${r5.slBoxes} / TP ${r5.tpBoxes} | étiquettes SL ${r5.slLabels} / TP ${r5.tpLabels} | PDH/PDL ${r5.pdh}`)
const passed = [
  r5.ok,
  r5.zz > 0,
  r5.slBoxes > 0,
  r5.tpBoxes > 0,
  (r5.slLabels + r5.tpLabels) > 0,
].every(Boolean)
console.log(passed ? '✅ V5 VALIDE : compile, dessine, ZigZag visible, zones SL/TP présentes, réglages câblés.' : '❌ ÉCHEC — voir ci-dessus.')
process.exit(passed ? 0 : 1)
