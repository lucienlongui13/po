# -*- coding: utf-8 -*-
"""Générateur du rapport d'audit PDF (corps ReportLab) — Template 07 Crystal Blue."""
import os
import sys
import hashlib

PDF_SKILL_DIR = "/home/z/my-project/skills/pdf"
sys.path.insert(0, os.path.join(PDF_SKILL_DIR, "scripts"))
sys.path.insert(0, "/home/z/my-project/scripts")

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_JUSTIFY, TA_LEFT, TA_CENTER
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                PageBreak, CondPageBreak, KeepTogether, HRFlowable)
from reportlab.platypus.tableofcontents import TableOfContents
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfbase.pdfmetrics import registerFontFamily

from pdf import install_font_fallback  # noqa: E402  (module du skill pdf)

import audit_report_content as C
import audit_report_text as T

# ───────────────────────── Fonts ─────────────────────────
FONT_DIR = "/usr/share/fonts"
pdfmetrics.registerFont(TTFont("FreeSerif", f"{FONT_DIR}/truetype/freefont/FreeSerif.ttf"))
pdfmetrics.registerFont(TTFont("FreeSerif-Bold", f"{FONT_DIR}/truetype/freefont/FreeSerifBold.ttf"))
pdfmetrics.registerFont(TTFont("FreeSerif-Italic", f"{FONT_DIR}/truetype/freefont/FreeSerifItalic.ttf"))
pdfmetrics.registerFont(TTFont("FreeSerif-BoldItalic", f"{FONT_DIR}/truetype/freefont/FreeSerifBoldItalic.ttf"))
pdfmetrics.registerFont(TTFont("NotoSerifSC", f"{FONT_DIR}/truetype/noto-serif-sc/NotoSerifSC-Regular.ttf"))
pdfmetrics.registerFont(TTFont("NotoSerifSC-Bold", f"{FONT_DIR}/truetype/noto-serif-sc/NotoSerifSC-Bold.ttf"))
pdfmetrics.registerFont(TTFont("DejaVuSans", f"{FONT_DIR}/truetype/dejavu/DejaVuSansMono.ttf"))
registerFontFamily("FreeSerif", normal="FreeSerif", bold="FreeSerif-Bold",
                   italic="FreeSerif-Italic", boldItalic="FreeSerif-BoldItalic")
registerFontFamily("NotoSerifSC", normal="NotoSerifSC", bold="NotoSerifSC-Bold")
registerFontFamily("DejaVuSans", normal="DejaVuSans", bold="DejaVuSans")
install_font_fallback()

# ───────────────── Palette (Template 07 — palette fixe du corps) ─────────────────
PAGE_BG      = colors.HexColor("#f5f8fc")
SECTION_BG   = colors.HexColor("#edf2f9")
CARD_BG      = colors.HexColor("#e4ecf5")
TABLE_STRIPE = colors.HexColor("#eef3fa")
HEADER_FILL  = colors.HexColor("#1a4a7a")
BORDER       = colors.HexColor("#c0d0e2")
ACCENT       = colors.HexColor("#2d7ab3")
TEXT_PRIMARY = colors.HexColor("#142840")
TEXT_MUTED   = colors.HexColor("#5a7a96")
# Variantes sémantiques (saturations basses) pour les verdicts
OK_GREEN     = colors.HexColor("#3a7a5a")
WARN_AMBER   = colors.HexColor("#8a6d3a")
BAD_RED      = colors.HexColor("#8a4a4a")

# ───────────────────────── Layout ─────────────────────────
MARGIN = 1.0 * inch
PAGE_W, PAGE_H = A4
AVAIL_W = PAGE_W - 2 * MARGIN
AVAIL_H = PAGE_H - 2 * MARGIN
H1_ORPHAN = AVAIL_H * 0.25

OUTPUT = "/home/z/my-project/scripts/audit_body.pdf"

# ───────────────────────── Styles ─────────────────────────
S_BODY = ParagraphStyle("Body", fontName="FreeSerif", fontSize=10.5, leading=16.5,
                        alignment=TA_JUSTIFY, textColor=TEXT_PRIMARY,
                        spaceBefore=0, spaceAfter=10)
S_BODY_FIRST = ParagraphStyle("BodyFirst", parent=S_BODY, firstLineIndent=0)
S_H1 = ParagraphStyle("H1", fontName="FreeSerif-Bold", fontSize=20, leading=25,
                      textColor=HEADER_FILL, spaceBefore=16, spaceAfter=4)
S_H2 = ParagraphStyle("H2", fontName="FreeSerif-Bold", fontSize=14, leading=18,
                      textColor=TEXT_PRIMARY, spaceBefore=12, spaceAfter=6)
S_KICKER = ParagraphStyle("Kicker", fontName="FreeSerif-Italic", fontSize=9, leading=12,
                          textColor=TEXT_MUTED, spaceBefore=0, spaceAfter=2)
S_CAPTION = ParagraphStyle("Caption", fontName="FreeSerif-Italic", fontSize=8.5, leading=11,
                           textColor=TEXT_MUTED, alignment=TA_CENTER, spaceBefore=3, spaceAfter=6)
S_TH = ParagraphStyle("TH", fontName="FreeSerif-Bold", fontSize=9.5, leading=12,
                      textColor=colors.white, alignment=TA_LEFT)
S_TD = ParagraphStyle("TD", fontName="FreeSerif", fontSize=9, leading=12.5,
                      textColor=TEXT_PRIMARY, alignment=TA_LEFT)
S_TD_C = ParagraphStyle("TDC", parent=S_TD, alignment=TA_CENTER)
S_TD_MUTED = ParagraphStyle("TDM", parent=S_TD, textColor=TEXT_MUTED)
S_QUOTE = ParagraphStyle("Quote", fontName="FreeSerif-Italic", fontSize=10.5, leading=16,
                         textColor=TEXT_MUTED, leftIndent=24, alignment=TA_LEFT,
                         spaceBefore=8, spaceAfter=8, borderPadding=4)
S_STAT_BIG = ParagraphStyle("StatBig", fontName="FreeSerif-Bold", fontSize=17, leading=20,
                            textColor=ACCENT, alignment=TA_CENTER)
S_STAT_LBL = ParagraphStyle("StatLbl", fontName="FreeSerif", fontSize=7.8, leading=10,
                            textColor=TEXT_MUTED, alignment=TA_CENTER)
S_TOC_TITLE = ParagraphStyle("TocTitle", fontName="FreeSerif-Bold", fontSize=22, leading=28,
                             textColor=HEADER_FILL, spaceAfter=14)
S_TOC0 = ParagraphStyle("TOC0", fontName="FreeSerif-Bold", fontSize=11, leading=18,
                        textColor=TEXT_PRIMARY, leftIndent=6)
S_TOC1 = ParagraphStyle("TOC1", fontName="FreeSerif", fontSize=10, leading=15,
                        textColor=TEXT_MUTED, leftIndent=24)

# ───────────────────────── Gabarit avec TOC ─────────────────────────
class TocDocTemplate(SimpleDocTemplate):
    def afterFlowable(self, flowable):
        if hasattr(flowable, "bookmark_name"):
            level = getattr(flowable, "bookmark_level", 0)
            text = getattr(flowable, "bookmark_text", "")
            key = getattr(flowable, "bookmark_key", "")
            # Numéro AFFICHÉ (le TOC en romain i occupe la page 1 ; le corps démarre à 1)
            display_page = self.page - 1 if self.page > 1 else self.page
            self.notify("TOCEntry", (level, text, display_page, key))


def on_page(canvas, doc):
    canvas.saveState()
    # Fond de page ultra-bleu (Template 07, corps clair)
    canvas.setFillColor(PAGE_BG)
    canvas.rect(-2, -2, PAGE_W + 4, PAGE_H + 4, stroke=0, fill=1)
    # En-tête
    canvas.setFont("FreeSerif-Italic", 7.5)
    canvas.setFillColor(TEXT_MUTED)
    canvas.drawString(MARGIN, PAGE_H - 0.55 * inch, C.DOC_TITLE)
    canvas.setStrokeColor(ACCENT)
    canvas.setLineWidth(1.2)
    canvas.line(MARGIN, PAGE_H - 0.62 * inch, PAGE_W - MARGIN, PAGE_H - 0.62 * inch)
    # Pied de page
    canvas.setFont("FreeSerif", 7.5)
    canvas.setFillColor(TEXT_MUTED)
    canvas.drawString(MARGIN, 0.5 * inch, "Z.ai — Audit technique")
    page_label = "i" if doc.page == 1 else str(doc.page - 1)
    canvas.drawRightString(PAGE_W - MARGIN, 0.5 * inch, page_label)
    canvas.restoreState()


def add_heading(text, style, level=0):
    key = "h_" + hashlib.md5(text.encode()).hexdigest()[:8]
    p = Paragraph('<a name="%s"/><b>%s</b>' % (key, text), style)
    p.bookmark_name = key
    p.bookmark_level = level
    p.bookmark_text = text
    p.bookmark_key = key
    return p


def h1_block(num, title, kicker=None):
    """Chapitre : saut conditionnel + titre + filet accent + kicker."""
    els = [CondPageBreak(H1_ORPHAN)]
    head = [add_heading("%d. %s" % (num, title), S_H1, level=0),
            HRFlowable(width="100%", color=ACCENT, thickness=1.4, spaceBefore=2, spaceAfter=8)]
    if kicker:
        head.insert(1, Paragraph(kicker, S_KICKER))
    els.append(KeepTogether(head))
    return els


def safe_keep(elements):
    total_h = 0
    for el in elements:
        w, h = el.wrap(AVAIL_W, PAGE_H)
        total_h += h
    if total_h <= PAGE_H * 0.4:
        return [KeepTogether(elements)]
    if len(elements) >= 2:
        return [KeepTogether(elements[:2])] + list(elements[2:])
    return list(elements)


VERDICT_COLORS = {
    "Conforme": OK_GREEN, "Partiel": WARN_AMBER, "Écart": BAD_RED,
    "Manquant": BAD_RED, "N/A": TEXT_MUTED, "Documenté": WARN_AMBER,
}


def verdict_cell(txt):
    col = VERDICT_COLORS.get(txt, TEXT_PRIMARY)
    st = ParagraphStyle("v" + txt, parent=S_TD_C, textColor=col,
                        fontName="FreeSerif-Bold" if txt in ("Écart", "Manquant") else "FreeSerif")
    return Paragraph(txt, st)


def compliance_table(rows, caption, col_ratios, header):
    widths = [r * AVAIL_W for r in col_ratios]
    assert abs(sum(widths) - AVAIL_W) < 1.0
    data = [[Paragraph("<b>%s</b>" % h, S_TH) for h in header]]
    for r in rows:
        data.append([
            Paragraph(r[0], S_TD),
            Paragraph(r[1], S_TD_MUTED),
            Paragraph(r[2], S_TD),
            verdict_cell(r[3]),
            verdict_cell(r[4]),
            Paragraph(r[5], S_TD),
        ])
    tbl = Table(data, colWidths=widths, hAlign="CENTER", repeatRows=1)
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_FILL),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.5, BORDER),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]
    for i in range(1, len(data)):
        if i % 2 == 0:
            style.append(("BACKGROUND", (0, i), (-1, i), TABLE_STRIPE))
        else:
            style.append(("BACKGROUND", (0, i), (-1, i), colors.white))
    tbl.setStyle(TableStyle(style))
    return [Spacer(1, 12)] + safe_keep([tbl]) + [Paragraph(caption, S_CAPTION), Spacer(1, 10)]


def bug_table(rows):
    widths = [0.16 * AVAIL_W, 0.08 * AVAIL_W, 0.46 * AVAIL_W, 0.30 * AVAIL_W]
    data = [[Paragraph("<b>%s</b>" % h, S_TH) for h in
             ("Défaut", "Gravité", "Description", "Correction v2")]]
    for r in rows:
        sev = ParagraphStyle("sev", parent=S_TD_C, fontName="FreeSerif-Bold",
                             textColor=BAD_RED if r[1] == "Critique" else WARN_AMBER)
        data.append([Paragraph(r[0], S_TD), Paragraph(r[1], sev),
                     Paragraph(r[2], S_TD), Paragraph(r[3], S_TD)])
    tbl = Table(data, colWidths=widths, hAlign="CENTER", repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_FILL),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.5, BORDER),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("BACKGROUND", (0, 2), (-1, 2), TABLE_STRIPE),
        ("BACKGROUND", (0, 4), (-1, 4), TABLE_STRIPE),
    ]))
    return [Spacer(1, 12), tbl, Paragraph("Tableau — Défauts techniques identifiés et corrections", S_CAPTION), Spacer(1, 10)]


def fixes_table(rows):
    widths = [0.30 * AVAIL_W, 0.26 * AVAIL_W, 0.12 * AVAIL_W, 0.32 * AVAIL_W]
    data = [[Paragraph("<b>%s</b>" % h, S_TH) for h in
             ("Correction", "Localisation (fonction / section)", "Nature", "Référence du livre")]]
    for r in rows:
        nat = ParagraphStyle("nat", parent=S_TD_C,
                             textColor={"Sécurité": BAD_RED, "Correction": WARN_AMBER,
                                        "Alignement": ACCENT, "Ajout": OK_GREEN,
                                        "Nettoyage": TEXT_MUTED}.get(r[2], TEXT_PRIMARY))
        data.append([Paragraph(r[0], S_TD), Paragraph(r[1], S_TD_MUTED),
                     Paragraph(r[2], nat), Paragraph(r[3], S_TD)])
    tbl = Table(data, colWidths=widths, hAlign="CENTER", repeatRows=1)
    st = [
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_FILL),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.5, BORDER),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]
    for i in range(1, len(data)):
        st.append(("BACKGROUND", (0, i), (-1, i), TABLE_STRIPE if i % 2 == 0 else colors.white))
    tbl.setStyle(TableStyle(st))
    return [Spacer(1, 12), tbl, Paragraph("Tableau — Les seize corrections de la version 2", S_CAPTION), Spacer(1, 10)]


def stat_row(stats):
    """Rangée de 3 encadrés statistiques (2 lignes de 3)."""
    rows = []
    for start in (0, 3):
        cells = []
        for val, lbl in stats[start:start + 3]:
            inner = Table([[Paragraph("<b>%s</b>" % val, S_STAT_BIG)],
                           [Paragraph(lbl, S_STAT_LBL)]],
                          colWidths=[AVAIL_W / 3 - 14])
            inner.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, -1), CARD_BG),
                ("BOX", (0, 0), (-1, -1), 0.8, BORDER),
                ("TOPPADDING", (0, 0), (-1, 0), 8),
                ("BOTTOMPADDING", (0, -1), (-1, -1), 8),
                ("TOPPADDING", (0, 1), (-1, 1), 2),
                ("BOTTOMPADDING", (0, 0), (-1, 0), 2),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ]))
            cells.append(inner)
        row = Table([cells], colWidths=[AVAIL_W / 3] * 3, hAlign="CENTER")
        row.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        rows.append(row)
    return [Spacer(1, 6)] + rows + [Spacer(1, 8)]


def synthese_table(rows):
    widths = [0.40 * AVAIL_W, 0.11 * AVAIL_W, 0.11 * AVAIL_W, 0.38 * AVAIL_W]
    data = [[Paragraph("<b>%s</b>" % h, S_TH) for h in
             ("Module (référence du livre)", "v1", "v2", "Principaux changements")]]
    for r in rows:
        data.append([Paragraph(r[0], S_TD),
                     Paragraph("<b>%s</b>" % r[1], ParagraphStyle("s1", parent=S_TD_C, textColor=WARN_AMBER)),
                     Paragraph("<b>%s</b>" % r[2], ParagraphStyle("s2", parent=S_TD_C, textColor=OK_GREEN)),
                     Paragraph(r[3], S_TD)])
    tbl = Table(data, colWidths=widths, hAlign="CENTER", repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), HEADER_FILL),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("GRID", (0, 0), (-1, -1), 0.5, BORDER),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("BACKGROUND", (0, 2), (-1, 2), TABLE_STRIPE),
        ("BACKGROUND", (0, 4), (-1, 4), TABLE_STRIPE),
    ]))
    return [Spacer(1, 12)] + safe_keep([tbl]) + [Paragraph("Tableau — Synthèse de conformité par module (règles respectées / règles évaluées)", S_CAPTION), Spacer(1, 10)]


# ───────────────────────── Histoire ─────────────────────────
story = []

# Table des matières
toc = TableOfContents()
toc.levelStyles = [S_TOC0, S_TOC1]
story.append(Paragraph("<b>Table des matières</b>", S_TOC_TITLE))
story.append(HRFlowable(width="100%", color=ACCENT, thickness=1.4, spaceBefore=0, spaceAfter=10))
story.append(toc)
story.append(PageBreak())

CH = [
    (1, "Résumé exécutif et verdict", None, T.CH1_INTRO),
    (2, "Méthodologie de l'audit", None, T.CH2_INTRO),
    (3, "Structure de marché (BOS, CHoCH, MSS)", "Référence : chapitres 2 et 3 du livre", T.CH3_INTRO),
    (4, "Liquidité et zones de liquidité", "Référence : chapitre 3 du livre", T.CH4_INTRO),
    (5, "Order Blocks, Breakers et blocs de mitigation", "Référence : chapitre 4 du livre", T.CH5_INTRO),
    (6, "Fair Value Gaps et imbalances", "Référence : chapitre 5 du livre", T.CH6_INTRO),
    (7, "Premium / Discount, OTE et cibles", "Référence : chapitres 6 et 7 du livre", T.CH7_INTRO),
    (8, "Bug critique et défauts techniques", None, T.CH8_INTRO),
    (9, "Corrections apportées dans la version 2", None, T.CH9_INTRO),
    (10, "Limites, conformité résiduelle et recommandations", None, T.CH10_INTRO),
]

COMP_HEADER = ("Règle (livre)", "Réf.", "Comportement du script", "v1", "v2", "Traitement en version 2")
COMP_RATIOS = (0.24, 0.065, 0.26, 0.065, 0.065, 0.305)

TABLES = {
    3: (C.T_STRUCT, "Tableau 1 — Conformité : structure de marché (6 règles)"),
    4: (C.T_LIQ, "Tableau 2 — Conformité : liquidité (9 règles)"),
    5: (C.T_OB, "Tableau 3 — Conformité : order blocks et variantes (11 règles)"),
    6: (C.T_FVG, "Tableau 4 — Conformité : fair value gaps (7 règles)"),
    7: (C.T_LOC, "Tableau 5 — Conformité : localisation, OTE et cibles (8 règles)"),
}

for num, title, kicker, paras in CH:
    story.extend(h1_block(num, title, kicker))
    for i, p in enumerate(paras):
        story.append(Paragraph(p.replace("\n", " "), S_BODY))
    if num == 1:
        story.extend(stat_row(T.STATS))
        story.extend(synthese_table(T.T_SYNTHESE))
    if num in TABLES:
        rows, cap = TABLES[num]
        story.extend(compliance_table(rows, cap, COMP_RATIOS, COMP_HEADER))
    if num == 8:
        story.extend(bug_table(C.T_BUGS))
    if num == 9:
        story.extend(fixes_table(C.T_FIXES))
        story.append(Paragraph(
            "Le fichier corrigé « wavescope_ict_v2_conforme.pine » (1 152 lignes) est livré avec ce "
            "rapport ; l'en-tête du script reprend l'intégralité de cette table de correspondance sous "
            "forme de commentaires, afin que chaque règle du livre reste traçable directement dans le code.",
            S_BODY))

doc = TocDocTemplate(
    OUTPUT, pagesize=A4,
    leftMargin=MARGIN, rightMargin=MARGIN, topMargin=MARGIN, bottomMargin=MARGIN,
    title=C.DOC_TITLE, author="Z.ai", creator="Z.ai",
    subject="Audit de conformité du script Pine WaveScope ICT/SMC au livre The Market's Secret Language",
)
doc.multiBuild(story, onFirstPage=on_page, onLaterPages=on_page)
print("OK —", OUTPUT)
