/**
 * diag-positions.ts — Sanity check: verify each trade's "now" context matches
 * its label (price position within the recent swing at evaluation time).
 */
import { genSeries, TRADE_CASES, HORIZON, swingExtremes, resolveNowIdx } from './eval-smart-trader-lib.js'

for (const tc of TRADE_CASES) {
  const series = genSeries(tc.gen)
  const nowIdx = resolveNowIdx(tc, series)
  const visible = series.slice(0, nowIdx + 1)
  const future = series.slice(nowIdx + 1, nowIdx + 1 + HORIZON)
  const last = visible[visible.length - 1]
  const sw = swingExtremes(visible, 45)
  const pos = (last.close - sw.lo) / Math.max(1e-12, sw.hi - sw.lo)
  const move = future[HORIZON - 1].close - last.close
  const maxUp = Math.max(...future.map(c => c.high)) - last.close
  const maxDown = last.close - Math.min(...future.map(c => c.low))
  console.log(
    `#${String(tc.id).padStart(2)} pos-in-swing ${(pos * 100).toFixed(1).padStart(5)}%` +
    ` | net move ${(move >= 0 ? '+' : '') + move.toFixed(5)}` +
    ` | maxUp ${maxUp.toFixed(5)} maxDown ${maxDown.toFixed(5)}` +
    ` | ${tc.name}`
  )
}
