/**
 * test-candle-builder.ts — Tests du CandleBuilder durci (§20 du ToDo).
 *
 * GARANTIES :
 *   - clôture exactement UNE fois par bougie (pas de double callback) ;
 *   - tick à `boundary - epsilon` reste dans l'ANCIENNE bougie ;
 *   - tick à `boundary` (ou après) ouvre la NOUVELLE bougie ;
 *   - seed historique avec bougie en formation (référence marché) ;
 *   - seed SANS référence marché (boot cache) → tout clôturé, puis un tick
 *     vivant dans le bucket du dernier close « réanime » la bougie ;
 *   - tick ancien (bucket déjà clôturé) ignoré + compté ;
 *   - invariants après seed : ordre strict, alignement, forming > lastClosed.
 *
 * Exécution : cd mini-services/iqoption-backend && node --import tsx ../../scripts/test-candle-builder.ts
 */
import { CandleBuilder, type CandleLike } from '../mini-services/iqoption-backend/candle-builder.js';
import { bucketStart } from '../mini-services/iqoption-backend/timeframe.js';

let pass = 0, fail = 0;
const ok = (name: string, cond: boolean, detail = '') => {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); }
};

/** Fabrique une série historique S30 consécutive ALIGNÉE se terminant à startBucket + (n-1)*period. */
function makeHistory(startBucket: number, n: number, period = 30): CandleLike[] {
  const out: CandleLike[] = [];
  for (let i = 0; i < n; i++) {
    const t = startBucket + i * period;
    out.push({ time: t, open: t / 1e6, high: t / 1e6 + 0.0002, low: t / 1e6 - 0.0002, close: t / 1e6 + 0.0001, volume: 20 });
  }
  return out;
}

/** Base ALIGNÉE sur la grille 30 s (99990 = 3333 × 30). */
const ALIGNED_T0 = 99990;

console.log('══ T1 — Clôture exactement une fois, ordre chronologique ══');
{
  const period = 30;
  const b = new CandleBuilder(period);
  const closes: CandleLike[] = [];
  b.setOnCandleClosed(c => closes.push(c));
  // 3 bougies complètes + 1 en formation (ticks à 2/seconde)
  const t0 = 100000;
  for (let s = 0; s < 3 * period + 10; s++) {
    b.addTick(t0 + s, 1 + (s % 7) * 0.001);
    b.addTick(t0 + s + 0.5, 1 + (s % 7) * 0.001 + 0.0005);
  }
  const lastTick = t0 + 3 * period + 9.5;
  const expectedCloses = bucketStart(lastTick, period) - bucketStart(t0, period) >= 0
    ? Math.floor(lastTick / period) - Math.floor(t0 / period)
    : 0;
  ok(`clôtures = frontières traversées (${expectedCloses})`, closes.length === expectedCloses, `got ${closes.length}`);
  ok('UNE clôture par bougie (pas de doublon)', new Set(closes.map(c => c.time)).size === closes.length);
  ok('clôtures en ordre chronologique strict', closes.every((c, i) => i === 0 || closes[i - 1].time < c.time));
  ok('chaque clôture alignée sur la grille', closes.every(c => c.time % period === 0));
  ok('callbacksFired === candlesClosed (statistiques cohérentes)',
    b.getStats().callbacksFired === b.getStats().candlesClosed && b.getStats().callbacksFired === closes.length);
}

console.log('══ T2 — Frontières : epsilon avant / exactement sur ══');
{
  const period = 30;
  const b = new CandleBuilder(period);
  const t0 = 100000;
  b.addTick(t0, 1.0);
  // Tick JUSTE AVANT la frontière (boundary - epsilon)
  const boundary = bucketStart(t0, period) + period; // 100020
  const before = b.addTick(boundary - 0.001, 1.5);
  ok('tick à boundary-ε reste dans l\'ANCIENNE bougie', before !== null && before.time === bucketStart(t0, period));
  ok('le close de l\'ancienne bougie = prix du tick boundary-ε', Math.abs(before!.close - 1.5) < 1e-12);
  // Tick EXACTEMENT sur la frontière → ouvre la nouvelle bougie
  const after = b.addTick(boundary, 1.6);
  ok('tick à boundary ouvre la NOUVELLE bougie', after !== null && after.time === boundary);
  ok('l\'ancienne bougie est clôturée avec close=1.5',
    b.getClosedCandles(1)[0].time === bucketStart(t0, period) && Math.abs(b.getClosedCandles(1)[0].close - 1.5) < 1e-12);
}

console.log('══ T3 — Seed historique avec bougie en formation ══');
{
  const period = 30;
  const hist = makeHistory(ALIGNED_T0, 10, period); // buckets 99990..100260
  const lastBucket = hist[hist.length - 1].time; // 100260
  const marketNow = lastBucket + 5; // le marché est DANS le dernier bucket

  const b = new CandleBuilder(period);
  b.seed(hist, { referenceMarketTimeSec: marketNow, periodSec: period, source: 'history' });
  const forming = b.getFormingCandle();
  const closed = b.getClosedCandles(100);
  ok('la dernière bougie historique (bucket courant) devient la formation',
    forming !== null && forming.time === lastBucket);
  ok('les autres bougies sont clôturées (9)', closed.length === 9);
  ok('invariant : forming.time > dernier clôturé', forming!.time > closed[closed.length - 1].time);
  ok('toutes alignées % 30', [...closed, forming!].every(c => c.time % 30 === 0));
  ok('ordre strict des clôturées', closed.every((c, i) => i === 0 || closed[i - 1].time < c.time));

  // Le live continue la bougie en formation : le prochain tick du MÊME bucket
  // met à jour la formation (pas de nouvelle bougie au même timestamp).
  const next = b.addTick(marketNow + 1, 99);
  ok('le tick live suivant CONTINUE la formation (même bucket, OHLC mis à jour)',
    next !== null && next.time === lastBucket && next.close === 99 && next.high >= 99);
  // Anti-rejeu : le seed history a fourni latestLiveTickTimeSec → un tick
  // rejoué antérieur est droppé.
  const replay = b.addTick(marketNow - 1, 55);
  ok('tick rejoué antérieur au dernier temps marché droppé (anti-rejeu)',
    replay === null && b.getStats().duplicateTickDropped >= 1);
}

console.log('══ T4 — Seed avec historique TOUT clôturé (marché ailleurs) ══');
{
  const period = 30;
  const hist = makeHistory(ALIGNED_T0, 10, period);
  const lastBucket = hist[hist.length - 1].time; // 100260
  // Référence marché dans un bucket ULTÉRIEUR → tout l'historique est clôturé
  const b = new CandleBuilder(period);
  b.seed(hist, { referenceMarketTimeSec: lastBucket + 3 * period + 2, periodSec: period, source: 'history' });
  ok('aucune formation (tout clôturé)', b.getFormingCandle() === null);
  ok('10 bougies clôturées', b.getClosedCandles(100).length === 10);

  // Un tick vivant dans le bucket du dernier close RÉANIME la bougie
  // (le temps marché prouve que le bucket est encore vivant).
  const revived = b.addTick(lastBucket + 1, 2.0);
  ok('tick vivant dans le bucket du dernier close → bougie RÉANIMÉE en formation',
    revived !== null && revived.time === lastBucket && revived.close === 2.0);
  ok('stat revivedForming comptée', b.getStats().revivedForming === 1);
  ok('le close d\'origine + tick fusionnés (high = max)', revived!.high >= 2.0);
}

console.log('══ T5 — Ticks anciens : jamais de ré-ouverture d\'une bougie clôturée ══');
{
  const period = 30;
  const b = new CandleBuilder(period);
  const t0 = 100000;
  for (let s = 0; s < 100; s++) b.addTick(t0 + s, 1 + s * 0.001);
  const closedBefore = b.getClosedCandles(100).length;
  const snapshot = JSON.stringify(b.getClosedCandles(100));
  // Tick ancien : bucket déjà clôturé (t0 + 10 → bucket 100000)
  const stale = b.addTick(t0 + 10, 9.99);
  ok('tick ancien droppé (null)', stale === null);
  ok('aucune bougie clôturée modifiée (pas de ré-ouverture)',
    JSON.stringify(b.getClosedCandles(100)) === snapshot && b.getClosedCandles(100).length === closedBefore);
  ok('compteur de drops (duplicate/late/outOfOrder) ≥ 1',
    b.getStats().duplicateTickDropped + b.getStats().lateTickDropped + b.getStats().outOfOrderTickDropped >= 1, JSON.stringify(b.getStats()));

  // Tick rejoué (même timestamp que le dernier tick vu)
  const lastT = t0 + 99;
  const dup = b.addTick(lastT, 1.05);
  ok('tick rejoué au même timestamp droppé + compté', dup === null && b.getStats().duplicateTickDropped >= 1);
}

console.log('══ T6 — Seed avec série sale (non alignée, doublons, invalide) ══');
{
  const period = 30;
  const dirty: CandleLike[] = [
    { time: 100007, open: 1, high: 2, low: 0.5, close: 1.5, volume: 10 },  // non alignée → 100000... wait 100007 → 999990
    { time: 100020, open: 1, high: 2, low: 0.5, close: 1.5, volume: 5 },   // doublon bucket 100020
    { time: 100020, open: 2, high: 3, low: 1.5, close: 2.5, volume: 9 },   // → garde volume 9
    { time: 100050, open: 1, high: 0.1, low: 9, close: 1, volume: 5 },     // OHLC invalide → rejet
    { time: 100080, open: 1, high: 2, low: 0.5, close: 1.5, volume: 8 },   // alignée
  ];
  const b = new CandleBuilder(period);
  b.seed(dirty, { referenceMarketTimeSec: 100090, periodSec: period, source: 'history' });
  const all = b.getCandles();
  ok('normalisation dans le seed : 3 buckets canoniques (99990, 100020, 100080)',
    all.length === 3 && all[0].time === 99990 && all[1].time === 100020 && all[2].time === 100080,
    JSON.stringify(all.map(c => c.time)));
  ok('doublon de bucket : volume le plus élevé conservé (9)', all[1].volume === 9);
  ok('bougies invalides rejetées', !all.some(c => c.time === 100050));
  // 100080 est le bucket courant (réf 100090 ∈ [100080, 100110)) → formation
  ok('dernière bougie du bucket courant = formation', b.getFormingCandle()?.time === 100080);
}

console.log('══ T7 — setPeriod : la formation est invalidée, l\'historique est préservé ══');
{
  const period = 30;
  const b = new CandleBuilder(period);
  const t0 = 100000;
  for (let s = 0; s < 70; s++) b.addTick(t0 + s, 1 + s * 0.001);
  const closedBefore = b.getClosedCandles(100).length;
  b.setPeriod(60);
  ok('changement de période → formation invalidée', b.getFormingCandle() === null);
  ok('les bougies clôturées sont conservées', b.getClosedCandles(100).length === closedBefore);
  const next = b.addTick(t0 + 200, 2.0);
  ok('le prochain tick utilise la NOUVELLE grille (multiple de 60)',
    next !== null && next.time % 60 === 0);
}

console.log('');
console.log('════════════════════════════════════');
console.log(`  RÉSULTAT : ${pass} PASS / ${fail} FAIL`);
console.log('════════════════════════════════════');
process.exit(fail > 0 ? 1 : 0);
