/**
 * test-pine-timestamp-mapping.ts — v1.9 suite.
 *
 * Validates the CANONICAL temporal layer (src/lib/pine-time-axis.ts):
 *  - single sec↔ms conversions and their round-trips
 *  - BarIdentity, timestamp lookup structures
 *  - alignPineSeries: timestamp-keyed placement, dropped out-of-window values,
 *    REFUSED positional fallbacks (missing timeline / length mismatch)
 *  - validatePineTimeline: monotonicity, duplicates, unit sanity, bar counts
 *  - diagnosePineAlignment: PINE_RESULT_STALE heuristic
 */
import {
  toPineTime, toChartTime, pineTimeToChartTime, barIdentityOf,
  buildTimeIndex, buildTimeToIndexMap, findCandleByPineTime,
  alignPineSeries, validatePineTimeline, diagnosePineAlignment,
} from '../src/lib/pine-time-axis'
import { makeCandles, makeChecker, timeOfIndex } from './pine-live-test-utils'

const { ok, finish } = makeChecker()

// ── 1. conversions ───────────────────────────────────────────────────
console.log('── 1. canonical conversions ──')
const sec = 1789439220
ok('toPineTime(sec) → ms', toPineTime(sec) === 1789439220000)
ok('toChartTime(ms) → sec (rounded)', toChartTime(1789439220000) === sec)
ok('toChartTime rounds half-ms', toChartTime(1789439220499.6) === 1789439221 || toChartTime(1789439220499.4) === 1789439220)
ok('pineTimeToChartTime is toChartTime (single source)', pineTimeToChartTime(1234567890123) === toChartTime(1234567890123))
const id = barIdentityOf({ time: sec, open: 1, high: 2, low: 0.5, close: 1.5, volume: 0 } as any)
ok('barIdentityOf carries both units', id.timeSec === sec && id.timeMs === sec * 1000)

// ── 2. timestamp lookup ──────────────────────────────────────────────
console.log('── 2. timestamp lookup ──')
const candles = makeCandles(150)
const index = buildTimeIndex(candles)
ok('buildTimeIndex finds every candle by time', candles.every((c) => index.get(c.time) === c))
const t2i = buildTimeToIndexMap(candles)
ok('buildTimeToIndexMap maps time → array index', t2i.get(candles[73].time) === 73)
ok('findCandleByPineTime resolves ms → candle', findCandleByPineTime(toPineTime(candles[42].time), index) === candles[42])
ok('findCandleByPineTime returns undefined for unknown time', findCandleByPineTime(toPineTime(999), index) === undefined)

// ── 3. alignPineSeries: THE anti-positional-fallback proof ─────────
console.log('── 3. alignPineSeries (spec §7) ──')
{
  // Pine holds 150 bars; the chart window only shows the LAST 100 → the
  // naive tail alignment `values[values.length - n + i]` would map the first
  // chart candle to Pine bar 50 — WRONG. Timestamp alignment must map each
  // value to the candle with the SAME time.
  const pineTimes = candles.map((c) => toPineTime(c.time))
  const values = candles.map((c) => c.close)
  const visible = candles.slice(50)
  const { points, issues } = alignPineSeries(values, pineTimes, visible)
  ok('no issues on coherent timeline', issues.length === 0)
  ok('all 100 visible candles matched', points.length === 100)
  ok('value lands on the candle with the SAME timestamp (not positional)',
    points.every((p) => p.candle.close === p.value))
  ok('first point is chart candle 0 = Pine bar 50',
    points[0].candle === visible[0] && pineTimes.indexOf(toPineTime(points[0].candle.time)) === 50)

  // Anti-shift: a result from an OLDER dataset (missing the newest bars) must
  // simply end earlier — the last visible candle gets NO point, and no value
  // is ever displaced onto the wrong candle.
  const staleCandles = candles.slice(0, 140)
  const staleTimes = staleCandles.map((c) => toPineTime(c.time))
  const staleValues = staleCandles.map((c) => c.close)
  const r2 = alignPineSeries(staleValues, staleTimes, visible)
  ok('stale result aligns on its own timestamps (no shift, just shorter)',
    r2.points.length === 90 && r2.points[0].candle === visible[0])
  ok('stale result never touches the newest 10 candles',
    !r2.points.some((p) => p.candle.time >= candles[140].time))

  // Missing timeline → REFUSED (no positional fallback).
  const r3 = alignPineSeries(values, undefined, visible)
  ok('missing timeline → zero points', r3.points.length === 0)
  ok('missing timeline → PINE_TIMELINE_MISSING diagnostic',
    r3.issues.some((i) => i.code === 'PINE_TIMELINE_MISSING'))

  // Length mismatch → REFUSED.
  const r4 = alignPineSeries(values.slice(0, 149), pineTimes, visible)
  ok('length mismatch → zero points (no tail alignment)', r4.points.length === 0)
  ok('length mismatch → PINE_TIMELINE_LENGTH_MISMATCH diagnostic',
    r4.issues.some((i) => i.code === 'PINE_TIMELINE_LENGTH_MISMATCH'))
}

// ── 4. validatePineTimeline ──────────────────────────────────────────
console.log('── 4. validatePineTimeline (spec §8) ──')
{
  const good = candles.slice(0, 60).map((c) => toPineTime(c.time))
  ok('valid monotonic ms timeline passes', validatePineTimeline(good, 60).ok)
  ok('bar count mismatch reported', !validatePineTimeline(good, 61).ok
    && validatePineTimeline(good, 61).issues.some((i) => i.code === 'PINE_TIMELINE_LENGTH_MISMATCH'))
  ok('missing timeline fails', !validatePineTimeline(undefined).ok)

  const dup = [...good]
  dup[30] = dup[29]
  ok('duplicate timestamp rejected', validatePineTimeline(dup).issues.some((i) => i.code === 'PINE_TIMELINE_DUPLICATE'))

  const nonMono = [...good]
  nonMono[40] = nonMono[10]
  ok('non-monotonic timeline rejected', validatePineTimeline(nonMono).issues.some((i) => i.code === 'PINE_TIMELINE_NOT_MONOTONIC'))

  const wrongUnit = good.map((t) => Math.round(t / 1000))
  ok('sec-unit timeline flagged as suspect', validatePineTimeline(wrongUnit).issues.some((i) => i.code === 'PINE_TIMELINE_UNIT_SUSPECT'))
}

// ── 5. diagnosePineAlignment ──────────────────────────────────────────
console.log('── 5. PINE_RESULT_STALE heuristic (spec §17) ──')
{
  const fresh = diagnosePineAlignment({
    scriptId: 's1',
    resultTimes: candles.map((c) => toPineTime(c.time)),
    candles,
    datasetRevision: 5,
    resultRevision: 5,
  })
  ok('fresh result → no PINE_RESULT_STALE', !fresh.codes.includes('PINE_RESULT_STALE'))
  ok('fresh probe compares last times correctly', fresh.lastCandleTimeSec === candles[149].time && fresh.resultLastTimeSec === candles[149].time)

  const staleTimes = candles.slice(0, 149).map((c) => toPineTime(c.time))
  const stale = diagnosePineAlignment({
    scriptId: 's1',
    resultTimes: staleTimes,
    candles,
    datasetRevision: 6,
    resultRevision: 5,
  })
  ok('1-bar-behind result → PINE_RESULT_STALE', stale.codes.includes('PINE_RESULT_STALE'))

  const veryStale = diagnosePineAlignment({
    scriptId: 's1',
    resultTimes: candles.slice(0, 100).map((c) => toPineTime(c.time)),
    candles,
    datasetRevision: 9,
    resultRevision: 2,
  })
  ok('50-bars-behind result → PINE_RESULT_STALE', veryStale.codes.includes('PINE_RESULT_STALE'))
  ok('stale probe reports the lag', veryStale.details.some((d) => d.includes('behind')))
}

console.log()
finish('test-pine-timestamp-mapping')
