#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# PROBE — mesure précise de l'alignement via window.__pineChartDebug
# ═══════════════════════════════════════════════════════════════════
cd /home/z/my-project

# l'éditeur peut être ouvert → fermer pour un rendu propre
agent-browser eval '(() => {
  const b = [...document.querySelectorAll("button")].find(x => (x.textContent || "").includes("PINE SCRIPT"));
  const panelOpen = document.body.textContent.includes("LIBRAIRIES PINE");
  if (b && panelOpen) { b.click(); }
  return "editor closed: " + !document.body.textContent.includes("Console");
})()' 2>&1 | tail -1
sleep 3

agent-browser eval '(() => {
  const dbg = window.__pineChartDebug;
  if (!dbg) return JSON.stringify({ error: "no debug hook (HMR?)" });
  const chart = dbg.getChart();
  const series = dbg.getSeries();
  const candles = dbg.getCandles();
  const scripts = dbg.getScripts().filter(s => s.enabled && s.result);
  if (!chart || !series || !candles.length) return JSON.stringify({ error: "chart not ready" });

  const h = chart.priceScale("right").width(); // not the pane height; get pane height via coordinateToPrice at 0 and at bottom
  // visible price range via inverse mapping
  const paneEl = document.querySelector(".relative.flex-1");
  const paneH = paneEl ? paneEl.clientHeight : 0;
  const priceAtTop = series.coordinateToPrice(0);
  const priceAtBottom = series.coordinateToPrice(paneH);

  const candlePrices = candles.flatMap(c => [c.low, c.high]);
  const cMin = Math.min(...candlePrices), cMax = Math.max(...candlePrices);

  const out = {
    paneH,
    priceAtTop, priceAtBottom,
    visibleRange: [priceAtBottom, priceAtTop],
    candleRange: [cMin, cMax],
    chartCandleCount: candles.length,
    chartTimeRange: [candles[0].time, candles[candles.length - 1].time],
    scripts: scripts.map(s => {
      const r = s.result;
      const dw = r.drawings || [];
      const prices = dw.flatMap(d =>
        d.kind === "line" ? [d.y1, d.y2] :
        d.kind === "label" ? (d.y != null ? [d.y] : []) :
        d.kind === "box" ? [d.top, d.bottom] :
        d.kind === "polyline" ? d.points.map(p => p.price) : []);
      const times = dw.flatMap(d =>
        d.kind === "line" ? [d.x1, d.x2] :
        d.kind === "label" ? [d.x] :
        d.kind === "box" ? [d.left, d.right] :
        d.kind === "polyline" ? d.points.map(p => p.time) : []);
      const pineTimes = r._times || [];
      return {
        id: s.id, name: s.name, overlay: r.overlay,
        drawings: dw.length,
        plots: r.plots.length, markers: r.markers.length,
        alerts: (r.alerts || []).length,
        pineBars: pineTimes.length,
        pineTimeRangeMs: pineTimes.length ? [pineTimes[0], pineTimes[pineTimes.length - 1]] : null,
        drawingPriceRange: prices.length ? [Math.min(...prices), Math.max(...prices)] : null,
        drawingTimeRangeMs: times.length ? [Math.min(...times), Math.max(...times)] : null,
        // how many drawings anchor INSIDE the chart candle window
        drawingsInsideWindow: times.filter(t => t >= candles[0].time * 1000 && t <= candles[candles.length - 1].time * 1000).length,
        drawingAnchorCount: times.length,
      };
    }),
  };
  return JSON.stringify(out, null, 1);
})()' 2>&1 | tail -40
