#!/bin/bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v21.sh — Livraison v21 « FINAL RULES » (4 nouvelles règles)
# ══════════════════════════════════════════════════════════════════════════
#
# 1. PLUS D'EURUSD_otc PAR DÉFAUT (bug signalé : après un refresh de la
#    page, l'asset en cours — ex. CADJPY_otc — disparaissait et repartait
#    sur EURUSD_otc) :
#      • FRONTEND : l'effet qui forçait selectMarket('EURUSD_otc') à CHAQUE
#        (re)authentification est SUPPRIMÉ — la source de vérité de l'asset
#        affiché est UNIQUEMENT le backend (status 1 Hz) ;
#      • BACKEND : DEFAULT_CONFIG.market = '' (le fallback codé en dur
#        `|| 'EURUSD_otc'` du login est RETIRÉ) ;
#      • DÉMARRAGE DU PROGRAMME : sans session à restaurer, un asset avec
#        profit 92 % est sélectionné ALÉATOIREMENT (ensureStartupAssetSelection,
#        candidats payout == 92 % exactement + marché ouvert, tirage
#        uniforme) ;
#      • refresh navigateur / re-login : retour sur l'ASSET EN COURS.
#
# 2. REFRESH OBLIGATOIRE FRONTEND + BACKEND à chaque Auto Switch Assets et
#    chaque Re-Login :
#      • BACKEND : reconstruction complète (désabonnement/réabonnement,
#        contextes par asset, purge des séries, historique frais, et pour le
#        re-login : client broker recréé) ;
#      • FRONTEND : événement force-frontend-refresh → window.location.reload()
#        (rechargement COMPLET de la page, émis APRÈS la reconstruction
#        backend — mono, multi et re-login).
#
# 3. RE-LOGIN AUTOMATIQUE TOUTES LES 1 HEURES de programme :
#      • AUTOMATIC_RELOGIN_MS = 60 min (était 30) ;
#      • STRICT : aucun ordre en cours + dernier ordre réglé = GAIN (la
#        dérogation « 10 min sans ordre en vol » est SUPPRIMÉE) ;
#      • retry 15 s + réveil IMMÉDIAT dès qu'un gain est réglé.
#
# 4. SWITCH « STAY ON FOREX OTC ONLY » (sous Auto-switch assets) :
#      • ON = tout Auto Switch Assets ne choisit QUE des paires FOREX OTC
#        (CADJPY_otc, AUDUSD_OTC…) — jamais métaux (XAUUSD), cryptos
#        (BTCUSD), indices ni actions ;
#      • classification isForexOtcAsset : suffixe _otc + symbole 6 lettres
#        = deux codes de devises FIAT (croisée exhaustive avec le catalogue
#        réel : 59/59 paires currency OTC ✓, 0/103 non-currency ✓) ;
#      • persisté (session snapshot + set-config), OFF par défaut.
#
# Validation : tsc root 0 · tsc backend 0 · tsc SDK 0 · next build PASS
# (6/6) · test-v21-rules (NOUVEAU) 61 ✓ · test-v21-rules-e2e (NOUVEAU,
# vrai backend + faux broker 4 assets dont l'or XAUUSD 92 %) 28/28 ✓ ·
# auto-switch-rule-e2e 20/20 ✓ · confirm-candle-cap-e2e 24/24 ✓ ·
# tie-refund-e2e 24/24 ✓ · bos-martingale-e2e 17/17 ✓ · multi-e2e 20/20 ✓ ·
# defaults-v20 7 ✓ · multi-assets 134 ✓ · v63-features 74 ✓ ·
# v63-integration 14 ✓ · bos-strategy 22 ✓ · martingale-streak 12 ✓ ·
# bos-expiry-martingale 39 ✓ · confirm-candle-cap 59 ✓ ·
# smart-stream-hardening (v20) PASS.
#
# Sortie : /home/z/my-project/download/pine_v6_engine_v21_final_rules.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v21"
FOLDER=pine_v6_engine
OUT="$ROOT/download/pine_v6_engine_v21_final_rules.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (structure identique aux zips v15-v20) ───────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude '.logs/' \
  --exclude '*.log' \
  --exclude 'winwinlogs.jsonl' \
  --exclude 'tsconfig.tsbuildinfo' \
  --exclude 'mini-services/iqoption-backend/data/backend-session.json' \
  --exclude 'mini-services/iqoption-backend/data/candle-cache/' \
  --exclude 'mini-services/iqoption-backend/e2e-*.log' \
  --exclude 'db/' \
  "$ROOT/pine_v6_engine/" "$STAGE/$FOLDER/"

# ── README de la version v20 (chaîne documentaire conservée) ─────────────
unzip -q -o "$ROOT/download/pine_v6_engine_v20_final_fixes.zip" \
  "pine_v6_engine/README-V1.6-V20-FINAL-FIXES.md" -d "$STAGE/"

# ── README de la version v21 ─────────────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.6-V21-FINAL-RULES.md" <<'EOF'
# Pine v6 Engine — v21 « Final Rules » : 4 nouvelles règles

## 1. Plus d'asset par défaut — démarrage aléatoire à 92 %

**Bug signalé** : après un refresh de la page, l'asset en cours (ex.
CADJPY_otc) disparaissait et l'application repartait sur EURUSD_otc.

**Cause racine** : le frontend forçait `selectMarket('EURUSD_otc')` à
CHAQUE (re)authentification — un défaut codé en dur écrasait l'asset en
cours dès que le status 1 Hz ré-authentifiait la page rechargée.

**v21** :
- la règle codée en dur EURUSD_otc est **RETIRÉE** (frontend + backend) ;
- **au démarrage du programme** (backend neuf, sans session à restaurer),
  un **asset avec profit 92 % est sélectionné aléatoirement** (payout
  == 92 % exactement, marché ouvert — même tolérance que l'Auto Switch) ;
- **refresh de la page** : retour sur l'**asset en cours** (le backend
  headless ne change jamais d'asset ; le frontend suit le status 1 Hz) ;
- **re-login / redémarrage backend** : le FOCUS sauvegardé est restauré.

## 2. Refresh frontend + backend OBLIGATOIRE (auto-switch & re-login)

À CHAQUE auto-switch d'assets et CHAQUE re-login :
1. le **backend** se reconstruit complètement : désabonnement de l'ancien
   asset, contextes/pipelines purgés, réabonnement du nouvel asset,
   historique de bougies frais (et pour le re-login : client broker
   détruit et recréé, session complète restaurée) ;
2. le **frontend** est rechargé **dans son intégralité** : le backend
   émet l'événement `force-frontend-refresh` UNE FOIS la reconstruction
   terminée → `window.location.reload()`. La page rechargée se
   ré-authentifie via le status 1 Hz et réaffiche l'asset en cours avec
   un état de graphique strictement reconstruit.

## 3. Re-login automatique toutes les 1 heure (strict)

Le re-login s'applique automatiquement **après chaque 1 heure de
programme**, en s'assurant que :
1. **aucun ordre n'est placé en cours** — un ordre ouvert est TOUJOURS
   attendu (jamais coupé) ;
2. **le dernier ordre réglé est un GAIN** — une perte ou un Tie reporte
   le re-login (retry toutes les 15 s, réveil immédiat dès qu'un gain
   est réglé). La dérogation « exécution après 10 min sans ordre en
   vol » des versions précédentes est **SUPPRIMÉE** : la règle est
   désormais stricte et sans exception.

## 4. Switch « Stay on Forex OTC Only » (sous Auto-switch assets)

Nouveau switch dans le panneau de droite, **sous** « Auto-switch
assets » :

- **ON** : tout Auto Switch Assets ne choisira **que les actifs Forex
  OTC** — CADJPY_otc, AUDUSD_OTC, EURUSD_otc, USDJPY_OTC… Les métaux
  (XAUUSD_otc = or), cryptos (BTCUSD_otc), indices et actions sont
  EXCLUS des cibles de remplacement ;
- **OFF** (défaut) : les cibles restent tout asset payout == 92 % ;
- l'état est **persisté** (survit aux re-logins et redémarrages) ;
- classification : suffixe `_otc` + symbole 6 lettres = deux codes de
  devises FIAT (vérifiée exhaustivement sur le catalogue réel : 59/59
  paires currency OTC reconnues, 0/103 métaux/crypto/indices/actions).

## Validation (toutes exécutées sur cette livraison)

| Vérification | Résultat |
|---|---|
| `tsc --noEmit` (root / backend / SDK) | 0 erreur |
| `next build` | PASS — 6/6 pages |
| `scripts/test-v21-rules.ts` (**nouveau** : classification Forex OTC croisée au catalogue, filtrage du moteur, persistance, vérifs sources) | 61 ✓ / 0 ✗ |
| `tests/test-v21-rules-e2e.mjs` (**nouveau** : vrai backend + faux broker avec l'or XAUUSD 92 %) | 28/28 ✓ |
| — Phase A : login sans session | asset 92 % sélectionné **aléatoirement** (reason `startup-random-92`), le 88 % jamais choisi |
| — Phase B : refresh simulé (nouveau socket) + login idempotent | **même asset conservé** — ne repart PAS sur EURUSD_otc |
| — Phase C : Stay on Forex OTC Only ON + payout 56 % | switch vers GBPUSD_otc — **l'or XAUUSD 92 % exclu** + événement `force-frontend-refresh` reçu |
| — Phase D : switch OFF + payout 56 % | l'or XAUUSD redevient éligible (filtre levé) |
| `tests/test-auto-switch-rule-e2e.mjs` (règles v20) | 20/20 ✓ |
| `tests/test-confirm-candle-cap-e2e.mjs` | 24/24 ✓ |
| `tests/test-martingale-tie-refund-e2e.mjs` | 24/24 ✓ |
| `tests/test-bos-choch-cisd-martingale-e2e.mjs` | 17/17 ✓ |
| `tests/test-bos-choch-cisd-multi-e2e.mjs` | 20/20 ✓ |
| `scripts/test-defaults-v20.ts` (indicateurs [] + thème clair) | 7 ✓ / 0 ✗ |
| `tests/test-multi-assets.ts` | 134 OK |
| `tests/test-v63-features.ts` / `test-v63-integration.ts` | 74 ✓ / 14 ✓ |
| `tests/test-bos-choch-cisd-strategy.ts` | 22 ✓ |
| `scripts/test-martingale-streak.ts` | 12 ✓ |
| `scripts/test-bos-choch-cisd-expiry-martingale.ts` | 39 ✓ |
| `scripts/test-confirm-candle-cap.ts` | 59 ✓ |
| `scripts/test-smart-stream-hardening.mjs` | PASS |

## Comment re-vérifier vous-même

```bash
# 1. Installer et démarrer
npm install && cd mini-services/iqoption-backend && npm install

# 2. Typecheck + build
cd ../.. && npx tsc --noEmit && npx next build

# 3. Nouveautés v21
npx tsx scripts/test-v21-rules.ts               # 61 ✓ (Forex OTC + sources)
cd mini-services/iqoption-backend
node tests/test-v21-rules-e2e.mjs               # 28/28 (démarrage aléatoire…)

# 4. Non-régression
node tests/test-auto-switch-rule-e2e.mjs        # 20/20
node tests/test-confirm-candle-cap-e2e.mjs       # 24/24
```

Dans l'application :
- **démarrage** : le premier login sans session précédente tire un asset
  92 % au hasard (log « [STARTUP] asset sélectionné ALÉATOIREMENT… ») ;
- **refresh** (F5) : l'asset en cours est conservé ;
- **Auto-switch + Stay on Forex OTC Only ON** : quand le payout passe
  sous 92 % avec un dernier ordre gagnant, la cible est toujours une
  paire Forex OTC — la page se recharge après le switch ;
- **re-login 1 h** : visible dans les logs (« programmé dans 1 h »),
  il ne part jamais pendant un ordre en vol ni après une perte.
EOF

cd "$STAGE"
zip -qr "$OUT" "$FOLDER"
cd "$ROOT"
rm -rf "$STAGE"
echo "─ Livraison v21 ─────────────────────────────────────────────"
echo "Zip      : $OUT"
echo "Taille   : $(du -h "$OUT" | cut -f1)"
echo "Fichiers : $(unzip -l "$OUT" | tail -1 | awk '{print $2}')"
echo "Intégrité: $(unzip -t "$OUT" > /dev/null && echo OK || echo ÉCHEC)"
sha256sum "$OUT"
md5sum "$OUT"
