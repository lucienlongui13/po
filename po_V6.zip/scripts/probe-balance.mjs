// probe-balance.mjs — vérifie le solde démo via le backend (login idempotent)
import { io } from 'socket.io-client';

const socket = io('http://127.0.0.1:3030', { transports: ['websocket'], path: '/', reconnection: false, timeout: 10000 });

socket.on('status', (s) => {
  if (s?.balance != null) {
    console.log('BALANCE:', JSON.stringify(s.balance));
  }
});

setTimeout(async () => {
  socket.emit('login', { email: 'longuilcn@gmail.com', password: 'Jean-Paul@#1964', mode: 'demo' });
}, 500);

socket.on('login-result', (r) => {
  console.log('LOGIN:', JSON.stringify(r));
});

setTimeout(() => {
  socket.emit('get-auto-status');
  socket.close();
  process.exit(0);
}, 8000);
