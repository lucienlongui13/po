#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v1.3.sh — Livraison v1.3 « Réglages Pine + WaveScope v5 »
#   - panneau ⚙ Réglages dans l'éditeur Pine (115 paramètres WaveScope v5)
#     avec application immédiate + persistance par script
#   - runPineScript transmet désormais les overrides d'inputs au moteur
#   - wavescope_ict_v5.pine INCLUS à la racine du zip (+ guide)
# Sortie : /home/z/my-project/download/pine_v6_engine_v1.3.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v1.3"
FOLDER=pine_v6_engine_v1.3
OUT="$ROOT/download/pine_v6_engine_v1.3.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (mêmes exclusions que v1.0/v1.1/v1.2) ─────────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude 'upload/' \
  --exclude 'download/' \
  --exclude 'tool-results/' \
  --exclude '.stage-v1.1/' \
  --exclude '.stage-v1.2/' \
  --exclude '.stage-v1.3/' \
  --exclude 'skills/' \
  --exclude 'bun.lock' \
  --exclude '*.tmp' \
  --exclude 'bun-error.log' \
  --exclude '.env.local' \
  --exclude 'tsconfig.tsbuildinfo' \
  --exclude 'next-env.d.ts' \
  --exclude '*.log' \
  --exclude '.logs/' \
  --exclude 'v12_*.png' \
  --exclude 'scripts/*.png' \
  --exclude 'scripts/v5_*.png' \
  --exclude 'scripts/vlm_*.json' \
  --exclude 'scripts/search*.json' \
  "$ROOT/" "$STAGE/$FOLDER/"

# ── Script WaveScope v5 + guide inclus dans le zip ─────────────────────────
cp "$ROOT/download/wavescope_ict_v5.pine" "$STAGE/$FOLDER/wavescope_ict_v5.pine"
cp "$ROOT/download/GUIDE-REGLAGES-V5.md" "$STAGE/$FOLDER/GUIDE-REGLAGES-V5.md"

# ── README des nouveautés v1.3 ────────────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.3-REGLAGES-PINE.md" <<'EOF'
# Pine v6 Engine — v1.3 « Réglages Pine & WaveScope v5 »

Cette version corrige le problème « le menu de réglage des paramètres ne
fonctionne pas » : l'app ne transmettait **jamais** les réglages au moteur
Pine et n'avait aucun panneau pour les éditer. C'est réparé — et le script
**WaveScope ICT v5** (avec les arrière-plans SL/TP) est inclus.

## 1. Panneau ⚙ Réglages (éditeur Pine)

Bouton **⚙ Réglages** dans la barre de l'éditeur (à côté de Run) :

- tous les `input()` du script, **groupés** comme dans TradingView ;
- widgets adaptés : **cases à cocher** (bool), **sélecteur de couleur**,
  **champs numériques** (min/max/pas), **listes déroulantes** (options),
  champs texte (session…) ;
- **application immédiate** : le script est ré-exécuté avec vos valeurs
  (~0,5 s) — le graphique change sous vos yeux ;
- **persistance par script** (localStorage) : les réglages survivent au
  rechargement de la page ;
- bouton **« Défauts »** pour tout restaurer.

Vérification intégrée : la ligne « ZigZag — N pivots • seuil effectif » du
tableau de bord de WaveScope prouve en direct que Deviation/Depth/Backstep
sont appliqués.

## 2. WaveScope ICT v5 (inclus : wavescope_ict_v5.pine)

Le script v5 est fourni à la racine du zip. Chargez-le via l'éditeur Pine →
bouton **Upload** (ou collez-le dans le textarea → Run).

Nouveautés v5 :

- **ZONES SL / TP EN ARRIÈRE-PLAN** : fond rouge = niveau d'invalidation
  (pool de liquidité opposé), fond vert = cible ; étiquettes
  « TP 🎯 BSL 1.1423 » / « SL ✕ SSL 1.1389 » recalculées à chaque barre ;
- **115 paramètres nommés** (plus aucune entrée « (2) », « (3) ») → le menu
  Réglages est lisible et les clés sont stables ;
- **ligne « TP / SL »** dans le tableau de bord ;
- ZigZag **Auto (×ATR)** par défaut (fonctionne de S5 à D1) ;
- toute la richesse de la v2 : structure interne, MIT, sessions, compteurs
  élevés, pièges retail, projection ICT, bannière « TENDANCE À SUIVRE »,
  conformité ICT/SMC du livre (Akash Gul).

Voir **GUIDE-REGLAGES-V5.md** (inclus) pour le mode d'emploi complet.

## 3. Lancer sur Termux

```bash
unzip pine_v6_engine_v1.3.zip
cd pine_v6_engine_v1.3
npm install --no-audit --no-fund
./start-dev.sh
```
EOF

# ── Création du zip ───────────────────────────────────────────────────────
rm -f "$OUT"
(cd "$STAGE" && zip -qr9 "$OUT" "$FOLDER")

# ── Vérification ──────────────────────────────────────────────────────────
echo "=== Archive créée : $OUT ==="
du -h "$OUT"
unzip -l "$OUT" | tail -1
echo "=== Fichiers clés présents ==="
unzip -l "$OUT" | grep -E 'wavescope_ict_v5|GUIDE-REGLAGES-V5|README-V1.3|pine-engine.ts|pine-store.ts|pine-script-editor|package-lock.json$' | awk '{print $1, $4}'

# Nettoyage du staging
rm -rf "$STAGE"
