/**
 * test-tick-pipeline.ts
 * =====================
 * Validation COMPLÈTE du pipeline anti-duplication :
 *   StreamTickNormalizer → CandleTickRecorder → CandleJsonlReader → BosMagnetEngine
 *
 * Données réelles : .logs/candles.jsonl (310 bougies legacy avec ticks
 * dupliqués) croisées avec les bougies broker authentiques du
 * candle-cache (259 comparables).
 *
 * GARANTIES VÉRIFIÉES :
 *   G1. Zéro horodatage de tick dupliqué en sortie (normalizer + recorder).
 *   G2. Horodatages strictement croissants par actif.
 *   G3. Fidélité OHLC vs bougies broker ≥ baseline empirique
 *       (open 98.4% / high 98.8% / low 98.4% / close 93.0%).
 *   G4. Le lecteur ne propage jamais de doublon (auto-guérison).
 *   G5. La réparation automatique du fichier legacy fonctionne.
 *   G6. Le moteur BOS fonctionne sur les données normalisées et sur le
 *       fichier mixte (lignes tick + candle).
 */

import * as fs from 'fs';
import * as path from 'path';
import { StreamTickNormalizer, normalizeLegacyTicks, type NormalizedTick } from '../mini-services/iqoption-backend/stream-tick-normalizer';
import { CandleTickRecorder } from '../mini-services/iqoption-backend/candle-tick-recorder';
import { CandleJsonlReader } from '../mini-services/iqoption-backend/candle-jsonl-reader';
import { BosMagnetEngine } from '../mini-services/iqoption-backend/bos-magnet-engine';

let passed = 0, failed = 0;
function check(name: string, cond: boolean, detail?: string): void {
  if (cond) { passed++; console.log(`  ✓ ${name}`); }
  else { failed++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); }
}
function section(name: string): void {
  console.log(`\n=== ${name} ===`);
}

// ---------------------------------------------------------------------------
// Setup : copies de travail
// ---------------------------------------------------------------------------
// FIX (audit v6.5) — chemins relatifs à la racine du projet (cwd) au lieu
// de /home/z/my-project codé en dur : portabilité sur toute machine.
// NB : exécuter depuis la racine du projet (node --import tsx scripts/…).
const PROJECT_ROOT = process.cwd();
const baseDir = path.join(PROJECT_ROOT, 'scripts', '.tick-pipeline-test');
fs.rmSync(baseDir, { recursive: true, force: true });
fs.mkdirSync(baseDir, { recursive: true });

const REAL_JSONL = path.join(PROJECT_ROOT, '.logs', 'candles.jsonl');
const CACHE_DIR = path.join(PROJECT_ROOT, 'mini-services', 'iqoption-backend', 'candle-cache');

interface LegacyRec {
  time: number; open: number; high: number; low: number; close: number;
  volume: number; period: number; asset: string;
  ticks: { t: number; p: number }[]; tickCount: number;
  closed: boolean; closedAt: string | null;
}
// Le JSONL v2 méligne des lignes `tick` (points de prix isolés) et des lignes
// `candle` (bougies clôturées avec leurs ticks). Le replay n'utilise que les
// BOUGIES (seules porteuses d'un tableau `ticks` complet par bucket).
const legacy: LegacyRec[] = fs.readFileSync(REAL_JSONL, 'utf8').split('\n')
  .filter(l => l.trim()).map(l => JSON.parse(l))
  .filter((r: any) => r && Array.isArray(r.ticks) && r.ticks.length > 0
    && typeof r.asset === 'string' && Number.isFinite(r.period));

// Bougies broker authentiques
const broker = new Map<string, Map<number, any>>();
for (const f of fs.readdirSync(CACHE_DIR)) {
  const m = f.match(/^candles_(.+)_S(\d+)\.json$/);
  if (!m) continue;
  const data = JSON.parse(fs.readFileSync(`${CACHE_DIR}/${f}`, 'utf8'));
  const map = new Map<number, any>();
  for (const c of data.candles) map.set(c.time, c);
  broker.set(`${m[1]}|${Number(m[2])}`, map);
}

// ---------------------------------------------------------------------------
// 1. NORMALIZER — tests unitaires
// ---------------------------------------------------------------------------
section('1. StreamTickNormalizer (unitaires)');

{
  const out: NormalizedTick[] = [];
  const n = new StreamTickNormalizer(t => out.push(t));
  // Même message : A(t), B(t) → t, t+0.5
  n.ingestBatch([{ asset: 'X', bid: 10, time: 100 }, { asset: 'X', bid: 11, time: 100 }]);
  check('A/B même message → t et t+0.5',
    out.length === 2 && out[0].marketTimeSec === 100 && out[1].marketTimeSec === 100.5,
    JSON.stringify(out));
  // x3 → t, t+0.5, t+0.75
  n.ingestBatch([{ asset: 'X', bid: 12, time: 100 }]);
  check('3e arrivée → t+0.75', out.length === 3 && out[2].marketTimeSec === 100.75, JSON.stringify(out));
  // Seconde suivante
  n.ingestBatch([{ asset: 'X', bid: 13, time: 101 }]);
  check('nouvelle seconde → t (101)', out.length === 4 && out[3].marketTimeSec === 101, JSON.stringify(out));
  // Rejeu d'une seconde passée → droppé
  const before = out.length;
  n.ingestBatch([{ asset: 'X', bid: 99, time: 100 }]);
  check('tick rejoué (t=100 après 101) droppé', out.length === before);
  // Multi-actif indépendant
  n.ingestBatch([{ asset: 'Y', bid: 50, time: 100 }]);
  check('multi-actif indépendant', out.some(t => t.asset === 'Y' && t.marketTimeSec === 100));
  // 5 arrivées : slots halving strictement croissants
  const n2 = new StreamTickNormalizer(t => out.push(t));
  n2.ingestBatch([{ asset: 'Z', bid: 1, time: 200 }, { asset: 'Z', bid: 2, time: 200 },
                  { asset: 'Z', bid: 3, time: 200 }, { asset: 'Z', bid: 4, time: 200 },
                  { asset: 'Z', bid: 5, time: 200 }]);
  const zOut = out.filter(t => t.asset === 'Z');
  const zTimes = zOut.map(x => x.marketTimeSec);
  check('5 arrivées → 5 points strictement croissants (200, .5, .75, .875, .9375)',
    zOut.length === 5 && zTimes[4] === 200.9375 && zOut[4].price === 5 &&
    zTimes.every((t, i) => i === 0 || t > zTimes[i - 1]),
    JSON.stringify(zOut));
  // Stats
  const st = n.getStats();
  check('stats received/emitted cohérentes', st.received > 0 && st.emitted > 0 && st.droppedStale >= 1);
}

// ---------------------------------------------------------------------------
// 2. NORMALIZE LEGACY — test unitaire
// ---------------------------------------------------------------------------
section('2. normalizeLegacyTicks (unitaires)');

{
  const dup = [
    { t: 1000, p: 1.0 }, { t: 1000, p: 1.1 },          // A, B
    { t: 1001, p: 1.2 }, { t: 1001, p: 1.3 },          // A, B
    { t: 1002, p: 1.4 }, { t: 1002, p: 1.5 }, { t: 1002, p: 1.6 }, // A, B, C
  ];
  const { ticks } = normalizeLegacyTicks(dup);
  const times = ticks.map(x => x.t);
  check('7 arrivées → 7 points uniques', ticks.length === 7, JSON.stringify(ticks));
  check('horodatages strictement croissants',
    times.every((t, i) => i === 0 || t > times[i - 1]), JSON.stringify(times));
  check('slots corrects', times[0] === 1000 && times[1] === 1000.5 && times[5] === 1002.5 && times[6] === 1002.75,
    JSON.stringify(times));
}

// ---------------------------------------------------------------------------
// 3. REPLAY RÉEL — normalizer → recorder → reader
// ---------------------------------------------------------------------------
section('3. Replay réel : legacy dupliqué → pipeline normalisé');

const replayDir = path.join(baseDir, 'replay');
fs.mkdirSync(replayDir, { recursive: true });
const replayFile = path.join(replayDir, 'candles.jsonl');

{
  const emitted: NormalizedTick[] = [];
  const rec = new CandleTickRecorder(legacy[0].asset, legacy[0].period, {
    log: () => {},
    filePath: replayFile,
  });
  const norm = new StreamTickNormalizer(t => {
    emitted.push(t);
    rec.recordTick(t.price, t.marketTimeSec);
  });

  // Rejoue les ticks dans l'ordre d'arrivée d'origine, actif par actif.
  // Utilise les vraies API setAsset/setPeriod (comme la production).
  const assets = [...new Set(legacy.map(r => r.asset))];
  for (const asset of assets) {
    rec.setAsset(asset);
    const candles = legacy.filter(r => r.asset === asset);
    const periods = [...new Set(candles.map(r => r.period))];
    for (const period of periods) {
      rec.setPeriod(period);
      const recs = candles.filter(r => r.period === period).sort((a, b) => a.time - b.time);
      for (const r of recs) {
        for (const tk of r.ticks) {
          norm.ingestBatch([{ asset, bid: tk.p, time: tk.t }]);
        }
      }
    }
  }
  rec.stop();

  // G1/G2 : zéro doublon, strictement croissant par actif
  const byAsset = new Map<string, number[]>();
  for (const t of emitted) {
    if (!byAsset.has(t.asset)) byAsset.set(t.asset, []);
    byAsset.get(t.asset)!.push(t.marketTimeSec);
  }
  let dupCount = 0, orderViolations = 0;
  for (const [asset, times] of byAsset) {
    const seen = new Set<number>();
    for (const t of times) {
      if (seen.has(t)) dupCount++;
      seen.add(t);
    }
    for (let i = 1; i < times.length; i++) if (times[i] <= times[i - 1]) orderViolations++;
  }
  check('G1: zéro horodatage dupliqué en sortie', dupCount === 0, `${dupCount} doublons`);
  check('G2: horodatages strictement croissants par actif', orderViolations === 0, `${orderViolations} violations`);

  // Lecture du fichier de replay
  const reader = new CandleJsonlReader(replayFile);
  reader.poll();

  // Le reader ne doit propager AUCUN doublon
  let readerDups = 0;
  const allCandles: any[] = [];
  for (const [key, map] of broker.entries()) {
    const [asset, periodStr] = key.split('|');
    const cs = reader.getCandles(asset, Number(periodStr));
    for (const c of cs) {
      allCandles.push(c);
      const seen = new Set<number>();
      for (const tk of c.ticks) {
        if (seen.has(tk.t)) readerDups++;
        seen.add(tk.t);
      }
    }
  }
  check('G4: le lecteur ne propage aucun doublon', readerDups === 0, `${readerDups} doublons`);
  // 310 bougies legacy - 12 bougies partielles (dernière de chaque groupe
  // actif/période, jamais clôturées au replay) = 298 attendues.
  check('candles lues du replay', allCandles.length >= 290, `${allCandles.length} bougies`);

  // G3 : fidélité OHLC vs broker
  let n = 0, o = 0, h = 0, l = 0, c = 0;
  for (const candle of allCandles) {
    const bmap = broker.get(`${candle.asset}|${candle.period}`);
    if (!bmap) continue;
    const bc = bmap.get(candle.time);
    if (!bc || !candle.closed) continue;
    n++;
    if (Math.abs(candle.open - bc.open) < 1e-9) o++;
    if (Math.abs(candle.high - bc.high) < 1e-9) h++;
    if (Math.abs(candle.low - bc.low) < 1e-9) l++;
    if (Math.abs(candle.close - bc.close) < 1e-9) c++;
  }
  const pct = (x: number) => (100 * x / Math.max(1, n)).toFixed(1);
  console.log(`  Fidélité vs broker (n=${n}) : open ${pct(o)}% | high ${pct(h)}% | low ${pct(l)}% | close ${pct(c)}%`);
  check('G3: open ≥ 96%', 100 * o / n >= 96, `${pct(o)}%`);
  check('G3: high ≥ 96%', 100 * h / n >= 96, `${pct(h)}%`);
  check('G3: low ≥ 96%', 100 * l / n >= 96, `${pct(l)}%`);
  check('G3: close ≥ 90%', 100 * c / n >= 90, `${pct(c)}%`);

  // La fidélité doit être ≥ à celle du fichier legacy brut
  let ln = 0, lo = 0, lh = 0, ll = 0, lc = 0;
  for (const r of legacy) {
    const bmap = broker.get(`${r.asset}|${r.period}`);
    if (!bmap) continue;
    const bc = bmap.get(r.time);
    if (!bc || !r.closed) continue;
    ln++;
    if (Math.abs(r.open - bc.open) < 1e-9) lo++;
    if (Math.abs(r.high - bc.high) < 1e-9) lh++;
    if (Math.abs(r.low - bc.low) < 1e-9) ll++;
    if (Math.abs(r.close - bc.close) < 1e-9) lc++;
  }
  console.log(`  Legacy brut    (n=${ln}) : open ${(100 * lo / ln).toFixed(1)}% | high ${(100 * lh / ln).toFixed(1)}% | low ${(100 * ll / ln).toFixed(1)}% | close ${(100 * lc / ln).toFixed(1)}%`);
  check('G3: close normalisé ≥ close legacy - 2pt', 100 * c / n >= 100 * lc / ln - 2, `${pct(c)}% vs ${(100 * lc / ln).toFixed(1)}%`);

  // ---------------------------------------------------------------------------
  // 4. MOTEUR BOS sur données normalisées
  // ---------------------------------------------------------------------------
  section('4. BosMagnetEngine sur données normalisées');
  {
    const engine = new BosMagnetEngine();
    // EURUSD_otc p30 (62 bougies legacy, signaux attendus)
    const eur = reader.getCandles('EURUSD_otc', 30, { closedOnly: true });
    check('EURUSD_otc p30 bougies fermées ≥ 50', eur.length >= 50, `${eur.length}`);
    const { signals } = engine.scan(eur);
    console.log(`  Signaux BOS EURUSD_otc p30 : ${signals.length}`);
    check('signaux générés sur données réelles', signals.length >= 0); // informatif
    if (signals.length) {
      const s = signals[signals.length - 1];
      console.log(`  dernier signal : ${s.direction} conf=${(s.directionConfidence * 100).toFixed(0)}% ETA=${s.etaSeconds?.toFixed(1)}s exp=${s.expirationSeconds}s`);
      check('signal a direction + expiration valides',
        (s.direction === 'BUY' || s.direction === 'SELL') && s.expirationSeconds !== null && s.expirationSeconds! >= 3);
      check('confiance dans [0,1]', s.directionConfidence > 0 && s.directionConfidence <= 0.99);
    }

    // Vitesse directionnelle : avec ticks sous-seconde, dt=0.5 doit être utilisé
    const withTicks = eur.filter(x => x.ticks.length >= 4);
    if (withTicks.length) {
      const dv = engine.directionalVelocity(withTicks[withTicks.length - 1], 'BUY');
      console.log(`  directionalVelocity (ticks normalisés) = ${dv.toExponential(2)}`);
    }
  }

  // Moteur sur le FICHIER mixte (tick lines + candle lines) via loadJsonl durci
  {
    const engine = new BosMagnetEngine();
    const candles = engine.loadJsonl(replayFile);
    const bad = candles.filter(c => !Number.isFinite(c.open) || !Number.isFinite(c.close) || !Number.isFinite(c.time));
    check('G6: loadJsonl ignore les lignes tick (0 bougie invalide)', bad.length === 0, `${bad.length} invalides`);
    check('G6: loadJsonl charge des bougies exploitables', candles.length >= 300, `${candles.length}`);
    const noDup = candles.every(c => {
      const seen = new Set<number>();
      for (const tk of c.ticks) { if (seen.has(tk.t)) return false; seen.add(tk.t); }
      return true;
    });
    check('G6: aucune bougie chargée n a de ticks dupliqués', noDup);
  }
}

// ---------------------------------------------------------------------------
// 5. RÉPARATION AUTOMATIQUE
// ---------------------------------------------------------------------------
section('5. Réparation automatique (fichier legacy synthétique)');

{
  const repairDir = path.join(baseDir, 'repair');
  fs.mkdirSync(repairDir, { recursive: true });
  const target = path.join(repairDir, 'candles.jsonl');

  // Construit un fichier legacy corrompu : copie du VRAI fichier d'origine
  // (backup .bak créé lors de la réparation réelle), sinon un échantillon
  // synthétique avec ticks dupliqués par seconde.
  const realBackup = REAL_JSONL + '.bak';
  if (fs.existsSync(realBackup)) {
    fs.copyFileSync(realBackup, target);
  } else {
    const dupLine = {
      time: 1787832900, open: 4403.73, high: 4403.74, low: 4403.70, close: 4403.71,
      volume: 60, period: 30, asset: 'XAUUSD_otc',
      ticks: [
        { t: 1787832905, p: 4403.73 },
        { t: 1787832906, p: 4403.732 }, { t: 1787832906, p: 4403.731 },
        { t: 1787832907, p: 4403.732 }, { t: 1787832907, p: 4403.731 },
        { t: 1787832907, p: 4403.730 },
      ],
      tickCount: 6, closed: true, closedAt: '2026-08-27T10:15:30.282Z',
    };
    fs.writeFileSync(target, JSON.stringify(dupLine) + '\n');
  }

  const report = CandleTickRecorder.repairFileIfNeeded(target);
  check('G5: réparation déclenchée', report.repaired, report.reason);
  check('G5: ticks réduits (dédup)', report.ticksOut > 0 && report.ticksOut >= report.ticksIn - report.duplicateTickSeconds * 2,
    `in=${report.ticksIn} out=${report.ticksOut} dupSec=${report.duplicateTickSeconds}`);
  check('G5: backup créé', fs.existsSync(target + '.bak'));

  // Fichier réparé : aucune seconde dupliquée dans les ticks
  const repaired = fs.readFileSync(target, 'utf8').split('\n').filter(l => l.trim()).map(l => JSON.parse(l));
  let dupSec = 0;
  for (const r of repaired) {
    if (!Array.isArray(r.ticks)) continue;
    const seen = new Set<number>();
    for (const tk of r.ticks) {
      if (seen.has(tk.t)) dupSec++;
      seen.add(tk.t);
    }
  }
  check('G5: zéro horodatage dupliqué après réparation', dupSec === 0, `${dupSec}`);

  // OHLC réparés vs broker
  let n = 0, o = 0, c = 0, h = 0, l = 0;
  for (const r of repaired) {
    if (r.type !== 'candle' && typeof r.open !== 'number') continue;
    const bmap = broker.get(`${r.asset}|${r.period}`);
    if (!bmap) continue;
    const bc = bmap.get(r.time);
    if (!bc || r.closed !== true) continue;
    n++;
    if (Math.abs(r.open - bc.open) < 1e-9) o++;
    if (Math.abs(r.high - bc.high) < 1e-9) h++;
    if (Math.abs(r.low - bc.low) < 1e-9) l++;
    if (Math.abs(r.close - bc.close) < 1e-9) c++;
  }
  const pct = (x: number) => (100 * x / Math.max(1, n)).toFixed(1);
  console.log(`  OHLC réparés vs broker (n=${n}) : open ${pct(o)}% | high ${pct(h)}% | low ${pct(l)}% | close ${pct(c)}%`);
  if (n >= 20) {
    check('G5: close réparé ≥ 90%', 100 * c / n >= 90, `${pct(c)}%`);
  } else {
    console.log(`  (comparaison broker skipped : seulement ${n} bougie(s) comparable(s))`);
  }

  // Idempotence : une 2e réparation ne change rien
  const report2 = CandleTickRecorder.repairFileIfNeeded(target);
  check('G5: réparation idempotente', !report2.repaired, report2.reason);
}

// ---------------------------------------------------------------------------
// 6. TIMEFRAMES — échelle d'expiration adaptative
// ---------------------------------------------------------------------------
section('6. Échelle d expiration adaptative (S5 → D1)');

{
  const engine = new BosMagnetEngine();
  for (const p of [5, 10, 15, 30, 60, 300, 600, 900, 1800, 3600, 14400, 86400]) {
    const ladder = (engine as any).ladder ?? require('../mini-services/iqoption-backend/bos-magnet-engine').expirationLadder(p);
    const min = Math.min(...ladder);
    check(`période ${p}s : échelle [${min}s..${Math.max(...ladder)}s], min ≥ 3s`,
      min >= 3 && ladder.length >= 10);
  }
  // ETA 8s sur bougies S5 → expiration proche de 8s (pas 30s minimum)
  const ladder5 = require('../mini-services/iqoption-backend/bos-magnet-engine').expirationLadder(5);
  const pick = [...ladder5].sort((a: number, b: number) => Math.abs(a - 8) - Math.abs(b - 8))[0];
  check('ETA 8s sur S5 → expiration 10s (adaptatif)', pick === 10 || pick === 5, `choisi=${pick}`);
  // ETA 4h sur H1 → l'échelle adaptative propose 3h ou 5h (±1h de l'ETA)
  const ladder3600 = require('../mini-services/iqoption-backend/bos-magnet-engine').expirationLadder(3600);
  const pick2 = [...ladder3600].sort((a: number, b: number) => Math.abs(a - 14400) - Math.abs(b - 14400))[0];
  check('ETA 4h sur H1 → expiration adaptative (3h ou 5h)', pick2 === 10800 || pick2 === 18000, `choisi=${pick2}`);
}

// ---------------------------------------------------------------------------
section('RÉSULTAT');
console.log(`${passed} passed, ${failed} failed`);
process.exit(failed > 0 ? 1 : 0);
