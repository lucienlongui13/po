#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v1.5.sh — Livraison v1.5 « STOP/RJT par côté + Log trades »
#   - Signal Strategy : chaque option d'ordre CALL ▲ / PUT ▼ possède SES
#     propres conditions de STOP et de REJET (sections dédiées dans chaque
#     onglet — plus d'onglet STOP/RJT global) ;
#   - Strategy Tester : switch « Log trades » → journalisation de chaque
#     trade simulé dans .logs/trade.jsonl (conditions détectées avant et
#     pendant le trade + bougies OHLC + source + contexte) via l'API
#     /api/trade-log ;
#   - WaveScope v5 + guides toujours inclus.
# Sortie : /home/z/my-project/download/pine_v6_engine_v1.5.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v1.5"
FOLDER=pine_v6_engine_v1.5
OUT="$ROOT/download/pine_v6_engine_v1.5.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (mêmes exclusions que v1.0→v1.4) ─────────────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude 'upload/' \
  --exclude 'download/' \
  --exclude 'tool-results/' \
  --exclude '.stage-v1.1/' \
  --exclude '.stage-v1.2/' \
  --exclude '.stage-v1.3/' \
  --exclude '.stage-v1.4/' \
  --exclude '.stage-v1.5/' \
  --exclude 'skills/' \
  --exclude 'bun.lock' \
  --exclude '*.tmp' \
  --exclude 'bun-error.log' \
  --exclude '.env.local' \
  --exclude 'tsconfig.tsbuildinfo' \
  --exclude 'next-env.d.ts' \
  --exclude '*.log' \
  --exclude '.logs/' \
  --exclude 'v12_*.png' \
  --exclude 'scripts/*.png' \
  --exclude 'scripts/vlm_*.json' \
  --exclude 'scripts/search*.json' \
  "$ROOT/" "$STAGE/$FOLDER/"

# ── Script WaveScope v5 + guide inclus dans le zip ─────────────────────────
cp "$ROOT/download/wavescope_ict_v5.pine" "$STAGE/$FOLDER/wavescope_ict_v5.pine"
cp "$ROOT/download/GUIDE-REGLAGES-V5.md" "$STAGE/$FOLDER/GUIDE-REGLAGES-V5.md"

# ── README des nouveautés v1.5 ────────────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.5-STOP-RJT-ET-LOG-TRADES.md" <<'EOF'
# Pine v6 Engine — v1.5 « STOP/RJT par côté + Log trades »

Deux nouveautés demandées : des conditions de stop et de rejet **propres à
chaque option d'ordre**, et un journal détaillé des trades du Strategy Tester.

## 1. STOP / RJT propres à CALL ▲ et à PUT ▼

Chaque option d'ordre possède maintenant **ses propres conditions de stop et
de rejet**. L'onglet STOP/RJT global disparaît : les listes vivent désormais
**dans chaque onglet**.

| Avant (v1.4) | Après (v1.5) |
|---|---|
| Onglet « STOP/RJT » global (stop/rejet partagés par CALL et PUT) | Dans **CALL ▲** : sections « CONDITIONS DE STOP CALL ▲ » + « CONDITIONS DE REJET CALL ▲ » · dans **PUT ▼** : « … STOP PUT ▼ » + « … REJET PUT ▼ » |

- Un **stop CALL** ne suspend **que les mises CALL** — les mises PUT continvent
  normalement (et inversement) ;
- Un **rejet PUT** ne rejette **que les émissions PUT** (et inversement) ;
- **Badge « SR n »** sur les boutons d'onglet CALL ▲ / PUT ▼ (n = stop + rejet
  du côté) — survolez-le pour le détail stop · rejet ;
- **Bannière d'état par côté** : « STOP CALL ▲ actif — mises CALL suspendues »,
  « REJET PUT ▼ actif… » n'apparaissent QUE pour les côtés concernés ;
- Les émissions des **stratégies Auto Trade testées** respectent aussi les
  stops/rejets du côté émis ;
- **Migration automatique** : votre ancienne configuration (stops/rejets
  partagés) est recopiée des deux côtés au premier chargement — comportement
  identique à avant, puis vous pouvez différencier chaque côté librement.

## 2. Switch « Log trades » dans le Strategy Tester

Un commutateur **LOG TRADES** apparaît dans la barre du Strategy Tester
(à côté de RESET TRADES).

- **OFF (défaut)** : rien n'est journalisé — aucun fichier n'est écrit ;
- **ON** : **chaque trade simulé** (CALL/PUT, quelle que soit sa source :
  conditions Signal Strategy, stratégie Auto Trade testée ou ordre manuel)
  est ajouté au fichier **`.logs/trade.jsonl`** (une ligne JSON par trade,
  créé automatiquement à la racine du projet) avec :
  - le **trade complet** : côté, mise, payout, prix/heure d'entrée et de
    sortie, expiration, résultat (won/lost/refunded), P&L ;
  - la **source** : stratégie + conditions déclencheuses qui ont produit
    l'ordre ;
  - **toutes les conditions détectées sur les bougies apparues AVANT le
    trade** (fenêtre de contexte = « Fenêtre (bougies) » des Réglages) ;
  - les **bougies OHLC** de cette fenêtre avant ;
  - **toutes les conditions détectées sur les bougies PENDANT le trade**
    (de l'entrée jusqu'au règlement) + leurs bougies OHLC ;
  - le **contexte** : actif, timeframe, fenêtre, solde, P&L, vitesse replay.
- La préférence ON/OFF est **persistée** (rechargement compris) ;
- Le compteur « n loggés » s'affiche à côté du switch (erreur en rouge si
  le fichier est inaccessible).

### Lire le journal

```bash
# Nombre de trades loggés
wc -l .logs/trade.jsonl

# Les 2 derniers trades (mise en forme)
tail -n 2 .logs/trade.jsonl | python3 -m json.tool --json-lines

# Conditions présentes AVANT les trades perdants (exemple d'analyse)
grep '"status":"lost"' .logs/trade.jsonl | python3 -c "
import json, sys
for line in sys.stdin:
    t = json.loads(line)
    print(t['trade']['side'].upper(), '→',
          [c['id'] for c in t['conditionsBefore']])
"
```

Chaque ligne est autonome (format JSONL) : vous pouvez la charger dans un
tableur, un script Python ou un notebook pour comprendre **quelles
conditions précèdent et accompagnent vos gains et vos pertes**.

## Moteur (vérifié par tests)

- `scripts/test-stopreject-sides.ts` (17 tests) : stop/rejet par côté,
  indépendance CALL/PUT, émissions externes, migration de l'ancienne config ;
- `scripts/test-trade-logger.ts` (21 tests) : OFF → rien loggé, ON → entrée
  complète (conditions avant/pendant, bougies, source, contexte), ordre
  manuel, reset, JSONL valide ;
- Non-régression : `test-split-conditions.ts` (9) + `test-adapters.ts` (26) ;
- E2E navigateur : `scripts/e2e-v15-stopreject-log.sh` — 23/23 ✓.

## Lancer sur Termux

```bash
unzip pine_v6_engine_v1.5.zip
cd pine_v6_engine_v1.5
npm install --no-audit --no-fund
./start-dev.sh
```

Le fichier `.logs/trade.jsonl` est créé automatiquement dès le premier trade
réglé avec le switch ON (dossier `.logs/` à la racine, à côté de
`package.json`).
EOF

# ── Création du zip ───────────────────────────────────────────────────────
rm -f "$OUT"
(cd "$STAGE" && zip -qr9 "$OUT" "$FOLDER")

# ── Vérification ──────────────────────────────────────────────────────────
echo "=== Archive créée : $OUT ==="
du -h "$OUT"
unzip -l "$OUT" | tail -1
echo "=== Fichiers clés présents ==="
unzip -l "$OUT" | grep -E 'wavescope_ict_v5|GUIDE-REGLAGES-V5|README-V1.5|signal-strategy-panel|trade-logger|trade-log/route|package-lock.json$' | awk '{print $1, $4}'
echo "=== Marqueurs de fonctionnalités (vérification rapide) ==="
# NOTE : les titres de sections sont construits au rendu (« CONDITIONS DE
# STOP {sideLabel} ») → on greppe les littéraux de source.
unzip -p "$OUT" "$FOLDER/src/components/trading/signal-strategy-panel.tsx" | grep -c 'CONDITIONS DE STOP' | xargs echo "section STOP par côté (littéral, >=1 attendu) :" || true
unzip -p "$OUT" "$FOLDER/src/components/trading/signal-strategy-panel.tsx" | grep -c 'CONDITIONS DE REJET' | xargs echo "section REJET par côté (littéral, >=1 attendu) :" || true
unzip -p "$OUT" "$FOLDER/src/components/trading/signal-strategy-panel.tsx" | grep -c 'onToggleSideListSignal' | xargs echo "toggle stop/rejet par côté (>=3 attendu) :" || true
unzip -p "$OUT" "$FOLDER/src/components/trading/signal-strategy-panel.tsx" | grep -c 'StopRejectTab' | xargs echo "StopRejectTab (0 attendu) :" || true
unzip -p "$OUT" "$FOLDER/src/lib/signal-catalog.ts" | grep -c 'stopCallSignalIds' | xargs echo "config stopCallSignalIds :" || true
unzip -p "$OUT" "$FOLDER/src/lib/trade-logger.ts" | grep -c 'conditionsBefore' | xargs echo "trade-logger conditionsBefore :" || true
unzip -p "$OUT" "$FOLDER/src/components/trading/chart/backtest-panel.tsx" | grep -c 'Toggle log trades' | xargs echo "switch Log trades :" || true
unzip -p "$OUT" "$FOLDER/src/app/api/trade-log/route.ts" | grep -c 'trade.jsonl' | xargs echo "API trade.jsonl :" || true
unzip -t "$OUT" > /dev/null && echo "=== Intégrité zip OK ==="

# Nettoyage du staging
rm -rf "$STAGE"
