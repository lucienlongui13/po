#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v1.8.sh — Livraison v1.8 « Alignement universel + Panes + Alertes »
#   1. ALIGNEMENT : `syminfo.mintick` dérivé automatiquement des bougies —
#      plus jamais la valeur par défaut 0.01 de piner qui éloignait les
#      indicateurs des bougies (labels BOS/CHoCH/CISD à ±0,1/0,2/0,3 du prix) ;
#   2. PANES : les scripts overlay=false (RSI, MACD, oscillateurs) ont leur
#      PROPRE panneau synchronisé sous le graphique (plots + hlines + fills +
#      markers + drawings) — plus de ligne flottante sur les bougies ni de
#      hlines 30/70 qui explosent l'échelle de prix ;
#   3. ALERTES : les événements alert()/alertcondition() de main.pine sont
#      visibles — cloches ambre ancrées sur les bougies + toasts pour les
#      nouveaux événements + journal dans la console de l'éditeur.
# Sortie : /home/z/my-project/download/pine_v6_engine_v1.8.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v1.8"
FOLDER=pine_v6_engine_v1.8
OUT="$ROOT/download/pine_v6_engine_v1.8.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (mêmes exclusions que v1.0→v1.7) ─────────────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude 'upload/' \
  --exclude 'download/' \
  --exclude 'tool-results/' \
  --exclude '.stage-v1.1/' \
  --exclude '.stage-v1.2/' \
  --exclude '.stage-v1.3/' \
  --exclude '.stage-v1.4/' \
  --exclude '.stage-v1.5/' \
  --exclude '.stage-v1.6/' \
  --exclude '.stage-v1.7/' \
  --exclude '.stage-v1.8/' \
  --exclude 'skills/' \
  --exclude 'bun.lock' \
  --exclude '*.tmp' \
  --exclude 'bun-error.log' \
  --exclude '.env.local' \
  --exclude 'tsconfig.tsbuildinfo' \
  --exclude 'next-env.d.ts' \
  --exclude '*.log' \
  --exclude '.logs/' \
  --exclude 'v12_*.png' \
  --exclude 'scripts/*.png' \
  --exclude 'scripts/diag/' \
  --exclude 'scripts/e2e-v18-*.png' \
  --exclude 'scripts/vlm_*.json' \
  --exclude 'scripts/search*.json' \
  --exclude 'scripts/e2e-v18-probe.txt' \
  --exclude 'db/' \
  "$ROOT/" "$STAGE/$FOLDER/"

# ── WaveScope v5 + guide réglages (inclus depuis v1.3) ────────────────────
cp "$ROOT/download/wavescope_ict_v5.pine" "$STAGE/$FOLDER/wavescope_ict_v5.pine"
cp "$ROOT/download/GUIDE-REGLAGES-V5.md" "$STAGE/$FOLDER/GUIDE-REGLAGES-V5.md"

# ── Pack d'exemple (celui fourni par l'utilisateur) pour test immédiat ────
mkdir -p "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies/libs"
cp "$ROOT/upload/piracy_extracted/Market_structures_scripts/Main.pine" \
   "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies/Main.pine"
cp "$ROOT/upload/piracy_extracted/Market_structures_scripts/libs/"*.pine \
   "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies/libs/"

# ── README des fonctionnalités v1.8 ───────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.8-ALIGNEMENT-PANES-ALERTES.md" <<'EOF'
# Pine v6 Engine — v1.8 « Alignement universel + Panes + Alertes »

Trois corrections majeures pour que **tous les types de scripts TradingView
s'adaptent parfaitement au graphique**, quel que soit l'actif ou le marché.

## 1. Les indicateurs restent collés aux bougies (correctif principal)

### Le bug
Les indicateurs « s'éloignaient des bougies » : à chaque nouvelle bougie, les
labels BOS/CHoCH/CISD flottaient à 10, 20 ou 30 cents du prix, dans le vide
sous le graphique. Le même script fonctionne à 100 % sur TradingView — le bug
était dans le projet, pas dans les scripts.

### La cause racine (mesurée)
Les scripts TradingView dimensionnent leurs décalages avec `syminfo.mintick`
(le plus petit mouvement de prix de l'actif) :

```pine
base_offset = math.max(atr * 0.30, syminfo.mintick * 10)
```

Le moteur d'exécution utilise une **valeur par défaut de 0,01** quand l'hôte
ne fournit pas le mintick. Sur EURUSD (mintick réel 0,00001), le décalage
sortait à `max(~0,0002 ; 0,1)` = **0,1** — 1000× trop grand. D'où les labels
à ±0,1/±0,2/±0,3 exactement (mesuré sur vos données : labels entre 0,847 et
1,452 pour des bougies entre 1,156 et 1,159).

### Le correctif
`deriveMintick()` (src/lib/pine-engine.ts) déduit le mintick **des bougies
elles-mêmes** : plus petit mouvement observé entre deux clôtures (les prix
bougent par ticks entiers), arrondi à la puissance de dix propre, avec
garde-fou anti-bruit et limite de cohérence (≤ 0,5 % du prix). Aucun appel
ne peut plus retomber sur la valeur 0,01 par défaut :

- EURUSD / GBPUSD (5 décimales) → 0,00001 ✓
- USDJPY (3 décimales) → 0,001 ✓
- XAUUSD (2 décimales) → 0,01 ✓
- changement d'actif → redéduction automatique à chaque exécution.

Résultat mesuré (dataset réel 2 242 bougies) : labels entre 1,1467 et 1,1548
pour des bougies entre 1,1415 et 1,1564 — **collés aux bougies**. Après
l'arrivée de nouvelles bougies (test live) : toujours collés.

## 2. Les scripts non-overlay ont leur propre panneau (comme TradingView)

Sur TradingView, `indicator(..., overlay=false)` (RSI, MACD, Stochastic…)
s'affiche dans un **panneau séparé sous le graphique**. Avant v1.8, le
moteur les rendait SUR le graphique des prix :

- les plots s'attachaient à une échelle indépendante dessinée par-dessus les
  bougies — jamais alignés, « l'indicateur ne colle jamais au graphique » ;
- pire : leurs hlines (RSI 30/70) étaient ajoutées à la SÉRIE PRINCIPALE —
  l'échelle de prix s'étirait de ~1,16 à 70 et tout le graphique explosait.

Le nouveau composant **PineSubPane** (src/components/trading/chart/pine-sub-pane.tsx)
donne à chaque script non-overlay son panneau synchronisé :

- plots (ligne/histogramme), plotcandle, plotshape (markers), hlines, fills
  entre plots, bandes bgcolor, drawings et cloches d'alerte — tout vit dans
  le panneau, dans l'espace de valeurs du script ;
- échelle de prix du panneau = valeurs du script uniquement (RSI 0-100) ;
- synchronisation temps réelle avec le graphique principal (échelle temporelle,
  crosshair, thème) via la même mécanique que les panneaux intégrés ;
- légende avec nom du script, valeurs, visibilité et suppression.

Tous les types de scripts sont maintenant couverts :

| Type de script | Rendu v1.8 |
|---|---|
| `overlay=true` + drawings (BOS/CHoCH, ZigZag, patterns) | sur le graphique, collé aux bougies |
| `overlay=true` + plots (EMA, Bandes) | sur le graphique, échelle des prix |
| `overlay=false` (RSI, MACD, oscillateurs) | panneau séparé synchronisé |
| `strategy()` | exécution + rapport PnL dans la console |
| Librairies communautaires (v1.7) | import ZIP multi-libs inchangé |

## 3. Les alertes de main.pine sont visibles

Le moteur collectait déjà les événements `alert()` / `alertcondition()`, mais
rien ne s'affichait. Maintenant :

- **cloches ambre** ancrées sur la bougie de chaque événement (comme les
  marqueurs d'alerte TradingView), avec le message pour les événements
  récents ;
- **toasts** pour chaque NOUVELLE alerte sur les dernières bougies (le
  premier passage sur l'historique reste silencieux, le replay est throttlé) ;
- journal des derniers événements dans la console de l'éditeur (inchangé).

Pour un script comme Main.pine dont les alertes sont pilotées par des inputs
(`BOS Up Alert`…), activez-les dans **Réglages** (icône ⚙ de l'éditeur) —
exactement comme sur TradingView où l'on crée l'alerte sur le script.

## 4. Correctif moteur : conditions flottantes (patch piner)

Le balayage de compatibilité a révélé un bug dans le moteur d'exécution
lui-même : `ta.valuewhen()`, `ta.barssince()` et `alertcondition()` testaient
leur condition avec la vérité JS (`if (cond)`) au lieu de la sémantique Pine
(`na` → false). Or les scripts theEccentricTrader (Double Top, Triple Bottom,
harmonics…) passent des PRIX de swing (float ou `na`) comme condition :

```pine
peak = ta.valuewhen(shPrice, shPrice, 0)   // shPrice = prix ou na
```

Résultat : la condition `na` comptait comme vraie → tous ces scripts
s'exécutaient « avec succès » mais produisaient ZÉRO dessin (patterns jamais
détectés, alertes jamais émises). Le correctif (patch-package,
`patches/@heyphat+piner+0.13.0.patch`, appliqué automatiquement au
`npm install` via postinstall) coerce la condition correctement —
**11 → 17 scripts compatibles sur 22**, dont pattern_2 qui produit maintenant
562 dessins + 65 alertes sur le dataset de référence.

### Balayage de compatibilité (22 scripts TradingView fournis)

| Script | Statut |
|---|---|
| Qasimodo (strategy), dynamic_liquidity, fractal_zigzag, impulse_target, markitick, pattern_1/2/4/5/7/8, price_action, retracements, rsi_custom (strategy), waves | ✓ 17/22 — exécutent, collés aux bougies |
| btc.pine | ✓ s'exécute — valeurs absurdes SUR EURUSD par design (script Bitcoin Almanac : calendrier tracé comme des prix) |
| hosada.pine | ✓ s'exécute — points A-E à régler dans Réglages (`input.price(100)` par défaut) |
| candles.pine, pattern_3, tendances.pine | librairies communautaires manquantes (piste d'import claire + suggestion de correspondance proche quand la même lib est enregistrée sous un autre auteur) |
| next_pivot.pine | script lui-même syntaxiquement invalide (édité à la main : `method float (int id)`) — échoue aussi sur TradingView |

## Tests (garanties de non-régression)

- `scripts/test-pine-alignment.ts` (**27 tests**) : deriveMintick par classe
  d'actif (FX/JPY/XAU), invariant d'alignement sur le dataset réel (labels
  collés ±tolérance ATR), absence des décalages ±0,1 du bug historique,
  alertes avec temps résolus, normalisation non-overlay (plots/hlines) ;
- E2E navigateur réel (**7 vérifications**) : échelle de prix saine avec un
  RSI chargé (ratio ~0,63 — plus d'étirement 30/70), drawings Main.pine
  collés, panneau Pine séparé présent, alertes collectées + cloches rendues
  (pixels ambre mesurés sur le canvas) ;
- vérification visuelle : labels BOS/CHoCH/CISD SUR les bougies, panneau RSI
  avec niveaux 30/70, cloches visibles, bougies occupant la hauteur du pane ;
- test live de dérive : après l'arrivée de nouvelles bougies, les drawings
  restent collés (glued=true) ;
- non-régression complète : pine-libraries (50), pine-engine-libs (21),
  martingale (12), stop/rejet par côté (17), log trades (21), onglets
  CALL/PUT (9), adaptateurs — tout passe ; `tsc` 0 erreur, `next build` OK.

## Lancer sur Termux

```bash
unzip pine_v6_engine_v1.8.zip
cd pine_v6_engine_v1.8
npm install --no-audit --no-fund   # le postinstall applique le patch piner
./start-dev.sh
```

> Le dossier `patches/` et le script `postinstall` (patch-package) font partie
> du projet : ne les supprimez pas, ils corrigent `ta.valuewhen` /
> `ta.barssince` / `alertcondition` dans le moteur piner 0.13.0.
EOF

# ── ZIP du pack d'exemple (prêt à importer pour tester) ───────────────────
(cd "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies" && zip -qr9 "$STAGE/EXEMPLE-Pack-Multi-Librairies.zip" .)
mv "$STAGE/EXEMPLE-Pack-Multi-Librairies.zip" "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies.zip"

# ── Création du zip ───────────────────────────────────────────────────────
rm -f "$OUT"
(cd "$STAGE" && zip -qr9 "$OUT" "$FOLDER")

# ── Vérification ──────────────────────────────────────────────────────────
echo "=== Archive créée : $OUT ==="
du -h "$OUT"
unzip -l "$OUT" | tail -1
echo "=== Fichiers clés présents ==="
unzip -l "$OUT" | grep -E 'pine-sub-pane|README-V1.8|EXEMPLE-Pack|wavescope_ict_v5|GUIDE-REGLAGES-V5|package-lock.json$|test-pine-alignment' | awk '{print $1, $4}'
echo "=== Marqueurs de fonctionnalités (vérification rapide) ==="
unzip -p "$OUT" "$FOLDER/src/lib/pine-engine.ts" | grep -c 'deriveMintick' | xargs echo "deriveMintick (>=3 attendu) :"
unzip -p "$OUT" "$FOLDER/src/lib/pine-engine.ts" | grep -c 'THE ALIGNMENT FIX' | xargs echo "fix mintick documenté (1 attendu) :"
unzip -p "$OUT" "$FOLDER/src/components/trading/chart/pine-sub-pane.tsx" | grep -c 'autoscaleInfoProvider' | xargs echo "ancre pane autoscale-exclue (1 attendu) :"
unzip -p "$OUT" "$FOLDER/src/components/trading/chart/chart-workspace.tsx" | grep -c 'pineSeparateScripts' | xargs echo "routage panes Pine (>=3 attendu) :"
unzip -p "$OUT" "$FOLDER/src/components/trading/chart/chart-workspace.tsx" | grep -c 'if (!script.result.overlay) continue' | xargs echo "garde non-overlay (2 attendus) :"
unzip -p "$OUT" "$FOLDER/src/components/trading/chart/pine-drawings-overlay.tsx" | grep -c 'drawBell' | xargs echo "cloches alertes (2 attendus) :"
unzip -p "$OUT" "$FOLDER/src/components/trading/chart/chart-workspace.tsx" | grep -c 'pineAlertSeenRef' | xargs echo "toasts alertes (>=2 attendus) :"
unzip -p "$OUT" "$FOLDER/src/components/trading/chart/pine-drawings-overlay.tsx" | grep -c '__pineChartDebug' | xargs echo "hook diagnostic e2e (2 attendus) :"
unzip -l "$OUT" | grep -c 'patches/@heyphat+piner' | xargs echo "patch piner inclus (1 attendu) :"
unzip -p "$OUT" "$FOLDER/package.json" | grep -c 'patch-package' | xargs echo "postinstall patch-package (2 attendus) :"
unzip -p "$OUT" "$FOLDER/src/lib/pine-engine.ts" | grep -c 'near-match' | xargs echo "suggestion correspondance proche (1 attendu) :"
unzip -t "$OUT" > /dev/null && echo "=== Intégrité zip OK ==="

# Nettoyage du staging
rm -rf "$STAGE"
