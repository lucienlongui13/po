#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v1.6.sh — Livraison v1.6 « Martingale corrigée + Trade History »
#   - FIX martingale (Signal Strategy + Strategy Tester) : la mise revient
#     TOUJOURS à la mise de base après un gain (le streak de pertes était
#     calculé sur les plus ANCIENS ordres au lieu des plus récents) ;
#     une perte réglée à la bougie N est prise en compte DÈS la mise suivante ;
#   - FIX Trade History : en replay, l'onglet affiche les trades SIMULÉS du
#     backtest (effacés par RESET TRADES) au lieu des deals réels du backend
#     qui ne s'effaçaient jamais ; bouton RESET (replay) / EFFACER (live).
# Sortie : /home/z/my-project/download/pine_v6_engine_v1.6.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v1.6"
FOLDER=pine_v6_engine_v1.6
OUT="$ROOT/download/pine_v6_engine_v1.6.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (mêmes exclusions que v1.0→v1.5) ─────────────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude 'upload/' \
  --exclude 'download/' \
  --exclude 'tool-results/' \
  --exclude '.stage-v1.1/' \
  --exclude '.stage-v1.2/' \
  --exclude '.stage-v1.3/' \
  --exclude '.stage-v1.4/' \
  --exclude '.stage-v1.5/' \
  --exclude '.stage-v1.6/' \
  --exclude 'skills/' \
  --exclude 'bun.lock' \
  --exclude '*.tmp' \
  --exclude 'bun-error.log' \
  --exclude '.env.local' \
  --exclude 'tsconfig.tsbuildinfo' \
  --exclude 'next-env.d.ts' \
  --exclude '*.log' \
  --exclude '.logs/' \
  --exclude 'v12_*.png' \
  --exclude 'scripts/*.png' \
  --exclude 'scripts/vlm_*.json' \
  --exclude 'scripts/search*.json' \
  "$ROOT/" "$STAGE/$FOLDER/"

# ── Script WaveScope v5 + guide inclus dans le zip ─────────────────────────
cp "$ROOT/download/wavescope_ict_v5.pine" "$STAGE/$FOLDER/wavescope_ict_v5.pine"
cp "$ROOT/download/GUIDE-REGLAGES-V5.md" "$STAGE/$FOLDER/GUIDE-REGLAGES-V5.md"

# ── README des correctifs v1.6 ────────────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.6-MARTINGALE-ET-TRADE-HISTORY.md" <<'EOF'
# Pine v6 Engine — v1.6 « Martingale corrigée + Trade History »

Deux correctifs demandés après la campagne de backtest.

## 1. Martingale : retour à la mise de base après un gain (CORRIGÉ)

**Symptôme** : en mode MARTINGALE (Signal Strategy → Réglages → stratégie de
mises), la mise ne revenait jamais à la mise de base après un gain — elle
restait doublée (voire ×4, ×8…), avec des mises « bizarres » (2 056 $,
2 300 $, 6 787 $…) plafonnées au solde, et une ruine prématurée du backtest.

**Cause** : le moteur de replay stocke les ordres **du plus récent (index 0)
au plus ancien** (`unshift`). Le calcul de la série de pertes parcourait le
tableau **depuis la fin** — c'est-à-dire en partant des plus ANCIENS trades.
La « série de pertes » était donc mesurée sur un lointain passé, figée, et
sans lien avec les résultats récents.

**Correctifs (src/components/trading/signal-strategy-panel.tsx)** :
1. `refreshLossStreak` parcourt maintenant le tableau **depuis l'index 0**
   (le plus récent) : la série compte les pertes réglées les plus récentes et
   **casse au premier gain/remboursement** ;
2. `placeOrderForEmission` rafraîchit la série **juste avant de calculer la
   mise** : le résultat d'un trade réglé à la bougie N est pris en compte
   **dès la mise suivante** (avant, il fallait attendre une bougie de plus).

**Comportement vérifié (replay 1000 bougies, X80, base 500 $, ×2)** :
- à chaque perte → la mise double : 500 → 1 000 → 2 000 → 4 000 → 8 000… ;
- **après un gain → la mise revient immédiatement à 500 $** (28/28 cas OK,
  0 exception ; avant le correctif : 13 mises > 500 $ après un gain sur le
  même scénario) ;
- après un remboursement (égalité de prix) → la série casse → mise de base ;
- la mise reste plafonnée au solde disponible (garde anti-ruine conservée).

## 2. Trade History : historique qui ne s'effaçait jamais (CORRIGÉ)

**Symptôme** : après « RESET TRADES » dans le Strategy Tester, l'historique
des trades ne s'effaçait jamais — « codé en dur ».

**Cause** : l'onglet **« Trade History »** (barre du bas, à côté de
« Strategy Tester ») affichait **les deals RÉELS de la session backend**
(socket Pocket Option) — même pendant un backtest. Ces deals n'ont aucun lien
avec les trades simulés du Strategy Tester : RESET TRADES ne pouvait pas les
effacer, et le backend les renvoie à chaque reconnexion.

**Correctifs** :
- **En replay**, l'onglet « Trade History » affiche maintenant les **trades
  SIMULÉS du backtest** (panneau « Simulated Trades · backtest », badge
  orange REPLAY, nom de l'actif rejoué, compteur « n/50 won »). **RESET
  TRADES les efface** en même temps que le tableau du Strategy Tester ;
- un bouton **RESET** est disponible directement dans l'onglet Trade History
  pendant le replay (même action que RESET TRADES : orders + equity + stats) ;
- **En live**, l'onglet affiche toujours les deals réels (« Recent Trades »),
  avec un bouton **EFFACER** pour vider l'affichage (les nouveaux deals
  réapparaîtront à leur survenue — le backend conserve sa session).

## Moteur (vérifié par tests)

- `scripts/test-martingale-streak.ts` (**12 tests**) : doublement à chaque
  perte (500→16 000), **retour à 500 après le gain**, remboursement = série
  cassée, reset → série 0, sémantique du tableau (index 0 = plus récent),
  comparaison avec l'ancien scan (divergent) ;
- `scripts/test-adapters.ts` mis à jour (section 7 : scan v1.6 depuis
  l'index 0, tableau récent→ancien) — toutes les suites passent ;
- Non-régression : `test-stopreject-sides.ts` (17) + `test-trade-logger.ts`
  (21) + `test-split-conditions.ts` (9) + `test-adapters.ts` ;
- E2E navigateur réel (po.sh + login + replay 1k + X80) :
  - martingale : invariants 100 % (après gain → 500 $, après perte → double,
    cohérence base×2^pertes PARFAITE sur 55 trades) ;
  - RESET TRADES : tableau Strategy Tester VIDÉ + Trade History VIDÉ +
    badge d'onglet disparu ; reprise → re-remplissage ; bouton RESET du
    Trade History = même reset ;
  - live : EFFACER vide l'affichage des deals réels ;
- `tsc` 0 erreur, `next build` production OK, vérification visuelle VLM OK.

## Lancer sur Termux

```bash
unzip pine_v6_engine_v1.6.zip
cd pine_v6_engine_v1.6
npm install --no-audit --no-fund
./start-dev.sh
```
EOF

# ── Création du zip ───────────────────────────────────────────────────────
rm -f "$OUT"
(cd "$STAGE" && zip -qr9 "$OUT" "$FOLDER")

# ── Vérification ──────────────────────────────────────────────────────────
echo "=== Archive créée : $OUT ==="
du -h "$OUT"
unzip -l "$OUT" | tail -1
echo "=== Fichiers clés présents ==="
unzip -l "$OUT" | grep -E 'wavescope_ict_v5|GUIDE-REGLAGES-V5|README-V1.6|signal-strategy-panel|trade-logger|trade-log/route|package-lock.json$' | awk '{print $1, $4}'
echo "=== Marqueurs de fonctionnalités (vérification rapide) ==="
unzip -p "$OUT" "$FOLDER/src/components/trading/signal-strategy-panel.tsx" | grep -c 'for (let i = 0; i < orders.length; i++)' | xargs echo "refreshLossStreak scan depuis index 0 (>=1 attendu) :" || true
unzip -p "$OUT" "$FOLDER/src/components/trading/signal-strategy-panel.tsx" | grep -c 'refreshLossStreak(replay.allOrders)' | xargs echo "refresh avant computeStake (1 attendu) :" || true
unzip -p "$OUT" "$FOLDER/src/components/trading/signal-strategy-panel.tsx" | grep -c 'for (let i = orders.length - 1; i >= 0; i--)' | xargs echo "ancien scan legacy (0 attendu) :" || true
unzip -p "$OUT" "$FOLDER/src/app/page.tsx" | grep -c 'simDeals' | xargs echo "simDeals (page.tsx, >=5 attendu) :" || true
unzip -p "$OUT" "$FOLDER/src/app/page.tsx" | grep -c 'handleResetTrades : po.clearClosedDeals' | xargs echo "onClear replay:reset / live:clear (1 attendu) :" || true
unzip -p "$OUT" "$FOLDER/src/components/trading/positions-panel.tsx" | grep -c 'Simulated Trades' | xargs echo "panneau Simulated Trades (>=1 attendu) :" || true
unzip -p "$OUT" "$FOLDER/src/components/trading/positions-panel.tsx" | grep -c 'EFFACER' | xargs echo "bouton EFFACER/RESET (>=2 attendu) :" || true
unzip -p "$OUT" "$FOLDER/src/hooks/use-pocket-option.ts" | grep -c 'clearClosedDeals' | xargs echo "clearClosedDeals (>=2 attendu) :" || true
unzip -t "$OUT" > /dev/null && echo "=== Intégrité zip OK ==="

# Nettoyage du staging
rm -rf "$STAGE"
