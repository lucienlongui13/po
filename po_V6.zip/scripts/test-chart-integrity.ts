/**
 * test-chart-integrity.ts — VALIDATION anti-contamination multi-actifs.
 *
 * Contexte (bug « graphiques endommagés ») : quand l'AI Coach ou l'auto-trade
 * Longui Lucien tournent, le graphique affichait des bougies ÉCLATÉES sur
 * plusieurs niveaux de prix (grappes isolées séparées de vides). Cause
 * racine : des bougies d'AUTRES actifs (XAUUSD ~4400, BTC ~64000, EURJPY
 * ~185…) entraient dans le dataset EURUSD ~1.16 via :
 *   1. l'auto-switch aléatoire post-trade (actifs mélangés dans le flux)
 *   2. le buffer de ticks jamais purgé au changement d'actif (ré-agrégation
 *      mélangée au prochain changement de timeframe)
 *   3. les caches 90 j contaminés (preuve : candle-cache/candles_EURGBP_otc_S30.json
 *      contient 5 niveaux de prix : 0.6-1.4 / ~19 / 67-308 / 354-565 / 4026-4519)
 *
 * Ce test valide les 4 lignes de défense v5.3 :
 *   A. sanitizeCandlesByPrice (backend)  — sur le cache EURGBP RÉELLEMENT contaminé
 *   B. purgePriceOutliers (CandleHistoryCache) — auto-guérison au chargement
 *   C. LiveEngine.resetHistory (frontend) — historique mixte nettoyé / rejeté
 *   D. LiveEngine.pushCandle (frontend)  — bougie étrangère rejetée du live
 *   E. resetTickBuffer — purge du buffer au changement d'actif (backend)
 */
import { readFileSync, mkdtempSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'

// ── import des modules testés (source de vérité = code de prod) ──
// tsx résout les imports relatifs depuis ce script.
import { sanitizeCandlesByPrice } from '../mini-services/iqoption-backend/candle-integrity'
import { CandleHistoryCache } from '../mini-services/iqoption-backend/candle-history-cache'
import { LiveEngine } from '../src/lib/live-engine'

// FIX (audit v6.5) — volume rendu requis : aligné sur CandleLike (indicators.ts).
// Tous les littéraux de ce test fournissent déjà volume: 60.
interface Candle { time: number; open: number; high: number; low: number; close: number; volume: number }

let passed = 0
let failed = 0
function check(name: string, cond: boolean, detail = ''): void {
  if (cond) { passed++; console.log(`  ✅ ${name}${detail ? ` — ${detail}` : ''}`) }
  else { failed++; console.error(`  ❌ ${name}${detail ? ` — ${detail}` : ''}`) }
}

console.log('\n══════════ A. sanitizeCandlesByPrice — cache EURGBP RÉELLEMENT contaminé ══════════')
{
  const cachePath = join(process.cwd(), 'mini-services/iqoption-backend/candle-cache/candles_EURGBP_otc_S30.json')
  let contaminated: Candle[] = []
  let contaminatedReal = false
  try {
    const raw = JSON.parse(readFileSync(cachePath, 'utf-8'))
    const loaded = (raw.candles ?? raw) as Candle[]
    // Le fichier n'est exploitable comme DONNÉE RÉELLE contaminée que s'il
    // contient effectivement plusieurs niveaux de prix (après auto-guérison
    // v5.3, le fichier sandbox est PROPRE — on reconstitue alors le profile
    // exact constaté avant la purge : 5445 bougies, 5 niveaux de prix).
    const levels = new Set(loaded.map((c) => Math.round(Math.log10(c.close))))
    if (loaded.length > 0 && levels.size >= 3) {
      contaminated = loaded
      contaminatedReal = true
    }
  } catch { /* cache absent (env de test propre) — on le reconstruit depuis les niveaux constatés */ }
  if (!contaminatedReal) {
    console.log('  (cache EURGBP non trouvé — reconstitution du profile de contamination observé)')
    // Reconstitution : 5445 bougies, 5 niveaux de prix constatés le 2026-08-29
    const t0 = 1780134180
    const levels = [0.86, 19.1, 160, 445, 4300]
    for (let i = 0; i < 500; i++) {
      const p = levels[i % levels.length] * (1 + (Math.random() - 0.5) * 0.02)
      contaminated.push({ time: t0 + i * 30, open: p, high: p * 1.001, low: p * 0.999, close: p, volume: 30 })
    }
    // La majorité = EURGBP (~0.86) pour matcher la structure réelle
    for (let i = 500; i < 1500; i++) {
      const p = 0.86 * (1 + (Math.random() - 0.5) * 0.01)
      contaminated.push({ time: t0 + i * 30, open: p, high: p * 1.001, low: p * 0.999, close: p, volume: 30 })
    }
    contaminated.sort((a, b) => a.time - b.time)
  }

  const before = new Set(contaminated.map((c) => Math.round(Math.log10(c.close))))
  check('cache de test multi-niveaux bien constitué', before.size >= 3, `${contaminated.length} bougies, ${before.size} niveaux de prix${contaminatedReal ? ' (DONNÉES RÉELLES contaminées)' : ' (reconstituées)'}`)

  const { clean, dropped } = sanitizeCandlesByPrice(contaminated)
  const after = new Set(clean.map((c) => Math.round(Math.log10(c.close))))
  check('bougies étrangères éliminées', dropped > 0, `${dropped}/${contaminated.length} rejetées`)
  check('série saine sur UN SEUL niveau de prix', after.size === 1, `niveaux restants: ${[...after].join(',')}`)
  const closes = clean.map((c) => c.close)
  const spread = Math.max(...closes) / Math.min(...closes)
  check('amplitude de prix plausible (≤ ×10)', spread <= 10, `amplitude ×${spread.toFixed(2)}`)

  // Série saine → rien n'est rejeté (aucun faux positif)
  const healthy: Candle[] = []
  for (let i = 0; i < 400; i++) {
    const p = 1.167 + Math.sin(i / 25) * 0.008
    healthy.push({ time: 1788000000 + i * 60, open: p, high: p + 0.0005, low: p - 0.0005, close: p + 0.0001, volume: 30 })
  }
  const h = sanitizeCandlesByPrice(healthy)
  check('saine EURUSD préservée à 100 %', h.dropped === 0 && h.clean.length === 400, `${h.dropped} rejetées`)

  // Série BTC saine (65940±3 %) → préservée elle aussi
  const btc: Candle[] = []
  for (let i = 0; i < 300; i++) {
    const p = 64000 + Math.sin(i / 30) * 1500
    btc.push({ time: 1788000000 + i * 60, open: p, high: p + 120, low: p - 120, close: p + 30, volume: 30 })
  }
  const b = sanitizeCandlesByPrice(btc)
  check('saine BTCUSD préservée à 100 % (×10 ne bloque pas les vrais instruments)', b.dropped === 0, `${b.dropped} rejetées`)

  // NaN / prix nuls rejetés
  const junk: Candle[] = [
    { time: 1, open: 1.16, high: 1.16, low: 1.16, close: 1.16, volume: 0 },
    { time: 2, open: NaN, high: 1.16, low: 1.16, close: 1.16, volume: 0 },
    { time: 3, open: 1.16, high: 1.16, low: 1.16, close: 0, volume: 0 },
    { time: 4, open: 1.16, high: 1.17, low: 1.15, close: 1.165, volume: 0 },
  ]
  const j = sanitizeCandlesByPrice(junk)
  check('NaN et prix ≤ 0 rejetés', j.clean.length === 2, `${j.dropped} rejetées`)
}

console.log('\n══════════ B. CandleHistoryCache.purgePriceOutliers — auto-guérison ══════════')
{
  const dir = mkdtempSync(join(tmpdir(), 'candle-cache-test-'))
  const cache = new CandleHistoryCache('EURUSD_otc', 60, dir, 100000)
  // Le cache est désormais strictement plafonné à 100 bougies.
  check('CandleHistoryCache : plafond dur = 100', cache.getSortedCandles().length === 0 && (cache as any).maxCandles === 100, 'maxCandles doit rester 100 même si 100000 est demandé')
  // Cache contaminé : 90 bougies EURUSD puis 10 bougies étrangères MÊLÉES à la
  // fin (le scénario reste suffisant pour tester la purge sans dépasser le cap)
  const t0 = 1788000000
  const bad: Array<{ time: number; open: number; high: number; low: number; close: number; volume: number }> = []
  for (let i = 0; i < 90; i++) {
    const p = 1.167 + Math.sin(i / 40) * 0.006
    bad.push({ time: t0 + i * 60, open: p, high: p + 0.0004, low: p - 0.0004, close: p, volume: 60 })
  }
  const tForeign = t0 + 90 * 60
  for (let i = 0; i < 10; i++) {
    const p = 4403 + Math.sin(i / 5) * 3
    bad.push({ time: tForeign + i * 120, open: p, high: p + 2, low: p - 2, close: p, volume: 60 })
  }
  bad.sort((a, b) => a.time - b.time)
  // Simulation d'un fichier écrit AVANT les garde-fous : premier batch sur
  // cache vide (référence inexistante → tout est accepté, comme historiquement)
  const res = cache.addHistoricalBatch(bad as any)
  check('contamination injectée (100 bougies max)', res.added === 100, `${res.added} bougies`)
  // → auto-guérison par purgePriceOutliers (comme au chargement du cache)
  const purged = cache.purgePriceOutliers()
  const sorted = cache.getSortedCandles()
  const closes = sorted.map((c) => c.close)
  const spread = Math.max(...closes) / Math.min(...closes)
  check('purge effective (10 bougies étrangères supprimées)', purged === 10, `${purged} purgées`)
  check('cache guéri : amplitude ≤ ×10', spread <= 10, `amplitude ×${spread.toFixed(3)}`)

  // addTick avec prix étranger → rejeté
  const before = cache.size()
  const rejectedTick = cache.addTick(t0 + 999999, 4403.5)
  check('tick XAUUSD (~4403) REJETÉ du cache EURUSD', rejectedTick === null && cache.size() === before)
  const okTick = cache.addTick(t0 + 999999, 1.16755)
  check('tick EURUSD (~1.167) ACCEPTÉ', okTick !== null && cache.size() === before + 1)

  // addHistoricalBatch avec batch étranger → rejeté
  const foreign = [{ time: t0 + 888888, open: 64000, high: 64100, low: 63900, close: 64050, volume: 100 }]
  const r2 = cache.addHistoricalBatch(foreign)
  check('batch BTCUSD REJETÉ du cache EURUSD', r2.rejected === 1 && r2.added === 0, `rejected=${r2.rejected}`)
}

console.log('\n══════════ C. LiveEngine.resetHistory — historique mixte ══════════')
{
  const engine = new LiveEngine()
  // 300 bougies EURUSD récentes (fin de série = référence) + 80 XAUUSD mêlées
  const t0 = 1788000000
  const mixed: Candle[] = []
  for (let i = 0; i < 300; i++) {
    const p = 1.167 + Math.sin(i / 30) * 0.005
    mixed.push({ time: t0 + i * 60, open: p, high: p + 0.0004, low: p - 0.0004, close: p, volume: 60 })
  }
  const tForeign = t0 + 300 * 60
  for (let i = 0; i < 80; i++) {
    const p = 4403 + Math.sin(i / 6) * 4
    mixed.push({ time: tForeign + i * 60, open: p, high: p + 3, low: p - 3, close: p, volume: 60 })
  }
  mixed.sort((a, b) => a.time - b.time)
  engine.resetHistory(mixed, '1:60')
  const candles = engine.getCandles()
  const closes = candles.map((c) => c.close)
  const spread = Math.max(...closes) / Math.min(...closes)
  check('historique mixte nettoyé (80 XAUUSD écartées)', candles.length === 300, `${candles.length} bougies conservées`)
  check('échelle de prix préservée (≤ ×10)', spread <= 10, `amplitude ×${spread.toFixed(2)}`)

  // Historique MAJORITAIREMENT corrompu → rejet total
  const engine2 = new LiveEngine()
  const mostlyBad: Candle[] = []
  for (let i = 0; i < 100; i++) {
    const p = 1.167 + Math.sin(i / 20) * 0.004
    mostlyBad.push({ time: t0 + i * 60, open: p, high: p + 0.0003, low: p - 0.0003, close: p, volume: 60 })
  }
  const tBad = t0 + 100 * 60
  for (let i = 0; i < 400; i++) {
    const p = 4403 + Math.sin(i / 10) * 5
    mostlyBad.push({ time: tBad + i * 60, open: p, high: p + 4, low: p - 4, close: p, volume: 60 })
  }
  mostlyBad.sort((a, b) => a.time - b.time)
  engine2.resetHistory(mostlyBad, '1:60')
  const keptBad = engine2.getCandles()
  const badCloses = keptBad.map((c) => c.close)
  const badSpread = Math.max(...badCloses) / Math.min(...badCloses)
  // Avec un dataset vide, la défense garde le CLUSTER MAJORITAIRE cohérent :
  // le graphique n'est jamais éclaté (l'auto-guérison du flux live corrige
  // ensuite le régime de prix si le stream insiste — test D2).
  check('historique majoritairement corrompu → dataset COHÉRENT (1 seul niveau de prix)', keptBad.length > 0 && badSpread <= 10, `${keptBad.length} bougies, amplitude ×${badSpread.toFixed(2)}`)

  // Historique sain inchangé
  const engine3 = new LiveEngine()
  const healthy: Candle[] = []
  for (let i = 0; i < 200; i++) {
    const p = 1.167 + Math.sin(i / 25) * 0.006
    healthy.push({ time: t0 + i * 60, open: p, high: p + 0.0005, low: p - 0.0005, close: p, volume: 60 })
  }
  engine3.resetHistory(healthy, '1:60')
  check('historique sain accepté tel quel', engine3.getCandles().length === 200)
}

console.log('\n══════════ D. LiveEngine.pushCandle — bougie étrangère du live ══════════')
{
  const engine = new LiveEngine()
  const t0 = 1788000000
  for (let i = 0; i < 50; i++) {
    const p = 1.167 + Math.sin(i / 10) * 0.004
    engine.pushCandle({ time: t0 + i * 60, open: p, high: p + 0.0004, low: p - 0.0004, close: p, volume: 60 })
  }
  const nBefore = engine.length
  // Bougie XAUUSD arrive dans le flux live (race backend) → REJET
  engine.pushCandle({ time: t0 + 50 * 60, open: 4403, high: 4405, low: 4401, close: 4404, volume: 60 })
  check('bougie XAUUSD REJETÉE du flux live EURUSD', engine.length === nBefore)
  // Bougie EURUSD légitime → ACCEPTÉE
  engine.pushCandle({ time: t0 + 50 * 60, open: 1.167, high: 1.1674, low: 1.1668, close: 1.1672, volume: 60 })
  check('bougie EURUSD légitime ACCEPTÉE', engine.length === nBefore + 1)
}

console.log('\n══════════ D2. LiveEngine — auto-guérison si le flux insiste sur un autre régime ══════════')
{
  // Dataset contaminé (400 XAUUSD — cf. test C « mostly bad ») + flux live
  // EURUSD persistant → après 10 rejets, le dataset adopte le régime du flux.
  const engine = new LiveEngine()
  const t0 = 1788000000
  const contaminated: Candle[] = []
  for (let i = 0; i < 400; i++) {
    const p = 4403 + Math.sin(i / 20) * 4
    contaminated.push({ time: t0 + i * 60, open: p, high: p + 3, low: p - 3, close: p, volume: 60 })
  }
  engine.resetHistory(contaminated, '21:60')
  check('dataset contaminé chargé (XAUUSD)', engine.getCandles().length === 400)
  // Le flux live EURUSD insiste
  let healed = false
  for (let i = 0; i < 15; i++) {
    const p = 1.167 + Math.sin(i / 5) * 0.003
    engine.pushCandle({ time: t0 + 400 * 60 + i * 60, open: p, high: p + 0.0004, low: p - 0.0004, close: p, volume: 60 })
    if (engine.getCandles()[0]?.close < 2) { healed = true; break }
  }
  const candles = engine.getCandles()
  const closes = candles.map((c) => c.close)
  const spread = Math.max(...closes) / Math.min(...closes)
  check('auto-guérison déclenchée (dataset réinitialisé sur le régime du flux live)', healed && spread <= 10, `${candles.length} bougies EURUSD, amplitude ×${spread.toFixed(2)}`)
  // Après guérison, le flux EURUSD continue normalement
  const nH = engine.length
  engine.pushCandle({ time: t0 + 500 * 60, open: 1.167, high: 1.1672, low: 1.1668, close: 1.1671, volume: 60 })
  check('flux EURUSD ACCEPTÉ après auto-guérison', engine.length === nH + 1)
}

console.log('\n══════════ E. Purge au changement d\u2019actif — synchroniseur v2 ══════════')
{
  // Vérification statique : le code source purge les séries du
  // synchroniseur sur les 3 chemins de changement de marché :
  //   - login           → clearAssetSelection() → candleSync.purgeAsset(asset)
  //   - select-market   → candleSync.switchAsset(m.name)
  //   - auto-switch     → candleSync.switchAsset(nextAsset)
  // FIX (audit v6.5) — l'ancienne heuristique ne comptait QUE switchAsset :
  // le chemin login est passé à purgeAsset (multi-assets, purge par actif,
  // strictement plus complète) → compte désormais les deux formes.
  // NB : ce test s'exécute depuis la RACINE du projet (cwd = répertoire du projet).
  const src = readFileSync(join(process.cwd(), 'mini-services/iqoption-backend/index.ts'), 'utf-8')
  const switchCalls = (src.match(/candleSync\.switchAsset\(/g) ?? []).length
  const purgeCalls = (src.match(/candleSync\.purgeAsset\(/g) ?? []).length
  const calls = switchCalls + purgeCalls
  check('purge du synchroniseur sur les 3 chemins de changement de marché (login+select+auto-switch)', calls >= 3 && purgeCalls >= 1, `${switchCalls} switchAsset + ${purgeCalls} purgeAsset`)
  const syncSrc = readFileSync(join(process.cwd(), 'mini-services/iqoption-backend/candle-sync-manager.ts'), 'utf-8')
  check('CandleSyncManager : purge du buffer de ticks par actif (switchAsset)', /switchAsset\(asset: string\): void[\s\S]*?st\.ticks = \[\]/.test(syncSrc))
  check('CandleSyncManager : buffer de ticks PAR ACTIF (jamais de mélange)', /interface AssetState[\s\S]*?ticks: Array/.test(syncSrc))
  check('autoSwitchAssets OFF par défaut', /autoSwitchAssets:\s*false/.test(src))
  const cacheSrc = readFileSync(join(process.cwd(), 'mini-services/iqoption-backend/candle-history-cache.ts'), 'utf-8')
  check('CandleHistoryCache : garde-fous prix actifs (addTick + addHistoricalBatch + purge)', /isPlausiblePrice/.test(cacheSrc) && /purgePriceOutliers/.test(cacheSrc))
  check('CandleHistoryCache : schéma v2 + validation de grille au chargement', /CACHE_SCHEMA_VERSION = 2/.test(cacheSrc) && /bucketStart/.test(cacheSrc) && /findGaps/.test(cacheSrc))
  const sdkSrc = readFileSync(join(process.cwd(), 'mini-services/iqoption-backend/pocket-option-sdk/src/api/market-data.ts'), 'utf-8')
  check('SDK : fallback anti cross-résolution (requête pendante unique)', /matches\.length === 1/.test(sdkSrc))
  const engineSrc = readFileSync(join(process.cwd(), 'src/lib/live-engine.ts'), 'utf-8')
  check('LiveEngine : sanitisation resetHistory + pushCandle', /isPlausibleCandle/.test(engineSrc) && engineSrc.includes('multi-actifs'))
}

console.log(`\n══════════════════════════════════════════════════`)
console.log(`  RÉSULTAT : ${passed} PASS / ${failed} FAIL`)
console.log(`══════════════════════════════════════════════════\n`)
process.exit(failed > 0 ? 1 : 0)
