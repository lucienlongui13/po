#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# E2E v1.6 — PARTIE 2 : vérification du RESET (flux corrigé)
#   RESET TRADES (onglet Strategy Tester) ET bouton RESET (onglet Trade
#   History) effacent l'historique simulé ; reprise → re-remplissage.
#   + mode live : bouton EFFACER sur les deals réels.
# ═══════════════════════════════════════════════════════════════════
cd /home/z/my-project
step() { echo ""; echo "════════ $1 ════════"; }
shot() { agent-browser screenshot "scripts/$1" >/dev/null 2>&1 && echo "📸 $1"; }

curl -s -m 3 -o /dev/null http://localhost:3000/ && echo "front OK" || { echo "✗ front mort"; exit 1; }
rm -f .logs/trade.jsonl

# ── 1. config + page propre (code v1.6 rechargé) ──
step "1. Config martingale + page propre"
node -e "
const fs = require('fs');
const src = fs.readFileSync('src/lib/signal-catalog.ts','utf8');
const ids = [...src.matchAll(/\{ id: '([A-Z0-9_]+)', family: '/g)].map(m => m[1]);
const seen = new Set(); const uniq = ids.filter(i => !seen.has(i) && seen.add(i));
const pick = uniq.filter(i => ['HH','LH','ENG_BULL','HAMMER','BULL_ENGULF','FVG_BULL','OB_BULL','TWEEZER_BOT'].includes(i));
const use = pick.length >= 4 ? pick : uniq.slice(0, 8);
const cfg = {
  enabled: true, callSignalIds: use, putSignalIds: [],
  stopCallSignalIds: [], stopPutSignalIds: [], rejectCallSignalIds: [], rejectPutSignalIds: [],
  callMode: 'ANY', putMode: 'ANY', windowBars: 3, expiryCandles: 1, cooldownCandles: 1,
  amount: 500, bettingStrategy: 'martingale', martingaleFactor: 2,
  autoTradeReplay: true, notifyLive: false
};
fs.writeFileSync('/tmp/cfg-mart.json', JSON.stringify(cfg));
console.log('config OK');
"
agent-browser open http://localhost:3000 >/dev/null 2>&1
sleep 12
B64=$(base64 -w0 /tmp/cfg-mart.json)
agent-browser eval "(() => {
  localStorage.clear();
  const cfg = JSON.parse(atob('$B64'));
  localStorage.setItem('signal-strategy-config-v1', JSON.stringify(cfg));
  localStorage.setItem('po-backtest-balance-v1', '10000');
  return 'injection OK';
})()" 2>&1 | tail -1
agent-browser reload >/dev/null 2>&1
sleep 12

# ── 2. login + replay ──
step "2. Login + Replay 1000 bougies"
agent-browser find role button click --name "Login with Pocket Option" >/dev/null 2>&1
for i in $(seq 1 12); do
  sleep 5
  if agent-browser snapshot -i -c 2>/dev/null | grep -q "PINE SCRIPT"; then break; fi
done
agent-browser snapshot -i -c 2>/dev/null | grep -q "PINE SCRIPT" && echo "✓ logué" || { echo "✗ login KO"; exit 1; }
sleep 8
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').trim() === 'Replay');
  if (b) { b.click(); return 'MENU REPLAY'; }
  return 'REPLAY INTROUVABLE';
})()" 2>&1 | tail -1
sleep 1
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').trim() === '1k');
  if (b) { b.click(); return '1K'; }
  return '1K INTROUVABLE';
})()" 2>&1 | tail -1
sleep 1
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').trim() === 'Start Replay');
  if (b) { b.click(); return 'REPLAY DEMARRE'; }
  return 'START INTROUVABLE';
})()" 2>&1 | tail -1
PANEL=""
for i in $(seq 1 22); do
  sleep 4
  PANEL=$(agent-browser eval "(() => document.body.textContent.includes('Start balance') ? 'PRET' : 'ATTENTE')()" 2>&1 | tail -1 | tr -d '"')
  [ "$PANEL" = "PRET" ] && break
done
[ "$PANEL" = "PRET" ] || { echo "✗ panneau backtest absent"; exit 1; }
agent-browser eval "
(() => {
  const s = [...document.querySelectorAll('select')].find(x => [...x.options].some(o => o.value === '12'));
  if (!s) return 'SELECT INTROUVABLE';
  const setter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, 'value').set;
  setter.call(s, '12');
  s.dispatchEvent(new Event('change', { bubbles: true }));
  return 'X80';
})()" 2>&1 | tail -1
sleep 1
agent-browser eval "
(() => {
  const b = document.querySelector('button[title=\"Play\"]');
  if (b) { b.click(); return 'PLAY'; }
  return 'PLAY INTROUVABLE';
})()" 2>&1 | tail -1
sleep 35
agent-browser eval "
(() => {
  const b = document.querySelector('button[title=\"Pause\"]');
  if (b) { b.click(); return 'PAUSE'; }
  return 'DEJA PAUSE';
})()" 2>&1 | tail -1
sleep 3

# ── 3. état avant reset ──
step "3. État avant reset"
agent-browser eval "
(() => {
  const rows = document.querySelectorAll('table tbody tr').length;
  const bars = (document.body.textContent.match(/(\d+\/\d+) bars/) || [])[1] || '?';
  const trades = (document.body.textContent.match(/Trades (\d+) \(/) || [])[1] || '?';
  return 'Strategy Tester → bars=' + bars + ' | lignes tableau=' + rows + ' | trades=' + trades;
})()" 2>&1 | tail -1

# ── 4. RESET TRADES depuis l'onglet Strategy Tester ──
step "4. RESET TRADES (onglet Strategy Tester)"
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('RESET TRADES'));
  if (!b) return 'RESET INTROUVABLE';
  b.click(); return 'RESET CLIQUÉ';
})()" 2>&1 | tail -1
sleep 4
agent-browser eval "
(() => {
  const rows = document.querySelectorAll('table tbody tr').length;
  const noTrades = document.body.textContent.includes('No simulated trades yet');
  const trades = (document.body.textContent.match(/Trades (\d+) \(/) || [])[1] || '?';
  return 'APRÈS reset → lignes=' + rows + ' | placeholder=' + (noTrades ? 'OUI' : 'NON') + ' | trades=' + trades;
})()" 2>&1 | tail -1
shot v16b_01_tester_apres_reset.png

# ── 5. Trade History après reset ──
step "5. Trade History après reset (doit être vide)"
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('Trade History'));
  if (b) { b.click(); return 'ONGLET OUVERT'; }
  return 'INTROUVABLE';
})()" 2>&1 | tail -1
sleep 2
agent-browser eval "
(() => {
  const rows = document.querySelectorAll('.grid-cols-5').length;
  const noSim = document.body.textContent.includes('No simulated trades yet');
  const tab = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('Trade History'));
  return 'Trade History → deals=' + rows + ' | message vide=' + (noSim ? 'OUI' : 'NON') + ' | badge onglet=' + ((tab.textContent.match(/\((\d+)\)/) || [])[0] || 'AUCUN');
})()" 2>&1 | tail -1
shot v16b_02_history_apres_reset.png

# ── 6. reprise → re-remplissage, puis RESET depuis Trade History ──
step "6. Reprise 20 s → nouveaux trades simulés"
agent-browser eval "
(() => {
  const b = document.querySelector('button[title=\"Play\"]');
  if (b) { b.click(); return 'PLAY'; }
  return 'PLAY INTROUVABLE';
})()" 2>&1 | tail -1
sleep 20
agent-browser eval "
(() => {
  const b = document.querySelector('button[title=\"Pause\"]');
  if (b) { b.click(); return 'PAUSE'; }
  return 'DEJA PAUSE';
})()" 2>&1 | tail -1
sleep 3
agent-browser eval "
(() => {
  const rows = document.querySelectorAll('.grid-cols-5').length;
  const tab = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('Trade History'));
  return 'Trade History → deals=' + rows + ' | badge onglet=' + ((tab.textContent.match(/\((\d+)\)/) || [])[0] || 'AUCUN');
})()" 2>&1 | tail -1
shot v16b_03_history_re_rempli.png

step "7. Bouton RESET dans l'onglet Trade History (nouveau)"
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('RESET') && !(x.textContent || '').includes('RESET TRADES') && !(x.textContent || '').includes('AI COACH'));
  if (!b) return 'BOUTON RESET (history) INTROUVABLE';
  b.click(); return 'RESET (history) CLIQUÉ';
})()" 2>&1 | tail -1
sleep 4
agent-browser eval "
(() => {
  const rows = document.querySelectorAll('.grid-cols-5').length;
  const noSim = document.body.textContent.includes('No simulated trades yet');
  const tab = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('Trade History'));
  return 'APRÈS RESET (history) → deals=' + rows + ' | message vide=' + (noSim ? 'OUI' : 'NON') + ' | badge onglet=' + ((tab.textContent.match(/\((\d+)\)/) || [])[0] || 'AUCUN');
})()" 2>&1 | tail -1
shot v16b_04_history_reset_local.png
# le tableau du Strategy Tester doit aussi être vide (même reset)
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').trim() === 'Strategy Tester');
  if (b) b.click();
  return 'ONGLET TESTER';
})()" 2>&1 | tail -1
sleep 3
agent-browser eval "
(() => {
  const rows = document.querySelectorAll('table tbody tr').length;
  const trades = (document.body.textContent.match(/Trades (\d+) \(/) || [])[1] || '?';
  return 'Strategy Tester → lignes=' + rows + ' | trades=' + trades;
})()" 2>&1 | tail -1

# ── 8. mode LIVE : bouton EFFACER sur les deals réels ──
step "8. Mode live — bouton EFFACER (deals réels)"
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('Exit replay'));
  if (b) { b.click(); return 'REPLAY QUITTÉ'; }
  return 'EXIT INTROUVABLE';
})()" 2>&1 | tail -1
sleep 4
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('Trade History'));
  if (b) { b.click(); return 'ONGLET HISTORY'; }
  return 'INTROUVABLE';
})()" 2>&1 | tail -1
sleep 2
agent-browser eval "
(() => {
  const header = [...document.querySelectorAll('span')].find(s => (s.textContent || '').trim() === 'Recent Trades');
  const rows = document.querySelectorAll('.grid-cols-5').length;
  return 'LIVE → panneau Recent Trades=' + (!!header) + ' | deals réels=' + rows;
})()" 2>&1 | tail -1
shot v16b_05_live_history.png
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('EFFACER'));
  if (!b) return 'BOUTON EFFACER INTROUVABLE';
  b.click(); return 'EFFACER CLIQUÉ';
})()" 2>&1 | tail -1
sleep 3
agent-browser eval "
(() => {
  const rows = document.querySelectorAll('.grid-cols-5').length;
  const noDeals = document.body.textContent.includes('No closed trades yet');
  return 'APRÈS EFFACER → deals=' + rows + ' | message vide=' + (noDeals ? 'OUI' : 'NON');
})()" 2>&1 | tail -1
shot v16b_06_live_apres_effacer.png

echo ""
echo "══ PARTIE 2 TERMINÉE ══"
