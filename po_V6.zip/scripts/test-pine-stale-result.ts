/**
 * test-pine-stale-result.ts — v1.9 suite (spec §4, §12, §20).
 *
 * Latest-result-wins. A stale async execution must NEVER be able to rewrite
 * a newer state:
 *   1. single-flight + trailing: while a SLOW batch N executes, a new-bar
 *      snapshot N+1 arrives → N+1 runs after N → the store's final state is
 *      N+1's (and never regresses).
 *   2. direct store attack: commitExecution with an OLD revision is refused.
 *   3. random-order legacy completions (N..N+3 resolving in any order):
 *      only the newest revision survives.
 *   4. asset/timeframe switch: results from the previous context are wiped
 *      and foreign-context commits are refused.
 */
import { usePineStore, type CommitEntry } from '../src/lib/pine-store'
import { pineCoordinator } from '../src/lib/pine-executor'
import { runPineScript } from '../src/lib/pine-engine'
import { toPineTime } from '../src/lib/pine-time-axis'
import {
  ALIGNMENT_PROBE_SRC, makeCandles, makeChecker, resetPineState,
  sleep, waitForIdle, waitForStore, allScriptsAtRevision, storeScript,
} from './pine-live-test-utils'

const { ok, finish } = makeChecker()
const TF_SEC = 60

function envelopeFor(revision: number, lastBarTime: number, barCount: number, asset = 'EURUSD_otc', timeframe = TF_SEC) {
  return { revision, asset, timeframe, firstBarTime: 0, lastBarTime, barCount }
}

async function main() {
  // ── 1. single-flight + trailing under a SLOW batch ───────────────────
  console.log('── 1. slow batch N + fast N+1 (spec §20) ──')
  resetPineState()
  const candles = makeCandles(100, { tfSec: TF_SEC })
  const id = usePineStore.getState().addScript(ALIGNMENT_PROBE_SRC, 'Probe')
  let delayMs = 0
  pineCoordinator.setRunnerForTests(async (source, cs, runtime) => {
    if (delayMs > 0) await sleep(delayMs)
    return runPineScript(source, cs as any, runtime)
  })
  pineCoordinator.setContext({ asset: 'EURUSD_otc', timeframe: TF_SEC })

  // Batch N — SLOW (the execution for dataset N resolves late).
  delayMs = 350
  pineCoordinator.notifyDataset(candles, 'init')
  await sleep(80) // batch N is in flight

  // Dataset N+1 — a NEW BAR arrives while N still executes.
  candles.push({
    time: candles[candles.length - 1].time + TF_SEC,
    open: 1.16, high: 1.161, low: 1.159, close: 1.1605, volume: 1,
  })
  delayMs = 0 // batch N+1 is fast
  pineCoordinator.notifyDataset(candles, 'new-bar')

  await waitForIdle(15000)
  const script = storeScript(id)!
  const stats = pineCoordinator.stats()
  ok('both batches ran (single-flight, no parallel execution)', stats.batchesCommitted === 2)
  ok('store holds the NEWEST dataset (101 bars, new last bar)',
    script.envelope?.barCount === 101
    && script.envelope?.lastBarTime === candles[candles.length - 1].time)
  ok('store never shows the stale 100-bar state after N+1 committed',
    script.result?._times?.length === 101)

  // ── 2. direct store attack: stale commit refused ─────────────────────
  console.log('── 2. stale commitExecution refused ──')
  const curRev = usePineStore.getState().dataset.revision
  const r1 = await runPineScript(ALIGNMENT_PROBE_SRC, candles.slice(0, 90) as any, { symbol: 'EURUSD_otc', timeframe: '1' })
  ok('stale payload executed for the attack', r1.ok)
  const staleEntry: CommitEntry = {
    id,
    result: r1.ok ? r1.result : null,
    error: null,
    envelope: envelopeFor(curRev - 1, candles[89].time, 90),
  }
  usePineStore.getState().commitExecution([staleEntry])
  const after = storeScript(id)!
  ok('stale commit REFUSED — store still at the newer revision',
    after.envelope?.revision === curRev && after.result?._times?.length === 101)

  // ── 3. random-order legacy completions ───────────────────────────────
  console.log('── 3. N..N+3 resolving in random order ──')
  {
    // Simulate four async executions completing out of order. The dataset
    // has advanced to N+3 by the time they all land.
    const revs = [curRev + 1, curRev + 2, curRev + 3, curRev + 4] // data at N+1..N+4
    const orders: number[][] = [
      [3, 1, 2, 0], // N+4 lands FIRST, then the older ones
      [0, 1, 2, 3], // ascending (normal)
      [2, 3, 0, 1], // mixed
      [1, 3, 0, 2],
    ]
    let allGood = true
    for (const order of orders) {
      // publish the CURRENT dataset (N+4) — the coordinator already moved on
      usePineStore.getState().publishDataset({
        revision: revs[3], asset: 'EURUSD_otc', timeframe: TF_SEC,
        lastBarTime: candles[candles.length - 1].time + 3 * TF_SEC, barCount: 104,
      })
      const last = candles[candles.length - 1]
      const entries: CommitEntry[] = order.map((idx) => ({
        id,
        result: {
          ...(usePineStore.getState().scripts.find((s) => s.id === id)!.result!),
          _times: [toPineTime(last.time - 5 * TF_SEC)],
        } as any,
        error: null,
        envelope: envelopeFor(revs[idx], last.time - (3 - idx) * TF_SEC, 101 + idx),
      }))
      for (const e of entries) usePineStore.getState().commitExecution([e])
      const st = storeScript(id)!
      // Whatever the order, the store must hold the dataset published as
      // current (N+4) — or the LAST accepted one — but NEVER a lower revision.
      if ((st.envelope?.revision ?? 0) < usePineStore.getState().dataset.revision - 0) {
        // accepted revisions can be < dataset.revision ONLY if none matched;
        // after the first order the store is already at N+4 → stays ≥ N+4.
      }
      if ((st.envelope?.revision ?? 0) < revs[3]) allGood = false
    }
    ok('random completion order → store NEVER regresses below the newest accepted revision',
      allGood)
    ok('store ends at the newest revision of the last order',
      storeScript(id)!.envelope?.revision === revs[3])
  }

  // ── 4. asset switch wipes old results (isolated scenario) ────────────
  console.log('── 4. asset/timeframe switch (spec §23) ──')
  resetPineState()
  const idB = usePineStore.getState().addScript(ALIGNMENT_PROBE_SRC, 'Probe B')
  const eurusd = makeCandles(90, { tfSec: TF_SEC })
  pineCoordinator.setContext({ asset: 'EURUSD_otc', timeframe: TF_SEC })
  pineCoordinator.notifyDataset(eurusd, 'init')
  const revE = pineCoordinator.stats().revision
  await waitForStore(() => allScriptsAtRevision(revE), 15000, 'eurusd commit')
  await waitForIdle()
  ok('EURUSD result committed', storeScript(idB)!.result != null)

  pineCoordinator.setRunnerForTests(null)
  pineCoordinator.setContext({ asset: 'BTCUSD_otc', timeframe: TF_SEC })
  ok('context switch wipes every stored result',
    usePineStore.getState().scripts.every((s) => s.result == null && s.envelope == null))
  ok('context barrier published (new asset, bumped revision)',
    usePineStore.getState().dataset.asset === 'BTCUSD_otc'
    && usePineStore.getState().dataset.revision === revE + 1)
  // A late commit for the OLD asset is refused even with a FUTURE revision.
  const rOld = await runPineScript(ALIGNMENT_PROBE_SRC, eurusd as any, { symbol: 'EURUSD_otc', timeframe: '1' })
  const lateForOldAsset: CommitEntry = {
    id: idB,
    result: rOld.ok ? rOld.result : null,
    error: null,
    envelope: envelopeFor(usePineStore.getState().dataset.revision + 5, eurusd[89].time, 90, 'EURUSD_otc'),
  }
  usePineStore.getState().commitExecution([lateForOldAsset])
  ok('foreign-context commit refused even with a FUTURE revision',
    storeScript(idB)!.result == null)

  // New asset's first snapshot repopulates.
  const btc = makeCandles(80, { tfSec: TF_SEC, base: 65000, tick: 0.5 })
  pineCoordinator.notifyDataset(btc, 'init')
  const revBtc = pineCoordinator.stats().revision
  await waitForStore(() => allScriptsAtRevision(revBtc), 15000, 'btc commit')
  await waitForIdle()
  ok('new asset result committed', storeScript(idB)!.envelope?.asset === 'BTCUSD_otc')
  ok('new asset result timeline = BTC dataset',
    storeScript(idB)!.result?._times?.[storeScript(idB)!.result!._times!.length - 1] === toPineTime(btc[79].time))

  resetPineState()
  console.log()
  finish('test-pine-stale-result')
}

main().catch((err) => {
  console.error('FATAL:', err)
  process.exit(1)
})
