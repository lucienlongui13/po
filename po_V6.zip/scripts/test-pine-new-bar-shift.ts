/**
 * test-pine-new-bar-shift.ts — v1.9 regression suite (RC1 — THE bug).
 *
 * Root cause being guarded: the v1.8 pipeline re-executed Pine through a
 * 350 ms setTimeout whose cleanup ran on EVERY new candles-array reference.
 * Live ticks produce one reference per rAF flush (≤ 16 ms apart) — the timer
 * was perpetually cancelled and NEVER fired. Pine results froze on the
 * initial history while each new candle advanced the chart → cumulative
 * left-drift of the whole Pine layer.
 *
 * This test:
 *   A) reproduces the OLD debounce pattern under a continuous stream and
 *      PROVES it never fires (negative control = root-cause evidence);
 *   B) drives the NEW coordinator under the same stream and proves batches
 *      commit for every new bar and the final result reaches the last bar.
 */
import { usePineStore } from '../src/lib/pine-store'
import { pineCoordinator } from '../src/lib/pine-executor'
import { toPineTime } from '../src/lib/pine-time-axis'
import {
  ALIGNMENT_PROBE_SRC, makeCandles, makeChecker, resetPineState,
  sleep, waitForIdle, waitForStore, allScriptsAtRevision, storeScript,
} from './pine-live-test-utils'

const { ok, finish } = makeChecker()
const TF_SEC = 60

async function main() {
  // ── A. negative control: the v1.8 debounce pattern ──────────────────
  console.log('── A. v1.8 pattern reproduction (negative control) ──')
  {
    let fired = 0
    let timer: ReturnType<typeof setTimeout> | null = null
    const oldDebouncedExecute = () => {
      // EXACTLY the v1.8 code: every new candles reference cancels the
      // pending timer and schedules a fresh 350 ms one.
      if (timer) clearTimeout(timer)
      timer = setTimeout(() => { fired++ }, 350)
    }
    const t0 = Date.now()
    while (Date.now() - t0 < 1400) {
      // a fresh reference every ~40 ms — mirrors one setLiveCandles call
      // per rAF flush carrying ticks
      oldDebouncedExecute()
      await sleep(40)
    }
    if (timer) clearTimeout(timer)
    ok(`v1.8 pattern: 350 ms debounce NEVER fires under a 40 ms tick stream (fired=${fired})`,
      fired === 0)
  }

  // Control sanity: the same pattern fires exactly once when the stream
  // pauses ≥ 350 ms (proving the mechanism, not the stream, is the cause).
  {
    let fired = 0
    let timer: ReturnType<typeof setTimeout> | null = null
    const run = () => { if (timer) clearTimeout(timer); timer = setTimeout(() => { fired++ }, 350) }
    run(); run(); run()
    await sleep(500)
    ok('v1.8 pattern: fires exactly once when the stream pauses ≥ 350 ms', fired === 1)
  }

  // ── B. the v1.9 coordinator under the same continuous stream ────────
  console.log('── B. v1.9 coordinator: continuous tick stream + new bars ──')
  resetPineState()
  const candles = makeCandles(120, { tfSec: TF_SEC })
  const scriptId = usePineStore.getState().addScript(ALIGNMENT_PROBE_SRC, 'Alignment Probe')
  pineCoordinator.setContext({ asset: 'EURUSD_otc', timeframe: TF_SEC })
  pineCoordinator.notifyDataset(candles, 'init')
  const rev0 = pineCoordinator.stats().revision
  await waitForStore(() => allScriptsAtRevision(rev0), 15000, 'initial commit')
  await waitForIdle()

  const NEW_BARS = 6
  const TICK_MS = 40          // ticks every 40 ms — far below any debounce
  const BAR_EVERY_TICKS = 10  // a new bar every ~400 ms
  const t0 = Date.now()
  let tick = 0
  let lastCommittedBars = 120
  const commitLog: number[] = []
  while (Date.now() - t0 < 2600) {
    await sleep(TICK_MS)
    tick++
    if (tick % BAR_EVERY_TICKS === 0) {
      // NEW CANDLE: max priority — must execute no matter how dense the
      // forming-tick stream around it is.
      const prev = candles[candles.length - 1]
      const c = prev.close + Math.sin(tick) * 3e-5
      candles.push({
        time: prev.time + TF_SEC,
        open: prev.close, high: Math.max(prev.close, c) + 9e-5, low: Math.min(prev.close, c) - 7e-5,
        close: c, volume: 100 + candles.length,
      })
      pineCoordinator.notifyDataset(candles, 'new-bar')
    } else {
      // FORMING TICK: in-place revision of the last candle, same barTime.
      const last = candles[candles.length - 1]
      const c = last.close + Math.cos(tick) * 2e-5
      candles[candles.length - 1] = { ...last, close: c, high: Math.max(last.high, c) }
      pineCoordinator.notifyDataset(candles, 'forming')
    }
    const s = pineCoordinator.stats()
    if (s.lastCommitAt > 0) {
      const script = storeScript(scriptId)!
      const bars = script.envelope?.barCount ?? 0
      if (bars !== lastCommittedBars) {
        commitLog.push(bars)
        lastCommittedBars = bars
      }
    }
  }
  await waitForIdle()
  // forming throttle trailing flush
  await sleep(1100)
  await waitForIdle()

  const stats = pineCoordinator.stats()
  ok(`new bars ALL executed: batches committed (${stats.batchesCommitted}) ≥ new bars (${NEW_BARS})`,
    stats.batchesCommitted >= NEW_BARS)
  ok('bar-count commit log is strictly non-decreasing (no regression ever)',
    commitLog.every((b, i) => i === 0 || b >= commitLog[i - 1]))

  const script = storeScript(scriptId)!
  ok('final envelope reaches the LAST candle of the stream (no cumulative drift)',
    script.envelope?.barCount === candles.length
    && script.envelope?.lastBarTime === candles[candles.length - 1].time)
  ok('final result timeline ends on the last candle (ms)',
    script.result?._times?.[script.result._times.length - 1] === toPineTime(candles[candles.length - 1].time))
  ok('no stale error', script.error == null)

  // The marker of the FIRST signal bar (index 0) is still at its timestamp.
  const T0ms = toPineTime(candles[0].time)
  const idx = script.result!._times!.indexOf(T0ms)
  ok('original signal at bar 0 STILL at barTime(0) after the whole stream',
    idx === 0 && script.result!.markers[0].data[0] != null)

  resetPineState()
  console.log()
  finish('test-pine-new-bar-shift')
}

main().catch((err) => {
  console.error('FATAL:', err)
  process.exit(1)
})
