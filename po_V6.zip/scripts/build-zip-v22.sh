#!/bin/bash
# ════════════════════════════════════════════════════════════════════════
# build-zip-v22.sh — Livraison v22 « Candles Validation + Ninja ProTrader »
# ════════════════════════════════════════════════════════════════════════
#
# 1. CANDLES VALIDATION (règle par combinaison — L_Lucien ProTrader) :
#      • chaque combinaison CALL ▲ / PUT ▼ du panneau Auto Trade porte un
#        champ « Candles Validation » (ex. RGRR ; R = Rouge, G = Vert,
#        max 5 caractères) ;
#      • à l'instant où la combinaison est émise, le programme vérifie en
#        temps réel les N dernières bougies CLÔTURÉES, lues DE LA PLUS
#        RÉCENTE À LA PLUS ANCIENNE — la bougie EN FORMATION n'est JAMAIS
#        validée (la validation commence à la bougie clôturée qui la
#        précède) ;
#      • L_Lucien ProTrader (signal à la clôture) : règle[0] = bougie
#        signalée (la dernière clôturée) ;
#      • règle vide = aucune validation ; refus → HOLD avec reason
#        explicite (attendu vs bougies réelles) ;
#      • doji (close === open) = VERTE (gc = close >= open, même rendu
#        que lightweight-charts).
#
# 2. STRATÉGIE « NINJA PROTRADER » (copie conforme de L_Lucien ProTrader) :
#      • ajoutée au dropdown Auto Trade à côté de L_Lucien ProTrader ;
#      • différence fondamentale : les signaux BOS Down, BOS Up, CHoCH Up,
#        CHoCH Down, CISD Up et CISD Down sont détectés AVANT LA CLÔTURE
#        des bougies — évaluation de la bougie EN FORMATION (prix temps
#        réel, polling 500 ms) → l'ordre part immédiatement dès le
#        franchissement du niveau de swing ;
#      • mêmes combinaisons, mêmes expirations par règle, même Candles
#        Validation (ancre = dernière bougie CLÔTURÉE, la bougie en
#        formation n'est jamais validée), même confirmation v19 ;
#      • garde anti re-trade : UN ordre par bougie en formation.
#
# 3. LIBELLÉS D'ORDRE : CHAQUE ordre placé porte son libellé —
#    « stratégie · CALL ▲/PUT ▼ · combinaison [alertes] · validation Règle »
#    (ou « sans validation ») — visible sur la CARTE de l'ordre dans le
#    graphique (triangle + carte trade) et dans le Strategy Tester
#    (colonne Label). Ordres manuels : « Manuel · Order panel ».
#
# 4. STRATEGY TESTER — L_Lucien ProTrader en BACKTESTING AUTOMATIQUE :
#      • nouvelle section « L_Lucien ProTrader · stratégie auto » dans le
#        panneau Strategy Tester (Bar Replay) : switch ON/OFF + mise ($)
#        + payout (%) ;
#      • chaque bougie clôturée du replay est évaluée avec TOUTES les
#        combinaisons et règles de validation du panneau Auto Trade
#        (partage temps réel : toute modification s'applique aussitôt) ;
#      • EXPIRATION EN NOMBRE DE BOUGIES : l'expiration (secondes) de
#        chaque règle est convertie selon le TF courant (ex. 60 s sur
#        S30 → 2 bougies ; plancher 1 bougie) — l'ordre simulé se règle
#        après N bougies ;
#      • garde une-mise-par-bougie (sémantique backend) ; RESET TRADES
#        ré-arme la garde pour rejouer l'historique.
#
# Validation : tsc root 0 · tsc backend 0 · tsc SDK 0 · next build PASS
# (6/6) · test-v22-candles-validation (NOUVEAU) 68 ✓ · test-v22-ninja-e2e
# (NOUVEAU, vrai backend + faux broker S5/RGG/mèches) 20/20 ✓ ·
# bos-martingale-e2e 17/17 ✓ · confirm-candle-cap-e2e 24/24 ✓ ·
# auto-switch-rule-e2e 20/20 ✓ · v21-rules-e2e 28/28 ✓ · v21-rules 61 ✓ ·
# multi-assets ✓ · v63-features ✓ · v63-integration ✓ · bos-strategy 22 ✓ ·
# martingale-streak 12 ✓ · bos-expiry-martingale 39 ✓ ·
# confirm-candle-cap 59 ✓ · smart-stream-hardening PASS.
#
# Sortie : /home/z/my-project/download/pine_v6_engine_v22_ninja_candles_validation.zip
# ════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v22"
FOLDER=pine_v6_engine
OUT="$ROOT/download/pine_v6_engine_v22_ninja_candles_validation.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (structure identique aux zips v15-v21) ───────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude '.logs/' \
  --exclude '*.log' \
  --exclude 'winwinlogs.jsonl' \
  --exclude 'tsconfig.tsbuildinfo' \
  --exclude 'mini-services/iqoption-backend/data/backend-session.json' \
  --exclude 'mini-services/iqoption-backend/data/candle-cache/' \
  --exclude 'mini-services/iqoption-backend/e2e-*.log' \
  --exclude 'db/' \
  "$ROOT/pine_v6_engine/" "$STAGE/$FOLDER/"

# ── READMEs des versions précédentes (chaîne documentaire conservée) ────
unzip -q -o "$ROOT/download/pine_v6_engine_v21_final_rules.zip" \
  "pine_v6_engine/README-V1.6-V21-FINAL-RULES.md" \
  "pine_v6_engine/README-V1.6-V20-FINAL-FIXES.md" -d "$STAGE/"

# ── README de la version v22 ─────────────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.6-V22-NINJA-CANDLES-VALIDATION.md" <<'EOF'
# Pine v6 Engine — v22 « Ninja ProTrader + Candles Validation »

## 1. Candles Validation — règle de validation par combinaison

Chaque **combinaison** CALL ▲ / PUT ▼ du panneau Auto Trade (L_Lucien
ProTrader comme Ninja ProTrader) porte un nouveau champ **« Candles
Validation »**.

**Syntaxe** : une suite de `R` (Rouge) et `G` (Vert), **1 à 5
caractères**, ex. `RGRR`. La saisie est sanitizée (majuscules, seuls
R/G conservés, tronquée à 5).

**Sémantique** : à l'instant où la combinaison est émise, le programme
vérifie les N dernières **bougies CLÔTURÉES**, lues **de la plus
récente à la plus ancienne** :

```
règle  R  G  R  R
       ↓  ↓  ↓  ↓
bougie [clôturée la + récente] [précédente] [avant] [avant]
```

- `RGRR` = la bougie clôturée la plus récente est **R**ouge, la
  précédente **V**erte (`G`), puis Rouge, Rouge ;
- **la bougie EN FORMATION n'est jamais validée** : la validation
  commence à la bougie clôturée qui précède la bougie en cours de
  formation ;
- **L_Lucien ProTrader** (signal à la clôture) : la bougie signalée
  EST la dernière clôturée → `règle[0]` = bougie signalée ;
- **Ninja ProTrader** (signal avant clôture) : `règle[0]` = dernière
  bougie **clôturée** (la bougie en formation porte le signal mais
  n'est pas validée) ;
- doji (close === open) = **VERTE** (`gc = close >= open`, même rendu
  que lightweight-charts) ;
- règle **vide** = aucune validation : l'ordre suit la combinaison
  seule ;
- refus → **HOLD** (aucun ordre), reason explicite
  (« Candles Validation RGRR ✗ — bougies réelles GGRG »).

## 2. Ninja ProTrader — détection AVANT la clôture

Nouvelle stratégie dans le dropdown Auto Trade, **copie conforme de
L_Lucien ProTrader** :

| | L_Lucien ProTrader | Ninja ProTrader |
|---|---|---|
| Détection BOS/CHoCH/CISD | à la **clôture** des bougies | **AVANT la clôture** (bougie en formation, prix temps réel, polling 500 ms) |
| Ordre | à la clôture confirmée | **immédiat** dès le franchissement du niveau de swing |
| Combinaisons CALL/PUT | identiques (partagées) | identiques (partagées) |
| Expiration par règle | identique | identique |
| Candles Validation | ancre = bougie signalée | ancre = dernière **clôturée** |
| Confirmation bougie précédente (v19) | ✓ | ✓ |
| Martingale / Fibonacci / stats | ✓ | ✓ |

Même moteur (shared/bos-choch-cisd.ts, validé contre le pack Pine),
mêmes réglages — la détection est simplement déplacée **avant la
clôture** : l'ordre part dès que le prix courant franchit le niveau de
swing, sans attendre la confirmation de la bougie. Garde anti re-trade :
**un ordre par bougie en formation**.

## 3. Libellés d'ordre — chaque ordre est étiqueté

**TOUT ordre placé** porte désormais son libellé complet :

```
Ninja ProTrader · CALL ▲ · call-ninja [BOS Up] · validation GRG
L_Lucien ProTrader · CALL ▲ · call-1 [BOS Up + CISD Up] · sans validation
```

- visible sur la **carte de l'ordre dans le graphique** (triangle +
  carte — texte complet au survol) ;
- visible dans le **Strategy Tester** (colonne « Label » de la table
  des trades + puces des trades ouverts) ;
- émis dans l'événement `trade-opened` (`label`) ;
- ordres manuels : `Manuel · Order panel`.

## 4. Strategy Tester — L_Lucien ProTrader en backtesting

La stratégie **L_Lucien ProTrader rejoint le Strategy Tester** :

1. lancer un **Bar Replay** (bouton Replay de la barre du haut) ;
2. dans l'onglet **Strategy Tester**, activer le switch
   **« L_Lucien ProTrader · stratégie auto »** ;
3. régler la **mise ($)** et le **payout (%)** ;
4. jouer le replay : **chaque bougie clôturée** est évaluée avec
   **toutes les combinaisons et règles de validation** du panneau Auto
   Trade (modifications appliquées en temps réel), les ordres simulés
   sont placés automatiquement ;
5. **expiration en NOMBRE DE BOUGIES** : l'expiration (secondes) de
   chaque règle est convertie selon le timeframe courant
   (ex. règle 60 s sur S30 → 2 bougies ; plancher 1 bougie) — l'ordre
   se règle après N bougies ;
6. `RESET TRADES` ré-arme la garde (une mise par bougie) pour rejouer
   l'historique.

## Validation (toutes exécutées sur cette livraison)

| Vérification | Résultat |
|---|---|
| `tsc --noEmit` (root / backend / SDK) | 0 erreur |
| `next build` | PASS — 6/6 pages |
| `scripts/test-v22-candles-validation.ts` (**nouveau** : sanitize, ancre L_Lucien vs Ninja, doji, refus, garde ninja, conversion bougies, libellés) | 68 ✓ / 0 ✗ |
| `tests/test-v22-ninja-e2e.mjs` (**nouveau** : vrai backend + faux broker S5/RGG/mèches) | 20/20 ✓ |
| — ordres Ninja placés avec validation `GRG` (impossible pour L_Lucien → preuve de l'ancre pré-clôture) | ✓ |
| — CHAQUE ordre placé PENDANT sa bougie signalée (bucket % 3 === 2) — avant clôture | ✓ |
| — libellés `Ninja ProTrader · CALL ▲ · call-ninja [BOS Up] · validation GRG` | ✓ |
| — règle impossible (`RRRRR`) → aucun ordre ; validation retirée → reprise + « sans validation » | ✓ |
| `tests/test-bos-choch-cisd-martingale-e2e.mjs` | 17/17 ✓ |
| `tests/test-confirm-candle-cap-e2e.mjs` | 24/24 ✓ |
| `tests/test-auto-switch-rule-e2e.mjs` | 20/20 ✓ |
| `tests/test-v21-rules-e2e.mjs` | 28/28 ✓ |
| `scripts/test-v21-rules.ts` | 61 ✓ / 0 ✗ |
| `tests/test-multi-assets.ts` | OK |
| `tests/test-v63-features.ts` / `test-v63-integration.ts` | OK |
| `tests/test-bos-choch-cisd-strategy.ts` | 22 ✓ |
| `scripts/test-martingale-streak.ts` | 12 ✓ |
| `scripts/test-bos-choch-cisd-expiry-martingale.ts` | 39 ✓ |
| `scripts/test-confirm-candle-cap.ts` | 59 ✓ |
| `scripts/test-smart-stream-hardening.mjs` | PASS |

## Comment re-vérifier vous-même

```bash
# 1. Installer et démarrer
npm install && cd mini-services/iqoption-backend && npm install

# 2. Typecheck + build
cd ../.. && npx tsc --noEmit && npx next build

# 3. Nouveautés v22
npx tsx scripts/test-v22-candles-validation.ts     # 68 ✓
cd mini-services/iqoption-backend
node tests/test-v22-ninja-e2e.mjs                  # 20/20 (vrai backend + faux broker)

# 4. Non-régression
node tests/test-bos-choch-cisd-martingale-e2e.mjs  # 17/17
node tests/test-confirm-candle-cap-e2e.mjs          # 24/24
node tests/test-auto-switch-rule-e2e.mjs           # 20/20
node tests/test-v21-rules-e2e.mjs                   # 28/28
```

Dans l'application :
- **Auto Trade → combinaison** : remplir « Candles Validation » (ex.
  `RGRR`) — le champ filtre les ordres selon les couleurs des
  dernières bougies clôturées ;
- **Auto Trade → Strategy** : choisir **Ninja ProTrader** — les
  ordres partent AVANT la clôture des bougies (badge orange
  « DÉTECTION AVANT CLÔTURE · TEMPS RÉEL ») ;
- **graphique** : chaque carte d'ordre affiche
  `Stratégie · direction · combinaison [alertes] · validation Règle` ;
- **Replay → Strategy Tester** : activer la stratégie auto
  L_Lucien ProTrader, régler mise/payout, jouer le replay — les ordres
  simulés s'expiration en bougies apparaissent avec leur libellé.
EOF

cd "$STAGE"
zip -qr "$OUT" "$FOLDER"
cd "$ROOT"
rm -rf "$STAGE"
echo "─ Livraison v22 ─────────────────────────────────────────────"
echo "Zip      : $OUT"
echo "Taille   : $(du -h "$OUT" | cut -f1)"
echo "Fichiers : $(unzip -l "$OUT" | tail -1 | awk '{print $2}')"
echo "Intégrité: $(unzip -t "$OUT" > /dev/null && echo OK || echo ÉCHEC)"
sha256sum "$OUT"
md5sum "$OUT"
