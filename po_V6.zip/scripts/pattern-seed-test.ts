import { runPineScript } from '../src/lib/pine-engine.ts'
import { readFileSync } from 'node:fs'

function makeCandles(n, start, stepMs, seed0) {
  const bars = []
  let price = 100
  let seed = seed0
  const rand = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648 }
  for (let i = 0; i < n; i++) {
    // sine-modulated drift creates clear peaks/troughs (pattern-friendly)
    const wave = Math.sin(i / 18) * 1.2 + Math.sin(i / 47) * 2.5
    const noise = (rand() - 0.5) * 0.6
    const open = price
    const close = open + wave * 0.15 + noise
    const high = Math.max(open, close) + rand() * 0.5
    const low = Math.min(open, close) - rand() * 0.5
    bars.push({ time: Math.floor((start + i * stepMs) / 1000), open, high, low, close, volume: 100 })
    price = close
  }
  return bars
}

const source = readFileSync('TradingView_pine_scripts_samples/pattern_1.pine', 'utf8')
for (const seed of [7, 99, 2024, 31337]) {
  const candles = makeCandles(2000, 1_700_000_000_000, 60_000, seed)
  const res = await runPineScript(source, candles, { symbol: 'X', timeframe: '1' })
  if (res.ok) {
    const types = {}
    for (const d of res.result.drawings) types[d.kind] = (types[d.kind] ?? 0) + 1
    console.log(`seed=${seed}: OK — drawings=${JSON.stringify(types)} plots=${res.result.plots.length}`)
  } else {
    console.log(`seed=${seed}: ${res.error.stage}: ${res.error.message.slice(0, 80)}`)
  }
}
