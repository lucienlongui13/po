#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v20.sh — Livraison v20 « 7 correctifs finaux »
#
# Le besoin (message utilisateur — 7 points) :
#   1. MARTINGALE MAX : « je règle à 4, il va jusqu'à 5 » → le cap compte
#      désormais N MISES dans la séquence (4 → 10/20/40/80 puis retour à
#      la mise initiale — la « 5e mise » n'existe plus).
#   2. AUTO TRADE : « 30 minutes à me battre pour le 1er ordre alors que
#      les signaux passent » → le switch d'asset (mode single) créait le
#      nouveau contexte avec autoTradeEnabled: false CODÉ EN DUR → l'Auto
#      Trade s'éteignait silencieusement à chaque switch.
#   3. AUTO SWITCH ASSETS (nouvelles règles) : « dès que le payout de
#      l'asset en cours baisse < 92 % et que le dernier ordre est un gain
#      et non une perte → switch automatique UNIQUEMENT vers des assets
#      avec profit == 92 % ».
#   4. ASSET EN COURS : « à chaque re-login ou refresh, toujours revenir
#      sur l'asset en cours (ex. USDJPY_OTC) » → restauration du FOCUS.
#   5. RE-LOGIN : « avant le re-login automatique, vérifier que le dernier
#      ordre placé est un gain, sinon attendre le gain ».
#   6. INDICATEURS : « par défaut au démarrage aucun indicateur ne doit
#      être actif » (l'ancien défaut auto-activait le Volume).
#   7. THÈME : « par défaut le thème du frontend est clair ».
#
# Les correctifs v20 :
#   1. asset-contexts.ts — computeBettingAmount : exposant max = N-1 ;
#      updateBettingAfterResult : reset quand streak >= N. UI : hint
#      « Séquence de N mise(s) max : 10 → 20 → 40 → 80 — puis retour à
#      10 $ si la 4e mise perd ». Cas signalé : cap 4, base 10 →
#      10→20→40→80→10 (JAMAIS 160).
#   2. index.ts switchAssetAndRefresh (single) : autoTradeEnabled:
#      session.config.autoTradeEnabled && session.config.autoOpen (le
#      nouveau contexte hérite de l'état global, comme le mode multi).
#   3. payout-guard.ts RÉÉCRIT : AUTO_SWITCH_TRIGGER_PCT = 92 (payout
#      < 92 % déclencheur), AUTO_SWITCH_TARGET_PCT = 92 (cible == 92 %
#      EXACTEMENT, tolérance ±0,05), verrou lastOrderWinByAsset (une
#      PERTE ou un Tie sur le dernier ordre de l'asset BLOQUE le switch ;
#      aucun ordre réglé → autorisé), positions ouvertes → attente,
#      cooldown 2 min/asset + quota 12/h (anti-churn), modes single
#      (asset FOCUS = « l'asset en cours ») ET multi. SUPPRIMÉS : le
#      switch post-trade (chaque trade, win OU loss) et le switch
#      « 90 s idle » (churn permanent). Branché sur chaque poussée
#      updateAssets (client.on('assets') → runPayoutGuard, re-indexé par
#      NOM d'asset — l'AssetsMap du SDK est indexée par ID numérique)
#      + ré-évaluation périodique 10 s (un gain qui règle juste après
#      une poussée ne doit pas attendre la suivante). Diagnostic :
#      « switch en attente du prochain GAIN » loggé une fois par asset.
#   4. index.ts restoreSessionSnapshot : restaure snap.focus (asset en
#      cours avant re-login/refresh/redémarrage) — avant, le focus
#      retombait sur assets[0] au login avec session persistée.
#   5. index.ts performScheduledRelogin : verrou reloginBlockReason()
#      (ordre en vol → attente TOUJOURS ; dernier ordre réglé ≠ gain →
#      attente), retry 15 s, réveil IMMÉDIAT au gain (deal_closed),
#      garde-fou 10 min sans ordre en vol (session broker vivante),
#      session.lastSettledWin suivi à chaque règlement.
#   6. tv-store.ts defaultIndicators() → [] ; l'ancien défaut [Volume]
#      seul (auto-persisté) est réinitialisé à [] au hydrate (tout autre
#      choix utilisateur est conservé).
#   7. page.tsx useState(false) + globals.css inversé (fond blanc par
#      défaut AVANT le premier rendu React — plus de flash sombre ; le
#      thème sombre n'existe plus que via la classe html.dark).
#
# Validation : tsc root 0 · tsc backend 0 · tsc SDK 0 · next build PASS
# (6/6) · confirm-candle-cap 59 ✓ · confirm-candle-cap-e2e 24/24 ✓ (mises
# 1→2→1→2→1) · auto-switch-rule-e2e (NOUVEAU) 20/20 ✓ · defaults-v20 7 ✓ ·
# multi-assets 134 ✓ · v63-features 74 ✓ · v63-intégration 14 ✓ ·
# bos-strategy 22 ✓ · martingale-streak 12 ✓ · bos-expiry-martingale 39 ✓ ·
# bos-martingale-e2e 17/17 ✓ · tie-refund-e2e 24/24 ✓ · multi-e2e 20/20 ✓ ·
# smart-stream-hardening (v20) PASS. TOTAL 466 vérifications.
#
# Sortie : /home/z/my-project/download/pine_v6_engine_v20_final_fixes.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v20"
FOLDER=pine_v6_engine
OUT="$ROOT/download/pine_v6_engine_v20_final_fixes.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (structure identique aux zips v15-v19) ───────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude '.logs/' \
  --exclude '*.log' \
  --exclude 'winwinlogs.jsonl' \
  --exclude 'mini-services/iqoption-backend/data/backend-session.json' \
  --exclude 'mini-services/iqoption-backend/data/candle-cache/' \
  --exclude 'mini-services/iqoption-backend/e2e-*.log' \
  --exclude 'db/' \
  "$ROOT/pine_v6_engine/" "$STAGE/$FOLDER/"

# ── README de la version v20 ─────────────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.6-V20-FINAL-FIXES.md" <<'EOF'
# Pine v6 Engine — v20 « L_Lucien ProTrader » : 7 correctifs finaux

## 1. Martingale max — N = N mises dans la séquence (bug signalé)

**Avant (v19)** : régler « Martingale max — doublements » à 4 produisait
**5 mises** (10 → 20 → 40 → 80 → **160**) avant le retour à la base —
le cap comptait les *doublements*.

**v20** : le champ compte le **nombre maximal de mises** de la
séquence. Exemples (base 10 $) :

| Réglage | Séquence de mises | Mise maximale |
|---|---|---|
| 4 | 10 → 20 → 40 → 80 | 80 $ — si le 80 perd → retour à 10 $ |
| 5 | 10 → 20 → 40 → 80 → 160 | 160 $ — si le 160 perd → retour à 10 $ |
| 2 | 10 → 20 | 20 $ — si le 20 perd → retour à 10 $ |
| 0 | illimité | double à chaque perte jusqu'à un gain |

La « 5e mise » avec le réglage 4 **n'existe plus**. Le hint du panneau
affiche la séquence exacte : « Séquence de 4 mise(s) max : 10 → 20 → 40
→ 80 — puis retour à 10 $ si la 4e mise perd ». Le champ libellé
« Martingale max — doublements » garde son nom (celui de l'UI d'origine)
mais sa sémantique est « nombre de mises de la séquence ».

Un **gain** réinitialise à la base, un **Tie/Refund** reste neutre (v17),
l'état reste **isolé par asset**, Fibonacci/Fixed non affectées, le cap
reste persisté et clampé [0, 1000].

## 2. Auto Trade — le 1er ordre ne se bat plus 30 minutes (bug signalé)

**Cause racine** : à chaque switch automatique d'asset en mode mono
(auto-switch, remplacement), le contexte du NOUVEL asset était créé avec
`autoTradeEnabled: false` **codé en dur** — l'Auto Trade s'éteignait
**silencieusement** alors que le master-switch du panneau restait ON :
les signaux passaient à l'écran, plus aucun ordre ne partait. L'utilisateur
devait éteindre/rallumer le switch (ou changer d'asset) pour repartir.

**v20** : le nouveau contexte **hérite de l'état global**
(`autoTradeEnabled: global && autoOpen`), exactement comme le mode
multi-assets. Combiné au point 3 (fini le switch « 90 s idle » qui
churnait l'asset toutes les 90 secondes), le premier ordre suit le
premier vrai signal BOS/CHoCH/CISD sur l'historique frais de l'asset
(≈ 30-100 s selon la formation de la structure — c'est la stratégie
qui attend un événement réel, plus jamais un contexte désactivé).

## 3. Auto Switch Assets — nouvelles règles

> « Dès que le pourcentage de profit de l'asset en cours baisse à une
> valeur < 92 % et que le dernier ordre est un gain et non une perte,
> alors on switch d'assets automatiquement — que sur des assets avec
> profit == 92 %. »

| Étape | Règle v20 |
|---|---|
| Déclencheur | payout de l'asset en cours passe **< 92 %** (poussée updateAssets du broker, ré-évalué aussi toutes les 10 s) |
| Verrou | le **dernier ordre réglé** de CET asset doit être un **GAIN** — une perte ou un Tie bloque le switch (une Martingale en récupération n'est JAMAIS abandonnée en cours de route) ; un asset sans ordre réglé peut être quitté immédiatement |
| Ordre en vol | une position ouverte retarde le switch jusqu'à sa clôture |
| Cible | **exclusivement** un asset de payout **== 92 %** (marché ouvert, non sélectionné) — les payouts 85, 88, 90, 95 % sont exclus |
| Application | mode mono : switch complet + refresh candles ; mode multi : remplacement en conservant la position dans la liste |
| Anti-churn | cooldown 2 min par asset écarté, quota 12 switches/heure |
| Diagnostic | log « payout X % (< 92 %) mais le dernier ordre est une PERTE — switch en attente du prochain GAIN » (une fois par asset) + log du switch avec la cible == 92 % |

**Supprimés** (remplacés par la règle ci-dessus) : le switch après
**chaque** trade (gain OU perte, cible aléatoire 90-92 %) et le switch
**90 s sans ordre** — ce dernier churnait les assets sans cesse et
était la principale source du bug n° 2.

## 4. Retour sur l'asset en cours après re-login / refresh

- **Re-login automatique** (H+30) : l'asset affiché avant le re-login
  (`tradingMode.focus`) est restauré — ex. USDJPY_OTC avant → USDJPY_OTC
  après ;
- **Redémarrage du backend / login avec session persistée** : le FOCUS
  sauvegardé est désormais réappliqué (avant, la sélection retombait sur
  le **premier** asset de la liste) ;
- **Refresh du navigateur** : le flux status 1 Hz du backend restaure
  l'affichage sur l'asset en cours (le backend headless n'a jamais
  changé d'asset).

## 5. Re-login automatique : attendre le gain

Avant chaque re-login automatique (30 min), le backend vérifie :

1. **aucun ordre en vol** — un ordre ouvert est TOUJOURS attendu
   (jamais coupé en cours de route) ;
2. **le dernier ordre réglé est un GAIN** — une perte ou un Tie reporte
   le re-login ; un **retry automatique toutes les 15 s** vérifie la
   condition ;
3. dès qu'un **gain est réglé**, le re-login part **immédiatement**
   (réveil instantané — pas d'attente du retry) ;
4. garde-fou : si **aucun ordre n'est en vol** depuis plus de 10 minutes
   et qu'aucun gain n'arrive, le re-login s'exécute quand même (garder
   la session broker vivante) — la session ne meurt jamais de cette
   attente.

## 6. Aucun indicateur actif par défaut

Au démarrage, **aucun** indicateur n'est actif (l'ancien défaut activait
le Volume d'office). L'utilisateur choisit lui-même via le menu
**Indicators**. Les sessions existantes dont la sauvegarde ne contenait
QUE le Volume (l'ancien défaut auto-persisté) repartent également à
zéro ; tout autre combinaison (choix explicite) est conservée.

## 7. Thème clair par défaut

Le frontend démarre en **thème clair** : fond blanc posé dans la CSS
**avant même le premier rendu React** (plus de flash sombre), texte
noir, scrollbars claires. Le sélecteur du TopBar bascule vers le thème
sombre via la classe `html.dark` (non persisté — chaque démarrage
revient clair).

## Validation (toutes exécutées sur cette livraison)

| Vérification | Résultat |
|---|---|
| `tsc --noEmit` (root / backend / SDK) | 0 erreur |
| `next build` | PASS — 6/6 pages |
| `scripts/test-confirm-candle-cap.ts` (cap = N mises, cas signalé 4→10/20/40/80, lastOrderWin) | 59 ✓ / 0 ✗ |
| `tests/test-confirm-candle-cap-e2e.mjs` (vrai backend + faux broker) | 24/24 ✓ — mises `1→2→1→2→1` (cap 2) |
| `tests/test-auto-switch-rule-e2e.mjs` (**nouveau**, vrai backend + faux broker, payouts dynamiques) | 20/20 ✓ |
| — Phase A : WIN puis payout 92 % → 56 % | switch ≤ 12 s vers GBPUSD_otc (== 92 %), **1er ordre du nouvel asset sans retoggle** (bug 2) |
| — Phase B : LOSS puis payout 56 % | **aucun switch** (« en attente du prochain GAIN ») |
| — Phase B : WIN suivant | switch ≤ 20 s vers USDJPY_otc (== 92 %) |
| `scripts/test-defaults-v20.ts` (indicateurs [] + ancien Volume réinitialisé + thème clair) | 7 ✓ / 0 ✗ |
| `tests/test-multi-assets.ts` | 134 OK / 0 échec |
| `tests/test-v63-features.ts` (SECTION B réécrite : 29 vérifications Auto Switch) | 74 OK / 0 échec |
| `tests/test-v63-integration.ts` | 14 OK / 0 échec |
| `tests/test-bos-choch-cisd-strategy.ts` | 22 ✓ / 0 ✗ |
| `scripts/test-martingale-streak.ts` | 12 ✓ / 0 ✗ |
| `scripts/test-bos-choch-cisd-expiry-martingale.ts` | 39 ✓ / 0 ✗ |
| `tests/test-bos-choch-cisd-martingale-e2e.mjs` | 17/17 ✓ |
| `tests/test-martingale-tie-refund-e2e.mjs` | 24/24 ✓ |
| `tests/test-bos-choch-cisd-multi-e2e.mjs` (2 assets, martingale isolée) | 20/20 ✓ |
| `scripts/test-smart-stream-hardening.mjs` (mis à jour v20 : gate auto-switch, propagation single, verrou re-login) | PASS |

**Total : 466 vérifications, 0 échec.**

## Comment re-vérifier vous-même

```bash
# 1. Installer et démarrer
npm install && cd mini-services/iqoption-backend && npm install

# 2. Typecheck + build
cd ../.. && npx tsc --noEmit && npx next build

# 3. Nouveautés v20
npx tsx scripts/test-confirm-candle-cap.ts     # 59 ✓ (cap = N mises)
npx tsx scripts/test-defaults-v20.ts           # 7 ✓ (indicateurs + thème)
cd mini-services/iqoption-backend
node tests/test-auto-switch-rule-e2e.mjs       # 20/20 (nouvelle règle)
node tests/test-confirm-candle-cap-e2e.mjs    # 24/24

# 4. Non-régression
node --import tsx tests/test-multi-assets.ts  # 134 ✓
node --import tsx tests/test-v63-features.ts  # 74 ✓
node tests/test-bos-choch-cisd-martingale-e2e.mjs # 17/17
node tests/test-martingale-tie-refund-e2e.mjs     # 24/24
```

Dans l'application :
- panneau Auto Trade → Stake strategy **Martingale** → régler
  « Martingale max — doublements » à **4** (base 10) → la « Prochaine
  stake » suit 10 → 20 → 40 → 80 → **10** (jamais 160) ;
- activer « Auto-switch assets » : quand le payout de l'asset affiché
  passe sous 92 % et que son dernier ordre est un gain, l'asset est
  remplacé par un asset 92 % (toast de notification) ; après une perte,
  le switch attend le prochain gain (visible dans les logs) ;
- au démarrage : aucun indicateur actif, thème clair ; fermer/rouvrir
  le navigateur → retour sur l'asset en cours ; le re-login
  automatique n'arrive jamais pendant une perte ou un ordre en vol.
EOF

# ── Zippage ───────────────────────────────────────────────────────────────
cd "$STAGE"
zip -qr "$OUT" "$FOLDER"
cd "$ROOT"
rm -rf "$STAGE"

echo "─ Livraison v20 ─────────────────────────────────────────────"
echo "Zip      : $OUT"
echo "Taille   : $(du -h "$OUT" | cut -f1)"
echo "Fichiers : $(unzip -l "$OUT" | tail -1 | awk '{print $2}')"
echo "Intégrité: $(unzip -t "$OUT" > /dev/null && echo OK || echo ÉCHEC)"
