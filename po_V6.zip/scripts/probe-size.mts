/** probe-size.mts — vérifie la valeur size propagée par piner aux labels. */
const backing = new Map<string, string>()
;(globalThis as any).window = {
  localStorage: {
    getItem: (k: string) => backing.get(k) ?? null,
    setItem: (k: string, v: string) => { backing.set(k, String(v)) },
    removeItem: (k: string) => { backing.delete(k) },
  },
}
const { runPineScript } = await import('../src/lib/pine-engine')

const candles = Array.from({ length: 40 }, (_, i) => ({
  time: 1789283280 + i * 60,
  open: 1.1 + Math.sin(i / 3) * 0.01,
  high: 1.11 + Math.sin(i / 3) * 0.01,
  low: 1.09 + Math.sin(i / 3) * 0.01,
  close: 1.1 + Math.sin((i + 1) / 3) * 0.01,
  volume: 100,
}))

const src = `//@version=6
indicator("probe size", overlay=true)
label.new(5, close, "Lnormal", size = size.normal)
label.new(6, close, "Lsmall", size = size.small)
label.new(7, close, "Ltiny", size = size.tiny)
label.new(8, close, "Lhuge", size = size.huge)
`
const res = await runPineScript(src, candles, { symbol: 'EURUSD_otc', timeframe: '1' })
if (!res.ok) { console.error('ÉCHEC', (res as any).error?.message); process.exit(1) }
for (const d of res.result.drawings as any[]) {
  console.log(d.text, '→ size =', JSON.stringify(d.size))
}
