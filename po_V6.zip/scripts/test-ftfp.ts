import assert from 'node:assert/strict'
import { INDICATORS } from '../src/lib/indicators-library'

const ftfp = INDICATORS.find(i => i.id === 'fractal-trigonometric-forecast')
assert.ok(ftfp, 'FTFP must be registered')
assert.equal(ftfp!.name, 'Fractal Trigonometric Forecast')
assert.equal(ftfp!.short, 'FTFP')
assert.deepEqual(ftfp!.params.map(p => [p.key,p.default,p.min,p.max,p.step]), [
  ['threshold',0.45,0.10,1.20,0.05],
  ['projection',1.00,0.10,2.00,0.10],
])

const candles = Array.from({length: 80}, (_, i) => ({
  time: i * 60,
  open: 100 + Math.sin(i / 5) * 2,
  high: 102 + Math.sin(i / 5) * 2 + (i % 3) * 0.2,
  low: 98 + Math.sin(i / 5) * 2 - (i % 4) * 0.2,
  close: 100 + Math.sin(i / 4) * 2.5,
  volume: 0,
}))
const out = ftfp!.compute(candles, {threshold:0.45, projection:1.0})
for (const key of ['ema13','ema34','visual','predict','call','put','score','trig']) assert.ok(Array.isArray(out[key]), `${key} series missing`)
assert.equal(out.score.length, candles.length)
assert.equal(out.trig.length, candles.length)
console.log('FTFP test OK')
