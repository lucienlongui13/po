#!/bin/bash
# build-zip-v25-update.sh — Livraison « pine_v6_engine_v25_remaining_time_closure_update.zip »
# (mission 73 candle patterns : zip final au nom EXIGÉ par le cahier des charges)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="/home/z/my-project/download/pine_v6_engine_v25_remaining_time_closure_update.zip"
cd "$ROOT"
rm -f "$OUT"
zip -r -q "$OUT" . \
  -x "node_modules/*" \
  -x "mini-services/iqoption-backend/node_modules/*" \
  -x "mini-services/iqoption-backend/pocket-option-sdk/node_modules/*" \
  -x ".next/*" -x "*.log" -x ".logs/*" -x ".logs" \
  -x "backend-session.json" -x "backend-session.json.*" \
  -x "mini-services/iqoption-backend/data/*" \
  -x "mini-services/iqoption-backend/candle-cache/*" \
  -x "mini-services/iqoption-backend/.candle-cache/*" \
  -x "tsconfig.tsbuildinfo" -x "e2e-*.log" -x ".git/*" -x "tests/*.log"
echo "OK → $OUT ($(du -h "$OUT" | cut -f1), $(unzip -l "$OUT" | tail -1 | awk '{print $2}') fichiers)"
unzip -t "$OUT" > /dev/null && echo "intégrité zip vérifiée (unzip -t OK)"
sha256sum "$OUT" | awk '{print "SHA-256 : " $1}'
