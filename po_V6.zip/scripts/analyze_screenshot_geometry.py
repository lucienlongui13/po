#!/usr/bin/env python3
"""Pixel-geometry analysis of the user's chart screenshot.

Locates:
  - candle bodies/wicks (green #26a69a / red #ef5350 families)
  - indicator line pixels (high-saturation non-candle colors)
  - label-ish blobs
and reports their vertical distributions to quantify the misalignment.
"""
from PIL import Image
import sys
from collections import Counter

path = sys.argv[1] if len(sys.argv) > 1 else '/home/z/my-project/upload/SmartSelect_20260915_012554_Chrome.jpg'
img = Image.open(path).convert('RGB')
W, H = img.size
print(f'image {W}x{H}')

px = img.load()

def classify(r, g, b):
    # candle-up: teal/green family (#26a69a)
    if g > 90 and 100 < r < 190 and 120 < b < 190 and g > r + 30:
        return 'candle_up'
    # candle-down: red family (#ef5350)
    if r > 150 and g < 110 and b < 110 and r > g + 60 and r > b + 60:
        return 'candle_down'
    # bright saturated others (indicator lines / labels)
    mx, mn = max(r, g, b), min(r, g, b)
    if mx > 120 and (mx - mn) > 60:
        if r >= g and r >= b and g > 120 and b < 120: return 'line_yellow_orange'  # orange/yellow
        if r > 180 and g > 180 and b < 120: return 'line_yellow'
        if b >= g and b >= r and b > 130: return 'line_blue_cyan'
        if g >= r and g >= b and g > 130: return 'line_green_bright'
        if r >= g and r >= b and r > 130: return 'line_red_bright'
        return 'line_other'
    # whites (labels/text)
    if r > 200 and g > 200 and b > 200:
        return 'white'
    return None

buckets = {}
for y in range(0, H, 2):
    for x in range(0, W, 2):
        c = classify(*px[x, y])
        if c:
            buckets.setdefault(c, []).append(y)

print('\n─ vertical distribution (percent of image height) ─')
for k in sorted(buckets):
    ys = buckets[k]
    n = len(ys)
    print(f'{k:18s} n={n:6d}  y-range {min(ys)/H*100:5.1f}% … {max(ys)/H*100:5.1f}%  mean {sum(ys)/n/H*100:5.1f}%')

# horizontal distribution of candles vs lines
def xrange_of(cls_list):
    xs = []
    for y in range(0, H, 2):
        for x in range(0, W, 2):
            if classify(*px[x, y]) in cls_list:
                xs.append(x)
    return (min(xs)/W*100, max(xs)/W*100) if xs else (None, None)

print('\n─ horizontal extent ─')
for name, cls in [('candles', ('candle_up', 'candle_down')),
                  ('indicator lines', ('line_yellow_orange', 'line_yellow', 'line_blue_cyan', 'line_green_bright', 'line_red_bright', 'line_other'))]:
    a, b = xrange_of(cls)
    print(f'{name:16s} x-range {a}% … {b}%')

# vertical histogram (10 bands) for candles vs lines
print('\n─ 10 vertical bands: candles / lines pixel counts ─')
for band in range(10):
    y0, y1 = int(H*band/10), int(H*(band+1)/10)
    cu = sum(1 for y in range(y0, y1, 2) for x in range(0, W, 2) if classify(*px[x, y]) in ('candle_up', 'candle_down'))
    li = sum(1 for y in range(y0, y1, 2) for x in range(0, W, 2) if classify(*px[x, y]) in ('line_yellow_orange', 'line_yellow', 'line_blue_cyan', 'line_green_bright', 'line_red_bright', 'line_other'))
    print(f'band {band} ({band*10:3d}-{band*10+10:3d}%): candles={cu:6d}  lines={li:6d}')
