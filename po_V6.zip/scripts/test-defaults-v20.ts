/**
 * test-defaults-v20.ts — v20 : défauts au démarrage du frontend.
 * ================================================================
 *
 * 1. INDICATEURS : AUCUN indicateur actif par défaut (l'utilisateur choisit
 *    lui-même). Avant v20 : Volume était activé d'office.
 *    - defaultIndicators() === [] ;
 *    - une sauvegarde workspace contenant UNIQUEMENT le Volume (l'ancien
 *      défaut auto-persisté) est traitée comme « pas un choix utilisateur »
 *      → liste vide au démarrage ;
 *    - toute AUTRE combinaison (choix explicite) est conservée.
 *
 * 2. THÈME : clair par défaut (const du composant page — vérifié par
 *    lecture du code source, le rendu React n'étant pas exécutable ici).
 *
 * Exécution : node --import tsx scripts/test-defaults-v20.ts
 */
import * as fs from 'node:fs';
import * as path from 'node:path';

let pass = 0, fail = 0;
function ok(cond: boolean, label: string) {
  if (cond) { pass++; console.log(`  ✓ ${label}`); }
  else { fail++; console.error(`  ✗ ${label}`); }
}

/** Fabrique un IndicatorInstance (comme makeIndicator du store). */
function makeIndicator(defId: string): any {
  return { uid: `test-${defId}`, defId, params: {}, visible: true, plotSettings: {}, cloudVisible: undefined };
}

async function main(): Promise<void> {
  // ── Store localStorage factice (AVANT l'import du module) ────────────────
  const store = new Map<string, string>();
  (globalThis as any).localStorage = {
    getItem: (k: string) => (store.has(k) ? store.get(k)! : null),
    setItem: (k: string, v: string) => { store.set(k, String(v)); },
    removeItem: (k: string) => { store.delete(k); },
  };

  const { useTVStore } = await import('../src/lib/tv-store.js');

  console.log('\n═══ v20 — 1. AUCUN indicateur actif par défaut ═══');

  {
    const s1 = useTVStore.getState();
    ok(Array.isArray(s1.indicators) && s1.indicators.length === 0,
      `defaultIndicators() → [] (obtenu ${s1.indicators.length} indicateur(s))`);
  }

  {
    // Hydrate avec l'ANCIEN défaut auto-persisté ([Volume] seul) → vide.
    useTVStore.setState({ indicators: [] as any });
    store.set('pc-trade-workspace-v1', JSON.stringify({
      chartStyle: 'candles',
      indicators: [makeIndicator('volume')],
      notes: '',
    }));
    useTVStore.getState().hydrate();
    const s2 = useTVStore.getState();
    ok(s2.indicators.length === 0,
      `ancien défaut [Volume] seul → réinitialisé à [] (obtenu ${s2.indicators.length})`);
  }

  {
    // Hydrate avec un VRAI choix utilisateur (RSI) → conservé.
    useTVStore.setState({ indicators: [] as any });
    store.set('pc-trade-workspace-v1', JSON.stringify({
      chartStyle: 'candles',
      indicators: [makeIndicator('rsi')],
      notes: '',
    }));
    useTVStore.getState().hydrate();
    const s3 = useTVStore.getState();
    ok(s3.indicators.length === 1 && s3.indicators[0]?.defId === 'rsi',
      `choix utilisateur [RSI] → conservé (obtenu ${s3.indicators.map((i: any) => i.defId).join(',')})`);
  }

  {
    // addIndicator fonctionne toujours (l'utilisateur peut activer).
    useTVStore.setState({ indicators: [] as any });
    useTVStore.getState().addIndicator('volume');
    const s4 = useTVStore.getState();
    ok(s4.indicators.length === 1 && s4.indicators[0]?.defId === 'volume',
      'addIndicator(volume) → activé manuellement (choix utilisateur)');
  }

  console.log('\n═══ v20 — 2. Thème clair par défaut (code source) ═══');

  {
    const here = path.dirname(new URL(import.meta.url).pathname);
    const pagePath = path.resolve(here, '..', 'src', 'app', 'page.tsx');
    const src = fs.readFileSync(pagePath, 'utf-8');
    ok(/const \[dark, setDark\] = useState\(false\)/.test(src),
      'page.tsx : useState(false) — thème CLAIR par défaut');
    const cssPath = path.resolve(here, '..', 'src', 'app', 'globals.css');
    const css = fs.readFileSync(cssPath, 'utf-8');
    ok(/background: #ffffff;\s*\/\* v20 — défaut : thème CLAIR \*\//.test(css),
      'globals.css : fond body blanc par défaut (pas de flash sombre au 1er rendu)');
    ok(/html\.dark body\s*\{/.test(css),
      'globals.css : thème sombre uniquement via la classe html.dark');
  }

  console.log(`\n═══ RÉSULTAT : ${pass} ✓ / ${fail} ✗ ═══`);
  if (fail > 0) process.exit(1);
}

void main();
