/** probe-size2.mts — teste ut.size() du pack via une lib importée. */
const backing = new Map<string, string>()
;(globalThis as any).window = {
  localStorage: {
    getItem: (k: string) => backing.get(k) ?? null,
    setItem: (k: string, v: string) => { backing.set(k, String(v)) },
    removeItem: (k: string) => { backing.delete(k) },
  },
}
import { readFileSync } from 'node:fs'
const { importLibraryBundle } = await import('../src/lib/pine-libraries')
const { runPineScript } = await import('../src/lib/pine-engine')

const base = '/home/z/my-project/upload/pine_full_pack_extracted/pine_full_pack'
const rd = (p: string) => readFileSync(`${base}/${p}`, 'utf8')
importLibraryBundle([
  { name: 'Main.pine', source: rd('Main.pine') },
  { name: 'PubLibSwing.pine', source: rd('libs/PubLibSwing.pine') },
  { name: 'PubLibTrend.pine', source: rd('libs/PubLibTrend.pine') },
  { name: 'PubLibUtility.pine', source: rd('libs/PubLibUtility.pine') },
  { name: 'PubLibCandleTrend.pine', source: rd('libs/PubLibCandleTrend.pine') },
])

const candles = Array.from({ length: 40 }, (_, i) => ({
  time: 1789283280 + i * 60,
  open: 1.1 + Math.sin(i / 3) * 0.01,
  high: 1.11 + Math.sin(i / 3) * 0.01,
  low: 1.09 + Math.sin(i / 3) * 0.01,
  close: 1.1 + Math.sin((i + 1) / 3) * 0.01,
  volume: 100,
}))

/* Utilise la librairie utilitaire comme le pack, + un label direct */
const src = `//@version=6
indicator("probe ut.size", overlay=true)
import PiracyChecker/PubLibUtility/2 as ut
label_size_inp = input.string("Normal", "Label Size", ["Tiny", "Small", "Normal", "Large", "Huge", "Auto"])
label_size = ut.size(label_size_inp)
label.new(5, close, "viaUt", size = label_size)
label.new(7, close, "directNormal", size = size.normal)
`
const res = await runPineScript(src, candles, { symbol: 'EURUSD_otc', timeframe: '1' })
if (!res.ok) { console.error('ÉCHEC', (res as any).error?.message); process.exit(1) }
for (const d of res.result.drawings as any[]) console.log(d.text, '→ size =', JSON.stringify(d.size))
