/**
 * test-pine-libraries.ts — Tests unitaires v1.7 : registre multi-librairies.
 *
 * Couvre : extraction d'imports, dérivation de clés par cross-référence,
 * ALIAS D'AUTEURS (même fichier référencé sous deux éditeurs), garde anti-
 * ambiguïté, import de bundle, dépendances transitives manquantes, shim
 * intégré remplaçable, registre piner, lecture ZIP réelle (PiracyChecker.zip),
 * et compilation piner end-to-end du pack complet.
 *
 * Exécution : npx tsx scripts/test-pine-libraries.ts
 */
import { readFileSync } from 'node:fs'

let failures = 0
let passed = 0
const check = (name: string, cond: boolean, detail = '') => {
  if (!cond) { failures++; console.error(`  ✗ ${name} ${detail}`) }
  else { passed++; console.log(`  ✓ ${name}${detail ? ' — ' + detail : ''}`) }
}

let addLibrary!: typeof import('../src/lib/pine-libraries').addLibrary
let removeLibrary!: typeof import('../src/lib/pine-libraries').removeLibrary
let listLibraries!: typeof import('../src/lib/pine-libraries').listLibraries
let getLibrarySource!: typeof import('../src/lib/pine-libraries').getLibrarySource
let asPinerRegistry!: typeof import('../src/lib/pine-libraries').asPinerRegistry
let extractImports!: typeof import('../src/lib/pine-libraries').extractImports
let extractImportPaths!: typeof import('../src/lib/pine-libraries').extractImportPaths
let inspectSourceKind!: typeof import('../src/lib/pine-libraries').inspectSourceKind
let deriveLibraryKeys!: typeof import('../src/lib/pine-libraries').deriveLibraryKeys
let importLibraryBundle!: typeof import('../src/lib/pine-libraries').importLibraryBundle
let computeMissingLibraries!: typeof import('../src/lib/pine-libraries').computeMissingLibraries
let backing = new Map<string, string>()

async function main() {
/* ── shim localStorage pour Node (pine-libraries persiste dedans) ── */
backing = new Map<string, string>()
;(globalThis as any).window = {
  localStorage: {
    getItem: (k: string) => backing.get(k) ?? null,
    setItem: (k: string, v: string) => { backing.set(k, String(v)) },
    removeItem: (k: string) => { backing.delete(k) },
  },
}

const lib = await import('../src/lib/pine-libraries')
addLibrary = lib.addLibrary
removeLibrary = lib.removeLibrary
listLibraries = lib.listLibraries
getLibrarySource = lib.getLibrarySource
asPinerRegistry = lib.asPinerRegistry
extractImports = lib.extractImports
extractImportPaths = lib.extractImportPaths
inspectSourceKind = lib.inspectSourceKind
deriveLibraryKeys = lib.deriveLibraryKeys
importLibraryBundle = lib.importLibraryBundle
computeMissingLibraries = lib.computeMissingLibraries

function cleanup() {
  for (const lib of listLibraries()) removeLibrary(lib.key)
}

/* ═══ Sources du pack PiracyChecker (le fichier-exemple de l'utilisateur) ═══ */
const base = '/home/z/my-project/upload/piracy_extracted/Market_structures_scripts'
const mainSrc = readFileSync(`${base}/Main.pine`, 'utf8')
const swingSrc = readFileSync(`${base}/libs/PubLibSwing.pine`, 'utf8')
const trendSrc = readFileSync(`${base}/libs/PubLibTrend.pine`, 'utf8')
const utilitySrc = readFileSync(`${base}/libs/PubLibUtility.pine`, 'utf8')
const candleTrendSrc = readFileSync(`${base}/libs/PubLibCandleTrend.pine`, 'utf8')
const packFiles = [
  { name: 'Market_structures_scripts/Main.pine', source: mainSrc },
  { name: 'Market_structures_scripts/libs/PubLibSwing.pine', source: swingSrc },
  { name: 'Market_structures_scripts/libs/PubLibTrend.pine', source: trendSrc },
  { name: 'Market_structures_scripts/libs/PubLibUtility.pine', source: utilitySrc },
  { name: 'Market_structures_scripts/libs/PubLibCandleTrend.pine', source: candleTrendSrc },
]

/* ── 1. extraction d'imports ── */
console.log('\n[1] Extraction d\'imports')
{
  const imps = extractImports(mainSrc)
  check('3 imports directs dans Main.pine', imps.length === 3, imps.map((i) => i.alias).join(','))
  check('alias sw → PubLibSwing', imps.some((i) => i.alias === 'sw' && i.path === 'PiracyChecker/PubLibSwing/3'))
  check('alias tr → PubLibTrend', imps.some((i) => i.alias === 'tr' && i.path === 'PiracyChecker/PubLibTrend/3'))
  check('alias ut → PubLibUtility', imps.some((i) => i.alias === 'ut' && i.path === 'PiracyChecker/PubLibUtility/2'))
  check('import transitif de PubLibTrend → theEccentricTrader/PubLibSwing/3',
    extractImports(trendSrc).some((i) => i.path === 'theEccentricTrader/PubLibSwing/3'))
  check('extractImportPaths dédupliqué', extractImportPaths(mainSrc).length === 3)
  check('inspectSourceKind library', inspectSourceKind(swingSrc).declaration === 'library' && inspectSourceKind(swingSrc).title === 'PubLibSwing')
  check('inspectSourceKind indicator', inspectSourceKind(mainSrc).declaration === 'indicator')
}

/* ── 2. dérivation de clés : cross-référence + ALIAS D'AUTEURS ── */
console.log('\n[2] Dérivation de clés (deriveLibraryKeys)')
{
  const derived = deriveLibraryKeys(packFiles)
  const byName = new Map(derived.libraries.map((l) => [l.libName, l]))

  check('4 librairies détectées', derived.libraries.length === 4, derived.libraries.map((l) => l.libName).join(','))
  check('1 script principal détecté (Main.pine)',
    derived.mainScripts.length === 1 && derived.mainScripts[0].title === 'BOS, CHoCH and CISD [PiracyChecker]')

  const swing = byName.get('PubLibSwing')!
  check('PubLibSwing — clé primaire PiracyChecker/PubLibSwing/3', swing.key === 'PiracyChecker/PubLibSwing/3', swing.key)
  check('PubLibSwing — ALIAS theEccentricTrader/PubLibSwing/3 (import de PubLibTrend)',
    swing.aliases.includes('theEccentricTrader/PubLibSwing/3'), swing.aliases.join(','))
  check('PubLibSwing — matched=import', swing.matched === 'import')

  check('PubLibTrend → PiracyChecker/PubLibTrend/3', byName.get('PubLibTrend')?.key === 'PiracyChecker/PubLibTrend/3')
  check('PubLibUtility → PiracyChecker/PubLibUtility/2', byName.get('PubLibUtility')?.key === 'PiracyChecker/PubLibUtility/2')
  check('PubLibCandleTrend → PiracyChecker/PubLibCandleTrend/2 (import de PubLibSwing)',
    byName.get('PubLibCandleTrend')?.key === 'PiracyChecker/PubLibCandleTrend/2')

  // pack SANS le Main (librairies seules) : la seule référence à PubLibSwing
  // est l'import transitif de PubLibTrend → theEccentricTrader/… devient la
  // clé primaire (l'alias PiracyChecker/… sera complété quand Main arrivera).
  const libsOnly = deriveLibraryKeys(packFiles.slice(1))
  const swingOnly = libsOnly.libraries.find((l) => l.libName === 'PubLibSwing')!
  check('sans Main : PubLibSwing enregistrée sous theEccentricTrader/PubLibSwing/3 (seule référence du pack)',
    swingOnly.key === 'theEccentricTrader/PubLibSwing/3' && swingOnly.aliases.length === 0, swingOnly.key)
  const trendOnly = libsOnly.libraries.find((l) => l.libName === 'PubLibTrend')!
  check('sans Main : PubLibTrend en fallback local/PubLibTrend/1', trendOnly.key === 'local/PubLibTrend/1' && trendOnly.matched === 'fallback', trendOnly.key)
  const candleOnly = libsOnly.libraries.find((l) => l.libName === 'PubLibCandleTrend')!
  check('sans Main : PubLibCandleTrend retrouvée via l\'import de PubLibSwing', candleOnly.key === 'PiracyChecker/PubLibCandleTrend/2')
}

/* ── 3. garde anti-ambiguïté : deux fichiers de même nom → pas d'alias ── */
console.log('\n[3] Garde anti-ambiguïté (deux « Utils » distincts)')
{
  const libA = `//@version=6\nlibrary("Utils")\nexport a() => 1\n`
  const libB = `//@version=6\nlibrary("Utils")\nexport b() => 2\n`
  const consumer = `//@version=6\nindicator("X")\nimport alice/Utils/1 as a\nimport bob/Utils/1 as b\nplot(a.a())`
  const derived = deriveLibraryKeys([
    { name: 'consumer.pine', source: consumer },
    { name: 'utilsA.pine', source: libA },
    { name: 'utilsB.pine', source: libB },
  ])
  const utils = derived.libraries.filter((l) => l.libName === 'Utils')
  check('les deux fichiers Utils restent distincts (pas de fusion d\'alias)',
    utils.length === 2 && utils.every((u) => u.aliases.length === 0),
    utils.map((u) => `${u.key}[aliases=${u.aliases.length}]`).join(' · '))
  check('appariement déterministe : utilsA→alice/Utils/1 · utilsB→bob/Utils/1',
    utils.some((u) => u.file.name === 'utilsA.pine' && u.key === 'alice/Utils/1') &&
    utils.some((u) => u.file.name === 'utilsB.pine' && u.key === 'bob/Utils/1'),
    utils.map((u) => `${u.file.name}→${u.key}`).join(' · '))
}

/* ── 3b. import en deux temps : libs d'abord, Main ensuite ── */
console.log('\n[3b] Import en deux temps (libs puis Main) — complétion d\'alias')
{
  cleanup()
  // 1. import des librairies seules (sans Main.pine)
  const r1 = importLibraryBundle(packFiles.slice(1))
  check('étape 1 (libs seules) : 4 enregistrées, 0 manquante entre elles',
    r1.registered.length === 4 && r1.missing.length === 0,
    `clé PubLibSwing = ${r1.registered.find((x) => x.libName === 'PubLibSwing')?.keys.join(' + ')}`)
  // 2. import du Main SEUL → ses imports PiracyChecker/… doivent être complétés
  //    en alias des librairies déjà enregistrées (même nom, même version).
  const r2 = importLibraryBundle([packFiles[0]])
  check('étape 2 (Main seul) : 0 librairie fichier, 3 alias complétés',
    r2.registered.length === 0 && r2.aliased.length === 3,
    r2.aliased.map((a) => `${a.path} ← ${a.from}`).join(' · '))
  check('étape 2 : AUCUNE manquante après complétion', r2.missing.length === 0, r2.missing.map((m) => m.path).join(','))
  check('Main proposé comme script principal', r2.mainScripts.length === 1)
  cleanup()
}

/* ── 4. dépendances manquantes : détection transitoire AVANT import ── */
console.log('\n[4] Dépendances manquantes (computeMissingLibraries)')
{
  cleanup()
  const missing = computeMissingLibraries(mainSrc)
  const paths = missing.map((m) => m.path)
  check('les 3 imports directs manquent', paths.length === 3, paths.join(','))
  check('PiracyChecker/PubLibSwing/3 listée', paths.includes('PiracyChecker/PubLibSwing/3'))

  // Enregistre UNIQUEMENT PubLibSwing → PubLibTrend exige theEccentricTrader/…
  addLibrary('PiracyChecker/PubLibSwing/3', swingSrc)
  const missing2 = computeMissingLibraries(mainSrc)
  check('PubLibSwing résolue → reste 2 manquantes', missing2.length === 2, missing2.map((m) => m.path).join(','))
  // PubLibCandleTrend (dépendance transitive de PubLibSwing) fournie par le SHIM intégré
  check('PiracyChecker/PubLibCandleTrend/2 résolue par le shim intégré',
    !missing2.some((m) => m.path === 'PiracyChecker/PubLibCandleTrend/2'))
  check('le shim intégré est listé (non supprimable)',
    listLibraries().some((l) => l.key === 'PiracyChecker/PubLibCandleTrend/2' && l.builtin === true))
  cleanup()
}

/* ── 5. import du bundle complet : alias + remplacement du shim ── */
console.log('\n[5] Import de bundle (importLibraryBundle)')
{
  cleanup()
  const report = importLibraryBundle(packFiles)

  check('4 librairies enregistrées', report.registered.length === 4, report.registered.map((r) => r.libName).join(','))
  const swingReg = report.registered.find((r) => r.libName === 'PubLibSwing')!
  check('PubLibSwing enregistrée sous 2 clés (primaire + alias)',
    swingReg.keys.length === 2 && swingReg.keys.includes('PiracyChecker/PubLibSwing/3') && swingReg.keys.includes('theEccentricTrader/PubLibSwing/3'),
    swingReg.keys.join(' · '))
  check('shim intégré REMPLACÉ par la source officielle du pack',
    report.registered.find((r) => r.libName === 'PubLibCandleTrend')?.replacedBuiltin === true)
  check('Main.pine proposé comme script principal',
    report.mainScripts.length === 1 && report.mainScripts[0].file.source === mainSrc)
  check('AUCUNE dépendance manquante après import complet', report.missing.length === 0,
    report.missing.map((m) => m.path).join(','))
  check('getLibrarySource via la clé alias',
    getLibrarySource('theEccentricTrader/PubLibSwing/3') === swingSrc)
  check('getLibrarySource via la clé primaire', getLibrarySource('PiracyChecker/PubLibSwing/3') === swingSrc)

  const reg = asPinerRegistry()
  const keys = reg.map((r) => r.key)
  check('registre piner : 5 entrées (4 libs + 1 alias)', reg.length === 5, keys.join(' · '))
  check('registre piner : aucune clé dupliquée', new Set(keys).size === keys.length)

  // persistance localStorage
  const stored = JSON.parse(backing.get('pine-libraries-v1') ?? '[]')
  check('persistance localStorage : 5 clés', Array.isArray(stored) && stored.length === 5)

  // re-import idempotent → mise à jour, pas d'erreur
  const report2 = importLibraryBundle(packFiles)
  check('ré-import : mise à jour signalée', report2.registered.every((r) => r.replacedUser === true))
  check('ré-import : toujours 0 manquante', report2.missing.length === 0)
}

/* ── 6. suppression + recomputation des manquantes ── */
console.log('\n[6] Suppression de librairie')
{
  removeLibrary('PiracyChecker/PubLibTrend/3')
  const missing = computeMissingLibraries(mainSrc)
  check('PubLibTrend supprimée → de nouveau manquante', missing.some((m) => m.path === 'PiracyChecker/PubLibTrend/3'))
  // le shim intégré ne peut pas être supprimé
  removeLibrary('PiracyChecker/PubLibCandleTrend/2')
  check('le shim intégré survit à removeLibrary', getLibrarySource('PiracyChecker/PubLibCandleTrend/2') !== undefined)
}

/* ── 7. zip-reader : lecture de l'archive réelle ── */
console.log('\n[7] ZIP reader (PiracyChecker.zip réel)')
{
  cleanup()
  const { readZipEntries } = await import('../src/lib/zip-reader')
  const zipBytes = readFileSync('/home/z/my-project/upload/PiracyChecker.zip')
  const entries = await readZipEntries(new Uint8Array(zipBytes))
  const pineEntries = entries.filter((e) => !e.binary && /\.pine$/i.test(e.name))
  check('5 fichiers .pine extraits du ZIP', pineEntries.length === 5, pineEntries.map((e) => e.name.split('/').pop()).join(','))
  check('le Main extrait est identique à la source disque',
    pineEntries.find((e) => e.name.endsWith('Main.pine'))?.text === mainSrc)
  check('PubLibTrend extrait intact (34 Ko)', pineEntries.find((e) => e.name.endsWith('PubLibTrend.pine'))?.text === trendSrc)

  // import via les entrées du ZIP → même résultat que depuis le disque
  const report = importLibraryBundle(pineEntries.map((e) => ({ name: e.name, source: e.text })))
  check('import ZIP : 4 librairies + 1 main + 0 manquante',
    report.registered.length === 4 && report.mainScripts.length === 1 && report.missing.length === 0)
}

/* ── 8. compilation piner end-to-end avec le registre issu du bundle ── */
console.log('\n[8] Compilation piner du pack complet (via asPinerRegistry)')
{
  const { compileAsync } = await import('@heyphat/piner')
  try {
    const compiled = await compileAsync(mainSrc, { libraries: asPinerRegistry() })
    check('compilation Main.pine + 4 libs (+alias) OK', true, `${compiled.metadata.title} · ${compiled.metadata.inputs.length} inputs`)
  } catch (err: any) {
    check('compilation Main.pine + 4 libs (+alias) OK', false, err?.message?.slice(0, 300))
  }

  // registre SANS l'alias → l'import transitive de PubLibTrend doit échouer
  // avec un message citant la librairie importeuse (piner attribue la chaîne).
  removeLibrary('theEccentricTrader/PubLibSwing/3')
  try {
    await compileAsync(mainSrc, { libraries: asPinerRegistry() })
    check('sans alias : la compilation échoue (attendu)', false, 'a compilé alors que theEccentricTrader/PubLibSwing/3 manque')
  } catch (err: any) {
    const msg = String(err?.message ?? '')
    check('sans alias : la compilation échoue (attendu)', msg.includes('theEccentricTrader/PubLibSwing/3'), msg.slice(0, 160).replace(/\n/g, ' '))
  }
  cleanup()
}

console.log(`\n═══ RÉSULTAT : ${passed} ✓ · ${failures} ✗ ═══`)
process.exit(failures > 0 ? 1 : 0)
}

main().catch((err) => { console.error(err); process.exit(1) })
