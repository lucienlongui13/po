#!/usr/bin/env python3
"""Assemblage de wavescope_ict_v4.pine à partir du moteur v3 (éprouvé)
   + corrections ciblées (bug ZigZag, couleurs, réglages inline, tableau)."""
import sys

SRC = "/home/z/my-project/download/wavescope_ict_v3.pine"
DST = "/home/z/my-project/download/wavescope_ict_v4.pine"
HDR = "/home/z/my-project/scripts/v4_block_header.txt"
INP = "/home/z/my-project/scripts/v4_block_inputs.txt"
TBL = "/home/z/my-project/scripts/v4_block_table.txt"

with open(SRC, encoding="utf-8") as f:
    lines = f.readlines()
with open(HDR, encoding="utf-8") as f:
    header = f.read()
with open(INP, encoding="utf-8") as f:
    inputs = f.read()
with open(TBL, encoding="utf-8") as f:
    table = f.read()

errors = []

# ── Garde-fous sur les ancres de lignes ──────────────────────────────
assert lines[1].startswith('indicator("WaveScope — ICT / SMC v3'), "ancre L2 invalide"
assert lines[36].startswith("// ───────────────────────── GROUPES"), f"ancre L37 invalide: {lines[36][:60]}"
assert "displacementMult = input.float(1.5," in lines[176], f"ancre L177 invalide: {lines[176][:60]}"
# La ligne 36 (index 35) doit rester une ligne vide avant GROUPES
assert lines[35].strip() == "", "L36 devrait être vide"

# ── 1) Remplacement header (lignes 2-35) + inputs (lignes 37-177) ────
new_lines = lines[:1]                      # garde //@version=6
new_lines += header.splitlines(keepends=True)
new_lines += ["\n"]                        # ligne vide après le header
new_lines += inputs.splitlines(keepends=True)
new_lines += lines[177:]                   # tout ce qui suit les inputs (depuis "// TYPES" environ)

content = "".join(new_lines)

def replace_once(old: str, new: str, label: str, expected: int = 1):
    global content, errors
    n = content.count(old)
    if n != expected:
        errors.append(f"{label}: {n} occurrence(s) au lieu de {expected}")
        return
    content = content.replace(old, new)

# ── 2) f_passes_filter : mode Auto (×ATR) en tête ────────────────────
replace_once(
    'float thresh = devMode == "Pourcentage (%)" ? math.abs(prevPrice) * devInput / 100.0 : devMode == "Points" ? devInput : atrRef * devInput',
    'float thresh = devMode == "Auto (×ATR) — recommandé" ? atrRef * devInput : devMode == "Pourcentage (%)" ? math.abs(prevPrice) * devInput / 100.0 : devInput',
    "f_passes_filter mode Auto")

# ── 3) Lignes de cassure BOS/CHoCH : violet → orange (famille événements)
replace_once(
    'color=color.new(levelColor, 5), style=f_line_style(breakLineStyle), width=breakWidth)',
    'color=color.new(chochColor, 25), style=f_line_style(breakLineStyle), width=breakWidth)',
    "couleur lignes de cassure", expected=2)

# ── 4) Ligne d'équilibre 50 % : orange → violet (famille niveaux) ────
replace_once(
    'extend=extend.right, color=color.new(chochColor, 25), style=line.style_dashed)',
    'extend=extend.right, color=color.new(levelColor, 40), style=line.style_dashed)',
    "couleur ligne équilibre")

# ── 5) Jambe en cours : âge max paramétrable ─────────────────────────
replace_once(
    '(bar_index - s.devAnchorBar) > 300',
    '(bar_index - s.devAnchorBar) > maxDevelopingBars',
    "âge max jambe en cours")

# ── 6) Tableau : dimensions élargies (ZigZag row + légende 12 familles)
replace_once(
    'table.new(f_panel_pos(panelPositionInput), 2, 22, border_width=0, frame_width=0)',
    'table.new(f_panel_pos(panelPositionInput), 2, 26, border_width=0, frame_width=0)',
    "table.new dims")
replace_once(
    'table.clear(statusPanel, 0, 0, 1, 21)',
    'table.clear(statusPanel, 0, 0, 1, 25)',
    "table.clear dims")

# ── 7) Bloc tableau final : remplacé (titre v4 + row ZigZag + légende) ─
anchor = "        int r = 0\n"
n_anchor = content.count(anchor)
if n_anchor != 1:
    errors.append(f"ancre table 'int r = 0': {n_anchor} occurrence(s)")
else:
    idx = content.find(anchor)
    content = content[:idx] + table

if errors:
    print("ÉCHEC — aucune écriture :")
    for e in errors:
        print("  ✗", e)
    sys.exit(1)

with open(DST, "w", encoding="utf-8") as f:
    f.write(content)

n_lines = content.count("\n")
print(f"✓ Écrit : {DST}")
print(f"  Lignes : {n_lines}")
print(f"  Inputs : {content.count('input.')}")
print(f"  Réfs mode Auto : {content.count('Auto (×ATR) — recommandé')}")
print(f"  Réfs maxDevelopingBars : {content.count('maxDevelopingBars')}")
print(f"  WAVESCOPE ICT v4 (titre) : {content.count('WAVESCOPE ICT v4')}")
