import { runPineScript } from '../src/lib/pine-engine.ts'
import { readFileSync } from 'node:fs'

function makeCandles(n, seed0) {
  const bars = []
  let price = 1.15
  let seed = seed0
  const rand = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648 }
  for (let i = 0; i < n; i++) {
    const drift = (rand() - 0.5) * 0.002
    const open = price, close = open + drift
    const high = Math.max(open, close) + rand() * 0.0008
    const low = Math.min(open, close) - rand() * 0.0008
    bars.push({ time: 1_700_000_000 + i * 60, open, high, low, close, volume: 100 })
    price = close
  }
  return bars
}

const source = readFileSync('TradingView_pine_scripts_samples/Qasimodo.pine', 'utf8')
for (const n of [301, 500, 800]) {
  const res = await runPineScript(source, makeCandles(n, 42), { symbol: 'EURUSD_otc', timeframe: '1' })
  if (res.ok) {
    const types = {}
    for (const d of res.result.drawings) types[d.kind] = (types[d.kind] ?? 0) + 1
    console.log(`${n} bars: drawings=${JSON.stringify(types)} strategy=${res.result.strategy ? 'net=' + res.result.strategy.netProfit.toFixed(2) + ' trades=' + res.result.strategy.closedTrades.length : 'n/a'}`)
  } else console.log(`${n} bars: ${res.error.message.slice(0, 60)}`)
}
