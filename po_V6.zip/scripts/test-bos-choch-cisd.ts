/**
 * test-bos-choch-cisd.ts — Validation de la stratégie Auto Trade
 * « BOS, CHoCH & CISD » (port du pack Pine de PiracyChecker).
 *
 * PARTIE A — sémantique du moteur (unitaire) :
 *   détection des swings (sh/sl), prix de swing (shp/slp), tendances
 *   (ut/dt), les 6 événements, sécurité na, exclusivité gc/rc,
 *   empilement des labels, évaluateur + toggles, réglages par défaut.
 *
 * PARTIE B — VALIDATION CROISÉE contre le VRAI pack Pine :
 *   le pack (Main.pine + 4 librairies) est exécuté par piner via le pont
 *   applicatif (runPineScript + importLibraryBundle) sur le dataset
 *   EURUSD M1 capturé. Chaque label et chaque ligne produit par le port
 *   TypeScript doit correspondre EXACTEMENT (position, texte, couleur,
 *   barres d'extrémité) aux drawings du pack Pine — le GC du pack
 *   (80 labels/famille, 80 lignes d'événement/famille, 50 lignes de
 *   tendance/sens) est appliqué des deux côtés.
 *
 * Exécution : npx tsx scripts/test-bos-choch-cisd.ts
 */
import { readFileSync } from 'node:fs'

/* ── shim localStorage AVANT tout import de pine-libraries/pine-engine ── */
const backing = new Map<string, string>()
;(globalThis as any).window = {
  localStorage: {
    getItem: (k: string) => backing.get(k) ?? null,
    setItem: (k: string, v: string) => { backing.set(k, String(v)) },
    removeItem: (k: string) => { backing.delete(k) },
  },
}

import {
  computeBosChochCisd,
  computeBosChochCisdVisuals,
  evaluateBosChochCisd,
  eventToggleKey,
  BOS_CHOCH_CISD_DEFAULT_SETTINGS,
  PACK_LABELS_PER_FAMILY,
  PACK_EVENT_LINES_PER_FAMILY,
  PACK_TREND_LINES_PER_KIND,
  TV_GREEN, TV_RED, TV_ORANGE, TV_BLUE, TV_WHITE,
  type BosChochCisdCandle,
} from '../shared/bos-choch-cisd'

let failures = 0
let passed = 0
const check = (name: string, cond: boolean, detail = '') => {
  if (!cond) { failures++; console.error(`  ✗ ${name} ${detail}`) }
  else { passed++; console.log(`  ✓ ${name}${detail ? ' — ' + detail : ''}`) }
}

/* ── helpers bougies synthétiques ── */
let t = 1_700_000_000_000
const mk = (open: number, close: number, high: number, low: number): BosChochCisdCandle => {
  t += 60_000
  return { time: t, open, close, high, low, volume: 100 }
}

/* ═══════════════════════ PARTIE A — unitaire ═══════════════════════ */

function partA() {
  console.log('══ PARTIE A — sémantique du moteur ══\n')

  /* ── A1. swings : sh = verte puis rouge ; sl = rouge puis verte ── */
  console.log('[A1] Détection des swings (sh/sl)')
  {
    const candles = [
      mk(10, 11, 11.5, 9.5),   // verte
      mk(11, 10, 11.2, 9.8),   // rouge → sh à la barre 1
      mk(10, 10.5, 10.8, 9.6), // verte → sl à la barre 2
      mk(10.5, 10.2, 10.9, 10),// rouge → sh à la barre 3
      mk(10.2, 10.8, 11, 10.1),// verte → sl à la barre 4
    ]
    const res = computeBosChochCisd(candles)
    /* sh à barre 1 : max(high1=11.2, high0=11.5) = 11.5 (prend la barre 0)
     * sh à barre 3 : max(high3=10.9, high2=10.8) = 10.9 (prend la barre 3)
     * sl à barre 2 : min(low2=9.6, low1=9.8) = 9.6 (barre 2)
     * sl à barre 4 : min(low4=10.1, low3=10) = 10 (barre 3) */
    check('2 swing highs détectés (prix)', res.swingHighPrice === 10.9 && res.swingHighPrice1 === 11.5,
      `shp(0)=${res.swingHighPrice} shp(1)=${res.swingHighPrice1}`)
    check('2 swing lows détectés (prix)', res.swingLowPrice === 10 && res.swingLowPrice1 === 9.6,
      `slp(0)=${res.swingLowPrice} slp(1)=${res.swingLowPrice1}`)
    /* ut = slp(0) > slp(1) = 10 > 9.6 ; dt = shp(0) < shp(1) = 10.9 < 11.5
     * → les deux conditions structurelles peuvent coexister. */
    check('tendances finales : ut ET dt (série courte)', res.uptrend && res.downtrend,
      `ut=${res.uptrend} dt=${res.downtrend}`)
  }

  /* ── A2. événements BOS sur série directionnelle ── */
  console.log('\n[A2] Événements BOS Up / BOS Down')
  {
    /* Construit : swing low ascendants (ut), puis cassure du swing high. */
    const candles: BosChochCisdCandle[] = [
      // formation du swing high sh0=12 (verte 0, rouge 1)
      mk(10, 10.8, 11, 9.9),   // 0 verte
      mk(10.8, 10.2, 12, 10.1),// 1 rouge → sh(1)=12 (bar 0 high=11 vs bar1 high=12 → 12@bar1)
      mk(10.2, 10.9, 11.1, 10),// 2 verte → sl(2)=10 (min(10,10.1))
      mk(10.9, 10.4, 11.2, 10.2),// 3 rouge
      mk(10.4, 10.6, 10.7, 10.3),// 4 verte → sl(4)=10.2 (min(10.3,10.2)@bar3)
      // sl(2)=10 < sl(4)=10.2 → uptrend dès la barre 4
      // cassure : close > shp(0)=12, close[1] < 12
      mk(10.6, 12.5, 12.6, 10.5), // 5 verte : close 12.5 > 12, prev 10.6 < 12 → BOS Up + CISD Up
    ]
    const res = computeBosChochCisd(candles)
    const bar5 = res.events.filter((e) => e.barIndex === 5)
    check('BOS Up + CISD Up sur la barre de cassure',
      bar5.some((e) => e.label === 'BOS Up') && bar5.some((e) => e.label === 'CISD Up'),
      bar5.map((e) => e.label).join(' + '))
    const bos = bar5.find((e) => e.label === 'BOS Up')!
    /* barre 3 rouge après verte → sh(3) = max(h3=11.2, h2=11.1) = 11.2 @ bar 3 :
     * le swing high LE PLUS RÉCENT (pas le plus haut) est cassé. */
    check('ligne d\'événement BOS : du swing (bar 3) vers la barre 5 au prix 11.2',
      bos.lineFromBarIndex === 3 && bos.linePrice === 11.2,
      `from=${bos.lineFromBarIndex} price=${bos.linePrice}`)
    /* sl(2)=10 @ bar2 ; sl(4)=10.2 @ bar3 → ligne verte bar2→bar3 */
    check('ligne de tendance BOS Up : swing lows bar2→bar3 (10→10.2, vert)',
      bos.trendLine != null && bos.trendLine.fromBarIndex === 2 && bos.trendLine.toBarIndex === 3 &&
      bos.trendLine.fromPrice === 10 && bos.trendLine.toPrice === 10.2 && bos.trendLine.kind === 'uptrend',
      bos.trendLine ? `${bos.trendLine.fromBarIndex}→${bos.trendLine.toBarIndex} @ ${bos.trendLine.fromPrice}→${bos.trendLine.toPrice}` : 'absente')
  }

  /* ── A3. CHoCH : cassure contre-tendance ── */
  console.log('\n[A3] CHoCH Up (retournement en downtrend)')
  {
    const candles: BosChochCisdCandle[] = [
      // downtrend : sh0 < sh1
      mk(20, 20.5, 21, 19.9),  // 0 verte
      mk(20.5, 20, 21.5, 19.8),// 1 rouge → sh(1)=21.5
      mk(20, 20.3, 20.6, 19.5),// 2 verte → sl(2)=19.5
      mk(20.3, 19.9, 20.4, 19.7),// 3 rouge → sh(3)=20.6 (max(20.6,20.4))
      // dt : shp(0)=20.6 < shp(1)=21.5 ✓
      // CHoCH Up : close > 20.6, close < shp(1)=21.5, close[1] < 20.6, verte
      mk(19.9, 20.9, 21, 19.85), // 4 verte → close 20.9 ∈ (20.6, 21.5), prev 19.9 < 20.6
    ]
    const res = computeBosChochCisd(candles)
    const bar4 = res.events.filter((e) => e.barIndex === 4)
    /* sl(2)=19.5 < sl(4)=19.7 → ut VRAI aussi → BOS Up se déclenche ÉGALEMENT
     * (la série présente les deux structures) — le CHoCH reste présent. */
    check('CHoCH Up présent sur la barre 4', bar4.some((e) => e.label === 'CHoCH Up'),
      bar4.map((e) => e.label).join(' + '))
    const choch = bar4.find((e) => e.label === 'CHoCH Up')!
    check('ligne de tendance CHoCH Up : swing highs en ROUGE (downtrend)',
      choch.trendLine != null && choch.trendLine.kind === 'downtrend',
      choch.trendLine?.kind ?? 'absente')
  }

  /* ── A4. sécurité na : aucune comparaison ne déclenche ── */
  console.log('\n[A4] Sécurité na (aucun swing → aucun événement)')
  {
    const allGreen = Array.from({ length: 10 }, (_, i) => mk(10 + i * 0.1, 10.2 + i * 0.1, 10.5 + i * 0.1, 9.9 + i * 0.1))
    const res = computeBosChochCisd(allGreen)
    check('série uniformément verte → 0 swing, 0 événement', res.events.length === 0 && res.swingHighPrice == null,
      `events=${res.events.length}`)
  }

  /* ── A5. exclusivité gc/rc : jamais UP et DOWN sur la même bougie ── */
  console.log('\n[A5] Exclusivité UP/DOWN (gc/rc)')
  {
    const candles: BosChochCisdCandle[] = []
    let base = 10
    for (let i = 0; i < 120; i++) {
      const wiggle = Math.sin(i / 3) * 1.2 + Math.sin(i / 7) * 2
      const open = base + wiggle * 0.1
      const close = open + (i % 2 === 0 ? 0.6 : -0.55) + Math.cos(i / 2) * 0.2
      candles.push(mk(open, close, Math.max(open, close) + 0.4, Math.min(open, close) - 0.35))
      base += Math.sin(i / 9) * 0.15
    }
    const res = computeBosChochCisd(candles)
    let conflicted = 0
    const perBar = new Map<number, Set<string>>()
    for (const e of res.events) {
      const s = perBar.get(e.barIndex) ?? new Set<string>()
      s.add(e.dir)
      perBar.set(e.barIndex, s)
    }
    for (const [, dirs] of perBar) if (dirs.has('up') && dirs.has('down')) conflicted++
    check('aucune bougie avec événements up ET down', conflicted === 0, `conflits=${conflicted}, events=${res.events.length}`)
    check('série riche → événements produits', res.events.length > 10, `${res.events.length} événements`)
  }

  /* ── A6. empilement : 2 événements up sur la même bougie ── */
  console.log('\n[A6] Empilement des labels (règles du pack)')
  {
    const candles: BosChochCisdCandle[] = [
      mk(10, 10.8, 11, 9.9),    // 0 verte
      mk(10.8, 10.2, 12, 10.1), // 1 rouge → sh(1)=12
      mk(10.2, 10.9, 11.1, 10), // 2 verte → sl(2)=10
      mk(10.9, 10.4, 11.2, 10.2), // 3 rouge
      mk(10.4, 10.6, 10.7, 10.3), // 4 verte → sl(4)=10.2 → uptrend
      mk(10.6, 12.5, 12.6, 10.5), // 5 verte : BOS Up + CISD Up (2 labels empilés)
    ]
    const res = computeBosChochCisd(candles)
    const bar5 = res.events.filter((e) => e.barIndex === 5)
    check('2 événements up sur la barre 5', bar5.length === 2, bar5.map((e) => e.label).join(' + '))
    const ys = bar5.map((e) => e.labelY).sort((a, b) => b - a)
    check('labels empilés : le 2e est plus bas que le 1er (pile below)', ys[0] > ys[1] && ys[0] !== ys[1],
      `y=${ys.map((v) => v.toFixed(4)).join(' > ')}`)
  }

  /* ── A7. évaluateur : direction, toggles, raison ── */
  console.log('\n[A7] Évaluateur de trading (toggles + direction)')
  {
    const candles: BosChochCisdCandle[] = [
      mk(10, 10.8, 11, 9.9),
      mk(10.8, 10.2, 12, 10.1),
      mk(10.2, 10.9, 11.1, 10),
      mk(10.9, 10.4, 11.2, 10.2),
      mk(10.4, 10.6, 10.7, 10.3),
      mk(10.6, 12.5, 12.6, 10.5),
    ]
    const sig = evaluateBosChochCisd(candles)
    check('cassure haussière → CALL', sig.action === 'CALL', sig.action)
    check('confiance = BOS (0.85)', Math.abs(sig.confidence - 0.85) < 1e-9, String(sig.confidence))
    check('événements listés (BOS Up + CISD Up)', sig.events.includes('BOS Up') && sig.events.includes('CISD Up'), sig.events.join(', '))
    check('raison cite la cassure', sig.reason.includes('BOS Up'), sig.reason.slice(0, 60))
    check('candleTime = bougie évaluée', sig.candleTime === candles[candles.length - 1].time)

    /* toggles OFF → HOLD */
    const off = evaluateBosChochCisd(candles, { bosUpAlert: false, cisdUpAlert: false })
    check('toggles OFF → HOLD avec message explicite', off.action === 'HOLD' && off.reason.includes('OFF'), off.reason.slice(0, 70))

    /* pas d'événement sur la dernière bougie → HOLD structurel */
    const quiet = evaluateBosChochCisd([...candles, mk(12.5, 12.4, 12.7, 12.2)])
    check('bougie sans événement → HOLD', quiet.action === 'HOLD' && quiet.reason.includes('swing'), quiet.reason.slice(0, 60))

    /* série vide */
    check('série vide → HOLD propre', evaluateBosChochCisd([]).action === 'HOLD')
  }

  /* ── A8. réglages par défaut = pack (couleurs) ── */
  console.log('\n[A8] Réglages par défaut (pack Pine)')
  {
    const d = BOS_CHOCH_CISD_DEFAULT_SETTINGS
    check('couleurs labels = pack (vert/rouge/orange/orange/bleu/bleu)',
      d.bosUpLabelColour === TV_GREEN && d.bosDownLabelColour === TV_RED &&
      d.chochUpLabelColour === TV_ORANGE && d.chochDownLabelColour === TV_ORANGE &&
      d.cisdUpLabelColour === TV_BLUE && d.cisdDownLabelColour === TV_BLUE)
    check('texte blanc, taille Normal', d.textColour === TV_WHITE && d.labelSize === 'Normal')
    check('toggles ON (stratégie fonctionnelle dès la sélection)',
      d.bosUpAlert && d.bosDownAlert && d.chochUpAlert && d.chochDownAlert && d.cisdUpAlert && d.cisdDownAlert)
    check('eventToggleKey — mapping complet', eventToggleKey({ kind: 'bos', dir: 'up' }) === 'bosUpAlert' &&
      eventToggleKey({ kind: 'choch', dir: 'down' }) === 'chochDownAlert' &&
      eventToggleKey({ kind: 'cisd', dir: 'up' }) === 'cisdUpAlert')
  }

  /* ── A9. visuels : limites GC du pack ── */
  console.log('\n[A9] Visuels — limites GC du pack (80/80/50)')
  {
    const candles: BosChochCisdCandle[] = []
    let base = 10
    for (let i = 0; i < 600; i++) {
      const wiggle = Math.sin(i / 3) * 1.2 + Math.sin(i / 7) * 2
      const open = base + wiggle * 0.1
      const close = open + (i % 2 === 0 ? 0.6 : -0.55) + Math.cos(i / 2) * 0.2
      candles.push(mk(open, close, Math.max(open, close) + 0.4, Math.min(open, close) - 0.35))
      base += Math.sin(i / 9) * 0.15
    }
    const v = computeBosChochCisdVisuals(candles)
    const perFamily = new Map<string, number>()
    for (const l of v.labels) perFamily.set(l.kind, (perFamily.get(l.kind) ?? 0) + 1)
    check('labels plafonnés à 80 par famille',
      [...perFamily.values()].every((c) => c <= PACK_LABELS_PER_FAMILY) && v.labels.length >= 90,
      JSON.stringify([...perFamily.entries()]))
    check('lignes d\'événement = labels (mêmes familles)', v.eventLines.length === v.labels.length)
    const trendKinds = new Map<string, number>()
    for (const tl of v.trendLines) trendKinds.set(tl.kind, (trendKinds.get(tl.kind) ?? 0) + 1)
    check('lignes de tendance plafonnées à 50 par sens',
      [...trendKinds.values()].every((c) => c <= PACK_TREND_LINES_PER_KIND),
      JSON.stringify([...trendKinds.entries()]))
    check('couleur de famille appliquée aux labels',
      v.labels.every((l) => typeof l.familyColour === 'string' && l.familyColour.startsWith('#')))
  }
}

/* ═══════════ PARTIE B — validation croisée vs pack Pine réel ═══════════ */

async function partB() {
  console.log('\n══ PARTIE B — validation croisée vs VRAI pack Pine (piner) ══\n')

  const { importLibraryBundle, removeLibrary, listLibraries } = await import('../src/lib/pine-libraries')
  const pineEngine = await import('../src/lib/pine-engine')
  const runPineScript = pineEngine.runPineScript
  const deriveMintick = pineEngine.deriveMintick

  /* ── sources du pack + dataset ── */
  const base = '/home/z/my-project/upload/pine_full_pack_extracted/pine_full_pack'
  const rd = (p: string) => readFileSync(`${base}/${p}`, 'utf8')
  const mainSrc = rd('Main.pine')
  const packFiles = [
    { name: 'Main.pine', source: mainSrc },
    { name: 'PubLibSwing.pine', source: rd('libs/PubLibSwing.pine') },
    { name: 'PubLibTrend.pine', source: rd('libs/PubLibTrend.pine') },
    { name: 'PubLibUtility.pine', source: rd('libs/PubLibUtility.pine') },
    { name: 'PubLibCandleTrend.pine', source: rd('libs/PubLibCandleTrend.pine') },
  ]
  const raw = JSON.parse(readFileSync('/home/z/my-project/scripts/dataset-eurusd-m1.json', 'utf8'))
  const candles: BosChochCisdCandle[] = (raw.candles ?? raw).map((c: any) => ({
    time: Number(c.time) * 1000,
    open: Number(c.open), high: Number(c.high), low: Number(c.low), close: Number(c.close),
    volume: Number(c.volume) || 0,
  }))
  console.log(`dataset : ${candles.length} bougies M1\n`)

  /* mintick IDENTIQUE des deux côtés (runPineScript le reçoit explicitement) */
  const mintick = deriveMintick(candles as any)
  check('mintick dérivé du dataset', mintick != null && mintick > 0, String(mintick))

  /* ── B1. exécution du VRAI pack via piner ── */
  console.log('[B1] Exécution du pack Pine par piner')
  for (const lib of listLibraries()) removeLibrary(lib.key)
  const report = importLibraryBundle(packFiles)
  pineEngine.invalidatePineCaches()
  check('import du pack : 4 librairies + 0 manquante', report.registered.length === 4 && report.missing.length === 0)

  const OPTS = { symbol: 'EURUSD_otc', timeframe: '1', mintick } as const
  const res = await runPineScript(mainSrc, candles as any, OPTS)
  check('exécution piner OK', res.ok, res.ok ? '' : String((res as any).error?.message).slice(0, 120))
  if (!res.ok) return
  const drawings = res.result.drawings
  const pineLabels = drawings.filter((d: any) => d.kind === 'label') as any[]
  const pineLines = drawings.filter((d: any) => d.kind === 'line') as any[]
  console.log(`   piner : ${pineLabels.length} labels, ${pineLines.length} lignes`)

  /* index temps → barre — piner résout les x en (temps d'entrée × 1000)
   * (xloc.bar_time) : nos bougies de test sont en ms → x piner en µs. */
  const timeToBar = new Map<number, number>()
  candles.forEach((c, i) => timeToBar.set(Number(c.time), i))
  const barOfTime = (rawX: number): number => {
    const x = rawX > 1e13 ? rawX / 1000 : rawX
    const exact = timeToBar.get(x)
    if (exact != null) return exact
    /* le swing peut porter la barre précédente : recherche dichotomique */
    let lo = 0, hi = candles.length - 1
    while (lo < hi) { const mid = (lo + hi) >> 1; if (candles[mid].time < x) lo = mid + 1; else hi = mid }
    return lo
  }

  /* ── B2. mon port (visuels, MÊME mintick) ── */
  const visuals = computeBosChochCisdVisuals(candles, {}, { mintick })
  const myLabels = visuals.labels
  const myEventLines = visuals.eventLines
  const myTrendLines = visuals.trendLines
  console.log(`   port TS : ${myLabels.length} labels, ${myEventLines.length} lignes événement + ${myTrendLines.length} lignes tendance`)

  /* ── B3. labels : multiset (barre, texte) exact ── */
  console.log('\n[B3] Labels — correspondance exacte (barre × texte)')
  {
    const key = (bar: number, text: string) => `${bar}|${text}`
    const pineCount = new Map<string, number>()
    for (const l of pineLabels) pineCount.set(key(barOfTime(l.x), String(l.text ?? '')), (pineCount.get(key(barOfTime(l.x), String(l.text ?? ''))) ?? 0) + 1)
    const myCount = new Map<string, number>()
    for (const l of myLabels) myCount.set(key(l.barIndex, l.label), (myCount.get(key(l.barIndex, l.label)) ?? 0) + 1)

    let missing = 0, extra = 0
    for (const [k, c] of pineCount) if ((myCount.get(k) ?? 0) !== c) { missing++; console.error(`     piner sans port : ${k} ×${c} (port ×${myCount.get(k) ?? 0})`) }
    for (const [k, c] of myCount) if ((pineCount.get(k) ?? 0) !== c) { extra++; console.error(`     port sans piner : ${k} ×${c} (piner ×${pineCount.get(k) ?? 0})`) }
    check(`labels identiques (${pineLabels.length} piner vs ${myLabels.length} port)`, missing === 0 && extra === 0)
  }

  /* ── B4. couleurs des labels ── */
  console.log('\n[B4] Couleurs des labels (réglages du pack)')
  {
    const expected: Record<string, string> = {
      'BOS Up': TV_GREEN, 'BOS Down': TV_RED,
      'CHoCH Up': TV_ORANGE, 'CHoCH Down': TV_ORANGE,
      'CISD Up': TV_BLUE, 'CISD Down': TV_BLUE,
    }
    let mismatch = 0, compared = 0
    for (const l of pineLabels) {
      const text = String(l.text ?? '')
      const exp = expected[text]
      if (!exp) continue
      compared++
      const got = String(l.color ?? '').slice(0, 7).toUpperCase()
      if (got !== exp.toUpperCase()) { mismatch++; console.error(`     ${text} : piner=${got} attendu=${exp}`) }
    }
    check(`couleurs conformes (${compared} labels)`, mismatch === 0 && compared > 100)
    /* NOTE piner : dans PubLibUtility, le paramètre `size` de la fonction
     * exportée masque le namespace `size` → size.normal devient na côté
     * piner et le label retombe sur le défaut 'small'. TradingView réel
     * résout le namespace intégré → 'normal'. Le port garde le
     * comportement TradingView ('Normal' → taille normal) ; le check
     * accepte donc la valeur piner (quirk documenté). */
    const textColourOk = pineLabels.every((l) => String(l.textcolor ?? '').slice(0, 7).toUpperCase() === '#FFFFFF')
    const sizeOk = pineLabels.every((l) => ['normal', 'small'].includes(String(l.size ?? '').toLowerCase()))
    check('texte blanc (pack) + taille Normal (quirk piner : small)', textColourOk && sizeOk)
  }

  /* ── B5. position Y des labels (offsets ATR + empilement) ── */
  console.log('\n[B5] Position Y des labels (offsets ATR + piles du pack)')
  {
    const byKeyPine = new Map<string, number[]>()
    for (const l of pineLabels) {
      if (l.y == null) continue
      const k = `${barOfTime(l.x)}|${l.text}`
      const arr = byKeyPine.get(k) ?? []
      arr.push(Number(l.y))
      byKeyPine.set(k, arr)
    }
    const byKeyMine = new Map<string, number[]>()
    for (const l of myLabels) {
      const k = `${l.barIndex}|${l.label}`
      const arr = byKeyMine.get(k) ?? []
      arr.push(l.labelY)
      byKeyMine.set(k, arr)
    }
    let maxDev = 0, compared = 0, bad = 0
    for (const [k, arr] of byKeyPine) {
      const mine = byKeyMine.get(k)
      if (!mine || mine.length !== arr.length) { bad++; continue }
      for (let i = 0; i < arr.length; i++) {
        const dev = Math.abs(arr[i] - mine[i])
        maxDev = Math.max(maxDev, dev)
        compared++
        if (dev > 1e-6) bad++
      }
    }
    check(`positions Y identiques (${compared} comparaisons, écart max=${maxDev.toExponential(2)})`, bad === 0 && compared > 100)
  }

  /* ── B6. lignes : événements (pointillées) + tendances (pleines) ── */
  console.log('\n[B6] Lignes — événements pointillées + tendances pleines')
  {
    const lineKey = (x1: number, y1: number, x2: number, y2: number, colour: string) =>
      `${barOfTime(x1)}→${barOfTime(x2)}@${y1.toFixed(5)}|${colour}`
    const pineEvent = new Map<string, number>()
    const pineTrend = new Map<string, number>()
    for (const l of pineLines) {
      const colour = String(l.color ?? '').slice(0, 7).toUpperCase()
      const k = lineKey(l.x1, Number(l.y1), l.x2, Number(l.y2), colour)
      const dashed = String(l.style ?? '').toLowerCase().includes('dash')
      const target = dashed ? pineEvent : pineTrend
      target.set(k, (target.get(k) ?? 0) + 1)
    }
    const myEvent = new Map<string, number>()
    for (const { event: e } of myEventLines) {
      const k = lineKey(candles[e.lineFromBarIndex].time, e.linePrice, candles[e.barIndex].time, e.linePrice, e.lineColour.toUpperCase())
      myEvent.set(k, (myEvent.get(k) ?? 0) + 1)
    }
    const myTrend = new Map<string, number>()
    for (const tl of myTrendLines) {
      const colour = tl.kind === 'uptrend' ? TV_GREEN : TV_RED
      const k = lineKey(candles[tl.fromBarIndex].time, tl.fromPrice, candles[tl.toBarIndex].time, tl.toPrice, colour.toUpperCase())
      myTrend.set(k, (myTrend.get(k) ?? 0) + 1)
    }

    let diff = 0
    for (const [k, c] of pineEvent) if ((myEvent.get(k) ?? 0) !== c) { diff++; console.error(`     événement piner manquant côté port : ${k} ×${c} vs ${myEvent.get(k) ?? 0}`) }
    for (const [k, c] of myEvent) if ((pineEvent.get(k) ?? 0) !== c) { diff++; console.error(`     événement port manquant côté piner : ${k} ×${c} vs ${pineEvent.get(k) ?? 0}`) }
    check(`lignes d'événement identiques (${pineEvent.size} clés piner / ${myEvent.size} port)`, diff === 0)

    let diffT = 0
    for (const [k, c] of pineTrend) if ((myTrend.get(k) ?? 0) !== c) { diffT++; console.error(`     tendance piner manquante côté port : ${k} ×${c} vs ${myTrend.get(k) ?? 0}`) }
    for (const [k, c] of myTrend) if ((pineTrend.get(k) ?? 0) !== c) { diffT++; console.error(`     tendance port manquante côté piner : ${k} ×${c} vs ${pineTrend.get(k) ?? 0}`) }
    check(`lignes de tendance identiques (${pineTrend.size} clés piner / ${myTrend.size} port)`, diffT === 0)
  }

  /* ── B7. évaluateur sur le dataset : cohérence avec les événements ── */
  console.log('\n[B7] Évaluateur — direction cohérente avec les événements')
  {
    /* re-évaluation bougie par bougie : à chaque événement actif sur la
     * dernière bougie d'un préfixe, l'évaluateur doit donner la bonne
     * direction. */
    const full = computeBosChochCisd(candles, { mintick })
    const evByBar = new Map<number, typeof full.events>()
    for (const e of full.events) {
      const arr = evByBar.get(e.barIndex) ?? []
      arr.push(e)
      evByBar.set(e.barIndex, arr)
    }
    const sample = [...evByBar.keys()].filter((b) => b > 30 && b % 37 === 0).slice(0, 12)
    let okDir = 0, okHold = 0
    for (const bar of sample) {
      const sig = evaluateBosChochCisd(candles.slice(0, bar + 1))
      const evs = evByBar.get(bar) ?? []
      const expectUp = evs.some((e) => e.dir === 'up')
      if (sig.action === (expectUp ? 'CALL' : 'PUT')) okDir++
      /* sans événement sur la dernière bougie → HOLD */
      if (evs.length === 0 && sig.action === 'HOLD') okHold++
    }
    check('directions CALL/PUT cohérentes sur échantillon', okDir === sample.length, `${okDir}/${sample.length}`)
    check('rétro-propagation : evaluateur(work[i..j]) = événement à j',
      sample.every((bar) => {
        const sig = evaluateBosChochCisd(candles.slice(0, bar + 1))
        const evs = evByBar.get(bar) ?? []
        return evs.length === 0 ? sig.action === 'HOLD' : sig.action !== 'HOLD'
      }))
  }

  /* ── B8. overrides d'inputs Pine = réglages du port ── */
  console.log('\n[B8] Parité des réglages (inputs Pine ↔ settings du port)')
  {
    /* couleurs personnalisées appliquées au pack Pine → le port les reflète */
    const custom = {
      bosUpLabelColour: '#00E676', chochDownLabelColour: '#E040FB',
      cisdUpLabelColour: '#FFD700', textColour: '#000000',
      labelSize: 'Huge' as const,
    }
    const schema = await pineEngine.getPineInputSchema(mainSrc)
    const colorInput = schema.inputs?.find((i: any) => i.title?.includes('BOS Up Label Colour'))
    const sizeInput = schema.inputs?.find((i: any) => i.title?.includes('Label Size'))
    check('input couleur BOS Up présent dans le schéma Pine', Boolean(colorInput), colorInput?.title ?? '')
    if (colorInput && sizeInput) {
      const res2 = await runPineScript(mainSrc, candles as any, {
        ...OPTS, inputs: { [colorInput.key]: '#00E676', [sizeInput.key]: 'Huge' },
      })
      check('re-exécution piner avec overrides', res2.ok)
      if (res2.ok) {
        const labels2 = res2.result.drawings.filter((d: any) => d.kind === 'label') as any[]
        const bosGreen = labels2.filter((l) => l.text === 'BOS Up' && String(l.color ?? '').slice(0, 7).toUpperCase() === '#00E676')
        check('override couleur BOS Up appliqué par piner', bosGreen.length > 0, `${bosGreen.length} labels`)
        const v2 = computeBosChochCisdVisuals(candles, custom, { mintick })
        check('port : même override couleur sur les labels BOS Up',
          v2.labels.filter((l) => l.label === 'BOS Up' && l.familyColour === '#00E676').length === bosGreen.length,
          `${v2.labels.filter((l) => l.label === 'BOS Up' && l.familyColour === '#00E676').length} vs ${bosGreen.length}`)
      }
    }
  }
}

async function main() {
  partA()
  await partB()
  console.log(`\n═══ RÉSULTAT : ${passed} ✓ · ${failures} ✗ ═══`)
  process.exit(failures > 0 ? 1 : 0)
}

main().catch((err) => { console.error(err); process.exit(1) })
