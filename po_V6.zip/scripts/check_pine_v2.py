#!/usr/bin/env python3
"""Vérification statique du script Pine v2 (wavescope_ict_v2_conforme.pine)."""
import re
import sys

PATH = "/home/z/my-project/download/wavescope_ict_v2_conforme.pine"

with open(PATH, encoding="utf-8") as f:
    lines = f.readlines()

issues = []
warns = []
ok = []

# 1) Toutes les boucles `for i = 0 to array.size(...) - 1` doivent être précédées
#    d'une garde (if ... > 0 / int sz = array.size(...) + if sz > 0).
loop_re = re.compile(r"^\s*for\s+\w+\s*=\s*0\s+to\s+array\.size\(")
for idx, line in enumerate(lines):
    if loop_re.match(line):
        # Cherche une garde dans les 4 lignes précédentes (non vides)
        context = "".join(lines[max(0, idx - 4):idx + 1])
        if not re.search(r"(>\s*0|>=\s*1|>=\s*2|>=\s*n\b|lookback\s*>=\s*1)", context):
            issues.append(f"L{idx+1}: boucle non gardée → {line.strip()[:80]}")
        else:
            ok.append(f"L{idx+1}: boucle gardée ✓")

# 2) Parenthèses équilibrées par ligne (hors chaînes et commentaires approximé)
def strip_strings_comments(s):
    s = re.sub(r"//[^\n]*", "", s)
    s = re.sub(r'"(?:[^"\\]|\\.)*"', '""', s)
    return s

bad_paren = 0
for idx, line in enumerate(lines):
    if line.strip().startswith("//"):
        continue
    s = strip_strings_comments(line)
    if s.count("(") != s.count(")"):
        # Multi-lignes possibles (peu probable en Pine sur une seule ligne) → warning
        warns.append(f"L{idx+1}: parens ({s.count('(')} vs {s.count(')')}) → {line.strip()[:70]}")
        bad_paren += 1

# 3) Indentation : multiples de 4 espaces
for idx, line in enumerate(lines):
    if not line.strip():
        continue
    m = re.match(r"^( +)\S", line)
    if m and len(m.group(1)) % 4 != 0:
        warns.append(f"L{idx+1}: indentation {len(m.group(1))} espaces (pas multiple de 4)")

# 4) Doublons de déclarations au scope global (colonne 0)
global_decls = {}
for idx, line in enumerate(lines):
    m = re.match(r"^(?:bool|int|float|string|color|label|line|box|var\s+\w+(?:<[^>]*>)?\s+\w+|var\s+(?:bool|int|float|string|color|label|line|box)\s+\w+)\s+(\w+)\s*=", line)
    if not m:
        m2 = re.match(r"^\w+\s+(\w+)\s*=", line)
        if m2 and not line.startswith(("if", "for", "while", "else", "f_")):
            m = m2
    if m:
        name = m.group(1)
        global_decls.setdefault(name, []).append(idx + 1)

for name, lns in global_decls.items():
    if len(lns) > 1:
        # les déclarations avec := ne comptent pas (regex ci-dessus exige =)
        issues.append(f"Déclaration dupliquée '{name}' aux lignes {lns}")

# 5) Fonctions : définition avant premier appel
func_def_re = re.compile(r"^(f_\w+)\s*\(")
func_defs = {}
for idx, line in enumerate(lines):
    m = func_def_re.match(line)
    if m and "=>" not in line:
        pass
    m = re.match(r"^(f_\w+)\s*\([^)]*\)\s*=>", line)
    if m:
        func_defs[m.group(1)] = idx + 1

calls_before_def = []
for idx, line in enumerate(lines):
    if line.strip().startswith("//"):
        continue
    for fn, def_ln in func_defs.items():
        # appel = fn( ... mais pas la ligne de définition
        if re.search(r"(?<!\w)" + re.escape(fn) + r"\(", line) and idx + 1 != def_ln:
            if idx + 1 < def_ln:
                calls_before_def.append(f"L{idx+1}: appel de {fn} avant sa définition (L{def_ln})")

# 6) Statistiques
n_lines = len(lines)
n_func = len(func_defs)

# 7) Vérifications sémantiques clés (marqueurs v2)
content = "".join(lines)
markers = {
    "boucles gardées (int sz = array.size)": content.count("int sz = array.size("),
    "obUseBody (OB sur corps)": content.count("obUseBody ?"),
    "f_create_breaker (breaker conforme)": content.count("f_create_breaker("),
    "f_create_mitigation (blocs mitigation)": content.count("f_create_mitigation("),
    "MSS conditionnel (hasDisp)": content.count('hasDisp ? "MSS"'),
    "OTE (61.8/78.6)": content.count("0.618") + content.count("0.786"),
    "PDH/PDL refs": content.count("PDH"),
    "sweep volume +V": content.count('"+V"'),
    "confluences OB tags": content.count("+FVG") + content.count("+SWP") + content.count("+VOL"),
    "touched (mitigation marquee)": content.count("z.touched := true"),
    "lastSweepBar refs": content.count("lastSweepBar"),
    "f_process_zone (generique)": content.count("f_process_zone("),
    "iCHoCH (MSS sans displacement)": content.count('"iCHoCH"'),
    "inversedInvalid (iFVG invalide)": content.count("inversedInvalid := true"),
}

print("=" * 62)
print("VERIFICATION STATIQUE — wavescope_ict_v2_conforme.pine")
print("=" * 62)
print(f"Lignes totales : {n_lines}   Fonctions : {n_func}")
print(f"Boucles vérifiées : {len(ok)} gardées, {len(issues)} non gardées")
print()

print("--- BOUCLES NON GARDEES (erreur potentielle) ---")
for i in issues:
    if "boucle" in i:
        print(" ", i)
if not any("boucle" in i for i in issues):
    print("  Aucune ✓")
print()

print("--- DOUBLONS ---")
for i in issues:
    if "Déclaration" in i:
        print(" ", i)
if not any("Déclaration" in i for i in issues):
    print("  Aucun ✓")
print()

print("--- APPELS AVANT DEFINITION ---")
for c in sorted(set(calls_before_def)):
    print(" ", c)
if not calls_before_def:
    print("  Aucun ✓")
print()

print("--- MARQUEURS v2 ---")
for k, v in markers.items():
    print(f"  {k}: {v}")
print()

print(f"--- AVERTISSEMENTS ({len(warns)}) ---")
for w in warns[:15]:
    print(" ", w)
if len(warns) > 15:
    print(f"  ... et {len(warns)-15} autres")
print()

# 8) Comparaison avec l'original
orig = open("/home/z/my-project/upload/ict_extracted/wavescope_ict.pine", encoding="utf-8").readlines()
orig_loop = sum(1 for l in orig if loop_re.match(l))
new_loop = sum(1 for l in lines if loop_re.match(l))
print(f"Boucles 'for 0 to array.size()-1' : original={orig_loop}, v2={new_loop}")
print(f"Taille : original={len(orig)} lignes, v2={n_lines} lignes")

sys.exit(1 if issues else 0)
