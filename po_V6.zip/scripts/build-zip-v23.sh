#!/bin/bash
# ════════════════════════════════════════════════════════════════════════
# build-zip-v23.sh — Livraison v23 « Vérification CISD : swing intact +
# confirmation par signal combiné » (L_Lucien ProTrader + Ninja ProTrader
# + Strategy Tester).
# ════════════════════════════════════════════════════════════════════════
#
# MISSION v23 (demande utilisateur) :
#   « dans les stratégies Ninja ProTrader et L_Lucien ProTrader, je veux
#     ajouter ces vérifications pour TOUT trades CISD UP et CISD Down.
#     Les CISD ont un bon winRate mais une faiblesse capable de graves
#     conséquences sur le solde. Avant de placer un ordre CALL ou PUT :
#     - sur les combinaisons CISD UP, on vérifie que le swing high le plus
#       proche n'a pas été violé, et on attend le prochain signal — s'il
#       est le combiné BOS UP + CISD UP ou CHoCH UP + CISD UP, on place
#       le CALL ;
#     - miroir CISD DOWN (swing low intact, combiné BOS DOWN + CISD DOWN
#       ou CHoCH DOWN + CISD DOWN → PUT). »
#
# Implémentation :
#   1. MOTEUR PARTAGÉ (shared/bos-choch-cisd.ts) — machine à états
#      « CISD Guard » : CisdGuardState/CisdGuardVerdict, createCisdGuard,
#      checkSwingHighIntact/checkSwingLowIntact, updateCisdGuard
#      (idempotence par bougie, détection de GAP, retrait intra-bougie
#      Ninja, armement et confirmation = DEUX signaux distincts) ;
#      evaluateBosChochCisdOrderRules porte la garde sur TOUTE règle
#      contenant CISD Up / CISD Down (options.cisdGuard — opt-in, les
#      appels sans état gardent le comportement v22 à l'identique).
#   2. L_LUCIEN PROTRADER (bos-choch-cisd-strategy.ts) : état de garde
#      PAR ASSET, réinitialisé par resetBosChochCisdState (changement de
#      stratégie / config Auto Trade).
#   3. NINJA PROTRADER (ninja-protrader-strategy.ts) : état PAR ASSET
#      séparé (ses propres séquences), réinitialisé par
#      resetNinjaProTraderState ; l'ordre part TOUJOURS AVANT la
#      clôture de la bougie de confirmation.
#   4. STRATEGY TESTER (src/lib/lucien-backtest.ts) : backtesting avec la
#      MÊME vérification (état dédié, reset au nouveau replay, libellé
#      des ordres simulés enrichi).
#   5. LIBELLÉS D'ORDRE : chaque ordre CISD confirmé porte
#      « … · CISD Up confirmé (armé bougie T, swing P intact) » ;
#      strategy-state et trade-opened transportent cisdConfirmation.
#   6. UI (auto-trade-panel.tsx) : note « Vérification CISD (toujours
#      active) » + détail du mécanisme sur chaque combinaison.
#
# Validation : tsc root 0 · tsc backend 0 · tsc SDK 0 · next build PASS
# (6/6) · test-v23-cisd-guard (NOUVEAU) 96 ✓ · test-v23-cisd-e2e (NOUVEAU,
# vrai backend + faux broker S5/pathScript/mèches) 31/31 ✓ · v22 unitaire
# 68 ✓ · v22-ninja-e2e 20/20 ✓ · bos-martingale-e2e 17/17 ✓ ·
# confirm-candle-cap-e2e 24/24 ✓ · auto-switch-rule-e2e 20/20 ✓ ·
# v21-rules-e2e 28/28 ✓ · multi-e2e 20/20 ✓ · tie-refund-e2e 24/24 ✓ ·
# v21-rules 61 ✓ · multi-assets ✓ · v63-features ✓ · v63-integration ✓ ·
# bos-strategy 22 ✓ · martingale-streak 12 ✓ · bos-expiry-martingale 39 ✓ ·
# confirm-candle-cap 59 ✓ · smart-stream-hardening PASS.
#
# Sortie : /home/z/my-project/download/pine_v6_engine_v23_cisd_swing_confirmation.zip
# ════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v23"
FOLDER=pine_v6_engine
OUT="$ROOT/download/pine_v6_engine_v23_cisd_swing_confirmation.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (structure identique aux zips v15-v22) ──────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude '.logs/' \
  --exclude '*.log' \
  --exclude 'winwinlogs.jsonl' \
  --exclude 'tsconfig.tsbuildinfo' \
  --exclude 'mini-services/iqoption-backend/data/backend-session.json' \
  --exclude 'mini-services/iqoption-backend/data/candle-cache/' \
  --exclude 'mini-services/iqoption-backend/e2e-*.log' \
  --exclude 'db/' \
  "$ROOT/pine_v6_engine/" "$STAGE/$FOLDER/"

# ── READMEs des versions précédentes (chaîne documentaire conservée) ────
unzip -q -o "$ROOT/download/pine_v6_engine_v22_ninja_candles_validation.zip" \
  "pine_v6_engine/README-V1.6-V22-NINJA-CANDLES-VALIDATION.md" \
  "pine_v6_engine/README-V1.6-V21-FINAL-RULES.md" \
  "pine_v6_engine/README-V1.6-V20-FINAL-FIXES.md" -d "$STAGE/"

# ── README de la version v23 ─────────────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.7-V23-CISD-SWING-CONFIRMATION.md" <<'EOF'
# Pine v6 Engine — v23 « Vérification CISD : swing intact + confirmation »

## La faiblesse des combinaisons CISD

Les combinaisons **CISD Up** et **CISD Down** ont un bon winRate, mais
elles peuvent causer de **graves conséquences sur le solde** : un CISD
qui arrive sur une cassure profonde — sans confirmation structurelle,
sur un swing déjà violé (liquidity sweep) — expose l'ordre à un
retournement immédiat, surtout avec la Martingale.

La v23 neutralise cette faiblesse sur **L_Lucien ProTrader**, **Ninja
ProTrader** et le **Strategy Tester** (backtesting inclus).

## Nouvelle séquence obligatoire (toujours active)

Une combinaison contenant **CISD Up** (ou **CISD Down**) ne place
**plus jamais** d'ordre direct :

```
1. CISD Up SEUL sur la bougie (sans BOS Up / CHoCH Up)
      └─ le programme vérifie que le SWING HIGH le plus proche
         (celui que le CISD franchit) n'a PAS été violé depuis sa
         formation — aucune bougie intermédiaire (mèche ou clôture)
         n'a dépassé le niveau ;
      └─ swing VIOLÉ  → refus explicite, aucune séquence ;
      └─ swing INTACT → séquence ARMÉE — AUCUN ordre, attente.

2. le signal SUIVANT décide :
      └─ combiné BOS Up + CISD Up ou CHoCH Up + CISD Up
         → l'ordre CALL ▲ est placé (avec la Candles Validation de
            la règle et la confirmation v19, si activées) ;
      └─ tout autre signal → la séquence est consommée sans ordre.
```

Miroir exact pour **CISD Down** : swing **low** intact → séquence armée
→ combiné **BOS Down + CISD Down** ou **CHoCH Down + CISD Down** →
**PUT ▼**.

**Conséquence clé** : un signal combiné qui arrive **d'emblée** (cassure
profonde sans CISD vérifié préalable) est **REFUSÉ** — c'est précisément
la protection demandée contre les pertes graves.

## Détails de robustesse

- **Par asset et par stratégie** : chaque asset (EURUSD_otc…) possède
  SES propres séquences, et L_Lucien / Ninja gardent des états séparés ;
- **deux signaux distincts** : l'armement et sa confirmation ne peuvent
  pas venir de la même bougie (Ninja inclus) ;
- **Ninja ProTrader** : l'ordre part toujours **AVANT la clôture** de la
  bougie de confirmation (polling 500 ms) ; un armement qui disparaît
  intra-bougie (flicker) est retiré, un retour du CISD le ré-arme ;
- **GAP** : si des bougies ont été sautées (redémarrage, asset
  momentanément désélectionné, garde maxPositions), l'armement est
  réputé périmé et annulé ;
- **idempotence** : les ré-évaluations d'une même bougie (polling) ne
  comptent qu'une fois ;
- **règles non-CISD** (BOS seul, CHoCH seul) : comportement inchangé —
  la vérification ne concerne QUE les combinaisons CISD ;
- **Candles Validation + confirmation v19** : toujours appliquées sur la
  bougie de confirmation (l'ordre doit passer TOUS les filtres).

## Libellés d'ordre (v23)

Chaque ordre confirmé porte la séquence complète, ex. :

```
L_Lucien ProTrader · CALL ▲ · call-1 [CISD Up] · sans validation ·
CISD Up confirmé (armé bougie 1790096525, swing 1.20194 intact)
```

Le `swing` documenté est le niveau vérifié intact au moment de
l'armement ; `armé bougie T` est l'horodatage de la bougie qui a armé
la séquence. `strategy-state` transporte en plus un objet
`cisdConfirmation` (direction, bougie d'armement, swing, alertes du
signal combiné).

## UI

- panneau **Auto Trade** : note bleue « Vérification CISD (toujours
  active) » sous le titre de la stratégie (L_Lucien et Ninja) ;
- chaque combinaison rappelle : « Combinaisons CISD : swing intact
  vérifié + signal combiné de confirmation exigé (v23) » ;
- « Latest signal » documente chaque étape : ARMÉE (swing intact,
  EN ATTENTE), REFUSÉ (swing VIOLÉ), REFUSÉ (combiné sans CISD
  vérifié préalable), CISD confirmé.

## Validation

```bash
# 1. Installer et démarrer
npm install && cd mini-services/iqoption-backend && npm install

# 2. Typecheck + build
cd ../.. && npx tsc --noEmit && npx next build

# 3. Nouveautés v23
npx tsx scripts/test-v23-cisd-guard.ts             # 96 ✓
cd mini-services/iqoption-backend
node tests/test-v23-cisd-e2e.mjs                   # 31/31 (vrai backend + faux broker)

# 4. Non-régression
node tests/test-v22-ninja-e2e.mjs                  # 20/20
node tests/test-bos-choch-cisd-martingale-e2e.mjs  # 17/17
node tests/test-confirm-candle-cap-e2e.mjs          # 24/24
node tests/test-auto-switch-rule-e2e.mjs           # 20/20
node tests/test-v21-rules-e2e.mjs                   # 28/28
```

Dans l'application :
- **Auto Trade** : configurer une combinaison CISD (ex. `[CISD Up]`
  CALL avec expiration) — le CISD seul arme la séquence (message
  « ARMÉE » dans Latest signal), l'ordre part au signal combiné
  suivant ;
- **Ninja ProTrader** : même séquence, ordre AVANT la clôture de la
  bougie de confirmation ;
- **Replay → Strategy Tester** : le backtesting applique la même
  vérification — les ordres simulés CISD portent leur confirmation
  dans la colonne Label.
EOF

cd "$STAGE"
zip -qr "$OUT" "$FOLDER"
cd "$ROOT"
rm -rf "$STAGE"
echo "─ Livraison v23 ─────────────────────────────────────────────"
echo "Zip      : $OUT"
echo "Taille   : $(du -h "$OUT" | cut -f1)"
echo "Fichiers : $(unzip -l "$OUT" | tail -1 | awk '{print $2}')"
echo "Intégrité: $(unzip -t "$OUT" > /dev/null && echo OK || echo ÉCHEC)"
sha256sum "$OUT"
md5sum "$OUT"
