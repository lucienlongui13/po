#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# E2E V1.8 — ALIGNMENT + PANES + ALERTS (regression guards)
#   1. Main.pine (overlay) + RSI (non-overlay) injectés, alertes ON
#   2. Import du pack PiracyChecker (libs) → ré-exécution auto
#   3. Assertions mesurées via window.__pineChartDebug :
#      A. échelle de prix NON distordue (RSI 30/70 ne l'étire plus)
#      B. drawings de Main.pine collés aux bougies (±tolérance)
#      C. panneau Pine séparé présent pour le script non-overlay
#      C. cloches d'alerte rendues sur le canvas (pixels ambre)
# ═══════════════════════════════════════════════════════════════════
cd /home/z/my-project
PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  ✓ $1"; }
ko()   { FAIL=$((FAIL+1)); echo "  ✗ $1"; }
step() { echo ""; echo "════════ $1 ════════"; }
shot() { agent-browser screenshot "scripts/e2e-v18-$1.png" >/dev/null 2>&1 && echo "📸 $1"; }

if ! curl -s -m 3 -o /dev/null http://localhost:3000/ 2>/dev/null; then
  step "0. Services morts → ./po.sh"
  setsid nohup ./po.sh > .logs/po-restart.log 2>&1
  for i in $(seq 1 30); do sleep 4; curl -s -m 5 -o /dev/null http://localhost:3000/ && break; done
fi
curl -s -m 3 -o /dev/null http://localhost:3000/ && echo "front OK" || { echo "✗ front mort"; exit 1; }

RSI_SRC='//@version=6
indicator("RSI Pane Test", overlay=false)
r = ta.rsi(close, 14)
plot(r, "RSI", color=color.purple)
hline(30, "OS")
hline(70, "OB")
plotshape(ta.crossover(r, 30), title="Cross Up", location=location.belowbar, color=color.green, size=size.tiny)
'

step "1. Injection Main.pine (alertes ON) + RSI (non-overlay)"
B64=$(base64 -w0 upload/piracy_extracted/Market_structures_scripts/Main.pine)
B64RSI=$(printf '%s' "$RSI_SRC" | base64 -w0)
agent-browser open http://localhost:3000 >/dev/null 2>&1
sleep 10
agent-browser eval "(() => {
  localStorage.clear();
  const src = atob('$B64');
  const rsi = atob('$B64RSI');
  const scripts = [
    { id: 'pine-main', name: 'BOS, CHoCH and CISD [PiracyChecker]', source: src,
      meta: { version: 6, declaration: 'indicator', title: 'BOS, CHoCH and CISD [PiracyChecker]', overlay: true },
      enabled: true,
      inputValues: { 'BOS Up Alert': true, 'BOS Down Alert': true, 'CHoCH Up Alert': true, 'CHoCH Down Alert': true, 'CISD Up Alert': true, 'CISD Down Alert': true } },
    { id: 'pine-rsi', name: 'RSI Pane Test', source: rsi,
      meta: { version: 6, declaration: 'indicator', title: 'RSI Pane Test', overlay: false },
      enabled: true }
  ];
  localStorage.setItem('pine-scripts-v1', JSON.stringify(scripts));
  return 'injected';
})()" >/dev/null 2>&1
agent-browser reload >/dev/null 2>&1
sleep 10

agent-browser find role button click --name "Login with Pocket Option" >/dev/null 2>&1
for i in $(seq 1 12); do
  sleep 5
  if agent-browser snapshot -i -c 2>/dev/null | grep -q "PINE SCRIPT"; then break; fi
done
agent-browser snapshot -i -c 2>/dev/null | grep -q "PINE SCRIPT" && echo "loggé" || { echo "✗ login"; exit 1; }
sleep 12

step "2. Import du pack (éditeur ouvert → input ZIP)"
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('PINE SCRIPT'));
  if (!b) return 'BOUTON ABSENT';
  b.click(); return 'ÉDITEUR OUVERT';
})()" 2>&1 | tail -1
sleep 4
B64ZIP=$(base64 -w0 upload/PiracyChecker.zip)
agent-browser eval "window.__zipB64 = '$B64ZIP'; 'ok'" >/dev/null 2>&1
agent-browser eval '(() => {
  const b64 = window.__zipB64;
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const file = new File([bytes], "PiracyChecker.zip", { type: "application/zip" });
  const input = [...document.querySelectorAll("input[type=file]")].find(i => (i.accept || "").includes("zip"));
  if (!input) return "INPUT ABSENT";
  const dt = new DataTransfer();
  dt.items.add(file);
  input.files = dt.files;
  input.dispatchEvent(new Event("change", { bubbles: true }));
  return "imported";
})()' 2>&1 | tail -1
sleep 16   # ré-exécution automatique des scripts

# fermer l'éditeur pour un rendu propre
agent-browser eval '(() => {
  const b = [...document.querySelectorAll("button")].find(x => (x.textContent || "").includes("PINE SCRIPT"));
  if (b && document.body.textContent.includes("Console")) { b.click(); }
  return "closed";
})()' >/dev/null 2>&1
sleep 4
shot chart

step "3. Assertions mesurées"
agent-browser eval '(() => {
  const dbg = window.__pineChartDebug;
  if (!dbg) return JSON.stringify({ error: "no debug hook" });
  const chart = dbg.getChart();
  const series = dbg.getSeries();
  const candles = dbg.getCandles();
  const scripts = dbg.getScripts().filter(s => s.enabled && s.result);
  if (!chart || !series || !candles.length || !scripts.length) return JSON.stringify({ error: "not ready", candles: candles.length, scripts: scripts.length });

  const paneEl = document.querySelector(".relative.flex-1");
  const paneH = paneEl ? paneEl.clientHeight : 0;
  const priceAtTop = series.coordinateToPrice(0);
  const priceAtBottom = series.coordinateToPrice(paneH);
  const lows = candles.map(c => c.low), highs = candles.map(c => c.high);
  const minLow = Math.min(...lows), maxHigh = Math.max(...highs);

  const main = scripts.find(s => s.result.overlay);
  const rsi = scripts.find(s => !s.result.overlay);
  const out = {
    candleCount: candles.length,
    visibleRange: [priceAtBottom, priceAtTop],
    candleRange: [minLow, maxHigh],
    rangeRatio: (priceAtTop - priceAtBottom) / Math.max(1e-12, maxHigh - minLow),
    mainDrawings: main ? main.result.drawings.length : 0,
    mainAlerts: main ? main.result.alerts.length : 0,
    rsiOverlayFlag: rsi ? rsi.result.overlay : null,
    rsiPlots: rsi ? rsi.result.plots.length : 0,
    rsiHlines: rsi ? rsi.result.hlines.length : 0,
    pinePanes: document.querySelectorAll("[data-testid=pine-sub-pane]").length,
  };
  if (main) {
    const prices = [];
    for (const d of main.result.drawings) {
      if (d.kind === "line") prices.push(d.y1, d.y2);
      else if (d.kind === "label" && d.y != null) prices.push(d.y);
      else if (d.kind === "box") prices.push(d.top, d.bottom);
    }
    if (prices.length) {
      out.drawingRange = [Math.min(...prices), Math.max(...prices)];
      const tol = (maxHigh - minLow) * 3 + maxHigh * 0.01;
      out.drawingsGlued = out.drawingRange[0] >= minLow - tol && out.drawingRange[1] <= maxHigh + tol;
    } else out.drawingsGlued = true;
  }
  const canvases = [...(paneEl ? paneEl.querySelectorAll("canvas") : [])];
  let bellPixels = 0;
  for (const c of canvases) {
    if (!c.className || !c.className.includes("z-[4]")) continue;
    try {
      const ctx = c.getContext("2d");
      const img = ctx.getImageData(0, 0, c.width, c.height).data;
      for (let i = 0; i < img.length; i += 16) {
        if (img[i+3] > 200 && img[i] >= 250 && img[i+1] >= 130 && img[i+1] <= 165 && img[i+2] === 0) bellPixels++;
      }
    } catch {}
    if (bellPixels > 0) break;
  }
  out.bellPixels = bellPixels;
  return JSON.stringify(out);
})()' > scripts/e2e-v18-probe.txt 2>&1
PROBE=$(tail -1 scripts/e2e-v18-probe.txt)

echo "$PROBE" | head -c 1200
echo ""

get() {
  echo "$PROBE" | python3 -c "
import json, sys
raw = sys.stdin.read().strip()
try:
    d = json.loads(json.loads(raw))
except Exception:
    try:
        d = json.loads(raw)
    except Exception:
        d = {}
v = d.get('$1', 'MISSING')
print(v)"
}

# A. price scale not distorted — the visible price range must stay within ±5%
# of the candle extremes (the RSI 30/70 bug stretched it to ~70 on EURUSD,
# a ~6000x distortion; zooming on a subset of bars keeps it well inside).
SCALE=$(agent-browser eval '(() => {
  const dbg = window.__pineChartDebug;
  const series = dbg.getSeries();
  const candles = dbg.getCandles();
  const paneEl = document.querySelector(".relative.flex-1");
  const paneH = paneEl ? paneEl.clientHeight : 0;
  const top = series.coordinateToPrice(0);
  const bottom = series.coordinateToPrice(paneH);
  const minLow = Math.min(...candles.map(c => c.low));
  const maxHigh = Math.max(...candles.map(c => c.high));
  const sane = top != null && bottom != null && top <= maxHigh * 1.05 && bottom >= minLow * 0.95;
  return sane ? "SANE" : "DISTORTED top=" + top + " bottom=" + bottom + " candles=[" + minLow + "," + maxHigh + "]";
})()' 2>&1 | tail -1 | tr -d '"')
[ "$SCALE" = "SANE" ] && ok "échelle de prix saine (visible range dans les ±5 % des extrêmes des bougies)" || ko "échelle distordue : $SCALE"

# B. drawings glued
GLUED=$(get drawingsGlued)
[ "$GLUED" = "True" ] && ok "drawings Main.pine collés aux bougies" || ko "drawings décollés (glued=$GLUED)"

DR=$(get mainDrawings)
[ "$DR" -gt 0 ] 2>/dev/null && ok "Main.pine exécuté : $DR drawings" || ko "drawings : $DR"

# C. pine pane present for non-overlay
PANES=$(get pinePanes)
[ "$PANES" -ge 1 ] 2>/dev/null && ok "panneau Pine séparé rendu pour le script non-overlay (RSI)" || ko "panneaux : $PANES"

RSIFLAG=$(get rsiOverlayFlag)
[ "$RSIFLAG" = "False" ] && ok "RSI détecté non-overlay" || ko "rsiOverlayFlag=$RSIFLAG"

# D. alerts visible
ALERTS=$(get mainAlerts)
[ "$ALERTS" -gt 0 ] 2>/dev/null && ok "alertes Main.pine collectées : $ALERTS événement(s)" || ko "alertes : $ALERTS"

BELLS=$(get bellPixels)
[ "$BELLS" -gt 0 ] 2>/dev/null && ok "cloches d'alerte rendues sur le graphique ($BELLS px ambre)" || ko "cloches : $BELLS"

echo ""
echo "════════════════════════════════════"
echo "E2E V1.8 : $PASS ✓ · $FAIL ✗"
echo "════════════════════════════════════"
[ "$FAIL" = "0" ]
