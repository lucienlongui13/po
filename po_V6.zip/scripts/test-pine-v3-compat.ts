/**
 * test-pine-v3-compat.ts — v1.10 regression suite: Pine v1–v4 legacy scripts.
 *
 * Guards the root causes fixed in v1.10:
 *  1. src/lib/pine-upgrade.ts — transparent v1–v4 → v6 source upgrade
 *     (study(), bare ta/math builtins, bare colors, style=stepline,
 *     isintraday/interval, legacy input(..., type=), transp=, iff, arity).
 *     Without it, pasted v3 scripts either fail to compile or — worse —
 *     silently produce `na` series (bare `sma()`/`macd()`/`min()` resolve
 *     to nothing under a v6 engine).
 *  2. piner int-division patch — Pine defines int/int → int (truncated);
 *     piner evaluated JS float division (`21/2 = 10.5`), so
 *     `ta.wma(close, len / 2)` returned `na` forever (HullMA broken).
 *  3. The user's Two Bar Break Line Alerts R1.1 (JustUncleL, Pine v3)
 *     must execute VERBATIM (no manual edit) with values that match an
 *     INDEPENDENT JS re-implementation of the indicator on the real
 *     2242-bar EURUSD M1 dataset — bar by bar.
 */
import { runPineScript, getPineInputSchema } from '../src/lib/pine-engine'
import { upgradeLegacyPine, isLegacyPine, detectPineVersion } from '../src/lib/pine-upgrade'
import { readFileSync } from 'node:fs'

let PASS = 0, FAIL = 0
const ok = (name: string, cond: boolean, extra = '') => {
  if (cond) { PASS++; console.log(`  ✓ ${name}`) }
  else { FAIL++; console.log(`  ✗ ${name}${extra ? ` — ${extra}` : ''}`) }
}

const SCRIPT_V3 = readFileSync('TradingView_pine_scripts_samples/2barbl_r11_v3.pine', 'utf8')
const raw = JSON.parse(readFileSync('scripts/dataset-eurusd-m1.json', 'utf8')) as any[]
const dataset = (Array.isArray(raw) ? raw : raw.candles ?? raw.data ?? []).map((c: any) => ({
  time: Number(c.time), open: Number(c.open), high: Number(c.high), low: Number(c.low), close: Number(c.close),
  volume: Number(c.volume ?? 0),
}))
const N = dataset.length

// ══════════════════════════════════════════════════════════════════════
// PART A — upgradeLegacyPine transform unit tests
// ══════════════════════════════════════════════════════════════════════
async function main() {
console.log('\n── A. source upgrade transform ──')
{
  const v6 = `//@version=6\nindicator("x")\nplot(ta.sma(close, 20), color=color.red)\n`
  ok('A1 v6 source untouched', upgradeLegacyPine(v6).upgraded === false && upgradeLegacyPine(v6).source === v6)
  const v5 = `//@version=5\nindicator("x")\nplot(ta.sma(close, 20))\n`
  ok('A2 v5 source untouched', upgradeLegacyPine(v5).upgraded === false)
  ok('A3 v3 detected as legacy', isLegacyPine(SCRIPT_V3) && detectPineVersion(SCRIPT_V3) === 3)
  ok('A4 no annotation + study() detected', isLegacyPine(`study("x")\nplot(close)\n`))

  const up = upgradeLegacyPine(SCRIPT_V3)
  ok('A5 upgraded flag set', up.upgraded === true)
  const lines = up.source.split('\n')
  ok('A6 line count preserved (error reporting)', lines.length === SCRIPT_V3.split('\n').length)
  ok('A7 study → indicator', /^indicator\(/.test(lines[2].trim()))
  const codeNoStrings = lines
    .map((l) => l.replace(/"(?:[^"\\]|\\.)*"/g, '""').replace(/\/\/.*$/, ''))
    .join('\n')
  const bareLeft = /(?<![\w.])(sma|ema|wma|vwma|macd|barssince|change|cum|exp|cos|sqrt|round|min|max)\s*\(/.exec(codeNoStrings)
  ok('A8 no bare ta/math calls remain', bareLeft === null, bareLeft ? `found: ${bareLeft[0]}` : '')
  ok('A9 bare colors namespaced', !/(^|[^.\w])(red|lime|maroon|gray)\b(?![-\w])/.test(codeNoStrings.replace(/color\.\w+/g, '')) || !/=\s*(red|lime|maroon|gray)\s*[,)]/.test(codeNoStrings))
  ok('A10 style=stepline namespaced', /style=plot\.style_stepline/.test(codeNoStrings))
  ok('A11 isintraday/interval mapped', /timeframe\.isintraday/.test(codeNoStrings) && !/(^|[^.\w])isintraday\b/.test(codeNoStrings) && /timeframe\.multiplier/.test(codeNoStrings))
  ok('A12 input type= stripped', !/type\s*=\s*(integer|string|bool|float)\s*[,)]/.test(codeNoStrings))
  ok('A13 `type` param + comparisons preserved', /variant\(type, src, len\)/.test(up.source) && /type=="EMA"/.test(up.source))
  ok('A14 transp= stripped', !/transp\s*=\s*\d/.test(codeNoStrings))
  ok('A15 macd namespaced', /ta\.macd\(/.test(up.source))

  const iff = upgradeLegacyPine(`//@version=3\nstudy("i")\nx = iff(close > open, 1, 2)\nplot(x)`)
  ok('A16 iff → ternary', /x\s*=\s*\(close > open\s*\?\s*1\s*:\s*2\)/.test(iff.source), JSON.stringify(iff.source.split('\n')[2]))
  const ris = upgradeLegacyPine(`//@version=3\nstudy("r")\nplot(rising(14))`)
  ok('A17 rising(14) → ta.rising(close, 14)', /ta\.rising\(close, ?14\)/.test(ris.source), ris.source.split('\n')[2])
  const sec = upgradeLegacyPine(`//@version=3\nstudy("s")\nv = security("X", "D", close)\nplot(v)`)
  ok('A18 security → request.security', /request\.security\(/.test(sec.source))

  const tr = upgradeLegacyPine(`//@version=3\nstudy("t")\nplot(close, color=red, transp=50)\nplot(open)\n`)
  ok('A19 transp=50 folded into color.new', /color=color\.new\(color\.red, ?50\)/.test(tr.source), JSON.stringify(tr.source.split('\n')[2]))
  ok('A20 strings/comments immune', upgradeLegacyPine(`//@version=3\nstudy("sma(close)")\n// plot red stepline here\nplot(close)`).source.includes('indicator("sma(close)")') && upgradeLegacyPine(`//@version=3\nstudy("s")\n// plot red stepline here\nplot(close)`).source.includes('// plot red stepline here'))

  const schema = await getPineInputSchema(SCRIPT_V3)
  ok('A21 schema builds for v3 source', schema.error === null && schema.inputs.length === 24, `inputs=${schema.inputs.length} err=${schema.error}`)
  const cmaType = schema.inputs.find((i) => i.key === 'Coloured MA Type: ')
  ok('A22 string enum input (11 options)', cmaType?.kind === 'string' && cmaType.options?.length === 11 && cmaType.default === 'HullMA')
  const boBars = schema.inputs.find((i) => i.key === 'Use 2 or 3 Bar Break Line Strategy')
  ok('A23 int input with minval/maxval', boBars?.kind === 'int' && boBars.minval === 2 && boBars.maxval === 3 && boBars.default === 2)
  const hidef = schema.inputs.find((i) => i.key === 'Hide Pivot Point Symbols (triangles)')
  ok('A24 bool input default true', hidef?.kind === 'bool' && hidef.default === true)
}

// ══════════════════════════════════════════════════════════════════════
// PART B — piner int-division patch (engine-level regression)
// ══════════════════════════════════════════════════════════════════════
console.log('\n── B. int division semantics (piner patch) ──')
async function lastValue(body: string): Promise<{ ok: boolean; value: number | null; finite: number }> {
  const res = await runPineScript(`//@version=6\nindicator("t", overlay=true)\n${body}`, dataset as any, { symbol: 'EURUSD_otc', timeframe: '1' })
  if (!res.ok) return { ok: false, value: null, finite: 0 }
  const data = (res.result.plots[0] as any).data as any[]
  const fin = data.map((d: any) => (d != null ? Number(d?.value ?? d) : null)).filter((v: any) => v != null && Number.isFinite(v))
  return { ok: true, value: fin.length ? fin[fin.length - 1] : null, finite: fin.length }
}
{
  const r1 = await lastValue('plot(21 / 2, title="d")')
  ok('B1 21/2 == 10 (int/int → int)', r1.ok && r1.value === 10, `got ${r1.value}`)
  const r2 = await lastValue('plot(5 / 2, title="d")')
  ok('B2 5/2 == 2', r2.ok && r2.value === 2, `got ${r2.value}`)
  const r3 = await lastValue('plot(2.5 / 2, title="d")')
  ok('B3 2.5/2 == 1.25 (float division preserved)', r3.ok && Math.abs((r3.value ?? 0) - 1.25) < 1e-12, `got ${r3.value}`)
  const r4 = await lastValue('plot(close / 2, title="d")')
  ok('B4 close/2 stays float', r4.ok && r4.finite === N)
  const r5 = await lastValue('l = 21\nplot(ta.wma(close, l / 2), title="d")')
  const r6 = await lastValue('plot(ta.wma(close, 10), title="d")')
  ok('B5 wma(close, 21/2) ≡ wma(close, 10) — HullMA unblocked',
    r5.ok && r6.ok && r5.finite === r6.finite && Math.abs((r5.value ?? 0) - (r6.value ?? 1)) < 1e-12,
    `half=${r5.finite}/${r5.value} full=${r6.finite}/${r6.value}`)
}

// ══════════════════════════════════════════════════════════════════════
// PART C — 2BARBL R1.1 (Pine v3) end-to-end vs independent reference
// ══════════════════════════════════════════════════════════════════════
console.log('\n── C. Two Bar Break Line Alerts R1.1 (v3, verbatim) ──')

// Independent JS re-implementation (probe3-verified to match engine values).
const na = NaN
const nz = (v: number, d = 0) => (Number.isFinite(v) ? v : d)
function smaR(s: number[], len: number): number[] {
  const out = Array(s.length).fill(na); let sum = 0
  for (let i = 0; i < s.length; i++) { sum += s[i]; if (i >= len) sum -= s[i - len]; if (i >= len - 1) out[i] = sum / len }
  return out
}
function emaR(s: number[], len: number): number[] {
  const out = Array(s.length).fill(na); const a = 2 / (len + 1); let prev = na
  for (let i = 0; i < s.length; i++) { prev = Number.isFinite(prev) ? a * s[i] + (1 - a) * prev : s[i]; out[i] = prev }
  return out
}
function wmaR(s: number[], len: number): number[] {
  const out = Array(s.length).fill(na); const den = (len * (len + 1)) / 2
  for (let i = len - 1; i < s.length; i++) { let num = 0; for (let j = 0; j < len; j++) num += s[i - j] * (len - j); out[i] = num / den }
  return out
}
function hullmaR(s: number[], len: number): number[] {
  const half = Math.max(1, Math.floor(len / 2)); const sq = Math.max(1, Math.round(Math.sqrt(len)))
  const w1 = wmaR(s, half), w2 = wmaR(s, len)
  const diff = s.map((_, i) => 2 * w1[i] - w2[i]).map((v) => (Number.isFinite(v) ? v : na))
  return wmaR(diff, sq)
}
const close = dataset.map((c) => c.close), open = dataset.map((c) => c.open), high = dataset.map((c) => c.high), low = dataset.map((c) => c.low)
const UP = 1, DOWN = -1
const topfractal: boolean[] = Array(N).fill(false), botfractal: boolean[] = Array(N).fill(false)
for (let i = 3; i < N; i++) {
  topfractal[i] = high[i - 1] > high[i - 2] && open[i - 2] < close[i - 2] && open[i - 1] < close[i - 1] && (open[i] > close[i] || high[i] < high[i - 1])
  botfractal[i] = low[i - 1] < low[i - 2] && open[i - 2] > close[i - 2] && open[i - 1] > close[i - 1] && (open[i] < close[i] || low[i] > low[i - 1])
}
const maSlow = hullmaR(close, 21)
const slowdirection: number[] = Array(N).fill(0)
for (let i = 0; i < N; i++) {
  const prev = i > 0 ? maSlow[i - 1] : na
  slowdirection[i] = maSlow[i] > prev ? UP : maSlow[i] < prev ? DOWN : (nz(slowdirection[i - 1] || 0) || UP)
}
const tDirection = slowdirection
const ef = emaR(close, 8), es = emaR(close, 21)
const currMacd = close.map((_, i) => ef[i] - es[i]).map((v) => (Number.isFinite(v) ? v : na))
const signalLine = emaR(currMacd, 5)
const toptriggers: number[] = Array(N).fill(na), bottriggers: number[] = Array(N).fill(na)
for (let i = 0; i < N; i++) {
  toptriggers[i] = topfractal[i] ? Math.min(low[i - 2], low[i - 1]) : (i > 0 ? toptriggers[i - 1] : na)
  bottriggers[i] = botfractal[i] ? Math.max(high[i - 2], high[i - 1]) : (i > 0 ? bottriggers[i - 1] : na)
}
const tup: number[] = Array(N).fill(0), tdn: number[] = Array(N).fill(0)
for (let i = 0; i < N; i++) {
  const bu = high[i] > bottriggers[i] && close[i] > open[i - 1] && open[i] < bottriggers[i] && tDirection[i] === UP
  tup[i] = bu ? nz(tup[i - 1]) + 1 : 0
  if (true) tup[i] = signalLine[i] < currMacd[i] ? tup[i] : 0
  const bd = low[i] < toptriggers[i] && close[i] < open[i - 1] && open[i] > toptriggers[i] && tDirection[i] === DOWN
  tdn[i] = bd ? nz(tdn[i - 1]) + 1 : 0
  if (true) tdn[i] = signalLine[i] > currMacd[i] ? tdn[i] : 0
}
const buy = tup.map((v) => v === 1), sell = tdn.map((v) => v === 1)
const refBuys = buy.filter(Boolean).length, refSells = sell.filter(Boolean).length
// BO statistics bar coloring (nc=0)
const yellowBar: boolean[] = Array(N).fill(false), blackBar: boolean[] = Array(N).fill(false)
for (let i = 0; i < N; i++) {
  const ab = buy[i] || sell[i]
  const correct = ab ? (buy[i] && close[i] > bottriggers[i]) || (sell[i] && close[i] < toptriggers[i]) : false
  yellowBar[i] = ab && correct
  blackBar[i] = ab && !correct
}
const refYellow = yellowBar.filter(Boolean).length, refBlack = blackBar.filter(Boolean).length

const res = await runPineScript(SCRIPT_V3, dataset as any, { symbol: 'EURUSD_otc', timeframe: '1' })
ok('C1 v3 script executes verbatim', res.ok, res.ok ? '' : JSON.stringify(res.error).slice(0, 160))
if (res.ok) {
  const r = res.result
  ok('C2 overlay=true (renders on chart)', r.overlay === true)
  ok('C3 four plots registered', r.plots.length === 4, `${r.plots.length}`)
  const byTitle = new Map(r.plots.map((p: any) => [p.title, p]))
  const hull = byTitle.get('Coloured MA Filter line')
  const hullData = ((hull as any)?.data ?? []) as any[]
  const hullVals = hullData.map((d: any) => (d != null ? Number(d?.value ?? d) : null))
  const refVals = maSlow
  let maxDiff = 0, mismatches = 0
  for (let i = 0; i < N; i++) {
    const a = hullVals[i], b = refVals[i]
    if (a == null || Number.isNaN(b)) { if ((a != null) !== (!Number.isNaN(b))) mismatches++ }
    else maxDiff = Math.max(maxDiff, Math.abs(a - b))
  }
  ok('C4 HullMA(21) bar-by-bar match (independent reference)',
    mismatches === 0 && maxDiff < 1e-9, `${mismatches} mismatches, maxDiff=${maxDiff.toExponential(2)}`)
  const top = byTitle.get('Top Breakout Line')
  const bot = byTitle.get('Bottom Breakout Line')
  const topVals = (((top as any)?.data ?? []) as any[]).map((d: any) => (d != null ? Number(d?.value ?? d) : null))
  const botVals = (((bot as any)?.data ?? []) as any[]).map((d: any) => (d != null ? Number(d?.value ?? d) : null))
  let topOk = 0, botOk = 0
  for (let i = 0; i < N; i++) {
    const tv = topVals[i], rv = toptriggers[i]
    if ((tv == null) === Number.isNaN(rv)) topOk++
    else if (tv != null && Math.abs(tv - rv) < 1e-9) topOk++
    const bv = botVals[i], rbv = bottriggers[i]
    if ((bv == null) === Number.isNaN(rbv)) botOk++
    else if (bv != null && Math.abs(bv - rbv) < 1e-9) botOk++
  }
  ok('C5 top/bottom breakout step lines bar-by-bar match', topOk === N && botOk === N, `top ${topOk}/${N} bot ${botOk}/${N}`)
  ok('C6 breakout lines use stepline style', (top as any)?.style === 'stepline' && (bot as any)?.style === 'stepline')
  const arrows = r.markers.find((m: any) => m.title === 'Breakout Arrows')
  const arrowData = ((arrows as any)?.data ?? []) as any[]
  const arrowBars = arrowData.map((d: any, i: number) => (d != null ? i : -1)).filter((i) => i >= 0)
  const refBars = buy.map((b, i) => (b || sell[i]) ? i : -1).filter((i) => i >= 0)
  ok('C7 breakout arrows land exactly on reference buy/sell bars',
    arrowBars.length === refBars.length && arrowBars.every((v, i) => v === refBars[i]),
    `engine ${arrowBars.length} vs ref ${refBars.length}${arrowBars.length === refBars.length ? '' : ' (positions differ)'}`)
  ok('C8 arrow count = reference buys+sells', arrowBars.length === refBuys + refSells, `${arrowBars.length} vs ${refBuys}+${refSells}`)
  const byMsg: Record<string, number> = {}
  for (const a of r.alerts) byMsg[a.message] = (byMsg[a.message] ?? 0) + 1
  ok('C9 alert breakdown exact (BUY/SELL/BL Alert)',
    byMsg['BUY'] === refBuys && byMsg['SELL'] === refSells && byMsg['BL Alert'] === refBuys + refSells,
    JSON.stringify(byMsg))
  ok('C10 trend-change alerts fire', (byMsg['TREND UP'] ?? 0) + (byMsg['TREND DOWN'] ?? 0) > 100, JSON.stringify(byMsg))
  const bc = (r.barColors[0] ?? []) as (string | null)[]
  const goldBars = bc.map((c, i) => (c != null && /FFD700/i.test(c)) ? i : -1).filter((i) => i >= 0)
  const blackBarsIdx = bc.map((c, i) => (c != null && !/FFD700/i.test(c)) ? i : -1).filter((i) => i >= 0)
  ok('C11 BO statistics bars: gold positions match reference',
    goldBars.length === refYellow && goldBars.every((v, i) => yellowBar[v]),
    `engine ${goldBars.length} vs ref ${refYellow}`)
  ok('C12 BO statistics bars: black positions match reference',
    blackBarsIdx.length === refBlack && blackBarsIdx.every((v, i) => blackBar[v]),
    `engine ${blackBarsIdx.length} vs ref ${refBlack}`)
  const statsMarkers = r.markers.filter((m: any) => ['success rate', 'trades made', 'total bars'].includes(String(m.title)))
  ok('C13 statistics plotshapes present at chart bottom', statsMarkers.length === 3 && statsMarkers.every((m: any) => m.location === 'bottom'))
  const colorsUsed = new Set(((hull as any)?.colors ?? []).filter(Boolean) as string[])
  ok('C14 coloured MA line has both up/down colors', colorsUsed.size >= 2, `${[...colorsUsed].join(',').slice(0, 80)}`)
}

console.log(`\n════ test-pine-v3-compat : ${PASS} ✓ · ${FAIL} ✗ ════`)
if (FAIL > 0) process.exit(1)
}

main().catch((e) => { console.error('SUITE FAILURE', e); process.exit(1) })
