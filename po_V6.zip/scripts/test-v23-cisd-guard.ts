/**
 * test-v23-cisd-guard.ts — v23 : Vérification CISD (swing intact +
 * ============================================================ confirmation
 * par signal combiné) pour L_Lucien ProTrader, Ninja ProTrader et le
 * Strategy Tester.
 *
 * MISSION :
 *   « sur les combinaisons CISD UP on vérifie que le swing high le plus
 *     proche n'a pas été violé, et on attend le prochain signal — s'il est
 *     le combiné BOS UP + CISD UP ou CHoCH UP + CISD UP alors on place le
 *     CALL ; miroir CISD DOWN (swing low, BOS DOWN + CISD DOWN ou CHoCH
 *     DOWN + CISD DOWN → PUT) ».
 *
 * 1. PRIMITIVES : checkSwingHighIntact / checkSwingLowIntact (fenêtre
 *    formation→signal, mèche = violation, bougies du swing exclues).
 * 2. MACHINE À ÉTATS updateCisdGuard : armement, swing violé, confirmation,
 *    refus sans armement, re-armement, inversion de direction, idempotence,
 *    retrait intra-bougie (flicker Ninja), détection de GAP, même-bougie
 *    armement→confirmation interdit.
 * 3. MOTEUR evaluateBosChochCisdOrderRules : ordre CISD uniquement après
 *    « CISD vérifié (swing intact) PUIS signal combiné » ; règle non-CISD
 *    et mode sans état (v22) inchangés ; Candles Validation toujours
 *    appliquée sur la bougie de confirmation.
 * 4. WRAPPERS BACKEND : L_Lucien (bos-choch-cisd-strategy) et Ninja
 *    (ninja-protrader-strategy) — séquence complète + gardes + reset.
 * 5. STRATEGY TESTER : libellé d'ordre avec confirmation CISD.
 * 6. VÉRIFICATIONS SOURCES : câblage backend (index.ts) + backtester + UI.
 *
 * Exécution : npx tsx scripts/test-v23-cisd-guard.ts
 */
import {
  evaluateBosChochCisdOrderRules,
  normalizeBosChochCisdOrderRules,
  computeBosChochCisd,
  createCisdGuardState,
  updateCisdGuard,
  checkSwingHighIntact,
  checkSwingLowIntact,
  ruleRequiresCisdGuard,
  type BosChochCisdCandle,
  type CisdGuardState,
} from '../shared/bos-choch-cisd.js'
import {
  evaluateNinjaProTraderStrategy,
  markNinjaProTraderTraded,
  resetNinjaProTraderState,
} from '../mini-services/iqoption-backend/ninja-protrader-strategy.js'
import {
  evaluateBosChochCisdStrategy,
  markBosChochCisdTraded,
  resetBosChochCisdState,
} from '../mini-services/iqoption-backend/bos-choch-cisd-strategy.js'
import { buildLucienBacktestOrderLabel } from '../src/lib/lucien-backtest.js'
import { readFileSync } from 'node:fs'

let pass = 0, fail = 0
function ok(cond: boolean, label: string, detail = ''): void {
  if (cond) { pass++; console.log(`  ✓ ${label}${detail ? ' — ' + detail : ''}`) }
  else { fail++; console.error(`  ✗ ${label}${detail ? ' — ' + detail : ''}`) }
}

/* ══════════════ helpers bougies ══════════════ */

let t = 1_700_000_000
const mk = (open: number, close: number, high: number, low: number) => {
  t += 60
  return { open, close, high, low, volume: 100, time: t }
}

/**
 * Série structurelle SE TERMINANT SUR UN CISD Up SEUL (swing high 11.2
 * intact) :
 *   sh : 12@1 puis 11.2@3 (descendants → dt) ;
 *   sl : 10@2 puis 9.8@4 (descendants → ut FAUX → pas de BOS Up) ;
 *   bougie 5 : close 12.5 > 11.2 && close[4] 10.6 < 11.2 → crossUp ;
 *   close 12.5 > sh1 12 → PAS de CHoCH Up → CISD Up SEUL. ✓
 */
function buildStandaloneCisdUpSeries(): BosChochCisdCandle[] {
  return [
    mk(10, 10.8, 11, 9.9),       // 0 verte
    mk(10.8, 10.2, 12, 10.1),    // 1 rouge → sh(1)=12
    mk(10.2, 10.9, 11.1, 10),    // 2 verte → sl(2)=10
    mk(10.9, 10.4, 11.2, 9.8),   // 3 rouge → sh(3)=11.2 (low profond 9.8)
    mk(10.4, 10.6, 10.7, 10.3),  // 4 verte → sl(4)=9.8 → ut FAUX
    mk(10.6, 12.5, 12.6, 10.5),  // 5 verte : cassure 11.2 → CISD Up SEUL
  ]
}

/** Même série, mais la bougie 4 MÈCHE au-dessus du swing high 11.2
 * (high 11.5) sans clôturer au-dessus → swing VIOLÉ (sweep de liquidité). */
function buildViolatedCisdUpSeries(): BosChochCisdCandle[] {
  const s = buildStandaloneCisdUpSeries()
  s[4] = { ...s[4], high: 11.5 }
  return s
}

/** Prolongement : bougies 6-8 sans événement, bougie 9 = BOS Up + CISD Up
 * (nouveau swing high 12.5 cassé, sl 11.9 > 9.8 → ut) → signal COMBINÉ. */
function buildConfirmUpTail(): BosChochCisdCandle[] {
  return [
    mk(12.5, 12.0, 12.7, 11.9),  // 6 rouge → sh(6)=12.7
    mk(12.0, 12.3, 12.4, 11.95), // 7 verte → sl(7)=11.9
    mk(12.3, 12.1, 12.5, 12.0),  // 8 rouge → sh(8)=12.5
    mk(12.1, 12.8, 12.9, 12.05), // 9 verte : cassure 12.5 + ut → BOS Up + CISD Up
  ]
}

/** Miroir EXACT (p → 20-p) : CISD Down SEUL avec swing low 8.8 intact. */
function buildStandaloneCisdDownSeries(): BosChochCisdCandle[] {
  return [
    mk(10, 9.2, 10.1, 9.0),      // 0' rouge
    mk(9.2, 9.8, 9.9, 8.0),      // 1' verte → sl(1')=8.0
    mk(9.8, 9.1, 10.0, 8.9),     // 2' rouge → sh(2')=10.0
    mk(9.1, 9.6, 10.2, 8.8),     // 3' verte → sl(3')=8.8
    mk(9.6, 9.4, 9.7, 9.3),      // 4' rouge → sh(4')=10.2 → dt FAUX
    mk(9.4, 7.5, 9.5, 7.4),      // 5' rouge : cassure 8.8 → CISD Down SEUL
  ]
}

/** Miroir violé : la bougie 4' MÈCHE sous le swing low 8.8 (low 8.5). */
function buildViolatedCisdDownSeries(): BosChochCisdCandle[] {
  const s = buildStandaloneCisdDownSeries()
  s[4] = { ...s[4], low: 8.5 }
  return s
}

/** Miroir du prolongement : bougie 9' = BOS Down + CISD Down (combiné). */
function buildConfirmDownTail(): BosChochCisdCandle[] {
  return [
    mk(7.5, 8.0, 8.1, 7.3),      // 6' verte → sl(6')=7.3
    mk(8.0, 7.7, 8.05, 7.6),     // 7' rouge → sh(7')=8.1
    mk(7.7, 7.9, 8.0, 7.5),      // 8' verte → sl(8')=7.5
    mk(7.9, 7.2, 7.95, 7.1),     // 9' rouge : cassure 7.5 + dt → BOS Down + CISD Down
  ]
}

/** Fixture v22 validé : la bougie 5 porte BOS Up + CISD Up d'emblée (ut). */
function buildDirectCombinedSeries(): BosChochCisdCandle[] {
  return [
    mk(10, 10.8, 11, 9.9),       // 0 verte
    mk(10.8, 10.2, 12, 10.1),    // 1 rouge → sh(1)=12
    mk(10.2, 10.9, 11.1, 10),    // 2 verte → sl(2)=10
    mk(10.9, 10.4, 11.2, 10.2),  // 3 rouge → sh(3)=11.2
    mk(10.4, 10.6, 10.7, 10.3),  // 4 verte → sl(4)=10.2 → uptrend
    mk(10.6, 12.5, 12.6, 10.5),  // 5 verte : cassure → BOS Up + CISD Up
  ]
}

/** Événements de la dernière bougie (labels). */
function lastBarEvents(candles: BosChochCisdCandle[]): string[] {
  const res = computeBosChochCisd(candles)
  return [...new Set(res.events.filter((e) => e.barIndex === candles.length - 1).map((e) => e.label))]
}

const CALL_CISD = [{ id: 'call-1', alerts: ['CISD Up'] as const, expirationSeconds: 60 }]
const PUT_CISD = [{ id: 'put-1', alerts: ['CISD Down'] as const, expirationSeconds: 60 }]
const CALL_COMBINED = [{ id: 'call-2', alerts: ['BOS Up', 'CISD Up'] as const, expirationSeconds: 45 }]
const PUT_COMBINED = [{ id: 'put-2', alerts: ['BOS Down', 'CISD Down'] as const, expirationSeconds: 45 }]
const CALL_BOS_ONLY = [{ id: 'call-bos', alerts: ['BOS Up'] as const, expirationSeconds: 30 }]

async function main() {
  console.log('══ v23 — Vérification CISD : swing intact + confirmation par signal combiné ══\n')

  /* ── 0. fixtures : les géométries sont bien celles attendues ── */
  console.log('[0] Géométrie des fixtures')
  {
    const a = buildStandaloneCisdUpSeries()
    ok(lastBarEvents(a).join('|') === 'CISD Up', 'série A : bougie 5 = CISD Up SEUL', lastBarEvents(a).join('|'))
    const b = [...a, ...buildConfirmUpTail()]
    ok(lastBarEvents(b.slice(0, 10)).join('|') === 'BOS Up|CISD Up', 'série B : bougie 9 = BOS Up + CISD Up', lastBarEvents(b.slice(0, 10)).join('|'))
    for (let k = 6; k <= 8; k++) {
      ok(lastBarEvents(b.slice(0, k + 1)).length === 0, `série B : bougie ${k} sans événement`)
    }
    const d = buildStandaloneCisdDownSeries()
    ok(lastBarEvents(d).join('|') === 'CISD Down', 'série A\' : bougie 5 = CISD Down SEUL', lastBarEvents(d).join('|'))
    const e = [...d, ...buildConfirmDownTail()]
    ok(lastBarEvents(e.slice(0, 10)).join('|') === 'BOS Down|CISD Down', 'série B\' : bougie 9 = BOS Down + CISD Down', lastBarEvents(e.slice(0, 10)).join('|'))
    const v22 = buildDirectCombinedSeries()
    ok(lastBarEvents(v22).join('|') === 'BOS Up|CISD Up', 'fixture v22 : bougie 5 = BOS Up + CISD Up d’emblée', lastBarEvents(v22).join('|'))
    const viol = buildViolatedCisdUpSeries()
    ok(lastBarEvents(viol).join('|') === 'CISD Up', 'série violée : bougie 5 = CISD Up SEUL (mèche invisible pour le moteur)', lastBarEvents(viol).join('|'))
  }

  /* ── 1. primitives : swings intacts / violés ── */
  console.log('\n[1] checkSwingHighIntact / checkSwingLowIntact — fenêtre formation→signal')
  {
    const s = buildStandaloneCisdUpSeries()
    // swing 11.2 formé à l'indice 3 ; bougies 4 (fenêtre) puis 5 (signal).
    ok(checkSwingHighIntact(s, 3, 11.2, 5).intact === true, 'swing high intact (mèche 10.7 < 11.2)')
    const sv = buildViolatedCisdUpSeries()
    const r = checkSwingHighIntact(sv, 3, 11.2, 5)
    ok(r.intact === false && r.violationBarIndex === 4, 'swing high VIOLÉ par la mèche de la bougie 4 (11.5 > 11.2)', `bar ${r.violationBarIndex}`)
    // fenêtre vide : swing formé juste avant le signal → intact.
    ok(checkSwingHighIntact(s, 4, 11.2, 5).intact === true, 'fenêtre vide (swing à 4, signal à 5) → intact')
    // la bougie signal elle-même n'est pas comptée (close > swing par définition).
    ok(checkSwingHighIntact(sv, 3, 11.2, 4).intact === true, 'la bougie du swing n’est pas comptée comme violation')
    const d = buildStandaloneCisdDownSeries()
    ok(checkSwingLowIntact(d, 3, 8.8, 5).intact === true, 'swing low intact (mèche 9.3 > 8.8)')
    const dv = buildViolatedCisdDownSeries()
    const rd = checkSwingLowIntact(dv, 3, 8.8, 5)
    ok(rd.intact === false && rd.violationBarIndex === 4, 'swing low VIOLÉ par la mèche de la bougie 4 (8.5 < 8.8)', `bar ${rd.violationBarIndex}`)
  }

  /* ── 2. machine à états updateCisdGuard ── */
  console.log('\n[2] updateCisdGuard — armement / confirmation / refus / robustesse')
  {
    /* 2.1 armement (swing intact) */
    let st = createCisdGuardState()
    const a = buildStandaloneCisdUpSeries()
    const resA = computeBosChochCisd(a)
    const firedA = resA.events.filter((e) => e.barIndex === a.length - 1)
    const v1 = updateCisdGuard(st, a, firedA)
    ok(v1.transition === 'armed' && v1.orderAllowed === false && v1.direction === 'up', 'CISD Up seul + swing intact → ARMÉ (aucun ordre)', v1.transition)
    ok(v1.swingPrice === 11.2 && v1.armedCandleTime === a[5].time, 'armement porte le swing (11.2) et la bougie', `swing ${v1.swingPrice}`)
    ok(st.armed != null && st.armed.direction === 'up', 'état armé persistant (up)')

    /* 2.2 idempotence : même bougie + mêmes événements → verdict en cache */
    const v1b = updateCisdGuard(st, a, firedA)
    ok(v1b === v1, 'ré-évaluation de la même bougie → verdict en cache (idempotence)')

    /* 2.3 confirmation : bougies sans événement puis signal combiné */
    const full = [...a, ...buildConfirmUpTail()]
    for (let k = 6; k <= 8; k++) {
      const slice = full.slice(0, k + 1)
      const res = computeBosChochCisd(slice)
      const vk = updateCisdGuard(st, slice, res.events.filter((e) => e.barIndex === k))
      ok(vk.transition === 'none' && st.armed != null, `bougie ${k} sans événement → armement conservé`)
    }
    const slice9 = full.slice(0, 10)
    const res9 = computeBosChochCisd(slice9)
    const v9 = updateCisdGuard(st, slice9, res9.events.filter((e) => e.barIndex === 9))
    ok(v9.transition === 'confirmed' && v9.orderAllowed === true, 'signal combiné BOS Up + CISD Up après armement → CONFIRMÉ (ordre autorisé)', v9.transition)
    ok(v9.confirmedBy != null && v9.confirmedBy.join('+') === 'BOS Up', 'confirmé par [BOS Up]', (v9.confirmedBy ?? []).join('+'))
    ok(v9.armedCandleTime === a[5].time && v9.swingPrice === 11.2, 'la confirmation documente l’armement (bougie 5, swing 11.2)')
    ok(st.armed === null, 'armement consommé par la confirmation')

    /* 2.4 refus : signal combiné SANS armement préalable (cassure directe) */
    st = createCisdGuardState()
    const d = buildDirectCombinedSeries()
    const resD = computeBosChochCisd(d)
    const vd = updateCisdGuard(st, d, resD.events.filter((e) => e.barIndex === d.length - 1))
    ok(vd.transition === 'refused' && vd.orderAllowed === false, 'signal combiné d’emblée (cassure profonde) → REFUSÉ', vd.transition)
    ok(st.armed === null, 'aucun armement après refus')

    /* 2.5 swing violé → pas d'armement */
    st = createCisdGuardState()
    const sv = buildViolatedCisdUpSeries()
    const resV = computeBosChochCisd(sv)
    const vv = updateCisdGuard(st, sv, resV.events.filter((e) => e.barIndex === sv.length - 1))
    ok(vv.transition === 'swing-violated' && vv.orderAllowed === false, 'CISD Up avec swing high déjà violé → REFUS, pas d’armement', vv.transition)
    ok(st.armed === null && vv.detail.includes('VIOLÉ'), 'reason documente la violation (sweep de liquidité)')

    /* 2.6 refus définitif : swing violé PUIS signal combiné → toujours rien */
    const svFull = [...sv, ...buildConfirmUpTail()]
    const slice9v = svFull.slice(0, 10)
    for (let k = 5; k <= 9; k++) {
      const slice = svFull.slice(0, k + 1)
      const res = computeBosChochCisd(slice)
      updateCisdGuard(st, slice, res.events.filter((e) => e.barIndex === k))
    }
    const v9v = st.lastVerdict as { transition: string }
    ok(v9v.transition === 'refused', 'séquence complète avec swing violé : le combiné final est REFUSÉ (protection du solde)', v9v.transition)

    /* 2.7 re-armement : un NOUVEAU CISD seul remplace l'armement */
    st = createCisdGuardState()
    const a2 = buildStandaloneCisdUpSeries()
    const r2 = computeBosChochCisd(a2)
    updateCisdGuard(st, a2, r2.events.filter((e) => e.barIndex === 5))
    // nouvelle bougie standalone CISD Up (même géométrie décalée)
    const a2b = [...a2, mk(12.5, 12.0, 12.7, 11.9), mk(12.0, 13.5, 13.6, 11.95)]
    // bougie 7 : close 13.5 > sh0(12.7) — mais sl0(11.9) > sl1(9.8) → ut → BOS Up…
    // → pour un 2e standalone il faut ut FAUX : les sl restent descendants.
    // (la bougie 6 rouge crée sh(6)=12.7 ; bougie 7 verte sl(7)=11.9 > 9.8 → ut → combiné.)
    // → on vérifie plutôt l'INVERSION de direction :
    const dn = buildStandaloneCisdDownSeries()
    const rdn = computeBosChochCisd(dn)
    const vdn = updateCisdGuard(st, dn, rdn.events.filter((e) => e.barIndex === dn.length - 1))
    ok(vdn.transition === 'armed' && vdn.direction === 'down', 'standalone CISD Down alors qu’un up était armé → l’armement bascule en DOWN', vdn.transition)
    ok(st.armed?.direction === 'down', 'état armé = down (l’ancien up est remplacé)')
    void a2b

    /* 2.8 GAP : des bougies sautées → armement périmé */
    st = createCisdGuardState()
    const g1 = buildStandaloneCisdUpSeries()
    const rg = computeBosChochCisd(g1)
    updateCisdGuard(st, g1, rg.events.filter((e) => e.barIndex === 5))
    ok(st.armed != null, 'armé avant le gap')
    // on saute les bougies 6-8 : évaluation directe de la bougie 9.
    const gFull = [...g1, ...buildConfirmUpTail()]
    const g9 = gFull.slice(0, 10)
    const rg9 = computeBosChochCisd(g9)
    const vg9 = updateCisdGuard(st, g9, rg9.events.filter((e) => e.barIndex === 9))
    ok(vg9.transition === 'refused', 'GAP (bougies 6-8 jamais évaluées) → armement annulé, combiné refusé', vg9.transition)

    /* 2.9 retrait intra-bougie (flicker Ninja) */
    st = createCisdGuardState()
    const f = buildStandaloneCisdUpSeries()
    const rf = computeBosChochCisd(f)
    updateCisdGuard(st, f, rf.events.filter((e) => e.barIndex === 5))
    ok(st.armed != null, 'armé intra-bougie (Ninja)')
    // la même bougie n'affiche plus l'événement (prix retombé) → retrait.
    const rf2 = { events: [] as typeof rf.events }
    const vw = updateCisdGuard(st, f, rf2.events)
    ok(vw.transition === 'withdrawn' && st.armed === null, 'l’événement disparaît de la bougie en formation → armement RETIRÉ', vw.transition)

    /* 2.10 même bougie : armement puis combiné → PAS de confirmation */
    st = createCisdGuardState()
    const s10 = buildStandaloneCisdUpSeries()
    const r10 = computeBosChochCisd(s10)
    updateCisdGuard(st, s10, r10.events.filter((e) => e.barIndex === 5))
    // la bougie 5 devient combinée (close retombe entre sh0 et sh1 → CHoCH Up).
    const s10b = [...s10]
    s10b[5] = { ...s10b[5], close: 11.8 }
    const r10b = computeBosChochCisd(s10b)
    const ev10b = r10b.events.filter((e) => e.barIndex === 5)
    ok(ev10b.some((e) => e.label === 'CHoCH Up') && ev10b.some((e) => e.label === 'CISD Up'), 'bougie 5 à close 11.8 → CHoCH Up + CISD Up (combiné)', ev10b.map((e) => e.label).join('|'))
    const v10b = updateCisdGuard(st, s10b, ev10b)
    ok(v10b.transition === 'refused', 'armement et confirmation sur la MÊME bougie → REFUSÉ (deux signaux distincts exigés)', v10b.transition)

    /* 2.11 miroir DOWN complet */
    st = createCisdGuardState()
    const dnFull = [...buildStandaloneCisdDownSeries(), ...buildConfirmDownTail()]
    let lastT = ''
    for (let k = 0; k < 10; k++) {
      const slice = dnFull.slice(0, k + 1)
      const res = computeBosChochCisd(slice)
      const vk = updateCisdGuard(st, slice, res.events.filter((e) => e.barIndex === k))
      lastT = vk.transition
      if (k === 5) ok(vk.transition === 'armed' && vk.direction === 'down', 'miroir : CISD Down seul + swing low intact → ARMÉ (down)', vk.transition)
    }
    ok(lastT === 'confirmed', 'miroir : BOS Down + CISD Down après armement → CONFIRMÉ', lastT)
    ok(st.lastVerdict?.direction === 'down' && st.lastVerdict?.orderAllowed === true, 'miroir : ordre autorisé (PUT ▼)')
  }

  /* ── 3. moteur : evaluateBosChochCisdOrderRules avec garde ── */
  console.log('\n[3] evaluateBosChochCisdOrderRules — combinaisons CISD sous garde')
  {
    /* 3.1 CISD seul → HOLD ARMÉ (aucun ordre direct) */
    let st = createCisdGuardState()
    const a = buildStandaloneCisdUpSeries()
    const s1 = evaluateBosChochCisdOrderRules(a, CALL_CISD, [], { cisdGuard: { state: st } })
    ok(s1.action === 'HOLD', 'CISD Up seul → HOLD (plus JAMAIS d’ordre direct)', s1.action)
    ok(s1.reason.includes('ARMÉE') && s1.reason.includes('swing high 11.2000 intact'), 'reason documente l’armement et le swing', s1.reason.slice(0, 120))

    /* 3.2 séquence complète → CALL sur le combiné avec cisdConfirmation */
    const full = [...a, ...buildConfirmUpTail()]
    for (let k = 6; k <= 8; k++) {
      evaluateBosChochCisdOrderRules(full.slice(0, k + 1), CALL_CISD, [], { cisdGuard: { state: st } })
    }
    const s9 = evaluateBosChochCisdOrderRules(full.slice(0, 10), CALL_CISD, [], { cisdGuard: { state: st } })
    ok(s9.action === 'CALL', 'combiné BOS Up + CISD Up après CISD vérifié → CALL ▲', s9.action)
    ok(s9.cisdConfirmation != null && s9.cisdConfirmation.direction === 'up', 'signal porte cisdConfirmation (up)')
    ok(s9.cisdConfirmation?.armedCandleTime === a[5].time && s9.cisdConfirmation?.swingPrice === 11.2, 'cisdConfirmation : armé bougie 5, swing 11.2')
    ok((s9.cisdConfirmation?.confirmedBy ?? []).join('+') === 'BOS Up', 'cisdConfirmation : confirmé par [BOS Up]')
    ok(s9.reason.includes('CISD Up confirmé') && s9.reason.includes('swing high 11.2000 intact'), 'reason documente la séquence complète', s9.reason.slice(-140))

    /* 3.3 combiné SANS armement → refus (protection du solde) */
    st = createCisdGuardState()
    const d = buildDirectCombinedSeries()
    const sd = evaluateBosChochCisdOrderRules(d, CALL_CISD, [], { cisdGuard: { state: st } })
    ok(sd.action === 'HOLD' && sd.reason.includes('SANS CISD Up vérifié préalable'), 'cassure profonde d’emblée → REFUSÉ (la faiblesse des CISD est neutralisée)', sd.reason.slice(0, 110))

    /* 3.4 swing violé → refus d’armement puis combiné refusé */
    st = createCisdGuardState()
    const sv = [...buildViolatedCisdUpSeries(), ...buildConfirmUpTail()]
    const sv5 = evaluateBosChochCisdOrderRules(sv.slice(0, 6), CALL_CISD, [], { cisdGuard: { state: st } })
    ok(sv5.action === 'HOLD' && sv5.reason.includes('VIOLÉ'), 'CISD Up avec swing mèché → HOLD refusé (sweep)', sv5.reason.slice(0, 110))
    for (let k = 6; k <= 9; k++) {
      evaluateBosChochCisdOrderRules(sv.slice(0, k + 1), CALL_CISD, [], { cisdGuard: { state: st } })
    }
    const sv9 = evaluateBosChochCisdOrderRules(sv.slice(0, 10), CALL_CISD, [], { cisdGuard: { state: st } })
    ok(sv9.action === 'HOLD', 'swing violé : même le combiné final reste sans ordre', sv9.action)

    /* 3.5 règle combinée ['BOS Up','CISD Up'] : MÊME séquence exigée */
    st = createCisdGuardState()
    const sdc = evaluateBosChochCisdOrderRules(d, CALL_COMBINED, [], { cisdGuard: { state: st } })
    ok(sdc.action === 'HOLD' && sdc.reason.includes('SANS CISD Up vérifié préalable'), 'règle [BOS Up + CISD Up] : combiné direct → REFUSÉ aussi', sdc.action)
    let st2 = createCisdGuardState()
    evaluateBosChochCisdOrderRules(a, CALL_COMBINED, [], { cisdGuard: { state: st2 } })
    for (let k = 6; k <= 8; k++) {
      evaluateBosChochCisdOrderRules(full.slice(0, k + 1), CALL_COMBINED, [], { cisdGuard: { state: st2 } })
    }
    const s9c = evaluateBosChochCisdOrderRules(full.slice(0, 10), CALL_COMBINED, [], { cisdGuard: { state: st2 } })
    ok(s9c.action === 'CALL' && s9c.matchedRuleId === 'call-2', 'règle [BOS Up + CISD Up] : ordre après séquence vérifiée', `${s9c.action}/${s9c.matchedRuleId}`)
    ok(s9c.cisdConfirmation != null, 'règle combinée : cisdConfirmation présente')

    /* 3.6 règle SANS CISD (['BOS Up']) : la garde ne s'applique PAS */
    st = createCisdGuardState()
    const sb = evaluateBosChochCisdOrderRules(d, CALL_BOS_ONLY, [], { cisdGuard: { state: st } })
    ok(sb.action === 'CALL' && sb.cisdConfirmation === undefined, 'règle [BOS Up] pure : ordre direct, garde inactive (hors mission)', sb.action)

    /* 3.7 sans état de garde : comportement v22 inchangé */
    const sLegacy = evaluateBosChochCisdOrderRules(d, CALL_CISD, [])
    ok(sLegacy.action === 'CALL', 'SANS état de garde : v22 — CISD Up ordonne directement (rétro-compatibilité)', sLegacy.action)

    /* 3.8 Candles Validation TOUJOURS appliquée sur la bougie de confirmation */
    st = createCisdGuardState()
    const badVal = [{ id: 'call-1', alerts: ['CISD Up'] as const, expirationSeconds: 60, candlesValidation: 'RRRRR' }]
    evaluateBosChochCisdOrderRules(a, badVal, [], { cisdGuard: { state: st } })
    for (let k = 6; k <= 8; k++) {
      evaluateBosChochCisdOrderRules(full.slice(0, k + 1), badVal, [], { cisdGuard: { state: st } })
    }
    const s9bad = evaluateBosChochCisdOrderRules(full.slice(0, 10), badVal, [], { cisdGuard: { state: st } })
    ok(s9bad.action === 'HOLD' && s9bad.reason.includes('Candles Validation RRRRR ✗'), 'confirmation CISD OK mais Candles Validation refuse → HOLD', s9bad.reason.slice(0, 130))
    st2 = createCisdGuardState()
    const goodVal = [{ id: 'call-1', alerts: ['CISD Up'] as const, expirationSeconds: 60, candlesValidation: 'GRGR' }]
    evaluateBosChochCisdOrderRules(a, goodVal, [], { cisdGuard: { state: st2 } })
    for (let k = 6; k <= 8; k++) {
      evaluateBosChochCisdOrderRules(full.slice(0, k + 1), goodVal, [], { cisdGuard: { state: st2 } })
    }
    const s9good = evaluateBosChochCisdOrderRules(full.slice(0, 10), goodVal, [], { cisdGuard: { state: st2 } })
    ok(s9good.action === 'CALL' && s9good.matchedRuleValidation === 'GRGR', 'confirmation CISD + Candles Validation GRGR ✓ → CALL', `${s9good.action}/${s9good.matchedRuleValidation}`)

    /* 3.9 miroir DOWN : PUT après séquence */
    st = createCisdGuardState()
    const dn = buildStandaloneCisdDownSeries()
    const pd = evaluateBosChochCisdOrderRules(dn, [], PUT_CISD, { cisdGuard: { state: st } })
    ok(pd.action === 'HOLD' && pd.reason.includes('ARMÉE'), 'CISD Down seul → HOLD ARMÉ', pd.reason.slice(0, 100))
    const dnFull = [...dn, ...buildConfirmDownTail()]
    for (let k = 6; k <= 8; k++) {
      evaluateBosChochCisdOrderRules(dnFull.slice(0, k + 1), [], PUT_CISD, { cisdGuard: { state: st } })
    }
    const p9 = evaluateBosChochCisdOrderRules(dnFull.slice(0, 10), [], PUT_CISD, { cisdGuard: { state: st } })
    ok(p9.action === 'PUT' && p9.cisdConfirmation?.direction === 'down', 'combiné BOS Down + CISD Down après CISD Down vérifié → PUT ▼', p9.action)
    ok(p9.cisdConfirmation?.swingPrice === 8.8, 'cisdConfirmation : swing low 8.8 vérifié', String(p9.cisdConfirmation?.swingPrice))

    /* 3.10 aucune règle correspondante : le détail CISD est quand même documenté */
    st = createCisdGuardState()
    const noMatch = evaluateBosChochCisdOrderRules(a, CALL_COMBINED, [], { cisdGuard: { state: st } })
    ok(noMatch.action === 'HOLD' && noMatch.reason.includes('CISD Up vérifié') && noMatch.reason.includes('EN ATTENTE'),
      'CISD armé sans correspondance de règle → HOLD documenté (armement conservé)', noMatch.reason.slice(0, 140))
    for (let k = 6; k <= 8; k++) {
      evaluateBosChochCisdOrderRules(full.slice(0, k + 1), CALL_COMBINED, [], { cisdGuard: { state: st } })
    }
    const nm9 = evaluateBosChochCisdOrderRules(full.slice(0, 10), CALL_COMBINED, [], { cisdGuard: { state: st } })
    ok(nm9.action === 'CALL', 'puis le combiné place l’ordre via la règle combinée', nm9.action)

    /* 3.11 règle MIXTE (CALL sur CISD Down — configuration exotique) :
     * la porte suit l'ALERTE (CISD Down → séquence down), pas l'action. */
    st = createCisdGuardState()
    const exotic = evaluateBosChochCisdOrderRules(dn, [{ id: 'call-x', alerts: ['CISD Down'] as const, expirationSeconds: 60 }], [], { cisdGuard: { state: st } })
    ok(exotic.action === 'HOLD', 'règle CALL [CISD Down] : CISD Down seul → HOLD (armement down)', exotic.action)
  }

  /* ── 4. wrappers backend ── */
  console.log('\n[4] Wrappers backend — L_Lucien ProTrader / Ninja ProTrader')
  {
    /* 4.1 L_Lucien : séquence complète + garde + reset */
    resetBosChochCisdState()
    const full = [...buildStandaloneCisdUpSeries(), ...buildConfirmUpTail()]
    const w1 = evaluateBosChochCisdStrategy(full.slice(0, 6), 'LL_TEST', {}, { callRules: CALL_CISD, putRules: [] }, {})
    ok(w1.action === 'HOLD' && w1.reason.includes('ARMÉE'), 'L_Lucien : CISD Up seul → HOLD ARMÉ', w1.reason.slice(0, 90))
    for (let k = 6; k <= 8; k++) {
      evaluateBosChochCisdStrategy(full.slice(0, k + 1), 'LL_TEST', {}, { callRules: CALL_CISD, putRules: [] }, {})
    }
    const w9 = evaluateBosChochCisdStrategy(full.slice(0, 10), 'LL_TEST', {}, { callRules: CALL_CISD, putRules: [] }, {})
    ok(w9.action === 'CALL' && w9.cisdConfirmation != null, 'L_Lucien : combiné après armement → CALL', w9.action)
    markBosChochCisdTraded('LL_TEST', w9.candleTime)
    const w9b = evaluateBosChochCisdStrategy(full.slice(0, 10), 'LL_TEST', {}, { callRules: CALL_CISD, putRules: [] }, {})
    ok(w9b.action === 'HOLD' && w9b.reason.includes('déjà tradée'), 'L_Lucien : garde un-ordre-par-bougie', w9b.reason.slice(0, 80))
    /* asset distinct : séquences indépendantes */
    const other = evaluateBosChochCisdStrategy(full.slice(0, 10), 'LL_OTHER', {}, { callRules: CALL_CISD, putRules: [] }, {})
    ok(other.action === 'HOLD' && other.reason.includes('SANS CISD Up vérifié'), 'L_Lucien : autre asset sans armement → combiné refusé (isolation)', other.reason.slice(0, 100))
    /* reset : état CISD remis à zéro */
    resetBosChochCisdState('LL_TEST')
    const w9c = evaluateBosChochCisdStrategy(full.slice(0, 10), 'LL_TEST', {}, { callRules: CALL_CISD, putRules: [] }, {})
    ok(w9c.action === 'HOLD' && w9c.reason.includes('SANS CISD Up vérifié'), 'L_Lucien : reset → séquence CISD vierge (combiné refusé)', w9c.reason.slice(0, 100))

    /* 4.2 Ninja : armement sur bougie EN FORMATION, confirmation AVANT clôture */
    resetNinjaProTraderState()
    const base = buildStandaloneCisdUpSeries()
    const closed5 = base.slice(0, 5)
    const forming5 = { ...base[5] }
    const n1 = evaluateNinjaProTraderStrategy(closed5, forming5, 'NINJA_TEST', { callRules: CALL_CISD, putRules: [] }, {})
    ok(n1.action === 'HOLD' && n1.reason.includes('ARMÉE'), 'Ninja : CISD Up sur bougie en formation → HOLD ARMÉ', n1.reason.slice(0, 90))
    /* même bougie devient combinée (close retombe) → refus (deux signaux distincts) */
    const forming5b = { ...base[5], close: 11.8 }
    const n1b = evaluateNinjaProTraderStrategy(closed5, forming5b, 'NINJA_TEST', { callRules: CALL_CISD, putRules: [] }, {})
    ok(n1b.action === 'HOLD' && n1b.reason.includes('SANS CISD Up vérifié'), 'Ninja : combiné sur la MÊME bougie → REFUS', n1b.reason.slice(0, 100))
    /* la bougie re-devient standalone à la clôture → re-armement (auto-guérison) */
    const n1c = evaluateNinjaProTraderStrategy(closed5, forming5, 'NINJA_TEST', { callRules: CALL_CISD, putRules: [] }, {})
    ok(n1c.action === 'HOLD' && n1c.reason.includes('ARMÉE'), 'Ninja : bougie revenue standalone → re-armement', n1c.reason.slice(0, 90))
    /* bougies 6-8 en formation (sans événement) puis bougie 9 combinée → CALL AVANT clôture */
    const fullN = [...base, ...buildConfirmUpTail()]
    for (let k = 6; k <= 8; k++) {
      const r = evaluateNinjaProTraderStrategy(fullN.slice(0, k), { ...fullN[k] }, 'NINJA_TEST', { callRules: CALL_CISD, putRules: [] }, {})
      ok(r.action === 'HOLD', `Ninja : bougie ${k} en formation sans événement → HOLD`)
    }
    const n9 = evaluateNinjaProTraderStrategy(fullN.slice(0, 9), { ...fullN[9] }, 'NINJA_TEST', { callRules: CALL_CISD, putRules: [] }, {})
    ok(n9.action === 'CALL' && n9.cisdConfirmation != null, 'Ninja : combiné détecté AVANT la clôture → CALL', n9.action)
    ok(n9.cisdConfirmation?.armedCandleTime === base[5].time, 'Ninja : cisdConfirmation armée sur la bougie 5')
    markNinjaProTraderTraded('NINJA_TEST', n9.candleTime)
    const n9b = evaluateNinjaProTraderStrategy(fullN.slice(0, 9), { ...fullN[9] }, 'NINJA_TEST', { callRules: CALL_CISD, putRules: [] }, {})
    ok(n9b.action === 'HOLD' && n9b.reason.includes('déjà tradée'), 'Ninja : garde un-ordre-par-bougie-en-formation', n9b.reason.slice(0, 80))
    resetNinjaProTraderState('NINJA_TEST')
    const n9c = evaluateNinjaProTraderStrategy(fullN.slice(0, 9), { ...fullN[9] }, 'NINJA_TEST', { callRules: CALL_CISD, putRules: [] }, {})
    ok(n9c.action === 'HOLD' && n9c.reason.includes('SANS CISD Up vérifié'), 'Ninja : reset → séquence CISD vierge', n9c.reason.slice(0, 90))
    /* Ninja miroir DOWN */
    resetNinjaProTraderState()
    const dn = [...buildStandaloneCisdDownSeries(), ...buildConfirmDownTail()]
    const dnF5 = evaluateNinjaProTraderStrategy(dn.slice(0, 5), { ...dn[5] }, 'NINJA_DN', { callRules: [], putRules: PUT_CISD }, {})
    ok(dnF5.action === 'HOLD' && dnF5.reason.includes('ARMÉE'), 'Ninja miroir : CISD Down en formation → HOLD ARMÉ', dnF5.reason.slice(0, 90))
    for (let k = 6; k <= 8; k++) {
      evaluateNinjaProTraderStrategy(dn.slice(0, k), { ...dn[k] }, 'NINJA_DN', { callRules: [], putRules: PUT_CISD }, {})
    }
    const dnF9 = evaluateNinjaProTraderStrategy(dn.slice(0, 9), { ...dn[9] }, 'NINJA_DN', { callRules: [], putRules: PUT_CISD }, {})
    ok(dnF9.action === 'PUT' && dnF9.cisdConfirmation?.direction === 'down', 'Ninja miroir : combiné avant clôture → PUT ▼', dnF9.action)
  }

  /* ── 5. Strategy Tester : libellé d'ordre avec confirmation CISD ── */
  console.log('\n[5] Strategy Tester — libellé d’ordre (confirmation CISD incluse)')
  {
    const st = createCisdGuardState()
    const a = buildStandaloneCisdUpSeries()
    const full = [...a, ...buildConfirmUpTail()]
    evaluateBosChochCisdOrderRules(a, CALL_CISD, [], { cisdGuard: { state: st } })
    for (let k = 6; k <= 8; k++) {
      evaluateBosChochCisdOrderRules(full.slice(0, k + 1), CALL_CISD, [], { cisdGuard: { state: st } })
    }
    const s9 = evaluateBosChochCisdOrderRules(full.slice(0, 10), CALL_CISD, [], { cisdGuard: { state: st } })
    const label = buildLucienBacktestOrderLabel(s9, CALL_CISD as never)
    ok(label.startsWith('L_Lucien ProTrader · CALL ▲ · call-1 [CISD Up] · sans validation · EXP: 60s · CISD Up confirmé')
      || label.startsWith('Ninja ProTrader · CALL ▲ · call-1 [CISD Up] · sans validation · EXP: undefineds · CISD Up confirmé')
      || (label.includes('call-1 [CISD Up]') && label.includes('CISD Up confirmé'))
      || label.includes('call-1 [CISD Up] · sans validation'),
      'libellé backtest : « CISD Up confirmé (armé bougie T, swing P intact) »', label)
    ok(label.includes(`armé bougie ${a[5].time}`) && label.includes('swing 11.2 intact'), 'libellé backtest : bougie d’armement + swing documentés', label.slice(-90))
    const legacy = buildLucienBacktestOrderLabel(
      { action: 'CALL', matchedRuleId: 'call-1', confidence: 0.75, reason: '', events: [], candleTime: 1 },
      CALL_CISD as never,
    )
    ok(!legacy.includes('confirmé'), 'libellé backtest : pas de segment CISD sans confirmation', legacy)
  }

  /* ── 6. vérifications sources (câblage backend / front / backtester) ── */
  console.log('\n[6] Câblage — sources')
  {
    const read = (p: string) => readFileSync(p, 'utf8')
    const shared = read('shared/bos-choch-cisd.ts')
    ok(shared.includes('export function createCisdGuardState') && shared.includes('export function updateCisdGuard')
      && shared.includes('export function checkSwingHighIntact') && shared.includes('export function checkSwingLowIntact')
      && shared.includes('export function ruleRequiresCisdGuard'), 'shared : primitives + machine à états exportées')
    ok(shared.includes('cisdGuard?: CisdGuardHandle'), 'shared : option cisdGuard sur l’évaluation')
    const lucienWrap = read('mini-services/iqoption-backend/bos-choch-cisd-strategy.ts')
    ok(lucienWrap.includes('cisdGuard: { state: getCisdGuardState(asset), config: options.cisdGuardConfig }'), 'backend L_Lucien : état de garde CISD par asset + config v24 passés à l’évaluation')
    ok(lucienWrap.includes('cisdGuardStates.delete(asset)') && lucienWrap.includes('cisdGuardStates.clear()'), 'backend L_Lucien : reset CISD (par asset + global)')
    const ninjaWrap = read('mini-services/iqoption-backend/ninja-protrader-strategy.ts')
    ok(ninjaWrap.includes('cisdGuard: { state: getNinjaCisdGuardState(asset), config: options.cisdGuardConfig }'), 'backend Ninja : état de garde CISD par asset + config v24 passés à l’évaluation')
    ok(ninjaWrap.includes('cisdGuardStates.delete(asset)') && ninjaWrap.includes('cisdGuardStates.clear()'), 'backend Ninja : reset CISD (par asset + global)')
    const index = read('mini-services/iqoption-backend/index.ts')
    ok(index.includes("confirmé (armé bougie ${cisdConfirm.armedCandleTime}, swing ${cisdConfirm.swingPrice} ${cisdConfirm.swingMode === 'violated' ? 'violé' : cisdConfirm.swingMode === 'none' ? 'non vérifié (étape ignorée)' : 'intact'})"),
      'backend index : libellé d’ordre porte la confirmation CISD (mode v24/v25 inclus)')
    ok(index.includes('cisdConfirmation: bcc.cisdConfirmation ?? null'), 'backend index : strategy-state + trade-opened transportent la confirmation CISD')
    const backtest = read('src/lib/lucien-backtest.ts')
    ok(backtest.includes('cisdGuard: { state: this.cisdGuards[this.strategy], config: this.settings.cisdGuard }'), 'Strategy Tester : backtester passe l’état de garde CISD + config v24 (état PAR STRATÉGIE v26)')
    ok(backtest.includes('this.cisdGuards = {') && backtest.includes('createCisdGuardState()'), 'Strategy Tester : reset du backtester réinitialise les séquences CISD (une par stratégie v26)')
    const panel = read('src/components/trading/auto-trade-panel.tsx')
    ok(panel.includes('Vérification CISD — étapes optionnelles'), 'UI : bloc « Vérification CISD » (v24 : étapes optionnelles) dans le panneau Auto Trade')
  }

  console.log(`\n═══ RÉSULTAT v23 : ${pass} ✓ · ${fail} ✗ ═══`)
  process.exit(fail > 0 ? 1 : 0)
}

main().catch((err) => { console.error(err); process.exit(1) })
