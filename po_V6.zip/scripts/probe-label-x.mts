/**
 * probe-label-x.ts — inspecte les valeurs x brutes des drawings piner
 * (labels vs lignes) pour comprendre l'unité/le décalage.
 */
import { readFileSync } from 'node:fs'

const backing = new Map<string, string>()
;(globalThis as any).window = {
  localStorage: {
    getItem: (k: string) => backing.get(k) ?? null,
    setItem: (k: string, v: string) => { backing.set(k, String(v)) },
    removeItem: (k: string) => { backing.delete(k) },
  },
}

const { importLibraryBundle, listLibraries, removeLibrary } = await import('../src/lib/pine-libraries')
const { runPineScript } = await import('../src/lib/pine-engine')

const base = '/home/z/my-project/upload/pine_full_pack_extracted/pine_full_pack'
const rd = (p: string) => readFileSync(`${base}/${p}`, 'utf8')
const mainSrc = rd('Main.pine')
importLibraryBundle([
  { name: 'Main.pine', source: mainSrc },
  { name: 'PubLibSwing.pine', source: rd('libs/PubLibSwing.pine') },
  { name: 'PubLibTrend.pine', source: rd('libs/PubLibTrend.pine') },
  { name: 'PubLibUtility.pine', source: rd('libs/PubLibUtility.pine') },
  { name: 'PubLibCandleTrend.pine', source: rd('libs/PubLibCandleTrend.pine') },
])

const raw = JSON.parse(readFileSync('/home/z/my-project/scripts/dataset-eurusd-m1.json', 'utf8'))
const candles = (raw.candles ?? raw).map((c: any) => ({
  time: Number(c.time) * 1000,
  open: Number(c.open), high: Number(c.high), low: Number(c.low), close: Number(c.close),
  volume: Number(c.volume) || 0,
}))

const res = await runPineScript(mainSrc, candles, { symbol: 'EURUSD_otc', timeframe: '1' })
if (!res.ok) { console.error('ÉCHEC', (res as any).error?.message); process.exit(1) }

const labels = res.result.drawings.filter((d: any) => d.kind === 'label') as any[]
const lines = res.result.drawings.filter((d: any) => d.kind === 'line') as any[]

console.log('candles[0].time =', candles[0].time, ' candles[last].time =', candles[candles.length - 1].time)
console.log('\n— 8 premiers labels —')
for (const l of labels.slice(0, 8)) console.log(JSON.stringify({ x: l.x, y: l.y, text: l.text }))
console.log('\n— 8 derniers labels —')
for (const l of labels.slice(-8)) console.log(JSON.stringify({ x: l.x, y: l.y, text: l.text }))
console.log('\n— 4 premières lignes —')
for (const l of lines.slice(0, 4)) console.log(JSON.stringify({ x1: l.x1, y1: l.y1, x2: l.x2, y2: l.y2 }))

/* les x labels tombent-ils exactement sur des temps de bougie ? */
const times = new Set(candles.map((c: any) => Number(c.time)))
let exact = 0, plusGrand = 0, plusPetit = 0, modulo = 0
for (const l of labels) {
  const x = Number(l.x)
  if (times.has(x)) exact++
  else if (x > candles[candles.length - 1].time) plusGrand++
  else if (x < candles[0].time) plusPetit++
  else modulo++
  if (x % 60000 !== 0) modulo++
}
console.log(`\nlabels : exact=${exact} > dernier=${plusGrand} < premier=${plusPetit}, x%60000!=0 → ${modulo}`)
/* correspondance temps→barre pour un x non exact */
const l0 = labels[0]
console.log('label[0].x =', l0.x, '→ temps/bougie ?', candles.findIndex((c: any) => Number(c.time) === Number(l0.x)))

/* valeurs size/textcolor brutes */
const sizes = new Set<string>(), textcol = new Set<string>(), styles = new Set<string>()
for (const l of labels) {
  sizes.add(JSON.stringify(l.size)); textcol.add(JSON.stringify(l.textcolor)); styles.add(JSON.stringify(l.style))
}
console.log('\nsize values:', [...sizes])
console.log('textcolor values:', [...textcol])
console.log('style values:', [...styles])
