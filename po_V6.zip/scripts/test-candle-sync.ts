/**
 * test-candle-sync.ts — Tests du CandleSyncManager (§20 + §22 + §23 du ToDo).
 *
 * COUVERTURE :
 *   T1  historique + live avec recouvrement → fusion par bucket, priorités §14 ;
 *   T2  historique contenant la bougie en formation → le LIVE gagne ;
 *   T3  réponse historique obsolète (génération / contexte inactif) → IGNORÉE ;
 *   T4  changement rapide de timeframe S5→S30→M1→M5→S5 → ni saut ni doublon ;
 *   T5  trou détecté → réparé depuis un historique ciblé → SYNCED ;
 *   T6  tick ancien / rejoué ignoré (jamais de ré-ouverture) ;
 *   T7  NON-DÉCALAGE entre timeframes (§22) : S5/S30/M1/M5 depuis les MÊMES
 *       ticks — frontières S30 ⊂ frontières S5, deltas === période ;
 *   T8  clôture UNE seule fois par (asset, period, bougie) — callbacks ;
 *   T9  switchAsset : purge du buffer, séries vierges, générations invalidées ;
 *   T10 diagnostics : rapport de sync, événements [SYNC], machine d'état.
 *
 * Exécution : cd mini-services/iqoption-backend && node --import tsx ../../scripts/test-candle-sync.ts
 */
import {
  CandleSyncManager, type CandleSeries,
} from '../mini-services/iqoption-backend/candle-sync-manager.js';
import { bucketStart } from '../mini-services/iqoption-backend/timeframe.js';
import type { CandleLike } from '../mini-services/iqoption-backend/candle-builder.js';

let pass = 0, fail = 0;
const ok = (name: string, cond: boolean, detail = '') => {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); }
};

const ASSET = 'EURUSD_otc';

/** Fabrique des ticks continus à ~2/seconde sur [t0, t0+durationSec). */
function makeTicks(t0: number, durationSec: number, basePrice = 1.16430): Array<{ marketTimeSec: number; price: number }> {
  const out: Array<{ marketTimeSec: number; price: number }> = [];
  for (let s = 0; s < durationSec; s++) {
    out.push({ marketTimeSec: t0 + s, price: basePrice + (s % 17) * 0.00003 });
    out.push({ marketTimeSec: t0 + s + 0.5, price: basePrice + ((s + 3) % 17) * 0.00003 });
  }
  return out;
}

/** Fabrique une série de bougies alignée consécutive. */
function makeCandles(startBucket: number, n: number, period: number, basePrice = 1.16430): CandleLike[] {
  const out: CandleLike[] = [];
  for (let i = 0; i < n; i++) {
    const t = startBucket + i * period;
    out.push({
      time: t, open: basePrice + i * 0.00001, high: basePrice + i * 0.00001 + 0.0002,
      low: basePrice + i * 0.00001 - 0.0002, close: basePrice + i * 0.00001 + 0.0001, volume: 30,
    });
  }
  return out;
}

/** Vérifie les invariants d'une série canonique. */
function checkSeries(name: string, series: CandleSeries, period: number, expectForming: boolean): boolean {
  const all = [...series.closed, ...(series.forming ? [series.forming] : [])];
  const aligned = all.every(c => c.time % period === 0);
  const sorted = all.every((c, i) => i === 0 || all[i - 1].time < c.time);
  const unique = new Set(all.map(c => c.time)).size === all.length;
  const formingOk = expectForming ? series.forming !== null : series.forming === null;
  const formingAfter = !series.forming || series.closed.length === 0
    || series.forming.time > series.closed[series.closed.length - 1].time;
  const okAll = aligned && sorted && unique && formingOk && formingAfter;
  if (!okAll) console.log(`    [${name}] aligned=${aligned} sorted=${sorted} unique=${unique} formingOk=${formingOk} formingAfter=${formingAfter}`);
  return okAll;
}

// ─────────────────────────────────────────────────────────────────────────────

console.log('══ T1 — Historique + live avec recouvrement : fusion par bucket (§5/§6/§14) ══');
{
  const sync = new CandleSyncManager({ periods: [5, 30] });
  // Live : ticks sur [100000, 100075) → bougies S5 100000..100070 (formation 100070)
  const liveTicks = makeTicks(100000, 75);
  for (const t of liveTicks) sync.ingestTick(ASSET, t);
  const lastTick = liveTicks[liveTicks.length - 1].marketTimeSec; // 100074.5
  const currentBucket = bucketStart(lastTick, 5); // 100070

  // Historique broker : bougies S5 99500..100070 (recouvrement : 100000..100070)
  const history = makeCandles(99500, 115, 5); // 99500..100070
  const gen = sync.beginHistoryLoad(ASSET, 5);
  const res = sync.ingestHistory(ASSET, 5, history, { generation: gen, source: 'history' });

  ok('fusion acceptée', res.accepted);
  ok('état SYNCED (aucun trou)', res.report.state === 'SYNCED', `state=${res.report.state}`);
  ok('recouvrement compté : 15 buckets communs (100000..100070)',
    res.report.lastMerge?.overlapBuckets === 15, `overlap=${res.report.lastMerge?.overlapBuckets}`);
  ok('bougie en formation = bucket courant marché (100070)',
    res.series.forming?.time === currentBucket);
  ok('série canonique : alignée + triée + unique + formation en dernier',
    checkSeries('T1', res.series, 5, true));
  ok('le close de la formation = dernier PRIX TICKÉ (live gagne sur le bucket en formation)',
    Math.abs((res.series.forming?.close ?? 0) - liveTicks[liveTicks.length - 1].price) < 1e-12);
  // Bougie clôturée présente dans les DEUX sources → l'historique broker gagne (§14)
  const overlapClosed = res.series.closed.find(c => c.time === 100065);
  const histCandle = history.find(c => c.time === 100065);
  ok('bougie clôturée du recouvrement : valeur HISTORIQUE broker conservée (§14)',
    !!overlapClosed && !!histCandle && overlapClosed.open === histCandle.open && overlapClosed.volume === histCandle.volume);
  ok('nb total = 115 buckets (99500..100070) — un seul bucket par timestamp',
    res.series.closed.length + (res.series.forming ? 1 : 0) === 115,
    `got ${res.series.closed.length + (res.series.forming ? 1 : 0)}`);
}

console.log('══ T2 — Historique contenant la bougie en formation : le LIVE gagne (§5) ══');
{
  const sync = new CandleSyncManager({ periods: [30] });
  // Live : ticks sur [99990, 100010) → S30 : 99990, 100020 en fait bucketStart(99990,30)=99990
  const liveTicks = makeTicks(99990, 20);
  for (const t of liveTicks) sync.ingestTick(ASSET, t);
  const lastTick = liveTicks[liveTicks.length - 1].marketTimeSec;
  const currentBucket = bucketStart(lastTick, 30);

  // Historique qui CONTIENT la bougie en formation avec des prix DIFFÉRENTS
  const history = makeCandles(99930, 3, 30, 9.99999); // 99930, 99960, 99990(=formation)
  const formingHist = history[history.length - 1];
  const res = sync.ingestHistory(ASSET, 30, history, { source: 'history' });

  ok('fusion acceptée', res.accepted);
  ok('une seule bougie pour le bucket courant (pas de doublon formation)',
    res.series.forming !== null && res.series.closed.every(c => c.time !== currentBucket));
  ok('la formation vient du LIVE (close = dernier tick), PAS de l\'historique',
    Math.abs((res.series.forming?.close ?? 0) - liveTicks[liveTicks.length - 1].price) < 1e-12
    && res.series.forming!.close !== formingHist.close);
  ok('les bougies clôturées de l\'historique sont conservées',
    res.series.closed.length === 2 && res.series.closed[0].time === 99930 && res.series.closed[1].time === 99960);
}

console.log('══ T3 — Réponse historique obsolète : IGNORÉE (§17) ══');
{
  const sync = new CandleSyncManager({ periods: [5, 30, 60] });
  for (const t of makeTicks(100000, 30)) sync.ingestTick(ASSET, t);

  // Scénario .har : requête A (S5) → changement de TF → requête B (S30) → réponse A arrive APRÈS B
  const genA = sync.beginHistoryLoad(ASSET, 5);
  sync.switchPeriod(ASSET, 30); // ← changement de timeframe, génération S5 inchangée mais contexte actif = 30
  const stale = sync.ingestHistory(ASSET, 5, makeCandles(99500, 100, 5), { generation: genA, source: 'history' });
  ok('réponse A (S5) après switch → 30 : REJETÉE (période inactive)',
    !stale.accepted && stale.reason === 'inactive-period', `reason=${stale.reason}`);

  // Par génération : requête S30 → switchAsset (TOUTES les générations de
  // l'actif sont invalidées) → réponse S30 avec l'ancienne génération
  const genB = sync.beginHistoryLoad(ASSET, 30);
  sync.switchAsset(ASSET); // purge + générations invalidées
  const staleB = sync.ingestHistory(ASSET, 30, makeCandles(99500, 20, 30), { generation: genB, source: 'history' });
  ok('réponse avec génération périmée : REJETÉE (stale-generation)',
    !staleB.accepted && staleB.reason === 'stale-generation', `reason=${staleB.reason}`);

  // La série courante reste INTACTE (la réponse obsolète n'a rien écrasé)
  const current = sync.getSeries(ASSET, 60);
  ok('la synchronisation courante n\'a PAS été écrasée',
    current.closed.length === 0 && current.forming === null);

  // Asset inactif
  sync.setActiveContext(ASSET, 60);
  for (const t of makeTicks(100000, 10)) sync.ingestTick(ASSET, t);
  const staleAsset = sync.ingestHistory('XAUUSD_otc', 60, makeCandles(99500, 20, 60), { source: 'history' });
  ok('réponse d\'un AUTRE actif que l\'actif actif : REJETÉE (inactive-asset)',
    !staleAsset.accepted && staleAsset.reason === 'inactive-asset', `reason=${staleAsset.reason}`);
}

console.log('══ T4 — Changement rapide de timeframe S5→S30→M1→M5→S5 (§11/§23) ══');
{
  const sync = new CandleSyncManager({ periods: [5, 30, 60, 300] });
  // ~20 minutes de ticks continus
  const ticks = makeTicks(100000, 1200);
  for (const t of ticks) sync.ingestTick(ASSET, t);
  const lastTick = ticks[ticks.length - 1].marketTimeSec;

  let prevPeriod = 5;
  for (const period of [30, 60, 300, 5]) {
    // Référence gelée au moment du switch = dernier temps marché vu
    const latestBefore = sync.getLatestMarketTimeSec(ASSET);
    const series = sync.switchPeriod(ASSET, period);
    const all = [...series.closed, ...(series.forming ? [series.forming] : [])];
    ok(`S${prevPeriod}→S${period} : série non vide (${all.length} bougies)`, all.length > 0);
    ok(`S${period} : zéro doublon de timestamp`, new Set(all.map(c => c.time)).size === all.length);
    ok(`S${period} : toutes alignées % ${period} === 0`, all.every(c => c.time % period === 0));
    // Aucun trou artificiel : deltas consécutifs === période (ticks continus)
    const badDeltas = all.filter((c, i) => i > 0 && c.time - all[i - 1].time !== period);
    ok(`S${period} : aucun trou artificiel (deltas === ${period}s)`, badDeltas.length === 0,
      `${badDeltas.length} anomalies: ${badDeltas.slice(0, 3).map(c => c.time).join(',')}`);
    ok(`S${period} : la dernière bougie = bougie EN FORMATION au bucket courant marché`,
      series.forming !== null && series.forming.time === bucketStart(latestBefore, period));
    // Le tick SUIVANT continue la même bougie (aucun saut)
    const before = sync.getForming(ASSET, period);
    sync.ingestTick(ASSET, { marketTimeSec: latestBefore + 0.75, price: 1.2 });
    const after = sync.getForming(ASSET, period);
    ok(`S${period} : le tick suivant CONTINUE la formation (même bucket, pas de saut)`,
      after !== null && before !== null && after.time === before.time && Math.abs(after.close - 1.2) < 1e-12);
    prevPeriod = period;
  }
  ok('retour S5 : la série S5 est préservée (retour instantané)', sync.getSeries(ASSET, 5).closed.length > 0);
}

console.log('══ T5 — Trou détecté → réparé depuis un historique ciblé (§13/§16) ══');
{
  const sync = new CandleSyncManager({ periods: [30] });
  // Live récent uniquement
  for (const t of makeTicks(100050, 30)) sync.ingestTick(ASSET, t);
  // Historique avec un TROU : 99900..99960 puis 100020..100050 (manque 99990)
  const history = [
    ...makeCandles(99900, 3, 30),  // 99900, 99930, 99960
    // TROU : 99990 manquante (60 s de trou → 1 bougie)
    ...makeCandles(100050 - 30, 2, 30), // 100020, 100050
  ];
  const gen = sync.beginHistoryLoad(ASSET, 30);
  const res = sync.ingestHistory(ASSET, 30, history, { generation: gen, source: 'history' });
  ok('état GAP_DETECTED après fusion trouée', res.report.state === 'GAP_DETECTED', `state=${res.report.state}`);
  ok('1 trou détecté avec 1 bougie manquante (99990)',
    res.report.gaps.length === 1 && res.report.gaps[0].missingCandles === 1 && res.report.gaps[0].startTime === 99990,
    JSON.stringify(res.report.gaps));

  // Deux réparations concurrentes interdites (§16)
  const r1 = sync.requestRepair(ASSET, 30);
  const r2 = sync.requestRepair(ASSET, 30);
  ok('première réparation autorisée', r1.started);
  ok('réparation CONCURRENTE refusée (état REPAIRING)', !r2.started);

  // Réparation : fetch ciblé de la bougie manquante (+ recouvrement §6)
  const repairCandles = makeCandles(99990, 1, 30); // 99990
  const repaired = sync.ingestHistory(ASSET, 30, repairCandles, { generation: r1.generation, source: 'history' });
  ok('réparation acceptée', repaired.accepted, `reason=${repaired.reason}`);
  ok('état SYNCED après réparation (trou comblé)', repaired.report.state === 'SYNCED', `state=${repaired.report.state}`);
  ok('plus aucun trou', repaired.report.gaps.length === 0);
  const all = [...repaired.series.closed, ...(repaired.series.forming ? [repaired.series.forming] : [])];
  ok('la série réparée est consécutive (deltas === 30)',
    all.every((c, i) => i === 0 || c.time - all[i - 1].time === 30));
}

console.log('══ T6 — Tick ancien / rejoué : ignoré, aucune ré-ouverture (§8) ══');
{
  const sync = new CandleSyncManager({ periods: [5, 30] });
  const ticks = makeTicks(100000, 60);
  for (const t of ticks) sync.ingestTick(ASSET, t);
  const lastTick = ticks[ticks.length - 1].marketTimeSec;
  const bufLen = sync.getTickBuffer(ASSET).length;

  // Tick rejoué (timestamp <= dernier temps marché)
  const dup = sync.ingestTick(ASSET, { marketTimeSec: lastTick, price: 9.99 });
  ok('tick rejoué (même timestamp) : droppé', !dup.applied && dup.reason === 'duplicate');
  const late = sync.ingestTick(ASSET, { marketTimeSec: lastTick - 10, price: 8.88 });
  ok('tick en retard (timestamp antérieur) : droppé', !late.applied && late.reason === 'duplicate');
  ok('le buffer de ticks n\'a pas été pollué', sync.getTickBuffer(ASSET).length === bufLen);

  // La série reste intacte : aucune bougie clôturée modifiée
  const s30 = sync.getSeries(ASSET, 30);
  const dupCandle = s30.closed.find(c => c.close === 9.99 || c.close === 8.88);
  ok('aucun prix de tick rejoué n\'a contaminé la série', !dupCandle);
  ok('latestMarketTimeSec inchangé', sync.getLatestMarketTimeSec(ASSET) === lastTick);

  // Un tick FUTUR normal reprend le cours normal
  const next = sync.ingestTick(ASSET, { marketTimeSec: lastTick + 0.5, price: 1.5 });
  ok('le tick suivant (futur) est accepté normalement', next.applied);
}

console.log('══ T7 — NON-DÉCALAGE entre timeframes : même fenêtre de ticks (§22) ══');
{
  const sync = new CandleSyncManager({ periods: [5, 30, 60, 300] });
  // 900 s de ticks continus + un VRAI trou de marché de 300 s (aligné sur la
  // grille M5 → exactement 1 bucket M5, 5 buckets M1, 10 S30, 60 S5 manquants)
  // + 300 s de ticks.
  const base = 99900; // 99900 % 300 === 0 ✓ % 60 === 0 ✓ % 30 === 0 ✓ % 5 === 0 ✓
  const HOLE = 300;
  const part1 = makeTicks(base, 900);              // [99900, 100800)
  const part2 = makeTicks(base + 900 + HOLE, 300); // trou [100800, 101100)
  const ticks = [...part1, ...part2];
  for (const t of ticks) sync.ingestTick(ASSET, t);
  const lastTick = ticks[ticks.length - 1].marketTimeSec;

  for (const period of [5, 30, 60, 300]) {
    const series = sync.getSeries(ASSET, period);
    const all = [...series.closed, ...(series.forming ? [series.forming] : [])];
    ok(`S${period} : firstTime % ${period} === 0`, all.length > 0 && all[0].time % period === 0);
    ok(`S${period} : lastTime % ${period} === 0`, all[all.length - 1].time % period === 0);
    ok(`S${period} : la formation couvre le dernier tick`,
      series.forming !== null && series.forming.time === bucketStart(lastTick, period));
    // Deltas === période SAUF le vrai trou de marché (300 s)
    const deltas = all.slice(1).map((c, i) => c.time - all[i].time);
    const abnormal = deltas.filter(d => d !== period && d !== period + HOLE);
    ok(`S${period} : deltas === ${period}s sauf le VRAI trou de marché (+${HOLE}s)`,
      abnormal.length === 0 && deltas.some(d => d === period + HOLE),
      `abnormal=${JSON.stringify(abnormal)}`);
    ok(`S${period} : jamais de bougie synthétique dans le trou`,
      all.every(c => c.time < base + 900 || c.time >= base + 900 + HOLE));
  }

  // Frontières S30 ⊂ frontières S5 ; M5 ⊂ M1 (§22)
  const s5Times = new Set(sync.getSeries(ASSET, 5).closed.map(c => c.time));
  const s30Times = sync.getSeries(ASSET, 30).closed.map(c => c.time);
  ok('chaque frontière S30 est une frontière S5 (bougies S30 ⊆ bougies S5)',
    s30Times.every(t => t % 5 === 0 && s5Times.has(t)));
  const m1Times = new Set(sync.getSeries(ASSET, 60).closed.map(c => c.time));
  const m5Times = sync.getSeries(ASSET, 300).closed.map(c => c.time);
  ok('chaque frontière M5 est une frontière M1 (bougies M5 ⊆ bougies M1)',
    m5Times.every(t => t % 60 === 0 && m1Times.has(t)),
    `m5=${JSON.stringify(m5Times)} m1=${JSON.stringify([...m1Times])}`);
}

console.log('══ T8 — Clôture UNE seule fois par (asset, period, bougie) ══');
{
  const closures: Array<{ asset: string; period: number; time: number }> = [];
  const sync = new CandleSyncManager({
    periods: [5, 30],
    onCandleClosed: (asset, period, candle) => closures.push({ asset, period: period * 1, time: candle.time }),
  });
  for (const t of makeTicks(99990, 125)) sync.ingestTick(ASSET, t);

  const keys = new Set(closures.map(c => `${c.asset}:${c.period}:${c.time}`));
  ok('aucune clôture en double (clé asset+period+bucket unique)', keys.size === closures.length,
    `${closures.length} clôtures, ${keys.size} clés`);
  const s5Closures = closures.filter(c => c.period === 5).map(c => c.time);
  const s30Closures = closures.filter(c => c.period === 30).map(c => c.time);
  ok(`clôtures S5 = frontières traversées (${s5Closures.length})`, s5Closures.length === 24,
    `got ${s5Closures.length}`);
  ok(`clôtures S30 = frontières traversées (${s30Closures.length})`, s30Closures.length === 4,
    `got ${s30Closures.length}`);
  ok('clôtures alignées sur leurs grilles respectives',
    s5Closures.every(t => t % 5 === 0) && s30Closures.every(t => t % 30 === 0));

  // Re-seed (historique) ne déclenche AUCUNE clôture supplémentaire
  const before = closures.length;
  sync.ingestHistory(ASSET, 30, makeCandles(99600, 15, 30), { source: 'history' });
  ok('un seed d\'historique ne déclenche aucune clôture', closures.length === before);
}

console.log('══ T9 — switchAsset : purge + générations invalidées ══');
{
  const sync = new CandleSyncManager({ periods: [5, 30] });
  for (const t of makeTicks(100000, 60)) sync.ingestTick(ASSET, t);
  ok('buffer de ticks alimenté', sync.getTickBuffer(ASSET).length === 120);

  sync.switchAsset(ASSET);
  ok('buffer PURGÉ après switchAsset', sync.getTickBuffer(ASSET).length === 0);
  ok('latestMarketTimeSec remis à zéro', sync.getLatestMarketTimeSec(ASSET) === 0);
  const s = sync.getSeries(ASSET, 5);
  ok('séries remises à zéro (DISCONNECTED, vides)',
    s.closed.length === 0 && s.forming === null);
  ok('état DISCONNECTED', sync.getSyncReport(ASSET, 5).state === 'DISCONNECTED');

  // Génération invalidée : une réponse historique en vol est rejetée
  const stale = sync.ingestHistory(ASSET, 5, makeCandles(99500, 20, 5), { generation: 0, source: 'history' });
  ok('réponse historique d\'avant le switch : REJETÉE (génération)',
    !stale.accepted && stale.reason === 'stale-generation', `reason=${stale.reason}`);

  // Les ticks du NOUVEL actif démarrent une nouvelle chronologie
  sync.ingestTick(ASSET, { marketTimeSec: 200000, price: 1.1 });
  ok('le premier tick après switchAsset démarre une nouvelle série',
    sync.getForming(ASSET, 5)?.time === 200000);
}

console.log('══ T10 — Diagnostics : rapport + événements [SYNC] (§19) ══');
{
  const events: Array<{ type: string; asset: string; periodSec: number }> = [];
  const sync = new CandleSyncManager({
    periods: [5, 30],
    onSyncEvent: e => events.push({ type: e.type, asset: e.asset, periodSec: e.periodSec }),
  });
  for (const t of makeTicks(99990, 45)) sync.ingestTick(ASSET, t);
  const gen = sync.beginHistoryLoad(ASSET, 5);
  sync.ingestHistory(ASSET, 5, makeCandles(99900, 25, 5), { generation: gen, source: 'history' });

  const report = sync.getSyncReport(ASSET, 5);
  ok('rapport : asset + period + état SYNCED', report.asset === ASSET && report.periodSec === 5 && report.state === 'SYNCED');
  ok('rapport : latestMarketTimeSec = dernier tick marché',
    report.latestMarketTimeSec === 99990 + 44.5, `got ${report.latestMarketTimeSec}`);
  ok('rapport : historyRange renseigné', report.historyRange?.[0] === 99900 && report.historyRange?.[1] === 100020);
  ok('rapport : lastMerge avec merged/duplicates/overlapBuckets',
    report.lastMerge !== null && typeof report.lastMerge.merged === 'number'
    && typeof report.lastMerge.overlapBuckets === 'number');
  ok('rapport : gaps vides (SYNCED)', report.gaps.length === 0);
  ok('rapport : builderStats présents',
    typeof report.builderStats.ticksAccepted === 'number' && typeof report.builderStats.candlesClosed === 'number');

  ok('événements [SYNC] capturés (history-loaded)',
    events.some(e => e.type === 'history-loaded' && e.asset === ASSET));
  ok('getRecentSyncEvents : 100 derniers en mémoire', sync.getRecentSyncEvents(100).length >= 1);
  ok('getAllReports : tous les timeframes de l\'actif', sync.getAllReports(ASSET).length === 2);

  // validate() : état recalculé depuis la série réelle
  const v = sync.validate(ASSET, 5);
  ok('validate() retourne le rapport cohérent', v.state === 'SYNCED');
}

console.log('');
console.log('════════════════════════════════════');
console.log(`  RÉSULTAT : ${pass} PASS / ${fail} FAIL`);
console.log('════════════════════════════════════');
process.exit(fail > 0 ? 1 : 0);
