#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v16.sh — Livraison v16 « Martingale BOS sur broker RÉEL »
#
# Le besoin (message utilisateur) : « install les dépendances, fait un login
# avec les identifiants par défaut, dans auto trade sélectionne BOS CHoCH &
# CISD, ajoute des combinaisons de CALL et PUT, expiration 3s, timeframe S5,
# mise de base 500, active martingale, réalise 20 ordres et vérifie que la
# martingale fonctionne » — car en conditions réelles « à chaque ordre échoué
# sans gain la mise n'est pas doublée et les ordres continuent sur la mise
# de base ».
#
# La cause racine (prouvée par capture du trafic réel 2026-09-17) : le broker
# publie chaque règlement via l'event « successcloseOrder » sous la forme
#   { "profit": <RETOUR TOTAL (mise + gain)>, "deals": [ <deal complet> ] }
# Le SDK parsait `data.deal ?? data` — l'ENVELOPPE (sans id ni asset) →
# ClosedDeal { id: 0, asset: '', profit: retour total } → le backend ne
# pouvait JAMAIS attribuer le règlement → la Martingale ne voyait JAMAIS les
# résultats → mise figée sur la base. Correctifs :
#   1. SDK client.ts successcloseOrder → lit data.deals[0] (le vrai deal :
#      UUID, asset, profit NET, prix, command 0/1, timestamps Unix) ;
#   2. SDK parseClosedDeal/parseOpenedDeal → champs natifs command +
#      openTimestamp/closeTimestamp (les strings datetime donnaient NaN et
#      vidaient les fenêtres temporelles de l'empreinte) ;
#   3. Mock broker : option realtimeClosePush — reproduit le chemin réel ;
#   4. Tests réparés : winwin-e2e (état par asset du mock v2),
#      multi-e2e (drain final watchdog + tolérance tie) ;
#   5. Scripts de test réel rejouables : test-real-bos-martingale.mjs +
#      verify-real-report.mjs (verdict 9/9 sur broker réel : 16 transitions
#      strictes LOSS→×2 / WIN→500, 0 règlement dégradé).
#
# Sortie : /home/z/my-project/download/pine_v6_engine_v16_real_broker_fix.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v16"
FOLDER=pine_v6_engine
OUT="$ROOT/download/pine_v6_engine_v16_real_broker_fix.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (structure identique au zip v15) ──────────────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude '.logs/' \
  --exclude '*.log' \
  --exclude 'e2e-bos-martingale.log' \
  --exclude 'e2e-bos-multi.log' \
  --exclude 'mini-services/iqoption-backend/data/backend-session.json' \
  --exclude 'mini-services/iqoption-backend/data/candle-cache/' \
  --exclude 'db/' \
  "$ROOT/pine_v6_engine/" "$STAGE/$FOLDER/"

# ── README de la version v16 ─────────────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.6-V16-REAL-BROKER-MARTINGALE.md" <<'EOF'
# Pine v6 Engine — v16 « Martingale BOS sur broker RÉEL »

## Le bug que vous avez constaté

En conditions réelles (identifiants par défaut, Auto Trade BOS CHoCH & CISD) :
**à chaque ordre perdu, la mise n'était PAS doublée** — les ordres
s'enchaînaient indéfiniment sur la mise de base.

## La cause racine (prouvée par capture du trafic réel)

Le broker Pocket Option publie chaque règlement via l'événement WebSocket
`successcloseOrder` sous cette forme :

```json
{ "profit": 960,
  "deals": [ { "id": "be8d12db-4478-…", "asset": "EURUSD_otc",
               "amount": 500, "profit": 460,
               "openPrice": 1.16731, "closePrice": 1.16723,
               "command": 1, "openTimestamp": 1789672146,
               "closeTimestamp": 1789672149, … } ] }
```

Le champ `profit` de l'ENVELOPPE est le **retour total** (mise + gain) ; le
vrai résultat vit dans `deals[0]` : l'UUID de l'ordre, l'asset, le profit
NET, les prix d'entrée/sortie, la direction (`command` : 0 = CALL, 1 = PUT)
et les horodatages Unix (`openTimestamp`/`closeTimestamp` — les champs
`openTime`/`closeTime` sont des strings datetime, pas des nombres).

Le SDK lisait `data.deal ?? data` — c'est-à-dire **l'enveloppe** (sans id ni
asset) → le backend recevait `deal #0, asset vide` → impossible de rattacher
le règlement à l'ordre suivi → `applyDealResult()` jamais appelé → la
Martingale ne voyait **aucun** résultat → mise figée sur la base. C'est
EXACTEMENT votre symptôme. (Les tests automatisés passaient car le faux
broker publiait les règlements dans un autre format.)

## Les correctifs

1. **SDK — `successcloseOrder`** : lit `data.deals[0]` (le vrai deal).
2. **SDK — parsing natif** : `command` (0/1) → action CALL/PUT ;
   `openTimestamp`/`closeTimestamp` → secondes Unix (les strings datetime
   donnaient `NaN`, ce qui vidait AUSSI les fenêtres temporelles du
   rattachement par empreinte et laissait des deals fantômes du cache
   broker se rattacher par erreur).
3. **Mock broker (tests)** : nouvelle option `realtimeClosePush` qui
   reproduit le chemin réel `successcloseOrder` — les E2E couvrent
   désormais cette régression.
4. **Tests réparés** : `test-winwin-e2e` (mock v2 multi-assets : état par
   asset), `test-bos-choch-cisd-multi-e2e` (drain final du watchdog +
   tolérance au tie).
5. **Scripts de test réel rejouables** :
   - `scripts/test-real-bos-martingale.mjs` — login identifiants par défaut,
     2 assets, S5, règles BOS CALL+PUT expiration 3s, base 500, martingale,
     surveillance des ordres/règlements/mises ;
   - `scripts/verify-real-report.mjs` — verdict final (transitions LOSS→×2,
     WIN→base, clamp de solde, règlements dégradés).

## La preuve réelle (2026-09-17, compte démo)

Login `longuilcn@gmail.com` (mode démo), EURUSD_otc + GBPUSD_otc, S5,
règles CALL {BOS Up} + {CHoCH Up, CISD Up} / PUT {BOS Down} + {CHoCH Down,
CISD Down}, expiration 3 s, base 500, martingale :

- **22 ordres BOS** placés sur les 2 assets, tous à 3 s d'expiration ;
- **21/22 réglés en temps réel** (~3 s après l'échéance) avec UUID + asset
  + profit NET + direction — **0** règlement dégradé `deal #0` (l'ancien
  bug en produisait un par ordre) ;
- **16 transitions strictes vérifiées** : chaque LOSS → mise ×2
  (500→1000 ×5, 1000→2000 ×2, 2000→4000), chaque WIN → retour à 500 (×10),
  sans distinction CALL/PUT ;
- 4 dernières mises « clampées » au solde (compte démo épuisé en fin de
  test : 3390 → 0) — comportement normal : on ne peut pas miser plus que
  le solde disponible ;
- séquences : EURUSD `500 →(W) 500 →(W) 500 →(W) 500 →(L) 1000 →(W) 500
  →(L) 1000 →(L) 2000 →(L) 4000 →(W) …` ; GBPUSD `500 →(L) 1000 →(L) 2000
  →(W) 500 …` — chaque asset isolé, l'un n'influence jamais l'autre.

## Comment re-vérifier vous-même

```bash
# 1. Démarrer le backend (terminal 1)
cd mini-services/iqoption-backend && npm run dev

# 2. Lancer le test réel (terminal 2)
node scripts/test-real-bos-martingale.mjs

# 3. Verdict final
node scripts/verify-real-report.mjs
```

Le rapport complet est écrit dans
`download/test-real-bos-martingale-report.json`.

**Note** : le solde démo peut être rechargé à tout moment depuis la
plateforme Pocket Option (modal « Add money to demo account »,
+1 000 / +5 000 / +10 000).
EOF

# ── Zippage ───────────────────────────────────────────────────────────────
cd "$STAGE"
zip -qr "$OUT" "$FOLDER"
cd "$ROOT"
rm -rf "$STAGE"

echo "─ Livraison v16 ──────────────────────────────────────────────"
echo "Zip      : $OUT"
echo "Taille   : $(du -h "$OUT" | cut -f1)"
echo "Fichiers : $(unzip -l "$OUT" | tail -1 | awk '{print $2}')"
echo "Intégrité: $(unzip -t "$OUT" > /dev/null && echo OK || echo ÉCHEC)"
