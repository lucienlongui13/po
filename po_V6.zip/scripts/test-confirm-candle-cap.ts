/**
 * test-confirm-candle-cap.ts — v19/v20 : deux fonctionnalités Auto Trade.
 * ============================================================================
 *
 * 1. SWITCH « CONFIRMATION BOUGIE PRÉCÉDENTE » (L_Lucien ProTrader) :
 *    - CALL ▲ (BOS Up / CHoCH Up / CISD Up) : la bougie PRÉCÉDANT la bougie
 *      signalée doit être BAISSIÈRE (close < open) ;
 *    - PUT ▼ (BOS Down / CHoCH Down / CISD Down) : elle doit être HAUSSIÈRE
 *      (close > open) ;
 *    - doji (close === open) : NEUTRE — ne confirme rien ;
 *    - 1re bougie de la série : aucune précédente → refus ;
 *    - switch OFF : comportement inchangé.
 *
 * 2. GARDE-FOU MARTINGALE (maxMartingaleSteps — sémantique v20) :
 *    - 0 = illimité (comportement historique) ;
 *    - N = nombre MAXIMAL DE MISES dans la séquence (la mise k vaut base×2^(k-1)) ;
 *      si la N-ième mise perd, RETOUR À LA MISE INITIALE (spéc. utilisateur :
 *      « 4 → 10→20→40→80, jamais 160 ; après échec de la 4e, retour à la
 *      mise initiale ») — la « (N+1)-ième mise » n'existe pas ;
 *    - clamp de computeBettingAmount (ceinture+bretelles) ;
 *    - WIN → reset ; TIE/PUSH → neutre ; isolation par asset ; Fibonacci
 *      non affectée.
 *
 * Exécution : npx tsx scripts/test-confirm-candle-cap.ts
 */
import {
  evaluateBosChochCisdOrderRules,
  evaluateBosChochCisd,
  checkPreviousCandleConfirmation,
  isBearishCandle,
  isBullishCandle,
  type BosChochCisdCandle,
} from '../shared/bos-choch-cisd.js'
import { evaluateBosChochCisdStrategy, resetBosChochCisdState, markBosChochCisdTraded } from '../mini-services/iqoption-backend/bos-choch-cisd-strategy.js'
import {
  createAssetContext,
  computeBettingAmount,
  updateBettingAfterResult,
  clampMaxMartingaleSteps,
} from '../mini-services/iqoption-backend/asset-contexts.js'

let pass = 0, fail = 0
function ok(cond: boolean, label: string): void {
  if (cond) { pass++; console.log(`  ✓ ${label}`) }
  else { fail++; console.error(`  ✗ ${label}`) }
}

/* ══════════════ helpers bougies ══════════════ */

/** Bougie verte/rouge avec mèche (w) autour du corps (b). */
function candle(time: number, dir: 'G' | 'R' | 'D', open: number, b = 0.0003, w = 0.0001): BosChochCisdCandle {
  const close = dir === 'G' ? open + b : dir === 'R' ? open - b : open
  const high = Math.max(open, close) + w
  const low = Math.min(open, close) - w
  return { time, open, high, low, close, volume: 100 }
}

/**
 * Série « RGG » répétée : swing highs/lows + uptrend → un événement UP
 * (BOS Up + CISD Up) se déclenche sur chaque 3e bougie (la 2e verte).
 * startOpen contrôle la couleur de la bougie PRÉCÉDANT la bougie signal :
 * c'est toujours une VERTE dans cette série (le 1er G du triplet).
 */
function rggSeries(count: number, startOpen = 1.18): BosChochCisdCandle[] {
  const out: BosChochCisdCandle[] = []
  let open = startOpen
  for (let i = 0; i < count; i++) {
    const dir = (i % 3 === 0) ? 'R' : 'G'
    out.push(candle(i * 5_000, dir, open))
    open = out[out.length - 1].close
  }
  return out
}

/** Série miroir « GRR » : événement DOWN (BOS Down + CISD Down) sur chaque
 *  3e bougie (la 2e rouge) ; la bougie précédente est ROUGE. */
function grrSeries(count: number, startOpen = 1.18): BosChochCisdCandle[] {
  const out: BosChochCisdCandle[] = []
  let open = startOpen
  for (let i = 0; i < count; i++) {
    const dir = (i % 3 === 0) ? 'G' : 'R'
    out.push(candle(i * 5_000, dir, open))
    open = out[out.length - 1].close
  }
  return out
}

/* ══════════════ PARTIE 1 — helpers de confirmation ══════════════ */
console.log('\n─── 1. Helpers bougie de confirmation ───')
ok(isBearishCandle({ time: 0, open: 1.2, high: 1.21, low: 1.19, close: 1.19 }) === true, 'isBearishCandle : close < open → vrai')
ok(isBearishCandle({ time: 0, open: 1.2, high: 1.21, low: 1.19, close: 1.21 }) === false, 'isBearishCandle : close > open → faux')
ok(isBullishCandle({ time: 0, open: 1.2, high: 1.21, low: 1.19, close: 1.21 }) === true, 'isBullishCandle : close > open → vrai')
ok(isBullishCandle({ time: 0, open: 1.2, high: 1.21, low: 1.19, close: 1.2 }) === false, 'isBullishCandle : doji → faux')

{
  const bear = [{ time: 0, open: 1.2, high: 1.21, low: 1.18, close: 1.19 }, { time: 5, open: 1.19, high: 1.21, low: 1.18, close: 1.21 }]
  const r = checkPreviousCandleConfirmation(bear, 'CALL')
  ok(r.confirmed === true && /baissière/.test(r.detail), `CALL confirmé par bougie baissière (${r.detail})`)
  const rPut = checkPreviousCandleConfirmation(bear, 'PUT')
  ok(rPut.confirmed === false && /baissière/.test(rPut.detail), `PUT refusé (précédente baissière) (${rPut.detail})`)
}
{
  const bull = [{ time: 0, open: 1.2, high: 1.22, low: 1.19, close: 1.21 }, { time: 5, open: 1.21, high: 1.22, low: 1.19, close: 1.19 }]
  const r = checkPreviousCandleConfirmation(bull, 'PUT')
  ok(r.confirmed === true && /haussière/.test(r.detail), `PUT confirmé par bougie haussière (${r.detail})`)
  const rCall = checkPreviousCandleConfirmation(bull, 'CALL')
  ok(rCall.confirmed === false && /haussière/.test(rCall.detail), `CALL refusé (précédente haussière) (${rCall.detail})`)
}
{
  const doji = [{ time: 0, open: 1.2, high: 1.21, low: 1.19, close: 1.2 }, { time: 5, open: 1.2, high: 1.21, low: 1.19, close: 1.21 }]
  const rCall = checkPreviousCandleConfirmation(doji, 'CALL')
  const rPut = checkPreviousCandleConfirmation(doji, 'PUT')
  ok(rCall.confirmed === false && /doji/.test(rCall.detail), `CALL refusé sur doji précédente (${rCall.detail})`)
  ok(rPut.confirmed === false && /doji/.test(rPut.detail), `PUT refusé sur doji précédente (${rPut.detail})`)
}
{
  const alone = [{ time: 0, open: 1.2, high: 1.21, low: 1.19, close: 1.21 }]
  const r = checkPreviousCandleConfirmation(alone, 'CALL')
  ok(r.confirmed === false && /aucune bougie précédente/.test(r.detail), `1re bougie : refus explicite (${r.detail})`)
}

/* ══════════════ PARTIE 2 — chemin règles CALL/PUT (orders) ══════════════ */
console.log('\n─── 2. Confirmation — chemin règles CALL/PUT (evaluateBosChochCisdOrderRules) ───')
const CALL_RULES = [{ id: 'call-1', alerts: ['BOS Up'] as any, expirationSeconds: 4 }]
const PUT_RULES = [{ id: 'put-1', alerts: ['BOS Down'] as any, expirationSeconds: 4 }]

{
  // Série RGG : événement UP sur la dernière bougie (2e verte du triplet).
  const series = rggSeries(30) // 30 bougies → dernière = i=29, 29%3=2 → G
  const base = evaluateBosChochCisdOrderRules(series, CALL_RULES, PUT_RULES)
  ok(base.action === 'CALL', `sans confirmation : signal CALL ▲ émis (events: ${base.events.join(', ')})`)
  ok(base.matchedRuleId === 'call-1' && base.expirationSeconds === 4, 'règle + expiration préservées sans confirmation')

  const off = evaluateBosChochCisdOrderRules(series, CALL_RULES, PUT_RULES, { confirmPreviousCandle: false })
  ok(off.action === 'CALL', 'switch OFF : CALL émis (comportement inchangé)')

  // La bougie précédant la bougie signalée (i=28, 28%3=1 → G) est HAUSSIÈRE
  // → la confirmation CALL (qui exige une BAISSIÈRE) doit REFUSER.
  const prev = series[series.length - 2]
  ok(prev.close > prev.open, `précondition : la bougie précédente est haussière (o=${prev.open} c=${prev.close})`)
  const blocked = evaluateBosChochCisdOrderRules(series, CALL_RULES, PUT_RULES, { confirmPreviousCandle: true })
  ok(blocked.action === 'HOLD', 'switch ON + précédente HAUSSIÈRE : CALL refusé → HOLD')
  ok(/REFUSÉ par la confirmation de bougie/.test(blocked.reason), `reason explicite (${blocked.reason})`)
  ok(blocked.candleTime === series[series.length - 1].time, 'candleTime préservé sur le HOLD de confirmation')

  // On RÉÉCRIT la bougie précédente en BAISSIÈRE (close < open) sans toucher
  // à la bougie signalée → la confirmation CALL doit PASSER.
  const mutated = series.slice()
  const p = mutated[mutated.length - 2]
  const newClose = p.open - 0.0002
  mutated[mutated.length - 2] = { ...p, close: newClose, low: Math.min(p.low, newClose) }
  const passed = evaluateBosChochCisdOrderRules(mutated, CALL_RULES, PUT_RULES, { confirmPreviousCandle: true })
  ok(passed.action === 'CALL', 'switch ON + précédente BAISSIÈRE : CALL émis')
  ok(/confirmé par la bougie précédente/.test(passed.reason), `reason porte la confirmation (${passed.reason.slice(0, 120)}…)`)
  ok(passed.matchedRuleId === 'call-1' && passed.expirationSeconds === 4, 'règle + expiration intactes après confirmation')
}
{
  // Série GRR : événement DOWN, précédente ROUGE → PUT refusé si ON,
  // puis précédente réécrite HAUSSIÈRE → PUT passe.
  const series = grrSeries(30)
  const base = evaluateBosChochCisdOrderRules(series, CALL_RULES, PUT_RULES)
  ok(base.action === 'PUT', `sans confirmation : signal PUT ▼ émis (events: ${base.events.join(', ')})`)
  const blocked = evaluateBosChochCisdOrderRules(series, CALL_RULES, PUT_RULES, { confirmPreviousCandle: true })
  ok(blocked.action === 'HOLD', 'switch ON + précédente BAISSIÈRE : PUT refusé → HOLD')
  ok(/exige une bougie haussière/.test(blocked.reason), `reason explicite PUT (${blocked.reason})`)

  const mutated = series.slice()
  const p = mutated[mutated.length - 2]
  const newClose = p.open + 0.0002
  mutated[mutated.length - 2] = { ...p, close: newClose, high: Math.max(p.high, newClose) }
  const passed = evaluateBosChochCisdOrderRules(mutated, CALL_RULES, PUT_RULES, { confirmPreviousCandle: true })
  ok(passed.action === 'PUT', 'switch ON + précédente HAUSSIÈRE : PUT émis')
}
{
  // Doji précédente : ni CALL ni PUT ne passent.
  const series = rggSeries(30)
  const mutated = series.slice()
  const p = mutated[mutated.length - 2]
  mutated[mutated.length - 2] = { ...p, close: p.open }
  const c = evaluateBosChochCisdOrderRules(mutated, CALL_RULES, PUT_RULES, { confirmPreviousCandle: true })
  ok(c.action === 'HOLD' && /doji/.test(c.reason), 'doji précédente : CALL refusé (neutre)')
}

/* ══════════════ PARTIE 3 — chemin toggles (evaluateBosChochCisd) ══════════════ */
console.log('\n─── 3. Confirmation — chemin toggles (evaluateBosChochCisd) ───')
{
  const series = rggSeries(30)
  const off = evaluateBosChochCisd(series, {})
  ok(off.action === 'CALL', `toggles, switch OFF : CALL émis (${off.events.join(', ')})`)
  const on = evaluateBosChochCisd(series, {}, { confirmPreviousCandle: true })
  ok(on.action === 'HOLD', 'toggles, switch ON + précédente haussière : HOLD')
  ok(/REFUSÉ par la confirmation de bougie/.test(on.reason), `reason explicite (${on.reason})`)

  const mutated = series.slice()
  const p = mutated[mutated.length - 2]
  const newClose = p.open - 0.0002
  mutated[mutated.length - 2] = { ...p, close: newClose, low: Math.min(p.low, newClose) }
  const passed = evaluateBosChochCisd(mutated, {}, { confirmPreviousCandle: true })
  ok(passed.action === 'CALL', 'toggles, switch ON + précédente baissière : CALL émis')
}

/* ══════════════ PARTIE 4 — wrapper backend (evaluateBosChochCisdStrategy) ══════════════ */
console.log('\n─── 4. Wrapper backend (evaluateBosChochCisdStrategy) ───')
{
  resetBosChochCisdState()
  const series = rggSeries(30)
  const off = evaluateBosChochCisdStrategy(series, 'EURUSD_otc', {}, { callRules: CALL_RULES, putRules: PUT_RULES }, { confirmPreviousCandle: false })
  ok(off.action === 'CALL', 'wrapper, switch OFF : CALL émis')
  const on = evaluateBosChochCisdStrategy(series, 'EURUSD_otc', {}, { callRules: CALL_RULES, putRules: PUT_RULES }, { confirmPreviousCandle: true })
  ok(on.action === 'HOLD', 'wrapper, switch ON + précédente haussière : HOLD (aucun ordre)')

  const mutated = series.slice()
  const p = mutated[mutated.length - 2]
  const newClose = p.open - 0.0002
  mutated[mutated.length - 2] = { ...p, close: newClose, low: Math.min(p.low, newClose) }
  const passed = evaluateBosChochCisdStrategy(mutated, 'EURUSD_otc', {}, { callRules: CALL_RULES, putRules: PUT_RULES }, { confirmPreviousCandle: true })
  ok(passed.action === 'CALL', 'wrapper, switch ON + précédente baissière : CALL émis')
  // La bougie marquée tradée (comme le fait index.ts après acceptation) :
  // un re-appel sur la MÊME bougie → HOLD (garde).
  markBosChochCisdTraded('EURUSD_otc', passed.candleTime)
  const again = evaluateBosChochCisdStrategy(mutated, 'EURUSD_otc', {}, { callRules: CALL_RULES, putRules: PUT_RULES }, { confirmPreviousCandle: true })
  ok(again.action === 'HOLD' && /déjà tradée/.test(again.reason), 'garde anti re-trade toujours active après confirmation OK')
  resetBosChochCisdState()
  // Chemin toggles sans règles.
  const togglesOn = evaluateBosChochCisdStrategy(series, 'EURUSD_otc', {}, undefined, { confirmPreviousCandle: true })
  ok(togglesOn.action === 'HOLD', 'wrapper chemin toggles, switch ON : HOLD (précédente haussière)')
}

/* ══════════════ PARTIE 5 — garde-fou Martingale ══════════════ */
console.log('\n─── 5. Garde-fou Martingale (asset-contexts) ───')
{
  ok(clampMaxMartingaleSteps(5) === 5, 'clamp 5 → 5')
  ok(clampMaxMartingaleSteps(0) === 0, 'clamp 0 → 0 (illimité)')
  ok(clampMaxMartingaleSteps(-3) === 0, 'clamp négatif → 0 (illimité)')
  ok(clampMaxMartingaleSteps(NaN) === 0, 'clamp NaN → 0')
  ok(clampMaxMartingaleSteps(99999) === 1000, 'clamp > 1000 → 1000')
  ok(clampMaxMartingaleSteps(2.7) === 2, 'clamp 2.7 → 2 (entier)')
}
{
  // SPÉC UTILISATEUR v20 — max 5, base 1 : 1→2→4→8→16 (5 mises) puis retour à 1.
  // (v19 comptait les doublements : 1→2→4→8→16→32 — corrigé en v20 : la
  // « 6e mise » n'existe plus, N = nombre de mises de la séquence.)
  const ctx = createAssetContext('EURUSD_otc', { bettingStrategy: 'martingale', baseAmount: 1, maxMartingaleSteps: 5 })
  const stakes: number[] = [computeBettingAmount(ctx)]
  const streaks: number[] = []
  for (let i = 0; i < 6; i++) {
    updateBettingAfterResult(ctx, 'loss')
    streaks.push(ctx.betting.consecutiveLosses)
    stakes.push(computeBettingAmount(ctx))
  }
  ok(JSON.stringify(stakes) === JSON.stringify([1, 2, 4, 8, 16, 1, 2]),
    `max 5, 6 pertes : mises 1→2→4→8→16→1→2 — 5 MISES puis retour (obtenu ${stakes.join('→')})`)
  ok(JSON.stringify(streaks.slice(0, 4)) === JSON.stringify([1, 2, 3, 4]), 'streak monte jusqu\'à 4 pendant la séquence de 5 mises')
  ok(streaks[4] === 0, `5e mise (16$) PERD : streak RESET à 0 (obtenu ${streaks[4]}) — retour à la mise initiale`)
  // Un WIN reset (comme toujours).
  updateBettingAfterResult(ctx, 'loss')
  updateBettingAfterResult(ctx, 'win')
  ok(computeBettingAmount(ctx) === 1, 'WIN à mi-course : retour à la mise de base')
}
{
  // SPÉC UTILISATEUR v20 — LE CAS SIGNALÉ : max 4, base 10 → 10→20→40→80, JAMAIS 160.
  const ctx = createAssetContext('EURUSD_otc', { bettingStrategy: 'martingale', baseAmount: 10, maxMartingaleSteps: 4 })
  const stakes: number[] = [computeBettingAmount(ctx)]
  for (let i = 0; i < 6; i++) {
    updateBettingAfterResult(ctx, 'loss')
    stakes.push(computeBettingAmount(ctx))
  }
  ok(JSON.stringify(stakes) === JSON.stringify([10, 20, 40, 80, 10, 20, 40]),
    `max 4, base 10 : 10→20→40→80→10 (4 mises, la « 5e » n'existe pas — obtenu ${stakes.join('→')})`)
}
{
  // max 0 = illimité (comportement historique).
  const ctx = createAssetContext('EURUSD_otc', { bettingStrategy: 'martingale', baseAmount: 1, maxMartingaleSteps: 0 })
  for (let i = 0; i < 10; i++) updateBettingAfterResult(ctx, 'loss')
  ok(computeBettingAmount(ctx) === 1024, 'max 0 (illimité) : 10 pertes → 1024 (comportement historique)')
}
{
  // max 2 : 1→2→1→2→1 (2 mises, puis retour à la mise initiale après l'échec de la 2e).
  const ctx = createAssetContext('EURUSD_otc', { bettingStrategy: 'martingale', baseAmount: 1, maxMartingaleSteps: 2 })
  const stakes: number[] = [computeBettingAmount(ctx)]
  for (let i = 0; i < 5; i++) {
    updateBettingAfterResult(ctx, 'loss')
    stakes.push(computeBettingAmount(ctx))
  }
  ok(JSON.stringify(stakes) === JSON.stringify([1, 2, 1, 2, 1, 2]),
    `max 2, 5 pertes : 1→2→1→2→1 (obtenu ${stakes.join('→')})`)
}
{
  // TIE/PUSH : neutre — n'avance ni ne reset la suite (v17 conservé).
  const ctx = createAssetContext('EURUSD_otc', { bettingStrategy: 'martingale', baseAmount: 1, maxMartingaleSteps: 5 })
  updateBettingAfterResult(ctx, 'loss')
  updateBettingAfterResult(ctx, 'loss')
  updateBettingAfterResult(ctx, 'push')
  ok(computeBettingAmount(ctx) === 4, 'TIE au niveau 4$ : mise conservée (état neutre v17)')
  updateBettingAfterResult(ctx, 'loss')
  ok(computeBettingAmount(ctx) === 8, 'LOSS après TIE : suite reprend (4→8)')
}
{
  // Clamp ceinture+bretelles : un consecutiveLosses hérité ≥ cap ne dépasse
  // JAMAIS la N-ième mise (cap 3 → mise max 2^(3-1) = 4).
  const ctx = createAssetContext('EURUSD_otc', { bettingStrategy: 'martingale', baseAmount: 1, maxMartingaleSteps: 3 })
  ctx.betting.consecutiveLosses = 9 // état hérité/corrompu simulé
  ok(computeBettingAmount(ctx) === 4, `clamp computeBettingAmount : cl=9 avec cap 3 → 2^2 = 4 (obtenu ${computeBettingAmount(ctx)})`)
}
{
  // Isolation par asset : le cap d'un asset ne contamine pas l'autre.
  const a = createAssetContext('EURUSD_otc', { bettingStrategy: 'martingale', baseAmount: 1, maxMartingaleSteps: 1 })
  const b = createAssetContext('XAUUSD_otc', { bettingStrategy: 'martingale', baseAmount: 1, maxMartingaleSteps: 0 })
  updateBettingAfterResult(a, 'loss'); updateBettingAfterResult(a, 'loss')
  updateBettingAfterResult(b, 'loss'); updateBettingAfterResult(b, 'loss'); updateBettingAfterResult(b, 'loss')
  ok(computeBettingAmount(a) === 1, 'EURUSD cap 1 : 2 pertes → retour à 1')
  ok(computeBettingAmount(b) === 8, 'XAUUSD illimité : 3 pertes → 8 (isolation du cap)')
}
{
  // Fibonacci non affectée par le cap (spéc : la règle concerne la Martingale).
  const ctx = createAssetContext('EURUSD_otc', { bettingStrategy: 'fibonacci', baseAmount: 1, maxMartingaleSteps: 2 })
  const fibs: number[] = []
  for (let i = 0; i < 6; i++) {
    fibs.push(computeBettingAmount(ctx))
    updateBettingAfterResult(ctx, 'loss')
  }
  ok(JSON.stringify(fibs) === JSON.stringify([1, 1, 2, 3, 5, 8]),
    `fibonacci avec cap 2 : progression 1,1,2,3,5,8 inchangée (obtenu ${fibs.join(',')})`)
}
{
  // Fixed : le cap n'a aucun effet visible.
  const ctx = createAssetContext('EURUSD_otc', { bettingStrategy: 'fixed', baseAmount: 3, maxMartingaleSteps: 1 })
  for (let i = 0; i < 5; i++) updateBettingAfterResult(ctx, 'loss')
  ok(computeBettingAmount(ctx) === 3, 'fixed avec cap : mise constante 3$')
}
{
  // applyDealResult porte le reset du cap aussi (chemin réel deal fermé).
  const ctx = createAssetContext('EURUSD_otc', { bettingStrategy: 'martingale', baseAmount: 1, maxMartingaleSteps: 2 })
  ctx.trackedDeals.set('d1', { asset: 'EURUSD_otc', amount: 1, expirationSeconds: 4 })
  const r1 = applyLike(ctx, 'd1', 'loss')
  ok(r1?.nextBetAmount === 2, 'deal 1 (1$) LOSS → prochaine 2$ (2e et dernière mise du cap 2)')
  ctx.trackedDeals.set('d2', { asset: 'EURUSD_otc', amount: 2, expirationSeconds: 4 })
  const r2 = applyLike(ctx, 'd2', 'loss')
  ok(r2?.nextBetAmount === 1, `deal 2 (2$, 2e mise du cap 2) LOSS → RETOUR à 1$ (obtenu ${r2?.nextBetAmount})`)
  // v20 — le résultat du dernier ordre réglé est mémorisé (Auto Switch Assets).
  ok(ctx.autoTrade.lastOrderWin === false, 'applyDealResult : lastOrderWin = false après une perte')
  ctx.trackedDeals.set('d3', { asset: 'EURUSD_otc', amount: 1, expirationSeconds: 4 })
  applyLike(ctx, 'd3', 'win')
  ok(ctx.autoTrade.lastOrderWin === true, 'applyDealResult : lastOrderWin = true après un gain')
}
function applyLike(ctx: ReturnType<typeof createAssetContext>, id: string, outcome: 'win' | 'loss' | 'push') {
  // Simule applyDealResult sans le module serveur : stats + updateBetting
  // + lastOrderWin (v20 — Auto Switch Assets), comme le vrai moteur.
  const tracked = ctx.trackedDeals.get(id)
  if (!tracked) return null
  ctx.trackedDeals.delete(id)
  if (outcome === 'win') ctx.stats.wins++
  else if (outcome === 'loss') ctx.stats.losses++
  else ctx.stats.pushes++
  updateBettingAfterResult(ctx, outcome)
  ctx.autoTrade.lastOrderWin = outcome === 'win'
  return { nextBetAmount: computeBettingAmount(ctx) }
}

/* ══════════════ bilan ══════════════ */
console.log(`\n═══ RÉSULTAT : ${pass} ✓ / ${fail} ✗ ═══`)
if (fail > 0) process.exit(1)
