#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# E2E VÉRIFICATION v1.6 — après correctifs martingale + Trade History
#   1. Martingale corrigée : après un GAIN → mise suivante = base (500)
#   2. Trade History (replay) = trades SIMULÉS, effacés par RESET TRADES
# ═══════════════════════════════════════════════════════════════════
cd /home/z/my-project
step() { echo ""; echo "════════ $1 ════════"; }
shot() { agent-browser screenshot "scripts/$1" >/dev/null 2>&1 && echo "📸 $1"; }

if ! curl -s -m 3 -o /dev/null http://localhost:3000/ 2>/dev/null; then
  step "0. Services morts → ./po.sh"
  setsid nohup ./po.sh > .logs/po-restart.log 2>&1
  for i in $(seq 1 30); do sleep 4; curl -s -m 5 -o /dev/null http://localhost:3000/ && break; done
fi
curl -s -m 3 -o /dev/null http://localhost:3000/ && echo "front OK" || { echo "✗ front mort"; exit 1; }

rm -f .logs/trade.jsonl

# ── 1. config martingale ×2 ──
step "1. Config — martingale ×2, base 500, balance 10000"
node -e "
const fs = require('fs');
const src = fs.readFileSync('src/lib/signal-catalog.ts','utf8');
const ids = [...src.matchAll(/\{ id: '([A-Z0-9_]+)', family: '/g)].map(m => m[1]);
const seen = new Set(); const uniq = ids.filter(i => !seen.has(i) && seen.add(i));
const pick = uniq.filter(i => ['HH','LH','ENG_BULL','HAMMER','BULL_ENGULF','FVG_BULL','OB_BULL','TWEEZER_BOT'].includes(i));
const use = pick.length >= 4 ? pick : uniq.slice(0, 8);
const cfg = {
  enabled: true,
  callSignalIds: use, putSignalIds: [],
  stopCallSignalIds: [], stopPutSignalIds: [],
  rejectCallSignalIds: [], rejectPutSignalIds: [],
  callMode: 'ANY', putMode: 'ANY',
  windowBars: 3, expiryCandles: 1, cooldownCandles: 1,
  amount: 500, bettingStrategy: 'martingale', martingaleFactor: 2,
  autoTradeReplay: true, notifyLive: false
};
fs.writeFileSync('/tmp/cfg-mart.json', JSON.stringify(cfg));
console.log('conditions CALL: ' + use.length);
"

# ── 2. page propre + injection (recharge le nouveau code v1.6) ──
step "2. Page propre + injection localStorage"
agent-browser open http://localhost:3000 >/dev/null 2>&1
sleep 12
B64=$(base64 -w0 /tmp/cfg-mart.json)
agent-browser eval "(() => {
  localStorage.clear();
  const cfg = JSON.parse(atob('$B64'));
  localStorage.setItem('signal-strategy-config-v1', JSON.stringify(cfg));
  localStorage.setItem('trade-logger-enabled-v1', '1');
  localStorage.setItem('po-backtest-balance-v1', '10000');
  return 'injection OK — martingale ×' + cfg.martingaleFactor + ' base ' + cfg.amount;
})()" 2>&1 | tail -1
agent-browser reload >/dev/null 2>&1
sleep 12

# ── 3. login ──
step "3. Login"
agent-browser find role button click --name "Login with Pocket Option" >/dev/null 2>&1
for i in $(seq 1 12); do
  sleep 5
  if agent-browser snapshot -i -c 2>/dev/null | grep -q "PINE SCRIPT"; then echo "app atteinte"; break; fi
done
agent-browser snapshot -i -c 2>/dev/null | grep -q "PINE SCRIPT" && echo "✓ logué" || { echo "✗ login KO"; exit 1; }
sleep 8

# ── 4. Replay 1000 bougies ──
step "4. Replay 1000 bougies"
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').trim() === 'Replay');
  if (!b) return 'REPLAY INTROUVABLE';
  b.click(); return 'MENU REPLAY';
})()" 2>&1 | tail -1
sleep 1
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').trim() === '1k');
  if (!b) return '1K INTROUVABLE';
  b.click(); return '1000 BOUGIES';
})()" 2>&1 | tail -1
sleep 1
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').trim() === 'Start Replay');
  if (!b) return 'START INTROUVABLE';
  b.click(); return 'REPLAY DEMARRE';
})()" 2>&1 | tail -1
PANEL=""
for i in $(seq 1 22); do
  sleep 4
  PANEL=$(agent-browser eval "(() => document.body.textContent.includes('Start balance') ? 'PRET' : 'ATTENTE')()" 2>&1 | tail -1 | tr -d '"')
  [ "$PANEL" = "PRET" ] && break
done
[ "$PANEL" = "PRET" ] || { echo "✗ panneau backtest absent"; exit 1; }
echo "panneau Strategy Tester OK"

# ── 5. X80 + Play ──
step "5. X80 + PLAY (90 s)"
agent-browser eval "
(() => {
  const s = [...document.querySelectorAll('select')].find(x => [...x.options].some(o => o.value === '12'));
  if (!s) return 'SELECT INTROUVABLE';
  const setter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, 'value').set;
  setter.call(s, '12');
  s.dispatchEvent(new Event('change', { bubbles: true }));
  return 'VITESSE 80x';
})()" 2>&1 | tail -1
sleep 1
agent-browser eval "
(() => {
  const b = document.querySelector('button[title=\"Play\"]');
  if (!b) return 'PLAY INTROUVABLE';
  b.click(); return 'PLAY';
})()" 2>&1 | tail -1
sleep 90
# pause
agent-browser eval "
(() => {
  const b = document.querySelector('button[title=\"Pause\"]');
  if (b) { b.click(); return 'PAUSE'; }
  return 'DEJA PAUSE/FIN';
})()" 2>&1 | tail -1
sleep 4
shot v16_01_apres_run.png

# ── 6. VÉRIFICATION MARTINGALE ──
step "6. Vérification martingale (trade.jsonl)"
agent-browser eval "
(() => {
  const t = document.body.textContent;
  const m = t.match(/série (\d+) pertes? — prochaine mise \\\$([\d.,]+)/);
  const bars = (t.match(/(\d+\/\d+) bars/) || [])[1] || '?';
  return 'bars=' + bars + ' | panneau: ' + (m ? ('série=' + m[1] + ' prochaine=' + m[2]) : 'série 0 (pas affichée)');
})()" 2>&1 | tail -1
node -e "
const fs = require('fs');
if (!fs.existsSync('.logs/trade.jsonl')) { console.log('✗ trade.jsonl absent'); process.exit(1); }
const lines = fs.readFileSync('.logs/trade.jsonl','utf8').trim().split('\n').filter(Boolean);
const trades = lines.map(l => { try { return JSON.parse(l).trade; } catch { return null; } }).filter(Boolean);
console.log('trades loggés: ' + trades.length);
const seq = trades.map(t => ({ amt: t.stake ?? t.amount, won: t.won ?? (t.profit > 0) }));
let out = [];
seq.slice(0, 45).forEach((s, i) => out.push('#' + (i+1) + ':' + s.amt + (s.won ? '✓' : '✕')));
console.log(out.join(' '));
let bugAfterWin = 0, okAfterWin = 0, doubledAfterLoss = 0, baseAfterLoss = 0;
for (let i = 1; i < seq.length; i++) {
  if (seq[i-1].won) { if (seq[i].amt > 500.001) bugAfterWin++; else okAfterWin++; }
  else { if (seq[i].amt > 500.001) doubledAfterLoss++; else baseAfterLoss++; }
}
console.log('── INVARIANT 1 : après un GAIN → mise = 500 (OK) : ' + okAfterWin + ' | mise > 500 (BUG) : ' + bugAfterWin);
console.log('── INVARIANT 2 : après une PERTE → mise doublée : ' + doubledAfterLoss + ' | mise 500 (cooldown/solde) : ' + baseAfterLoss);
const amts = {};
seq.forEach(s => amts[s.amt] = (amts[s.amt]||0)+1);
console.log('distribution des mises:', JSON.stringify(amts));
// vérifie la séquence exacte de doublement : base×2^k pour k = suite de pertes
let seqErr = 0;
let streak = 0;
for (let i = 0; i < seq.length; i++) {
  const expected = Math.min(500 * Math.pow(2, streak), 100000);
  if (Math.abs(seq[i].amt - Math.min(expected, seq[i].amt)) > 0.01 && seq[i].amt < expected - 0.01) seqErr++;
  streak = seq[i].won ? 0 : streak + 1;
}
console.log('cohérence base×2^pertes_consecutives : ' + (seqErr === 0 ? 'PARFAITE' : seqErr + ' écarts (plafonds solde)'));
fs.writeFileSync('/tmp/mart-seq-v16.json', JSON.stringify({ bugAfterWin, okAfterWin, doubledAfterLoss, n: seq.length }));
if (bugAfterWin > 0) { console.log('✗ BUG ENCORE PRÉSENT'); process.exit(1); }
console.log('✓ MARTINGALE CORRIGÉE — retour à la base après chaque gain');
"

# ── 7. Trade History (replay) = trades simulés ──
step "7. Trade History — onglet (mode replay)"
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('Trade History'));
  if (!b) return 'ONGLET INTROUVABLE';
  b.click(); return 'ONGLET OUVERT';
})()" 2>&1 | tail -1
sleep 2
agent-browser eval "
(() => {
  const header = [...document.querySelectorAll('span')].find(s => (s.textContent || '').includes('Simulated Trades'));
  const rows = document.querySelectorAll('.grid-cols-5');
  const badge = [...document.querySelectorAll('span')].some(s => (s.textContent || '').trim() === 'REPLAY');
  const tab = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('Trade History'));
  return JSON.stringify({
    panneauSimule: !!header,
    badgeREPLAY: badge,
    deals: rows.length,
    badgeOnglet: (tab.textContent.match(/\((\d+)\)/) || [])[1] || '0',
    premier: rows.length ? (rows[0].textContent || '').trim().slice(0, 60) : '—'
  });
})()" 2>&1 | tail -1
shot v16_02_trade_history_sim.png

# ── 8. RESET TRADES → tout s'efface ──
step "8. RESET TRADES → Strategy Tester + Trade History vidés"
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('RESET TRADES'));
  if (!b) return 'RESET INTROUVABLE';
  b.click(); return 'RESET CLIQUÉ';
})()" 2>&1 | tail -1
sleep 4
agent-browser eval "
(() => {
  const rows = document.querySelectorAll('.grid-cols-5');
  const noSim = document.body.textContent.includes('No simulated trades yet');
  const tab = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('Trade History'));
  return 'Trade History APRÈS reset → deals=' + rows.length + ' | message vide=' + (noSim ? 'OUI' : 'NON') + ' | badge onglet=' + ((tab.textContent.match(/\((\d+)\)/) || [])[0] || 'aucun');
})()" 2>&1 | tail -1
shot v16_03_trade_history_apres_reset.png
# vérifie aussi le tableau du Strategy Tester
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').trim() === 'Strategy Tester');
  if (b) b.click();
  return 'ONGLET STRATEGY TESTER';
})()" 2>&1 | tail -1
sleep 2
agent-browser eval "
(() => {
  const rows = document.querySelectorAll('table tbody tr');
  const noTrades = document.body.textContent.includes('No simulated trades yet');
  const stats = (document.body.textContent.match(/Trades\s*(\d+) \((\d+)W/g) || [])[0] || '?';
  return 'Strategy Tester APRÈS reset → lignes=' + rows.length + ' | placeholder=' + (noTrades ? 'OUI' : 'NON') + ' | ' + stats;
})()" 2>&1 | tail -1
shot v16_04_tester_apres_reset.png

echo ""
echo "══ VÉRIFICATION E2E v1.6 TERMINÉE ══"
