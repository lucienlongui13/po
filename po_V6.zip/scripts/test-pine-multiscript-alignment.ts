/**
 * test-pine-multiscript-alignment.ts — v1.9 suite (spec §14, §15, §21).
 *
 * Five Pine scripts of every rendering family active simultaneously
 * (overlay plots, non-overlay RSI pane, probe markers+labels, drawings,
 * histogram). 20 new bars arrive one by one through the coordinator.
 *
 * Invariants:
 *  - every script observes the SAME snapshot (identical envelope revision);
 *  - all results reach the current last bar — no script lags behind;
 *  - the probe's signal at bar 50 stays at barTime(50) for every script
 *    family (marker / label / plot value / drawing);
 *  - no indicator drifts progressively to the left.
 */
import { usePineStore } from '../src/lib/pine-store'
import { pineCoordinator } from '../src/lib/pine-executor'
import { toPineTime } from '../src/lib/pine-time-axis'
import {
  ALIGNMENT_PROBE_SRC, ANCHOR_PROBE_SRC, EMA_CROSS_SRC, RSI_PANE_SRC, HIST_SRC,
  makeCandles, makeChecker, resetPineState, waitForIdle, waitForStore,
  allScriptsAtRevision, storeScript, timeOfIndex,
} from './pine-live-test-utils'

const { ok, finish } = makeChecker()
const TF_SEC = 60
const OPTS = { startTime: 1789439220, tfSec: TF_SEC }

async function main() {
  resetPineState()
  const candles = makeCandles(120, OPTS)

  const ids = {
    ema: usePineStore.getState().addScript(EMA_CROSS_SRC, 'EMA Cross'),
    rsi: usePineStore.getState().addScript(RSI_PANE_SRC, 'RSI Pane'),
    probe: usePineStore.getState().addScript(ALIGNMENT_PROBE_SRC, 'Alignment Probe'),
    anchor: usePineStore.getState().addScript(ANCHOR_PROBE_SRC, 'Anchor Probe'),
    hist: usePineStore.getState().addScript(HIST_SRC, 'Histogram'),
  }
  const allIds = Object.values(ids)

  pineCoordinator.setContext({ asset: 'EURUSD_otc', timeframe: TF_SEC })
  pineCoordinator.notifyDataset(candles, 'init')
  let rev = pineCoordinator.stats().revision
  await waitForStore(() => allScriptsAtRevision(rev), 20000, 'initial commit (5 scripts)')
  await waitForIdle()

  console.log('── 1. initial batch: atomic, same snapshot ──')
  let envelopes = allIds.map((id) => storeScript(id)!.envelope!)
  ok('all 5 scripts committed with the SAME revision (atomic snapshot sharing)',
    envelopes.every((e) => e.revision === envelopes[0].revision))
  ok('all 5 envelopes describe the SAME dataset',
    envelopes.every((e) => e.barCount === 120 && e.lastBarTime === candles[119].time))
  ok('every script has a result or explicit error',
    allIds.every((id) => storeScript(id)!.result != null || storeScript(id)!.error != null))
  const errors = allIds.map((id) => `${id}: ${storeScript(id)!.error}`).filter((e) => !e.endsWith(': null'))
  if (errors.length) console.log('  (script errors:', errors.join(' | '), ')')

  const T50 = toPineTime(timeOfIndex(50, OPTS))

  console.log('── 2. 20 new bars, one by one ──')
  let driftDetected = false
  let revisionGaps = 0
  for (let k = 0; k < 20; k++) {
    const prev = candles[candles.length - 1]
    const c = prev.close + Math.sin(k / 2) * 3e-5
    candles.push({
      time: prev.time + TF_SEC,
      open: prev.close, high: Math.max(prev.close, c) + 9e-5, low: Math.min(prev.close, c) - 7e-5,
      close: c, volume: 200 + k,
    })
    pineCoordinator.notifyDataset(candles, 'new-bar')
    rev = pineCoordinator.stats().revision
    await waitForStore(() => allScriptsAtRevision(rev), 20000, `commit bar ${k}`)
    await waitForIdle()

    envelopes = allIds.map((id) => storeScript(id)!.envelope!)
    const revs = new Set(envelopes.map((e) => e.revision))
    if (revs.size !== 1) revisionGaps++
    if (!envelopes.every((e) => e.lastBarTime === candles[candles.length - 1].time)) driftDetected = true

    // The probe's label "50" must sit at barTime(50) after EVERY bar.
    const label50 = storeScript(ids.probe)!.result!.drawings.find((d: any) => d.kind === 'label' && d.text === '50') as any
    if (!label50 || label50.x !== T50) driftDetected = true
  }
  ok('all 5 scripts stay on the same revision after every bar (atomic sync)', revisionGaps === 0)
  ok('no script lags behind the last bar after 20 new bars (no drift)', !driftDetected)
  ok('all 5 results reach the final bar',
    allIds.every((id) => {
      const s = storeScript(id)!
      return s.result?._times?.[s.result._times.length - 1] === toPineTime(candles[candles.length - 1].time)
        || s.result == null /* errored scripts exempt — checked below */
    }))

  console.log('── 3. per-family invariants after the 20 bars ──')
  // EMA plots: values exist on every timestamp including the newest.
  const ema = storeScript(ids.ema)!.result!
  const emaTimes = ema._times!
  ok('EMA overlay plot covers the full timeline',
    ema.plots[0].data.length === emaTimes.length)
  ok('EMA plot has a value on the newest bar', ema.plots[0].data[emaTimes.length - 1] != null)

  // RSI pane: non-overlay, hlines present.
  const rsi = storeScript(ids.rsi)!.result!
  ok('RSI non-overlay with 30/70 hlines', rsi.overlay === false && rsi.hlines.length === 2)

  // Probe: marker at bar 50 still a signal bar; label count = 140.
  const probe = storeScript(ids.probe)!.result!
  const idxT50 = probe._times!.indexOf(T50)
  ok('probe marker at barTime(50) after 20 bars', idxT50 >= 0 && probe.markers[0].data[idxT50] != null)
  ok('probe produced 140 labels (one per bar, none dropped)',
    probe.drawings.filter((d: any) => d.kind === 'label').length === 140)

  // Anchor: box/line still on their bars.
  const anchor = storeScript(ids.anchor)!.result!
  const box = anchor.drawings.find((d: any) => d.kind === 'box') as any
  const line = anchor.drawings.find((d: any) => d.kind === 'line') as any
  ok('anchor box still at bars 35..60',
    box && box.left === toPineTime(timeOfIndex(35, OPTS)) && box.right === toPineTime(timeOfIndex(60, OPTS)))
  ok('anchor line still at bars 45..55',
    line && line.x1 === toPineTime(timeOfIndex(45, OPTS)) && line.x2 === toPineTime(timeOfIndex(55, OPTS)))

  // Histogram.
  const hist = storeScript(ids.hist)!.result!
  ok('histogram covers the full timeline', hist.plots[0].data.length === hist._times!.length)

  ok('no script ended in error', allIds.every((id) => storeScript(id)!.error == null))

  resetPineState()
  console.log()
  finish('test-pine-multiscript-alignment')
}

main().catch((err) => {
  console.error('FATAL:', err)
  process.exit(1)
})
