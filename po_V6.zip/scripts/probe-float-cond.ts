/**
 * probe-float-cond.ts — does piner coerce float conditions like Pine does?
 * Pine semantics: a float used as a condition is na→false, any value→true.
 * theEccentricTrader's pattern scripts rely on this everywhere:
 *   shPrice = <swing price or na>;  peak = ta.valuewhen(shPrice, shPrice, 0)
 */
import { compileAsync, Engine, ArrayFeed } from '@heyphat/piner'

const src = `
//@version=6
indicator("float cond probe", overlay=true)
// swing-high style float: price on some bars, na otherwise
raw = close[1] > open[1] and close < open ? high : na
// 1) ternary with float condition
t1 = raw ? 1 : 0
// 2) valuewhen with float condition
vw = ta.valuewhen(raw, raw, 0)
// 3) logical and with float
both = raw and close > 0
lbl = label.new(bar_index, high, "t1=" + str.tostring(t1) + " vw=" + str.tostring(vw) + " both=" + str.tostring(both), style=label.style_label_down)
`

const bars: any[] = []
let t = 1000
for (let i = 0; i < 30; i++) {
  const up = i % 3 !== 0
  const open = 10 + i * 0.1
  const close = up ? open + 0.2 : open - 0.25
  bars.push({ time: t, open, high: Math.max(open, close) + 0.1, low: Math.min(open, close) - 0.1, close, volume: 5 })
  t += 60_000
}

async function main() {
  const compiled: any = await compileAsync(src, { libraries: [], resolveLibrary: () => undefined })
  const engine: any = new Engine(compiled, new ArrayFeed(bars) as any, undefined)
  await engine.run({ symbol: 'X', timeframe: '1' })
  const labels = (engine.drawings as any[]).filter((d) => d.type === 'label')
  console.log(`labels: ${labels.length}`)
  for (const l of labels.slice(-6)) console.log(' ', l.props.text)
  // expected Pine-true output: on down-bars after an up-bar: t1=1, vw=<that high>, both=true
  // on other bars: t1=0, vw=<last such high>, both=false
}
main().catch((e) => { console.error('FAIL', e); process.exit(1) })
