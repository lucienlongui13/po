#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# E2E V1.11 — BOS, CHoCH & CISD : stratégie Auto Trade + visuels + réglages
#   1. Sélection de la stratégie dans le panneau Auto Trade (dropdown backend)
#   2. Champs de réglages du pack : Labels (7 couleurs + taille) + Alerts (6 toggles)
#   3. Overlay graphique : labels BOS/CHoCH/CISD + lignes rendus sur canvas
#   4. Réactivité : changement de couleur → overlay mis à jour en direct
#   5. Strategy Tester : adaptateur BOS/CHoCH/CISD (mode AUTO TRADE)
#   6. Store localStorage : réglages persistés
#
# NOTE : les eval utilisent des sélecteurs SANS guillemets imbriqués et des
# retours délimités (clé=valeur) — l'échappement bash/JS est fragile sinon.
# ═══════════════════════════════════════════════════════════════════
cd /home/z/my-project
PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  ✓ $1"; }
ko()   { FAIL=$((FAIL+1)); echo "  ✗ $1"; }
step() { echo ""; echo "════════ $1 ════════"; }
shot() { agent-browser screenshot "scripts/e2e-v111-$1.png" >/dev/null 2>&1 && echo "📸 $1"; }

if ! curl -s -m 3 -o /dev/null http://localhost:3000/ 2>/dev/null; then
  step "0. Services morts → ./po.sh"
  setsid nohup ./po.sh > .logs/po-restart.log 2>&1
  for i in $(seq 1 30); do sleep 4; curl -s -m 3 -o /dev/null http://localhost:3000/ && break; done
fi
curl -s -m 3 -o /dev/null http://localhost:3000/ && echo "front OK" || { echo "✗ front mort"; exit 1; }

step "1. Ouverture + login (si nécessaire)"
agent-browser open http://localhost:3000 >/dev/null 2>&1
sleep 8
LOGGED=$(agent-browser eval '(() => {
  const b = [...document.querySelectorAll("button")].find(x => (x.textContent || "").includes("Login with Pocket Option"));
  if (b) { b.click(); return "login-clique"; }
  return "deja-connecte";
})()' 2>/dev/null | tail -1 | tr -d '"')
echo "   $LOGGED"
for i in $(seq 1 12); do
  sleep 5
  if agent-browser snapshot -i -c 2>/dev/null | grep -qi "auto trade"; then break; fi
done
agent-browser snapshot -i -c 2>/dev/null | grep -qi "auto trade" && ok "interface chargée (panneaux visibles)" || { ko "interface chargée"; exit 1; }
sleep 8

step "2. Panneau Auto Trade — sélection de la stratégie"
agent-browser eval '(() => {
  const h = [...document.querySelectorAll("button")].find(x => (x.textContent || "").trim().toUpperCase() === "AUTO TRADE" && (x.textContent || "").indexOf("ON") === -1);
  if (h) { h.click(); return "ouvert"; }
  return "deja-ouvert";
})()' >/dev/null 2>&1
sleep 3
FOUND=$(agent-browser eval '(() => {
  const sel = [...document.querySelectorAll("select")].find(s => [...s.options].some(o => (o.value || o.textContent).indexOf("bos_choch_cisd") >= 0));
  return sel ? "presente" : "absente";
})()' 2>/dev/null | tail -1 | tr -d '"')
[ "$FOUND" == "presente" ] && ok "stratégie bos_choch_cisd listée par le backend" || ko "stratégie bos_choch_cisd listée ($FOUND)"

agent-browser eval '(() => {
  const sel = [...document.querySelectorAll("select")].find(s => [...s.options].some(o => (o.value || "").indexOf("bos_choch_cisd") >= 0));
  if (!sel) return "absente";
  const setter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value").set;
  setter.call(sel, "bos_choch_cisd");
  sel.dispatchEvent(new Event("change", { bubbles: true }));
  return "selectionnee";
})()' >/dev/null 2>&1
sleep 5

step "3. Champs de réglages du pack (Labels + Alerts)"
FIELDS=$(agent-browser eval '(() => {
  const all = [...document.querySelectorAll("div")].filter(d => (d.textContent || "").includes("BOS, CHoCH & CISD — pack Pine") && d.textContent.includes("Reset pack"));
  const box = all[all.length - 1];
  if (!box) return "colours=0 alerts=0 size=0";
  const colours = box.querySelectorAll("input[type=color]").length;
  const txt = box.textContent;
  const alerts = ["BOS Up Alert","BOS Down Alert","CHoCH Up Alert","CHoCH Down Alert","CISD Up Alert","CISD Down Alert"].filter(a => txt.indexOf(a) >= 0).length;
  return "colours=" + colours + " alerts=" + alerts + " size=" + (txt.includes("Label Size") ? 1 : 0);
})()' 2>/dev/null | tail -1 | tr -d '"')
echo "   $FIELDS"
echo "$FIELDS" | grep -q "colours=7" && ok "7 sélecteurs de couleur (6 labels + texte)" || ko "7 sélecteurs de couleur ($FIELDS)"
echo "$FIELDS" | grep -q "alerts=6" && ok "6 toggles Alerts (BOS/CHoCH/CISD Up/Down)" || ko "6 toggles Alerts ($FIELDS)"
echo "$FIELDS" | grep -q "size=1" && ok "Label Size présent (Tiny→Auto)" || ko "Label Size ($FIELDS)"

step "4. Overlay graphique — labels + lignes du pack (moteur + pixels)"
sleep 5
shot panel-settings
CANVAS=$(agent-browser eval '(() => {
  const c = [...document.querySelectorAll("canvas")].find(x => (x.getAttribute("aria-label") || "").indexOf("BOS") >= 0);
  if (!c) return "ABSENT";
  const ctx = c.getContext("2d");
  const data = ctx.getImageData(0, 0, c.width, c.height).data;
  let drawn = 0;
  for (let i = 0; i < data.length; i += 4) if (data[i+3] >= 40) drawn++;
  return "drawn=" + drawn;
})()' 2>/dev/null | tail -1 | tr -d '"')
echo "   pixels : $CANVAS"
echo "$CANVAS" | grep -vq "ABSENT" && ok "canvas overlay monté" || ko "canvas overlay monté"
getv() { echo "$CANVAS" | grep -o "$1=[0-9]*" | cut -d= -f2; }
DRAWN=$(getv drawn)
[ "${DRAWN:-0}" -gt 500 ] 2>/dev/null && ok "overlay dessiné sur le canvas (${DRAWN} px)" || ko "overlay dessiné (${DRAWN} px)"

# assertions moteur (déterministes) via le hook diagnostic lecture seule
DBG=$(agent-browser eval '(() => {
  const hook = window.__bosChochCisdDebug;
  if (!hook || !hook.getSummary()) return "HOOK ABSENT";
  const s = hook.getSummary();
  return "candles=" + s.candles + " labels=" + s.labels + " events=" + s.eventLines + " trends=" + s.trendLines
    + " bos=" + (s.families.bos || 0) + " choch=" + (s.families.choch || 0) + " cisd=" + (s.families.cisd || 0)
    + " bosUp=" + (s.colours["bos:up"] || "-") + " bosDown=" + (s.colours["bos:down"] || "-")
    + " chochUp=" + (s.colours["choch:up"] || "-") + " cisdUp=" + (s.colours["cisd:up"] || "-")
    + " cisdDown=" + (s.colours["cisd:down"] || "-");
})()' 2>/dev/null | tail -1 | tr -d '"')
echo "   moteur : $DBG"
getd() { echo "$DBG" | grep -o "$1=[^ ]*" | cut -d= -f2; }
[ "$(getd candles)" -gt 100 ] 2>/dev/null && ok "moteur alimenté par les bougies live ($(getd candles))" || ko "bougies moteur ($(getd candles)"
[ "$(getd labels)" -gt 50 ] 2>/dev/null && ok "labels du pack calculés ($(getd labels), GC 80/famille)" || ko "labels calculés ($(getd labels))"
[ "$(getd events)" -gt 50 ] 2>/dev/null && ok "lignes d'événement calculées ($(getd events))" || ko "lignes d'événement ($(getd events))"
[ "$(getd trends)" -gt 5 ] 2>/dev/null && ok "lignes de tendance calculées ($(getd trends))" || ko "lignes de tendance ($(getd trends))"
FAMSOK=1
for fam in bos choch cisd; do [ "$(getd $fam)" -gt 5 ] 2>/dev/null || FAMSOK=0; done
[ "$FAMSOK" == "1" ] && ok "les 3 familles BOS + CHoCH + CISD présentes ($(getd bos)/$(getd choch)/$(getd cisd))" || ko "familles ($(getd bos)/$(getd choch)/$(getd cisd))"
[ "$(getd bosUp)" == "#4CAF50" ] && [ "$(getd bosDown)" == "#F23645" ] && [ "$(getd chochUp)" == "#FF9800" ] && [ "$(getd cisdUp)" == "#2962FF" ] \
  && ok "couleurs du pack appliquées (vert/rouge/orange/bleu)" || ko "couleurs du pack ($DBG)"
shot chart-overlay

step "5. Réactivité — changement de couleur BOS Up (store + overlay)"
agent-browser eval '(() => {
  const all = [...document.querySelectorAll("div")].filter(d => (d.textContent || "").includes("BOS, CHoCH & CISD — pack Pine") && d.textContent.includes("Reset pack"));
  const box = all[all.length - 1];
  if (!box) return "ABSENT";
  const input = box.querySelectorAll("input[type=color]")[0];
  const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
  setter.call(input, "#00E676");
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.dispatchEvent(new Event("change", { bubbles: true }));
  return "change";
})()' >/dev/null 2>&1
sleep 3
NEWCOL=$(agent-browser eval '(() => {
  const hook = window.__bosChochCisdDebug;
  if (!hook || !hook.getSummary()) return "HOOK ABSENT";
  return String(hook.getSummary().colours["bos:up"] || "-");
})()' 2>/dev/null | tail -1 | tr -d '"')
echo "   couleur BOS Up côté moteur : $NEWCOL"
NEWCOL_LC=$(echo "$NEWCOL" | tr 'A-Z' 'a-z')
[ "$NEWCOL_LC" == "#00e676" ] && ok "couleur appliquée au moteur de l'overlay en direct" || ko "couleur appliquée ($NEWCOL)"
STORE=$(agent-browser eval '(() => {
  const s = JSON.parse(localStorage.getItem("bos-choch-cisd-settings-v1") || "null");
  return s ? String(s.bosUpLabelColour) : "ABSENT";
})()' 2>/dev/null | tail -1 | tr -d '"')
STORE_LC=$(echo "$STORE" | tr 'A-Z' 'a-z')
[ "$STORE_LC" == "#00e676" ] && ok "réglage persisté dans le store localStorage" || ko "store ($STORE)"
shot chart-recolor

# restaure les réglages du pack
agent-browser eval '(() => {
  const b = [...document.querySelectorAll("button")].find(x => (x.textContent || "").includes("Reset pack"));
  if (b) { b.click(); return "reset"; }
  return "ABSENT";
})()' >/dev/null 2>&1
sleep 3

step "6. Strategy Tester — adaptateur BOS/CHoCH/CISD (mode AUTO TRADE)"
agent-browser eval '(() => {
  const tabs = [...document.querySelectorAll("button")].filter(b => (b.textContent || "").includes("Strategy Tester"));
  if (tabs.length) { tabs[tabs.length-1].click(); return "ouvert"; }
  return "ABSENT";
})()' >/dev/null 2>&1
sleep 3
agent-browser eval '(() => {
  const b = [...document.querySelectorAll("button")].find(x => (x.textContent || "").trim() === "AUTO TRADE");
  if (b) { b.click(); return "source"; }
  return "ABSENT";
})()' >/dev/null 2>&1
sleep 2
agent-browser eval '(() => {
  const sel = [...document.querySelectorAll("select")].find(s => [...s.options].some(o => o.value === "bos_choch_cisd"));
  if (!sel) return "ABSENT";
  const setter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, "value").set;
  setter.call(sel, "bos_choch_cisd");
  sel.dispatchEvent(new Event("change", { bubbles: true }));
  return "ok";
})()' >/dev/null 2>&1
sleep 5
STILL=$(agent-browser eval '(() => {
  const c = [...document.querySelectorAll("canvas")].find(x => (x.getAttribute("aria-label") || "").indexOf("BOS") >= 0);
  if (!c) return "0";
  const ctx = c.getContext("2d");
  const data = ctx.getImageData(0, 0, c.width, c.height).data;
  let drawn = 0;
  for (let i = 0; i < data.length; i += 4) if (data[i+3] >= 40) drawn++;
  return String(drawn);
})()' 2>/dev/null | tail -1 | tr -d '"')
echo "   overlay pendant le test : $STILL px"
[ "${STILL:-0}" -gt 500 ] 2>/dev/null && ok "overlay actif pendant le backtest (${STILL} px)" || ko "overlay pendant backtest (${STILL} px)"
EVAL=$(agent-browser eval '(() => {
  const sel = [...document.querySelectorAll("select")].find(s => [...s.options].some(o => o.value === "bos_choch_cisd"));
  return sel ? "present" : "absent";
})()' 2>/dev/null | tail -1 | tr -d '"')
[ "$EVAL" == "present" ] && ok "adaptateur sélectionnable dans le Strategy Tester" || ko "adaptateur sélectionnable"
shot tester-backtest

step "7. Store localStorage — réglages persistés"
PERSIST=$(agent-browser eval '(() => {
  const s = JSON.parse(localStorage.getItem("bos-choch-cisd-settings-v1") || "null");
  if (!s) return "ABSENT";
  return "size=" + s.labelSize + " textColour=" + s.textColour + " toggles=" + (s.bosUpAlert && s.bosDownAlert && s.cisdUpAlert ? "on" : "?");
})()' 2>/dev/null | tail -1 | tr -d '"')
echo "   store : $PERSIST"
echo "$PERSIST" | grep -q "size=Normal" && ok "réglages persistés dans le navigateur (store du pack)" || ko "store de réglages ($PERSIST)"
shot final

echo ""
echo "════════ RÉSULTAT E2E V1.11 : $PASS ✓ · $FAIL ✗ ════════"
[ "$FAIL" -eq 0 ] && exit 0 || exit 1
