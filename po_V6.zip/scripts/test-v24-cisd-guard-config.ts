/**
 * test-v24-cisd-guard-config.ts — v24 : Étapes de vérification CISD
 * ==================================================================== OPTIONNELLES
 * (cases à cocher) pour L_Lucien ProTrader, Ninja ProTrader et le
 * Strategy Tester.
 *
 * MISSION v24 :
 *   « j'aimerais que ces étapes soient optionnelles — l'utilisateur a le
 *     droit de choisir s'il veut activer les étapes de vérification et
 *     validation CISD UP et CISD Down comme dans les cases à cocher.
 *     L'utilisateur pourra aussi cocher s'il veut vérifier que le swing
 *     high ou low est violé tout comme pas violé. Il peut aussi choisir
 *     entre BOS Up + CISD Up ou CHoCH Up + CISD Up (cas d'un CALL) ou
 *     encore entre BOS Down + CISD Down ou CHoCH Down + CISD Down (cas
 *     d'un PUT). »
 *
 * 1. normalizeCisdGuardConfig : défauts v23, partiels, valeurs invalides.
 * 2. MACHINE À ÉTATS updateCisdGuard + config :
 *    - direction décochée → transition 'none' (garde neutre, ordre direct) ;
 *    - swingMode 'violated' → arme sur swing VIOLÉ (sweep), refuse intact ;
 *    - combos de confirmation : BOS/CHoCH décochés → combiné NON ACCEPTÉ,
 *      séquence consommée sans ordre ; cochés → CONFIRMÉ.
 * 3. MOTEUR evaluateBosChochCisdOrderRules : ordre direct v22 quand la
 *    direction est décochée, séquence complète sinon, libellés/reasons.
 * 4. WRAPPERS backend : L_Lucien + Ninja (config passée dans les options).
 * 5. STRATEGY TESTER : libellé d'ordre avec mode d'armement (violé/intact).
 * 6. VÉRIFICATIONS SOURCES : câblage backend (index.ts), persistance,
 *    hook frontend, panneau Auto Trade (cases à cocher).
 *
 * Exécution : npx tsx scripts/test-v24-cisd-guard-config.ts
 */
import {
  evaluateBosChochCisdOrderRules,
  computeBosChochCisd,
  createCisdGuardState,
  updateCisdGuard,
  normalizeCisdGuardConfig,
  DEFAULT_CISD_GUARD_CONFIG,
  type BosChochCisdCandle,
  type BosChochCisdEvent,
  type CisdGuardState,
} from '../shared/bos-choch-cisd.js'
import {
  evaluateNinjaProTraderStrategy,
  resetNinjaProTraderState,
} from '../mini-services/iqoption-backend/ninja-protrader-strategy.js'
import {
  evaluateBosChochCisdStrategy,
  resetBosChochCisdState,
} from '../mini-services/iqoption-backend/bos-choch-cisd-strategy.js'
import { buildLucienBacktestOrderLabel } from '../src/lib/lucien-backtest.js'
import { readFileSync } from 'node:fs'

let pass = 0, fail = 0
function ok(cond: boolean, label: string, detail = ''): void {
  if (cond) { pass++; console.log(`  ✓ ${label}${detail ? ' — ' + detail : ''}`) }
  else { fail++; console.error(`  ✗ ${label}${detail ? ' — ' + detail : ''}`) }
}

/* ══════════════ helpers bougies (mêmes géométries que v23) ══════════════ */

let t = 1_700_000_000
const mk = (open: number, close: number, high: number, low: number) => {
  t += 60
  return { open, close, high, low, volume: 100, time: t }
}

/** CISD Up SEUL (swing high 11.2 intact) — bougie 5. */
function buildStandaloneCisdUpSeries(): BosChochCisdCandle[] {
  return [
    mk(10, 10.8, 11, 9.9),       // 0 verte
    mk(10.8, 10.2, 12, 10.1),    // 1 rouge → sh(1)=12
    mk(10.2, 10.9, 11.1, 10),    // 2 verte → sl(2)=10
    mk(10.9, 10.4, 11.2, 9.8),   // 3 rouge → sh(3)=11.2 (low profond 9.8)
    mk(10.4, 10.6, 10.7, 10.3),  // 4 verte → sl(4)=9.8 → ut FAUX
    mk(10.6, 12.5, 12.6, 10.5),  // 5 verte : cassure 11.2 → CISD Up SEUL
  ]
}

/** Même série, bougie 4 MÈCHE au-dessus du swing high 11.2 → swing VIOLÉ. */
function buildViolatedCisdUpSeries(): BosChochCisdCandle[] {
  const s = buildStandaloneCisdUpSeries()
  s[4] = { ...s[4], high: 11.5 }
  return s
}

/** Prolongement : bougie 9 = BOS Up + CISD Up (sl ascendants → ut). */
function buildBosConfirmUpTail(): BosChochCisdCandle[] {
  return [
    mk(12.5, 12.0, 12.7, 11.9),  // 6 rouge → sh(6)=12.7
    mk(12.0, 12.3, 12.4, 11.95), // 7 verte → sl(7)=11.9
    mk(12.3, 12.1, 12.5, 12.0),  // 8 rouge → sh(8)=12.5
    mk(12.1, 12.8, 12.9, 12.05), // 9 verte : cassure 12.5 + ut → BOS Up + CISD Up
  ]
}

/**
 * v24 — Prolongement CHoCH : bougie 9 = CHoCH Up + CISD Up SEUL
 * (sh descendants → dt ; sl descendants → ut FAUX → pas de BOS Up).
 *   8 : low 11.85 → sl(9)=11.85 < sl(7)=11.9 → ut FAUX ;
 *   9 : close 12.55 > sh(8) 12.5, < sh(6) 12.7, close[1] 12.1 < 12.5 → CHoCH Up.
 */
function buildChochConfirmUpTail(): BosChochCisdCandle[] {
  return [
    mk(12.5, 12.0, 12.7, 11.9),   // 6 rouge → sh(6)=12.7
    mk(12.0, 12.3, 12.4, 11.95),  // 7 verte → sl(7)=11.9
    mk(12.3, 12.1, 12.5, 11.85),  // 8 rouge → sh(8)=12.5 (low profond 11.85)
    mk(12.1, 12.55, 12.65, 12.05),// 9 verte : CHoCH Up + CISD Up (PAS de BOS)
  ]
}

/** Miroir bas : CISD Down SEUL (swing low 8.8 intact). */
function buildStandaloneCisdDownSeries(): BosChochCisdCandle[] {
  return [
    mk(10, 9.2, 10.1, 9.0),      // 0' rouge
    mk(9.2, 9.8, 9.9, 8.0),      // 1' verte → sl(1')=8.0
    mk(9.8, 9.1, 10.0, 8.9),     // 2' rouge → sh(2')=10.0
    mk(9.1, 9.6, 10.2, 8.8),     // 3' verte → sl(3')=8.8
    mk(9.6, 9.4, 9.7, 9.3),      // 4' rouge → sh(4')=10.2 → dt FAUX
    mk(9.4, 7.5, 9.5, 7.4),      // 5' rouge : cassure 8.8 → CISD Down SEUL
  ]
}

/** Miroir violé : bougie 4' MÈCHE sous le swing low 8.8 (low 8.5). */
function buildViolatedCisdDownSeries(): BosChochCisdCandle[] {
  const s = buildStandaloneCisdDownSeries()
  s[4] = { ...s[4], low: 8.5 }
  return s
}

/** Miroir du prolongement BOS : bougie 9' = BOS Down + CISD Down. */
function buildBosConfirmDownTail(): BosChochCisdCandle[] {
  return [
    mk(7.5, 8.0, 8.1, 7.3),      // 6' verte → sl(6')=7.3
    mk(8.0, 7.7, 8.05, 7.6),     // 7' rouge → sh(7')=8.1
    mk(7.7, 7.9, 8.0, 7.5),      // 8' verte → sl(8')=7.5
    mk(7.9, 7.2, 7.95, 7.1),     // 9' rouge : cassure 7.5 + dt → BOS Down + CISD Down
  ]
}

/**
 * v24 — Miroir du prolongement CHoCH : bougie 9' = CHoCH Down + CISD Down
 * SEUL (sl ascendants → ut ; sh ascendants → dt FAUX → pas de BOS Down).
 */
function buildChochConfirmDownTail(): BosChochCisdCandle[] {
  return [
    mk(7.5, 8.0, 8.1, 7.3),     // 6' verte → sl(6')=7.3
    mk(8.0, 7.7, 8.05, 7.6),    // 7' rouge → sh(7')=8.1
    mk(7.7, 7.9, 8.15, 7.5),    // 8' verte → sl(8')=7.5 (high profond 8.15)
    mk(7.9, 7.45, 7.95, 7.35),  // 9' rouge : CHoCH Down + CISD Down (PAS de BOS)
  ]
}

/** Bougie 5 porte BOS Up + CISD Up d'emblée (ut) — cassure profonde v22. */
function buildDirectCombinedSeries(): BosChochCisdCandle[] {
  return [
    mk(10, 10.8, 11, 9.9),       // 0 verte
    mk(10.8, 10.2, 12, 10.1),    // 1 rouge → sh(1)=12
    mk(10.2, 10.9, 11.1, 10),    // 2 verte → sl(2)=10
    mk(10.9, 10.4, 11.2, 10.2),  // 3 rouge → sh(3)=11.2
    mk(10.4, 10.6, 10.7, 10.3),  // 4 verte → sl(4)=10.2 → uptrend
    mk(10.6, 12.5, 12.6, 10.5),  // 5 verte : cassure → BOS Up + CISD Up
  ]
}

/** Événements de la dernière bougie (labels). */
function lastBarEvents(candles: BosChochCisdCandle[]): string[] {
  const res = computeBosChochCisd(candles)
  return [...new Set(res.events.filter((e) => e.barIndex === candles.length - 1).map((e) => e.label))]
}

/** Événements de la dernière bougie (objets complets, pour updateCisdGuard). */
function lastBarFired(candles: BosChochCisdCandle[]): BosChochCisdEvent[] {
  const res = computeBosChochCisd(candles)
  return res.events.filter((e) => e.barIndex === candles.length - 1)
}

/** Évalue la machine à états sur toute la série, bougie par bougie. */
function runGuard(state: CisdGuardState, candles: BosChochCisdCandle[], config?: Parameters<typeof updateCisdGuard>[3]) {
  for (let k = 0; k < candles.length; k++) {
    const slice = candles.slice(0, k + 1)
    updateCisdGuard(state, slice, lastBarFired(slice), config)
  }
  return state.lastVerdict
}

const CALL_CISD = [{ id: 'call-1', alerts: ['CISD Up'] as const, expirationSeconds: 60 }]
const PUT_CISD = [{ id: 'put-1', alerts: ['CISD Down'] as const, expirationSeconds: 60 }]
const CALL_COMBINED = [{ id: 'call-2', alerts: ['BOS Up', 'CISD Up'] as const, expirationSeconds: 45 }]
const CALL_CHOCH = [{ id: 'call-3', alerts: ['CHoCH Up', 'CISD Up'] as const, expirationSeconds: 50 }]
const PUT_COMBINED = [{ id: 'put-2', alerts: ['BOS Down', 'CISD Down'] as const, expirationSeconds: 45 }]

async function main() {
  console.log('══ v24 — Étapes de vérification CISD optionnelles (cases à cocher) ══\n')

  /* ── 0. géométrie des fixtures (dont les NOUVEAUX tails CHoCH purs) ── */
  console.log('[0] Géométrie des fixtures')
  {
    const a = buildStandaloneCisdUpSeries()
    ok(lastBarEvents(a).join('|') === 'CISD Up', 'standalone UP : bougie 5 = CISD Up SEUL', lastBarEvents(a).join('|'))
    const viol = buildViolatedCisdUpSeries()
    ok(lastBarEvents(viol).join('|') === 'CISD Up', 'violée UP : bougie 5 = CISD Up SEUL (mèche invisible pour le moteur)')
    const bosTail = [...a, ...buildBosConfirmUpTail()]
    ok(lastBarEvents(bosTail).join('|') === 'BOS Up|CISD Up', 'tail BOS : bougie 9 = BOS Up + CISD Up', lastBarEvents(bosTail).join('|'))
    const chochTail = [...a, ...buildChochConfirmUpTail()]
    ok(lastBarEvents(chochTail).join('|') === 'CHoCH Up|CISD Up', 'v24 tail CHoCH : bougie 9 = CHoCH Up + CISD Up SEUL (sans BOS)', lastBarEvents(chochTail).join('|'))
    const d = buildStandaloneCisdDownSeries()
    ok(lastBarEvents(d).join('|') === 'CISD Down', 'standalone DOWN : bougie 5 = CISD Down SEUL')
    const dv = buildViolatedCisdDownSeries()
    ok(lastBarEvents(dv).join('|') === 'CISD Down', 'violée DOWN : bougie 5 = CISD Down SEUL')
    const bosDownTail = [...d, ...buildBosConfirmDownTail()]
    ok(lastBarEvents(bosDownTail).join('|') === 'BOS Down|CISD Down', 'tail BOS DOWN : bougie 9 = BOS Down + CISD Down', lastBarEvents(bosDownTail).join('|'))
    const chochDownTail = [...d, ...buildChochConfirmDownTail()]
    ok(lastBarEvents(chochDownTail).join('|') === 'CHoCH Down|CISD Down', 'v24 tail CHoCH DOWN : bougie 9 = CHoCH Down + CISD Down SEUL (sans BOS)', lastBarEvents(chochDownTail).join('|'))
    const v22 = buildDirectCombinedSeries()
    ok(lastBarEvents(v22).join('|') === 'BOS Up|CISD Up', 'fixture v22 : bougie 5 = BOS Up + CISD Up d\u2019emblée')
  }

  /* ── 1. normalizeCisdGuardConfig ── */
  console.log('\n[1] normalizeCisdGuardConfig — défauts v23, partiels, invalides')
  {
    const d = normalizeCisdGuardConfig()
    ok(d.up === true && d.down === true && d.swingMode === 'intact'
      && d.confirmBosUp === true && d.confirmChochUp === true
      && d.confirmBosDown === true && d.confirmChochDown === true, 'sans argument → défaut v23 intégral')
    ok(JSON.stringify(d) === JSON.stringify(DEFAULT_CISD_GUARD_CONFIG), 'défaut identique à DEFAULT_CISD_GUARD_CONFIG')
    const n = normalizeCisdGuardConfig(null)
    ok(n.up === true && n.swingMode === 'intact', 'null → défaut v23')
    const p = normalizeCisdGuardConfig({ up: false, swingMode: 'violated' })
    ok(p.up === false && p.down === true && p.swingMode === 'violated', 'partiel : up=false + swingMode=violated pris en compte, le reste par défaut')
    const inv = normalizeCisdGuardConfig({ up: 'yes' as unknown as boolean, swingMode: 'foo' as unknown as 'intact', confirmBosUp: 1 as unknown as boolean })
    ok(inv.up === true && inv.swingMode === 'intact' && inv.confirmBosUp === true, 'valeurs invalides ignorées → défauts v23')
  }

  /* ── 2. machine à états — direction décochée ── */
  console.log('\n[2] updateCisdGuard — direction décochée → garde neutre (ordre direct v22)')
  {
    let st = createCisdGuardState()
    const a = buildStandaloneCisdUpSeries()
    const v = updateCisdGuard(st, a, lastBarFired(a), { up: false })
    ok(v.transition === 'none' && v.orderAllowed === false, 'CISD Up seul + case UP décochée → transition none (aucun armement)', v.transition)
    ok(st.armed === null, 'aucun armement quand la direction est décochée')
    ok(v.detail.includes('désactivée'), 'le verdict documente la désactivation')

    st = createCisdGuardState()
    const dc = buildDirectCombinedSeries()
    const vc = updateCisdGuard(st, dc, lastBarFired(dc), { up: false })
    ok(vc.transition === 'none', 'combiné d\u2019emblée + case UP décochée → none (PAS de refus — c\u2019est le moteur qui laisse passer)', vc.transition)

    st = createCisdGuardState()
    const dn = buildStandaloneCisdDownSeries()
    const vdn = updateCisdGuard(st, dn, lastBarFired(dn), { down: false })
    ok(vdn.transition === 'none' && st.armed === null, 'miroir : CISD Down seul + case DOWN décochée → none')

    /* mixed : UP décochée, DOWN cochée → DOWN s\u2019arme encore */
    st = createCisdGuardState()
    const mixed = { up: false }
    const upFirst = updateCisdGuard(st, buildStandaloneCisdUpSeries(), lastBarFired(buildStandaloneCisdUpSeries()), mixed)
    ok(upFirst.transition === 'none' && st.armed === null, 'mixed : UP décochée → rien')
    const downThen = updateCisdGuard(st, dn, lastBarFired(dn), mixed)
    ok(downThen.transition === 'armed' && downThen.direction === 'down', 'mixed : DOWN cochée → armement down actif', downThen.transition)
  }

  /* ── 3. machine à états — swingMode 'violated' ── */
  console.log('\n[3] updateCisdGuard — swingMode « VIOLÉ » (sweep de liquidité)')
  {
    /* 3.1 swing VIOLÉ + mode violé → ARMÉ */
    let st = createCisdGuardState()
    const sv = buildViolatedCisdUpSeries()
    const v = updateCisdGuard(st, sv, lastBarFired(sv), { swingMode: 'violated' })
    ok(v.transition === 'armed' && v.orderAllowed === false, 'CISD Up + swing VIOLÉ + mode « violé » → ARMÉ', v.transition)
    ok(v.swingMode === 'violated', 'le verdict porte swingMode=violated')
    ok(v.detail.includes('VIOLÉ') && v.detail.includes('sweep'), 'l\u2019armement documente le sweep de liquidité')

    /* 3.2 confirmation après armement violé → swingMode violé */
    const svFull = [...sv, ...buildBosConfirmUpTail()]
    const last = runGuard(st, svFull, { swingMode: 'violated' })
    ok(last?.transition === 'confirmed' && last.orderAllowed === true, 'séquence complète (armement violé) : combiné BOS → CONFIRMÉ', last?.transition)
    ok(last?.swingMode === 'violated', 'la confirmation porte swingMode=violated (mode d\u2019armement)')

    /* 3.3 swing INTACT + mode violé → REFUS */
    st = createCisdGuardState()
    const a = buildStandaloneCisdUpSeries()
    const vi = updateCisdGuard(st, a, lastBarFired(a), { swingMode: 'violated' })
    ok(vi.transition === 'swing-violated' && st.armed === null, 'CISD Up + swing INTACT + mode « violé » → REFUS (exigence non remplie)', vi.transition)
    ok(vi.detail.includes('INTACT') && vi.detail.includes('VIOLÉ'), 'le refus documente l\u2019exigence (intact alors que violé exigé)')

    /* 3.4 défaut (mode intact) : swing violé → REFUS (v23 inchangé) */
    st = createCisdGuardState()
    const vd = updateCisdGuard(st, sv, lastBarFired(sv))
    ok(vd.transition === 'swing-violated' && st.armed === null, 'mode défaut « intact » : swing violé → REFUS (v23 inchangé)')

    /* 3.5 miroir DOWN : swing low violé + mode violé → ARMÉ */
    st = createCisdGuardState()
    const dvs = buildViolatedCisdDownSeries()
    const vdown = updateCisdGuard(st, dvs, lastBarFired(dvs), { swingMode: 'violated' })
    ok(vdown.transition === 'armed' && vdown.direction === 'down', 'miroir : CISD Down + swing low VIOLÉ + mode « violé » → ARMÉ (down)')
  }

  /* ── 4. machine à états — combinaisons de confirmation ── */
  console.log('\n[4] updateCisdGuard — cases BOS/CHoCH (combinaisons acceptées)')
  {
    /* 4.1 BOS cochée : séquence → BOS Up + CISD Up → CONFIRMÉ */
    let st = createCisdGuardState()
    const bosSeq = [...buildStandaloneCisdUpSeries(), ...buildBosConfirmUpTail()]
    const vb = runGuard(st, bosSeq, { confirmBosUp: true, confirmChochUp: false })
    ok(vb?.transition === 'confirmed' && vb.orderAllowed === true, 'BOS cochée (CHoCH décochée) : BOS Up + CISD Up → CONFIRMÉ', vb?.transition)

    /* 4.2 BOS décochée : séquence → BOS Up + CISD Up → REFUS « NON ACCEPTÉ » */
    st = createCisdGuardState()
    const vnb = runGuard(st, [...buildStandaloneCisdUpSeries(), ...buildBosConfirmUpTail()], { confirmBosUp: false })
    ok(vnb?.transition === 'refused' && vnb.orderAllowed === false, 'BOS décochée : BOS Up + CISD Up après armement → REFUS', vnb?.transition)
    ok(vnb?.detail.includes('NON ACCEPTÉ'), 'le refus documente « NON ACCEPTÉ comme confirmation »')
    ok(st.armed === null, 'la séquence armée est consommée par le combiné non accepté')

    /* 4.3 CHoCH décochée : séquence → CHoCH Up + CISD Up → REFUS */
    st = createCisdGuardState()
    const vnc = runGuard(st, [...buildStandaloneCisdUpSeries(), ...buildChochConfirmUpTail()], { confirmChochUp: false })
    ok(vnc?.transition === 'refused' && vnc?.detail.includes('NON ACCEPTÉ'), 'CHoCH décochée : CHoCH Up + CISD Up après armement → REFUS « NON ACCEPTÉ »')

    /* 4.4 CHoCH cochée : séquence → CHoCH Up + CISD Up → CONFIRMÉ */
    st = createCisdGuardState()
    const vc = runGuard(st, [...buildStandaloneCisdUpSeries(), ...buildChochConfirmUpTail()], { confirmChochUp: true })
    ok(vc?.transition === 'confirmed' && vc.orderAllowed === true, 'CHoCH cochée : CHoCH Up + CISD Up → CONFIRMÉ', vc?.transition)
    ok(vc?.confirmedBy?.join('+') === 'CHoCH Up', 'confirmé par [CHoCH Up]')

    /* 4.5 les DEUX cases CALL décochées → texte AUCUN + refus */
    st = createCisdGuardState()
    const vnone = runGuard(st, [...buildStandaloneCisdUpSeries(), ...buildBosConfirmUpTail()], { confirmBosUp: false, confirmChochUp: false })
    ok(vnone?.transition === 'refused', 'les deux cases CALL décochées : aucun combiné ne peut confirmer → REFUS')
    ok(vnone?.detail.includes('AUCUN'), 'le texte documente « AUCUN » (aucune combinaison cochée)')

    /* 4.6 miroir DOWN : BOS Down décochée → REFUS */
    st = createCisdGuardState()
    const vdnb = runGuard(st, [...buildStandaloneCisdDownSeries(), ...buildBosConfirmDownTail()], { confirmBosDown: false })
    ok(vdnb?.transition === 'refused' && vdnb?.detail.includes('NON ACCEPTÉ'), 'miroir : BOS Down décochée → BOS Down + CISD Down REFUSÉ')

    /* 4.7 miroir DOWN : CHoCH Down cochée → CONFIRMÉ */
    st = createCisdGuardState()
    const vdnc = runGuard(st, [...buildStandaloneCisdDownSeries(), ...buildChochConfirmDownTail()], { confirmChochDown: true, confirmBosDown: false })
    ok(vdnc?.transition === 'confirmed' && vdnc.orderAllowed === true, 'miroir : CHoCH Down cochée → CHoCH Down + CISD Down CONFIRMÉ', vdnc?.transition)

    /* 4.8 défaut (tout coché) : CHoCH et BOS confirment tous les deux (v23) */
    st = createCisdGuardState()
    const vdef = runGuard(st, [...buildStandaloneCisdUpSeries(), ...buildChochConfirmUpTail()])
    ok(vdef?.transition === 'confirmed', 'défaut v23 (tout coché) : CHoCH Up + CISD Up confirme aussi')
  }

  /* ── 5. moteur evaluateBosChochCisdOrderRules ── */
  console.log('\n[5] evaluateBosChochCisdOrderRules — ordre direct vs séquence selon les cases')
  {
    /* 5.1 UP décochée + règle [CISD Up] sur un CISD seul → CALL DIRECT (v22) */
    let st = createCisdGuardState()
    const a = buildStandaloneCisdUpSeries()
    const sig1 = evaluateBosChochCisdOrderRules(a, CALL_CISD, [], { cisdGuard: { state: st, config: { up: false } } })
    ok(sig1.action === 'CALL', 'case UP décochée : règle [CISD Up] sur CISD seul → CALL DIRECT (v22)', sig1.action)
    ok(!sig1.cisdConfirmation, 'aucune cisdConfirmation sur l\u2019ordre direct')
    ok(sig1.reason.includes('désactivée : ordre direct'), 'le reason documente l\u2019ordre direct', sig1.reason.slice(-80))

    /* 5.2 UP décochée + règle [BOS Up + CISD Up] sur cassure directe → CALL */
    st = createCisdGuardState()
    const sig2 = evaluateBosChochCisdOrderRules(buildDirectCombinedSeries(), CALL_COMBINED, [], { cisdGuard: { state: st, config: { up: false } } })
    ok(sig2.action === 'CALL' && sig2.matchedRuleId === 'call-2', 'case UP décochée : combiné d\u2019emblée + règle combinée → CALL DIRECT')

    /* 5.3 défaut (UP cochée) : CISD seul → HOLD ARMÉE (v23 inchangé) */
    st = createCisdGuardState()
    const sig3 = evaluateBosChochCisdOrderRules(a, CALL_CISD, [], { cisdGuard: { state: st } })
    ok(sig3.action === 'HOLD' && sig3.reason.includes('ARMÉE'), 'défaut : CISD Up seul → HOLD « séquence ARMÉE » (v23)')

    /* 5.4 mode violé : CISD sur swing violé → HOLD ARMÉE (armement) */
    st = createCisdGuardState()
    const sig4 = evaluateBosChochCisdOrderRules(buildViolatedCisdUpSeries(), CALL_CISD, [], { cisdGuard: { state: st, config: { swingMode: 'violated' } } })
    ok(sig4.action === 'HOLD' && sig4.reason.includes('ARMÉE'), 'mode « violé » : CISD Up sur swing VIOLÉ → HOLD ARMÉE')
    ok(sig4.reason.includes('sweep'), 'le reason documente le sweep')

    /* 5.5 mode violé : séquence complète → CALL avec swingMode violé */
    st = createCisdGuardState()
    let sig5action = 'HOLD'
    let sig5: ReturnType<typeof evaluateBosChochCisdOrderRules> | null = null
    const seqV = [...buildViolatedCisdUpSeries(), ...buildBosConfirmUpTail()]
    for (let k = 5; k < seqV.length; k++) {
      const slice = seqV.slice(0, k + 1)
      sig5 = evaluateBosChochCisdOrderRules(slice, CALL_CISD, [], { cisdGuard: { state: st, config: { swingMode: 'violated' } } })
      if (sig5.action !== 'HOLD') { sig5action = sig5.action; break }
    }
    ok(sig5action === 'CALL' && sig5?.cisdConfirmation?.swingMode === 'violated', 'mode « violé » : armement (violé) PUIS combiné → CALL avec swingMode=violé', `${sig5action} / ${sig5?.cisdConfirmation?.swingMode ?? '—'}`)

    /* 5.6 CHoCH décochée : règle [CHoCH Up + CISD Up] sur séquence CHoCH → HOLD NON ACCEPTÉ */
    st = createCisdGuardState()
    const seqCh = [...buildStandaloneCisdUpSeries(), ...buildChochConfirmUpTail()]
    let sig6action = 'HOLD'
    let sig6reason = ''
    for (let k = 5; k < seqCh.length; k++) {
      const slice = seqCh.slice(0, k + 1)
      const s = evaluateBosChochCisdOrderRules(slice, CALL_CHOCH, [], { cisdGuard: { state: st, config: { confirmChochUp: false } } })
      if (s.action !== 'HOLD') { sig6action = s.action; break }
      if (k === seqCh.length - 1) { sig6reason = s.reason }
    }
    ok(sig6action === 'HOLD' && sig6reason.includes('NON ACCEPTÉ'), 'CHoCH décochée : séquence CHoCH → HOLD « NON ACCEPTÉ »', sig6action)

    /* 5.7 CHoCH cochée (BOS décochée) : séquence CHoCH → CALL */
    st = createCisdGuardState()
    let sig7action = 'HOLD'
    for (let k = 5; k < seqCh.length; k++) {
      const slice = seqCh.slice(0, k + 1)
      const s = evaluateBosChochCisdOrderRules(slice, CALL_CHOCH, [], { cisdGuard: { state: st, config: { confirmChochUp: true, confirmBosUp: false } } })
      if (s.action !== 'HOLD') { sig7action = s.action; break }
    }
    ok(sig7action === 'CALL', 'CHoCH cochée (BOS décochée) : séquence CHoCH → CALL', sig7action)

    /* 5.8 DOWN décochée + règle [CISD Down] sur CISD Down seul → PUT DIRECT */
    st = createCisdGuardState()
    const sig8 = evaluateBosChochCisdOrderRules(buildStandaloneCisdDownSeries(), [], PUT_CISD, { cisdGuard: { state: st, config: { down: false } } })
    ok(sig8.action === 'PUT' && !sig8.cisdConfirmation, 'miroir : case DOWN décochée → PUT DIRECT sur CISD Down seul')

    /* 5.9 mixed : UP décochée (CALL direct) MAIS DOWN toujours protégée */
    st = createCisdGuardState()
    const sig9 = evaluateBosChochCisdOrderRules(a, CALL_CISD, PUT_CISD, { cisdGuard: { state: st, config: { up: false, down: true } } })
    ok(sig9.action === 'CALL', 'mixed : UP décochée → CALL direct pendant que DOWN reste protégée')
    const sig9d = evaluateBosChochCisdOrderRules(buildStandaloneCisdDownSeries(), CALL_CISD, PUT_CISD, { cisdGuard: { state: st, config: { up: false, down: true } } })
    ok(sig9d.action === 'HOLD', 'mixed : DOWN cochée → CISD Down seul reste HOLD (séquence armée)')

    /* 5.10 sans handle → v22 intégral (aucune vérification) */
    const sig10 = evaluateBosChochCisdOrderRules(a, CALL_CISD, [])
    ok(sig10.action === 'CALL', 'sans état de garde : comportement v22 inchangé (ordre direct)')
  }

  /* ── 6. wrappers backend (L_Lucien + Ninja) ── */
  console.log('\n[6] Wrappers backend — config passée dans les options')
  {
    /* 6.1 L_Lucien : UP décochée → ordre direct sur CISD seul */
    resetBosChochCisdState()
    const l1 = evaluateBosChochCisdStrategy(buildStandaloneCisdUpSeries(), 'TEST_v24_A', {}, { callRules: CALL_CISD as never, putRules: [] }, { cisdGuardConfig: { up: false } })
    ok(l1.action === 'CALL', 'L_Lucien : case UP décochée → CALL direct', l1.action)
    resetBosChochCisdState()
    const l2 = evaluateBosChochCisdStrategy(buildStandaloneCisdUpSeries(), 'TEST_v24_A', {}, { callRules: CALL_CISD as never, putRules: [] }, {})
    ok(l2.action === 'HOLD' && l2.reason.includes('ARMÉE'), 'L_Lucien : défaut → HOLD ARMÉE (v23)')
    resetBosChochCisdState()

    /* 6.2 L_Lucien : mode violé → armement sur swing violé */
    const lv = evaluateBosChochCisdStrategy(buildViolatedCisdUpSeries(), 'TEST_v24_B', {}, { callRules: CALL_CISD as never, putRules: [] }, { cisdGuardConfig: { swingMode: 'violated' } })
    ok(lv.action === 'HOLD' && lv.reason.includes('ARMÉE'), 'L_Lucien : mode « violé » → armement sur swing VIOLÉ')

    /* 6.3 Ninja : UP décochée → ordre direct AVANT clôture (bougie en formation) */
    resetNinjaProTraderState()
    const closed = buildStandaloneCisdUpSeries().slice(0, 5)
    const forming = { ...buildStandaloneCisdUpSeries()[5] }
    const n1 = evaluateNinjaProTraderStrategy(closed, forming, 'TEST_v24_N', { callRules: CALL_CISD as never, putRules: [] }, { cisdGuardConfig: { up: false } })
    ok(n1.action === 'CALL', 'Ninja : case UP décochée → CALL direct sur la bougie en formation', n1.action)
    resetNinjaProTraderState()
    const n2 = evaluateNinjaProTraderStrategy(closed, forming, 'TEST_v24_N', { callRules: CALL_CISD as never, putRules: [] }, {})
    ok(n2.action === 'HOLD' && n2.reason.includes('ARMÉE'), 'Ninja : défaut → armement (v23), aucun ordre sur le CISD seul')
    resetNinjaProTraderState()

    /* 6.4 Ninja : combos — CHoCH décochée refuse la confirmation.
     * Séquence CONTINUE (candles 0-9 consécutifs) : armement sur la bougie
     * en formation 5 (CISD seul), bougies 6-8 évaluées (aucun événement,
     * pas de GAP), puis bougie en formation 9 = CHoCH Up + CISD Up. */
    resetNinjaProTraderState()
    const ninjaSeq = [...buildStandaloneCisdUpSeries(), ...buildChochConfirmUpTail()]
    const ninjaRules = { callRules: [...CALL_CISD, ...CALL_CHOCH] as never, putRules: [] }
    let ninjaHolds = 0
    let ninjaFinal: ReturnType<typeof evaluateNinjaProTraderStrategy> | null = null
    for (let k = 5; k <= 9; k++) {
      const sig = evaluateNinjaProTraderStrategy(ninjaSeq.slice(0, k), ninjaSeq[k], 'TEST_v24_N2', ninjaRules, { cisdGuardConfig: { confirmChochUp: false } })
      if (sig.action === 'HOLD') ninjaHolds++
      ninjaFinal = sig
    }
    ok(ninjaFinal?.action === 'HOLD' && ninjaFinal.reason.includes('NON ACCEPTÉ'), 'Ninja : CHoCH décochée → confirmation refusée « NON ACCEPTÉ »', `${ninjaFinal?.action} (${ninjaHolds} HOLD)`)
    resetNinjaProTraderState()
    let ninjaCall: ReturnType<typeof evaluateNinjaProTraderStrategy> | null = null
    for (let k = 5; k <= 9; k++) {
      const sig = evaluateNinjaProTraderStrategy(ninjaSeq.slice(0, k), ninjaSeq[k], 'TEST_v24_N2', ninjaRules, { cisdGuardConfig: { confirmChochUp: true } })
      if (sig.action !== 'HOLD') { ninjaCall = sig; break }
    }
    ok(ninjaCall?.action === 'CALL' && ninjaCall?.cisdConfirmation?.confirmedBy?.includes('CHoCH Up'), 'Ninja : CHoCH cochée → CALL confirmé par CHoCH Up', ninjaCall?.action)
    resetNinjaProTraderState()
    resetBosChochCisdState()
  }

  /* ── 7. Strategy Tester — libellé avec mode d'armement ── */
  console.log('\n[7] Strategy Tester — libellés d\u2019ordre (mode violé / intact)')
  {
    const rules = [...CALL_CISD, ...CALL_COMBINED] as never
    const labViolated = buildLucienBacktestOrderLabel(
      {
        action: 'CALL', matchedRuleId: 'call-1', confidence: 0.75, reason: '', events: [], candleTime: 1,
        cisdConfirmation: { direction: 'up', armedCandleTime: 42, swingPrice: 1.2345, confirmedBy: ['BOS Up'], swingMode: 'violated' },
      },
      rules,
    )
    ok(labViolated.includes('CISD Up confirmé') && labViolated.includes('violé'), 'libellé backtest mode violé : « swing 1.2345 violé »', labViolated)
    const labIntact = buildLucienBacktestOrderLabel(
      {
        action: 'CALL', matchedRuleId: 'call-1', confidence: 0.75, reason: '', events: [], candleTime: 1,
        cisdConfirmation: { direction: 'up', armedCandleTime: 42, swingPrice: 1.2345, confirmedBy: ['BOS Up'] },
      },
      rules,
    )
    ok(labIntact.includes('intact'), 'libellé backtest défaut : « swing … intact » (swingMode absent → intact)')
  }

  /* ── 8. vérifications sources (câblage v24) ── */
  console.log('\n[8] Câblage v24 — sources')
  {
    const read = (p: string) => readFileSync(p, 'utf8')
    const shared = read('shared/bos-choch-cisd.ts')
    ok(shared.includes('export interface CisdGuardConfig') && shared.includes('export function normalizeCisdGuardConfig')
      && shared.includes('DEFAULT_CISD_GUARD_CONFIG'), 'shared : CisdGuardConfig + normaliseur + défaut exportés')
    ok(shared.includes('cisdGuardConfig?: Partial<CisdGuardConfig>'), 'shared : option cisdGuardConfig sur l\u2019évaluation')
    const index = read('mini-services/iqoption-backend/index.ts')
    ok(index.includes('cisdGuardUp?: boolean') && index.includes('cisdGuardSwingMode?: \'intact\' | \'violated\'')
      && index.includes('cisdGuardConfirmBosUp?: boolean') && index.includes('cisdGuardConfirmChochDown?: boolean'), 'backend index : clés cisdGuard* dans StrategyConfig')
    ok(index.includes('cisdGuardUp: true') && index.includes('cisdGuardSwingMode: \'intact\''), 'backend index : DEFAULT_CONFIG = v23 intégral')
    ok(index.includes('const cisdGuardConfig = {') && index.includes('cisdGuardConfig,'), 'backend index : config construite et passée à l\u2019évaluation')
    ok(index.includes('resetBosChochCisdState();') && index.includes('resetNinjaProTraderState();') && index.includes('cisdGuardChanged.length > 0'), 'backend index : reset des gardes au changement de cases')
    ok(index.includes('CISD ${ruleCisdDir === \'up\' ? \'Up\' : \'Down\'} direct (vérification désactivée)'), 'backend index : libellé « CISD direct (vérification désactivée) »')
    ok(index.includes('cisdGuard: {') && index.includes("session.config.cisdGuardSwingMode === 'violated' ? 'violated' : session.config.cisdGuardSwingMode === 'none' ? 'none' : 'intact'"), 'backend index : auto-trade-status porte cisdGuard (swingMode none v25 inclus)')
    const persistence = read('mini-services/iqoption-backend/session-persistence.ts')
    ok(persistence.includes('cisdGuardUp?: boolean') && persistence.includes('cisdGuardSwingMode?: \'intact\' | \'violated\'')
      && persistence.includes('config.cisdGuardConfirmChochDown = cfgRaw.cisdGuardConfirmChochDown'), 'persistance : clés cisdGuard* sanitizées + restaurées')
    const restore = read('mini-services/iqoption-backend/index.ts')
    ok(restore.includes('session.config.cisdGuardUp = snap.config.cisdGuardUp !== false')
      && restore.includes("session.config.cisdGuardSwingMode = snap.config.cisdGuardSwingMode === 'violated' ? 'violated' : snap.config.cisdGuardSwingMode === 'none' ? 'none' : 'intact'"), 'backend index : restauration snapshot sanitise les cases (none v25 inclus)')
    const hook = read('src/hooks/use-pocket-option.ts')
    ok(hook.includes('cisdGuardUp?: boolean') && hook.includes('cisdGuardSwingMode?: \'intact\' | \'violated\''), 'hook frontend : clés cisdGuard* exposées (setAutoConfig)')
    ok(hook.includes('cisdGuard?: {'), 'hook frontend : AutoTradeStatus porte cisdGuard')
    const panel = read('src/components/trading/auto-trade-panel.tsx')
    ok(panel.includes('const applyGuard = (patch: Partial<CisdGuardConfig>) => {'), 'UI : applyGuard pousse les cases au backend')
    ok(panel.includes('Vérifier CISD UP') && panel.includes('Vérifier CISD DOWN'), 'UI : cases d\u2019activation par direction')
    ok(panel.includes('Swing NON violé') && panel.includes('Swing VIOLÉ'), 'UI : choix swing non violé / violé')
    ok(panel.includes('CALL ▲ · BOS Up + CISD Up') && panel.includes('CALL ▲ · CHoCH Up + CISD Up'), 'UI : cases combinaisons CALL')
    ok(panel.includes('PUT ▼ · BOS Down + CISD Down') && panel.includes('PUT ▼ · CHoCH Down + CISD Down'), 'UI : cases combinaisons PUT')
    ok(panel.includes('séquence ARMÉE — aucun ordre, attente'), 'UI : tableau récapitulatif des 3 étapes')
    const settings = read('src/lib/bos-choch-cisd-settings.ts')
    ok(settings.includes('normalizeCisdGuardConfig(parsed.cisdGuard)'), 'settings : fusion profonde du cisdGuard persisté')
    const backtest = read('src/lib/lucien-backtest.ts')
    ok(backtest.includes('config: this.settings.cisdGuard'), 'backtester : config des cases appliquée au Strategy Tester')
  }

  console.log(`\n═══ RÉSULTAT v24 : ${pass} ✓ · ${fail} ✗ ═══`)
  process.exit(fail > 0 ? 1 : 0)
}

main().catch((err) => { console.error(err); process.exit(1) })
