/**
 * campaign-probe.mjs — Sonde pré-campagne v19.
 * ====================================================================
 * 1. Login avec les identifiants test par défaut codés en dur (page.tsx)
 * 2. Vérifie le solde du compte démo (broker RÉEL Pocket Option)
 * 3. Vérifie la disponibilité des assets OTC + payouts
 * 4. Vérifie la config auto-trade actuelle (état de session persisté)
 */
import { io } from 'socket.io-client';

const URL = 'http://127.0.0.1:3030';
const EMAIL = 'longuilcn@gmail.com';
const PASSWORD = 'Jean-Paul@#1964';

const sleep = ms => new Promise(r => setTimeout(r, ms));

async function main() {
  const socket = io(URL, { transports: ['websocket'], path: '/', reconnection: false, timeout: 10000 });

  const logs = [];
  socket.on('log', (ev) => {
    const m = String(ev?.message ?? '');
    logs.push(m);
    if (/balance|login|demo|asset|payout|symbol|stream/i.test(m)) console.log(`  [backend] ${m}`);
  });
  socket.on('status', (s) => {
    console.log(`  [status] balance=${JSON.stringify(s?.balance)} mode=${s?.mode} assets=${JSON.stringify(s?.assets ?? s?.activeAssets ?? null)}`);
  });

  const connected = await new Promise(r => {
    socket.once('connect', () => r(true));
    socket.once('connect_error', e => { console.log('connect_error:', e?.message); r(false); });
    setTimeout(() => r(false), 12000);
  });
  if (!connected) { console.error('✗ Backend injoignable'); process.exit(1); }
  console.log('[1] Backend connecté');

  console.log('[2] Login…');
  const loginResult = await new Promise(r => {
    socket.once('login-result', r);
    socket.emit('login', { email: EMAIL, password: PASSWORD, mode: 'demo' });
    setTimeout(() => r({ ok: false, error: 'timeout 90s' }), 90000);
  });
  if (!loginResult?.ok) {
    console.error('✗ LOGIN ÉCHOUÉ :', JSON.stringify(loginResult));
    process.exit(1);
  }
  console.log(`✓ Login OK (uid=${loginResult.user_id}, mode=${loginResult.mode}, resumed=${!!loginResult.resumed})`);

  // Laisse le temps aux streams/assets de se charger
  console.log('[3] Attente 25 s (streams, payouts, assets)…');
  await sleep(25000);

  // Auto-trade status (config persistée + contextes par asset)
  const ats = await new Promise(r => {
    socket.once('auto-trade-status', r);
    socket.emit('get-auto-status');
    setTimeout(() => r(null), 8000);
  });
  if (ats) {
    console.log('[4] Auto-trade status :');
    console.log(`    strategy=${ats.strategyId} betting=${ats.bettingStrategy} enabled=${ats.enabled}`);
    console.log(`    base=${ats.baseAmount} maxMartingaleSteps=${ats.maxMartingaleSteps} confirmCandle=${ats.bosChochCisdConfirmCandle}`);
    for (const [a, st] of Object.entries(ats.assets ?? {})) {
      console.log(`    ${a}: next=${st.nextBetAmount} losses=${st.stats?.consecutiveLosses} W/L/T=${st.stats?.wins}/${st.stats?.losses}/${st.stats?.pushes}`);
    }
  }

  // Liste des assets disponibles (catalogue markets)
  const cat = await new Promise(r => {
    socket.once('assets-list', r);
    socket.emit('get-assets');
    setTimeout(() => r(null), 8000);
  });
  if (cat) {
    const arr = Array.isArray(cat) ? cat : (cat.assets ?? []);
    console.log(`[5] ${arr.length} assets reçus`);
    const interesting = arr.filter(a => /EURUSD|GBPUSD|USDJPY|AUDUSD|XAUUSD/i.test(String(a?.symbol ?? a)));
    for (const a of interesting.slice(0, 12)) console.log(`    ${JSON.stringify(a)}`);
  }

  socket.close();
  process.exit(0);
}

main().catch(e => { console.error('FATAL:', e); process.exit(1); });
