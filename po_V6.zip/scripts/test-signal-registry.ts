/**
 * test-signal-registry.ts — v26 : SIGNAL_REGISTRY + filtres d'affichage.
 * ====================================================================
 * 1. §4/§5 — Registry central : 6 alertes ICT + 73 candles enregistrés,
 *    ids uniques, classification (catégorie/direction/nature §6) ;
 * 2. §23 — filtres de visibilité : master, groupes, 73 patterns
 *    individuels, masters candle bullish/bearish/neutral ;
 * 3. §24 — presets (Show All/Hide All/Minimal/Balanced/Full/Structure
 *    Only/ICT Only/Candle Only/Swings Only/Liquidity Only) ;
 * 4. §33 — SÉPARATION DISPLAY/TRADING : la visibilité ne filtre QUE le
 *    rendu (isSignalVisible), JAMAIS la détection ni le Rule Builder ;
 * 5. Migration : normalizeSignalDisplayFilters (localStorage anciens
 *    formats → défauts sûrs, jamais « tout masqué » par accident).
 *
 * Exécution : node --import tsx scripts/test-signal-registry.ts
 */
import {
  SIGNAL_REGISTRY,
  SIGNAL_REGISTRY_BY_ID,
  tradableSignalIds,
  getRegistryEntry,
  signalLabel,
  isCandleCondition,
  tradableConditionsByCategory,
  normalizeSignalDisplayFilters,
  isSignalVisible,
  applySignalDisplayPreset,
  SIGNAL_DISPLAY_PRESETS,
  SIGNAL_CATEGORY_ORDER,
  type SignalDisplayFilters,
} from '../shared/signal-registry.js'
import { CANDLE_PATTERN_DEFS } from '../shared/candle-patterns.js'
import { SignalLabelManager } from '../shared/signal-label-manager.js'

let pass = 0, fail = 0
function ok(cond: boolean, label: string) {
  if (cond) { pass++; console.log(`  ✓ ${label}`); }
  else { fail++; console.error(`  ✗ ${label}`); }
}

console.log('── 1. Registry central (§4/§5/§6) ──')
{
  ok(SIGNAL_REGISTRY.length === 6 + 73 + 54, `registry = 6 alertes ICT + 73 candles + 54 ICT classés non détectés (${SIGNAL_REGISTRY.length})`)
  const ids = new Set(SIGNAL_REGISTRY.map((s) => s.id))
  ok(ids.size === SIGNAL_REGISTRY.length, 'ids uniques (aucune collision)')
  for (const d of CANDLE_PATTERN_DEFS) {
    const e = SIGNAL_REGISTRY_BY_ID[d.id]
    if (!e) { ok(false, `pattern candle enregistré : ${d.id}`); continue }
  }
  ok(CANDLE_PATTERN_DEFS.every((d) => SIGNAL_REGISTRY_BY_ID[d.id] != null), 'les 73 patterns candle TOUS enregistrés dans le registry')
  ok(getRegistryEntry('BOS Up')?.category === 'STRUCTURE' && getRegistryEntry('BOS Up')?.nature === 'SIGNAL', 'BOS Up = STRUCTURE/SIGNAL')
  ok(getRegistryEntry('BOS Up')?.available === true, 'BOS Up disponible (moteur actuel)')
  ok(getRegistryEntry('hammer')?.category === 'CANDLE' && getRegistryEntry('hammer')?.tradable, 'hammer = CANDLE/tradable')
  /* §5 — signaux ICT classés mais non détectés par le moteur actuel. */
  const unavailable = SIGNAL_REGISTRY.filter((s) => !s.available)
  ok(unavailable.length > 40, `${unavailable.length} signaux ICT classés non détectés (extensibilité §5 — grisés dans les filtres)`)
  ok(!unavailable.some((s) => /killzone/i.test(s.id)), 'AUCUNE Killzone réintroduite (§43)')
  /* §6 — natures : un LEVEL/CONTEXT n'est jamais tradable. */
  ok(SIGNAL_REGISTRY.filter((s) => s.available).every((s) => s.nature === 'SIGNAL' && s.tradable), 'tous les signaux DISPONIBLES sont des SIGNAL tradables')
  ok(SIGNAL_REGISTRY.filter((s) => s.nature !== 'SIGNAL').every((s) => !s.available), 'les LEVEL/CONTEXT ne deviennent jamais automatiquement un CALL/PUT (§6)')
  ok(signalLabel('morning_star') === 'Morning Star', 'signalLabel — libellé lisible')
  ok(signalLabel('BOS Up') === 'BOS Up', 'signalLabel — alerte pack')
  ok(isCandleCondition('hammer') && !isCandleCondition('BOS Up'), 'isCandleCondition distingue candles/alertes')
  const tradable = tradableSignalIds()
  ok(tradable.length === 6 + 73, `conditions tradables = 6 + 73 (${tradable.length})`)
  const groups = tradableConditionsByCategory()
  ok(groups.length === 2 && groups[0].entries.length === 6 && groups[1].entries.length === 73, 'selector groupé : STRUCTURE (6) + CANDLE (73)')
}

console.log('── 2. Filtres de visibilité (§22/§23) ──')
{
  const base = normalizeSignalDisplayFilters(null)
  ok(base.showLabels === false, 'switch MASTER défaut OFF (aucun tag à l’initialisation)')
  ok(base.labelSize === 'Large', 'taille défaut Large (§29)')
  /* master OFF → rien, même groupes cochés. */
  ok(!isSignalVisible(base, { id: 'BOS Up', category: 'STRUCTURE', direction: 'bullish' }), 'master OFF → BOS Up invisible')
  const on: SignalDisplayFilters = { ...base, showLabels: true }
  ok(isSignalVisible(on, { id: 'BOS Up', category: 'STRUCTURE', direction: 'bullish' }), 'master ON → BOS Up visible')
  /* groupe OFF → tout le groupe masqué. */
  const noStruct: SignalDisplayFilters = { ...on, groups: { ...on.groups, STRUCTURE: false } }
  ok(!isSignalVisible(noStruct, { id: 'BOS Up', category: 'STRUCTURE', direction: 'bullish' }), 'groupe STRUCTURE OFF → BOS Up masqué')
  ok(isSignalVisible(noStruct, { id: 'hammer', category: 'CANDLE', direction: 'bullish' }), 'groupe STRUCTURE OFF n’affecte PAS les candles')
  /* pattern individuel. */
  const noHammer: SignalDisplayFilters = { ...on, signals: { hammer: false } }
  ok(!isSignalVisible(noHammer, { id: 'hammer', category: 'CANDLE', direction: 'bullish' }), 'hammer OFF → masqué SEUL')
  ok(isSignalVisible(noHammer, { id: 'bullish_engulfing', category: 'CANDLE', direction: 'bullish' }), 'engulfing reste visible')
  /* masters candle par direction. */
  const noBull: SignalDisplayFilters = { ...on, candleMasters: { bullish: false, bearish: true, neutral: true } }
  ok(!isSignalVisible(noBull, { id: 'hammer', category: 'CANDLE', direction: 'bullish' }), 'master bullish OFF → hammer masqué')
  ok(isSignalVisible(noBull, { id: 'bearish_engulfing', category: 'CANDLE', direction: 'bearish' }), 'master bearish ON → bearish engulfing visible')
  ok(isSignalVisible(noBull, { id: 'doji', category: 'CANDLE', direction: 'neutral' }), 'master neutral ON → doji visible')
}

console.log('── 3. Presets (§24) ──')
{
  ok(SIGNAL_DISPLAY_PRESETS.length === 10, '10 presets')
  const on: SignalDisplayFilters = normalizeSignalDisplayFilters({ showLabels: true })
  const showAll = applySignalDisplayPreset(on, 'show_all')
  ok(isSignalVisible(showAll, { id: 'hammer', category: 'CANDLE', direction: 'bullish' }), 'show_all → hammer visible')
  const hideAll = applySignalDisplayPreset(showAll, 'hide_all')
  ok(!isSignalVisible(hideAll, { id: 'hammer', category: 'CANDLE', direction: 'bullish' }), 'hide_all → hammer masqué')
  ok(!isSignalVisible(hideAll, { id: 'BOS Up', category: 'STRUCTURE', direction: 'bullish' }), 'hide_all → BOS Up masqué')
  const structureOnly = applySignalDisplayPreset(on, 'structure_only')
  ok(isSignalVisible(structureOnly, { id: 'BOS Up', category: 'STRUCTURE', direction: 'bullish' }), 'structure_only → BOS Up visible')
  ok(!isSignalVisible(structureOnly, { id: 'hammer', category: 'CANDLE', direction: 'bullish' }), 'structure_only → candle masqué')
  const candleOnly = applySignalDisplayPreset(on, 'candle_only')
  ok(isSignalVisible(candleOnly, { id: 'hammer', category: 'CANDLE', direction: 'bullish' }), 'candle_only → hammer visible')
  ok(!isSignalVisible(candleOnly, { id: 'BOS Up', category: 'STRUCTURE', direction: 'bullish' }), 'candle_only → BOS Up masqué')
  const minimal = applySignalDisplayPreset(on, 'minimal')
  ok(isSignalVisible(minimal, { id: 'BOS Up', category: 'STRUCTURE', direction: 'bullish' }), 'minimal → structure visible')
  ok(!isSignalVisible(minimal, { id: 'hammer', category: 'CANDLE', direction: 'bullish' }), 'minimal → candles masqués')
  /* les presets ne touchent NI le master NI la taille. */
  ok(showAll.showLabels === true && showAll.labelSize === on.labelSize, 'presets : master + taille inchangés')
}

console.log('── 4. Migration / normalisation (§31) ──')
{
  const junk = normalizeSignalDisplayFilters({ showLabels: 'yes', labelSize: 'GIGANTIC', groups: { STRUCTURE: 'nope' }, signals: { 'EMA 20': true, hammer: false }, candleMasters: { bullish: 42 } })
  ok(junk.showLabels === false, 'showLabels non booléen → défaut (false)')
  ok(junk.labelSize === 'Large', 'labelSize invalide → Large')
  ok(junk.groups.STRUCTURE !== false, 'groupe invalide → pas masqué par accident')
  ok(junk.signals['EMA 20'] === undefined && junk.signals.hammer === false, 'signaux inconnus ignorés, connus conservés')
  ok(junk.candleMasters.bullish === true, 'master non booléen → défaut true')
  const legacy = normalizeSignalDisplayFilters({ showLabels: true, labelSize: 'Small' })
  ok(legacy.showLabels === true && legacy.labelSize === 'Small', 'ancien format → valeurs reprises')
  ok(SIGNAL_CATEGORY_ORDER.length === 10, '10 groupes de filtres (§23)')
}

console.log('── 5. §33 + SignalLabelManager — masqué ≠ non détecté ──')
{
  /* Le manager ne reçoit que des entrées DÉJÀ détectées : la visibilité
   * filtre la SORTIE. Un pattern masqué reste dans les entrées détectées
   * (moteur) — on vérifie que le layout le retire du RENDU seulement. */
  const mgr = new SignalLabelManager()
  const events = [
    { id: 'BOS Up', label: 'BOS UP', category: 'STRUCTURE' as const, direction: 'bullish' as const, barIndex: 10, time: 1000, side: 'below' as const, referenceLevel: 110 },
    { id: 'hammer', label: 'HAMMER', category: 'CANDLE' as const, direction: 'bullish' as const, barIndex: 10, time: 1000, side: 'below' as const },
    { id: 'bullish_engulfing', label: 'ENGULFING', category: 'CANDLE' as const, direction: 'bullish' as const, barIndex: 10, time: 1000, side: 'below' as const },
  ]
  const allVisible = normalizeSignalDisplayFilters({ showLabels: true })
  const badgesAll = mgr.layout(events, { liveBarIndex: null, isSignalVisible: (id, c, d) => isSignalVisible(allVisible, { id, category: c, direction: d }) })
  ok(badgesAll.some((b) => b.ids.includes('hammer')), 'rendu complet : badge contient hammer')
  /* hammer masqué → badge candle réduit, détection inchangée (events intact). */
  const hammerHidden = normalizeSignalDisplayFilters({ showLabels: true, signals: { hammer: false } })
  const badgesHidden = mgr.layout(events, { liveBarIndex: null, isSignalVisible: (id, c, d) => isSignalVisible(hammerHidden, { id, category: c, direction: d }) })
  ok(!badgesHidden.some((b) => b.ids.includes('hammer')), 'hammer masqué → absent du RENDU (§33)')
  ok(badgesHidden.some((b) => b.ids.includes('bullish_engulfing')), 'engulfing toujours rendu')
  ok(events.length === 3, 'les DÉTECTIONS (entrées moteur) sont INTACTES (3 événements)')
  /* master OFF → rien. */
  const masterOff = normalizeSignalDisplayFilters({ showLabels: false })
  const badgesOff = mgr.layout(events, { liveBarIndex: null, isSignalVisible: (id, c, d) => isSignalVisible(masterOff, { id, category: c, direction: d }) })
  ok(badgesOff.length === 0, 'master OFF → aucun badge rendu (§22)')
  /* déduplication + groupage + LIVE + réutilisation d'objets. */
  const dup = mgr.layout([...events, ...events], { liveBarIndex: 10, isSignalVisible: () => true })
  const candleBadge = dup.find((b) => b.klass === 'candle')
  ok(Boolean(candleBadge), 'badge candle groupé (ENGULFING · HAMMER)')
  ok(candleBadge?.text.includes('HAMMER') && candleBadge?.text.includes('ENGULFING'), `badge compact multi-patterns : « ${candleBadge?.text} » (§25)`)
  ok(dup.every((b) => typeof b.lane === 'number' && b.lane >= 0), 'chaque badge a une voie (lanes §27)')
  const b1 = mgr.layout(events, { liveBarIndex: 10, isSignalVisible: () => true })
  const b2 = mgr.layout(events, { liveBarIndex: 10, isSignalVisible: () => true })
  const key1 = b1.map((b) => b.key).join('|')
  const key2 = b2.map((b) => b.key).join('|')
  ok(key1 === key2 && b1.length === b2.length, 'clés stables — badges réutilisés entre frames (§26/§29, pas recréés)')
  ok(b1.some((b) => b.live), 'flag LIVE sur les badges de la bougie en formation (préfixe « LIVE · » au rendu §29)')
  /* priorité : structure avant candle. */
  const structLane = b1.find((b) => b.klass === 'structure')?.lane
  const candleLane = b1.find((b) => b.klass === 'candle')?.lane
  ok(structLane != null && candleLane != null && structLane < candleLane, 'priorité : badge STRUCTURE en voie plus haute que CANDLE (§27)')
}

console.log(`\n${pass} ✓ · ${fail} ✗`)
if (fail > 0) process.exit(1)
