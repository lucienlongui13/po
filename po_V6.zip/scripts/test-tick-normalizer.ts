/**
 * test-tick-normalizer.ts — Tests du normaliseur de flux (§20 du ToDo).
 *
 * GARANTIES :
 *   - plusieurs ticks dans la même seconde → slots sous-seconde distincts ;
 *   - timestamps strictement croissants par actif ;
 *   - tick rejoué (même horodatage) → dropped + duplicateTickDropped ;
 *   - tick en retard (horodatage antérieur) → dropped + lateTickDropped ;
 *   - reconnexion : après reset, les ticks repartent proprement ;
 *   - marketTimeSec (temps marché) vs receivedAtMs (temps local) distincts.
 *
 * Exécution : cd mini-services/iqoption-backend && node --import tsx ../../scripts/test-tick-normalizer.ts
 */
import { StreamTickNormalizer, type NormalizedTick } from '../mini-services/iqoption-backend/stream-tick-normalizer.js';

let pass = 0, fail = 0;
const ok = (name: string, cond: boolean, detail = '') => {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); }
};

console.log('══ T1 — Plusieurs ticks dans la même seconde ══');
{
  const out: NormalizedTick[] = [];
  const n = new StreamTickNormalizer(t => out.push(t));
  n.ingestBatch([
    { asset: 'EURUSD_otc', bid: 1.16432, time: 1787915506.001 },
    { asset: 'EURUSD_otc', bid: 1.16430, time: 1787915506.401 },
    { asset: 'EURUSD_otc', bid: 1.16431, time: 1787915506.759 },
  ]);
  ok('3 arrivées de la même seconde → 3 ticks émis', out.length === 3, JSON.stringify(out));
  ok('slots sous-seconde distincts (t, t+0.5, t+0.75)',
    out[0].marketTimeSec === 1787915506 && out[1].marketTimeSec === 1787915506.5 && out[2].marketTimeSec === 1787915506.75,
    out.map(t => t.marketTimeSec).join(','));
  ok('tous dans la MÊME seconde (aucun arrondi au timeframe à la réception)',
    out.every(t => Math.floor(t.marketTimeSec) === 1787915506));
  ok('strictement croissants', out[0].marketTimeSec < out[1].marketTimeSec && out[1].marketTimeSec < out[2].marketTimeSec);
}

console.log('══ T2 — marketTimeSec vs receivedAtMs (§4 : notions de temps distinctes) ══');
{
  const out: NormalizedTick[] = [];
  const n = new StreamTickNormalizer(t => out.push(t));
  n.ingestBatch([{ asset: 'X', bid: 1, time: 1000 }]);
  const t = out[0];
  ok('marketTimeSec = temps marché tronqué à la seconde', t.marketTimeSec === 1000);
  ok('receivedAtMs = temps local ms (~Date.now())', Math.abs(t.receivedAtMs - Date.now()) < 5000);
  ok('marketTimeSec ≠ receivedAtMs (jamais confondus)', t.marketTimeSec * 1000 < t.receivedAtMs + 1e6);
}

console.log('══ T3 — Tick rejoué / en retard ══');
{
  const out: NormalizedTick[] = [];
  const n = new StreamTickNormalizer(t => out.push(t));
  n.ingestBatch([{ asset: 'X', bid: 1, time: 100 }, { asset: 'X', bid: 2, time: 100 }]);
  const sizeAfterFirstSecond = out.length;
  n.ingestBatch([{ asset: 'X', bid: 3, time: 101 }]); // seconde suivante
  n.ingestBatch([{ asset: 'X', bid: 99, time: 100 }]); // REJOUÉ : seconde passée
  ok('tick rejoué droppé (aucune émission)', out.length === sizeAfterFirstSecond + 1);
  const st = n.getStats();
  ok('compteur droppedStale ≥ 1', st.droppedStale >= 1);
  ok('compteur duplicateTickDropped ou lateTickDropped renseigné',
    st.duplicateTickDropped + st.lateTickDropped >= 1, JSON.stringify(st));
}

console.log('══ T4 — Multi-actifs indépendants ══');
{
  const out: NormalizedTick[] = [];
  const n = new StreamTickNormalizer(t => out.push(t));
  n.ingestBatch([
    { asset: 'EURUSD_otc', bid: 1.16, time: 200 },
    { asset: 'XAUUSD_otc', bid: 4400, time: 200 },
    { asset: 'EURUSD_otc', bid: 1.17, time: 200 },
  ]);
  const eur = out.filter(t => t.asset === 'EURUSD_otc');
  const xau = out.filter(t => t.asset === 'XAUUSD_otc');
  ok('chaque actif a sa propre chronologie sous-seconde',
    eur.length === 2 && xau.length === 1 && eur[0].marketTimeSec === 200 && eur[1].marketTimeSec === 200.5 && xau[0].marketTimeSec === 200);
}

console.log('══ T5 — Reconnexion (reset) ══');
{
  const out: NormalizedTick[] = [];
  const n = new StreamTickNormalizer(t => out.push(t));
  n.ingestBatch([{ asset: 'X', bid: 1, time: 500 }]);
  n.ingestBatch([{ asset: 'X', bid: 2, time: 501 }]);
  // Reconnexion : l'état est réinitialisé, les ticks repartent proprement.
  n.reset();
  const before = out.length;
  n.ingestBatch([{ asset: 'X', bid: 3, time: 502 }]);
  ok('après reset, un nouveau tick est accepté', out.length === before + 1);
  ok('les compteurs sont remis à zéro', n.getStats().received === 1 && n.getStats().droppedStale === 0);
  // Tick ancien rejoué APRÈS reset → le normaliseur repart de zéro : il est
  // accepté (nouvelle session) MAIS l'invariant strictement croissant est
  // rétabli à partir de lui.
  n.ingestBatch([{ asset: 'X', bid: 4, time: 503 }]);
  ok('après reconnexion, la chronologie continue strictement croissante', out[out.length - 1].marketTimeSec === 503);
}

console.log('══ T6 — Charge : invariants sur une longue série ══');
{
  const out: NormalizedTick[] = [];
  const n = new StreamTickNormalizer(t => out.push(t));
  // Simule ~2 ticks/seconde pendant 600 s + qlq rejeux
  const updates: Array<{ asset: string; bid: number; time: number }> = [];
  for (let s = 0; s < 600; s++) {
    updates.push({ asset: 'X', bid: 1 + (s % 10) * 0.001, time: 100000 + s });
    updates.push({ asset: 'X', bid: 1 + (s % 10) * 0.001 + 0.0005, time: 100000 + s });
  }
  // rejeux en vrac (reconnexion) : secondes déjà passées
  for (let s = 0; s < 600; s += 50) updates.push({ asset: 'X', bid: 9.99, time: 100000 + s });
  n.ingestBatch(updates);
  const times = out.map(t => t.marketTimeSec);
  let monotonic = true;
  for (let i = 1; i < times.length; i++) if (times[i] <= times[i - 1]) monotonic = false;
  ok(`1200 ticks émis, strictement croissants (12 rejeus droppés)`, out.length === 1200 && monotonic,
    `emitted=${out.length}`);
  const st = n.getStats();
  ok('stats : received=1212, emitted=1200, droppedStale=12',
    st.received === 1212 && st.emitted === 1200 && st.droppedStale === 12, JSON.stringify(st));
}

console.log('');
console.log('════════════════════════════════════');
console.log(`  RÉSULTAT : ${pass} PASS / ${fail} FAIL`);
console.log('════════════════════════════════════');
process.exit(fail > 0 ? 1 : 0);
