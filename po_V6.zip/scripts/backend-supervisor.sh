#!/bin/bash
# Backend supervisor: keeps the broker process independent from the frontend
# and restarts it after an unexpected crash. System reboot still requires the
# host to start start-dev.sh (or a process manager such as systemd).
set -u
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BACKEND_DIR="$ROOT_DIR/mini-services/iqoption-backend"
LOG_FILE="$ROOT_DIR/backend.log"
RESTART_DELAY=3
while true; do
  printf '[supervisor] starting backend at %s\n' "$(date -Iseconds)"
  (cd "$BACKEND_DIR" && exec npx tsx index.ts) >> "$LOG_FILE" 2>&1
  code=$?
  printf '[supervisor] backend exited code=%s at %s; restarting in %ss\n' "$code" "$(date -Iseconds)" "$RESTART_DELAY"
  sleep "$RESTART_DELAY"
done
