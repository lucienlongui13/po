// debug-verify-geometry.ts — simule les ticks EXACTS du mock (path+gap)
// → bougies construites → moteurs (BOS/CHoCH/CISD + 73 candles).
// Reproduit tickPrice/sendHistorySnapshot de mock-po-broker.mjs à l'identique.
const BODY = 0.00300;
const WICK = 0.00100;
const S = 5;
const PATH = [-1, 0.5, -1, 0.7, -0.2, 0.5, -0.05, 1.5, -1, 0.3, -1, 0.5];
const GAP = [0, 0, 0, 0, 0, 0, 0, -0.6, 0, 0, 0, 0];

function tickPrice(open, dir, k, body, wick) {
  const close = open + dir * body;
  if (wick > 0 && S >= 3) {
    if (k <= S - 2) return open + dir * body * (k / (S - 1));
    if (k === S - 1) return close + dir * wick;
    return close;
  }
  return open + dir * body * (k / S);
}

/* Historique de 300 buckets, ticks chaque 1 s. */
const buckets = 300;
let p = 1.18;
const built: Array<{ time: number; open: number; high: number; low: number; close: number }> = [];
for (let b = 0; b < buckets; b++) {
  const idx = b % PATH.length;
  const dir = PATH[idx] >= 0 ? 1 : -1;
  const body = Math.abs(PATH[idx]) * BODY;
  if (b > 0) p += GAP[idx] * BODY;
  const open = p;
  let hi = -Infinity, lo = Infinity;
  for (let k = 1; k <= S; k++) {
    const price = Number(tickPrice(open, dir, k, body, WICK).toFixed(5));
    hi = Math.max(hi, price); lo = Math.min(lo, price);
  }
  const close = Number((open + dir * body).toFixed(5));
  built.push({ time: b * S, open: Number(open.toFixed(5)), high: hi, low: lo, close });
  p = close;
}

/* Derniers cycles : événements par bougie. */
import { computeBosChochCisd } from '../shared/bos-choch-cisd.js'
import { detectCandlePatternsOnLastBar } from '../shared/candle-patterns.js'

let bosCount = 0, engCount = 0, both = 0;
for (let end = 60; end <= buckets; end++) {
  const slice = built.slice(Math.max(0, end - 120), end)
  const res = computeBosChochCisd(slice as never)
  const last = res.events.filter((e) => e.barIndex === slice.length - 1)
  const pats = detectCandlePatternsOnLastBar(slice as never)
  const hasBos = last.some((e) => e.label === 'BOS Up')
  const hasEng = pats.includes('bullish_engulfing')
  if (hasBos) bosCount++
  if (hasEng) engCount++
  if (hasBos && hasEng) both++
  if (end >= buckets - 24 && (hasBos || hasEng || pats.length)) {
    const pos = (end - 1) % PATH.length
    console.log(`bucket ${end - 1} pos=${pos}: BOS=${hasBos} patterns=[${pats.join(',')}] ut=${res.uptrend}`)
  }
}
console.log(`\nTOTAUX sur ${buckets - 60} bougies évaluées : BOS Up=${bosCount}, Bullish Engulfing=${engCount}, LES DEUX=${both}`)
console.log(`attendu : ~${Math.floor((buckets - 60) / PATH.length)} signaux (1 par cycle de ${PATH.length})`)
