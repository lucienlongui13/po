#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v1.2.sh — Livraison v1.2 « Strategy Tester Pro »
#   - corrections d'erreurs TypeScript (front + types AutoTradeStatus)
#   - champ « Mise de base » + martingale dans le Strategy Tester
#   - vitesses de replay X40 / X80
#   - test des stratégies Auto Trade dans le Strategy Tester
#   - Signal Strategy disponible comme stratégie d'Auto Trade
# Sortie : /home/z/my-project/download/pine_v6_engine_v1.2.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v1.2"
FOLDER=pine_v6_engine_v1.2
OUT="$ROOT/download/pine_v6_engine_v1.2.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (mêmes exclusions que la v1.0/v1.1) ────────────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude 'upload/' \
  --exclude 'download/' \
  --exclude 'tool-results/' \
  --exclude '.stage-v1.1/' \
  --exclude '.stage-v1.2/' \
  --exclude 'skills/' \
  --exclude 'bun.lock' \
  --exclude '*.tmp' \
  --exclude 'bun-error.log' \
  --exclude '.env.local' \
  --exclude 'tsconfig.tsbuildinfo' \
  --exclude 'next-env.d.ts' \
  --exclude '*.log' \
  --exclude '.logs/' \
  --exclude 'v12_*.png' \
  "$ROOT/" "$STAGE/$FOLDER/"

# ── README des nouveautés v1.2 ────────────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.2-STRATEGY-TESTER.md" <<'EOF'
# Pine v6 Engine — v1.2 « Strategy Tester Pro »

Basée sur la v1.1 (cartes de conditions v2), cette version corrige toutes les
erreurs TypeScript du build et livre 5 nouvelles fonctionnalités pour le
Strategy Tester. Aucune dépendance supplémentaire : `npm install` puis
`./start-dev.sh` comme avant.

## 0. Erreurs corrigées

- `src/app/page.tsx` — `chartRefreshSignal` manquait dans le retour du hook
  `usePocketOption` (clé de remontage du graphique).
- `auto-trade-panel.tsx` — interface `AutoTradeStatus` complétée avec les
  champs réellement diffusés par le backend : `otc`, `ninjaTrader`
  (SMS AI COACH), et le bloc SMART pro (`phase`, `regimeScore`,
  `structureScore`, `momentumScore`, `entryQuality`, `confirmationCount`,
  `blockers`, `analysis`).
- `indicators-library.ts` — les résultats typés FTFP / Fractal Live / BIS
  sont castés explicitement vers `Record<string, Series>`.
- `trade-markers-overlay.tsx` — `subscribeVisibleLogicalRangeChange` retourne
  `void` dans lightweight-charts 4.2.3 : désabonnement explicite via
  `unsubscribeVisibleLogicalRangeChange`.
- `tsconfig.json` — le dossier `skills/` (outillage interne) est exclu du
  type-check du projet applicatif.

## 1. Champ « Mise de base ($) »

Le Strategy Tester possède désormais un champ de saisie **Mise de base**
(0,1 $ → 500 $) dans l'onglet Réglages. C'est le point de départ de toutes
les mises simulées — et la base de la martingale.

## 2. Martingale comme stratégie de mises

Dans Réglages → **Stratégie de mises** : `FIXE` (toujours la mise de base)
ou `MARTINGALE` :

- après chaque perte, la mise est multipliée par le **facteur** réglable
  (×1,1 → ×3,0) ;
- après un gain, retour immédiat à la mise de base ;
- la mise est toujours **plafonnée au solde disponible** du replay ;
- la série de pertes en cours et la **prochaine mise** s'affichent en direct
  (en-tête du panneau + Réglages) ;
- les ordres ouverts en fin de liste ne masquent pas les pertes déjà réglées ;
- garde de ruine inchangée : le backtest s'arrête si le solde passe sous la
  mise de base. En live, les ordres réels utilisent la mise de base.

## 3. Vitesses de replay X40 et X80

La barre de replay gère deux nouvelles vitesses : **40x** (25 ms/bougie) et
**80x** (12 ms/bougie) — en plus de 0,5x → 20x.

## 4. Tester les stratégies de l'Auto Trade dans le Strategy Tester

Le panneau Signal Strategy a un nouveau sélecteur de source :
**CONDITIONS / AUTO TRADE**. En mode AUTO TRADE, la stratégie sélectionnée
remplace le moteur de conditions — même pipeline : cooldown, ordres simulés
en replay (avec martingale), stats du Strategy Tester, cartes sur le
lightweight-charts.

Stratégies testables (ports déterministes sur bougies clôturées) :

| Stratégie | Source |
|---|---|
| Live Fractal | shared/fractal-custom-live.ts |
| Fractal Live Custom BIS | shared/fractal-custom-live-bis.ts |
| Body Imbalance | shared/body-imbalance.ts |
| Hope (FTFP + Fractal Live) | shared/* |
| Ichimoku Prediction | port fidèle du backend |
| WaveTrend Resonance | port fidèle (canal EMA 9 + signal 4 + EMA21) |
| Zone + Confirmation (PDF) | port fidèle |
| Impulse + RSI (PDF) | port fidèle |
| 3 Bougies (PDF) | port fidèle |

Les stratégies tick-par-tick (Broker Flow Timing, BIS Velocity, Social…)
ne sont pas portables sur des bougies clôturées et restent en exécution
live uniquement.

## 5. Signal Strategy disponible dans l'Auto Trade

La liste des stratégies du panneau **Auto Trade** contient désormais
**« Signal Strategy (Conditions) »**. Quand l'Auto Trade est activé avec
cette stratégie :

- les émissions de conditions (panneau Signal Strategy, section OUVERTE et
  active) placent de **vrais ordres** via le pipeline place-order ;
- mise = mise de base du panneau Signal Strategy ; expiration = expiration
  (bougies) × durée de la bougie ;
- le toast de signal SMS est conservé et mentionne « ordre réel placé » ;
- en replay, rien ne change : ordres simulés uniquement.

## Lancer sur Termux

```bash
unzip pine_v6_engine_v1.2.zip
cd pine_v6_engine_v1.2
npm install --no-audit --no-fund
./start-dev.sh
```
EOF

# ── Création du zip ───────────────────────────────────────────────────────
rm -f "$OUT"
(cd "$STAGE" && zip -qr9 "$OUT" "$FOLDER")

# ── Vérification ──────────────────────────────────────────────────────────
echo "=== Archive créée : $OUT ==="
du -h "$OUT"
unzip -l "$OUT" | tail -1
echo "=== Fichiers clés présents ==="
unzip -l "$OUT" | grep -E 'autotrade-strategies|signal-strategy-panel|README-V1.2|package-lock.json$|iqoption-backend/index.ts' | awk '{print $1, $4}'

# Nettoyage du staging
rm -rf "$STAGE"
