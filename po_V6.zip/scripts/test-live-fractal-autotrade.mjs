import fs from 'fs'
const panel = fs.readFileSync('src/components/trading/auto-trade-panel.tsx','utf8')
const hook = fs.readFileSync('src/hooks/use-pocket-option.ts','utf8')
const backend = fs.readFileSync('mini-services/iqoption-backend/index.ts','utf8')
const engine = fs.readFileSync('mini-services/iqoption-backend/live-fractal.ts','utf8')
for (const [name, text, checks] of [
  ['panel', panel, [
    'liveFractalLookback?: number',
    'liveFractalStrictness?: number | null',
    'onConfigChange({ liveFractalLookback: v })',
    'const value = Number(raw)',
    'if (Number.isFinite(value))',
    'onConfigChange({ liveFractalStrictness: value })'
  ]],
  ['hook', hook, ['liveFractalLookback?: number','liveFractalStrictness?: number | null','socketRef.current?.emit(\'set-auto-config\', cfg)']],
  ['backend', backend, [
    'liveFractalLookback?: number;',
    'liveFractalStrictness?: number;',
    'if (typeof data.liveFractalLookback === \'number\' && Number.isFinite(data.liveFractalLookback))',
    'session.config.liveFractalStrictness = data.liveFractalStrictness;',
    'strictness: session.config.liveFractalStrictness,'
  ]],
  ['engine', engine, [
    'const strict = options.strictness ? 1 : 0;',
    'const bull = strict',
    'const bear = strict'
  ]],
]) for (const c of checks) if (!text.includes(c)) throw new Error(`${name}: missing ${c}`)
console.log('live-fractal autotrade pass-through checks: OK')
