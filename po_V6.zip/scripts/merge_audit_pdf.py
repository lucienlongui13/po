# -*- coding: utf-8 -*-
"""Fusion couverture + corps → PDF final normalisé A4."""
from pypdf import PdfReader, PdfWriter

A4_W, A4_H = 595.28, 841.89

COVER = "/home/z/my-project/scripts/audit_cover.pdf"
BODY = "/home/z/my-project/scripts/audit_body.pdf"
OUTPUT = "/home/z/my-project/download/rapport_audit_wavescope_ict.pdf"


def normalize_page_to_a4(page):
    box = page.mediabox
    w, h = float(box.width), float(box.height)
    if abs(w - A4_W) > 0.1 or abs(h - A4_H) > 0.1:
        page.scale_to(A4_W, A4_H)
    return page


writer = PdfWriter()
cover_page = PdfReader(COVER).pages[0]
writer.add_page(normalize_page_to_a4(cover_page))
for page in PdfReader(BODY).pages:
    writer.add_page(normalize_page_to_a4(page))

writer.add_metadata({
    "/Title": "Audit de conformité ICT / SMC — WaveScope Pine v6",
    "/Author": "Z.ai",
    "/Creator": "Z.ai",
    "/Subject": "Audit de conformité du script Pine WaveScope ICT/SMC au livre The Market's Secret Language",
})
with open(OUTPUT, "wb") as f:
    writer.write(f)
print("OK —", OUTPUT)
