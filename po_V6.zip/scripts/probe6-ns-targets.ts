/**
 * probe6-ns-targets.ts — verify that every v6 namespaced target used by the
 * upgrade mapping actually WORKS in piner (so the transform never introduces
 * new breakage).
 */
import { runPineScript } from '../src/lib/pine-engine'
import { readFileSync } from 'node:fs'

const raw = JSON.parse(readFileSync('scripts/dataset-eurusd-m1.json', 'utf8')) as any[]
const ds = (Array.isArray(raw) ? raw : raw.candles ?? raw.data ?? []).map((c: any) => ({
  time: Number(c.time), open: Number(c.open), high: Number(c.high), low: Number(c.low), close: Number(c.close),
  volume: Number(c.volume ?? 0),
}))

const targets: Array<[string, string]> = [
  ['ta.cum', 'plot(ta.cum(volume), title="x")'],
  ['ta.rma', 'plot(ta.rma(close, 14), title="x")'],
  ['ta.hma', 'plot(ta.hma(close, 21), title="x")'],
  ['ta.highest', 'plot(ta.highest(high, 10), title="x")'],
  ['ta.lowest', 'plot(ta.lowest(low, 10), title="x")'],
  ['ta.valuewhen', 'plot(ta.valuewhen(close > open, close, 0), title="x")'],
  ['ta.mom', 'plot(ta.mom(close, 10), title="x")'],
  ['ta.roc', 'plot(ta.roc(close, 10), title="x")'],
  ['ta.rsi', 'plot(ta.rsi(close, 14), title="x")'],
  ['ta.stoch', 'plot(ta.stoch(close, high, low, 14), title="x")'],
  ['ta.cci', 'plot(ta.cci(close, 14), title="x")'],
  ['ta.atr', 'plot(ta.atr(14), title="x")'],
  ['ta.tr', 'plot(ta.tr(true), title="x")'],
  ['ta.crossover', 'plot(ta.crossover(close, open) ? 1 : 0, title="x")'],
  ['ta.falling', 'plot(ta.falling(close, 3) ? 1 : 0, title="x")'],
  ['ta.pivothigh', 'plot(ta.pivothigh(high, 5, 5), title="x")'],
  ['math.abs', 'plot(math.abs(close - open), title="x")'],
  ['math.log', 'plot(math.log(close), title="x")'],
  ['math.pow', 'plot(math.pow(close, 2), title="x")'],
  ['math.sign', 'plot(math.sign(close - open), title="x")'],
  ['math.sum', 'plot(math.sum(volume, 10), title="x")'],
  ['math.avg', 'plot(math.avg(open, close), title="x")'],
  ['math.ceil', 'plot(math.ceil(close), title="x")'],
  ['math.floor', 'plot(math.floor(close), title="x")'],
]

function finiteOf(p: any): number {
  const data = p?.data
  if (!Array.isArray(data)) return -1
  return data.filter((d: any) => d != null && Number.isFinite(Number(d?.value ?? d))).length
}

async function main() {
  let ok = 0, bad = 0
  for (const [name, stmt] of targets) {
    const src = `//@version=6\nindicator("t", overlay=true)\n${stmt}`
    const res = await runPineScript(src, ds as any, { symbol: 'EURUSD_otc', timeframe: '1' })
    if (!res.ok) { console.log(`✗ ${name.padEnd(18)} ERROR: ${res.error.message.split('\n')[0].slice(0, 70)}`); bad++; continue }
    const n = finiteOf(res.result.plots[0])
    if (n > 0) { console.log(`✓ ${name.padEnd(18)} ${n}/2242`); ok++ }
    else { console.log(`✗ ${name.padEnd(18)} SILENT NA (0/2242)`); bad++ }
  }
  console.log(`\n${ok} ok / ${bad} broken`)
}
main()
