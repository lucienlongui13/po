#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# E2E V1.7 — IMPORT MULTI-LIBRAIRIES (pack PiracyChecker réel)
#   A. Main.pine chargé SANS librairies → bannière LIBRAIRIES REQUISES
#      (chemins + importeurs + boutons d'import) + pastilles ambre
#   B. Import du VRAI PiracyChecker.zip via le bouton « Importer un ZIP »
#      → 4 librairies enregistrées + alias + shim remplacé
#      → ré-exécution automatique → bannière DISPARUE → drawings
#   C. Réglages : 14 paramètres du script compilé
# ═══════════════════════════════════════════════════════════════════
cd /home/z/my-project
PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  ✓ $1"; }
ko()   { FAIL=$((FAIL+1)); echo "  ✗ $1"; }
step() { echo ""; echo "════════ $1 ════════"; }
shot() { agent-browser screenshot "scripts/$1" >/dev/null 2>&1 && echo "📸 $1"; }

if ! curl -s -m 3 -o /dev/null http://localhost:3000/ 2>/dev/null; then
  step "0. Services morts → ./po.sh"
  setsid nohup ./po.sh > .logs/po-restart.log 2>&1
  for i in $(seq 1 30); do sleep 4; curl -s -m 5 -o /dev/null http://localhost:3000/ && break; done
fi
curl -s -m 3 -o /dev/null http://localhost:3000/ && echo "front OK" || { echo "✗ front mort"; exit 1; }

# ── 1. Injection : Main.pine seul, AUCUNE librairie ──
step "1. Injection Main.pine (sans librairies)"
B64=$(base64 -w0 upload/piracy_extracted/Market_structures_scripts/Main.pine)
agent-browser open http://localhost:3000 >/dev/null 2>&1
sleep 10
agent-browser eval "(() => {
  localStorage.clear();
  const src = atob('$B64');
  const scripts = [{ id: 'pine-e2e-main', name: 'BOS, CHoCH and CISD [PiracyChecker]', source: src,
    meta: { version: 6, declaration: 'indicator', title: 'BOS, CHoCH and CISD [PiracyChecker]', overlay: true },
    enabled: true }];
  localStorage.setItem('pine-scripts-v1', JSON.stringify(scripts));
  return 'Main.pine injecté (' + src.length + ' car.)';
})()" 2>&1 | tail -1
agent-browser reload >/dev/null 2>&1
sleep 10

# ── 2. Login ──
step "2. Login"
agent-browser find role button click --name "Login with Pocket Option" >/dev/null 2>&1
for i in $(seq 1 12); do
  sleep 5
  if agent-browser snapshot -i -c 2>/dev/null | grep -q "PINE SCRIPT"; then break; fi
done
agent-browser snapshot -i -c 2>/dev/null | grep -q "PINE SCRIPT" && ok "loggé" || { ko "login"; exit 1; }
sleep 8

# ── 3. Scénario A : bannière LIBRAIRIES REQUISES ──
step "3. Scénario A — bannière sans librairies"
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('PINE SCRIPT'));
  if (!b) return 'BOUTON ABSENT';
  b.click(); return 'ÉDITEUR OUVERT';
})()" 2>&1 | tail -1
sleep 6

BANNER=$(agent-browser eval "(() => {
  const t = document.body.textContent;
  const has = t.includes('LIBRAIRIES REQUISES');
  const n = (t.match(/requise par/g) || []).length;
  return has ? 'BANNIÈRE+(' + n + ')' : 'ABSENTE';
})()" 2>&1 | tail -1 | tr -d '"')
echo "$BANNER" | grep -q "BANNIÈRE+(3)" && ok "bannière LIBRAIRIES REQUISES visible avec 3 dépendances" || ko "bannière : $BANNER"

P1=$(agent-browser eval "(() => document.body.textContent.includes('PiracyChecker/PubLibSwing/3') && document.body.textContent.includes('PiracyChecker/PubLibTrend/3') && document.body.textContent.includes('PiracyChecker/PubLibUtility/2') ? 'CHEMINS OK' : 'CHEMINS KO')()" 2>&1 | tail -1 | tr -d '"')
[ "$P1" = "CHEMINS OK" ] && ok "les 3 chemins auteur/nom/version listés" || ko "chemins : $P1"

BTNS=$(agent-browser eval "(() => {
  const t = document.body.textContent;
  return (t.includes('Importer le pack (ZIP)') ? '1' : '0') + (t.includes('Fichiers séparés') ? '1' : '0') + (t.includes('Gestion des librairies') ? '1' : '0');
})()" 2>&1 | tail -1 | tr -d '"')
[ "$BTNS" = "111" ] && ok "boutons ZIP / Fichiers séparés / Gestion présents" || ko "boutons : $BTNS"

ERRV=$(agent-browser eval "(() => {
  const err = [...document.querySelectorAll('div')].find(d => (d.textContent || '').startsWith('compiler:') || (d.textContent || '').includes('needs the community library'));
  return err ? 'ERREUR EXPLICITE' : 'PAS D ERREUR VISIBLE';
})()" 2>&1 | tail -1 | tr -d '"')
[ "$ERRV" = "ERREUR EXPLICITE" ] && ok "erreur compiler affichée dans la console de l'éditeur" || ko "erreur : $ERRV"
shot e2e-v17-banner.png

# ── 4. Scénario B : import du VRAI ZIP ──
step "4. Scénario B — import PiracyChecker.zip"
# 4a. injection du ZIP dans l'input fichier (DataTransfer + change) — équivalent
#     exact à un sélection manuelle dans le dialogue natif ; l'input reste caché.
B64ZIP=$(base64 -w0 upload/PiracyChecker.zip)
agent-browser eval "window.__zipB64 = '$B64ZIP'; 'ZIP STOCKÉ (' + window.__zipB64.length + ' car.)'" 2>&1 | tail -1
UP=$(agent-browser eval '(() => {
  const b64 = window.__zipB64;
  if (!b64) return "ZIP ABSENT";
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const file = new File([bytes], "PiracyChecker.zip", { type: "application/zip" });
  const input = [...document.querySelectorAll("input[type=file]")].find(i => (i.accept || "").includes("zip"));
  if (!input) return "INPUT ABSENT";
  const dt = new DataTransfer();
  dt.items.add(file);
  input.files = dt.files;
  input.dispatchEvent(new Event("change", { bubbles: true }));
  return "CHANGE DISPATCHÉ — " + bytes.length + " octets";
})()' 2>&1 | tail -1)
echo "upload → $UP"
sleep 10

# 4b. OUVRIR le panneau via le bouton d'en-tête « Librairies » (toujours présent)
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').trim().startsWith('Librairies'));
  if (!b) return 'BOUTON ABSENT';
  b.click(); return 'PANNEAU LIBRAIRIES';
})()" 2>&1 | tail -1
sleep 3

PANEL=$(agent-browser eval "(() => {
  const t = document.body.textContent;
  return (t.includes('Librairies Pine') ? '1' : '0') + (t.includes('Importer un pack complet') ? '1' : '0') + (t.includes('Importer un ZIP') ? '1' : '0') + (t.includes('Fichiers multiples') ? '1' : '0') + (t.includes('Ajout manuel') ? '1' : '0');
})()" 2>&1 | tail -1 | tr -d '"')
[ "$PANEL" = "11111" ] && ok "panneau Librairies Pine complet (import pack + registre + manuel)" || ko "panneau : $PANEL"

REP=$(agent-browser eval "(() => {
  const t = document.body.textContent;
  return (t.includes('librairie(s) enregistrée(s)') ? '1' : '0') + (t.includes('theEccentricTrader/PubLibSwing/3') ? '1' : '0') + (t.includes('alias') ? '1' : '0') + (t.includes('shim intégré remplacé') ? '1' : '0') + (t.includes('script(s) principal(aux) ajouté(s)') ? '1' : '0');
})()" 2>&1 | tail -1 | tr -d '"')
[ "$REP" = "11111" ] && ok "rapport : 4 enregistrées + alias theEccentricTrader + shim remplacé + main ajouté" || ko "rapport : $REP"

NREG=$(agent-browser eval "(() => {
  const m = document.body.textContent.match(/(\d+) librairie\(s\) enregistrée\(s\)/);
  return m ? m[1] : '0';
})()" 2>&1 | tail -1 | tr -d '"')
[ "$NREG" = "4" ] && ok "4 librairies enregistrées (fichiers du pack)" || ko "enregistrées : $NREG"
shot e2e-v17-import-report.png

# ── 5. Après import : fermeture du panneau, exécution automatique, bannière disparue ──
step "5. Après import — exécution automatique"
agent-browser eval "(() => { const b = document.querySelector('[data-testid=pine-libraries-close]'); if (b) { b.click(); return 'PANNEAU FERMÉ'; } return 'BOUTON ABSENT'; })()" 2>&1 | tail -1
sleep 12  # ré-exécution des scripts activés

GONE=$(agent-browser eval "(() => document.body.textContent.includes('LIBRAIRIES REQUISES') ? 'ENCORE LÀ' : 'DISPARUE')()" 2>&1 | tail -1 | tr -d '"')
[ "$GONE" = "DISPARUE" ] && ok "bannière LIBRAIRIES REQUISES disparue" || ko "bannière : $GONE"

DRAW=$(agent-browser eval "(() => {
  const m = document.body.textContent.match(/(\d+) drawing object\(s\)/);
  return m ? m[1] : '0';
})()" 2>&1 | tail -1 | tr -d '"')
[ "$DRAW" -gt 0 ] 2>/dev/null && ok "Main.pine exécuté automatiquement : $DRAW drawings (BOS/CHoCH/CISD sur les bougies live)" || ko "drawings : $DRAW"

NOERR=$(agent-browser eval "(() => document.body.textContent.includes('compiler:') ? 'ERREUR' : 'PROPRE')()" 2>&1 | tail -1 | tr -d '"')
[ "$NOERR" = "PROPRE" ] && ok "aucune erreur compiler résiduelle" || ko "erreur résiduelle"

HDR=$(agent-browser eval "(() => {
  const btn = [...document.querySelectorAll('button')].find(b => (b.textContent || '').trim().startsWith('Librairies'));
  if (!btn) return '0';
  const m = btn.textContent.match(/(\d+)/);
  return m ? m[1] : '0';
})()" 2>&1 | tail -1 | tr -d '"')
[ "$HDR" = "5" ] && ok "badge header « Librairies 5 » (4 libs + 1 alias)" || ko "badge : $HDR"

# persistance après reload
agent-browser reload >/dev/null 2>&1
sleep 12
PERS=$(agent-browser eval "(() => {
  const raw = localStorage.getItem('pine-libraries-v1');
  if (!raw) return '0';
  try { return String(JSON.parse(raw).length); } catch { return '0'; }
})()" 2>&1 | tail -1 | tr -d '"')
[ "$PERS" = "5" ] && ok "persistance localStorage : 5 clés après reload" || ko "persistance : $PERS"
shot e2e-v17-executed.png

# ── 6. Réglages : 14 paramètres ──
step "6. Modale Réglages — 14 paramètres"
# après le reload, l'éditeur est fermé → rouvrir
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('PINE SCRIPT'));
  if (!b) return 'BOUTON ABSENT';
  b.click(); return 'ÉDITEUR ROUVERT';
})()" 2>&1 | tail -1
sleep 4
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.title || '').startsWith('Réglages du script'));
  if (!b) return 'RÉGLAGES PINE ABSENT';
  b.click(); return 'MODALE PINE';
})()" 2>&1 | tail -1
sleep 6
NINP=0
for i in $(seq 1 12); do
  sleep 5
  NINP=$(agent-browser eval "(() => {
    const m = document.body.textContent.match(/(\d+) paramètres/);
    return m ? m[1] : '0';
  })()" 2>&1 | tail -1 | tr -d '"')
  [ "$NINP" = "14" ] && break
done
[ "$NINP" = "14" ] && ok "modale Réglages : 14 paramètres (schéma compilé du script + librairies)" || ko "paramètres : $NINP"
shot e2e-v17-settings.png

echo ""
echo "════════════════════════════════════"
echo "E2E V1.7 : $PASS ✓ · $FAIL ✗"
echo "════════════════════════════════════"
[ "$FAIL" = "0" ]
