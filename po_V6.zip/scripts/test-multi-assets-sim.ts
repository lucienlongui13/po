/**
 * test-multi-assets-sim.ts — SIMULATION MULTI-ASSETS 24 (horizon 90 min).
 * ====================================================================
 * Reproduit FIDÈLEMENT le câblage production (index.ts) :
 *   - CandleSyncManager periods [5,30,60,300], maxTickBuffer 4800
 *   - MarketDataHealth S30, minCandles 25
 *   - onSyncEvent → applySyncGapsToHealth (v6.11 : UNIQUEMENT pour le TF
 *     graphique — isolation par timeframe)
 *   - ingestHistoryFastSnapshot : ingestHistoryTicks + processHistory(closed)
 *   - fetchAndBroadcastHistory : beginHistoryLoad + ingestHistory + processHistory(seriesAll)
 *   - onChartCandleClosed : processCandle + scheduleGapResync (60 s throttle, 3 tentatives)
 *   - processAssetTick : onTick + ingestTick
 *   - reconnexion : re-push du snapshot fast
 *
 * v6.11 — DÉGRADATIONS RÉALISTES (absentes de la v1, cause du test vert
 * mensonger) : la simulation injecte désormais les conditions REelles du
 * multi-assets 24 :
 *   · STALLS LIVE STAGGÉRÉS (contention WS) : 2–4 min sans tick par asset,
 *     bougies JAMAIS servies (limite OTC — la source ne génère un symbole
 *     que lorsqu'il est actif) ;
 *   · MICRO-TROUS S5 (45–60 s) : pertes de ticks S5 seules — ne doivent
 *     PLUS atteindre la santé S30 (isolation par timeframe) ;
 *   · TROU INTERNE dans l'historique paginé (3 min, 40 min derrière le
 *     live — l'asset était inactif côté source) ;
 *   · RECONNEXION à T+35 min + re-push snapshots fast.
 *
 * ASSERTIONS STRICTES (exit code ≠ 0 si échec) :
 *   A1 — AUCUN canTrade() ne retourne JAMAIS reason = CRITICAL_GAP ;
 *   A2 — dès T+15 min, les 24 assets sont TRADING_OK à CHAQUE point de
 *        contrôle (aucun INSUFFICIENT_CANDLES persistant) ;
 *   A3 — des trades auto s'exécutent (stratégies non bloquées) ;
 *   A4 — les micro-pertes de ticks n'affectent QUE la qualité (score/gaps
 *        signalés), jamais la permission de trading.
 *
 * Exécution : npx tsx scripts/test-multi-assets-sim.ts
 */
import { CandleSyncManager, type SyncEvent } from '../mini-services/iqoption-backend/candle-sync-manager.js'
import { MarketDataHealth } from '../mini-services/iqoption-backend/market-data-health.js'

// ── Paramètres du scénario (valeurs production) ─────────────────────────────
const N_ASSETS = 24
const TF = 30                       // timeframe graphique S30
const PERIODS = [5, 30, 60, 300]    // comme index.ts:667
const MAX_TICK_BUFFER = 4800        // comme index.ts:668
const MIN_CANDLES = 25
const FAST_TICKS = 1301             // ~12 min @ ~0.48 s (HAR : 1301)
const FAST_SPAN_SEC = 621           // 1301 ticks × 0.48 s ≈ 621 s
const PAGINATED_CANDLES = 1440
const PAGINATION_GAP_SEC = 5382     // HAR : pagination finit ~90 min AVANT le début du live
const HISTORY_FETCH_CONCURRENCY = 4
const PAGINATION_WAVE_SEC = 45      // chaque vague de 4 assets prend ~45 s
const TICKS_PER_SEC = 2
const GAP_RESYNC_THROTTLE_MS = 60_000
const GAP_RESYNC_MAX_ATTEMPTS = 3
const RECONNECT_AT_MIN = 35         // reconnexion broker simulée à T+35 min

// ── Horloge virtuelle ───────────────────────────────────────────────────────
let VIRTUAL_MS = 1788219222000  // = T0_MS — horloge alignée sur le temps marché
const vnow = () => VIRTUAL_MS

// ── Générateur de prix (random walk déterministe) ───────────────────────────
let seed = 42
const rand = (): number => {
  seed = (seed * 1103515245 + 12345) % 2147483648
  return seed / 2147483648
}
class PriceGen {
  private p: number
  constructor(base: number) { this.p = base }
  next(): number { this.p += (rand() - 0.5) * 0.0008; return Number(this.p.toFixed(5)) }
}

interface AssetSim {
  asset: string
  health: MarketDataHealth
  gen: PriceGen
  paginatedAtMs: number | null      // quand la pagination arrive
  paginatedCandles: Array<{ time: number; open: number; high: number; low: number; close: number; volume: number }>
  lastProcessedCandleTime: number   // ctx.candleState.lastProcessedCandleTime
  gapResync: { lastTs: number; attempts: number }
  gapRepairLastAttempt: number
  repairAttempts: number            // candleSync.requestRepair attempts (via état série)
  trades: number
  blockedReasons: Map<string, number>
  // v6.11 — dégradations réalistes :
  stallFromSec: number | null       // début du grand stall (contention WS), null = n/a
  stallToSec: number | null         // fin du grand stall (bougies jamais servies)
  microStallPhaseSec: number        // phase des micro-stalls S5 (45-60 s)
  microStallCount: number           // compteur des micro-stalls subis (assert A4)
}

// ── Le gestionnaire de synchronisation (CÂBLÉ comme index.ts) ───────────────
const ASSETS: AssetSim[] = []
const registry = new Set<string>()
const pipelineFor = (asset: string) => ASSETS.find(a => a.asset === asset)

const candleSync = new CandleSyncManager({
  periods: PERIODS,
  maxTickBuffer: MAX_TICK_BUFFER,
  maxCandlesPerSeries: 300,
  onCandleClosed: (asset, periodSec, candle) => onChartCandleClosed(asset, periodSec, candle as any),
  onSyncEvent: (event: SyncEvent) => {
    // ── index.ts:673-701 (câblage v6.11 — ISOLATION PAR TIMEFRAME) ──
    if (
      (event.type === 'gap-detected' || event.type === 'history-loaded')
      && event.periodSec === TF
    ) {
      applySyncGapsToHealth(event.asset, (event.data as any)?.gapDetails)
    }
    if (event.type === 'gap-detected' && registry.has(event.asset) && event.periodSec === TF) {
      repairDetectedGaps(event.asset, event.periodSec)
    }
  },
})

// ── applySyncGapsToHealth (index.ts:846-882, EXACT y compris fallback) ──────
function applySyncGapsToHealth(asset: string, gapDetails: unknown): void {
  const sim = pipelineFor(asset)
  if (!sim) return
  if (Array.isArray(gapDetails)) {
    const holes = (gapDetails as Array<Record<string, unknown>>)
      .map(g => ({
        endTimeSec: typeof g.endTime === 'number' ? g.endTime : undefined,
        startTimeSec: typeof g.startTime === 'number' ? g.startTime : undefined,
        missingCandles: typeof g.missingCandles === 'number' ? g.missingCandles : 1,
      }))
      .filter(g => g.missingCandles > 0)
    const liveEdge = candleSync.getLatestMarketTimeSec(asset)
    const firstLiveSec = candleSync.getFirstLiveTickSec(asset)
    sim.health.onSyncGaps(holes, vnow(), liveEdge > 0 ? liveEdge : undefined, firstLiveSec > 0 ? firstLiveSec : undefined)
    // v6.10.1 — recompte rétroactif des bougies fraîches
    if (sim.health.liveSeamFirstSec != null) {
      sim.health.recountFreshCandles(candleSync.getClosed(asset, TF, 2000))
    }
    return
  }
  // Fallback legacy — index.ts:880
  const count = typeof gapDetails === 'number' ? gapDetails : 1
  if (count > 0) sim.health.onGapsDetected(count)
}

// ── ingestHistoryFastSnapshot (index.ts:3365-3426, essentiel) ───────────────
function ingestHistoryFastSnapshot(asset: string, ticks: Array<{ time: number; price: number }>): void {
  if (!registry.has(asset)) return
  if (!Array.isArray(ticks) || ticks.length === 0) return
  const res = candleSync.ingestHistoryTicks(asset, ticks)
  if (res.merged <= 0) return
  const series = candleSync.getSeries(asset, TF)
  const sim = pipelineFor(asset)
  if (sim && series.closed.length > 0) {
    const closed = series.closed
    // v6.10.1 — deep: false (le snapshot fast est du live seedé)
    sim.health.onHistoryIngested({
      closedCount: closed.length,
      firstTimestamp: closed[0].time,
      lastTimestamp: closed[closed.length - 1].time,
    }, { deep: false })
  }
}

// ── fetchAndBroadcastHistory (index.ts:3246-3344, essentiel) ────────────────
async function fetchAndBroadcastHistory(asset: string, reason: string): Promise<void> {
  const sim = pipelineFor(asset)
  if (!sim) return
  const generation = candleSync.beginHistoryLoad(asset, TF)
  await later(PAGINATION_WAVE_SEC * 1000)   // la pagination prend du temps
  if (!registry.has(asset)) return
  const ingest = candleSync.ingestHistory(asset, TF, sim.paginatedCandles, { generation, source: 'history' })
  if (!ingest.accepted) { logSim(`[HISTORY] ${asset} IGNORÉ (${ingest.reason})`); return }
  const seriesAll = [...ingest.series.closed, ...(ingest.series.forming ? [ingest.series.forming] : [])]
  // v6.10.1 — bougies CLÔTURÉES uniquement + deep: true
  const closed = ingest.series.closed
  sim.health.onHistoryIngested({
    closedCount: closed.length,
    firstTimestamp: closed.length ? closed[0].time : null,
    lastTimestamp: closed.length ? closed[closed.length - 1].time : null,
  }, { deep: true })
  logSim(`[HISTORY] ${asset} pagination (${reason}) : ${seriesAll.length} bougies fusionnées`)
}

// ── scheduleGapResync (index.ts:1127-1146) ──────────────────────────────────
function scheduleGapResync(asset: string): void {
  if (!registry.has(asset)) return
  const sim = pipelineFor(asset)!
  const key = `${asset}:${TF}`
  const st = sim.gapResync
  if (VIRTUAL_MS - st.lastTs < GAP_RESYNC_THROTTLE_MS) return
  if (st.attempts >= GAP_RESYNC_MAX_ATTEMPTS) return
  st.lastTs = VIRTUAL_MS
  st.attempts++
  logSim(`[GAP_RESYNC] ${asset} tentative ${st.attempts}`)
  void fetchAndBroadcastHistory(asset, 'gap-resync')
}

// ── repairDetectedGaps (index.ts:1237-, essentiel) ──────────────────────────
let repairsScheduled = 0
function repairDetectedGaps(asset: string, periodSec: number): void {
  if (!registry.has(asset) || TF !== periodSec) return
  const sim = pipelineFor(asset)!
  if (VIRTUAL_MS - sim.gapRepairLastAttempt < 60_000) return
  sim.gapRepairLastAttempt = VIRTUAL_MS
  // requestRepair : série en GAP_DETECTED + < 3 tentatives
  const req = candleSync.requestRepair(asset, periodSec)
  if (!req.started) return
  repairsScheduled++
  // Le repair fait un loadHistoryPeriod ciblé → mêmes données paginées
  void (async () => {
    await later(8_000)
    if (!registry.has(asset)) return
    const mapped = sim.paginatedCandles.slice(-Math.max(20, req.gaps.reduce((a, g) => a + g.missingCandles + 2, 0)))
    candleSync.ingestHistory(asset, periodSec, mapped, { generation: req.generation, source: 'history' })
  })()
}

// ── onChartCandleClosed (index.ts:1148-1215, essentiel pour la santé) ──────
function onChartCandleClosed(asset: string, periodSec: number, candle: { time: number }): void {
  if (!registry.has(asset)) return
  if (periodSec !== TF) return
  const sim = pipelineFor(asset)!
  const healthState = sim.health.update(vnow())
  sim.health.onCandleClosed(candle as any, vnow())
  const st = sim.health.update(vnow())
  const blockingGaps = (st.recentGapCount ?? 0) - (st.seamGapCount ?? 0)
  if (blockingGaps > 0) scheduleGapResync(asset)
  if (candle.time <= sim.lastProcessedCandleTime) return
  sim.lastProcessedCandleTime = candle.time
  // AUTO-TRADE : evaluateCoachOnCandleClose → canTrade()
  const check = sim.health.canTrade(vnow())
  if (check.allowed) sim.trades++
  else {
    const r = check.reason ?? 'UNKNOWN'
    sim.blockedReasons.set(r, (sim.blockedReasons.get(r) ?? 0) + 1)
  }
}

// ── processAssetTick (index.ts:4229-, essentiel) ────────────────────────────
function processAssetTick(asset: string, marketTimeSec: number, price: number): void {
  if (!registry.has(asset)) return
  const sim = pipelineFor(asset)!
  sim.health.onTick(vnow())
  candleSync.ingestTick(asset, { marketTimeSec, price, receivedAtMs: vnow() })
}

// ── Utilitaires ─────────────────────────────────────────────────────────────
const pending: Array<{ atMs: number; run: () => void | Promise<void> }> = []
const later = (ms: number): Promise<void> => new Promise(res => { pending.push({ atMs: VIRTUAL_MS + ms, run: () => res() }) })
const logSim = (m: string) => { /* console.log(m) */ }
const SIM_MS_PER_STEP = 100   // 100 ms virtuels par pas

function genFastTicks(gen: PriceGen, tEndSec: number): Array<{ time: number; price: number }> {
  const out: Array<{ time: number; price: number }> = []
  let t = tEndSec - FAST_SPAN_SEC
  while (t < tEndSec) { out.push({ time: Number(t.toFixed(3)), price: gen.next() }); t += 0.48 }
  return out
}
function genPaginated(gen: PriceGen, liveStartSec: number): Array<{ time: number; open: number; high: number; low: number; close: number; volume: number }> {
  const out = []
  const end = liveStartSec - PAGINATION_GAP_SEC
  for (let i = 0; i < PAGINATED_CANDLES; i++) {
    const time = Math.floor((end - (PAGINATED_CANDLES - 1 - i) * TF) / TF) * TF
    // v6.11 — TROU INTERNE (asset inactif côté source) : 3 minutes
    // manquantes ~40 min derrière le live (jamais servies — la pagination
    // réelle contient de tels trous pour les symboles OTC peu actifs).
    const holeStart = end - 40 * 60
    if (time > holeStart && time <= holeStart + 180) continue
    const o = gen.next(); const c = gen.next()
    out.push({ time, open: o, close: c, high: Math.max(o, c) + 0.0002, low: Math.min(o, c) - 0.0002, volume: 40 })
  }
  return out
}

// ── SCÉNARIO ────────────────────────────────────────────────────────────────
const NAMES = ['EURUSD_otc', 'GBPUSD_otc', 'USDJPY_otc', 'AUDCAD_otc', 'EURNZD_otc', 'XAUUSD_otc',
  'UKBrent_otc', 'XAGUSD_otc', 'USDCHF_otc', 'CADJPY_otc', 'EURJPY_otc', 'GBPJPY_otc',
  'AUDUSD_otc', 'NZDUSD_otc', 'USDCAD_otc', 'EURGBP_otc', 'EURCHF_otc', 'CHFJPY_otc',
  'AUDJPY_otc', 'AUDNZD_otc', 'NZDJPY_otc', 'EURAUD_otc', 'GBPAUD_otc', 'GBPCAD_otc']

const T0_SEC = 1788219222         // base temps marché (HAR)
const T0_MS = 1788219222000

function setup(): void {
  candleSync.setActiveAssets(NAMES, TF, NAMES[0])
  for (let i = 0; i < N_ASSETS; i++) {
    const asset = NAMES[i]!
    const gen = new PriceGen(1.05 + i * 0.013)
    const health = new MarketDataHealth(asset, { timeframeSec: TF, minCandles: MIN_CANDLES, minHealthScoreToTrade: 80, streamConnected: true })
    const liveStart = T0_SEC
    // v6.11 — stall LIVE contention WS : 2 à 4 min sans tick, démarrant
    // entre T+2 min et T+9 min (étalé sur les 24 assets), bougies JAMAIS
    // servies ensuite (limite OTC).
    const stallDurSec = 120 + (i % 3) * 60        // 120/180/240 s
    const stallFrom = T0_SEC + 120 + (i * 18)     // T+2 min → T+9 min
    ASSETS.push({
      asset, health, gen,
      paginatedAtMs: (Math.floor(i / HISTORY_FETCH_CONCURRENCY) + 1) * PAGINATION_WAVE_SEC * 1000,
      paginatedCandles: genPaginated(gen, liveStart),
      lastProcessedCandleTime: 0,
      gapResync: { lastTs: 0, attempts: 0 },
      gapRepairLastAttempt: 0,
      repairAttempts: 0,
      trades: 0,
      blockedReasons: new Map(),
      stallFromSec: stallFrom,
      stallToSec: stallFrom + stallDurSec,
      microStallPhaseSec: (i * 37) % 300,          // micro-stalls décalés par asset
      microStallCount: 0,
    })
    registry.add(asset)
  }
}

// Ticks live par asset — le flux updateStream (2/s), marché = temps virtuel
async function main(): Promise<void> {
  setup()
  console.log(`Simulation multi-assets : ${N_ASSETS} assets, TF S${TF}, horizon 90 min\n`)

  // T0 : snapshot fast pour CHAQUE asset (comme activateSymbolStreams → changeSymbol)
  for (const sim of ASSETS) {
    const ticks = genFastTicks(sim.gen, T0_SEC)
    ingestHistoryFastSnapshot(sim.asset, ticks)
  }
  // File de pagination (concurrence 4 → vagues de PAGINATION_WAVE_SEC)
  for (const sim of ASSETS) {
    void (async () => { await later(sim.paginatedAtMs!); await fetchAndBroadcastHistory(sim.asset, 'select-assets') })()
  }

  const CHECKPOINTS = [1, 2, 5, 10, 15, 20, 30, 40, 50, 60, 75, 90].map(m => T0_MS + m * 60_000)
  let nextCp = 0
  const lastTickByAsset = new Map<string, number>()

  const TOTAL_MS = 90 * 60_000
  let fastReconnectPushed = false
  while (VIRTUAL_MS < T0_MS + TOTAL_MS) {
    VIRTUAL_MS += SIM_MS_PER_STEP
    // rend la main aux microtâches (les suites des `await later(...)` ne
    // s'exécutent QUE si la boucle async yield — sinon la pagination n'arrive JAMAIS)
    await Promise.resolve()
    if (VIRTUAL_MS % 50_000 === 0) await Promise.resolve()
    // exécute les tâches différées arrivées à échéance
    for (let i = pending.length - 1; i >= 0; i--) {
      if (pending[i]!.atMs <= VIRTUAL_MS) { const t = pending.splice(i, 1)[0]!; void t.run() }
    }
    // ticks live : 2/s → un tick toutes les 500 ms virtuelles
    const marketSec = T0_SEC + (VIRTUAL_MS - T0_MS) / 1000
    if (VIRTUAL_MS % 500 === 0) {
      for (const sim of ASSETS) {
        // v6.11 — STALL contention WS : pas de tick pendant le stall
        // (les bougies manquantes ne seront JAMAIS servies — limite OTC).
        if (sim.stallFromSec != null && sim.stallToSec != null
          && marketSec > sim.stallFromSec && marketSec <= sim.stallToSec) continue
        // v6.11 — MICRO-STALL S5 : 50 s sans tick toutes les 5 min (jitter
        // multi-assets) — crée des trous dans la série S5 UNIQUEMENT
        // (une bougie S30 partielle reste formée par les ticks voisins).
        const microPhase = (marketSec - sim.microStallPhaseSec) % 300
        if (microPhase > 0 && microPhase <= 50) {
          if (microPhase <= 0.5) sim.microStallCount++
          continue
        }
        const price = sim.gen.next()
        processAssetTick(sim.asset, marketSec, price)
        lastTickByAsset.set(sim.asset, marketSec)
      }
    }
    // reconnexion à T+35 min : le broker REPOUSSE le snapshot fast
    if (!fastReconnectPushed && VIRTUAL_MS >= T0_MS + RECONNECT_AT_MIN * 60_000) {
      fastReconnectPushed = true
      console.log(`\n── RECONNEXION broker à T+${RECONNECT_AT_MIN} min : re-push des snapshots fast ──`)
      for (const sim of ASSETS) {
        const tEnd = T0_SEC + RECONNECT_AT_MIN * 60 - 621  // snapshot ~12 min finissant à la reconnexion
        const ticks = genFastTicks(sim.gen, tEnd)
        ingestHistoryFastSnapshot(sim.asset, ticks)
      }
    }
    // points de contrôle
    if (nextCp < CHECKPOINTS.length && VIRTUAL_MS >= CHECKPOINTS[nextCp]) {
      report(`T+${Math.round((CHECKPOINTS[nextCp]! - T0_MS) / 60000)} min`)
      nextCp++
    }
  }
  finalReport()
}

// ── Assertions v6.11 (exit code ≠ 0 si échec) ───────────────────────────
const FAILURES: string[] = []
const seenReasons = new Set<string>()

function report(label: string): void {
  const samples = [0, 5, 11, 17, 23].map(i => ASSETS[i]!)
  console.log(`\n════ ${label} ════`)
  for (const s of samples) {
    const st = s.health.update(vnow())
    const ck = s.health.canTrade(vnow())
    const firstLive = candleSync.getFirstLiveTickSec(s.asset)
    const ageMin = ((T0_SEC + (VIRTUAL_MS - T0_MS) / 1000) - firstLive) / 60
    console.log(
      `  ${s.asset.padEnd(12)} canTrade=${ck.allowed ? '✓ OUI' : '✗ NON'} reason=${(ck.reason ?? '-').padEnd(22)} ` +
      `status=${st.status.padEnd(7)} score=${st.healthScore} candles=${st.candleCount} ` +
      `fresh=${(st as any).freshCandleCount ?? '-'} gapsRec=${st.recentGapCount} seam=${st.seamGapCount} ` +
      `firstLiveAge=${ageMin.toFixed(0)}min`
    )
  }
  // agrégat
  const agg = new Map<string, number>()
  for (const s of ASSETS) {
    const ck = s.health.canTrade(vnow())
    const r = ck.allowed ? 'TRADING_OK' : (ck.reason ?? 'UNKNOWN')
    if (ck.reason) seenReasons.add(ck.reason)
    agg.set(r, (agg.get(r) ?? 0) + 1)
  }
  console.log('  AGRÉGAT 24 assets : ' + [...agg.entries()].map(([k, v]) => `${k}=${v}`).join('  '))

  // A1 — jamais de CRITICAL_GAP (à tout point de contrôle)
  if ((agg.get('CRITICAL_GAP') ?? 0) > 0) {
    FAILURES.push(`A1: ${label} — ${agg.get('CRITICAL_GAP')} asset(s) en CRITICAL_GAP`)
  }
  // A2 — dès T+15 min : les 24 assets TRADING_OK à chaque point de contrôle
  const minMark = (VIRTUAL_MS - T0_MS) / 60_000
  if (minMark >= 15) {
    const blocked = 24 - (agg.get('TRADING_OK') ?? 0)
    if (blocked > 0) {
      FAILURES.push(`A2: ${label} — ${blocked} asset(s) non-TRADING_OK (${[...agg.entries()].filter(([k]) => k !== 'TRADING_OK').map(([k, v]) => `${k}=${v}`).join(' ')})`)
    }
  }
}

function finalReport(): void {
  console.log(`\n════════════════ BILAN FINAL (90 min) ═══════════════════`)
  let totalTrades = 0
  let totalMicroStalls = 0
  const totalBlocks = new Map<string, number>()
  for (const s of ASSETS) {
    totalTrades += s.trades
    totalMicroStalls += s.microStallCount
    for (const [k, v] of s.blockedReasons) {
      totalBlocks.set(k, (totalBlocks.get(k) ?? 0) + v)
      seenReasons.add(k)
    }
  }
  console.log(`  Trades auto exécutés (sur 90 min, 24 assets) : ${totalTrades}`)
  console.log(`  Micro-stalls S5 subis (dégradations réalistes) : ${totalMicroStalls}`)
  console.log(`  Blocages cumulés par raison : ${[...totalBlocks.entries()].map(([k, v]) => `${k}=${v}`).join('  ') || 'aucun'}`)
  console.log(`  Raisons de blocage vues : ${[...seenReasons].join(', ') || 'aucune'}`)
  console.log(`  Réparations programmées : ${repairsScheduled}`)
  const ck = ASSETS[0]!.health.canTrade(vnow())
  console.log(`\n  VERDICT asset[0] : allowed=${ck.allowed} reason=${ck.reason} reasons=${ck.reasons.join(' | ')}`)

  // A1 — CRITICAL_GAP ne doit JAMAIS apparaître comme raison de blocage
  if (seenReasons.has('CRITICAL_GAP')) {
    FAILURES.push(`A1: CRITICAL_GAP est apparue comme raison de blocage (interdit depuis v6.11) — ${(totalBlocks.get('CRITICAL_GAP') ?? 0)} fois`)
  }
  // A2 — état final : les 24 assets TRADING_OK
  const finalBlocked = ASSETS.filter(s => !s.health.canTrade(vnow()).allowed)
  if (finalBlocked.length > 0) {
    FAILURES.push(`A2: ${finalBlocked.length} asset(s) bloqués à T+90 min : ${finalBlocked.map(s => `${s.asset}(${s.health.canTrade(vnow()).reason})`).join(', ')}`)
  }
  // A3 — les stratégies tradent (des trades ont été exécutés)
  if (totalTrades <= 0) {
    FAILURES.push('A3: AUCUN trade auto exécuté — les stratégies sont bloquées')
  }
  // A4 — les dégradations étaient bien réelles (le test n'est pas trivial)
  if (totalMicroStalls < N_ASSETS) {
    FAILURES.push(`A4: dégradations insuffisantes (${totalMicroStalls} micro-stalls) — scénario non significatif`)
  }

  if (FAILURES.length > 0) {
    console.log(`\n❌ ÉCHEC — ${FAILURES.length} assertion(s) violée(s) :`)
    for (const f of FAILURES) console.log(`   • ${f}`)
    process.exitCode = 1
  } else {
    console.log('\n✅ SUCCÈS — aucune carte multi-assets ne peut afficher « TRADING BLOQUÉ — CRITICAL_GAP » :')
    console.log('   gaps critiques = informatifs (score/badge), stratégies non bloquées, 24/24 TRADING_OK.')
    process.exitCode = 0
  }
}

void main().catch(e => { console.error('ERREUR SIMULATION:', e); process.exit(1) })
