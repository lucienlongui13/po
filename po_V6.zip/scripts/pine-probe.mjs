/**
 * Probe @heyphat/piner 0.13.0 — dump the real output shapes for a set of
 * Pine scripts, reproducing the "no visual output" bug and inventorying
 * what the host must render.
 */
import { compile, Engine, ArrayFeed } from '@heyphat/piner'
import { readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'

// Deterministic synthetic OHLCV candles (15m, 600 bars)
function makeCandles(n = 600, start = 1_700_000_000_000, stepMs = 15 * 60_000) {
  const bars = []
  let price = 100
  let seed = 42
  const rand = () => {
    seed = (seed * 1103515245 + 12345) % 2147483648
    return seed / 2147483648
  }
  for (let i = 0; i < n; i++) {
    const drift = (rand() - 0.5) * 2
    const open = price
    const close = open + drift
    const high = Math.max(open, close) + rand() * 0.8
    const low = Math.min(open, close) - rand() * 0.8
    bars.push({
      time: start + i * stepMs,
      open: Number(open.toFixed(2)),
      high: Number(high.toFixed(2)),
      low: Number(low.toFixed(2)),
      close: Number(close.toFixed(2)),
      volume: Math.round(500 + rand() * 1500),
    })
    price = close
  }
  return bars
}

const SIMPLE = {
  name: 'SIMPLE_SMA',
  source: `//@version=6
indicator("SMA", overlay=true)
plot(ta.sma(close, 20), title="SMA")`,
}

const EMA_CROSS = {
  name: 'EMA_CROSS',
  source: readFileSync(join(import.meta.dirname, '../samples/ema_cross_v6.pine'), 'utf8'),
}

async function runOne(name, source, bars) {
  console.log('\n==========================================================')
  console.log(`▶ SCRIPT: ${name}`)
  console.log('==========================================================')
  let compiled
  try {
    compiled = compile(source)
    console.log('  ✓ compile OK')
  } catch (err) {
    console.log(`  ✗ COMPILE ERROR: ${err.message}`)
    return
  }
  try {
    const feed = new ArrayFeed(bars)
    const engine = new Engine(compiled, feed)
    await engine.run({ symbol: 'CUSTOM', timeframe: '15' })
    const out = engine.outputs
    const plots = [...out.plots.values()]
    const markers = [...out.markers.values()]
    const hlines = [...out.hlines.values()]
    const fills = [...out.fills.values()]
    const candles = [...out.candles.values()]
    const alerts = out.alerts ?? []
    const drawings = engine.drawings ?? []
    const byType = {}
    for (const d of drawings) byType[d.type] = (byType[d.type] ?? 0) + 1

    // Simulate the user's outputCount
    const bridgeCount =
      plots.length + markers.length + hlines.length + fills.length +
      (out.barColors ? out.barColors.size : 0) + (out.bgColors ? out.bgColors.size : 0) + alerts.length

    console.log(`  plots=${plots.length} markers=${markers.length} hlines=${hlines.length} fills=${fills.length} candles=${candles.length} alerts=${alerts.length}`)
    console.log(`  barColors=${out.barColors?.size ?? 0} bgColors=${out.bgColors?.size ?? 0}`)
    console.log(`  drawings=${drawings.length} (by type: ${JSON.stringify(byType)})`)
    console.log(`  >>> BRIDGE outputCount (user's logic) = ${bridgeCount} ${bridgeCount === 0 && drawings.length === 0 ? '← "no visual output" ERROR' : ''}`)
    console.log(`  >>> REAL visual richness = ${bridgeCount + drawings.length}`)

    if (plots.length) {
      const p = plots[0]
      const nonNull = p.data.filter((v) => v != null).length
      console.log(`  plot[0]: id=${p.id} title="${p.title}" data=${p.data.length} (non-null=${nonNull}) colors=${p.colors.length} options=${JSON.stringify(p.options).slice(0, 140)}`)
    }
    if (markers.length) {
      const m = markers[0]
      console.log(`  marker[0]: id=${m.id} title="${m.title}" kind=${m.kind} location=${m.location} glyph=${m.glyph} data=${m.data.length}`)
      const on = m.data.filter((v) => v != null).length
      console.log(`            markers shown on ${on} bars; sample=${JSON.stringify(m.data.find((v) => v != null))}`)
    }
    if (drawings.length) {
      for (const t of ['line', 'label', 'box', 'table', 'polyline', 'linefill']) {
        const obj = drawings.find((d) => d.type === t)
        if (obj) console.log(`  ${t}[0]: props=${JSON.stringify(obj.props).slice(0, 220)}`)
      }
    }
    if (engine.strategy && (engine.strategy.netProfit !== undefined || engine.strategy.closedTrades?.length)) {
      const s = engine.strategy
      console.log(`  strategy: netProfit=${s.netProfit} closedTrades=${s.closedTrades?.length ?? 0} keys=${Object.keys(s).join(',')}`)
    }
  } catch (err) {
    console.log(`  ✗ RUNTIME ERROR: ${err.message}`)
    console.log(err.stack?.split('\n').slice(0, 6).join('\n'))
  }
}

const bars = makeCandles()
console.log(`Candles: ${bars.length} bars, 15m, from ${new Date(bars[0].time).toISOString()}`)

await runOne(SIMPLE.name, SIMPLE.source, bars)
await runOne(EMA_CROSS.name, EMA_CROSS.source, bars)

// TradingView samples
const dir = join(import.meta.dirname, '../TradingView_pine_scripts_samples')
for (const f of readdirSync(dir).filter((x) => x.endsWith('.pine')).sort()) {
  const source = readFileSync(join(dir, f), 'utf8')
  await runOne(f, source, bars)
}
