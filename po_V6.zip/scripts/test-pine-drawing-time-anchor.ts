/**
 * test-pine-drawing-time-anchor.ts — v1.9 suite (spec §10, §11, §19).
 *
 * bar_index is NOT a persistent identity: the Pine runtime (pine-engine.ts
 * resolveX/timeResolver) converts every drawing's bar_index to the bar's
 * epoch-ms timestamp AT EXECUTION TIME. The frontend only ever receives
 * x = barTime — it never re-interprets an index against a mutated dataset.
 *
 * This test proves the anchor property end-to-end through the coordinator:
 * a label / line / box created at bar N keeps x === barTime(N) after the
 * dataset grows by +1, +10 and +100 bars, and after a dataset replacement
 * that changes the array indexes.
 */
import { usePineStore } from '../src/lib/pine-store'
import { pineCoordinator } from '../src/lib/pine-executor'
import { toPineTime } from '../src/lib/pine-time-axis'
import {
  ANCHOR_PROBE_SRC, makeCandles, makeChecker, resetPineState,
  waitForIdle, waitForStore, allScriptsAtRevision, storeScript, timeOfIndex,
} from './pine-live-test-utils'

const { ok, finish } = makeChecker()
const TF_SEC = 60
const OPTS = { startTime: 1789439220, tfSec: TF_SEC }

async function commitAndGrab(candles: any[], reason: 'new-bar' | 'replace' = 'new-bar') {
  pineCoordinator.notifyDataset(candles, reason)
  const rev = pineCoordinator.stats().revision
  await waitForStore(() => allScriptsAtRevision(rev), 15000, `commit (${reason})`)
  await waitForIdle()
  return storeScript(scriptId!)!.result!
}

let scriptId: string | null = null

async function main() {
  resetPineState()
  scriptId = usePineStore.getState().addScript(ANCHOR_PROBE_SRC, 'Anchor Probe')
  pineCoordinator.setContext({ asset: 'EURUSD_otc', timeframe: TF_SEC })

  console.log('── 1. initial execution (100 bars) ──')
  const candles = makeCandles(100, OPTS)
  let result = await commitAndGrab(candles, 'replace')
  let box = result.drawings.find((d: any) => d.kind === 'box') as any
  let line = result.drawings.find((d: any) => d.kind === 'line') as any
  ok('box created at bar 40 (trigger condition)', box != null)
  ok('line created at bar 45 (trigger condition)', line != null)
  const T35 = toPineTime(timeOfIndex(35, OPTS))
  const T60 = toPineTime(timeOfIndex(60, OPTS))
  const T45 = toPineTime(timeOfIndex(45, OPTS))
  const T55 = toPineTime(timeOfIndex(55, OPTS))
  ok('box.left resolved to barTime(35) — bar_index → time AT EXECUTION', box?.left === T35)
  ok('box.right resolved to barTime(60)', box?.right === T60)
  ok('line.x1 resolved to barTime(45)', line?.x1 === T45)
  ok('line.x2 resolved to barTime(55)', line?.x2 === T55)

  console.log('── 2. +1 bar ──')
  const pushBars = (n: number) => {
    for (let k = 0; k < n; k++) {
      const prev = candles[candles.length - 1]
      const c = prev.close + Math.sin(k) * 3e-5
      candles.push({
        time: prev.time + TF_SEC,
        open: prev.close, high: Math.max(prev.close, c) + 9e-5, low: Math.min(prev.close, c) - 7e-5,
        close: c, volume: 1,
      })
    }
  }
  pushBars(1)
  result = await commitAndGrab(candles)
  box = result.drawings.find((d: any) => d.kind === 'box') as any
  line = result.drawings.find((d: any) => d.kind === 'line') as any
  ok('box stays at barTime(35)..barTime(60) after +1 bar',
    box?.left === T35 && box?.right === T60)
  ok('line stays at barTime(45)..barTime(55) after +1 bar',
    line?.x1 === T45 && line?.x2 === T55)

  console.log('── 3. +10 bars ──')
  pushBars(10)
  result = await commitAndGrab(candles)
  box = result.drawings.find((d: any) => d.kind === 'box') as any
  line = result.drawings.find((d: any) => d.kind === 'line') as any
  ok('box stays at barTime(35)..barTime(60) after +11 total bars',
    box?.left === T35 && box?.right === T60)
  ok('line stays at barTime(45)..barTime(55) after +11 total bars',
    line?.x1 === T45 && line?.x2 === T55)

  console.log('── 4. +100 bars — indexes shifted massively ──')
  pushBars(100)
  result = await commitAndGrab(candles)
  box = result.drawings.find((d: any) => d.kind === 'box') as any
  line = result.drawings.find((d: any) => d.kind === 'line') as any
  ok('box STILL anchored at barTime(35)..barTime(60) after +111 bars',
    box?.left === T35 && box?.right === T60)
  ok('line STILL anchored at barTime(45)..barTime(55) after +111 bars',
    line?.x1 === T45 && line?.x2 === T55)
  ok('drawings are time-anchored objects (x values are epoch ms, not indexes)',
    typeof box?.left === 'number' && box.left > 1e12 && typeof line?.x1 === 'number' && line.x1 > 1e12)

  console.log('── 5. head eviction — correct Pine sliding-window semantics ──')
  // Removing the FIRST 30 bars shifts every array index by -30. In Pine
  // semantics bar_index is DATASET-RELATIVE (TradingView's max_bars_back
  // window slides the same way): the script re-executes and recreates its
  // objects at the NEW bar_index positions — bar_index 40 now designates the
  // bar that previously sat at index 70. What must NEVER happen is a
  // positional rendering drift: the recreated objects must sit exactly on
  // the timestamps of the new bar_index targets (proving the renderer maps
  // through time, not through stale indexes).
  const evicted = candles.slice(30)
  result = await commitAndGrab(evicted, 'replace')
  box = result.drawings.find((d: any) => d.kind === 'box') as any
  line = result.drawings.find((d: any) => d.kind === 'line') as any
  ok('box recreated at the NEW bar_index 35..60 positions (= original bars 65..90, by timestamp)',
    box?.left === toPineTime(timeOfIndex(65, OPTS)) && box?.right === toPineTime(timeOfIndex(90, OPTS)))
  ok('line recreated at the NEW bar_index 45..55 positions (= original bars 75..85, by timestamp)',
    line?.x1 === toPineTime(timeOfIndex(75, OPTS)) && line?.x2 === toPineTime(timeOfIndex(85, OPTS)))
  ok('no drawing kept a STALE x from the pre-eviction dataset',
    !result.drawings.some((d: any) => d.kind === 'line' && d.x1 === T45))

  resetPineState()
  console.log()
  finish('test-pine-drawing-time-anchor')
}

main().catch((err) => {
  console.error('FATAL:', err)
  process.exit(1)
})
