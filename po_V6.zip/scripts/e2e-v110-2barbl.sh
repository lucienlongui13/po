#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# E2E V1.10 — le script Pine v3 « Two Bar Break Line Alerts R1.1 »
# (JustUncleL) s'exécute VERBATIM dans l'app :
#   1. Injection via localStorage (même flux que l'utilisateur)
#   2. Login → exécution automatique par le coordinateur
#   3. Assertions via window.__pineChartDebug :
#      A. script exécuté, overlay=true (sur le graphique, pas un panneau)
#      B. 4 plots (MA colorée + 2 lignes de breakout + filtre masqué)
#      C. flèches de breakout rendues (markers non-null > 100)
#      D. alertes collectées > 600 (buy/sell/trend)
#      E. barcolors BO (jaune/noir) > 100
# ═══════════════════════════════════════════════════════════════════
cd /home/z/my-project
PASS=0; FAIL=0
ok()   { PASS=$((PASS+1)); echo "  ✓ $1"; }
ko()   { FAIL=$((FAIL+1)); echo "  ✗ $1"; }
step() { echo ""; echo "════════ $1 ════════"; }
shot() { agent-browser screenshot "scripts/e2e-v110-$1.png" >/dev/null 2>&1 && echo "📸 $1"; }

if ! curl -s -m 3 -o /dev/null http://localhost:3000/ 2>/dev/null; then
  echo "front mort — relance ./po.sh"; exit 1
fi
curl -s -m 3 -o /dev/null http://localhost:3000/ && echo "front OK"

SRC=$(cat TradingView_pine_scripts_samples/2barbl_r11_v3.pine)
B64=$(printf '%s' "$SRC" | base64 -w0)

step "1. Injection du script Pine v3 (2BARBL R1.1, source verbatim)"
agent-browser open http://localhost:3000 >/dev/null 2>&1
sleep 6
agent-browser eval "(() => {
  localStorage.clear();
  const src = atob('$B64');
  const scripts = [
    { id: 'pine-2barbl', name: '2BARBL R1.1', source: src,
      meta: { version: 5, declaration: 'indicator', title: 'Two Bar Break Line Alerts R1.1 by JustUncleL', overlay: true },
      enabled: true }
  ];
  localStorage.setItem('pine-scripts-v1', JSON.stringify(scripts));
  return 'injected';
})()" >/dev/null 2>&1
agent-browser reload >/dev/null 2>&1
sleep 10

agent-browser find role button click --name "Login with Pocket Option" >/dev/null 2>&1
for i in $(seq 1 12); do
  sleep 5
  if agent-browser snapshot -i -c 2>/dev/null | grep -q "PINE SCRIPT"; then break; fi
done
agent-browser snapshot -i -c 2>/dev/null | grep -q "PINE SCRIPT" && echo "loggé" || { echo "✗ login"; exit 1; }
sleep 15

step "2. Assertions mesurées sur le script v3 exécuté"
JSON=$(agent-browser eval '(() => {
  const dbg = window.__pineChartDebug;
  if (!dbg) return JSON.stringify({ error: "no debug hook" });
  const scripts = (dbg.getScripts() || []).filter(s => s.enabled && s.result);
  const s2 = scripts.find(s => s.name && s.name.includes("2BARBL")) || scripts[0];
  if (!s2) return JSON.stringify({ error: "script not executed" });
  const r = s2.result;
  const arrows = (r.markers || []).find(m => (m.title || "") === "Breakout Arrows");
  const arrowCount = arrows ? (arrows.data || []).filter(d => d != null).length : 0;
  const bc = (r.barColors && r.barColors[0]) || [];
  const bcolCount = bc.filter(c => c != null).length;
  return JSON.stringify({
    overlay: r.overlay,
    plots: (r.plots || []).length,
    plotTitles: (r.plots || []).map(p => p.title),
    markers: (r.markers || []).length,
    arrowCount,
    alerts: (r.alerts || []).length,
    barColorCount: bcolCount,
    err: s2.error || null,
  });
})()' 2>/dev/null | tail -1)
echo "$JSON"

PY=$(printf '%s' "$JSON" | python3 -c '
import json,sys
raw = sys.stdin.read().strip()
if raw.startswith("\"") and raw.endswith("\""): raw = raw[1:-1].replace("\\\"", "\"")
try: d = json.loads(raw)
except Exception: d = {}
print("OVERLAY=%s" % d.get("overlay"))
print("PLOTS=%s" % d.get("plots"))
print("ARROWS=%s" % d.get("arrowCount"))
print("ALERTS=%s" % d.get("alerts"))
print("BARCOL=%s" % d.get("barColorCount"))
' 2>/dev/null)
eval "$PY"
echo "overlay=$OVERLAY plots=$PLOTS arrows=$ARROWS alerts=$ALERTS barcol=$BARCOL"

num() { case "$1" in ''|null) echo 0;; True|true) echo true;; *) echo "$1";; esac }

[ "$(num "$OVERLAY" | tr '[:upper:]' '[:lower:]')" = "true" ] && ok "overlay=true — rendu SUR le graphique" || ko "overlay ($OVERLAY)"
[ "$(num "$PLOTS")" = "4" ] && ok "4 plots enregistrés (MA colorée + lignes breakout)" || ko "plots ($PLOTS)"
python3 -c "exit(0 if int('$(num "$ARROWS")') > 5 else 1)" 2>/dev/null && ok "flèches breakout rendues: $ARROWS" || ko "flèches ($ARROWS)"
python3 -c "exit(0 if int('$(num "$ALERTS")') > 20 else 1)" 2>/dev/null && ok "alertes collectées: $ALERTS" || ko "alertes ($ALERTS)"
python3 -c "exit(0 if int('$(num "$BARCOL")') > 5 else 1)" 2>/dev/null && ok "barcolors BO (jaune/noir): $BARCOL" || ko "barcolors ($BARCOL)"

shot 2barbl

echo ""
echo "════════════════════════════════════"
echo "E2E V1.10 : $PASS ✓ · $FAIL ✗"
echo "════════════════════════════════════"
[ "$FAIL" -eq 0 ] || exit 1
