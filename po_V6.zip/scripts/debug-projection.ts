/**
 * debug-projection.ts — Dump internal decision features for each test trade.
 * Calibration tool: shows WHY the model decides (edge decomposition).
 */
import { smartTraderProjectionDiagnostics } from '../src/lib/smart-trader-projection.js'
import {
  genSeries, TRADE_CASES, HORIZON, swingExtremes, resolveNowIdx,
} from './eval-smart-trader-lib.js'

const num = (v: number, d = 3) => (Number.isFinite(v) ? v.toFixed(d) : 'n/a')

for (const tc of TRADE_CASES) {
  const series = genSeries(tc.gen)
  const nowIdx = resolveNowIdx(tc, series)
  const visible = series.slice(0, nowIdx + 1)
  const future = series.slice(nowIdx + 1, nowIdx + 1 + HORIZON)
  const anchors = swingExtremes(visible, 45)
  const { result, internals: I } = smartTraderProjectionDiagnostics(visible, HORIZON, anchors.hi, anchors.lo)
  if (!I || !result) { console.log(`#${tc.id} null`); continue }
  const actualMove = future[HORIZON - 1].close - visible[nowIdx].close
  const actualDir = actualMove > 0 ? 'UP' : actualMove < 0 ? 'DOWN' : 'FLAT'
  const dir = result.direction > 0 ? 'UP' : result.direction < 0 ? 'DOWN' : 'WAIT'
  console.log(`#${tc.id} pred=${dir} actual=${actualDir} edge=${num(I.edge)} θ=${num(I.theta)}`)
  console.log(
    `   tail: mean=${num(I.tailMean)} tanh=${num(I.tailTanh)} consist=${num(I.tailConsistency)}` +
    ` | pos=${num(I.pos, 2)} volR=${num(I.volRatio, 2)} autocorr=${num(I.autocorr, 2)}`
  )
  console.log(
    `   regime: trendiness=${num(I.trendiness, 2)} rf=${num(I.rangeFactor, 2)} volExp=${num(I.volExpansion, 2)} impulse=${num(I.impulse, 2)}`
  )
  console.log(
    `   ensemble: consensus=${num(I.consensus)} medATR=${num(I.medianDispATR, 1)} meanATR=${num(I.meanDispATR, 1)} voteU/D=${num(I.voteUp, 2)}/${num(I.voteDown, 2)}`
  )
  console.log(
    `   weights: momW=${num(I.momentumW)} consW=${num(I.consensusW)} fadeW=${num(I.fadeW)}` +
    ` | terms: mom=${num(I.momentumW * I.tailTanh)} cons=${num(I.consensusW * I.consensus)} fade=${num(I.fadeW * (0.5 - I.pos))}`
  )
  console.log(
    `   analogues(end,score,w,endpointATR): ` +
    I.analogues.slice(0, 6).map(a => `(${a.end},${num(a.score, 2)},${num(a.weight, 2)},${num(a.endpointATR, 1)})`).join(' ')
  )
  console.log('')
}
