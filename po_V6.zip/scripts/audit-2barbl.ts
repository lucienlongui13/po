/**
 * audit-2barbl.ts — run the v3 script VERBATIM through runPineScript and
 * report the error cascade (stage, line, message). Audit step for the v3
 * compatibility layer: we fix what ACTUALLY breaks, in order.
 */
import { runPineScript } from '../src/lib/pine-engine'
import { readFileSync } from 'node:fs'

const raw = JSON.parse(readFileSync('scripts/dataset-eurusd-m1.json', 'utf8')) as any[]
const dataset = (Array.isArray(raw) ? raw : raw.candles ?? raw.data ?? []).map((c: any) => ({
  time: Number(c.time), open: Number(c.open), high: Number(c.high), low: Number(c.low), close: Number(c.close),
  volume: Number(c.volume ?? 0),
}))
console.log(`dataset: ${dataset.length} bars`)

const src = readFileSync('TradingView_pine_scripts_samples/2barbl_r11_v3.pine', 'utf8')
console.log(`script: ${src.length} chars, version line: ${src.split('\n')[0]}`)

async function main() {
const res = await runPineScript(src, dataset as any, { symbol: 'EURUSD_otc', timeframe: '1' })
if (res.ok) {
  const r = res.result
  console.log('OK — unexpected for a v3 script on a v6 engine!')
  console.log(`overlay=${r.overlay} plots=${r.plots.length} markers=${r.markers.length} barColors=${r.barColors.length} alerts=${r.alerts.length}`)
} else {
  console.log(`\nERROR stage=${res.error.stage} line=${res.error.line ?? '?'} col=${res.error.column ?? '?'}`)
  console.log(`message: ${res.error.message.slice(0, 4000)}`)
}
}
main()
