/**
 * Probe v1.7-alias: the NEW PiracyChecker.zip pack has AUTHOR ALIASING —
 * Main.pine imports PiracyChecker/PubLibSwing/3 but PubLibTrend.pine imports
 * theEccentricTrader/PubLibSwing/3. Same FILE, two canonical keys.
 *
 * Verifies that registering one source under BOTH keys lets piner compile and
 * run the pack (double-merge with distinct slugs must be semantically sound).
 */
import { compileAsync, Engine, ArrayFeed } from '@heyphat/piner'
import { readFileSync } from 'node:fs'

const base = '/home/z/my-project/upload/piracy_extracted/Market_structures_scripts'
const main = readFileSync(`${base}/Main.pine`, 'utf8')
const swing = readFileSync(`${base}/libs/PubLibSwing.pine`, 'utf8')
const trend = readFileSync(`${base}/libs/PubLibTrend.pine`, 'utf8')
const utility = readFileSync(`${base}/libs/PubLibUtility.pine`, 'utf8')
const candleTrend = readFileSync(`${base}/libs/PubLibCandleTrend.pine`, 'utf8')

const registry = [
  // PubLibSwing registered under BOTH author paths (aliasing)
  { key: 'PiracyChecker/PubLibSwing/3', source: swing },
  { key: 'theEccentricTrader/PubLibSwing/3', source: swing },
  { key: 'PiracyChecker/PubLibTrend/3', source: trend },
  { key: 'PiracyChecker/PubLibUtility/2', source: utility },
  { key: 'PiracyChecker/PubLibCandleTrend/2', source: candleTrend },
]

async function run() {
  // 1. Compile with the aliased registry
  try {
    const compiled = await compileAsync(main, { libraries: registry })
    console.log('ALIAS COMPILE: OK —', compiled.metadata.title, '·', compiled.metadata.inputs.length, 'inputs')
  } catch (err: any) {
    console.log('ALIAS COMPILE FAILED:', err?.message?.slice(0, 600))
    return
  }

  // 2. Full execution on the captured dataset
  const raw = JSON.parse(readFileSync('/home/z/my-project/scripts/dataset-eurusd-m1.json', 'utf8'))
  const candles = (raw.candles ?? raw).map((c: any) => ({
    time: Number(c.time) * 1000,
    open: Number(c.open), high: Number(c.high), low: Number(c.low), close: Number(c.close),
    volume: Number(c.volume) || 0,
  }))
  const compiled = await compileAsync(main, { libraries: registry })
  const engine = new Engine(compiled as any, new ArrayFeed(candles) as any)
  const t0 = Date.now()
  await engine.run({ symbol: 'EURUSD_otc', timeframe: '1' })
  const drawings = (engine as any).drawings ?? []
  const kinds: Record<string, number> = {}
  for (const d of drawings) kinds[d.type] = (kinds[d.type] ?? 0) + 1
  console.log('ALIAS RUN: OK in', Date.now() - t0, 'ms ·', candles.length, 'bars · drawings:', drawings.length, JSON.stringify(kinds))

  // 3. Sanity: BOS/CHoCH/CISD labels must exist
  const labels = (drawings as any[]).filter((d) => d.type === 'label')
  console.log('sample label:', JSON.stringify(labels[0]).slice(0, 300))
  const texts = labels.map((l) => String(l?.text ?? l?.options?.text ?? l?.props?.text ?? '')).filter(Boolean)
  const counts: Record<string, number> = {}
  for (const t of texts) counts[t] = (counts[t] ?? 0) + 1
  console.log('label texts:', JSON.stringify(counts))
}

run().catch((err) => console.log('PROBE FAILED:', err?.message?.slice(0, 500)))
