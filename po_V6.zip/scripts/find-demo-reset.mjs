/**
 * find-demo-reset.mjs — cherche l'endpoint de reset du solde démo dans le
 * HTML/JS de la plateforme Pocket Option (cabinet).
 */
import authModule from '../mini-services/iqoption-backend/pocket-option-sdk/src/auth.js';
const { loginMobile, fetchCabinet } = authModule;

const EMAIL = 'longuilcn@gmail.com';
const PASSWORD = 'Jean-Paul@#1964';

async function main() {
  const login = await loginMobile({
    credentials: { email: EMAIL, password: PASSWORD },
    logger: { debug: () => {}, info: () => {}, warn: () => {}, error: () => {} },
  });
  console.log('login OK uid=', login.uid);

  // Fetch brut du cabinet (avec suivi des redirects) pour inspecter le HTML
  const query = new URLSearchParams({ token: login.token, ...Object.fromEntries(Object.entries(login.tracking ?? {}).map(([k, v]) => [k, String(v)])) });
  const url = `https://m.pocketoption.com/en/cabinet?${query}`;
  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 13; SM-T870 Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0.0.0 Mobile Safari/537.36, webview2_android_428',
      Accept: 'text/html',
    },
    redirect: 'follow',
  });
  const html = await res.text();
  console.log('cabinet HTTP', res.status, 'taille', html.length);

  // Cherche tout ce qui évoque un reset/refill démo
  const patterns = [/demo[\w-]*reset/gi, /reset[\w-]*demo/gi, /refill/gi, /demo[-_]?balance/gi, /topup|top-up/gi];
  for (const p of patterns) {
    const matches = [...new Set(html.match(p) ?? [])];
    if (matches.length) console.log(`PATTERN ${p}:`, matches.slice(0, 8));
  }
  // Cherche les URLs d'actions AJAX
  const urls = [...new Set(html.match(/["'](\/[a-z]{2}\/[a-z0-9\-\/]*(?:reset|refill|demo)[a-z0-9\-\/]*)["']/gi) ?? [])];
  console.log('URLS candidates:', urls.slice(0, 20));
}

main().catch(e => { console.error('FATAL:', e.message); process.exit(1); });
