/**
 * probe-patterns.ts — validate that the harmonic/double-top pattern scripts
 * DO produce drawings when the dataset actually contains their patterns
 * (the 2242-bar EURUSD capture simply has none). Crafts a synthetic series
 * with a textbook double top + double bottom + trends.
 */
import { runPineScript } from '../src/lib/pine-engine'
import { readFileSync } from 'node:fs'

// Craft: uptrend → double top (two peaks same height, valley between) →
// downtrend → double bottom → recovery. Swing-friendly W-shaped prices.
const bars: any[] = []
let t = 1789439220
const push = (close: number) => {
  const open = bars.length ? bars[bars.length - 1].close : close
  bars.push({ time: t, open, high: Math.max(open, close) + 0.0004, low: Math.min(open, close) - 0.0004, close, volume: 120 })
  t += 60
}
// phase 1: uptrend with pullbacks (zigzag legs)
for (let i = 0; i < 60; i++) push(1.1500 + i * 0.0006 + Math.sin(i / 4) * 0.0008)
// phase 2: double top
for (let i = 0; i < 12; i++) push(1.1870 - i * 0.0004)          // up to peak 1
for (let i = 0; i < 10; i++) push(1.1822 + i * 0.0005)          // valley
for (let i = 0; i < 12; i++) push(1.1872 - i * 0.0002)          // peak 2 (same height)
// phase 3: breakdown
for (let i = 0; i < 40; i++) push(1.1848 - i * 0.0008 + Math.sin(i / 3) * 0.0006)
// phase 4: double bottom
const low1 = bars[bars.length - 1].close
for (let i = 0; i < 10; i++) push(low1 + i * 0.0005)
for (let i = 0; i < 8; i++) push(low1 + 0.0050 - i * 0.0005)
for (let i = 0; i < 10; i++) push(low1 - 0.0002 + i * 0.0003)
// phase 5: recovery
for (let i = 0; i < 60; i++) push(bars[bars.length - 1].close + i * 0.0007 + Math.sin(i / 5) * 0.0009)

async function main() {
  for (const f of ['pattern_1.pine', 'pattern_2.pine', 'pattern_4.pine', 'pattern_5.pine']) {
    const src = readFileSync(`TradingView_pine_scripts_samples/${f}`, 'utf8')
    const res = await runPineScript(src, bars, { symbol: 'EURUSD_otc', timeframe: '1' })
    if (res.ok) {
      const r = res.result
      const kinds: Record<string, number> = {}
      for (const d of r.drawings) kinds[d.kind] = (kinds[d.kind] ?? 0) + 1
      console.log(`  ${f}: ✓ ${r.drawings.length} drawings ${JSON.stringify(kinds)}`)
    } else {
      console.log(`  ${f}: ✗ ${res.error.stage}: ${res.error.message.slice(0, 80)}`)
    }
  }
}
main().catch((e) => { console.error(e); process.exit(1) })
