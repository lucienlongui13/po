/**
 * test-real-bos-martingale.mjs — TEST RÉEL sur le VRAI broker Pocket Option.
 * ============================================================================
 * Suit EXACTEMENT les instructions utilisateur :
 *   1. Login avec les identifiants par défaut codés en dur (page.tsx)
 *   2. Auto Trade → stratégie « BOS, CHoCH & CISD (pack Pine) »
 *   3. Combinaisons CALL + PUT (toutes les 6 alertes)
 *   4. Expiration = 3 s (par règle), timeframe bougies S5
 *   5. Mise de base 500, martingale activée
 *   6. Réalise 20 ordres et vérifie que la martingale fonctionne
 *   7. Vérifie que BOS, CHoCH & CISD place des ordres
 *
 * v2 : déduplication des events trade-opened (broker + strategy émettent le
 * même deal), appariement règlement→ordre par dealId, filtrage du burst de
 * règlements antérieurs au début du test, vérification martingale par asset.
 *
 * Prérequis : backend déjà démarré sur :3030 (connexion broker RÉELLE).
 * Exécution : node scripts/test-real-bos-martingale.mjs
 */
import { io } from 'socket.io-client';
import * as fs from 'node:fs';

const URL = 'http://127.0.0.1:3030';
// Identifiants par défaut codés en dur (src/app/page.tsx)
const EMAIL = 'longuilcn@gmail.com';
const PASSWORD = 'Jean-Paul@#1964';
// 2 assets (exigence utilisateur précédente : au moins 2 assets)
const ASSETS = ['EURUSD_otc', 'GBPUSD_otc'];
const BASE = 500;          // mise de base
const EXPIRY = 3;          // expiration des règles (s)
const TARGET_ORDERS = 20;  // nombre d'ordres uniques à réaliser
const MAX_WAIT_MS = Number(process.env.TEST_MAX_WAIT_MS ?? 30 * 60 * 1000);

const sleep = ms => new Promise(r => setTimeout(r, ms));
const hhmmss = ts2 => new Date(ts2).toISOString().slice(11, 19);

const state = {
  autoTradeOnTs: null,     // moment où l'auto-trade a été activé (début du test réel)
  deals: new Map(),        // dealId → { asset, action, amount, source, expirationSeconds, ts, settled }
  orderEvents: [],         // events bruts (diagnostic)
  settlements: [],         // règlements { ts, asset, dealId, isWin, profit, matched }
  placeholders: [],        // règlements deal #0 / asset vide (diagnostic)
  martingaleLogs: [],
  balance: null,
};

function saveReport(extra = {}) {
  const report = {
    when: new Date().toISOString(),
    config: { EMAIL, ASSETS, BASE, EXPIRY, TARGET_ORDERS, MODE: 'demo' },
    balance: state.balance,
    orders: [...state.deals.values()],
    orderEvents: state.orderEvents,
    settlements: state.settlements,
    placeholders: state.placeholders,
    martingaleLogs: state.martingaleLogs,
    ...extra,
  };
  fs.writeFileSync('/home/z/my-project/download/test-real-bos-martingale-report.json', JSON.stringify(report, null, 2));
}

async function main() {
  console.log('════════════════════════════════════════════════════════════════');
  console.log('  TEST RÉEL v2 — Martingale BOS, CHoCH & CISD (pack Pine)');
  console.log(`  Login: ${EMAIL} | Assets: ${ASSETS.join(' + ')} | S5 | exp ${EXPIRY}s | base ${BASE} | martingale`);
  console.log('════════════════════════════════════════════════════════════════\n');

  const socket = io(URL, { transports: ['websocket'], path: '/', reconnection: false, timeout: 10000 });

  // ── Monitoring passif ──
  socket.on('log', (ev) => {
    const m = String(ev?.message ?? '');
    if (/martingale|empreinte|rattaché|trade (opened|result)|WATCHDOG|bloqué|BLOCKED|purgé|start balance/i.test(m)) {
      state.martingaleLogs.push({ ts: ev?.ts, level: ev?.level, message: m });
      if (/martingale step|empreinte|rattaché|trade result|trade opened|BLOCKED|bloqué|auto-trade enabled/i.test(m)) {
        console.log(`  [backend] ${m}`);
      }
      // Capture le solde de départ annoncé par le backend
      const sb = m.match(/start balance: ([0-9.]+)/);
      if (sb && state.startBalance == null) state.startBalance = parseFloat(sb[1]);
    }
  });
  socket.on('status', (s) => { if (s?.balance != null) state.balance = s.balance; });

  socket.on('trade-opened', (ev) => {
    const dealId = String(ev?.deal?.id ?? '');
    if (!dealId) return;
    const after = state.autoTradeOnTs == null || Date.now() >= state.autoTradeOnTs;
    if (!after) return;
    const existing = state.deals.get(dealId);
    if (existing) {
      // Second event du même deal (source=broker + source=strategy) : fusionne —
      // l'event strategy porte expirationSeconds, l'event broker parfois pas.
      if (ev?.source === 'l_lucien_protrader') existing.source = 'l_lucien_protrader';
      if (ev?.expirationSeconds != null) existing.expirationSeconds = ev.expirationSeconds;
      if (ev?.deal?.action && existing.action == null) existing.action = ev.deal.action;
      existing.sources.push(ev?.source);
      return;
    }
    state.deals.set(dealId, {
      n: state.deals.size + 1,
      dealId,
      ts: Date.now(),
      asset: ev?.asset,
      source: ev?.source,
      sources: [ev?.source],
      action: ev?.deal?.action,
      amount: Number(ev?.deal?.amount ?? 0),
      openPrice: ev?.deal?.openPrice,
      openTime: ev?.deal?.openTime,
      expirationSeconds: ev?.expirationSeconds,
      settled: false,
    });
    const d = state.deals.get(dealId);
    console.log(`  [${hhmmss(Date.now())}] ORDRE #${d.n} ${d.asset} ${String(d.action).toUpperCase()} ${d.amount}$ exp=${d.expirationSeconds}s (source=${d.source}, deal=${dealId.slice(0, 10)}…)`);
  });

  socket.on('trade-closed', (ev) => {
    const dealId = String(ev?.deal?.id ?? '');
    const entry = {
      ts: Date.now(),
      asset: ev?.asset,
      dealId,
      isWin: !!ev?.isWin,
      profit: Number(ev?.profit ?? 0),
      action: ev?.deal?.action,
      inTest: state.autoTradeOnTs != null && Date.now() >= state.autoTradeOnTs,
    };
    // Placeholders deal #0 / asset vide → diagnostic séparé
    if (dealId === '0' || dealId === '' || !ev?.asset) {
      state.placeholders.push(entry);
      console.log(`  [${hhmmss(entry.ts)}] PLACEHOLDER deal#${dealId || '?'} asset='${ev?.asset ?? ''}' isWin=${entry.isWin} profit=${entry.profit} action=${entry.action}`);
      return;
    }
    state.settlements.push(entry);
    const d = state.deals.get(dealId);
    if (d) { d.settled = true; d.result = entry.isWin ? 'WIN' : 'LOSS'; d.profit = entry.profit; }
    console.log(`  [${hhmmss(entry.ts)}] RÈGLEMENT ${entry.asset} deal=${dealId.slice(0, 10)}… → ${entry.isWin ? 'WIN ✓' : 'LOSS ✗'} (profit=${entry.profit}${d ? `, mise=${d.amount}` : ', HORS-TEST'})`);
  });

  // ── 1. Connexion socket ──
  const connected = await new Promise(r => {
    socket.once('connect', () => r(true));
    socket.once('connect_error', () => r(false));
    setTimeout(() => r(false), 12000);
  });
  if (!connected) { console.error('✗ Backend injoignable sur :3030'); process.exit(1); }
  console.log(`[1] Backend connecté (${URL})`);

  // ── 2. Login avec les identifiants par défaut ──
  console.log(`[2] Login ${EMAIL} (mode demo) sur le VRAI broker…`);
  const loginResult = await new Promise(r => {
    socket.once('login-result', r);
    socket.emit('login', { email: EMAIL, password: PASSWORD, mode: 'demo' });
    setTimeout(() => r({ ok: false, error: 'timeout 90s' }), 90000);
  });
  if (!loginResult?.ok) {
    console.error('✗ LOGIN ÉCHOUÉ :', JSON.stringify(loginResult));
    saveReport({ fatal: 'login failed', loginResult });
    process.exit(1);
  }
  console.log(`✓ Login OK (uid=${loginResult.user_id}, mode=${loginResult.mode}${loginResult.resumed ? ', session reprise' : ''})`);
  // Attends que le burst de règlements de l'ancienne session passe
  console.log('   (attente 12 s : purge du burst de règlements de la session précédente…)');
  await sleep(12000);

  // ── 3. Configuration : S5 ──
  console.log('[3] Timeframe S5 (candleSize=5)…');
  socket.emit('set-config', { candleSize: 5, cooldownSeconds: 3 });
  await sleep(500);

  // ── 4. Sélection des 2 assets ──
  console.log(`[4] Sélection assets ${ASSETS.join(' + ')}…`);
  const selected = await new Promise(r => {
    socket.once('assets-selected', r);
    socket.emit('select-assets', { mode: 'multi', assets: ASSETS });
    setTimeout(() => r({ ok: false, error: 'timeout 30s' }), 30000);
  });
  if (!selected?.ok) {
    console.error('✗ Sélection assets échouée :', JSON.stringify(selected));
    saveReport({ fatal: 'select-assets failed', selected });
    process.exit(1);
  }
  console.log(`✓ Assets actifs : ${(selected.assets || []).join(', ')} (focus=${selected.focus})`);
  await sleep(10000);

  // ── 5. Stratégie BOS, CHoCH & CISD ──
  console.log('[5] Stratégie auto-trade = bos_choch_cisd…');
  socket.emit('set-auto-strategy', { strategyId: 'l_lucien_protrader' });
  await sleep(400);

  // ── 6. Martingale + base 500 ──
  console.log('[6] Martingale, base 500…');
  socket.emit('set-auto-config', {
    bettingStrategy: 'martingale',
    baseAmount: BASE,
    expirationMode: 'fixed',
    expirySeconds: EXPIRY,
  });
  socket.emit('set-config', { margin: String(BASE), bettingStrategy: 'martingale', cooldownSeconds: 3 });
  await sleep(400);

  // ── 7. Combinaisons CALL + PUT (expiration 3 s par règle) ──
  console.log(`[7] Règles BOS : CALL {BOS Up} + {CHoCH Up, CISD Up} | PUT {BOS Down} + {CHoCH Down, CISD Down}, exp ${EXPIRY}s…`);
  socket.emit('set-auto-config', {
    bosChochCisdCallRules: [
      { id: 'call-1', alerts: ['BOS Up'], expirationSeconds: EXPIRY },
      { id: 'call-2', alerts: ['CHoCH Up', 'CISD Up'], expirationSeconds: EXPIRY },
    ],
    bosChochCisdPutRules: [
      { id: 'put-1', alerts: ['BOS Down'], expirationSeconds: EXPIRY },
      { id: 'put-2', alerts: ['CHoCH Down', 'CISD Down'], expirationSeconds: EXPIRY },
    ],
  });
  await sleep(400);

  // ── 8. Vérification de la config ──
  const status1 = await new Promise(r => {
    socket.once('auto-trade-status', r);
    socket.emit('get-auto-status');
    setTimeout(() => r(null), 8000);
  });
  if (status1) {
    console.log(`[8] Config confirmée : strategy=${status1.strategyId}, betting=${status1.bettingStrategy}`);
    for (const [a, st] of Object.entries(status1.assets ?? {})) {
      console.log(`      ${a}: base=${st.baseAmount} next=${st.nextBetAmount} losses=${st.stats.consecutiveLosses}`);
    }
    if (status1.strategyId !== 'l_lucien_protrader') { console.error('✗ stratégie != l_lucien_protrader'); saveReport({ fatal: 'wrong strategy', status1 }); process.exit(1); }
    if (status1.bettingStrategy !== 'martingale') { console.error('✗ mise != martingale'); saveReport({ fatal: 'wrong betting', status1 }); process.exit(1); }
  }

  // ── 9. Activation : LE TEST COMMENCE ICI ──
  console.log('[9] ACTIVATION auto-trade — début du test réel…\n');
  const autoOn = await new Promise(r => {
    socket.once('auto-trade-status', r);
    socket.emit('set-auto-trade', { enabled: true });
    setTimeout(() => r(null), 10000);
  });
  if (!autoOn?.enabled) { console.error('✗ Auto-trade pas activé !'); saveReport({ fatal: 'auto-trade not enabled', autoOn }); process.exit(1); }
  state.autoTradeOnTs = Date.now();

  // ── 10. Boucle de surveillance ──
  const start = Date.now();
  let lastSaved = 0;
  while (Date.now() - start < MAX_WAIT_MS) {
    const nOrders = [...state.deals.values()].filter(d => d.source === 'l_lucien_protrader').length;
    if (nOrders >= TARGET_ORDERS) {
      console.log(`\n[10] ${nOrders} ordres uniques placés — attente des derniers règlements (30 s)…`);
      await sleep(30000);
      break;
    }
    if (nOrders === 0 && Date.now() - start > 10 * 60 * 1000) {
      console.error('\n✗ AUCUN ordre après 10 minutes — BOS ne place pas d\'ordres !');
      break;
    }
    if (Date.now() - lastSaved > 20000) { lastSaved = Date.now(); saveReport(); }
    await sleep(2000);
  }

  socket.emit('set-auto-trade', { enabled: false });

  // ── 11. RAPPORT ──
  console.log('\n════════════════════════════════════════════════════════════════');
  console.log('  RAPPORT — MARTINGALE BOS/CHoCH/CISD (broker RÉEL, démo)');
  console.log('════════════════════════════════════════════════════════════════');

  const orders = [...state.deals.values()].filter(d => d.source === 'l_lucien_protrader');
  const checks = [];
  const ok = (cond, label) => { checks.push(!!cond); console.log(`  ${cond ? '✓' : '✗'} ${label}`); };

  ok(orders.length >= TARGET_ORDERS, `${orders.length}/${TARGET_ORDERS} ordres BOS placés`);
  ok(orders.every(o => o.expirationSeconds === EXPIRY), `expiration de chaque ordre = ${EXPIRY}s (${[...new Set(orders.map(o => o.expirationSeconds))].join(', ')})`);
  const assetsTraded = [...new Set(orders.map(o => o.asset))];
  ok(assetsTraded.length >= 2, `ordres sur ≥ 2 assets (${assetsTraded.join(', ')})`);

  console.log('\n  ── Séquences par asset (ordres du test, appariés par dealId) ──');
  let martingaleOK = true;
  let transitions = 0;
  for (const asset of ASSETS) {
    const ordersA = orders.filter(o => o.asset === asset).sort((a, b) => a.ts - b.ts);
    if (ordersA.length === 0) { console.log(`  ${asset} : AUCUN ordre`); martingaleOK = false; continue; }
    console.log(`  ${asset} : ${ordersA.length} ordres`);
    console.log(`    mises    : ${ordersA.map(o => o.amount).join(' → ')}`);
    console.log(`    résultats: ${ordersA.map(o => o.result ?? '?').join(' ')}`);

    // Vérifie chaque transition : le résultat du deal i impose la mise du deal i+1
    for (let i = 0; i + 1 < ordersA.length; i++) {
      const cur = ordersA[i], next = ordersA[i + 1];
      if (cur.result == null) continue; // jamais réglé (déjà un problème — reporté plus bas)
      const expected = cur.result === 'WIN' ? BASE : cur.amount * 2;
      transitions++;
      if (next.amount !== expected) {
        martingaleOK = false;
        console.log(`    ✗ deal #${cur.n} ${cur.result} → mise suivante ${next.amount}$, attendu ${expected}$`);
      }
    }
    if (ordersA.some(o => o.result == null)) {
      console.log(`    ⚠ ${ordersA.filter(o => o.result == null).length} ordre(s) jamais réglés (deal_closed absent)`);
    }
  }
  ok(martingaleOK, `Martingale : LOSS → ×2, WIN → ${BASE}, sur ${transitions} transition(s)`);

  const settled = orders.filter(o => o.result != null);
  const nWin = settled.filter(o => o.result === 'WIN').length;
  const nLoss = settled.filter(o => o.result === 'LOSS').length;
  const nUnsettled = orders.filter(o => o.result == null).length;
  console.log(`\n  Total : ${orders.length} ordres BOS | ${settled.length} réglés (${nWin} WIN, ${nLoss} LOSS) | ${nUnsettled} non réglés`);
  console.log(`  Placeholders deal#0/asset-vide reçus : ${state.placeholders.length}`);
  ok(nWin > 0, `au moins un WIN observé (${nWin})`);
  ok(nLoss > 0, `au moins un LOSS observé (${nLoss})`);
  if (state.balance != null) console.log(`  Balance : ${JSON.stringify(state.balance)}`);

  const passed = checks.every(Boolean);
  saveReport({ passed, checks: checks.length, passedCount: checks.filter(Boolean).length, transitions, nWin, nLoss, nUnsettled });

  console.log(`\n════ RÉSULTAT : ${checks.filter(Boolean).length}/${checks.length} vérifications OK ════`);
  console.log('Rapport complet : /home/z/my-project/download/test-real-bos-martingale-report.json');

  socket.close();
  process.exit(passed ? 0 : 2);
}

main().catch(e => { console.error('FATAL:', e); saveReport({ fatal: String(e) }); process.exit(1); });
