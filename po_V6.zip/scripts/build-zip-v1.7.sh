#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v1.7.sh — Livraison v1.7 « Import multi-librairies »
#   - Le moteur Pine exécute les scripts qui IMPORTENT plusieurs librairies
#     communautaires (ex. pack « BOS, CHoCH and CISD [PiracyChecker] » :
#     Main.pine → PubLibSwing + PubLibTrend + PubLibUtility, avec dépendances
#     transitives PubLibCandleTrend et ALIAS D'AUTEURS) ;
#   - Import d'un pack complet en UNE opération : archive ZIP (Main + libs/),
#     sélection multi-fichiers, glisser-déposer sur l'éditeur, ou collage
#     manuel d'une librairie isolée ;
#   - Détection automatique des librairies manquantes (graphe complet, direct
#     ET transitif) avec bannière « LIBRAIRIES REQUISES » + boutons d'import ;
#   - Clés auteur/nom/version déduites automatiquement des instructions import
#     du pack — alias d'auteurs (miroirs) et complétion inter-imports inclus ;
#   - Ré-exécution automatique de tous les scripts après chaque import.
# Sortie : /home/z/my-project/download/pine_v6_engine_v1.7.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v1.7"
FOLDER=pine_v6_engine_v1.7
OUT="$ROOT/download/pine_v6_engine_v1.7.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (mêmes exclusions que v1.0→v1.6) ─────────────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude 'upload/' \
  --exclude 'download/' \
  --exclude 'tool-results/' \
  --exclude '.stage-v1.1/' \
  --exclude '.stage-v1.2/' \
  --exclude '.stage-v1.3/' \
  --exclude '.stage-v1.4/' \
  --exclude '.stage-v1.5/' \
  --exclude '.stage-v1.6/' \
  --exclude '.stage-v1.7/' \
  --exclude 'skills/' \
  --exclude 'bun.lock' \
  --exclude '*.tmp' \
  --exclude 'bun-error.log' \
  --exclude '.env.local' \
  --exclude 'tsconfig.tsbuildinfo' \
  --exclude 'next-env.d.ts' \
  --exclude '*.log' \
  --exclude '.logs/' \
  --exclude 'v12_*.png' \
  --exclude 'scripts/*.png' \
  --exclude 'scripts/vlm_*.json' \
  --exclude 'scripts/search*.json' \
  "$ROOT/" "$STAGE/$FOLDER/"

# ── WaveScope v5 + guide réglages (inclus depuis v1.3) ────────────────────
cp "$ROOT/download/wavescope_ict_v5.pine" "$STAGE/$FOLDER/wavescope_ict_v5.pine"
cp "$ROOT/download/GUIDE-REGLAGES-V5.md" "$STAGE/$FOLDER/GUIDE-REGLAGES-V5.md"

# ── Pack d'exemple (celui fourni par l'utilisateur) pour test immédiat ────
mkdir -p "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies/libs"
cp "$ROOT/upload/piracy_extracted/Market_structures_scripts/Main.pine" \
   "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies/Main.pine"
cp "$ROOT/upload/piracy_extracted/Market_structures_scripts/libs/"*.pine \
   "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies/libs/"

# ── README des fonctionnalités v1.7 ───────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.7-IMPORT-MULTI-LIBRAIRIES.md" <<'EOF'
# Pine v6 Engine — v1.7 « Import multi-librairies »

Le moteur exécute désormais les scripts Pine qui **importent plusieurs
librairies communautaires à la fois** — y compris les librairies qui
s'importent **entre elles** — sans qu'aucune ne soit publiée sur TradingView.

## Le problème résolu

Un script communautaire typique (ex. « BOS, CHoCH and CISD [PiracyChecker] »)
déclare :

```pine
import PiracyChecker/PubLibSwing/3 as sw
import PiracyChecker/PubLibTrend/3 as tr
import PiracyChecker/PubLibUtility/2 as ut
```

…et ces librairies s'importent elles-mêmes (PubLibTrend → PubLibSwing →
PubLibCandleTrend). Sur TradingView, chaque `import` télécharge une librairie
**publiée**. Localement, ces sources n'existent nulle part : la compilation
échouait et **aucune option ne permettait de fournir les sources**.

## La solution : un éditeur de liens (linker) multi-librairies

### 1. Détection — bannière « LIBRAIRIES REQUISES »

Dès qu'un script (ou une de ses librairies) référence une librairie non
enregistrée, l'éditeur Pine affiche une bannière ambre qui liste **chaque
chemin manquant avec sa chaîne d'importateurs** :

```
LIBRAIRIES REQUISES (3) — importez le pack pour exécuter ce script
PiracyChecker/PubLibSwing/3 · requise par script principal
PiracyChecker/PubLibTrend/3 · requise par script principal
PiracyChecker/PubLibUtility/2 · requise par script principal
[📦 Importer le pack (ZIP)] [📄 Fichiers séparés] [Gestion des librairies]
```

La détection parcourt le **graphe complet** (imports directs + transitifs) :
une dépendance requise seulement par une libraire (ex. PubLibCandleTrend
derrière PubLibSwing) est listée aussi. Une pastille ambre apparaît sur le
bouton PINE SCRIPT et sur chaque script concerné dans la barre latérale.

### 2. Import d'un pack complet en UNE opération

Quatre chemins d'import, tous équivalents :

- **Archive ZIP** : bouton « Importer le pack (ZIP) » → sélectionnez le ZIP
  contenant `Main.pine` + le dossier `libs/` (structure exacte des packs
  TradingView). Lecture 100 % locale, aucun envoi réseau ;
- **Fichiers séparés** : bouton « Fichiers séparés » → sélection multiple
  (Ctrl+clic) des `.pine` ;
- **Glisser-déposer** : déposez le ZIP ou les fichiers directement sur la
  fenêtre de l'éditeur (zone de dépôt orange) ;
- **Manuel** : « Librairies → Ajout manuel » pour coller UNE librairie isolée
  (copiez sa source depuis sa page TradingView, onglet « Source code »).

### 3. Zéro configuration — clés déduites automatiquement

Une librairie ne connaît pas sa propre clé : seule la clé `auteur/nom/version`
apparaît dans les `import` des AUTRES fichiers. L'importeur recoupe donc
**toutes les instructions import de tous les fichiers du pack** pour retrouver
la clé exacte de chaque librairie :

- correspondance par titre `library("Nom")` (identité officielle) ;
- version la plus haute = clé primaire ;
- **alias d'auteurs** : le même fichier est enregistré sous CHAQUE chemin qui
  le référence — le pack d'exemple importe PubLibSwing à la fois comme
  `PiracyChecker/PubLibSwing/3` (Main) et `theEccentricTrader/PubLibSwing/3`
  (PubLibTrend, auteur original) : les DEUX chemins résolvent ;
- **complétion inter-imports** : importez les libs d'abord, le Main ensuite
  (ou l'inverse) — les chemins manquants sont rattachés automatiquement aux
  librairies déjà enregistrées (même nom + même version) ;
- deux librairies de même nom dans un pack = appariement déterministe, jamais
  fusionnées ;
- **shim de compatibilité intégré** : `PiracyChecker/PubLibCandleTrend/2`
  (dépendance transitivE rarement redistribuée) est fourni en shim minimal
  (gc()/rc()) — remplacé automatiquement par la source officielle quand le
  pack la contient, ou par votre propre source collée sous la même clé.

### 4. Rapport d'import + exécution automatique

Après chaque import, le panneau « Librairies Pine » affiche le rapport :
librairies enregistrées (clés + alias), shim remplacé, scripts principaux
ajoutés, dépendances encore manquantes (s'il en reste). **Tous les scripts
activés sont ré-exécutés automatiquement** — un script resté en erreur
re-part dès que ses librairies arrivent.

### 5. Registre persistant

Les librairies sont mémorisées (localStorage) pour tous vos scripts et tous
vos rechargements. Le panneau « Librairies » liste chaque clé (badge SHIM
pour les shims intégrés, taille en KB, suppression) — la suppression d'une
entrée qui écrasait un shim restaure le shim.

## Exemple pas-à-pas (pack fourni dans ce zip)

1. `./start-dev.sh` → « Login with Pocket Option » ;
2. bouton **PINE SCRIPT** (pastille ambre si un script importe des librairies
   manquantes) ;
3. bouton **Librairies** (en haut à droite de l'éditeur) → **Importer un ZIP**
   → sélectionnez `EXEMPLE-Pack-Multi-Librairies.zip` (ou le dossier dézippé
   du même nom, livré à côté de ce README) ;
4. le rapport liste 4 librairies enregistrées (dont PubLibSwing sous SES DEUX
   clés d'auteur) + le shim CandleTrend remplacé + le Main ajouté ;
5. fermez : le script « BOS, CHoCH and CISD [PiracyChecker] » s'exécute —
   labels BOS/CHoCH/CISD et lignes de structure sur le graphique ;
6. bouton **Réglages** : les 14 paramètres du script (couleurs, tailles,
   alertes) sont modifiables comme sur TradingView.

## Moteur (vérifié par tests)

- `scripts/test-pine-libraries.ts` (**50 tests**) : extraction d'imports,
  dérivation de clés par recoupement, alias d'auteurs, garde anti-ambiguïté,
  import en deux temps (libs puis Main), dépendances transitives, shim
  remplaçable, registre piner, lecture du ZIP réel, compilation du pack ;
- `scripts/test-pine-engine-libs.ts` (**21 tests**) : pont applicatif complet —
  erreur propre avant import, exécution de Main.pine sur 2 242 bougies
  (580 drawings : 240 labels BOS/CHoCH/CISD + 340 lignes), schéma des 14
  inputs, overrides de réglages, suppression → ré-import (cycle complet) ;
- E2E navigateur réel (**14 vérifications**) : bannière + boutons + erreur
  AVANT import, import du VRAI ZIP PiracyChecker, rapport (4 libs + alias +
  shim remplacé), ré-exécution automatique (drawings sur le graphique),
  bannière disparue, badge « Librairies 5 », persistance après rechargement,
  modale Réglages (14 paramètres) ;
- Non-régression : martingale (12), stop/rejet par côté (17), log trades
  (21), onglets CALL/PUT (9), adaptateurs — toutes les suites passent ;
- `tsc` 0 erreur, `next build` production OK.

## Lancer sur Termux

```bash
unzip pine_v6_engine_v1.7.zip
cd pine_v6_engine_v1.7
npm install --no-audit --no-fund
./start-dev.sh
```
EOF

# ── ZIP du pack d'exemple (prêt à importer pour tester) ───────────────────
(cd "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies" && zip -qr9 "$STAGE/EXEMPLE-Pack-Multi-Librairies.zip" .)
mv "$STAGE/EXEMPLE-Pack-Multi-Librairies.zip" "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies.zip"

# ── Création du zip ───────────────────────────────────────────────────────
rm -f "$OUT"
(cd "$STAGE" && zip -qr9 "$OUT" "$FOLDER")

# ── Vérification ──────────────────────────────────────────────────────────
echo "=== Archive créée : $OUT ==="
du -h "$OUT"
unzip -l "$OUT" | tail -1
echo "=== Fichiers clés présents ==="
unzip -l "$OUT" | grep -E 'pine-libraries|zip-reader|README-V1.7|EXEMPLE-Pack|wavescope_ict_v5|GUIDE-REGLAGES-V5|package-lock.json$' | awk '{print $1, $4}'
echo "=== Marqueurs de fonctionnalités (vérification rapide) ==="
unzip -p "$OUT" "$FOLDER/src/lib/pine-libraries.ts" | grep -c 'aliases' | xargs echo "aliasing registre (>=5 attendu) :"
unzip -p "$OUT" "$FOLDER/src/lib/pine-libraries.ts" | grep -c 'BUILTIN_COMPAT_LIBRARIES' | xargs echo "shims intégrés (>=3 attendu) :"
unzip -p "$OUT" "$FOLDER/src/lib/pine-libraries.ts" | grep -c 'entryIsFallback' | xargs echo "complétion inter-imports (1 attendu) :"
unzip -p "$OUT" "$FOLDER/src/lib/pine-libraries.ts" | grep -c 'group.forEach' | xargs echo "appariement même-nom (1 attendu) :"
unzip -p "$OUT" "$FOLDER/src/lib/zip-reader.ts" | grep -c 'readZipEntries' | xargs echo "lecteur ZIP (>=2 attendu) :"
unzip -p "$OUT" "$FOLDER/src/components/trading/chart/pine-script-editor.tsx" | grep -c 'LIBRAIRIES REQUISES' | xargs echo "bannière détection (1 attendu) :"
unzip -p "$OUT" "$FOLDER/src/components/trading/chart/pine-script-editor.tsx" | grep -c 'Importer le pack (ZIP)' | xargs echo "bouton import ZIP (2 attendu) :"
unzip -p "$OUT" "$FOLDER/src/components/trading/chart/pine-script-editor.tsx" | grep -c 'onDropFiles' | xargs echo "glisser-déposer (2 attendu) :"
unzip -p "$OUT" "$FOLDER/src/components/trading/chart/pine-script-editor.tsx" | grep -c 'reexecuteAll' | xargs echo "ré-exécution auto (>=4 attendu) :"
unzip -p "$OUT" "$FOLDER/src/lib/pine-engine.ts" | grep -c 'asPinerRegistry' | xargs echo "registry transmis au compilateur (>=3 attendu) :"
unzip -t "$OUT" > /dev/null && echo "=== Intégrité zip OK ==="

# Nettoyage du staging
rm -rf "$STAGE"
