#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v1.1.sh — Livraison v1.1 « Signal Strategy Cards v2 »
# Même structure que pine_v6_engine_v1.0.zip (runtime_fixed) :
#   - tout le projet, SANS node_modules / .next / .git / upload / download /
#     tool-results / bun.lock / *.tmp / caches
#   + README-V1.1-CARDS.md (nouveautés de cette version)
# Sortie : /home/z/my-project/download/pine_v6_engine_v1.1.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v1.1"
FOLDER=pine_v6_engine_v1.1
OUT="$ROOT/download/pine_v6_engine_v1.1.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (mêmes exclusions que la v1.0) ────────────────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude 'upload/' \
  --exclude 'download/' \
  --exclude 'tool-results/' \
  --exclude '.stage-v1.1/' \
  --exclude 'bun.lock' \
  --exclude '*.tmp' \
  --exclude 'bun-error.log' \
  --exclude '.env.local' \
  --exclude 'skills/' \
  --exclude 'tsconfig.tsbuildinfo' \
  --exclude 'next-env.d.ts' \
  --exclude '*.log' \
  "$ROOT/" "$STAGE/$FOLDER/"

# ── README des nouveautés v1.1 ────────────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.1-CARDS.md" <<'EOF'
# Pine v6 Engine — v1.1 « Signal Strategy Cards v2 »

Cette version livre la refonte complète des cartes de conditions du
**Signal Strategy** affichées sur le lightweight-charts. Basée sur la v1.0
(`pine_v6_engine_v1.0.zip`), elle n'ajoute aucune dépendance : `npm install`
puis `./start-dev.sh` (ou `bash po.sh`) comme avant.

## Les 6 nouveautés

1. **Conditions CALL + PUT fusionnées.** Les conditions haussières (CALL) et
   baissières (PUT) attachées à la même bougie d'émission sont regroupées
   dans UNE carte unifiée par direction — plus besoin de croiser deux listes
   pour cerner la stratégie. Les marqueurs triangulaires C / P sur les
   bougies restent inchangés.

2. **Liste COMPLÈTE des conditions.** Fini le « +3 autres / +2 autres /
   +1 autre ». Chaque carte affiche désormais TOUTES les conditions actives
   de l'émission, même si la liste est longue : la carte s'allonge
   automatiquement et, en cas d'extrême besoin, un liseré en pied de carte
   signale simplement que l'affichage est complet. Vision globale ET
   détaillée garantie.

3. **Cartes déplaçables (drag & drop).** Chaque carte peut être saisie à la
   souris / au doigt (pointer events) et éloignée des bougies. La position
   est mémorisée par carte (offset individuel) et reste stable d'une frame
   à l'autre. Relâchez la carte où vous voulez : elle y reste.

4. **Carte SMS dédiée.** Le signal SMS haussier (« SMS HAUSSIER ▲ ») et le
   signal SMS baissier (« SMS BAISSIER ▼ ») ont chacun leur propre carte
   colorée sur le graphique, reliée à sa bougie par un connecteur — car le
   SMS fait partie intégrante des conditions de stratégie.

5. **Notification SMS conservée.** Le petit toast « Signal Strategy —
   CALL / PUT » qui s'affiche à chaque émission SMS est inchangé
   (réglable via « Notifications en live » dans le panneau Signal
   Strategy).

6. **Switch afficher / masquer les cartes.** Un interrupteur est désormais
   ancré en haut à droite du graphique (badge « ON/OFF »). Il masque ou
   réaffiche toutes les cartes de conditions d'un clic — les marqueurs
   C/P sur les bougies restent toujours visibles. L'état est persisté en
   localStorage (`ss-cards-visible-v1`) et conservé au rechargement.

## Fichiers touchés

- `src/components/trading/chart/signal-strategy-overlay.tsx` — refonte
  complète : regroupement CALL+PUT, liste intégrale, drag & drop, cartes
  SMS dédiées, switch de visibilité persistant.
- `src/components/trading/signal-strategy-panel.tsx` — inchangé côté
  notifs (toast conservé).

## Lancer sur Termux

```bash
unzip pine_v6_engine_v1.1.zip
cd pine_v6_engine_v1.1
npm install --no-audit --no-fund
./start-dev.sh        # ou : bash po.sh
```
EOF

# ── Création du zip ───────────────────────────────────────────────────────
rm -f "$OUT"
(cd "$STAGE" && zip -qr9 "$OUT" "$FOLDER")

# ── Vérification ──────────────────────────────────────────────────────────
echo "=== Archive créée : $OUT ==="
du -h "$OUT"
unzip -l "$OUT" | tail -1
echo "=== Fichiers clés présents ==="
unzip -l "$OUT" | grep -E 'signal-strategy-overlay|signal-strategy-panel|README-V1.1|package.json$' | awk '{print $1, $4}'

# Nettoyage du staging
rm -rf "$STAGE"
