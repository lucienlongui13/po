/**
 * eval-smart-trader-lib.ts — Shared library for the Smart Trader evaluation.
 *
 * Deterministic synthetic market data (regime engine), the 10 official test
 * trades, swing/Fib anchor simulation and scoring helpers.
 *
 * NO model import here — the model is injected, so any version of
 * smartTraderProjection can be evaluated with the exact same data.
 */

export type CandleLike = { time: number; open: number; high: number; low: number; close: number; volume: number }

// ---------------------------------------------------------------------------
// Deterministic PRNG (mulberry32) + gaussian
// ---------------------------------------------------------------------------

export function mulberry32(seed: number) {
  let a = seed >>> 0
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function makeGauss(rand: () => number) {
  return function gauss(): number {
    let u = 0, v = 0
    while (u === 0) u = rand()
    while (v === 0) v = rand()
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v)
  }
}

// ---------------------------------------------------------------------------
// Market regime engine — realistic synthetic OTC-like candles
// ---------------------------------------------------------------------------

export type SegKind = 'range' | 'trendUp' | 'trendDown' | 'squeeze' | 'breakoutUp' | 'breakdown' | 'chop'

export interface Seg {
  kind: SegKind
  bars: number
  /** Mean-reversion strength (range/squeeze/chop). Default per kind. */
  kappa?: number
  /** Center EMA span (range/squeeze/chop). Default per kind. */
  span?: number
}

export interface GenParams {
  seed: number
  start: number
  sigma: number   // base bar volatility in price units
  segs: Seg[]
}

/** Generate a full OHLC series following the regime script.
 *  Range/squeeze/chop mean-revert toward an ADAPTIVE EMA center, so
 *  regime transitions (impulse → retracement) are gradual and realistic.
 *  kappa = reversion strength, span = center EMA length (per segment). */
export function genSeries(p: GenParams): CandleLike[] {
  const rand = mulberry32(p.seed)
  const gauss = makeGauss(rand)
  const out: CandleLike[] = []
  let price = p.start
  let prevDelta = 0
  let t = 1700000000

  // Continuous multi-span EMA centers — updated EVERY bar across ALL regimes,
  // so a mean-reverting segment inherits a meaningful gap (no center jump).
  const SPANS = [24, 40, 60, 150]
  const ema = new Map<number, number>(SPANS.map(s => [s, p.start]))
  const KAPPA: Record<string, number> = { range: 0.25, squeeze: 0.06, chop: 0.04 }
  const SPAN: Record<string, number> = { range: 24, squeeze: 40, chop: 60 }

  for (const seg of p.segs) {
    const kappa = seg.kappa ?? KAPPA[seg.kind] ?? 0.1
    const span = seg.span ?? SPAN[seg.kind] ?? 40
    const centerOf = () => ema.get(span) ?? p.start
    for (let i = 0; i < seg.bars; i++) {
      let delta = 0
      const noise = gauss() * p.sigma
      const center = centerOf()
      switch (seg.kind) {
        case 'range': {
          delta = -kappa * (price - center) + noise * 1.0
          break
        }
        case 'trendUp': {
          delta = p.sigma * 0.55 + 0.35 * prevDelta + noise
          break
        }
        case 'trendDown': {
          delta = -p.sigma * 0.55 + 0.35 * prevDelta + noise
          break
        }
        case 'squeeze': {
          const prog = i / Math.max(1, seg.bars)
          delta = -kappa * (price - center) + noise * (1 - 0.6 * prog)
          break
        }
        case 'breakoutUp': {
          const prog = i / Math.max(1, seg.bars)
          delta = p.sigma * (0.5 + 1.6 * prog) + 0.4 * prevDelta + noise
          break
        }
        case 'breakdown': {
          const prog = i / Math.max(1, seg.bars)
          delta = -p.sigma * (0.5 + 1.6 * prog) + 0.4 * prevDelta + noise
          break
        }
        case 'chop': {
          delta = noise * 1.7 + 0.25 * prevDelta - kappa * (price - center)
          break
        }
      }
      // safety clamps keep price positive & bounded
      if (price > p.start * 1.12) delta -= 0.02 * (price - p.start * 1.12)
      if (price < p.start * 0.88) delta += 0.02 * (p.start * 0.88 - price)

      const open = price
      const close = price + delta
      const wick = Math.abs(gauss()) * p.sigma * 0.55 + p.sigma * 0.05
      const high = Math.max(open, close) + wick
      const low = Math.min(open, close) - Math.abs(gauss()) * p.sigma * 0.55 - p.sigma * 0.05
      out.push({ time: t, open, high, low: Math.max(low, 1e-6), close, volume: Math.round(20 + 120 * rand()) })
      price = close
      prevDelta = delta
      for (const s of SPANS) ema.set(s, (2 / (s + 1)) * close + (1 - 2 / (s + 1)) * (ema.get(s) ?? p.start))
      t += 60
    }
  }
  return out
}

// ---------------------------------------------------------------------------
// The 10 official test trades / movements
// ---------------------------------------------------------------------------

export const HORIZON = 30

/** Swing extremes over the recent window — what a trader anchors the Fib box on. */
export function swingExtremes(candles: CandleLike[], window: number): { hi: number; lo: number } {
  const slice = candles.slice(-Math.min(window, candles.length))
  let hi = -Infinity, lo = Infinity
  for (const c of slice) { if (c.high > hi) hi = c.high; if (c.low < lo) lo = c.low }
  return { hi, lo }
}

export interface TradeCase {
  id: number
  name: string
  gen: GenParams
  /** Explicit evaluation bar (0-based index of "now"). -1 = scan-based. */
  nowOffset: number
  /** Optional deterministic scan: predicate over the visible series. */
  scan?: { from: number; predicate: (series: CandleLike[], i: number) => boolean }
}

/** Position of bar i's close within the last `win` bars' swing, 0..1. */
function posInSwing(series: CandleLike[], i: number, win = 45): number {
  const lo = Math.min(...series.slice(Math.max(0, i - win), i).map(c => c.low))
  const hi = Math.max(...series.slice(Math.max(0, i - win), i).map(c => c.high))
  return (series[i].close - lo) / Math.max(1e-12, hi - lo)
}

const delta = (series: CandleLike[], i: number) => series[i].close - series[i - 1].close

export const TRADE_CASES: TradeCase[] = [
  {
    id: 1, name: 'Trend up — momentum continuation',
    nowOffset: 320,
    gen: { seed: 101, start: 1.0850, sigma: 0.00042, segs: [
      { kind: 'range', bars: 120 },
      { kind: 'trendUp', bars: 200 },
      { kind: 'trendUp', bars: 90 },   // future: continuation
    ] },
  },
  {
    id: 2, name: 'Up impulse — Fibonacci retrace down (pullback started)',
    nowOffset: 330,
    gen: { seed: 202, start: 0.9820, sigma: 0.00038, segs: [
      { kind: 'range', bars: 100 },
      { kind: 'trendUp', bars: 220 },
      { kind: 'range', bars: 90, kappa: 0.02, span: 150 }, // slow reversion: deep retrace
    ] },
  },
  {
    id: 3, name: 'Trend down — momentum continuation',
    nowOffset: 320,
    gen: { seed: 303, start: 1.2010, sigma: 0.00040, segs: [
      { kind: 'range', bars: 110 },
      { kind: 'trendDown', bars: 210 },
      { kind: 'trendDown', bars: 90 }, // future: continuation
    ] },
  },
  {
    id: 4, name: 'Down impulse — bounce up (reversal started)',
    nowOffset: 330,
    gen: { seed: 404, start: 0.6650, sigma: 0.00035, segs: [
      { kind: 'range', bars: 100 },
      { kind: 'trendDown', bars: 220 },
      { kind: 'range', bars: 90, kappa: 0.02, span: 150 }, // slow reversion: deep bounce
    ] },
  },
  {
    id: 5, name: 'Range — rejection after touch of range top',
    nowOffset: -1,
    scan: { from: 180, predicate: (s, i) => posInSwing(s, i) >= 0.80 && delta(s, i) < 0 && delta(s, i - 1) >= 0 },
    gen: { seed: 505, start: 1.3100, sigma: 0.00030, segs: [
      { kind: 'range', bars: 340 },
    ] },
  },
  {
    id: 6, name: 'Range — bounce after touch of range bottom',
    nowOffset: -1,
    scan: { from: 180, predicate: (s, i) => posInSwing(s, i) <= 0.20 && delta(s, i) > 0 && delta(s, i - 1) <= 0 },
    gen: { seed: 606, start: 0.7420, sigma: 0.00028, segs: [
      { kind: 'range', bars: 340 },
    ] },
  },
  {
    id: 7, name: 'Squeeze — breakout up (expansion started)',
    nowOffset: 345,
    gen: { seed: 707, start: 1.0500, sigma: 0.00045, segs: [
      { kind: 'range', bars: 150 },
      { kind: 'squeeze', bars: 190 },
      { kind: 'breakoutUp', bars: 60 }, // 5 visible breakout bars
    ] },
  },
  {
    id: 8, name: 'Squeeze — breakdown (expansion started)',
    nowOffset: 345,
    gen: { seed: 808, start: 0.8150, sigma: 0.00044, segs: [
      { kind: 'range', bars: 150 },
      { kind: 'squeeze', bars: 190 },
      { kind: 'breakdown', bars: 60 },  // 5 visible breakdown bars
    ] },
  },
  {
    id: 9, name: 'Volatile chop — fade of swing extreme (hard)',
    nowOffset: -1,
    scan: { from: 200, predicate: (s, i) => posInSwing(s, i) >= 0.85 && delta(s, i) < 0 },
    gen: { seed: 909, start: 1.1310, sigma: 0.00050, segs: [
      { kind: 'chop', bars: 410 },
    ] },
  },
  {
    id: 10, name: 'Exhaustion after long trend — reversal down (started)',
    nowOffset: 435,
    gen: { seed: 1010, start: 0.9510, sigma: 0.00040, segs: [
      { kind: 'trendUp', bars: 300 },
      { kind: 'squeeze', bars: 130 },
      { kind: 'trendDown', bars: 60 },  // 5 visible reversal bars
    ] },
  },
]

/** Resolve the evaluation bar for a trade case (fixed offset or scan). */
export function resolveNowIdx(tc: TradeCase, series: CandleLike[]): number {
  if (tc.nowOffset >= 0) return tc.nowOffset - 1
  if (!tc.scan) throw new Error(`trade ${tc.id}: no nowOffset and no scan`)
  const maxI = series.length - HORIZON - 2
  for (let i = Math.max(tc.scan.from, 60); i <= maxI; i++) {
    if (tc.scan.predicate(series, i)) return i
  }
  throw new Error(`trade ${tc.id}: scan found no qualifying bar`)
}

// ---------------------------------------------------------------------------
// Scoring
// ---------------------------------------------------------------------------

export interface TradeResult {
  id: number
  name: string
  predDir: number
  conf: number
  actualDir: number
  actualMove: number
  onsetPred: number
  onsetActual: number
  target: number
  actualTarget: number
  win: boolean
  waited: boolean
}

export function actualOnset(future: CandleLike[], dir: number, refClose: number): number {
  const total = (future[future.length - 1].close - refClose) * dir
  if (Math.abs(total) < 1e-12) return 0
  for (let i = 1; i < future.length; i++) {
    const disp = (future[i].close - refClose) * dir
    if (disp >= 0.3 * Math.abs(total)) return i
  }
  return future.length
}

export interface ModelLike {
  (candles: CandleLike[], horizonBars: number, anchorA: number, anchorB: number): {
    direction: number
    target: number
    onsetBar: number
    confidence: number
  } | null
}

export function runTrade(tc: TradeCase, model: ModelLike): TradeResult | null {
  const series = genSeries(tc.gen)
  const nowIdx = resolveNowIdx(tc, series)
  const visible = series.slice(0, nowIdx + 1)
  const future = series.slice(nowIdx + 1, nowIdx + 1 + HORIZON)
  if (future.length < HORIZON) throw new Error(`trade ${tc.id}: not enough future bars`)

  const anchors = swingExtremes(visible, 45)
  const m = model(visible, HORIZON, anchors.hi, anchors.lo)
  if (!m) return null

  const refClose = visible[nowIdx].close
  const actualMove = future[HORIZON - 1].close - refClose
  const actualDir = actualMove > 0 ? 1 : actualMove < 0 ? -1 : 0
  const win = m.direction !== 0 && m.direction === actualDir
  const onsetA = actualOnset(future, actualDir, refClose)

  return {
    id: tc.id,
    name: tc.name,
    predDir: m.direction,
    conf: m.confidence,
    actualDir,
    actualMove,
    onsetPred: m.onsetBar,
    onsetActual: onsetA,
    target: m.target,
    actualTarget: future[HORIZON - 1].close,
    win,
    waited: m.direction === 0,
  }
}

export function fmtDir(d: number): string {
  return d > 0 ? 'UP  ' : d < 0 ? 'DOWN' : 'WAIT'
}

export interface Summary {
  wins: number
  waits: number
  issued: number
  total: number
  strictWR: number
  issuedWR: number
  meanOnsetErr: number
  results: TradeResult[]
}

export function summarize(results: TradeResult[]): Summary {
  const wins = results.filter(r => r.win).length
  const waits = results.filter(r => r.waited).length
  const issued = results.length - waits
  const onsetErrs = results.filter(r => r.win).map(r => Math.abs(r.onsetPred - r.onsetActual))
  return {
    wins,
    waits,
    issued,
    total: results.length,
    strictWR: results.length ? (wins / results.length) * 100 : 0,
    issuedWR: issued ? (wins / issued) * 100 : 0,
    meanOnsetErr: onsetErrs.length ? onsetErrs.reduce((a, b) => a + b, 0) / onsetErrs.length : NaN,
    results,
  }
}

export function printReport(label: string, s: Summary) {
  console.log('═══════════════════════════════════════════════════════════════════')
  console.log(` SMART TRADER PROJECTION — ${label}`)
  console.log('═══════════════════════════════════════════════════════════════════')
  for (const r of s.results) {
    const mark = r.win ? '✔ WIN ' : r.waited ? '· WAIT' : '✘ LOSS'
    console.log(
      ` #${String(r.id).padStart(2)} ${mark} | pred ${fmtDir(r.predDir)} conf ${String(r.conf).padStart(3)}%` +
      ` | actual ${fmtDir(r.actualDir)} (${(r.actualMove >= 0 ? '+' : '') + r.actualMove.toFixed(5)})` +
      ` | onset pred/act ${r.onsetPred}/${r.onsetActual}` +
      ` | target ${r.target.toFixed(5)} vs ${r.actualTarget.toFixed(5)}`
    )
  }
  console.log('───────────────────────────────────────────────────────────────────')
  console.log(` WIN-RATE (strict, /10)      : ${s.wins}/${s.total} = ${s.strictWR.toFixed(1)}%`)
  console.log(` WIN-RATE (issued signals)   : ${s.wins}/${s.issued} = ${s.issuedWR.toFixed(1)}%`)
  console.log(` WAIT (no signal)            : ${s.waits}`)
  console.log(` Mean onset error (wins)     : ${Number.isFinite(s.meanOnsetErr) ? s.meanOnsetErr.toFixed(1) + ' bars' : 'n/a'}`)
  console.log(` THRESHOLD                   : 65%–70%`)
  console.log(s.strictWR >= 65 ? ' >>> SUCCESS — threshold reached' : ' >>> BELOW threshold — iterate')
  console.log('═══════════════════════════════════════════════════════════════════')
}
