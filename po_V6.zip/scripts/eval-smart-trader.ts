/**
 * eval-smart-trader.ts — Offline evaluation harness for smartTraderProjection().
 *
 * Reproduces EXACTLY how the Fibonacci Retracement tool calls the model in
 * drawing-layer.tsx (visible candles only, fib anchors = recent swing extremes,
 * horizonBars = 30). Official metric: directional win-rate over 10 test trades.
 *
 * Run:  cd <project root> && node --import tsx scripts/eval-smart-trader.ts [v0|v2]
 * (default: v2 — the production model; v0 is the baseline kept for A/B)
 */

import {
  smartTraderProjection as modelV2,
  smartTraderProjectionV0 as modelV0,
} from '../src/lib/smart-trader-projection.js'
import {
  TRADE_CASES, runTrade, summarize, printReport,
} from './eval-smart-trader-lib.js'

const which = process.argv[2] ?? 'v2'
const model = which === 'v0' ? modelV0 : modelV2

function main() {
  const results = []
  for (const tc of TRADE_CASES) {
    const r = runTrade(tc, model)
    if (!r) { console.log(` #${tc.id} ${tc.name} → model returned null (skipped)`); continue }
    results.push(r)
  }
  printReport(`Evaluation ${which} (Fib Retracement · 10 trades)`, summarize(results))
}

main()
