/**
 * test-martingale-tie-push.ts — Test du correctif v17 « état neutre Tie/Refund ».
 * ==============================================================================
 *
 * SPÉCIFICATION UTILISATEUR (P&L = 0 $ = Tie ou Refund) :
 *   1. Gain (Win)          : Réinitialiser la mise au montant initial ;
 *   2. Perte (Loss)        : Incrémenter la mise selon le multiplicateur défini ;
 *   3. Remboursement/Égalité (Push/Tie, P&L = 0) : Conserver le niveau de mise
 *      courant pour l'ordre suivant (l'index de la suite de mises ne bouge PAS).
 *
 * CAS DE VALIDATION (exigés par l'utilisateur, base 1$, multiplicateur ×2) :
 *   Cas 1 (remise à niveau simple) :
 *     Ordre 1 (1$) → Remboursé (0$) → Ordre 2 = 1$ (au lieu d'incrémenter à 2$).
 *   Cas 2 (séquence progressive) :
 *     Ordre 1 (1$) → Perdu ; Ordre 2 (2$) → Perdu ; Ordre 3 (4$) → Remboursé (0$)
 *     → Ordre 4 = 4$ (mise maintenue) ; Ordre 5 (si Ordre 4 perdu) = 8$.
 *
 * Couvre AUSSI :
 *   - classifySettledOutcome (profit > 0 / < 0 / = 0 réel / = 0 dégradé) ;
 *   - stats : un push n'est ni un win ni un loss (compteur dédié pushes) ;
 *   - Fibonacci : un push ne fait PAS avancer fibIndex ;
 *   - isolation multi-assets : un push EURUSD ne touche JAMAIS XAUUSD ;
 *   - compatibilité booléenne des anciens appels (true/false) ;
 *   - chemin RÉEL : règlement broker (id numérique ≠ UUID, empreinte) avec
 *     profit NET = 0 (Tie) → 'push' → index de mises inchangé.
 *
 * Exécution : npx tsx scripts/test-martingale-tie-push.ts
 */
import {
  computeBettingAmount,
  createAssetContext,
  updateBettingAfterResult,
  applyDealResult,
  classifySettledOutcome,
  normalizeBettingOutcome,
  findTrackedDealByFingerprint,
  MARTINGALE_MULTIPLIER,
} from '../mini-services/iqoption-backend/asset-contexts.js'

let passed = 0
let failed = 0
function check(name: string, cond: boolean, detail = '') {
  if (cond) { passed++; console.log(`  ✓ ${name}`) }
  else { failed++; console.error(`  ✗ ${name}${detail ? ' — ' + detail : ''}`) }
}

/* ══ 1. classifySettledOutcome — classification trois états ══ */
console.log('\n[1] classifySettledOutcome — profit > 0 = win, < 0 = loss, = 0 réel = push')
{
  check('profit 0.85 (isWin absent) → win', classifySettledOutcome({ profit: 0.85 }) === 'win')
  check('isWin true (profit 0) → win (le broker dit gain)', classifySettledOutcome({ profit: 0, isWin: true, id: 'uuid-1' }) === 'win')
  check('profit -1 → loss', classifySettledOutcome({ profit: -1, id: 123 }) === 'loss')
  check('isWin false, profit -5 → loss', classifySettledOutcome({ profit: -5, isWin: false, id: 123 }) === 'loss')

  // Tie/Refund RÉEL (chemin successcloseOrder, capture 2026-09-17) :
  // deals[0] porte l'UUID d'ouverture, l'asset, closeTimestamp — profit NET = 0.
  check('profit 0 + closeTime réel → push (Tie/Refund)',
    classifySettledOutcome({ id: '550e8400-e29b', asset: 'EURUSD_otc', closeTime: 1789042, profit: 0, isWin: false }) === 'push')
  check('profit 0 + asset réel (cache lazy, id numérique) → push',
    classifySettledOutcome({ id: 48151623, asset: 'EURUSD_otc', closeTime: 0, profit: 0, isWin: false }) === 'push')
  check('profit 0 + UUID seul (sans asset ni closeTime) → push',
    classifySettledOutcome({ id: '550e8400-e29b', asset: '', closeTime: 0, profit: 0 }) === 'push')

  // Placeholder dégradé (enveloppe fallback : id 0, asset vide, sans clôture) :
  // comportement ANTÉRIEUR conservé (loss) — de toute façon inattribuable.
  check('profit 0 + id 0 + asset vide + sans closeTime → loss (dégradé, inchangé)',
    classifySettledOutcome({ id: 0, asset: '', closeTime: 0, profit: 0, isWin: false }) === 'loss')

  check('normalizeBettingOutcome(true)=win, (false)=loss, (\'push\')=push',
    normalizeBettingOutcome(true) === 'win' && normalizeBettingOutcome(false) === 'loss' && normalizeBettingOutcome('push') === 'push')
  check('MARTINGALE_MULTIPLIER = 2 (attendu par les cas de validation)', MARTINGALE_MULTIPLIER === 2)
}

/* ══ 2. CAS 1 UTILISATEUR — remise à niveau simple ══ */
console.log('\n[2] CAS 1 — Ordre 1 (1$) → Remboursé (0$) → Ordre 2 = 1$ (pas 2$)')
{
  const ctx = createAssetContext('EURUSD_otc', { baseAmount: 1, bettingStrategy: 'martingale' })
  const stake1 = computeBettingAmount(ctx)
  check('Ordre 1 : mise de base 1$', stake1 === 1, `obtenu ${stake1}`)

  ctx.trackedDeals.set('uuid-o1', { asset: ctx.asset, amount: 1, expirationSeconds: 3 })
  const res1 = applyDealResult(ctx, 'uuid-o1', 'push')
  check('Ordre 1 réglé REMBOURSÉ (profit 0) → résultat push appliqué',
    res1?.outcome === 'push' && res1?.isWin === false, `obtenu ${res1?.outcome}`)

  const stake2 = computeBettingAmount(ctx)
  check('Ordre 2 : mise maintenue à 1$ (AU LIEU d\'incrémenter à 2$)', stake2 === 1, `obtenu ${stake2}`)
  check('l\'index de la suite de mises n\'a pas bougé (consecutiveLosses = 0)',
    ctx.betting.consecutiveLosses === 0, `obtenu ${ctx.betting.consecutiveLosses}`)
  check('stats : 0 win, 0 loss, 1 push (état neutre compté à part)',
    ctx.stats.wins === 0 && ctx.stats.losses === 0 && ctx.stats.pushes === 1,
    `obtenu ${ctx.stats.wins}W/${ctx.stats.losses}L/${ctx.stats.pushes}T`)
}

/* ══ 3. CAS 2 UTILISATEUR — séquence progressive 1→2→4→TIE→4→8 ══ */
console.log('\n[3] CAS 2 — 1$→Perdu, 2$→Perdu, 4$→Remboursé, Ordre 4 = 4$ (maintenue), Ordre 5 (perdu) → 8$')
{
  const ctx = createAssetContext('EURUSD_otc', { baseAmount: 1, bettingStrategy: 'martingale' })

  // Ordre 1 : 1$ → LOSS
  ctx.trackedDeals.set('uuid-o1', { asset: ctx.asset, amount: 1, expirationSeconds: 3 })
  const r1 = applyDealResult(ctx, 'uuid-o1', 'loss')
  check('Ordre 1 (1$) → Perdu : prochaine mise 2$', r1?.nextBetAmount === 2, `obtenu ${r1?.nextBetAmount}`)

  // Ordre 2 : 2$ → LOSS
  check('Ordre 2 : mise calculée 2$', computeBettingAmount(ctx) === 2, `obtenu ${computeBettingAmount(ctx)}`)
  ctx.trackedDeals.set('uuid-o2', { asset: ctx.asset, amount: 2, expirationSeconds: 3 })
  const r2 = applyDealResult(ctx, 'uuid-o2', 'loss')
  check('Ordre 2 (2$) → Perdu : prochaine mise 4$', r2?.nextBetAmount === 4, `obtenu ${r2?.nextBetAmount}`)

  // Ordre 3 : 4$ → TIE (remboursé 0$)
  check('Ordre 3 : mise calculée 4$', computeBettingAmount(ctx) === 4, `obtenu ${computeBettingAmount(ctx)}`)
  ctx.trackedDeals.set('uuid-o3', { asset: ctx.asset, amount: 4, expirationSeconds: 3 })
  const r3 = applyDealResult(ctx, 'uuid-o3', 'push')
  check('Ordre 3 (4$) → Remboursé (0$) : prochaine mise TOUJOURS 4$ (maintenue)',
    r3?.nextBetAmount === 4, `obtenu ${r3?.nextBetAmount}`)
  check('après le Tie : consecutiveLosses = 2 (index inchangé — pas d\'incrément)',
    ctx.betting.consecutiveLosses === 2, `obtenu ${ctx.betting.consecutiveLosses}`)

  // Ordre 4 : 4$ (maintenue) → LOSS
  check('Ordre 4 : mise calculée 4$ (niveau maintenu par le Tie)', computeBettingAmount(ctx) === 4, `obtenu ${computeBettingAmount(ctx)}`)
  ctx.trackedDeals.set('uuid-o4', { asset: ctx.asset, amount: 4, expirationSeconds: 3 })
  const r4 = applyDealResult(ctx, 'uuid-o4', 'loss')
  check('Ordre 4 (4$) → Perdu : Ordre 5 = 8$ (passage au niveau suivant)',
    r4?.nextBetAmount === 8, `obtenu ${r4?.nextBetAmount}`)

  // Séquence complète exigée : 1 → 2 → 4 → 4 → 8
  check('séquence complète des mises = 1 → 2 → 4 → 4 → 8',
    ctx.betting.consecutiveLosses === 3 && computeBettingAmount(ctx) === 8,
    `streak=${ctx.betting.consecutiveLosses} prochaine=${computeBettingAmount(ctx)}`)
}

/* ══ 4. WIN après un push — reset normal ; push après win — maintien ══ */
console.log('\n[4] WIN après push → reset à la base ; push après win → mise de base maintenue')
{
  const ctx = createAssetContext('EURUSD_otc', { baseAmount: 1, bettingStrategy: 'martingale' })

  // 1 → L → 2 → L → 4
  updateBettingAfterResult(ctx, false)
  updateBettingAfterResult(ctx, false)
  check('préambule : 2 pertes → mise 4$', computeBettingAmount(ctx) === 4, `obtenu ${computeBettingAmount(ctx)}`)

  // push → toujours 4
  updateBettingAfterResult(ctx, 'push')
  check('push à streak 2 : mise conservée 4$', computeBettingAmount(ctx) === 4, `obtenu ${computeBettingAmount(ctx)}`)

  // win → reset à la base
  updateBettingAfterResult(ctx, 'win')
  check('WIN après push : mise réinitialisée à 1$', computeBettingAmount(ctx) === 1, `obtenu ${computeBettingAmount(ctx)}`)

  // push après win → base maintenue (pas d'incrément)
  updateBettingAfterResult(ctx, 'push')
  check('push à streak 0 : mise maintenue 1$ (pas 2$)', computeBettingAmount(ctx) === 1, `obtenu ${computeBettingAmount(ctx)}`)

  // chaîne de pushes : aucun effet
  for (let i = 0; i < 5; i++) updateBettingAfterResult(ctx, 'push')
  check('5 pushes consécutifs : mise toujours 1$, streak toujours 0',
    computeBettingAmount(ctx) === 1 && ctx.betting.consecutiveLosses === 0,
    `mise=${computeBettingAmount(ctx)} streak=${ctx.betting.consecutiveLosses}`)
}

/* ══ 5. Fibonacci — un push ne fait PAS avancer fibIndex ══ */
console.log('\n[5] Fibonacci — push : fibIndex inchangé (mise conservée)')
{
  const ctx = createAssetContext('EURUSD_otc', { baseAmount: 1, bettingStrategy: 'fibonacci' })

  updateBettingAfterResult(ctx, false) // fibIndex 0 → 1
  updateBettingAfterResult(ctx, false) // fibIndex 1 → 2
  const fibAfter2Losses = ctx.betting.fibIndex
  const stakeAfter2Losses = computeBettingAmount(ctx)
  check('préambule Fibonacci : 2 pertes → fibIndex 2', fibAfter2Losses === 2, `obtenu ${fibAfter2Losses}`)

  updateBettingAfterResult(ctx, 'push')
  check('push : fibIndex INCHANGÉ (2)',
    ctx.betting.fibIndex === fibAfter2Losses, `obtenu ${ctx.betting.fibIndex}`)
  check('push : mise Fibonacci conservée au niveau courant',
    computeBettingAmount(ctx) === stakeAfter2Losses,
    `obtenu ${computeBettingAmount(ctx)} (attendu ${stakeAfter2Losses})`)

  updateBettingAfterResult(ctx, false)
  check('perte après push : fibIndex avance normalement (3)',
    ctx.betting.fibIndex === 3, `obtenu ${ctx.betting.fibIndex}`)
}

/* ══ 6. Isolation multi-assets — push EURUSD ne touche pas XAUUSD ══ */
console.log('\n[6] Isolation — un push EURUSD n\'affecte JAMAIS la suite de mises de XAUUSD')
{
  const eur = createAssetContext('EURUSD_otc', { baseAmount: 1, bettingStrategy: 'martingale' })
  const xau = createAssetContext('XAUUSD_otc', { baseAmount: 1, bettingStrategy: 'martingale' })

  updateBettingAfterResult(eur, false) // EUR streak 1
  updateBettingAfterResult(xau, false) // XAU streak 1
  updateBettingAfterResult(xau, false) // XAU streak 2

  eur.trackedDeals.set('uuid-e1', { asset: 'EURUSD_otc', amount: 2, expirationSeconds: 3 })
  applyDealResult(eur, 'uuid-e1', 'push') // push sur EURUSD

  check('EURUSD : streak inchangé par son propre push (1)',
    eur.betting.consecutiveLosses === 1, `obtenu ${eur.betting.consecutiveLosses}`)
  check('XAUUSD : streak intact (2) — aucune contamination',
    xau.betting.consecutiveLosses === 2, `obtenu ${xau.betting.consecutiveLosses}`)
  check('XAUUSD : mise intacte 4$',
    computeBettingAmount(xau) === 4, `obtenu ${computeBettingAmount(xau)}`)
  check('EURUSD : stats pushes = 1, XAUUSD : pushes = 0',
    eur.stats.pushes === 1 && xau.stats.pushes === 0,
    `eur=${eur.stats.pushes} xau=${xau.stats.pushes}`)
}

/* ══ 7. Chemin RÉEL — règlement broker (id numérique ≠ UUID) Tie par empreinte ══ */
console.log('\n[7] Chemin réel — règlement broker Tie (profit NET = 0) rattaché par empreinte → push')
{
  const ctx = createAssetContext('EURUSD_otc', { baseAmount: 1, bettingStrategy: 'martingale' })

  // 2 pertes préalables : streak 2 → prochaine mise 4$.
  updateBettingAfterResult(ctx, false)
  updateBettingAfterResult(ctx, false)

  // Ordre BOS en vol : UUID d'ouverture + empreinte du fill.
  const orderUuid = '9f1c8a34-7b2e-4d55-9a10-6e8d1c2b4a77'
  const fill = 1.18543
  const openTime = 1_789_000_000
  const expiry = 3 // expiration de la RÈGLE BOS (3 s)
  ctx.trackedDeals.set(orderUuid, {
    asset: ctx.asset,
    amount: 4,
    expirationSeconds: expiry,
    openPrice: fill,
    openTime,
    action: 'call',
  })

  // Règlement broker TIE : id NUMÉRIQUE ≠ UUID, closePrice === openPrice
  // (égalité exacte), profit NET = 0, isWin = false — le payload natif
  // successcloseOrder (capture 2026-09-17) avec deals[0].
  const closedNumericId = 48151623
  const classified = classifySettledOutcome({
    id: closedNumericId,
    asset: ctx.asset,
    closeTime: openTime + expiry,
    profit: 0,
    isWin: false,
  })
  check('classification du règlement broker Tie → push', classified === 'push', `obtenu ${classified}`)

  const match = findTrackedDealByFingerprint(ctx, {
    id: closedNumericId,
    asset: ctx.asset,
    amount: 4,
    openPrice: fill,
    closePrice: fill, // égalité exacte = Tie
    openTime,
    closeTime: openTime + expiry,
    profit: 0,
    isWin: false,
  })
  check('le règlement Tie (close === open) rattaché à l\'ordre suivi par empreinte (direction cohérente)',
    match?.key === orderUuid, `obtenu ${match?.key ?? 'AUCUN'}`)

  const res = match ? applyDealResult(ctx, match.key, classified) : null
  check('applyDealResult sur la clé rattachée → push, prochaine mise 4$ (conservée)',
    res?.outcome === 'push' && res?.nextBetAmount === 4, `obtenu ${res?.outcome}/${res?.nextBetAmount}`)

  // La perte suivante repart du niveau maintenu.
  updateBettingAfterResult(ctx, 'loss')
  check('perte suivante : mise 8$ (le Tie n\'avait PAS avancé l\'index)',
    computeBettingAmount(ctx) === 8, `obtenu ${computeBettingAmount(ctx)}`)

  check('le deal suivi a bien été retiré de trackedDeals',
    !ctx.trackedDeals.has(orderUuid), 'le tracked deal aurait dû être supprimé')
}

/* ══ 8. Compatibilité booléenne — anciens appels true/false ══ */
console.log('\n[8] Compatibilité — les anciens appels booléens (true/false) restent win/loss')
{
  const ctx = createAssetContext('EURUSD_otc', { baseAmount: 5, bettingStrategy: 'martingale' })
  ctx.trackedDeals.set('d-1', { asset: ctx.asset, amount: 5, expirationSeconds: 5 })
  const r1 = applyDealResult(ctx, 'd-1', false)
  check('applyDealResult(ctx, deal, false) → loss (mise doublée)',
    r1?.outcome === 'loss' && r1?.nextBetAmount === 10, `obtenu ${r1?.outcome}/${r1?.nextBetAmount}`)
  ctx.trackedDeals.set('d-2', { asset: ctx.asset, amount: 10, expirationSeconds: 5 })
  const r2 = applyDealResult(ctx, 'd-2', true)
  check('applyDealResult(ctx, deal, true) → win (reset à la base)',
    r2?.outcome === 'win' && r2?.nextBetAmount === 5, `obtenu ${r2?.outcome}/${r2?.nextBetAmount}`)
  check('isWin du résumé : true seulement pour win (loss et push → false)',
    r1?.isWin === false && r2?.isWin === true, `r1=${r1?.isWin} r2=${r2?.isWin}`)
  check('deal non suivi → null (aucun effet)',
    applyDealResult(ctx, 'inconnu', 'push') === null)
}

console.log(`\n══ ${passed} ✓ / ${failed} ✗ ══`)
process.exit(failed > 0 ? 1 : 0)
