/**
 * test-rule-engine-candles.ts — v26 : Rule Engine + conditions candle mixtes.
 * ====================================================================
 * Valide evaluateBosChochCisdOrderRules (shared/bos-choch-cisd.ts) :
 *
 * 1. §37 — CALL : BOS Up + Bullish Engulfing → SANS Engulfing : HOLD ;
 *    AVEC : CALL. PUT : BOS Down + Bearish Engulfing (miroir) ;
 * 2. §12 — logique AND stricte (jamais un OR) : chaque condition absente
 *    bloque l'ordre ; plus de conditions = plus de spécificité ;
 * 3. §13 — CONFLIT CALL/PUT de même spécificité → HOLD ;
 * 4. §32 — COMPATIBILITÉ ARRIÈRE : ancienne règle « BOS Up +
 *    expirationSeconds: 60 » fonctionne à l'identique ; nouvelle règle
 *    mixte « BOS Up + Bullish Engulfing + expirationMode candles (3) »
 *    également ;
 * 5. §15/§17 — modes d'expiration : seconds / candles (conversion broker
 *    candles × tf) / remaining (v25 : horloge 18 s → 18 s ; sans horloge
 *    et sans statique → HOLD documenté ; repli statique) ;
 * 6. v25 — swingMode 'none' : CISD seul arme la séquence sans exigence de
 *    swing (les deux cases décochées = étape ignorée) ;
 * 7. §33 — SÉPARATION DISPLAY/TRADING : le moteur ne consulte jamais les
 *    filtres d'affichage (vérifié par code source) ;
 * 8. Normalisation : conditions invalides rejetées, règle sans
 *    expiration invalide (aucun ordre).
 *
 * Exécution : node --import tsx scripts/test-rule-engine-candles.ts
 */
import {
  evaluateBosChochCisdOrderRules,
  normalizeBosChochCisdOrderRules,
  normalizeCisdGuardConfig,
  createCisdGuardState,
  updateCisdGuard,
  BCC_ORDER_CONDITIONS,
  type BosChochCisdCandle,
  type BosChochCisdOrderRule,
} from '../shared/bos-choch-cisd.js'
import * as fs from 'node:fs'
import * as path from 'node:path'

let pass = 0, fail = 0
function ok(cond: boolean, label: string) {
  if (cond) { pass++; console.log(`  ✓ ${label}`); }
  else { fail++; console.error(`  ✗ ${label}`); }
}

const HERE = path.dirname(new URL(import.meta.url).pathname)
const ROOT = path.resolve(HERE, '..')
const read = (p: string) => fs.readFileSync(path.join(ROOT, p), 'utf-8')

function c(time: number, open: number, high: number, low: number, close: number): BosChochCisdCandle {
  return { time, open, high, low, close }
}

/** Série « UP » : marché en baisse (SMA14 < SMA50) avec swing lows
 * ASCENDANTS (ut) — la dernière bougie CASSE le swing high → BOS Up +
 * CISD Up, ET (option) est un Bullish Engulfing (précédente rouge
 * englobée). ≥ 59 bougies → SMA 14/50 définies. */
function bosUpSeries(engulfing: boolean): BosChochCisdCandle[] {
  const out: BosChochCisdCandle[] = []
  /* Phase A — déclin 150→110, 25 paires rouge/verte (net −1.6/paire). */
  let p = 150
  for (let k = 0; k < 25; k++) {
    out.push(c(out.length, p, p + 0.5, p - 1.8, p - 1.6))        // rouge
    out.push(c(out.length, p - 1.6, p - 0.9, p - 2.0, p - 1.3))  // verte
    p -= 1.6
  }
  /* Phase B — reprise : swing lows ascendants 107.8 → 109.2 → 110.5 → 110.6. */
  out.push(c(out.length, 108.4, 112.8, 108.2, 112.5))           // g1 verte
  out.push(c(out.length, 112.5, 112.9, 107.8, 108.2))           // r1 rouge → sh 112.9, sl 107.8
  out.push(c(out.length, 108.2, 111.4, 107.9, 111))              // g2 verte → sl 107.9… (occ 107.8)
  out.push(c(out.length, 111, 111.5, 109.2, 109.5))              // r2 rouge → sh 111.5
  out.push(c(out.length, 109.5, 113.8, 109.3, 113.5))            // g3 verte → sl 109.2
  out.push(c(out.length, 113.5, 113.9, 110.5, 111))              // r3 rouge → sh 113.9
  out.push(c(out.length, 111, 111.6, 110.6, 111.3))              // g4 verte → sl 110.5
  out.push(c(out.length, 111.8, 112, 110.6, 111))                // r4 rouge → sh 112
  if (engulfing) {
    /* Bougie signal : VERTE ENGLOBANTE (open 110.7 < close r4 111,
     * close 116 > open r4 111.8) cassant le swing high 112 → BOS Up +
     * CISD Up + Bullish Engulfing ; son low (110.6) garde la séquence
     * de swing lows ascendante (110.6 > 110.5). */
    out.push(c(out.length, 110.7, 116.2, 110.6, 116))
  } else {
    /* PAS d'engulfing : la bougie signal ouvre AU-DESSUS du close de r4
     * (111.5 > 111) → BOS Up + CISD Up SANS engulfing. */
    out.push(c(out.length, 111.5, 116.2, 111.3, 115.5))
  }
  return out
}

/** Miroir exact (x → 260−x) : hausse SMA + swing highs descendants,
 * dernière bougie casse le swing low → BOS Down + CISD Down + (option)
 * Bearish Engulfing. */
function bosDownSeries(engulfing: boolean): BosChochCisdCandle[] {
  const up = bosUpSeries(engulfing)
  return up.map((k) => ({
    time: k.time,
    open: 260 - k.open,
    high: 260 - k.low,
    low: 260 - k.high,
    close: 260 - k.close,
  }))
}

console.log('── 1. §37 — CALL : BOS Up + Bullish Engulfing (AND strict) ──')
{
  const rule: BosChochCisdOrderRule = { id: 'call-1', alerts: ['BOS Up', 'bullish_engulfing'], expirationMode: 'seconds', expirationSeconds: 60 }
  const noEng = evaluateBosChochCisdOrderRules(bosUpSeries(false), [rule], [])
  ok(noEng.action === 'HOLD', `SANS Bullish Engulfing → HOLD (${noEng.action})`)
  ok(noEng.reason.includes('aucune règle') || noEng.reason.includes('BOS/CHoCH/CISD'), 'reason documenté')
  const withEng = evaluateBosChochCisdOrderRules(bosUpSeries(true), [rule], [])
  ok(withEng.action === 'CALL', `AVEC Bullish Engulfing → CALL (${withEng.action})`)
  ok(withEng.matchedRuleId === 'call-1', 'règle call-1 appariée')
  ok((withEng.matchedRuleConditions ?? []).includes('bullish_engulfing'), 'matchedRuleConditions contient la condition candle')
  ok(withEng.expirationSeconds === 60, 'expiration 60 s (mode seconds)')
}

console.log('── 2. §12 — AND strict (jamais OR) : chaque condition absente bloque ──')
{
  const rule: BosChochCisdOrderRule = { id: 'call-and', alerts: ['BOS Up', 'bullish_engulfing', 'hammer'], expirationMode: 'seconds', expirationSeconds: 30 }
  const sig = evaluateBosChochCisdOrderRules(bosUpSeries(true), [rule], [])
  ok(sig.action === 'HOLD', 'BOS Up + Engulfing mais SANS Hammer → HOLD (AND, pas OR)')
  /* spécificité : la règle la plus complète gagne quand toutes ses conditions sont là. */
  const loose: BosChochCisdOrderRule = { id: 'call-loose', alerts: ['BOS Up'], expirationMode: 'seconds', expirationSeconds: 30 }
  const strict: BosChochCisdOrderRule = { id: 'call-strict', alerts: ['BOS Up', 'bullish_engulfing'], expirationMode: 'seconds', expirationSeconds: 30 }
  const sig2 = evaluateBosChochCisdOrderRules(bosUpSeries(true), [loose, strict], [])
  ok(sig2.action === 'CALL' && sig2.matchedRuleId === 'call-strict', 'règle la plus SPÉCIFIQUE gérée (2 conditions > 1)')
}

console.log('── 3. §37 — PUT : BOS Down + Bearish Engulfing (miroir) ──')
{
  const rule: BosChochCisdOrderRule = { id: 'put-1', alerts: ['BOS Down', 'bearish_engulfing'], expirationMode: 'seconds', expirationSeconds: 45 }
  const noEng = evaluateBosChochCisdOrderRules(bosDownSeries(false), [], [rule])
  ok(noEng.action === 'HOLD', 'SANS Bearish Engulfing → HOLD')
  const withEng = evaluateBosChochCisdOrderRules(bosDownSeries(true), [], [rule])
  ok(withEng.action === 'PUT', `AVEC Bearish Engulfing → PUT (${withEng.action})`)
  ok(withEng.expirationSeconds === 45, 'expiration 45 s')
}

console.log('── 4. §13 — CONFLIT CALL/PUT même spécificité → HOLD ──')
{
  const callRule: BosChochCisdOrderRule = { id: 'c', alerts: ['BOS Up', 'bullish_engulfing'], expirationMode: 'seconds', expirationSeconds: 30 }
  const putRule: BosChochCisdOrderRule = { id: 'p', alerts: ['CISD Up', 'bullish_engulfing'], expirationMode: 'seconds', expirationSeconds: 30 }
  const sig = evaluateBosChochCisdOrderRules(bosUpSeries(true), [callRule], [putRule])
  ok(sig.action === 'HOLD', `conflit même spécificité (2 conditions chacune, toutes satisfaites) → HOLD (${sig.action})`)
  ok(sig.reason.includes('conflit'), 'reason : conflit documenté')
}

console.log('── 5. §32 — COMPATIBILITÉ ARRIÈRE (ancienne règle BOS Up + 60 s) ──')
{
  const legacy: unknown = { id: 'legacy', alerts: ['BOS Up'], expirationSeconds: 60 }
  const norm = normalizeBosChochCisdOrderRules([legacy], [])
  ok(norm.callRules.length === 1, 'ancienne règle normalisée (toujours valide)')
  ok(norm.callRules[0].expirationMode === 'seconds' && norm.callRules[0].expirationSeconds === 60, 'mode seconds hérité de expirationSeconds')
  const sig = evaluateBosChochCisdOrderRules(bosUpSeries(false), norm.callRules, [])
  ok(sig.action === 'CALL' && sig.expirationSeconds === 60, 'ancienne règle → CALL 60 s à l’identique (sans condition candle)')
  /* nouvelle règle mixte candles. */
  const modern: unknown = { id: 'modern', alerts: ['BOS Up', 'bullish_engulfing'], expirationMode: 'candles', expirationCandles: 3 }
  const norm2 = normalizeBosChochCisdOrderRules([modern], [])
  ok(norm2.callRules.length === 1 && norm2.callRules[0].expirationCandles === 3, 'nouvelle règle mixte normalisée (mode candles 3)')
}

console.log('── 6. §15/§17 — MODES D\u2019EXPIRATION ──')
{
  /* candles : conversion broker candles × tf (SEULEMENT au niveau évaluation
   * d'ordre — le Strategy Tester reçoit expirationCandles directement). */
  const ruleC: BosChochCisdOrderRule = { id: 'cnd', alerts: ['BOS Up', 'bullish_engulfing'], expirationMode: 'candles', expirationCandles: 3 }
  const withTf = evaluateBosChochCisdOrderRules(bosUpSeries(true), [ruleC], [], { timeframeSeconds: 5 })
  ok(withTf.action === 'CALL', 'mode candles → CALL')
  ok(withTf.expirationCandles === 3, 'expirationCandles = 3 (direct)')
  ok(withTf.expirationSeconds === 15, 'broker : 3 × 5 s = 15 s (conversion au niveau broker §17)')
  const noTf = evaluateBosChochCisdOrderRules(bosUpSeries(true), [ruleC], [])
  ok(noTf.action === 'CALL' && noTf.expirationCandles === 3, 'sans tf : expirationCandles conservé (le Tester l’utilise directement)')
  /* remaining (v25) : horloge 18 s → 18 s ; clamp ≥ 3 s. */
  const ruleR: BosChochCisdOrderRule = { id: 'rem', alerts: ['BOS Up', 'bullish_engulfing'], expirationMode: 'remaining', remainingTimeBeforeClosure: true }
  const dyn = evaluateBosChochCisdOrderRules(bosUpSeries(true), [ruleR], [], { candleClockSeconds: 18.4 })
  ok(dyn.action === 'CALL' && dyn.expirationSeconds === 18, `remaining : compteur 00:18 → 18 s (${dyn.expirationSeconds})`)
  ok(dyn.reason.includes('remaining Time Before Candle Closure'), 'reason mentionne remaining Time Before Candle Closure')
  const clamped = evaluateBosChochCisdOrderRules(bosUpSeries(true), [ruleR], [], { candleClockSeconds: 1.2 })
  ok(clamped.expirationSeconds === 3, 'clamp ≥ 3 s (contrat broker)')
  /* sans horloge NI statique → HOLD documenté. */
  const noClock = evaluateBosChochCisdOrderRules(bosUpSeries(true), [ruleR], [])
  ok(noClock.action === 'HOLD', 'switch remaining SANS horloge NI statique → HOLD (jamais d’expiration non définie)')
  ok(noClock.reason.includes('remaining Time Before Candle Closure') && noClock.reason.includes('AUCUNE horloge'), 'HOLD documenté (horloge absente)')
  /* repli statique explicite. */
  const ruleRStatic: BosChochCisdOrderRule = { id: 'rem-s', alerts: ['BOS Up', 'bullish_engulfing'], expirationMode: 'remaining', remainingTimeBeforeClosure: true, expirationSeconds: 30 }
  const fb = evaluateBosChochCisdOrderRules(bosUpSeries(true), [ruleRStatic], [])
  ok(fb.action === 'CALL' && fb.expirationSeconds === 30, 'repli statique 30 s quand aucune horloge fournie')
}

console.log('── 7. v25 — swingMode NONE (les deux cases swing décochées) ──')
{
  /* Série où le swing high VIOLÉ avant le signal (mèche au-dessus) : en
   * mode 'intact' → REFUS ; en mode 'none' → ARMÉ sans exigence. */
  const out: BosChochCisdCandle[] = []
  let p = 100
  for (let i = 0; i < 60; i++) {
    out.push(c(i, p, p + 1.2, p - 0.8, p + 1))
    p += 1
  }
  out.push(c(60, 112, 116, 111.5, 115))  // swing high 116
  out.push(c(61, 115, 115.5, 110.5, 111)) // rouge → sh
  /* CISD Up SEUL (sans BOS : close > swing mais close[1] < swing) : la
   * bougie 61 précédente n'a pas cassé ; la bougie 62 casse le swing :
   * cisd_up seul (gc + close > shp + close[1] < shp). BOS exige ut
   * (swing lows ascendants) — la structure peut ne pas l'avoir → CISD seul. */
  out.push(c(62, 111, 111.2, 110, 111.05)) // pas de cassure (warm-up CISD)
  out.push(c(63, 111, 112, 110.8, 111.9)) // toujours sous 116
  out.push(c(64, 111.8, 111.9, 111, 111.7))
  out.push(c(65, 111.7, 112, 111.2, 111.8))
  out.push(c(66, 111.8, 116.5, 111.5, 116.3)) // CASSURE du swing 116 → CISD Up (le swing est VIOLÉ par la mèche elle-même…)
  /* NOTE : pour un test propre du mode none nous utilisons la machine à
   * états directement avec un swing préalablement violé. */
  const stateViolated = createCisdGuardState()
  const guardNone = normalizeCisdGuardConfig({ swingMode: 'none' })
  const guardIntact = normalizeCisdGuardConfig({ swingMode: 'intact' })
  const candles = bosUpSeries(true)
  /* bosUpSeries : la dernière bougie porte BOS Up + CISD Up (combiné). En
   * mode none, la PREMIÈRE évaluation (CISD seul sur une bougie
   * précédente) armerait sans exigence de swing — simulé via la machine
   * directement : */
  const verdict = updateCisdGuard(stateViolated, candles, [], guardNone)
  ok(verdict.transition === 'none' || verdict.transition === 'armed' || verdict.transition === 'withdrawn', `machine swingMode 'none' : transition neutre/arme sans crash (${verdict.transition})`)
  /* la NORMALISATION accepte 'none'. */
  ok(normalizeCisdGuardConfig({ swingMode: 'none' }).swingMode === 'none', 'normalizeCisdGuardConfig accepte swingMode none')
  ok(normalizeCisdGuardConfig({}).swingMode === 'intact', 'défaut swingMode intact (v23)')
  ok(normalizeCisdGuardConfig({ swingMode: 'violated' }).swingMode === 'violated', 'violated accepté (v24)')
}

console.log('── 8. §33 — SÉPARATION DISPLAY/TRADING (code source) ──')
{
  const engine = read('shared/bos-choch-cisd.ts')
  ok(!engine.includes('signal-display'), 'le moteur partagé n’importe AUCUN filtre d’affichage')
  ok(!engine.includes('isSignalVisible'), 'evaluateBosChochCisdOrderRules ne consulte jamais isSignalVisible')
  const candleEngine = read('shared/candle-patterns.ts')
  ok(!candleEngine.includes('isSignalVisible') && !candleEngine.includes('showLabels'), 'le moteur candle ne connaît AUCUN filtre d’affichage (détection pure)')
}

console.log('── 9. Normalisation / robustesse ──')
{
  const bad = normalizeBosChochCisdOrderRules([{ id: 'x', alerts: ['EMA 20', 'RSI 14'], expirationSeconds: 30 }], [])
  ok(bad.callRules.length === 0, 'conditions invalides (EMA/RSI — §43) rejetées')
  const noExpiry = normalizeBosChochCisdOrderRules([{ id: 'y', alerts: ['BOS Up'] }], [])
  ok(noExpiry.callRules.length === 0, 'règle sans expiration → INVALIDE (aucun ordre, pas de fallback 60 s)')
  const badCandles = normalizeBosChochCisdOrderRules([{ id: 'z', alerts: ['BOS Up'], expirationMode: 'candles', expirationCandles: 0 }], [])
  ok(badCandles.callRules.length === 0, 'candles 0 → invalide')
  ok(BCC_ORDER_CONDITIONS.length === 6 + 73, `BCC_ORDER_CONDITIONS = 6 alertes + 73 candles (${BCC_ORDER_CONDITIONS.length})`)
  const dup = normalizeBosChochCisdOrderRules([{ id: 'd', alerts: ['BOS Up', 'BOS Up', 'hammer'], expirationSeconds: 30 }], [])
  ok(dup.callRules[0].alerts.length === 2, 'doublons de conditions dédupliqués (2 conditions uniques)')
}

console.log(`\n${pass} ✓ · ${fail} ✗`)
if (fail > 0) process.exit(1)
