#!/bin/bash
# Vérification finale complète du menu Réglages (page propre)
cd /home/z/my-project
step() { echo ""; echo "════════ $1 ════════"; }
count() {
  agent-browser eval "
(() => {
  const blocks = [...document.querySelectorAll('div')].filter(d => String(d.className||'').includes('font-semibold') && /drawing object/.test(d.textContent));
  return blocks[0] ? blocks[0].textContent.match(/(\d+) drawing object/)[1] : '0';
})()" 2>&1 | tail -1 | tr -d '"'
}

# 1. Backend
pkill -f backend-supervisor 2>/dev/null; pkill -f "tsx index.ts" 2>/dev/null; sleep 1
setsid nohup bash scripts/backend-supervisor.sh >> backend.log 2>&1 &
sleep 16
curl -s -m 3 http://localhost:3030/health >/dev/null && echo "backend OK"

# 2. Page propre (le script v5 est déjà dans localStorage avec ZigZag=OFF)
agent-browser reload >/dev/null 2>&1
sleep 6
agent-browser find role button click --name "Login with Pocket Option" >/dev/null 2>&1
sleep 16
agent-browser eval "document.querySelectorAll('button').forEach(b=>{if(b.textContent.includes('PINE SCRIPT'))b.click()})" >/dev/null 2>&1
sleep 16
step "A. Après reload (réglages PERSISTÉS : ZigZag=OFF)"
A=$(count); echo "Dessins : $A (attendu ~252, pas 285 → la persistance marche)"

# 3. Rouvrir Réglages et recocher ZigZag
agent-browser eval "document.querySelectorAll('button').forEach(b=>{if(b.textContent.includes('Réglages'))b.click()})" >/dev/null 2>&1
sleep 4
agent-browser eval "
(() => {
  const inputs = [...document.querySelectorAll('input[type=checkbox]')];
  const target = inputs.find(cb => (cb.closest('div')?.textContent || '').includes('ZigZag : afficher'));
  if (target) { target.click(); return 'RECOCHÉ'; }
  return 'INTROUVABLE';
})()" 2>&1 | tail -1
sleep 5
step "B. ZigZag recoché"
B=$(count); echo "Dessins : $B (attendu ~285)"
[ "$A" != "$B" ] && echo "✓ toggle inverse OK ($A → $B)" || echo "✗ pas de changement"

# 4. Changer Deviation → 10.0
DEV_INPUT=$(agent-browser eval "
(() => {
  const rows = [...document.querySelectorAll('input[type=number]')];
  const row = rows.find(n => (n.closest('div')?.textContent || '').includes('Deviation — mouvement minimal'));
  return row ? 'TROUVÉ' : 'ABSENT';
})()" 2>&1 | tail -1 | tr -d '"')
echo "input deviation : $DEV_INPUT"
agent-browser eval "
(() => {
  const rows = [...document.querySelectorAll('input[type=number]')];
  const row = rows.find(n => (n.closest('div')?.textContent || '').includes('Deviation — mouvement minimal'));
  if (!row) return 'ABSENT';
  const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  setter.call(row, '10');
  row.dispatchEvent(new Event('input', { bubbles: true }));
  row.dispatchEvent(new Event('change', { bubbles: true }));
  return 'DEV=10 ENVOYÉ';
})()" 2>&1 | tail -1
sleep 5
step "C. Deviation = 10 (×ATR)"
C=$(count); echo "Dessins : $C (attendu < 285 — moins de pivots)"
[ "$C" != "$B" ] && echo "✓ deviation appliquée ($B → $C)" || echo "✗ pas de changement"

# 5. Bouton « Défauts » (reset)
agent-browser eval "
(() => {
  const btns = [...document.querySelectorAll('button')];
  const b = btns.find(x => x.textContent.includes('Défauts'));
  if (b) { b.click(); return 'RESET CLIQUÉ'; }
  return 'ABSENT';
})()" 2>&1 | tail -1
sleep 5
step "D. Reset « Défauts »"
D=$(count); echo "Dessins : $D (attendu ~285)"
[ "$D" = "$B" ] && echo "✓ reset OK ($C → $D = $B par défaut)" || echo "→ $D vs défaut $B"

# 6. Fermer la modale + capture finale du GRAPHIQUE (v5 complet visible)
agent-browser eval "
(() => {
  const modals = [...document.querySelectorAll('div')].filter(d => String(d.className||'').includes('z-[75]'));
  if (modals.length) { const btns = modals[0].querySelectorAll('button'); btns[btns.length-1].click(); }
  return 'fermée';
})()" >/dev/null 2>&1
sleep 2
agent-browser eval "
(() => {
  // ferme aussi l'éditeur (modale z-70) pour voir le graphique seul
  const modals = [...document.querySelectorAll('div')].filter(d => String(d.className||'').includes('z-[70]'));
  if (modals.length) { const btns = modals[0].querySelectorAll('button'); btns[btns.length-1].click(); }
  return 'éditeur fermé';
})()" >/dev/null 2>&1
sleep 3
agent-browser screenshot scripts/v5_final_chart.png >/dev/null 2>&1
echo "📸 v5_final_chart.png (graphique avec v5 par défaut)"

step "RÉCAPITULATIF"
echo "ZigZag OFF persisté: $A | ON: $B | Deviation 10: $C | Reset: $D"
