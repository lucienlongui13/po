#!/usr/bin/env python3
"""Vérification statique du script Pine v3 (wavescope_ict_v3.pine)."""
import re
import sys

PATH = "/home/z/my-project/download/wavescope_ict_v3.pine"

with open(PATH, encoding="utf-8") as f:
    lines = f.readlines()

issues = []
warns = []
ok = []

# 1) Boucles `for i = 0 to array.size(...) - 1` gardées
loop_re = re.compile(r"^\s*for\s+\w+\s*=\s*0\s+to\s+array\.size\(")
for idx, line in enumerate(lines):
    if loop_re.match(line):
        context = "".join(lines[max(0, idx - 4):idx + 1])
        if not re.search(r"(>\s*0|>=\s*1|>=\s*2|>=\s*n\b|lookback\s*>=\s*1)", context):
            issues.append(f"L{idx+1}: boucle non gardée → {line.strip()[:80]}")
        else:
            ok.append(f"L{idx+1}: boucle gardée ✓")

# 1bis) Boucles `for i = 0 to <var> - 1` où <var> est une taille — garder trace
loop2_re = re.compile(r"^\s*for\s+\w+\s*=\s*0\s+to\s+(\w+)\s*-\s*([12])\b")
for idx, line in enumerate(lines):
    m = loop2_re.match(line)
    if m:
        var = m.group(1)
        context = "".join(lines[max(0, idx - 6):idx + 1])
        if not re.search(re.escape(var) + r"\s*(>=|>)", context) and var not in ("nSwExt",):
            warns.append(f"L{idx+1}: boucle sur {var} sans garantie ≥ borne → {line.strip()[:70]}")

# 2) Parenthèses équilibrées par ligne
def strip_strings_comments(s):
    s = re.sub(r"//[^\n]*", "", s)
    s = re.sub(r'"(?:[^"\\]|\\.)*"', '""', s)
    return s

for idx, line in enumerate(lines):
    if line.strip().startswith("//"):
        continue
    s = strip_strings_comments(line)
    if s.count("(") != s.count(")"):
        warns.append(f"L{idx+1}: parens ({s.count('(')} vs {s.count(')')}) → {line.strip()[:70]}")

# 3) Indentation multiple de 4
for idx, line in enumerate(lines):
    if not line.strip():
        continue
    m = re.match(r"^( +)\S", line)
    if m and len(m.group(1)) % 4 != 0:
        warns.append(f"L{idx+1}: indentation {len(m.group(1))} espaces (pas multiple de 4)")

# 4) Doublons de déclarations globales
global_decls = {}
for idx, line in enumerate(lines):
    m = re.match(r"^(?:bool|int|float|string|color|label|line|box|table|var\s+\w+(?:<[^>]*>)?\s+\w+|var\s+(?:bool|int|float|string|color|label|line|box|table)\s+\w+)\s+(\w+)\s*=", line)
    if not m:
        m2 = re.match(r"^(\w+)\s+(\w+)\s*=", line)
        if m2 and not line.startswith(("if", "for", "while", "else", "f_", "[", "var")):
            m = m2
    if m:
        name = m.group(2) if m.re.pattern.startswith("(") else m.group(1)
        if name and name not in ("f_",):
            global_decls.setdefault(name, []).append(idx + 1)

for name, lns in global_decls.items():
    if len(lns) > 1:
        issues.append(f"Déclaration dupliquée '{name}' aux lignes {lns}")

# 5) Fonctions : définition avant premier appel
func_defs = {}
for idx, line in enumerate(lines):
    m = re.match(r"^(f_\w+)\s*\([^)]*\)\s*=>", line)
    if m:
        func_defs[m.group(1)] = idx + 1

calls_before_def = []
for idx, line in enumerate(lines):
    if line.strip().startswith("//"):
        continue
    for fn, def_ln in func_defs.items():
        if re.search(r"(?<!\w)" + re.escape(fn) + r"\(", line) and idx + 1 != def_ln:
            if idx + 1 < def_ln:
                calls_before_def.append(f"L{idx+1}: appel de {fn} avant sa définition (L{def_ln})")

# 6) Vérification des fonctions appelées mais jamais définies
all_called = set()
for idx, line in enumerate(lines):
    if line.strip().startswith("//"):
        continue
    for fn in re.findall(r"(?<!\w)(f_\w+)\(", line):
        all_called.add(fn)
undef = [fn for fn in all_called if fn not in func_defs]
if undef:
    issues.append(f"Fonctions appelées non définies : {sorted(undef)}")

# 7) Marqueurs v3 (fonctionnalités demandées)
content = "".join(lines)
markers = {
    "calc_on_every_tick (temps réel)": content.count("calc_on_every_tick=true"),
    "ZigZag Depth": content.count("zzDepth"),
    "ZigZag Deviation": content.count("zzDeviation"),
    "ZigZag Backstep": content.count("zzBackstep"),
    "filtre deviation (f_passes_filter)": content.count("f_passes_filter("),
    "lignes de tendance": content.count("trendSupLines") + content.count("trendResLines"),
    "bannière TENDANCE À SUIVRE": content.count("TENDANCE À SUIVRE"),
    "pièges retail": content.count("PIÈGE RETAIL"),
    "projection ICT": content.count("projL1") + content.count("showProjection"),
    "points pivots ●": content.count('"●"'),
    "pointe ▲/▼": content.count('tipChar'),
    "jambes retracement atténuées": content.count("isRetraceLeg"),
    "légende des couleurs": content.count("LÉGENDE DES COULEURS"),
    "scénario ANTICIPATION": content.count("ANTICIPATION (ICT)"),
    "confluences (checklist)": content.count("cfScore"),
    "boucles gardées (int sz = array.size)": content.count("int sz = array.size("),
    "obUseBody (OB sur corps)": content.count("obUseBody ?"),
    "f_create_breaker (breaker conforme)": content.count("f_create_breaker("),
    "f_create_mitigation (blocs mitigation)": content.count("f_create_mitigation("),
    "MSS conditionnel (hasDisp)": content.count('hasDisp ? "MSS"'),
    "OTE (61.8/78.6)": content.count("0.618") + content.count("0.786"),
    "PDH/PDL refs": content.count("PDH"),
    "sweep volume +V": content.count('"+V"'),
    "confluences OB tags": content.count("+FVG") + content.count("+SWP") + content.count("+VOL"),
    "inversedInvalid (iFVG invalide)": content.count("inversedInvalid := true"),
    "inputs (réglages)": content.count("input."),
}

# 8) Compte des inputs par groupe
input_groups = re.findall(r'group=G_(\w+)', content)
from collections import Counter
grp_counts = Counter(input_groups)

print("=" * 62)
print("VERIFICATION STATIQUE — wavescope_ict_v3.pine")
print("=" * 62)
print(f"Lignes totales : {len(lines)}   Fonctions : {len(func_defs)}")
print(f"Boucles vérifiées : {len(ok)} gardées, {len(issues)} problèmes")
print()

print("--- PROBLEMES (bloquants) ---")
for i in issues:
    print(" ", i)
if not issues:
    print("  Aucun ✓")
print()

print("--- APPELS AVANT DEFINITION ---")
for c in sorted(set(calls_before_def)):
    print(" ", c)
if not calls_before_def:
    print("  Aucun ✓")
print()

print("--- MARQUEURS v3 ---")
for k, v in markers.items():
    print(f"  {k}: {v}")
print()

print(f"--- INPUTS PAR GROUPE ({sum(grp_counts.values())} au total) ---")
for g, c in sorted(grp_counts.items()):
    print(f"  G_{g}: {c}")
print()

print(f"--- AVERTISSEMENTS ({len(warns)}) ---")
for w in warns[:20]:
    print(" ", w)
if len(warns) > 20:
    print(f"  ... et {len(warns)-20} autres")
print()

sys.exit(1 if issues else 0)
