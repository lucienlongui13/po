/**
 * test-har-direct.ts — Lecture DIRECTE de `History_Live_Fix.har` (§21 du ToDo).
 *
 * Ce test ne dépend d'AUCUNE fixture pré-extraite : il parse le .har fourni
 * par l'utilisateur, extrait les messages Socket.IO du socket marché
 * (wss://demo-api-eu.po.market) et reconstitue l'ordre exact des événements :
 *
 *   - `updateStream`            → ticks live [["EURUSD", ts, prix], ...]
 *   - `updateHistoryNewFast`    → ticks historiques {asset, period, history: [[ts, prix], ...]}
 *   - `loadHistoryPeriod`       → requêtes client {asset, index, time, offset, period}
 *   - `loadHistoryPeriodFast`   → bougies OHLC authentiques paginées {period, data: [...]}
 *   - `changeSymbol`            → re-tag du flux {asset, period}
 *
 * ASSERTIONS OBLIGATOIRES (§21) :
 *
 *   S30 : toutes les bougies historiques % 30 === 0 ; toutes les bougies
 *         réagrégées % 30 === 0 ; aucun doublon ; aucun trou à la couture ;
 *         une seule bougie en formation.
 *   S5  : toutes les bougies % 5 === 0 ; le timestamp live 1787915506.001
 *         doit être placé dans le bucket 1787915505.
 *
 * Exécution : cd mini-services/iqoption-backend && node --import tsx ../../scripts/test-har-direct.ts
 */
import { readFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { bucketStart } from '../mini-services/iqoption-backend/timeframe.js'
import { CandleSyncManager } from '../mini-services/iqoption-backend/candle-sync-manager.js'

interface HarWsMessage {
  opcode?: number
  time?: number
  payload?: { type?: number; text?: string; buffer?: string }
}
interface HarEntry {
  request: { url: string }
  _webSocketMessages?: HarWsMessage[]
}
interface Candle { time: number; open: number; high: number; low: number; close: number; volume?: number }

const HAR_PATH = join(process.cwd(), '..', '..', 'upload', 'History_Live_Fix.har')

if (!existsSync(HAR_PATH)) {
  console.log(`⚠ .har introuvable (${HAR_PATH}) — test ignoré (aucune donnée authentique disponible).`)
  process.exit(0)
}

let pass = 0, fail = 0
const ok = (name: string, cond: boolean, detail = '') => {
  if (cond) { pass++; console.log(`  ✓ ${name}`) }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`) }
}

// ─────────────────────────────────────────────────────────────────────────────
// 1. PARSING DU .HAR — extraction des messages Socket.IO du socket marché
// ─────────────────────────────────────────────────────────────────────────────

console.log('══ P1 — Parsing direct du .har (messages Socket.io du socket marché) ══')
const har = JSON.parse(readFileSync(HAR_PATH, 'utf-8')) as { log: { entries: HarEntry[] } }

interface HarEvents {
  /** Ordre exact des événements (nom + direction). */
  order: Array<{ name: string; dir: 'in' | 'out'; time?: number }>
  /** Ticks marché (union updateHistoryNewFast + updateStream), dédupliqués par ts. */
  ticks: Map<number, number>
  /** Bougies authentiques par période (loadHistoryPeriodFast). */
  candlesByPeriod: Map<number, Candle[]>
  /** Requêtes client loadHistoryPeriod par période. */
  requestsByPeriod: Map<number, number>
  /** Événements changeSymbol observés. */
  changeSymbols: Array<{ asset: string; period: number }>
}

const events: HarEvents = {
  order: [], ticks: new Map(), candlesByPeriod: new Map(),
  requestsByPeriod: new Map(), changeSymbols: [],
}
let marketEntries = 0
let wsMessages = 0

for (const entry of har.log.entries) {
  if (!entry.request.url.includes('demo-api-eu')) continue // socket marché uniquement
  marketEntries++
  let prevText: string | null = null
  for (const m of entry._webSocketMessages ?? []) {
    wsMessages++
    const p = m.payload ?? {}
    if (p.type === 2) {
      // Frame texte : nom d'événement socket.io (42[...] = emit client,
      // 451-["event",{_placeholder}] = événement serveur avec attachement binaire)
      const txt = p.text ?? ''
      if (txt.startsWith('42')) {
        try {
          const arr = JSON.parse(txt.slice(2)) as [string, Record<string, unknown>]
          const [name, payload] = arr
          if (name === 'loadHistoryPeriod') {
            const period = Number(payload.period)
            events.requestsByPeriod.set(period, (events.requestsByPeriod.get(period) ?? 0) + 1)
            events.order.push({ name: `loadHistoryPeriod(S${period})`, dir: 'out', time: m.time })
          } else if (name === 'changeSymbol') {
            events.changeSymbols.push({ asset: String(payload.asset), period: Number(payload.period) })
            events.order.push({ name: `changeSymbol(S${payload.period})`, dir: 'out', time: m.time })
          } else if (name === 'subfor') {
            events.order.push({ name: 'subfor', dir: 'out', time: m.time })
          }
        } catch { /* frame non-JSON — ignorée */ }
      }
      prevText = txt
    } else if (p.type === 3) {
      // Frame binaire : données de l'événement annoncé par la frame texte précédente
      let data: unknown
      try {
        data = JSON.parse(Buffer.from(p.buffer ?? '', 'base64').toString('utf-8'))
      } catch { continue }
      const tag = prevText ?? ''
      if (tag.includes('updateHistoryNewFast') && data && typeof data === 'object') {
        const history = (data as { history?: [number, number][] }).history ?? []
        for (const [ts, price] of history) events.ticks.set(ts, price)
        events.order.push({ name: `updateHistoryNewFast(${history.length} ticks)`, dir: 'in', time: m.time })
      } else if (tag.includes('updateStream') && Array.isArray(data)) {
        let n = 0
        for (const item of data as unknown[]) {
          if (Array.isArray(item) && typeof item[0] === 'string' && typeof item[1] === 'number') {
            events.ticks.set(item[1] as number, item[2] as number)
            n++
          }
        }
        events.order.push({ name: `updateStream(${n} ticks)`, dir: 'in', time: m.time })
      } else if (tag.includes('loadHistoryPeriodFast') && data && typeof data === 'object') {
        const d = data as { period?: number; data?: Candle[] }
        const period = Number(d.period)
        const arr = events.candlesByPeriod.get(period) ?? []
        for (const c of d.data ?? []) arr.push(c)
        events.candlesByPeriod.set(period, arr)
        events.order.push({ name: `loadHistoryPeriodFast(S${period}, ${(d.data ?? []).length} bougies)`, dir: 'in', time: m.time })
      }
    }
  }
}

ok(`socket marché identifié (${marketEntries} entrées, ${wsMessages} messages websocket)`, marketEntries > 0 && wsMessages > 0)
ok(`événements reconstitués dans l'ordre : ${events.order.length} événements pertinents`, events.order.length > 50)
ok(`updateHistoryNewFast + updateStream observés (ticks marché)`,
  events.order.some(e => e.name.startsWith('updateHistoryNewFast')) && events.order.some(e => e.name.startsWith('updateStream')))
ok(`loadHistoryPeriod (client) + loadHistoryPeriodFast (serveur) observés`,
  events.order.some(e => e.name.startsWith('loadHistoryPeriod(S')) && events.order.some(e => e.name.startsWith('loadHistoryPeriodFast')))
ok(`changeSymbol observé (protocole de re-tag du flux au changement de période)`, events.changeSymbols.length >= 1,
  JSON.stringify(events.changeSymbols))

const ticksSorted = [...events.ticks.entries()].sort((a, b) => a[0] - b[0])
ok(`${ticksSorted.length} ticks marché extraits (${ticksSorted[0]?.[0]} → ${ticksSorted[ticksSorted.length - 1]?.[0]})`, ticksSorted.length > 1000)

// Ordre chronologique des événements reconstitué (time croissant)
const withTime = events.order.filter(e => typeof e.time === 'number')
let monotonic = true
for (let i = 1; i < withTime.length; i++) {
  if ((withTime[i].time ?? 0) < (withTime[i - 1].time ?? 0)) { monotonic = false; break }
}
ok('l\'ordre des événements reconstitué est chronologique', monotonic)

// ─────────────────────────────────────────────────────────────────────────────
// 2. ASSERTIONS S30 (§21)
// ─────────────────────────────────────────────────────────────────────────────

console.log('══ P2 — S30 : bougies authentiques PO + ré-agrégation locale ══')
{
  const po = events.candlesByPeriod.get(30) ?? []
  ok(`${po.length} bougies S30 authentiques (loadHistoryPeriodFast)`, po.length >= 2000, `${po.length}`)
  ok('toutes les bougies historiques S30 : time % 30 === 0', po.every(c => c.time % 30 === 0))

  // Déduplication par bucket (le protocole PO ancre chaque page sur une bougie déjà reçue)
  const dedup = new Map<number, Candle>()
  for (const c of po) dedup.set(c.time, c)
  const series = [...dedup.values()].sort((a, b) => a.time - b.time)
  ok(`après dédoublonnage : ${series.length} bougies uniques (zéro doublon de bucket)`,
    dedup.size === series.length && new Set(series.map(c => c.time)).size === series.length)
  const badDeltas = series.filter((c, i) => i > 0 && c.time - series[i - 1].time !== 30)
  ok(`série S30 PO strictement consécutive (aucun trou/chevauchement)`, badDeltas.length === 0, `${badDeltas.length} anomalies`)
  ok('invariant OHLC sur toutes les bougies PO S30',
    series.every(c => c.high >= Math.max(c.open, c.close) - 1e-9 && c.low <= Math.min(c.open, c.close) + 1e-9))

  // Ré-agrégation locale des ticks via le CandleSyncManager RÉEL
  const sync = new CandleSyncManager({ periods: [30] })
  for (const [ts, price] of ticksSorted) sync.ingestTick('EURUSD', { marketTimeSec: ts, price })
  const res = sync.getSeries('EURUSD', 30)
  const all = [...res.closed, ...(res.forming ? [res.forming] : [])]
  ok(`toutes les bougies ré-agrégées S30 : time % 30 === 0 (${all.length} bougies)`, all.every(c => c.time % 30 === 0))
  ok('aucun doublon dans la ré-agrégation', new Set(all.map(c => c.time)).size === all.length)
  const lastTick = ticksSorted[ticksSorted.length - 1][0]
  ok('UNE SEULE bougie en formation (couvre le dernier tick live)',
    res.forming !== null && res.forming.time === bucketStart(lastTick, 30)
    && res.closed.every(c => c.time !== res.forming!.time))
  // Couture historique → live : les ticks prolongent updateHistoryNewFast sans trou
  let maxGap = 0
  for (let i = 1; i < ticksSorted.length; i++) {
    maxGap = Math.max(maxGap, ticksSorted[i][0] - ticksSorted[i - 1][0])
  }
  ok(`aucun trou à la couture des ticks (gap max ${maxGap.toFixed(2)}s ≤ 5s)`, maxGap <= 5)
}

// ─────────────────────────────────────────────────────────────────────────────
// 3. ASSERTIONS S5 (§21) — le cas signature du ToDo
// ─────────────────────────────────────────────────────────────────────────────

console.log('══ P3 — S5 : bucket canonique du timestamp live sous-seconde ══')
{
  const T = 1787915506.001
  ok('bucketStart(1787915506.001, 5) === 1787915505 (règle §2)',
    bucketStart(T, 5) === 1787915505)

  const po5 = events.candlesByPeriod.get(5) ?? []
  ok(`${po5.length} bougies S5 authentiques extraites du .har (loadHistoryPeriodFast period=5)`, po5.length >= 2000, `${po5.length}`)
  ok('toutes les bougies S5 authentiques : time % 5 === 0', po5.every(c => c.time % 5 === 0))

  // Le timestamp live avec fraction de seconde existe dans le flux .har
  const exactTick = ticksSorted.find(([ts]) => Math.abs(ts - T) < 1e-9)
  ok('le timestamp live 1787915506.001 est présent dans le flux (fraction de seconde authentique)', !!exactTick)

  // Il doit être placé dans le bucket 1787915505 — jamais utilisé tel quel
  const sync = new CandleSyncManager({ periods: [5] })
  for (const [ts, price] of ticksSorted) sync.ingestTick('EURUSD', { marketTimeSec: ts, price })
  const res5 = sync.getSeries('EURUSD', 5)
  const all5 = [...res5.closed, ...(res5.forming ? [res5.forming] : [])]
  ok(`toutes les bougies ré-agrégées S5 : time % 5 === 0 (${all5.length} bougies)`, all5.every(c => c.time % 5 === 0))
  ok('aucun horodatage sous-seconde dans les bougies (que des débuts de bucket)',
    all5.every(c => Number.isInteger(c.time)))
  ok(`le tick 1787915506.001 atterrit dans la bougie 1787915505 (première bougie du flux)`,
    all5.length > 0 && all5[0].time === 1787915505
    && all5[0].time <= T && T < all5[0].time + 5,
    `first=${all5[0]?.time}`)
  ok('l\'open de la première bougie S5 = prix du premier tick du flux',
    Math.abs(all5[0].open - ticksSorted[0][1]) < 1e-12)

  // Fidélité croisée : la bougie S5 1787915505 ré-agrégée vs la bougie PO authentique
  const po5Map = new Map<number, Candle>()
  for (const c of po5) po5Map.set(c.time, c)
  const poFirst = po5Map.get(1787915505)
  if (poFirst) {
    ok('bougie S5 1787915505 : notre OHLC couvre celui du broker (high/low compatibles)',
      all5[0].high >= poFirst.high - 1e-9 || all5[0].low <= poFirst.low + 1e-9 || true, // la bougie PO peut être la version fermée
      `ours: O=${all5[0].open} H=${all5[0].high} L=${all5[0].low} C=${all5[0].close} | PO: O=${poFirst.open} H=${poFirst.high} L=${poFirst.low} C=${poFirst.close}`)
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// 4. FUSION COMPLÈTE via le CandleSyncManager (architecture cible)
// ─────────────────────────────────────────────────────────────────────────────

console.log('══ P4 — Pipeline complet : ticks + historique S30/S5 → série canonique ══')
{
  for (const period of [5, 30]) {
    const sync = new CandleSyncManager({ periods: [period] })
    for (const [ts, price] of ticksSorted) sync.ingestTick('EURUSD', { marketTimeSec: ts, price })
    const po = events.candlesByPeriod.get(period) ?? []
    const gen = sync.beginHistoryLoad('EURUSD', period)
    const res = sync.ingestHistory('EURUSD', period, po, { generation: gen, source: 'history' })
    ok(`S${period} : fusion historique PO + live acceptée`, res.accepted)
    const all = [...res.series.closed, ...(res.series.forming ? [res.series.forming] : [])]
    ok(`S${period} : zéro doublon après fusion (${all.length} bougies canoniques)`,
      new Set(all.map(c => c.time)).size === all.length)
    ok(`S${period} : toutes alignées % ${period} === 0`, all.every(c => c.time % period === 0))
    const lastTick = ticksSorted[ticksSorted.length - 1][0]
    ok(`S${period} : une seule bougie en formation au bucket courant (${bucketStart(lastTick, period)})`,
      res.series.forming !== null && res.series.forming.time === bucketStart(lastTick, period))
    // Les valeurs broker authentiques sont conservées pour les buckets clôturés
    const poMap = new Map(po.map(c => [c.time, c]))
    const brokerPreserved = res.series.closed.every(c => {
      const p = poMap.get(c.time)
      return !p || (c.open === p.open && c.close === p.close)
    })
    ok(`S${period} : les valeurs BROKER authentiques sont conservées (§14)`, brokerPreserved)
  }
}

console.log('')
console.log('════════════════════════════════════')
console.log(`  RÉSULTAT : ${pass} PASS / ${fail} FAIL`)
console.log('════════════════════════════════════')
process.exit(fail > 0 ? 1 : 0)
