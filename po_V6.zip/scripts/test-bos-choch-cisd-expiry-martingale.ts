/**
 * test-bos-choch-cisd-expiry-martingale.ts — Martingale commune Auto Trade
 * pour BOS, CHoCH & CISD (pack Pine) : chemin RÉEL reproduit de bout en bout.
 * ============================================================================
 *
 * Reproduit EXACTEMENT la chaîne d'exécution réelle d'Auto Trade :
 *
 *   règle BOS → calcul mise (computeBettingAmount) → openOrder → trackedDeals
 *   (clé = UUID d'ouverture) → deal fermé broker (id NUMÉRIQUE ≠ UUID,
 *   publication paresseuse) → rattachement (findTrackedDealByFingerprint)
 *   → applyDealResult → updateBettingAfterResult → prochaine mise.
 *
 * Scénario obligatoire (base = 5) :
 *   5 LOSS → 10 LOSS → 20 LOSS → 40 WIN → 5 WIN → 5 LOSS → 10
 * c'est-à-dire 5 → 10 → 20 → 40 → 5 → 5 → 10, le WIN remettant
 * IMMÉDIATEMENT la série à zéro AVANT le calcul de la mise suivante.
 *
 * Scénario multi-actifs : la victoire EURUSD ne JAMAIS remettre la
 * Martingale XAUUSD à zéro (isolation par asset).
 *
 * Scénario d'attribution : un deal BOS ouvert puis réglé ALORS QUE la
 * stratégie UI a changé — le résultat doit quand même mettre à jour la
 * Martingale de l'asset (le rattachement ne dépend PAS de
 * session.config.strategyId).
 *
 * Scénario fantômes : un deal fermé étranger (prix d'entrée hors marché,
 * montant différent) ne peut JAMAIS régler notre ordre suivi.
 *
 * Exécution : npx tsx scripts/test-bos-choch-cisd-expiry-martingale.ts
 */
import assert from 'node:assert/strict'
import {
  normalizeBosChochCisdOrderRules,
  evaluateBosChochCisdOrderRules,
} from '../shared/bos-choch-cisd.js'
import {
  computeBettingAmount,
  createAssetContext,
  updateBettingAfterResult,
  applyDealResult,
  findTrackedDealByFingerprint,
  MARTINGALE_MULTIPLIER,
} from '../mini-services/iqoption-backend/asset-contexts.js'

let passed = 0
let failed = 0
function check(name: string, cond: boolean, detail = '') {
  if (cond) { passed++; console.log(`  ✓ ${name}`) }
  else { failed++; console.error(`  ✗ ${name}${detail ? ' — ' + detail : ''}`) }
}

/* ══ 1. Expiration : aucune règle sans expiration ne produit d'ordre ══ */
console.log('\n[1] Expiration — règle sans expiration = invalide, aucun fallback')
{
  const empty = normalizeBosChochCisdOrderRules([{ id: 'missing-exp', alerts: ['BOS Up'] }], [])
  check('une règle sans expiration est rejetée — aucun fallback 60s', empty.callRules.length === 0)

  // Expiration choisie par l'utilisateur uniquement.
  const explicit = normalizeBosChochCisdOrderRules(
    [{ id: 'call-15s', alerts: ['BOS Up', 'CISD Up'], expirationSeconds: 15 }], [])
  check("règle CALL avec expiration=15s acceptée, expiration=15", explicit.callRules[0]?.expirationSeconds === 15)
}

/* ══ 2. Chemin RÉEL : 5 → 10 → 20 → 40 → 5 → 5 → 10 ══ */
console.log('\n[2] Chemin réel Auto Trade/BOS — base 5 : 5 → 10 → 20 → 40 → 5 → 5 → 10')
{
  const ctx = createAssetContext('EURUSD_otc', { baseAmount: 5 })
  ctx.bettingStrategy = 'martingale'

  // La séquence de résultats broker (comme deal_closed la livre).
  const outcomes: Array<'WIN' | 'LOSS'> = ['LOSS', 'LOSS', 'LOSS', 'WIN', 'WIN', 'LOSS']
  const expected = [5, 10, 20, 40, 5, 5, 10]

  const placed: number[] = [computeBettingAmount(ctx)] // mise AVANT le trade #1
  let orderSeq = 0
  for (const outcome of outcomes) {
    // --- openOrder (UUID) ---
    const orderUuid = `uuid-open-${++orderSeq}`
    const fill = 1.18543 + orderSeq * 0.00001
    const openTime = 1_789_000_000 + orderSeq * 60
    const expiry = 15 // expiration de LA RÈGLE (jamais le champ global)
    ctx.trackedDeals.set(orderUuid, {
      asset: ctx.asset,
      amount: computeBettingAmount(ctx),
      expirationSeconds: expiry,
      openPrice: fill,
      openTime,
      action: 'call',
    })

    // --- deal fermé broker : id NUMÉRIQUE ≠ UUID d'ouverture ---
    const closedId = 900_000 + orderSeq
    const isWin = outcome === 'WIN'
    const match = findTrackedDealByFingerprint(ctx, {
      id: closedId,
      asset: ctx.asset,
      amount: computeBettingAmount(ctx),
      openPrice: fill,
      closePrice: isWin ? fill + 0.00021 : fill - 0.00019,
      openTime,
      closeTime: openTime + expiry,
      profit: isWin ? 3.6 : -computeBettingAmount(ctx),
      isWin,
    })
    check(`trade #${orderSeq} : règlement (id numérique ${closedId}) rattaché à l'ordre suivi ${orderUuid}`,
      match?.key === orderUuid, match ? `rattaché à ${match.key}` : 'AUCUN rattachement')

    // --- applyDealResult sur la clé RATTACHÉE (pas l'id broker) ---
    const res = applyDealResult(ctx, match!.key, isWin)
    check(`trade #${orderSeq} (${outcome}) : applyDealResult applique le résultat`, res != null)
    check(`trade #${orderSeq} (${outcome}) : prochaine mise = ${expected[orderSeq]}`,
      computeBettingAmount(ctx) === expected[orderSeq],
      `obtenu ${computeBettingAmount(ctx)}`)
    placed.push(computeBettingAmount(ctx))
  }

  console.log(`  mises successives : ${placed.join(' → ')}`)
  check('SÉQUENCE OBLIGATOIRE 5 → 10 → 20 → 40 → 5 → 5 → 10',
    placed.join(',') === '5,10,20,40,5,5,10', placed.join(','))
}

/* ══ 3. Isolation multi-actifs ══ */
console.log('\n[3] Isolation multi-actifs — la victoire EURUSD ne touche pas XAUUSD')
{
  const eur = createAssetContext('EURUSD_otc', { baseAmount: 5 })
  const xau = createAssetContext('XAUUSD_otc', { baseAmount: 5 })
  eur.bettingStrategy = 'martingale'
  xau.bettingStrategy = 'martingale'

  // EURUSD : 5 → LOSS → 10 → LOSS → 20 → WIN → 5
  for (const [i, win] of [false, false, true].entries()) {
    const uuid = `eur-${i}`
    const fill = 1.1010
    const openTime = 1_789_000_000 + i * 60
    eur.trackedDeals.set(uuid, { asset: eur.asset, amount: computeBettingAmount(eur), expirationSeconds: 30, openPrice: fill, openTime, action: 'call' })
    const m = findTrackedDealByFingerprint(eur, {
      id: 700_000 + i, asset: eur.asset, amount: computeBettingAmount(eur), openPrice: fill,
      closePrice: fill + (win ? 0.0003 : -0.0003), openTime, closeTime: openTime + 30,
      profit: win ? 4.4 : -computeBettingAmount(eur), isWin: win,
    })
    assert.ok(m, `rattachement EURUSD #${i}`)
    applyDealResult(eur, m.key, win)
  }
  check('EURUSD après WIN → mise de base 5', computeBettingAmount(eur) === 5, `obtenu ${computeBettingAmount(eur)}`)
  check('EURUSD consecutiveLosses = 0', eur.betting.consecutiveLosses === 0)

  // XAUUSD : 5 → LOSS → 10 (la victoire EURUSD ne l'a PAS touché)
  check('XAUUSD intact après la victoire EURUSD (mise 5, streak 0)',
    computeBettingAmount(xau) === 5 && xau.betting.consecutiveLosses === 0)
  {
    const uuid = 'xau-0'
    const fill = 2351.20
    const openTime = 1_789_000_500
    xau.trackedDeals.set(uuid, { asset: xau.asset, amount: 5, expirationSeconds: 60, openPrice: fill, openTime, action: 'put' })
    const m = findTrackedDealByFingerprint(xau, {
      id: 800_001, asset: xau.asset, amount: 5, openPrice: fill,
      closePrice: fill + 0.35, openTime, closeTime: openTime + 60, profit: -5, isWin: false,
    })
    assert.ok(m, 'rattachement XAUUSD')
    applyDealResult(xau, m.key, false)
  }
  check('XAUUSD après LOSS → mise 10 (Martingale isolée par asset)',
    computeBettingAmount(xau) === 10, `obtenu ${computeBettingAmount(xau)}`)
  check('EURUSD toujours à 5 pendant ce temps', computeBettingAmount(eur) === 5)
}

/* ══ 4. Attribution : changement de stratégie UI pendant le deal ══ */
console.log('\n[4] Attribution — le deal BOS réglé après un changement de stratégie UI')
{
  // Le deal a été ouvert sous BOS ; à la clôture, l'UI est passée sur WinWin.
  // Le rattachement par empreinte ne dépend NI de session.config.strategyId,
  // NI de la stratégie du moment — uniquement du deal réellement placé.
  const ctx = createAssetContext('EURUSD_otc', { baseAmount: 5 })
  ctx.bettingStrategy = 'martingale'
  ctx.betting.consecutiveLosses = 3 // 40 en cours

  const orderUuid = 'uuid-bos-ouvert-sous-bos'
  const fill = 1.18222
  const openTime = 1_789_001_000
  ctx.trackedDeals.set(orderUuid, {
    asset: ctx.asset, amount: 40, expirationSeconds: 20,
    openPrice: fill, openTime, action: 'put',
  })

  // L'UI est maintenant sur WinWin — le deal fermé arrive quand même.
  const strategyIdAtClose = 'removed_strategy' // ≠ 'l_lucien_protrader' (inconnu → l'attribution ne dépend PAS du strategyId)
  const m = findTrackedDealByFingerprint(ctx, {
    id: 666_001, asset: ctx.asset, amount: 40, openPrice: fill,
    closePrice: fill - 0.00042, openTime, closeTime: openTime + 20,
    profit: 36.8, isWin: true,
  })
  check(`deal L_Lucien ProTrader rattaché même si strategyId='${strategyIdAtClose}' à la clôture`,
    m?.key === orderUuid)
  const res = m ? applyDealResult(ctx, m.key, true) : null
  check('WIN appliqué → consecutiveLosses = 0', res != null && ctx.betting.consecutiveLosses === 0)
  check('prochaine mise = mise initiale 5', computeBettingAmount(ctx) === 5)
}

/* ══ 5. Fantômes : un deal fermé étranger ne règle jamais notre ordre ══ */
console.log('\n[5] Fantômes du cache broker — rejet garantis')
{
  const ctx = createAssetContext('EURUSD_otc', { baseAmount: 5 })
  ctx.bettingStrategy = 'martingale'
  ctx.trackedDeals.set('uuid-notre-ordre', {
    asset: ctx.asset, amount: 10, expirationSeconds: 15,
    openPrice: 1.18500, openTime: 1_789_002_000, action: 'call',
  })

  // Fantôme A (type 5ed07a66 du JSONL réel) : entrée 15 pips hors marché,
  // SANS closeTime ni openTime, faux WIN +0.78.
  const ghostA = findTrackedDealByFingerprint(ctx, {
    id: '5ed07a66-ghost', asset: ctx.asset, amount: 1, openPrice: 1.18650,
    closePrice: 1.18630, openTime: 0, closeTime: 0, profit: 0.78, isWin: true,
  })
  check('fantôme A (entrée hors marché, sans horodatages) REJETÉ', ghostA == null)

  // Fantôme B (type 38095056) : horodatages frais mais entrée 8 pips hors
  // marché, montant différent.
  const ghostB = findTrackedDealByFingerprint(ctx, {
    id: '38095056-ghost', asset: ctx.asset, amount: 1, openPrice: 1.18420,
    closePrice: 1.18421, openTime: 1_789_002_010, closeTime: 1_789_002_019,
    profit: -1, isWin: false,
  })
  check('fantôme B (entrée 8 pips off, montant 1) REJETÉ', ghostB == null)

  // Un deal d'un AUTRE asset ne peut jamais régler notre ordre.
  const foreignAsset = findTrackedDealByFingerprint(ctx, {
    id: 123, asset: 'XAUUSD_otc', amount: 10, openPrice: 1.18500,
    closePrice: 1.18521, openTime: 1_789_002_000, closeTime: 1_789_002_015,
    profit: 9.2, isWin: true,
  })
  check('deal d\'un autre asset REJETÉ (isolation §17)', foreignAsset == null)

  // Notre VRAI règlement (id numérique ≠ UUID) est bien rattaché.
  const real = findTrackedDealByFingerprint(ctx, {
    id: 900_777, asset: ctx.asset, amount: 10, openPrice: 1.18500,
    closePrice: 1.18522, openTime: 1_789_002_000, closeTime: 1_789_002_015,
    profit: 9.2, isWin: true,
  })
  check('le VRAI règlement (id numérique ≠ UUID) est rattaché', real?.key === 'uuid-notre-ordre')
}

/* ══ 6. Règle BOS → expiration propre uniquement ══ */
console.log('\n[6] Règles BOS — expiration explicite de la règle uniquement')
{
  let t = 1_700_000_000
  const mk = (open: number, close: number, high: number, low: number) => {
    t += 60
    return { open, close, high, low, volume: 100, time: t }
  }
  const candles = [
    mk(10, 10.8, 11, 9.9),
    mk(10.8, 10.2, 12, 10.1),
    mk(10.2, 10.9, 11.1, 10),
    mk(10.9, 10.4, 11.2, 10.2),
    mk(10.4, 10.6, 10.7, 10.3),
    mk(10.6, 12.5, 12.6, 10.5), // cassure → BOS Up + CISD Up
  ]
  const sig = evaluateBosChochCisdOrderRules(
    candles,
    [{ id: 'call-bos-cisd-15s', alerts: ['BOS Up', 'CISD Up'], expirationSeconds: 15 }],
    [{ id: 'put-mixed', alerts: ['BOS Up', 'CISD Up', 'CHoCH Down'], expirationSeconds: 20 }],
  )
  check('règle CALL 15s correspond', sig.action === 'CALL' && sig.matchedRuleId === 'call-bos-cisd-15s')
  check('expiration de l\'ordre = 15s (celle de la règle, jamais le champ global)', sig.expirationSeconds === 15)
  // Aucune règle → HOLD, aucune expiration injectée.
  const noRule = evaluateBosChochCisdOrderRules(candles, [], [])
  check('aucune règle → HOLD sans expiration', noRule.action === 'HOLD' && noRule.expirationSeconds == null)
}

/* ══ 7. Martingale pure (règle §4) ══ */
console.log('\n[7] Règle Martingale stricte (×2 par perte, reset au WIN)')
{
  const ctx = createAssetContext('TEST_otc', { baseAmount: 5 })
  ctx.bettingStrategy = 'martingale'
  const seq: number[] = [computeBettingAmount(ctx)]
  for (let i = 0; i < 4; i++) { updateBettingAfterResult(ctx, false); seq.push(computeBettingAmount(ctx)) }
  check('streak 0..4 → 5,10,20,40,80', seq.join(',') === '5,10,20,40,80', seq.join(','))
  updateBettingAfterResult(ctx, true)
  check('WIN après 4 pertes → retour immédiat à la base 5', computeBettingAmount(ctx) === 5)
  check('WIN → WIN → WIN reste à 5 (pas de montée fantôme)',
    (updateBettingAfterResult(ctx, true), updateBettingAfterResult(ctx, true), computeBettingAmount(ctx) === 5))
}

console.log(`\n═══ RÉSULTAT : ${passed} ✓ · ${failed} ✗ ═══`)
process.exit(failed > 0 ? 1 : 0)
