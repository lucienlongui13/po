#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v19.sh — Livraison v19 « Confirmation bougie précédente
# + garde-fou Martingale »
#
# Le besoin (message utilisateur) :
#   1. SWITCH « CONFIRMATION BOUGIE PRÉCÉDENTE » dans la stratégie
#      L_Lucien ProTrader (Auto Trade) :
#        - toutes combinaisons CALL ▲ (BOS Up, CHoCH Up, CISD Up) : si le
#          switch est ON, la bougie PRÉCÉDANT la bougie signalée doit être
#          BAISSIÈRE (close < open) comme confirmation avant de lancer
#          l'ordre ;
#        - toutes combinaisons PUT ▼ (BOS Down, CHoCH Down, CISD Down) :
#          si le switch est ON, elle doit être HAUSSIÈRE (close > open).
#   2. GARDE-FOU DE GESTION DES RISQUES DES MISES : règle utilisateur du
#      nombre MAXIMAL de fois que la Martingale peut être appliquée.
#      Ex. valeur 5 : au plus 5 doublements de mise ; si l'ordre du 5e
#      doublement ne rapporte pas de gain → RETOUR À LA MISE INITIALE.
#
# Les correctifs v19 :
#   1. CONFIRMATION — moteur partagé (shared/bos-choch-cisd.ts) :
#      ConfirmPreviousCandleOptions { confirmPreviousCandle } câblé dans
#      evaluateBosChochCisdOrderRules (chemin règles CALL/PUT) ET
#      evaluateBosChochCisd (chemin toggles) ; helpers isBearishCandle /
#      isBullishCandle / checkPreviousCandleConfirmation (doji = NEUTRE,
#      1re bougie = refus) ; reason explicite « REFUSÉ par la confirmation
#      de bougie » (visible dans Latest signal du panneau) ; le signal
#      confirmé porte « confirmé par la bougie précédente ». Wrapper
#      backend evaluateBosChochCisdStrategy : 5e paramètre options.
#      Config socket : bosChochCisdConfirmCandle (set-auto-config),
#      DÉFAUT OFF — comportement inchangé tant que le switch n'est pas
#      activé. Front : switch dédié dans le bloc L_Lucien ProTrader du
#      panneau Auto Trade (role=switch, aria-checked, état synchronisé
#      du backend via auto-trade-status).
#   2. GARDE-FOU MARTINGALE — asset-contexts.ts :
#      AssetBettingState.maxMartingaleSteps (0 = illimité, comportement
#      historique ; clamp [0, 1000] via clampMaxMartingaleSteps) ;
#      updateBettingAfterResult : une perte au niveau MAX reset
#      consecutiveLosses → RETOUR À LA MISE INITIALE ; computeBettingAmount
#      clampe le nombre de doublements (ceinture+bretelles) ; Fibonacci
#      (fibIndex) et Fixed NON affectés ; TIE/PUSH toujours neutre (v17) ;
#      isolation par asset conservée. Config socket : maxMartingaleSteps
#      (set-auto-config + set-config), propagé aux 5 sites
#      ensureAssetContext + set-auto-strategy + restauration de session ;
#      persisté (session-persistence.ts, clampé au rechargement) ; exposé
#      par auto-trade-status (racine + PAR ASSET). Front : champ
#      « Martingale max — doublements » (visible en mode Martingale,
#      0 = illimité, mise max affichée) + badge « · max N » sur les pertes
#      consécutives.
#
# Validation : tsc root 0 erreur · tsc backend 0 erreur · tsc SDK 0
# erreur · build Next.js PASS (6/6 pages) · confirm-candle-cap (unitaire)
# 56 ✓ / 0 ✗ · confirm-candle-cap-e2e (vrai backend + faux broker, chemins
# réels successcloseOrder) 24/24 ✓ — Phase A mises 1→2→4→1→2 (cap 2, retour
# à la mise initiale) · Phase B switch ON → 0 ordre + reason REFUSÉ, OFF →
# CALL repart, ON → re-blocage · multi-assets 134 ✓ · v63-features 71 ✓ ·
# v63-intégration 14 ✓ · bos-strategy 22 ✓ · martingale-streak 12 ✓ ·
# bos-expiry-martingale 39 ✓ · bos-martingale-e2e 17/17 ✓ · tie-refund-e2e
# 24/24 ✓ · bos-multi-e2e (daemon, voir worklog).
#
# Sortie : /home/z/my-project/download/pine_v6_engine_v19_confirm_candle_martingale_cap.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v19"
FOLDER=pine_v6_engine
OUT="$ROOT/download/pine_v6_engine_v19_confirm_candle_martingale_cap.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (structure identique aux zips v15-v18) ───────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude '.logs/' \
  --exclude '*.log' \
  --exclude 'winwinlogs.jsonl' \
  --exclude 'mini-services/iqoption-backend/data/backend-session.json' \
  --exclude 'mini-services/iqoption-backend/data/candle-cache/' \
  --exclude 'mini-services/iqoption-backend/e2e-*.log' \
  --exclude 'db/' \
  "$ROOT/pine_v6_engine/" "$STAGE/$FOLDER/"

# ── README de la version v19 ─────────────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.6-V19-CONFIRM-CANDLE-MARTINGALE-CAP.md" <<'EOF'
# Pine v6 Engine — v19 « L_Lucien ProTrader » : confirmation par bougie précédente + garde-fou Martingale

## 1. Switch « Confirmation bougie précédente » (Auto Trade → L_Lucien ProTrader)

Un **switch ON/OFF** dans le bloc L_Lucien ProTrader du panneau Auto
Trade active un **filtre de confirmation** sur TOUS les signaux avant le
lancement d'un ordre :

| Direction | Signaux concernés | Confirmation exigée (switch ON) |
|---|---|---|
| **CALL ▲** | BOS Up · CHoCH Up · CISD Up | la bougie **précédant** la bougie signalée doit être **BAISSIÈRE** (close < open) |
| **PUT ▼** | BOS Down · CHoCH Down · CISD Down | la bougie **précédant** la bougie signalée doit être **HAUSSIÈRE** (close > open) |

- **Désactivé par défaut** : tant que le switch est OFF, le comportement
  est strictement identique aux versions précédentes (aucun filtre) ;
- une **doji** (close === open) est neutre : elle ne confirme ni un CALL
  ni un PUT ;
- s'il n'y a pas de bougie précédente (première bougie de la série), la
  confirmation est refusée ;
- quand la confirmation refuse un signal, **aucun ordre n'est lancé** et
  la raison est visible dans « Latest signal » du panneau :
  `signal CALL ▲ (BOS Up) REFUSÉ par la confirmation de bougie — bougie
  précédente haussière (…) — CALL ▲ exige une bougie baissière` ;
- la confirmation s'applique au **chemin règles CALL/PUT** (combinaisons
  d'alertes du panneau) comme au **chemin toggles** (moteur du pack) ;
- la règle QUI a produit le signal, son expiration et la garde
  un-ordre-par-bougie restent inchangées ; la bougie refusée n'est pas
  consommée ;
- le switch voyage par la config socket (`set-auto-config` →
  `bosChochCisdConfirmCandle`), est exposé dans `auto-trade-status`,
  **persisté** avec la session et restauré au redémarrage du backend.

## 2. Garde-fou Martingale — nombre maximal de doublements

Une règle de **gestion des risques** permet à l'utilisateur de limiter
le nombre de fois que la Martingale double la mise :

- champ **« Martingale max — doublements »** du panneau Auto Trade
  (visible lorsque la stratégie de mise est **Martingale**) ;
- **0 = illimité** (comportement historique) ; valeur de 1 à 1000 ;
- exemple (spécification utilisateur, valeur **5**, base 1 $) :
  `1 → 2 → 4 → 8 → 16 → 32` (5 doublements maximum) ; **si l'ordre de
  32 $ perd → RETOUR À LA MISE INITIALE (1 $)** au lieu de 64 $ ;
- l'état est **isolé par asset** (une perte EURUSD ne touche jamais
  XAUUSD), comme toute la suite de mises ;
- un **gain** réinitialise toujours à la mise de base ; un **Tie/Refund**
  (P&L = 0 $, v17) reste un état neutre qui conserve le niveau courant ;
- **Fibonacci** (pilotée par fibIndex) et **Fixed** ne sont pas affectées
  par cette règle ;
- le cap est appliqué à TOUS les contextes d'assets, persisté avec la
  session, restauré au redémarrage, et exposé dans `auto-trade-status`
  (racine + entrée par asset) ;
- le panneau affiche la mise maximale résultante
  (base × 2^cap) et un badge « · max N » à côté des pertes consécutives.

## Où se trouvent les réglages dans l'UI

1. **Panneau Auto Trade** → bloc « L_Lucien ProTrader » :
   - « Tags & labels sur le graphique » (v18, défaut OFF) ;
   - **« Confirmation bougie précédente »** (v19, défaut OFF) ;
   - combinaisons CALL ▲ / PUT ▼ (alertes + expiration par règle) ;
2. **Panneau Auto Trade** → « Stake strategy : Martingale » :
   - **« Martingale max — doublements »** (0 = illimité).

## Validation (toutes exécutées sur cette livraison)

| Vérification | Résultat |
|---|---|
| `tsc --noEmit` (root / backend / SDK) | 0 erreur |
| `next build` | PASS — 6/6 pages |
| `scripts/test-confirm-candle-cap.ts` (unitaire : helpers, 2 chemins, wrapper, cap, doji, isolation, Fibonacci, clamp) | 56 ✓ / 0 ✗ |
| `tests/test-confirm-candle-cap-e2e.mjs` (vrai backend + faux broker, règlements temps réel) | 24/24 ✓ |
| — Phase A : Martingale cap 2, 5 pertes | mises `1→2→4→1→2` (retour à la mise initiale) |
| — Phase B : switch ON | 0 ordre, reason « REFUSÉ par la confirmation de bougie » |
| — Phase B : switch OFF | ordre CALL ▲ relancé immédiatement |
| — Phase B : switch ON (re) | plus aucun ordre |
| `tests/test-multi-assets.ts` | 134 OK / 0 échec |
| `tests/test-v63-features.ts` | 71 OK / 0 échec |
| `tests/test-v63-integration.ts` | 14 OK / 0 échec |
| `tests/test-bos-choch-cisd-strategy.ts` | 22 ✓ / 0 ✗ |
| `scripts/test-martingale-streak.ts` | 12 ✓ / 0 ✗ |
| `scripts/test-bos-choch-cisd-expiry-martingale.ts` | 39 ✓ / 0 ✗ |
| `tests/test-bos-choch-cisd-martingale-e2e.mjs` | 17/17 ✓ |
| `tests/test-martingale-tie-refund-e2e.mjs` | 24/24 ✓ |
| `tests/test-bos-choch-cisd-multi-e2e.mjs` (2 assets) | 20/20 ✓ |

## Comment re-vérifier vous-même

```bash
# 1. Installer et démarrer
npm install && cd mini-services/iqoption-backend && npm install

# 2. Typecheck + build
cd ../.. && npx tsc --noEmit && npx next build

# 3. Nouveautés v19
npx tsx scripts/test-confirm-candle-cap.ts        # 56 ✓
cd mini-services/iqoption-backend
node tests/test-confirm-candle-cap-e2e.mjs        # 24/24

# 4. Non-régression
node --import tsx tests/test-multi-assets.ts     # 134 ✓
node --import tsx tests/test-v63-features.ts     # 71 ✓
node tests/test-bos-choch-cisd-martingale-e2e.mjs # 17/17
node tests/test-martingale-tie-refund-e2e.mjs      # 24/24
```

Dans l'application : panneau Auto Trade → bloc L_Lucien ProTrader →
activer « Confirmation bougie précédente » ; choisir « Martingale » dans
Stake strategy et régler « Martingale max — doublements » (ex. 2) ;
observer « Latest signal » : un signal refusé par la confirmation y
explique la raison, et la « Prochaine stake » retombe à la mise de base
après la perte au niveau maximal.
EOF

# ── Zippage ───────────────────────────────────────────────────────────────
cd "$STAGE"
zip -qr "$OUT" "$FOLDER"
cd "$ROOT"
rm -rf "$STAGE"

echo "─ Livraison v19 ─────────────────────────────────────────────"
echo "Zip      : $OUT"
echo "Taille   : $(du -h "$OUT" | cut -f1)"
echo "Fichiers : $(unzip -l "$OUT" | tail -1 | awk '{print $2}')"
echo "Intégrité: $(unzip -t "$OUT" > /dev/null && echo OK || echo ÉCHEC)"
