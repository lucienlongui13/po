/**
 * test-sync-socket.ts — Validation INTÉGRATION RÉELLE du CandleSyncManager
 * contre le backend live (login Pocket Option démo + flux live).
 *
 * Vérifie :
 *   1. get-sync-report → rapport complet par timeframe (machine d'état,
 *      génération, plages, recouvrement, compteurs de ticks) ;
 *   2. Changement de timeframe LIVE (set-config) → série S60 consécutive,
 *      alignée, une seule formation, puis RETOUR S30 — sans saut ;
 *   3. La bougie en formation du timeframe actif progresse avec les ticks ;
 *   4. Invariants de la série canonique reçue par le frontend.
 */
import { io, type Socket } from 'socket.io-client';

const URL = 'http://localhost:3030';
let passed = 0, failed = 0;
function check(name: string, cond: boolean, extra?: string): void {
  if (cond) { passed++; console.log(`  ✓ ${name}`); }
  else { failed++; console.log(`  ✗ ${name}${extra ? ' — ' + extra : ''}`); }
}
function wait(ms: number): Promise<void> { return new Promise((r) => setTimeout(r, ms)); }

interface Candle { time: number; open: number; high: number; low: number; close: number; volume?: number }

async function main(): Promise<void> {
  const socket: Socket = io(URL, { transports: ['websocket'] });

  let syncReport: any = null;
  let lastHistory: { key: string; candles: Candle[] } | null = null;
  // FIX (audit v6.5) — TS ne suit pas les réaffectations faites dans les
  // callbacks socket : le CFA rétrécissait lastHistory à `null` puis `never`
  // (accès .key/.candles impossibles). Un snapshot via fonction réinitialise
  // l'analyse au type déclaré.
  const lastHistorySnapshot = (): { key: string; candles: Candle[] } | null => lastHistory;
  const candleUpdates: Candle[] = [];
  let activeSize = 30;

  socket.on('sync-report', (r: any) => { syncReport = r; });
  socket.on('candles-history', (h: any) => { lastHistory = h; });
  socket.on('candle', (c: any) => {
    if (c.size === activeSize) candleUpdates.push(c);
  });
  socket.on('log', (l: any) => {
    if (String(l.message).includes('[SYNC]')) console.log(`    [backend] ${l.message.slice(0, 130)}`);
  });

  await wait(800);
  socket.emit('login', { email: process.env.PO_EMAIL ?? 'longuilcn@gmail.com', password: process.env.PO_PASSWORD ?? 'Jean-Paul@#1964', mode: 'demo' });
  console.log('── Login + flux live (attente historique) ──');
  await wait(20000);

  console.log('── 1. Rapport de synchronisation (get-sync-report) ──');
  socket.emit('get-sync-report', {});
  await wait(1500);
  check('sync-report reçu', syncReport != null);
  if (syncReport) {
    check('rapport : latestMarketTimeSec > 0 (temps marché vivant)', syncReport.latestMarketTimeSec > 0);
    check('rapport : rapports par timeframe présents', Array.isArray(syncReport.reports) && syncReport.reports.length >= 1);
    const active = (syncReport.reports as any[]).find((r: any) => r.periodSec === syncReport.activePeriod);
    check(`timeframe actif S${syncReport.activePeriod} présent dans le rapport`, !!active);
    if (active) {
      console.log(`    ℹ S${active.periodSec}: état=${active.state} clôturées=${active.closedCount} ` +
        `formation=${active.formingBucket} ticks buffer=${active.tickBufferCount} ` +
        `gaps=${active.gaps?.length ?? 0} lateTicks=${active.builderStats?.lateTickDropped ?? 0}`);
      check('état de synchronisation cohérent (SYNCED/GAP_DETECTED/…)', typeof active.state === 'string');
      check('builderStats présents (compteurs de ticks)', active.builderStats != null);
      check('historique OU ticks présents (série non vide)',
        (active.closedCount ?? 0) + (active.formingBucket ? 1 : 0) > 0);
    }
    check('100 derniers événements [SYNC] exposés', Array.isArray(syncReport.recentEvents));
  }

  console.log('── 2. Changement de timeframe LIVE : S30 → S60 ──');
  activeSize = 60;
  socket.emit('set-config', { candleSize: 60 });
  await wait(6000);
  check('candles-history reçu après le switch S60', lastHistorySnapshot() != null && lastHistorySnapshot()!.key.endsWith(':60'));
  const hist60 = lastHistorySnapshot();
  if (hist60 && hist60.key.endsWith(':60')) {
    const candles = hist60.candles;
    check(`série S60 reçue (${candles.length} bougies)`, candles.length > 0);
    check('toutes alignées % 60 === 0', candles.every(c => c.time % 60 === 0));
    check('zéro doublon de timestamp', new Set(candles.map(c => c.time)).size === candles.length);
    // Rapport APRÈS le switch (l'état de synchronisation documente les trous
    // réels du marché — couture historique ↔ live comprise).
    socket.emit('get-sync-report', { period: 60 });
    await wait(1200);
    const r60 = syncReport?.reports?.[0];
    const documentedGaps = r60?.gaps?.length ?? 0;
    const badDeltas = candles.filter((c, i) => i > 0 && c.time - candles[i - 1].time !== 60);
    check(`série consécutive ou trous DOCUMENTÉS dans le rapport (${badDeltas.length} deltas anormaux / ${documentedGaps} trous documentés)`,
      badDeltas.length === 0 || badDeltas.length <= documentedGaps,
      `${badDeltas.length} deltas anormaux vs ${documentedGaps} documentés`);
    // une seule bougie en formation = dernier bucket couvert par les ticks
    if (r60) {
      console.log(`    ℹ S60 après switch: état=${r60.state} clôturées=${r60.closedCount} formation=${r60.formingBucket} gaps=${r60.gaps?.length ?? 0}`);
      check('bougie en formation S60 présente (bucket courant)', r60.formingBucket != null);
      check('la formation est la DERNIÈRE bougie de la série',
        r60.formingBucket === candles[candles.length - 1]?.time,
        `forming=${r60.formingBucket} last=${candles[candles.length - 1]?.time}`);
    }
  }

  console.log('── 3. Live sur S60 : la formation progresse avec les ticks ──');
  const nBefore = candleUpdates.length;
  await wait(8000);
  check(`mises à jour de bougies S60 reçues (${candleUpdates.length - nBefore} en 8 s)`,
    candleUpdates.length > nBefore, `avant=${nBefore} après=${candleUpdates.length}`);
  if (candleUpdates.length > 0) {
    const last = candleUpdates[candleUpdates.length - 1];
    check('bougie live alignée % 60 === 0', last.time % 60 === 0);
  }

  console.log('── 4. Retour S30 (sans saut temporel) ──');
  activeSize = 30;
  socket.emit('set-config', { candleSize: 30 });
  await wait(6000);
  check('candles-history reçu après le retour S30', lastHistorySnapshot() != null && lastHistorySnapshot()!.key.endsWith(':30'));
  const hist30 = lastHistorySnapshot();
  if (hist30 && hist30.key.endsWith(':30')) {
    const candles = hist30.candles;
    check('toutes alignées % 30 === 0', candles.every(c => c.time % 30 === 0));
    check('zéro doublon de timestamp', new Set(candles.map(c => c.time)).size === candles.length);
    const lastTime = candles[candles.length - 1].time;
    check('la série S30 couvre le temps courant (formation au bout)',
      lastTime >= Math.floor(Date.now() / 1000) - 120, `last=${lastTime}`);
  }
  socket.close();
  console.log('\n══════════════════════════════');
  console.log(`  RÉSULTAT : ${passed} PASS / ${failed} FAIL`);
  console.log('══════════════════════════════');
  process.exit(failed > 0 ? 1 : 0);
}

main().catch(e => { console.error('ERREUR:', e); process.exit(1); });
