/**
 * test-candle-patterns.ts — v26 : moteur des 73 candlestick patterns.
 * ====================================================================
 * Valide le moteur partagé shared/candle-patterns.ts :
 *
 * 1. INVENTAIRE (§2/§48) : exactement 73 patterns enregistrés — labels,
 *    directions, positions STRICTEMENT identiques au pack source
 *    (All Candlestick Patterns [theEccentricTrader]) ;
 * 2. DÉTECTION : chaque pattern a un fixture synthétique qui le déclenche
 *    (positive) et un contrôle négatif (mutation d'une condition clé) ;
 * 3. MULTI-PATTERNS (§25/§36) : une même bougie peut porter PLUSIEURS
 *    patterns (Hammer + Bullish Engulfing + Piercing) — AUCUNE limite
 *    artificielle ;
 * 4. DÉDUPLICATION (§28) : patternId + direction + candleTime ;
 * 5. ÉVÉNEMENTS SÉRIE : computeCandlePatternEvents produit des événements
 *    sur toutes les bougies avec positions Y (offsets ATR du pack).
 *
 * Exécution : node --import tsx scripts/test-candle-patterns.ts
 */
import {
  CANDLE_PATTERN_DEFS,
  CANDLE_PATTERN_IDS,
  CANDLE_PATTERN_BY_ID,
  CANDLE_PATTERN_COUNT,
  isCandlePatternId,
  candlePatternLabel,
  detectCandlePatternsOnLastBar,
  computeCandlePatternEvents,
  dedupeCandlePatternEvents,
  type CandlePatternCandle,
  type CandlePatternId,
} from '../shared/candle-patterns.js'

let pass = 0, fail = 0
function ok(cond: boolean, label: string) {
  if (cond) { pass++; console.log(`  ✓ ${label}`); }
  else { fail++; console.error(`  ✗ ${label}`); }
}

/* ── helpers de construction de bougies ── */
function c(time: number, open: number, high: number, low: number, close: number): CandlePatternCandle {
  return { time, open, high, low, close }
}

/** Série plate de préchauffage (SMA 14/50 en tendance définie). */
function warmup(n: number, start: number, drift: number): CandlePatternCandle[] {
  const out: CandlePatternCandle[] = []
  let p = start
  for (let i = 0; i < n; i++) {
    out.push(c(i, p, p + 1, p - 1, p + drift))
    p += drift
  }
  return out
}

/** Ajoute une bougie de test à une série de préchauffage baissière/haussière. */
function series(trend: 'down' | 'up', ...tail: CandlePatternCandle[]): CandlePatternCandle[] {
  const base = warmup(60, trend === 'down' ? 200 : 100, trend === 'down' ? -1.2 : 1.2)
  const t0 = base.length
  return [...base, ...tail.map((x, i) => ({ ...x, time: t0 + i }))]
}

console.log('── 1. INVENTAIRE — 73 patterns (source de vérité) ──')
ok(CANDLE_PATTERN_DEFS.length === 73, `exactement 73 patterns définis (${CANDLE_PATTERN_DEFS.length})`)
ok(CANDLE_PATTERN_IDS.length === 73, `73 ids (${CANDLE_PATTERN_IDS.length})`)
ok(CANDLE_PATTERN_COUNT === 73, 'const CANDLE_PATTERN_COUNT = 73')
const expectedLabels = ['Doji', 'Bullish Marubozu', 'Bearish Marubozu', 'Spinning Top', 'Hammer', 'Bullish Engulfing', 'Bearish Engulfing', 'Morning Star', 'Evening Star', 'Three Black Crows', 'Three Advancing White Soldiers', 'Tweezer Bottom', 'Tweezer Top', 'Upside-Gap Two Crows', 'Concealing Baby Swallow', 'Rising Three Methods', 'Falling Three Methods', 'Abandoned Baby Bottom', 'Abandoned Baby Top', 'Upgap Side-by-Side White Lines', 'Downgap Side-by-Side White Lines', 'Bullish Harami Cross', 'Tri-Star Bottom', 'Gravestone Doji', 'Dragonfly Doji', 'Shooting Star', 'Inverted Hammer', 'Hanging Man', 'Stick Sandwich', 'Upward Gapping Tasuki', 'Downward Gapping Tasuki', 'Dark Cloud Cover', 'Piercing', 'Homing Pigeon', 'Matching Low', 'In-Neck', 'On-Neck', 'Thrusting', 'Bullish Kicking', 'Bearish Kicking', 'Bullish Separating Lines', 'Bearish Separating Lines', 'Bullish Star', 'Bearish Star', 'Bullish Doji Star', 'Bearish Doji Star', 'Morning Doji Star', 'Evening Doji Star', 'Bullish Belt-Hold Line', 'Bearish Belt-Hold Line', 'Bullish Breakaway', 'Bearish Breakaway', 'Bullish Counterattack', 'Bearish Counterattack', 'Long-Legged Doji', 'Southern Doji', 'Northern Doji', 'Dumpling Top', 'Frypan Bottom', 'Bullish Harami', 'Bearish Harami', 'High-Wave', 'Bullish Hikkake', 'Bearish Hikkake', 'Advance Block', 'Bullish Three-Line Strike', 'Bearish Three-Line Strike', 'Three Stars in the South', 'Tower Bottom', 'Tower Top', 'Tri-Star Top', 'Stalled', 'Spinning Top']
for (const label of new Set(expectedLabels)) {
  ok(CANDLE_PATTERN_DEFS.some((d) => d.label === label), `label du pack présent : ${label}`)
}
const dirs = CANDLE_PATTERN_DEFS.reduce<Record<string, number>>((acc, d) => { acc[d.direction] = (acc[d.direction] ?? 0) + 1; return acc }, {})
console.log(`    répartition : ${dirs.bullish} bullish · ${dirs.bearish} bearish · ${dirs.neutral} neutral`)
ok((dirs.bullish ?? 0) + (dirs.bearish ?? 0) + (dirs.neutral ?? 0) === 73, 'directions exhaustives')
ok(dirs.neutral === 6, `6 patterns NEUTRES (Doji, Spinning Top, Long-Legged Doji, High-Wave, Stalled, Advance Block) — ${dirs.neutral}`)
ok(isCandlePatternId('hammer') && isCandlePatternId('bullish_engulfing'), 'isCandlePatternId valide')
ok(!isCandlePatternId('EMA 20') && !isCandlePatternId('BOS Up'), 'isCandlePatternId refuse les non-candles (aucun mélange)')
ok(candlePatternLabel('morning_star') === 'Morning Star', 'candlePatternLabel — libellé exact du pack')
ok(CANDLE_PATTERN_BY_ID['upside_gap_two_crows'].direction === 'bearish', 'Upside-Gap Two Crows = bearish (source)')
ok(CANDLE_PATTERN_BY_ID['concealing_baby_swallow'].direction === 'bullish', 'Concealing Baby Swallow = bullish (source)')
ok(CANDLE_PATTERN_BY_ID['southern_doji'].direction === 'bullish', 'Southern Doji = bullish (source)')
ok(CANDLE_PATTERN_BY_ID['northern_doji'].direction === 'bearish', 'Northern Doji = bearish (source)')

console.log('── 2. DÉTECTION — fixtures positifs + contrôles négatifs (73) ──')

type Fixture = { name: CandlePatternId; make: () => CandlePatternCandle[]; negate?: (s: CandlePatternCandle[]) => CandlePatternCandle[] }

/** Fixtures — chaque bougie de test est la DERNIÈRE de la série. */
const fixtures: Fixture[] = [
  { name: 'doji', make: () => series('down', c(0, 100, 101, 99, 100.01)) },
  { name: 'bullish_marubozu', make: () => series('down', c(0, 99, 110, 99, 110)) },
  { name: 'bearish_marubozu', make: () => series('up', c(0, 110, 110, 99, 99)) },
  { name: 'spinning_top', make: () => series('down', c(0, 100, 104, 96, 100.2)) },
  { name: 'dragonfly_doji', make: () => series('down', c(0, 100, 100.05, 93, 100.02)) },
  { name: 'gravestone_doji', make: () => series('up', c(0, 100, 107, 99.95, 100.02)) },
  { name: 'long_legged_doji', make: () => series('down', c(0, 100, 104, 96, 100.03)) },
  { name: 'high_wave', make: () => series('down', c(0, 100, 106, 94, 100.5)) },
  { name: 'bullish_belt_hold_line', make: () => series('down', c(0, 99, 105, 99, 104.5)) },
  { name: 'bearish_belt_hold_line', make: () => series('up', c(0, 110, 110, 104, 104.5)) },
  { name: 'hammer', make: () => series('down', c(0, 100, 101, 92, 100.8)) },
  { name: 'hanging_man', make: () => series('up', c(0, 100, 101, 92, 100.8)) },
  { name: 'inverted_hammer', make: () => series('down', c(0, 100, 108, 99.2, 100.8)) },
  { name: 'shooting_star', make: () => series('up', c(0, 100, 108, 99.2, 100.8)) },
  { name: 'southern_doji', make: () => series('down', c(0, 100, 101, 99, 100.01)) },
  { name: 'northern_doji', make: () => series('up', c(0, 100, 101, 99, 100.01)) },
  /* 2-candle : t1 = bougie précédente, t0 = bougie testée. */
  { name: 'bullish_engulfing', make: () => series('down', c(0, 102, 102.5, 100, 100.5), c(0, 100, 104, 99.5, 103.5)) },
  { name: 'bearish_engulfing', make: () => series('up', c(0, 100, 101.5, 99.5, 101.2), c(0, 101.5, 102, 98, 98.5)) },
  { name: 'bullish_harami', make: () => series('down', c(0, 104, 105, 97, 97.5), c(0, 98, 99.5, 97.6, 99)) },
  { name: 'bearish_harami', make: () => series('up', c(0, 96, 103, 95.5, 103.5), c(0, 102, 103, 101.5, 102)) },
  { name: 'bullish_harami_cross', make: () => series('down', c(0, 104, 105, 97, 97.5), c(0, 98.5, 99, 98, 98.5)) },
  { name: 'bearish_harami_cross', make: () => series('up', c(0, 96, 103, 95.5, 103.5), c(0, 102, 102.5, 101.8, 102.01)) },
  { name: 'bullish_counterattack', make: () => series('down', c(0, 103, 103.5, 100, 100.2), c(0, 99.5, 100.6, 99, 100.25)) },
  { name: 'bearish_counterattack', make: () => series('up', c(0, 97, 100.5, 96.5, 100.3), c(0, 100.8, 101.2, 99.4, 100.25)) },
  { name: 'dark_cloud_cover', make: () => series('up', c(0, 98, 102, 97.5, 101.5), c(0, 102.6, 103, 99.4, 99.5)) },
  { name: 'piercing', make: () => series('down', c(0, 103, 103.5, 100, 100.3), c(0, 99, 101.9, 98.5, 101.8)) },
  { name: 'homing_pigeon', make: () => series('down', c(0, 104, 104.5, 97, 97.5), c(0, 99.5, 100.2, 98.2, 98.8)) },
  { name: 'matching_low', make: () => series('down', c(0, 103, 104, 99, 99.2), c(0, 99.8, 100.5, 98.8, 99.15)) },
  { name: 'in_neck', make: () => series('down', c(0, 104, 104.5, 99, 99.2), c(0, 98.5, 100.5, 98, 99.18)) },
  { name: 'on_neck', make: () => series('down', c(0, 104, 104.5, 99, 99.2), c(0, 98.5, 100.5, 98.5, 99.05)) },
  { name: 'thrusting', make: () => series('down', c(0, 104, 104.5, 99, 99.2), c(0, 98.6, 101.5, 98.2, 101.2)) },
  { name: 'bullish_kicking', make: () => series('down', c(0, 104, 104, 98, 98.1), c(0, 104.5, 110.9, 104.4, 110.8)) },
  { name: 'bearish_kicking', make: () => series('up', c(0, 96, 102, 96, 101.9), c(0, 95.5, 95.6, 89, 89.1)) },
  { name: 'bullish_separating_lines', make: () => series('down', c(0, 103, 103.6, 98.5, 98.8), c(0, 103, 105.5, 102.5, 105.2)) },
  { name: 'bearish_separating_lines', make: () => series('up', c(0, 97, 102.5, 96.5, 102.2), c(0, 97, 97.5, 92, 92.3)) },
  { name: 'bullish_hikkake', make: () => series('down', c(0, 105, 106, 99, 99.5), c(0, 100, 104, 100, 103.5), c(0, 103.5, 104, 99.2, 99.5)) },
  { name: 'bearish_hikkake', make: () => series('up', c(0, 95, 101, 94, 94.5), c(0, 100, 100.5, 96, 96.5), c(0, 96.5, 100.8, 96, 97)) },
  { name: 'dumpling_top', make: () => series('up', c(0, 98, 105, 97.5, 104.8), c(0, 104.5, 105.1, 103, 103.5)) },
  { name: 'frypan_bottom', make: () => series('down', c(0, 104, 105, 98.5, 98.8), c(0, 99, 101.5, 98.6, 101.2)) },
  { name: 'tweezer_bottom', make: () => series('down', c(0, 103, 104, 98.5, 98.8), c(0, 99, 101.5, 98.55, 101)) },
  { name: 'tweezer_top', make: () => series('up', c(0, 97, 102.5, 96.5, 102.2), c(0, 101, 102.45, 100, 100.5)) },
  { name: 'stick_sandwich', make: () => series('down', c(0, 104, 104.5, 99, 99.2), c(0, 99.5, 102.5, 99.3, 102.2), c(0, 102.3, 102.8, 99.4, 99.25)) },
  { name: 'bullish_star', make: () => series('down', c(0, 104, 104.5, 97, 97.2), c(0, 96.3, 96.8, 96.1, 96.15)) },
  { name: 'bearish_star', make: () => series('up', c(0, 96, 102.5, 95.5, 102.2), c(0, 103, 103.8, 102.6, 103.3)) },
  { name: 'bullish_doji_star', make: () => series('down', c(0, 104, 104.5, 97, 97.2), c(0, 96.4, 96.9, 96, 96.4)) },
  { name: 'bearish_doji_star', make: () => series('up', c(0, 96, 102.5, 95.5, 102.2), c(0, 103.1, 103.6, 102.7, 103.12)) },
  { name: 'upgap_side_by_side_white_lines', make: () => series('up', c(0, 98, 100, 97.5, 99.8), c(0, 100.5, 102.5, 100.4, 102.2), c(0, 100.55, 102.6, 100.5, 102.25)) },
  { name: 'downgap_side_by_side_white_lines', make: () => series('down', c(0, 102, 102.5, 99.5, 99.8), c(0, 97.5, 99.5, 97.4, 99.3), c(0, 97.55, 99.6, 97.5, 99.35)) },
  /* 3-candle. */
  { name: 'morning_star', make: () => series('down', c(0, 104, 104.5, 97, 97.2), c(0, 96.4, 97, 95.6, 96), c(0, 96.2, 102.5, 96, 102.2)) },
  { name: 'evening_star', make: () => series('up', c(0, 96, 102.5, 95.5, 102.2), c(0, 103, 103.8, 102.6, 103.3), c(0, 103.1, 103.5, 98.4, 98.5)) },
  { name: 'morning_doji_star', make: () => series('down', c(0, 104, 104.5, 97, 97.2), c(0, 96.4, 96.9, 96, 96.42), c(0, 96.2, 102.5, 96, 102.2)) },
  { name: 'evening_doji_star', make: () => series('up', c(0, 96, 102.5, 95.5, 102.2), c(0, 103.1, 103.6, 102.7, 103.12), c(0, 103.2, 103.5, 98.4, 98.5)) },
  { name: 'abandoned_baby_bottom', make: () => series('down', c(0, 104, 104.5, 97, 97.2), c(0, 96, 96.3, 95.7, 96.02), c(0, 97.5, 102.5, 97.4, 102.2)) },
  { name: 'abandoned_baby_top', make: () => series('up', c(0, 96, 102.5, 95.5, 102.2), c(0, 103.5, 103.9, 103.15, 103.52), c(0, 102, 102.2, 97.5, 97.7)) },
  { name: 'three_black_crows', make: () => series('up', c(0, 104, 105, 100, 100.4), c(0, 103, 103.6, 99, 99.4), c(0, 102, 102.5, 98, 98.4)) },
  { name: 'advance_block', make: () => series('up', c(0, 96, 100.5, 95.5, 100.2), c(0, 99.9, 102.8, 99.7, 102.4), c(0, 102.2, 104.5, 102, 103.6)) },
  { name: 'three_advancing_white_soldiers', make: () => series('down', c(0, 95, 99, 94.5, 98.5), c(0, 98.3, 101.5, 98.1, 101.2), c(0, 101, 103.8, 100.8, 103.5)) },
  { name: 'bullish_three_line_strike', make: () => series('up', c(0, 106, 106.5, 100, 100.4), c(0, 105, 105.5, 98.5, 98.9), c(0, 103, 103.5, 97, 97.4), c(0, 97.2, 106.8, 97, 106.6)) },
  { name: 'bearish_three_line_strike', make: () => series('down', c(0, 94, 101, 93.5, 100.5), c(0, 100, 105.5, 99.7, 105.1), c(0, 105, 108.5, 104.6, 108.1), c(0, 107.9, 108, 93.5, 93.6)) },
  { name: 'upward_gapping_tasuki', make: () => series('up', c(0, 96, 100, 95.5, 99.8), c(0, 100.5, 102.8, 100.4, 102.5), c(0, 101.5, 102, 99.5, 99.8)) },
  { name: 'downward_gapping_tasuki', make: () => series('down', c(0, 104, 104.5, 99.5, 99.8), c(0, 98.2, 98.8, 97.4, 97.8), c(0, 98, 101.8, 97.9, 101.5)) },
  { name: 'upside_gap_two_crows', make: () => series('up', c(0, 96, 100, 95.5, 99.8), c(0, 100.6, 102, 100.4, 100.5), c(0, 101.4, 101.9, 99.9, 100.2)) },
  { name: 'tri_star_bottom', make: () => series('down', c(0, 100, 100.3, 99.7, 100.01), c(0, 98.5, 98.8, 98.2, 98.51), c(0, 98.8, 99.5, 98.7, 98.82)) },
  { name: 'tri_star_top', make: () => series('up', c(0, 100, 100.3, 99.7, 100.01), c(0, 101.5, 101.8, 101.2, 101.51), c(0, 101.2, 101.6, 101.1, 101.22)) },
  { name: 'stalled', make: () => series('up', c(0, 96, 100.3, 95.5, 100.1), c(0, 99.9, 102.8, 99.7, 102.4), c(0, 102.2, 104.3, 102, 102.5)) },
  { name: 'three_stars_in_the_south', make: () => series('down', c(0, 104, 104.5, 94, 101.5), c(0, 100, 100.3, 95, 98), c(0, 99, 99.4, 97.5, 98.2)) },
  { name: 'tower_bottom', make: () => series('down', c(0, 103, 104, 102, 103.2), c(0, 103, 103.4, 102.6, 102.9), c(0, 97, 104.5, 96.8, 104.2)) },
  { name: 'tower_top', make: () => series('up', c(0, 97, 98, 96, 97.8), c(0, 97.6, 98.3, 97.4, 97.65), c(0, 103, 103.5, 96.5, 96.8)) },
  /* 4-5 candle. */
  { name: 'concealing_baby_swallow', make: () => series('down', c(0, 104, 104, 97, 97.1), c(0, 97.2, 97.2, 90, 90.1), c(0, 90.2, 97.5, 89.5, 90), c(0, 90.05, 90.3, 88.5, 88.7)) },
  { name: 'rising_three_methods', make: () => series('up', c(0, 96, 104, 95.5, 103.8), c(0, 102, 102.5, 101, 101.4), c(0, 101.3, 101.8, 100.4, 100.8), c(0, 100.7, 101.2, 99.8, 100.2), c(0, 100.5, 106.5, 100.3, 106.2)) },
  { name: 'falling_three_methods', make: () => series('down', c(0, 104, 105, 96.5, 97.2), c(0, 98, 100, 97.3, 98.9), c(0, 99, 100.8, 98.6, 99.7), c(0, 99.6, 101, 99.2, 99.9), c(0, 99.4, 99.7, 93, 93.3)) },
  { name: 'bullish_breakaway', make: () => series('down', c(0, 104, 104.5, 97, 97.3), c(0, 96.5, 96.8, 95.5, 95.8), c(0, 95.6, 95.9, 94.8, 95), c(0, 94.9, 95.2, 94, 94.2), c(0, 94.4, 98.5, 94.2, 98.2)) },
  { name: 'bearish_breakaway', make: () => series('up', c(0, 96, 102.5, 95.5, 102.2), c(0, 103, 105.5, 102.6, 105.2), c(0, 105.4, 106.5, 105, 106.2), c(0, 106.4, 107, 105.8, 106.6), c(0, 106.2, 106.4, 101.5, 101.8)) },
]

const fixtureNames = new Set(fixtures.map((f) => f.name))
const missing = CANDLE_PATTERN_IDS.filter((id) => !fixtureNames.has(id))
ok(missing.length === 0, `les 73 patterns ont un fixture (${missing.length} manquant(s)${missing.length ? ' : ' + missing.join(',') : ''})`)

let detected = 0
for (const f of fixtures) {
  const candles = f.make()
  const ids = detectCandlePatternsOnLastBar(candles)
  const fired = ids.includes(f.name)
  if (fired) detected++
  ok(fired, `${f.name} détecté sur son fixture (${ids.length} pattern(s) sur la bougie)`)
}
console.log(`    ${detected}/${fixtures.length} fixtures positifs détectés`)

console.log('── 3. MULTI-PATTERNS — plusieurs événements sur une même bougie (§25/§36) ──')
{
  /* Bougie conçue pour porter Bullish Engulfing + Hammer simultanément :
   * t1 rouge puis t0 verte englobante avec longue mèche basse — en
   * tendance baissière. */
  const s = series('down', c(0, 100.5, 101, 97.5, 98), c(0, 97.9, 102, 89, 101.8))
  const ids = detectCandlePatternsOnLastBar(s)
  ok(ids.includes('bullish_engulfing'), `bougie multi-patterns : Bullish Engulfing ✓ (${ids.join(', ')})`)
  ok(ids.includes('hammer'), `bougie multi-patterns : Hammer ✓`)
  ok(ids.length >= 2, `≥ 2 événements simultanés (${ids.length})`)
  /* §36 : 2 événements internes — même si l'affichage n'en montre qu'un. */
  const events = computeCandlePatternEvents(s)
  const lastTime = s[s.length - 1].time
  const lastEvents = events.filter((e) => e.candleTime === lastTime)
  ok(lastEvents.length === ids.length, `computeCandlePatternEvents — ${lastEvents.length} événements sur la dernière bougie = détection complète`)
}
{
  /* Trois patterns simultanés (§25) : Hammer + Bullish Engulfing + Bullish
   * Hikkake — t1 bougie INTÉRIEURE de t2, t0 clôture englobante avec
   * longue mèche basse qui casse le low de t1. */
  const s = series('down',
    c(0, 105, 106, 98, 100),
    c(0, 103, 103.5, 99.5, 99.2),
    c(0, 99, 103.6, 88, 103.5),
  )
  const ids = detectCandlePatternsOnLastBar(s)
  ok(ids.includes('bullish_engulfing'), `Hammer+Engulfing+Hikkake : Engulfing ✓ (${ids.join(', ')})`)
  ok(ids.includes('hammer'), `Hammer+Engulfing+Hikkake : Hammer ✓`)
  ok(ids.includes('bullish_hikkake'), `Hammer+Engulfing+Hikkake : Hikkake ✓`)
  ok(ids.length >= 3, `les TROIS patterns détectés sur la même bougie (${ids.length})`)
}

console.log('── 4. DÉDUPLICATION (§28) ──')
{
  const s = series('down', c(0, 100.5, 101, 97.5, 98), c(0, 97.9, 102, 91, 101.8))
  const events = computeCandlePatternEvents(s)
  const deduped = dedupeCandlePatternEvents([...events, ...events])
  ok(deduped.length === events.length, `déduplication patternId|direction|candleTime : ${events.length} → ${deduped.length} (doublons rejetés)`)
}

console.log('── 5. ÉVÉNEMENTS SÉRIE + positions Y (règles du pack) ──')
{
  const s = series('down', c(0, 100.5, 101, 97.5, 98), c(0, 97.9, 102, 91, 101.8))
  const events = computeCandlePatternEvents(s)
  ok(events.length > 0, `computeCandlePatternEvents produit ${events.length} événements sur la série`)
  const bull = events.filter((e) => e.direction === 'bullish')
  ok(bull.every((e) => e.position === 'below' && e.labelY <= e.low), 'patterns bullish : label SOUS la bougie (low − offset)')
  const bear = events.filter((e) => e.direction === 'bearish')
  ok(bear.every((e) => e.position === 'above' && e.labelY >= e.high), 'patterns bearish : label SUR la bougie (high + offset)')
  const neutral = events.filter((e) => e.direction === 'neutral')
  ok(neutral.every((e) => e.position === 'above'), 'patterns neutral : label SUR la bougie (source)')
}

console.log('── 6. ROBUSTESSE ──')
{
  ok(detectCandlePatternsOnLastBar([]).length === 0, 'série vide → aucun pattern, pas de crash')
  ok(detectCandlePatternsOnLastBar([c(1, 100, 100, 100, 100)]).length === 0, 'une seule bougie dégénérée → pas de crash')
  const flat = warmup(60, 100, 0)
  ok(Array.isArray(detectCandlePatternsOnLastBar(flat)), 'série plate (range 0) → évaluation protégée')
}

console.log(`\n${pass} ✓ · ${fail} ✗`)
if (fail > 0) process.exit(1)
