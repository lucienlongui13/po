// test-capture-ack.ts — verify capture-history ack returns the deep series.
import { io } from 'socket.io-client'

const URL = 'http://localhost:3030'
const socket = io(URL, { transports: ['websocket'] })

socket.on('connect', () => {
  console.log('connected as', socket.id)
  // 1) small warm capture
  socket.emit('capture-history', { count: 500, size: 60 }, (r: any) => {
    console.log('[500] ok=', r?.ok, 'count=', r?.count, 'candles.len=', r?.candles?.length,
      'first=', r?.candles?.[0]?.time, 'last=', r?.candles?.[r?.candles?.length - 1]?.time)
    // 2) deep capture — 10 days M1
    const t0 = Date.now()
    socket.emit('capture-history', { count: 14400, size: 60 }, (r2: any) => {
      const ms = Date.now() - t0
      console.log(`[14400] ok=${r2?.ok} count=${r2?.count} candles.len=${r2?.candles?.length} en ${ms}ms`)
      if (Array.isArray(r2?.candles) && r2.candles.length > 0) {
        const c = r2.candles
        console.log('first:', new Date(c[0].time * 1000).toISOString(), ' last:', new Date(c[c.length - 1].time * 1000).toISOString())
        console.log('SPAN jours:', ((c[c.length - 1].time - c[0].time) / 86400).toFixed(2))
      }
      socket.close()
      process.exit(0)
    })
  })
})

socket.on('connect_error', (e: any) => { console.error('connect_error', e.message); process.exit(1) })
setTimeout(() => { console.error('TIMEOUT'); process.exit(1) }, 120000)
