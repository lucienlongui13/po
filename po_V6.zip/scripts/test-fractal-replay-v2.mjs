import fs from 'fs'
const lib = fs.readFileSync('src/lib/indicators-library.ts','utf8')
const replay = fs.readFileSync('src/lib/replay-engine.ts','utf8')
const drawings = fs.readFileSync('src/components/trading/chart/drawing-layer.tsx','utf8')
const tv = fs.readFileSync('src/lib/tv-store.ts','utf8')
const page = fs.readFileSync('src/app/page.tsx','utf8')
for (const [name,text,checks] of [
 ['indicators',lib,["id: 'fractal'","id: 'fractal-custom'","marker: 'arrowUp'","marker: 'arrowDown'"]],
 ['replay',replay,['getVisible()','onAdvance','start(full']],
 ['drawings',drawings,['pointerdown',"pointermove', onPointerMove, true","pointercancel"]],
 ['settings',tv,['plotSettings','updateIndicatorPlotSettings','cloudVisible']],
 ['mono replay',page,['const safeBarsBack','candles.length < 20']],
]) { for (const c of checks) if (!text.includes(c)) throw new Error(`${name}: missing ${c}`) }
console.log('fractal/replay/settings structural checks: OK')
