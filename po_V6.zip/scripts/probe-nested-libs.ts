/**
 * Probe: does piner accept SINGLE-quoted strings ('PubLibSwing') and nested
 * library imports (Main -> PubLibSwing -> PubLibCandleTrend)?
 * Uses the user's uploaded Market_structures_scripts sources directly.
 */
import { compileAsync } from '@heyphat/piner'
import { readFileSync } from 'node:fs'

const base = '/home/z/my-project/upload/market_structures_extracted/Market_structures_scripts'
const main = readFileSync(`${base}/Main.pine`, 'utf8')
const swing = readFileSync(`${base}/libs/PubLibSwing.pine`, 'utf8')
const trend = readFileSync(`${base}/libs/PubLibTrend.pine`, 'utf8')
const utility = readFileSync(`${base}/libs/PubLibUtility.pine`, 'utf8')

// Minimal shim for the missing transitive dep: PiracyChecker/PubLibCandleTrend/2
const candleTrend = `//@version=6
library('PubLibCandleTrend')
export gc() => close >= open
export rc() => close < open
`

const registry = [
  { key: 'PiracyChecker/PubLibSwing/3', source: swing },
  { key: 'PiracyChecker/PubLibTrend/3', source: trend },
  { key: 'PiracyChecker/PubLibUtility/2', source: utility },
  { key: 'PiracyChecker/PubLibCandleTrend/2', source: candleTrend },
]

async function mainProbe() {
  // 1. Single-quote probe on a library alone
  try {
    await compileAsync(swing, { libraries: registry })
    console.log('PROBE 1 (single-quoted library decl): OK')
  } catch (err: any) {
    console.log('PROBE 1 FAILED:', err?.message?.slice(0, 400))
  }

  // 2. Full nested graph: Main -> {Swing -> CandleTrend, Trend -> Swing, Utility}
  try {
    const compiled = await compileAsync(main, { libraries: registry })
    console.log('PROBE 2 (nested multi-library compile): OK')
    console.log('  title:', compiled.metadata.title)
    console.log('  inputs:', compiled.metadata.inputs.length)
    console.log('  maxLabelsCount:', compiled.metadata.maxLabelsCount)
  } catch (err: any) {
    console.log('PROBE 2 FAILED:', err?.message?.slice(0, 600))
  }

  // 3. Missing transitive dep error message quality
  try {
    await compileAsync(main, { libraries: registry.filter((r) => r.key !== 'PiracyChecker/PubLibCandleTrend/2') })
    console.log('PROBE 3: compiled (unexpected)')
  } catch (err: any) {
    console.log('PROBE 3 (missing transitive dep error):', err?.message?.slice(0, 500))
  }
}

mainProbe()
