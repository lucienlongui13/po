/**
 * Probe 2 — (a) exact input schema keys of Main.pine (for alert bool overrides),
 * (b) does an overlay=false script with hlines pollute the main price scale?
 * (c) confirm mintick default effect on label offsets with real mintick passed.
 */
import { compileAsync, Engine, ArrayFeed } from '@heyphat/piner'
import { asPinerRegistry, importLibraryBundle } from '../src/lib/pine-libraries'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'

const LIB_DIR = 'upload/piracy_extracted/Market_structures_scripts'
const files = [
  { name: 'libs/PubLibCandleTrend.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibCandleTrend.pine'), 'utf8') },
  { name: 'libs/PubLibSwing.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibSwing.pine'), 'utf8') },
  { name: 'libs/PubLibTrend.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibTrend.pine'), 'utf8') },
  { name: 'libs/PubLibUtility.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibUtility.pine'), 'utf8') },
  { name: 'Main.pine', source: readFileSync(join(LIB_DIR, 'Main.pine'), 'utf8') },
]
importLibraryBundle(files)

// real captured dataset (2242 M1 EURUSD_otc candles — same as the campaign)
const raw = JSON.parse(readFileSync('scripts/dataset-eurusd-m1.json', 'utf8')) as any[]
const bars = (Array.isArray(raw) ? raw : raw.candles ?? raw.data ?? []).map((c: any) => ({
  time: Number(c.time) * (Number(c.time) > 1e12 ? 1 : 1000),
  open: Number(c.open), high: Number(c.high), low: Number(c.low), close: Number(c.close),
  volume: Number(c.volume ?? 0),
}))
if (!bars.length) throw new Error('dataset empty')
console.log(`dataset: ${bars.length} bars, prices ${Math.min(...bars.map(b => b.low))} … ${Math.max(...bars.map(b => b.high))}`)

const run = async (source: string, opts: any, inputs?: Record<string, unknown>) => {
  const compiled = await compileAsync(source, { libraries: asPinerRegistry(), resolveLibrary: (id) => asPinerRegistry().find((l) => l.key === id.canonical)?.source })
  const engine = new Engine(compiled as any, new ArrayFeed(bars) as any, inputs ? { inputs } : undefined)
  await engine.run({ symbol: 'EURUSD_otc', timeframe: '1', ...opts })
  return engine as any
}

const main = async () => {
  // (a) input schema keys
  const compiled = await compileAsync(files[4].source, { libraries: asPinerRegistry(), resolveLibrary: (id) => asPinerRegistry().find((l) => l.key === id.canonical)?.source })
  const inputs = (compiled as any)?.metadata?.inputs ?? []
  console.log('── (a) Main.pine input keys ──')
  console.log(JSON.stringify(inputs.map((i: any) => ({ key: i.key, kind: i.kind, def: i.default })), null, 1).slice(0, 1600))

  // (b) NO mintick (app behavior today) vs (c) real mintick 0.00001
  const alertInputs: Record<string, unknown> = {}
  for (const i of inputs) if (i.kind === 'bool' && /alert/i.test(i.key)) alertInputs[i.key] = true

  const e1 = await run(files[4].source, { symbol: 'EURUSD_otc', timeframe: '1' }, alertInputs)
  const labels1 = (e1.drawings as any[]).filter((d) => d.type === 'label')
  const ys1 = labels1.map((d) => d.props?.y).filter((y: unknown) => typeof y === 'number') as number[]
  console.log(`\n── (b) WITHOUT mintick: ${labels1.length} labels, alerts=${e1.outputs?.alerts?.length ?? 0} ──`)
  if (ys1.length) {
    console.log('label y range:', Math.min(...ys1).toFixed(6), '…', Math.max(...ys1).toFixed(6), '| candle range 1.1564 … 1.1589')
    console.log('offsets from price:', ys1.slice(0, 6).map((y) => (y - 1.1575).toFixed(4)).join(', '))
  }

  const e2 = await run(files[4].source, { symbol: 'EURUSD_otc', timeframe: '1', mintick: 0.00001 }, alertInputs)
  const labels2 = (e2.drawings as any[]).filter((d) => d.type === 'label')
  const ys2 = labels2.map((d) => d.props?.y).filter((y: unknown) => typeof y === 'number') as number[]
  console.log(`\n── (c) WITH mintick=0.00001: ${labels2.length} labels, alerts=${e2.outputs?.alerts?.length ?? 0} ──`)
  if (ys2.length) {
    console.log('label y range:', Math.min(...ys2).toFixed(6), '…', Math.max(...ys2).toFixed(6))
    console.log('offsets from price:', ys2.slice(0, 6).map((y) => (y - 1.1575).toFixed(6)).join(', '))
  }
  const alerts2 = e2.outputs?.alerts ?? []
  console.log('\nalert events sample:', JSON.stringify(alerts2.slice(0, 5)))
}
main().catch((e) => { console.error('FAIL', e); process.exit(1) })
