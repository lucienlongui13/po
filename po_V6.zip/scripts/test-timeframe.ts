/**
 * test-timeframe.ts — Tests unitaires du module timeframe (§20 du ToDo).
 *
 * Vérifie la SOURCE DE VÉRITÉ TEMPORELLE UNIQUE :
 *   - S5 avec timestamp `1787915506.001` → bucket `1787915505` (cas .har) ;
 *   - S30 avec timestamp `1787915506.001` → bucket multiple de 30 ;
 *   - M1 avec timestamp exact de frontière ;
 *   - M5 avec timestamp juste avant/après frontière ;
 *   - findGaps : détection des trous (début/fin/nombre) ;
 *   - normalizeCandleSeries : alignement + dédup + tri + validation + trous ;
 *   - isOhlcValid : invariants OHLC.
 *
 * Exécution : cd mini-services/iqoption-backend && ../../node_modules/.bin/tsx ../../scripts/test-timeframe.ts
 */
import {
  bucketStart, bucketEnd, isBucketAligned, findGaps, isOhlcValid, normalizeCandleSeries,
} from '../mini-services/iqoption-backend/timeframe.js';

let pass = 0, fail = 0;
const ok = (name: string, cond: boolean, detail = '') => {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); }
};

console.log('══ T1 — bucketStart : grille canonique par timeframe ══');
{
  // Cas .har authentique : le premier chargement live S5 part de 1787915506.001
  ok('S5 : 1787915506.001 → 1787915505', bucketStart(1787915506.001, 5) === 1787915505);
  ok('S5 : 1787915505 exact → 1787915505 (frontière)', bucketStart(1787915505, 5) === 1787915505);
  ok('S5 : 1787915504.999 → 1787915500 (bucket précédent)', bucketStart(1787915504.999, 5) === 1787915500);

  const s30 = bucketStart(1787915506.001, 30);
  ok('S30 : 1787915506.001 → 1787915490 (multiple de 30)', s30 === 1787915490 && s30 % 30 === 0);
  ok('S30 : la fenêtre [start, start+30) contient le tick', s30 <= 1787915506.001 && 1787915506.001 < s30 + 30);

  ok('M1 : 1787915520 (frontière exacte) → 1787915520', bucketStart(1787915520, 60) === 1787915520);
  ok('M1 : 1787915519.999 → 1787915460', bucketStart(1787915519.999, 60) === 1787915460);

  ok('M5 : 1787915699.999 (juste avant frontière) → 1787915400', bucketStart(1787915699.999, 300) === 1787915400);
  ok('M5 : 1787915700.001 (juste après frontière) → 1787915700', bucketStart(1787915700.001, 300) === 1787915700);
  ok('M5 : 1787915700 (frontière exacte) → 1787915700', bucketStart(1787915700, 300) === 1787915700);

  ok('bucketEnd : [t, t+period)', bucketEnd(1787915506.001, 30) === 1787915520);
  ok('isBucketAligned : vrai sur frontière, faux sinon',
    isBucketAligned(1787915500, 5) === true && isBucketAligned(1787915501, 5) === false && isBucketAligned(1787915502.5, 5) === false);
}

console.log('══ T2 — isOhlcValid : invariants OHLC ══');
{
  ok('bougies valides', isOhlcValid({ time: 100, open: 10, high: 12, low: 9, close: 11 }));
  ok('high == low == open == close (doji) valide', isOhlcValid({ time: 100, open: 10, high: 10, low: 10, close: 10 }));
  ok('high < max(open, close) REJETÉ', !isOhlcValid({ time: 100, open: 10, high: 10.5, low: 9, close: 11 }));
  ok('low > min(open, close) REJETÉ', !isOhlcValid({ time: 100, open: 10, high: 12, low: 10.5, close: 11 }));
  ok('NaN REJETÉ', !isOhlcValid({ time: 100, open: NaN, high: 12, low: 9, close: 11 }));
  ok('timestamp non fini REJETÉ', !isOhlcValid({ time: Infinity, open: 10, high: 12, low: 9, close: 11 }));
}

console.log('══ T3 — findGaps : détection des trous ══');
{
  const p = 30;
  const series = [
    { time: 1000, open: 1, high: 1, low: 1, close: 1 },
    { time: 1030, open: 1, high: 1, low: 1, close: 1 },
    { time: 1060, open: 1, high: 1, low: 1, close: 1 },
    // TROU : 1090, 1120, 1150 manquantes
    { time: 1180, open: 1, high: 1, low: 1, close: 1 },
    { time: 1210, open: 1, high: 1, low: 1, close: 1 },
  ];
  const gaps = findGaps(series, p);
  ok('1 trou détecté', gaps.length === 1, JSON.stringify(gaps));
  ok('trou : startTime = 1090 (premier bucket manquant)', gaps[0]?.startTime === 1090);
  ok('trou : endTime = 1180 (bucket présent suivant)', gaps[0]?.endTime === 1180);
  ok('trou : 3 bougies manquantes', gaps[0]?.missingCandles === 3);
  ok('trou : periodSec renseigné', gaps[0]?.periodSec === 30);
  ok('série consécutive → zéro trou', findGaps(series.slice(0, 3), p).length === 0);
}

console.log('══ T4 — normalizeCandleSeries : alignement + dédup + tri + validation ══');
{
  const p = 30;
  const messy = [
    // non alignée (bucket réel 99990 — 1000 n'est PAS un multiple de 30)
    { time: 1007, open: 1, high: 2, low: 0.5, close: 1.5, volume: 10 },
    // doublon du même bucket (1000 → 99990), volume inférieur → écrasé
    { time: 1000, open: 9, high: 9, low: 9, close: 9, volume: 3 },
    // bougie invalide (OHLC incohérent) — bucket 1020
    { time: 1030, open: 1, high: 0.2, low: 5, close: 1, volume: 5 },
    // non alignée (1060 → bucket 1050)
    { time: 1060, open: 1, high: 2, low: 0.5, close: 1.5, volume: 7 },
  ];
  const res = normalizeCandleSeries(messy, p);
  ok('3 bougies réalignées sur leur grille (1007, 1000, 1060)', res.realigned === 3, `realigned=${res.realigned}`);
  ok('1 doublon de bucket fusionné', res.duplicates === 1, `duplicates=${res.duplicates}`);
  ok('1 bougie invalide rejetée', res.invalid === 1, `invalid=${res.invalid}`);
  ok('2 bougies canoniques en sortie', res.candles.length === 2, `n=${res.candles.length}`);
  ok('toutes alignées % 30 === 0', res.candles.every(c => c.time % 30 === 0));
  ok('tri croissant strict', res.candles[0].time < res.candles[1].time);
  ok('le doublon garde la bougie au volume le plus élevé (10 > 3)',
    res.candles[0].volume === 10, `vol=${res.candles[0]?.volume}`);
  ok('trous détectés dans la série normalisée (bucket 1020 manquant)',
    res.gaps.length === 1 && res.gaps[0].missingCandles === 1, JSON.stringify(res.gaps));

  // Série vide / NaN
  const empty = normalizeCandleSeries([], 30);
  ok('série vide → vide, aucun trou', empty.candles.length === 0 && empty.gaps.length === 0);
}

console.log('══ T5 — Propriété : un tick sous-seconde n\'est JAMAIS un début de bougie ══');
{
  // Le .har montre des ticks live avec fraction de seconde : aucun ne doit
  // jamais devenir un timestamp de bougie non aligné.
  const T0 = 1787915506.001;
  let allAligned = true;
  for (const period of [5, 10, 15, 30, 60, 120, 300, 900, 1800, 3600]) {
    for (const dt of [0, 0.001, 0.201, 0.5, 0.75, 0.875, 0.999]) {
      const b = bucketStart(T0 + dt, period);
      if (b % period !== 0 || b > T0 + dt || b + period <= T0 + dt) allAligned = false;
    }
  }
  ok('pour tout timeframe et toute fraction de seconde : bucket aligné et fenêtre [b, b+p) contient le tick', allAligned);
}

console.log('');
console.log('════════════════════════════════════');
console.log(`  RÉSULTAT : ${pass} PASS / ${fail} FAIL`);
console.log('════════════════════════════════════');
process.exit(fail > 0 ? 1 : 0);
