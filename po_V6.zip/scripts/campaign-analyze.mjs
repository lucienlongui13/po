/**
 * campaign-analyze.mjs — Analyse des campagnes + simulation 127 → 207.
 * ====================================================================
 * 1. Charge les campagnes (S5/S10), répare les attributions manquantes
 *    (scan des logs « signal accepted for execution — règle c-bos… »).
 * 2. Cellules : combinaison × expiration → n/win/loss/tie, win rate,
 *    payout moyen (payouts dynamiques PO observés).
 * 3. SIMULATION FIDÈLE (sémantique backend asset-contexts.ts) :
 *    - mise = base × 2^min(consecutiveLosses, cap)   (cap = maxMartingaleSteps)
 *    - clamp : si mise > solde → mise = max(1, floor(solde))
 *    - WIN → solde += mise × payout ; cl = 0
 *    - LOSS → solde -= mise ; cl++ ; si cl > cap → cl = 0 (retour mise initiale)
 *    - TIE → rien (état neutre v17)
 * 4. Replay réel : chaque cellule rejouée depuis 127 (base 10) → parcours
 *    du solde, atteinte de 207 ?
 * 5. Bootstrap Monte-Carlo (10 000 tirages) : probabilité d'atteindre 207
 *    en ≤ 40 ordres par cellule.
 *
 * Usage :
 *   node scripts/campaign-analyze.mjs --in /tmp/campaign-s5.json,/tmp/campaign-s10.json \
 *     --start 127 --target 207 --base 10 --cap 5
 */
import * as fs from 'node:fs';

const args = process.argv.slice(2);
const arg = (name, def) => {
  const i = args.indexOf(`--${name}`);
  return i >= 0 && args[i + 1] != null ? args[i + 1] : def;
};
const INPUTS = arg('in', '/tmp/campaign-s5.json,/tmp/campaign-s10.json').split(',');
const START = Number(arg('start', 127));
const TARGET = Number(arg('target', 207));
const BASE = Number(arg('base', 10));
const CAP = Number(arg('cap', 5));
const BOOT = Number(arg('boot', 10000));

const COMBO_LABEL = {
  'c-bos': 'BOS Up → CALL ▲',
  'c-choch': 'CHoCH Up → CALL ▲',
  'c-cisd': 'CISD Up → CALL ▲',
  'p-bos': 'BOS Down → PUT ▼',
  'p-choch': 'CHoCH Down → PUT ▼',
  'p-cisd': 'CISD Down → PUT ▼',
};

/* ── Réparation d'attribution par les logs ── */
function repairAttribution(campaign) {
  const logLines = (campaign.logs ?? [])
    .map(l => ({ ts: typeof l.ts === 'number' ? l.ts : Date.parse(l.ts), message: l.message }))
    .filter(l => l.ts > 0 && /signal accepted for execution/.test(l.message));
  let repaired = 0;
  for (const o of campaign.orders ?? []) {
    if (o.matchedRuleId) continue;
    const m = (o.reason ?? '').match(/règle (c-bos|c-choch|c-cisd|p-bos|p-choch|p-cisd)/);
    if (m) { o.matchedRuleId = m[1]; repaired++; continue; }
    // Dernier recours : ligne de log la plus proche AVANT l'ordre sur le même asset
    const near = logLines
      .filter(l => /signal accepted/.test(l.message))
      .filter(l => Math.abs(l.ts - o.ts) < 4000)
      .filter(l => l.message.includes(String(o.asset ?? '')))
      .sort((a, b) => Math.abs(a.ts - o.ts) - Math.abs(b.ts - o.ts))[0];
    if (near) {
      const m2 = near.message.match(/règle (c-bos|c-choch|c-cisd|p-bos|p-choch|p-cisd)/);
      if (m2) { o.matchedRuleId = m2[1]; repaired++; }
    }
  }
  return repaired;
}

/* ── Cellules combinaison × expiration ── */
function buildCells(campaigns) {
  const cells = new Map();
  for (const camp of campaigns) {
    for (const o of camp.orders ?? []) {
      if (!o.settled) continue;
      const rule = o.matchedRuleId ?? '?';
      const exp = o.expirationSeconds ?? null;
      if (exp == null) continue; // ordre sans expiration fiable → exclu des cellules
      const key = `${rule}|${exp}s|${camp.config.timeframe}`;
      if (!cells.has(key)) cells.set(key, { rule, exp, tf: camp.config.timeframe, outcomes: [], payouts: [], events: [] });
      const c = cells.get(key);
      c.outcomes.push({ result: o.result, payout: o.payoutPct ?? null, profit: o.profit, amount: o.amount });
      if (o.payoutPct != null) c.payouts.push(o.payoutPct);
      if ((o.events ?? []).length > 1) c.events.push(o.events.join('+'));
    }
  }
  return cells;
}

/* ── Simulation fidèle du moteur de mises ── */
function simulateStep(balance, cl, outcome, base, cap) {
  const step = Math.max(0, Math.min(Math.floor(cl), cap));
  let amount = base * Math.pow(2, step);
  if (amount > balance) amount = Math.max(1, Math.floor(balance));
  if (balance < 1) return { balance, cl, amount: 0, bust: true };
  if (outcome.result === 'WIN') {
    const payout = (outcome.payout ?? 92) / 100;
    const next = balance + amount * payout;
    return { balance: next, cl: 0, amount, profit: amount * payout, bust: false };
  }
  if (outcome.result === 'LOSS') {
    const next = balance - amount;
    let ncl = cl + 1;
    if (ncl > cap) ncl = 0; // garde-fou v19 : retour à la mise initiale
    return { balance: next, cl: ncl, amount, profit: -amount, bust: next < 1 };
  }
  return { balance, cl, amount, profit: 0, bust: false }; // TIE neutre
}

function replayFrom(outcomes, startBalance, base, cap, target) {
  let balance = startBalance, cl = 0;
  const path = [{ i: 0, balance, amount: 0, result: null }];
  let hitAt = null, bustAt = null;
  for (let i = 0; i < outcomes.length; i++) {
    const st = simulateStep(balance, cl, outcomes[i], base, cap);
    if (st.bust && st.amount === 0) { bustAt = i + 1; break; }
    balance = st.balance; cl = st.cl;
    path.push({ i: i + 1, balance: Number(balance.toFixed(2)), amount: st.amount, result: outcomes[i].result, profit: st.profit != null ? Number(st.profit.toFixed(2)) : 0 });
    if (hitAt == null && balance >= target) hitAt = i + 1;
    if (balance < 1) { bustAt = i + 1; break; }
  }
  return { finalBalance: Number(balance.toFixed(2)), hitAt, bustAt, path, nOrders: path.length - 1 };
}

/* PRNG déterministe (mulberry32) pour la reproductibilité */
function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function bootstrap(outcomes, startBalance, base, cap, target, maxOrders, draws) {
  const rnd = mulberry32(20260920);
  let hits = 0, finals = [];
  for (let d = 0; d < draws; d++) {
    let balance = startBalance, cl = 0, hit = false;
    for (let i = 0; i < maxOrders; i++) {
      if (balance < 1) break;
      const o = outcomes[Math.floor(rnd() * outcomes.length)];
      const st = simulateStep(balance, cl, o, base, cap);
      if (st.bust && st.amount === 0) break;
      balance = st.balance; cl = st.cl;
      if (balance >= target) { hit = true; break; }
    }
    if (hit) hits++;
    finals.push(balance);
  }
  finals.sort((a, b) => a - b);
  return {
    pHit: Number((hits / draws).toFixed(3)),
    median: Number(finals[Math.floor(draws / 2)].toFixed(2)),
    p10: Number(finals[Math.floor(draws * 0.1)].toFixed(2)),
    p90: Number(finals[Math.floor(draws * 0.9)].toFixed(2)),
  };
}

/* ── Main ── */
function main() {
  const campaigns = INPUTS.map(p => {
    const c = JSON.parse(fs.readFileSync(p, 'utf8'));
    c._file = p;
    return c;
  });

  let repairedTotal = 0;
  for (const c of campaigns) repairedTotal += repairAttribution(c);

  const cells = buildCells(campaigns);
  const rows = [];
  for (const [key, c] of cells) {
    const n = c.outcomes.length;
    const wins = c.outcomes.filter(o => o.result === 'WIN').length;
    const losses = c.outcomes.filter(o => o.result === 'LOSS').length;
    const ties = c.outcomes.filter(o => o.result === 'TIE').length;
    const winRate = n ? wins / n : 0;
    const avgPayout = c.payouts.length ? c.payouts.reduce((s, p) => s + p, 0) / c.payouts.length : null;
    const replay = replayFrom(c.outcomes, START, BASE, CAP, TARGET);
    const boot = bootstrap(c.outcomes, START, BASE, CAP, TARGET, 40, BOOT);
    rows.push({
      key, rule: c.rule, label: COMBO_LABEL[c.rule] ?? c.rule, exp: c.exp, tf: c.tf,
      n, wins, losses, ties, winRate: Number(winRate.toFixed(3)),
      avgPayout: avgPayout != null ? Number(avgPayout.toFixed(1)) : null,
      replayFinal: replay.finalBalance, replayHitAt: replay.hitAt, replayBustAt: replay.bustAt,
      bootP: boot.pHit, bootMedian: boot.median, bootP10: boot.p10, bootP90: boot.p90,
      confluences: [...new Set(c.events)],
    });
  }

  // Global : toutes campagnes confondues
  const allOutcomes = campaigns.flatMap(c => (c.orders ?? []).filter(o => o.settled && o.matchedRuleId && o.expirationSeconds != null)
    .map(o => ({ result: o.result, payout: o.payoutPct ?? null })));
  const globalReplay = replayFrom(allOutcomes, START, BASE, CAP, TARGET);
  const globalBoot = bootstrap(allOutcomes, START, BASE, CAP, TARGET, 40, BOOT);

  // Résumé par campagne (P&L réel sur le compte démo)
  const campSummaries = campaigns.map(c => {
    const orders = (c.orders ?? []).filter(o => o.settled);
    const pnl = orders.reduce((s, o) => s + (o.profit ?? 0), 0);
    return {
      file: c._file, timeframe: c.config?.timeframe, orders: orders.length,
      wins: orders.filter(o => o.result === 'WIN').length,
      losses: orders.filter(o => o.result === 'LOSS').length,
      ties: orders.filter(o => o.result === 'TIE').length,
      pnl: Number(pnl.toFixed(2)),
      startBalance: c.startBalance, endBalance: c.balance,
      unattributed: (c.orders ?? []).filter(o => !o.matchedRuleId).length,
      noExpiry: (c.orders ?? []).filter(o => o.expirationSeconds == null).length,
    };
  });

  // Tri : d'abord celles qui atteignent 207 en replay, puis proba bootstrap, puis win rate
  rows.sort((a, b) => (b.replayHitAt ?? 999) - (a.replayHitAt ?? 999) === 0 ? 0 : (a.replayHitAt ?? 999) - (b.replayHitAt ?? 999));
  rows.sort((a, b) => {
    const score = r => (r.replayHitAt != null ? 2 : 0) + r.bootP + r.winRate;
    return score(b) - score(a);
  });

  const result = {
    when: new Date().toISOString(),
    params: { start: START, target: TARGET, base: BASE, cap: CAP, maxOrders: 40, bootDraws: BOOT },
    repairedTotal,
    campSummaries,
    global: {
      outcomes: allOutcomes.length,
      winRate: Number((allOutcomes.filter(o => o.result === 'WIN').length / (allOutcomes.length || 1)).toFixed(3)),
      replay: { finalBalance: globalReplay.finalBalance, hitAt: globalReplay.hitAt, bustAt: globalReplay.bustAt },
      boot: globalBoot,
    },
    cells: rows,
  };
  fs.writeFileSync('/tmp/campaign-analysis.json', JSON.stringify(result, null, 2));

  /* ── Sortie console lisible ── */
  console.log('═══════════════════════════════════════════════════════════════════');
  console.log(`  ANALYSE — ${START} → ${TARGET} en ≤ 40 ordres (base ${BASE}, martingale cap ${CAP})`);
  console.log(`  Attributions réparées par logs : ${repairedTotal}`);
  console.log('═══════════════════════════════════════════════════════════════════');
  for (const s of campSummaries) {
    console.log(`  ${s.timeframe}: ${s.orders} ordres réglés | ${s.wins}W/${s.losses}L${s.ties ? `/${s.ties}T` : ''} | P&L réel ${s.pnl} | non attribués: ${s.unattributed}, sans expiration: ${s.noExpiry}`);
  }
  console.log('');
  console.log('  Cellule (combinaison | expiration | TF) — n, win%, payout — replay 127→207 — bootstrap');
  for (const r of rows) {
    console.log(`  ${r.label.padEnd(18)} exp ${String(r.exp).padStart(3)}s ${r.tf} | n=${r.n} WR=${(r.winRate * 100).toFixed(0)}% pay=${r.avgPayout ?? '—'}% | final=${r.replayFinal}${r.replayHitAt != null ? ` ATTEINT à l'ordre ${r.replayHitAt}` : ''}${r.replayBustAt != null ? ` BUST ordre ${r.replayBustAt}` : ''} | P(207≤40)=${(r.bootP * 100).toFixed(0)}% médiane=${r.bootMedian}`);
  }
  console.log('');
  console.log(`  GLOBAL (tous ordres): n=${result.global.outcomes} WR=${(result.global.winRate * 100).toFixed(0)}% | replay final=${result.global.replay.finalBalance} (hit ordre ${result.global.replay.hitAt ?? '—'}) | P(207≤40)=${(result.global.boot.pHit * 100).toFixed(1)}%`);
  console.log('═══════════════════════════════════════════════════════════════════');
  console.log('  Analyse détaillée : /tmp/campaign-analysis.json');
}

main();
