/**
 * PROBE — what does piner's ta.valuewhen() return when the condition NEVER fired?
 * (Main.pine's swing library depends on it: shp(0)/slp(0) → line.new coordinates)
 *
 * Reproduces the app's exact pipeline: compileAsync + Engine + ArrayFeed on a
 * 26-bar synthetic dataset with prices ~1.158 (like the live EURUSD_otc session).
 */
import { compileAsync, Engine, ArrayFeed } from '@heyphat/piner'
import { asPinerRegistry, importLibraryBundle } from '../src/lib/pine-libraries'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'

const LIB_DIR = 'upload/piracy_extracted/Market_structures_scripts'
const files = [
  { name: 'libs/PubLibCandleTrend.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibCandleTrend.pine'), 'utf8') },
  { name: 'libs/PubLibSwing.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibSwing.pine'), 'utf8') },
  { name: 'libs/PubLibTrend.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibTrend.pine'), 'utf8') },
  { name: 'libs/PubLibUtility.pine', source: readFileSync(join(LIB_DIR, 'libs/PubLibUtility.pine'), 'utf8') },
  { name: 'Main.pine', source: readFileSync(join(LIB_DIR, 'Main.pine'), 'utf8') },
]
importLibraryBundle(files)

// 26 synthetic bars, trending up from 1.1572 → 1.1589 (like the live session)
const bars = []
let price = 1.1572
for (let i = 0; i < 26; i++) {
  price += 0.00006 * (i % 3 === 0 ? -0.4 : 1)
  const o = price, c = price + 0.00007
  bars.push({
    time: 1789439220000 + i * 60_000,
    open: o, high: Math.max(o, c) + 0.00003, low: Math.min(o, c) - 0.00003, close: c,
    volume: 100 + i,
  })
}

const source = `
//@version=6
indicator("valuewhen probe", overlay=true)
cond = close > 999999
v0 = ta.valuewhen(cond, high, 0)
v1 = ta.valuewhen(cond, high, 1)
lbl = label.new(bar_index, close, "v0=" + str.tostring(v0) + " v1=" + str.tostring(v1) + " na0=" + str.tostring(na(v0)), style=label.style_label_left)
`

const main = async () => {
  // 1) bare valuewhen probe
  const compiled = await compileAsync(source, { libraries: asPinerRegistry(), resolveLibrary: (id) => asPinerRegistry().find((l) => l.key === id.canonical)?.source })
  const engine = new Engine(compiled as any, new ArrayFeed(bars) as any, { symbol: 'EURUSD_otc', timeframe: '1' })
  await engine.run({ symbol: 'EURUSD_otc', timeframe: '1', mintick: 0.00001 })
  const drawings = (engine as any).drawings as any[]
  console.log('── bare ta.valuewhen(cond-never-true) probe ──')
  for (const d of drawings.slice(-3)) {
    console.log(JSON.stringify(d?.props ?? d))
  }

  // 2) the REAL Main.pine on the same 26 bars
  const compiled2 = await compileAsync(files[4].source, { libraries: asPinerRegistry(), resolveLibrary: (id) => asPinerRegistry().find((l) => l.key === id.canonical)?.source })
  const engine2 = new Engine(compiled2 as any, new ArrayFeed(bars) as any, undefined)
  await engine2.run({ symbol: 'EURUSD_otc', timeframe: '1', mintick: 0.00001 })
  const d2 = (engine2 as any).drawings as any[]
  console.log(`\n── Main.pine on 26 bars → ${d2.length} drawings ──`)
  const prices: number[] = []
  for (const d of d2) {
    const p = d?.props ?? {}
    for (const k of ['y1', 'y2', 'top', 'bottom']) {
      const v = p[k]
      if (typeof v === 'number' && Number.isFinite(v)) prices.push(v)
      else if (v && typeof v === 'object' && typeof v.value === 'number') prices.push(v.value)
    }
  }
  if (prices.length) {
    console.log('drawing y price range:', Math.min(...prices).toFixed(6), '…', Math.max(...prices).toFixed(6))
    console.log('candle range: 1.157 … 1.159 → OUT OF RANGE?', Math.min(...prices) < 1.15 || Math.max(...prices) > 1.17)
  }
  // dump a few line props raw
  for (const d of d2.filter((x) => x.type === 'line').slice(0, 6)) {
    console.log('line:', JSON.stringify(d.props))
  }
}
main().catch((e) => { console.error('FAIL', e); process.exit(1) })
