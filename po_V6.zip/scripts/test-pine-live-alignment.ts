/**
 * test-pine-live-alignment.ts — v1.9 regression suite (spec §18).
 *
 * THE invariant: a signal generated at bar T stays at bar T, forever —
 * across +1 / +5 / +10 / +100 new bars, full coordinator pipeline
 * (snapshot → revision → single-flight execution → freshness check →
 * atomic commit), real Pine executions of the spec §19 Alignment Probe.
 *
 * This is the dynamic, cumulative validation the spec demands:
 *   initial load → new bar → new bar → … → NO retrograde movement, ever.
 */
import { usePineStore } from '../src/lib/pine-store'
import { pineCoordinator } from '../src/lib/pine-executor'
import { toPineTime, pineTimeToChartTime } from '../src/lib/pine-time-axis'
import {
  ALIGNMENT_PROBE_SRC, makeCandles, makeChecker, resetPineState,
  waitForIdle, waitForStore, allScriptsAtRevision, storeScript, timeOfIndex,
} from './pine-live-test-utils'

const { ok, finish } = makeChecker()

const TF_SEC = 60
const OPTS = { startTime: 1789439220, tfSec: TF_SEC }

async function commitNewBars(candles: any[], add: number): Promise<number> {
  for (let k = 0; k < add; k++) {
    const prev = candles[candles.length - 1]
    const t = prev.time + TF_SEC
    const c = prev.close + Math.sin(k) * 3e-5
    candles.push({
      time: t,
      open: prev.close, high: Math.max(prev.close, c) + 9e-5, low: Math.min(prev.close, c) - 7e-5,
      close: c, volume: 100 + candles.length,
    })
  }
  pineCoordinator.notifyDataset(candles, 'new-bar')
  const rev = pineCoordinator.stats().revision
  await waitForStore(() => allScriptsAtRevision(rev), 10000, `commit at revision ${rev}`)
  await waitForIdle()
  return rev
}

async function main() {
  resetPineState()

  console.log('── 1. initial dataset (100 bars) + first execution ──')
  const candles = makeCandles(100, OPTS)
  const scriptId = usePineStore.getState().addScript(ALIGNMENT_PROBE_SRC, 'Alignment Probe')
  pineCoordinator.setContext({ asset: 'EURUSD_otc', timeframe: TF_SEC })
  pineCoordinator.notifyDataset(candles, 'init')
  const rev1 = pineCoordinator.stats().revision
  await waitForStore(() => allScriptsAtRevision(rev1), 15000, 'initial commit')
  await waitForIdle()

  let script = storeScript(scriptId)!
  let result = script.result!
  ok('initial result exists', result != null)
  ok('initial envelope describes the dataset (100 bars, last bar time)',
    script.envelope?.barCount === 100 && script.envelope?.lastBarTime === candles[99].time)
  ok('initial result timeline ends on the last candle (ms)',
    result._times![result._times!.length - 1] === toPineTime(candles[99].time))

  // Reference signal: bar 50 (50 % 10 == 0 → plotshape fires there).
  const T50 = timeOfIndex(50, OPTS)
  const T50ms = toPineTime(T50)
  const idxT50 = result._times!.indexOf(T50ms)
  ok('probe signal exists at bar 50', idxT50 >= 0 && result.markers[0].data[idxT50] != null)
  const labelAtT50 = result.drawings.find((d) => d.kind === 'label' && d.x === T50ms) as any
  ok('probe label "50" exists at barTime(50)', labelAtT50?.text === '50')

  // Marker set snapshot: every bar time where a marker fired.
  const markerTimes = (): number[] => {
    const r = storeScript(scriptId)!.result!
    const out: number[] = []
    const md = r.markers[0]?.data ?? []
    for (let i = 0; i < md.length; i++) if (md[i] != null) out.push(r._times![i])
    return out
  }
  const labelTimes = (): number[] =>
    (storeScript(scriptId)!.result!.drawings.filter((d: any) => d.kind === 'label') as any[])
      .map((d: any) => d.x).sort((a: number, b: number) => a - b)

  /** Probe ground truth: signal fires on every %10 bar index. */
  const expectedMarkers = (barCount: number): number[] => {
    const out: number[] = []
    for (let i = 0; i < barCount; i++) if (i % 10 === 0) out.push(toPineTime(timeOfIndex(i, OPTS)))
    return out
  }
  const expectedLabels = (barCount: number): number[] => {
    const out: number[] = []
    for (let i = 0; i < barCount; i++) out.push(toPineTime(timeOfIndex(i, OPTS)))
    return out
  }

  const initialMarkers = markerTimes()
  const initialLabels = labelTimes()
  ok('10 markers on the initial 100 bars (every 10th bar)', initialMarkers.length === 10)
  ok('100 labels on the initial 100 bars', initialLabels.length === 100)
  ok('initial marker set matches the probe ground truth',
    JSON.stringify(initialMarkers) === JSON.stringify(expectedMarkers(100)))

  // ── 2. +1 bar ────────────────────────────────────────────────────
  console.log('── 2. +1 bar: nothing may move ──')
  const rev2 = await commitNewBars(candles, 1)
  script = storeScript(scriptId)!
  result = script.result!
  ok('revision bumped on the new bar', rev2 > rev1)
  ok('envelope follows the new dataset', script.envelope?.barCount === 101 && script.envelope?.lastBarTime === candles[100].time)
  ok('result timeline includes the new bar', result._times![result._times!.length - 1] === toPineTime(candles[100].time))
  ok('OLD markers keep their EXACT timestamps (+1 bar — only the NEW bar 100 signal is appended)',
    JSON.stringify(markerTimes()) === JSON.stringify(expectedMarkers(101)))
  ok('OLD labels keep their EXACT timestamps (+1 bar)',
    JSON.stringify(labelTimes()) === JSON.stringify(expectedLabels(101)))
  const label50after1 = (result.drawings.find((d: any) => d.kind === 'label' && d.text === '50') as any)
  ok('label "50" still anchored on barTime(50) after +1 bar', label50after1?.x === T50ms)

  // ── 3. +5 bars ────────────────────────────────────────────────────
  console.log('── 3. +5 bars: no cumulative shift ──')
  await commitNewBars(candles, 5)
  ok('markers exactly the ground truth after +6 total bars (no new signal bar in 101-105)',
    JSON.stringify(markerTimes()) === JSON.stringify(expectedMarkers(106)))
  ok('label "50" still at barTime(50) after +6 total bars',
    (storeScript(scriptId)!.result!.drawings.find((d: any) => d.kind === 'label' && d.text === '50') as any)?.x === T50ms)

  // ── 4. +10 bars ───────────────────────────────────────────────────
  console.log('── 4. +10 bars: no cumulative shift ──')
  await commitNewBars(candles, 10)
  const m4 = markerTimes()
  ok('markers exactly the ground truth after +16 total bars (olds intact + new signal bar 110)',
    JSON.stringify(m4) === JSON.stringify(expectedMarkers(116))
    && m4.slice(0, initialMarkers.length).every((t, i) => t === initialMarkers[i]))
  ok('label "50" still at barTime(50) after +16 total bars',
    (storeScript(scriptId)!.result!.drawings.find((d: any) => d.kind === 'label' && d.text === '50') as any)?.x === T50ms)

  // ── 5. +100 bars — the decisive cumulative test ───────────────────
  console.log('── 5. +100 bars: cumulative drift check ──')
  const revBefore = pineCoordinator.stats().revision
  await commitNewBars(candles, 100)
  script = storeScript(scriptId)!
  result = script.result!
  ok('revision advanced well beyond the original', pineCoordinator.stats().revision > revBefore)
  ok('envelope: 216 bars, last bar current', script.envelope?.barCount === 216 && script.envelope?.lastBarTime === candles[215].time)
  const m5 = markerTimes()
  ok('every ORIGINAL marker timestamp still present and identical',
    initialMarkers.every((t, i) => m5[i] === t))
  ok('marker set equals the probe ground truth on 216 bars (olds + new signal bars)',
    JSON.stringify(m5) === JSON.stringify(expectedMarkers(216)))
  const label50final = (result.drawings.find((d: any) => d.kind === 'label' && d.text === '50') as any)
  ok('SIGNAL AT T STAYS AT T: label "50" still at barTime(50) after +116 bars',
    label50final?.x === T50ms)
  ok('labels never drifted: all 216 labels on distinct increasing timestamps',
    (() => {
      const ls = labelTimes()
      return ls.length === 216 && ls.every((t, i) => i === 0 || t > ls[i - 1])
    })())
  ok('marker at barTime(50) is still a signal bar',
    (() => {
      const r = storeScript(scriptId)!.result!
      const i = r._times!.indexOf(T50ms)
      return i >= 0 && r.markers[0].data[i] != null
    })())

  // ── 6. dataset replacement (replay seek / history reload) ─────────
  console.log('── 6. dataset replace keeps invariants ──')
  const shorter = candles.slice(0, 150)
  pineCoordinator.notifyDataset(shorter, 'replace')
  const revR = pineCoordinator.stats().revision
  await waitForStore(() => allScriptsAtRevision(revR), 10000, 'replace commit')
  await waitForIdle()
  script = storeScript(scriptId)!
  ok('replace → envelope describes the 150-bar prefix', script.envelope?.barCount === 150)
  ok('replace → result timeline = prefix timeline',
    script.result!._times![script.result!._times!.length - 1] === toPineTime(shorter[149].time))
  ok('replace → label "50" STILL at barTime(50)',
    (script.result!.drawings.find((d: any) => d.kind === 'label' && d.text === '50') as any)?.x === T50ms)

  resetPineState()
  console.log()
  finish('test-pine-live-alignment')
}

main().catch((err) => {
  console.error('FATAL:', err)
  process.exit(1)
})
