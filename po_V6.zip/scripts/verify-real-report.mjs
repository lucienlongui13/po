/**
 * verify-real-report.mjs — VERDICT FINAL du test réel Martingale BOS.
 * ============================================================================
 * Analyse le rapport JSON capturé pendant le test réel (login identifiants
 * par défaut, 2 assets, S5, exp 3s, base 500, martingale) et vérifie chaque
 * transition : LOSS → mise ×2, WIN → retour à la base — AVEC prise en compte
 * du CLAMP DE SOLDE (computeBettingAmount borne le montant au solde disponible).
 *
 * Sources de vérité :
 *   - chaque ordre porte son résultat fusionné (result/profit) par dealId ;
 *   - l'expiration de chaque ordre est lue dans les logs backend du rapport
 *     (« trade opened — … expiry=Ns ») ;
 *   - le solde est reconstruit : solde_initial + Σ profits des ordres réglés
 *     avant chaque ordre (les mises en vol sont décomptées par le broker —
 *     la reconstruction est une BORNE SUP de ce que le moteur pouvait miser).
 *
 * Exécution : node scripts/verify-real-report.mjs [chemin-du-rapport.json]
 */
import * as fs from 'node:fs';

const REPORT = process.argv[2] ?? '/home/z/my-project/download/test-real-bos-martingale-report.json';
const raw = JSON.parse(fs.readFileSync(REPORT, 'utf8'));

const BASE = raw.config?.BASE ?? raw.config?.baseAmount ?? 500;
const EXPIRY = raw.config?.EXPIRY ?? raw.config?.expiry ?? 3;

// ── Ordres BOS uniques, triés chronologiquement (résultat déjà fusionné) ──
const orders = (raw.orders ?? [])
  .filter(o => o.source === 'l_lucien_protrader')
  .sort((a, b) => a.ts - b.ts);

// ── Expirations réellement placées, depuis les logs backend du rapport ──
const logText = (raw.martingaleLogs ?? []).map(l => l.message ?? '').join('\n');
const expiryLines = [...logText.matchAll(/trade opened — (?:CALL|PUT) @ [0-9.]+ \(amount=([0-9.]+), expiry=(\d+)s/g)];

// ── Solde initial annoncé par le backend ──
let startBalance = raw.startBalance ?? null;
if (startBalance == null) {
  const sb = logText.match(/start balance: ([0-9.]+)/);
  if (sb) startBalance = parseFloat(sb[1]);
}

console.log('════════════════════════════════════════════════════════════════');
console.log('  VERDICT FINAL — Martingale BOS/CHoCH/CISD (test broker RÉEL)');
console.log('════════════════════════════════════════════════════════════════');
console.log(`  Rapport       : ${REPORT}`);
console.log(`  Ordres BOS    : ${orders.length}`);
console.log(`  Solde initial : ${startBalance ?? 'inconnu'}`);
console.log(`  Base / expiry : ${BASE} / ${EXPIRY}s`);

const checks = [];
const ok = (cond, label) => { checks.push(!!cond); console.log(`  ${cond ? '✓' : '✗'} ${label}`); };

// ── 1. BOS place des ordres ──
ok(orders.length >= 20, `≥ 20 ordres BOS placés (${orders.length})`);
const exps = [...new Set(expiryLines.map(m => Number(m[2])))];
ok(expiryLines.length >= orders.length && exps.every(e => e === EXPIRY),
  `expiration de chaque ordre = ${EXPIRY}s (logs backend : ${expiryLines.length} ordres, expirations ${exps.join(', ')})`);
const assets = [...new Set(orders.map(o => o.asset))];
ok(assets.length >= 2, `ordres sur ≥ 2 assets (${assets.join(', ')})`);

// ── 2. Rattachement des règlements (résultat fusionné sur chaque ordre) ──
const nSettled = orders.filter(o => o.result != null).length;
const nUnsettled = orders.length - nSettled;
ok(nSettled >= orders.length - 1, `règlements rattachés aux ordres : ${nSettled}/${orders.length}${nUnsettled ? ` (${nUnsettled} en vol à la coupure du test)` : ''}`);

// ── 3. Martingale PAR ASSET (avec clamp de solde) ──
console.log('\n  ── Séquences par asset ──');
let strictOK = 0, clampOK = 0, fails = [];
let allOK = true;
for (const asset of assets) {
  const ordersA = orders.filter(o => o.asset === asset);
  console.log(`  ${asset} : ${ordersA.length} ordres`);
  console.log(`    mises    : ${ordersA.map(o => o.amount).join(' → ')}`);
  console.log(`    résultats: ${ordersA.map(o => o.result ?? '?').join(' ')}`);

  for (let i = 0; i + 1 < ordersA.length; i++) {
    const cur = ordersA[i], next = ordersA[i + 1];
    if (cur.result == null) continue;
    const expected = cur.result === 'WIN' ? BASE : cur.amount * 2;
    if (next.amount === expected) { strictOK++; continue; }

    // Clamp de solde : le solde reconstruit AVANT l'ordre suivant est
    // inférieur au montant attendu → le moteur a misé tout le disponible.
    if (startBalance != null && next.amount < expected) {
      const balanceBeforeNext = startBalance + orders
        .filter(o => o.result != null && o.ts < next.ts)
        .reduce((n, o) => n + Number(o.profit ?? 0), 0);
      if (expected > balanceBeforeNext && next.amount <= Math.floor(balanceBeforeNext) + 1) {
        clampOK++;
        console.log(`    ⚠ ${cur.result} → ${next.amount}$ (attendu ${expected}$) — CLAMP SOLDE (${balanceBeforeNext.toFixed(2)} disponibles)`);
        continue;
      }
    }
    fails.push(`${asset}: ${cur.result} (mise ${cur.amount}$) → mise suivante ${next.amount}$, attendu ${expected}$`);
    allOK = false;
  }
}
console.log(`\n  Transitions martingale : ${strictOK} strictes ✓, ${clampOK} clampées au solde ⚠, ${fails.length} échouées ✗`);
if (fails.length) fails.forEach(f => console.log(`    ✗ ${f}`));

ok(allOK, `Martingale : chaque LOSS → ×2, chaque WIN → ${BASE} (hors clamp de solde)`);
ok(strictOK >= 5, `au moins 5 transitions STRICTES vérifiées (${strictOK})`);

const nWin = orders.filter(o => o.result === 'WIN').length;
const nLoss = orders.filter(o => o.result === 'LOSS').length;
ok(nWin > 0 && nLoss > 0, `les deux issues observées : ${nWin} WIN, ${nLoss} LOSS`);

// ── 4. Le bug d'origine est-il présent ? ──
const placeholders = (raw.placeholders ?? []).filter(p => p.inTest !== false);
ok(placeholders.length === 0,
  `AUCUN règlement dégradé deal#0/asset-vide pendant le test (${placeholders.length} — le bug d'origine en produisait un par ordre)`);

// ── 5. Cohérence des montants avec les logs backend ──
const loggedAmounts = expiryLines.map(m => Number(m[1]));
ok(loggedAmounts.length >= orders.length,
  `chaque ordre apparaît dans les logs backend avec sa mise (${loggedAmounts.length} lignes / ${orders.length} ordres)`);

const passed = checks.filter(Boolean).length;
console.log(`\n════ VERDICT : ${passed}/${checks.length} vérifications OK — ${checks.every(Boolean) ? 'MARTINGALE VALIDÉE SUR BROKER RÉEL ✓' : 'ÉCHEC ✗'} ════`);
process.exit(checks.every(Boolean) ? 0 : 2);
