#!/usr/bin/env python3
"""patch-piner-intdiv.py — TradingView-exact integer division for piner.

Pine (v1–v6) defines `/` between two int operands as INTEGER division
(truncated). piner 0.13.0 evaluates it as JS float division, so
`ta.wma(close, len / 2)` receives 10.5 for len=21 and returns na forever
(Ta.wma: buf.length < 10.5 is always true). This patch:

  1. sema:        `/` types as int when both operands are int
  2. codegen:     `/` emits `$.idiv` when statically int
  3. interpreter: `/` calls `$.idiv` when statically int
  4. runtime:     new `idiv` helper (trunc toward zero, na-safe)
  5. const folds: int/int literals truncate

Also patches $.eq/$.ne for Pine v3 bool<->int interchangeability
(`alert_bar == 1` where alert_bar is a bool series — strict JS equality
returned false for every bar). Valid v5/v6 scripts never compare bool to
number (type error on TradingView), so the coercion only affects legacy
code.

Applied to dist/index.js AND dist/index.cjs. Re-generate the patch-package
patch afterwards: npx patch-package @heyphat/piner
"""
import sys

EDITS = [
    # 1. runtime helper — add idiv after div
    (
        "  div(a, b) {\n    return num(a) / num(b);\n  }",
        "  div(a, b) {\n    return num(a) / num(b);\n  }\n  idiv(a, b) {\n    const q = num(a) / num(b);\n    return Number.isFinite(q) ? Math.trunc(q) : q;\n  }",
        1,
    ),
    # 2. sema — `/` types as int when both operands int
    (
        "      case \"-\":\n      case \"*\":\n      case \"%\":\n        return e.type = isFloat(l) || isFloat(r) ? tFloat : tInt;\n      case \"/\":\n        return e.type = tFloat;",
        "      case \"-\":\n      case \"*\":\n      case \"%\":\n        return e.type = isFloat(l) || isFloat(r) ? tFloat : tInt;\n      case \"/\":\n        return e.type = isFloat(l) || isFloat(r) ? tFloat : tInt;",
        1,
    ),
    # 3. codegen — emit $.idiv when statically int
    (
        "      case \"/\":\n        return `$.div(${l}, ${r})`;",
        "      case \"/\":\n        return e.type?.kind === \"int\" ? `$.idiv(${l}, ${r})` : `$.div(${l}, ${r})`;",
        1,
    ),
    # 4. interpreter — call $.idiv when statically int
    (
        "      case \"/\":\n        return this.$.div(l, r);",
        "      case \"/\":\n        return e.type?.kind === \"int\" ? this.$.idiv(l, r) : this.$.div(l, r);",
        1,
    ),
    # 5. constValue fold — int/int truncates
    (
        "          if (e.op === \"/\")\n            return left / right;",
        "          if (e.op === \"/\")\n            return Number.isInteger(left) && Number.isInteger(right) ? Math.trunc(left / right) : left / right;",
        1,
    ),
    # 6. constantHistoryNumber fold — int/int truncates
    (
        "        case \"/\":\n          result = left / right;\n          break;",
        "        case \"/\":\n          result = Number.isInteger(left) && Number.isInteger(right) ? Math.trunc(left / right) : left / right;\n          break;",
        1,
    ),
    # 7. eq/ne — bool<->number coercion (Pine v3 interchangeability)
    (
        """  eq(a, b) {
    if (isNa(a) || isNa(b))
      return false;
    if (typeof a === "number" && typeof b === "number")
      return Math.round(a * 1e9) === Math.round(b * 1e9);
    return a === b;
  }""",
        """  eq(a, b) {
    if (isNa(a) || isNa(b))
      return false;
    if (typeof a === "number" && typeof b === "number")
      return Math.round(a * 1e9) === Math.round(b * 1e9);
    if (typeof a === "boolean" && typeof b === "number")
      return (a ? 1 : 0) === b;
    if (typeof b === "boolean" && typeof a === "number")
      return (b ? 1 : 0) === a;
    return a === b;
  }""",
        1,
    ),
]

FILES = [
    "/home/z/my-project/node_modules/@heyphat/piner/dist/index.js",
    "/home/z/my-project/node_modules/@heyphat/piner/dist/index.cjs",
]

for path in FILES:
    with open(path, encoding="utf-8") as f:
        src = f.read()
    for i, (old, new, expected) in enumerate(EDITS, 1):
        count = src.count(old)
        if count != expected:
            print(f"FAIL {path} edit {i}: found {count} occurrences (expected {expected})")
            sys.exit(1)
        src = src.replace(old, new)
        print(f"  ok edit {i} in {path.split('/')[-1]}")
    with open(path, "w", encoding="utf-8") as f:
        f.write(src)
    print(f"patched {path}")
print("ALL EDITS APPLIED")
