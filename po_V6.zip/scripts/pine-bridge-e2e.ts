/**
 * E2E validation of the REWRITTEN pine-engine bridge.
 * Runs every TradingView sample script through runPineScript() and asserts
 * the "no visual output" error is gone (outputCount > 0 via drawings).
 */
import { runPineScript, toPineTimeframe } from '../src/lib/pine-engine.ts'
import { readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'

// Deterministic synthetic OHLCV candles (5s bars to match the app's live feed)
function makeCandles(n = 800, start = 1_700_000_000_000, stepMs = 5_000) {
  const bars = []
  let price = 1.15
  let seed = 42
  const rand = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648 }
  for (let i = 0; i < n; i++) {
    const drift = (rand() - 0.5) * 0.002
    const open = price
    const close = open + drift
    const high = Math.max(open, close) + rand() * 0.0008
    const low = Math.min(open, close) - rand() * 0.0008
    bars.push({
      time: Math.floor((start + i * stepMs) / 1000),
      open: Number(open.toFixed(5)),
      high: Number(high.toFixed(5)),
      low: Number(low.toFixed(5)),
      close: Number(close.toFixed(5)),
      volume: Math.round(500 + rand() * 1500),
    })
    price = close
  }
  return bars
}

const candles = makeCandles()
let pass = 0, fail = 0, libSkipped = 0
const failures = []

async function test(name, source) {
  const res = await runPineScript(source, candles, { symbol: 'EURUSD_otc', timeframe: toPineTimeframe(5) })
  if (res.ok) {
    const r = res.result
    const drawTypes = {}
    for (const d of r.drawings) drawTypes[d.kind] = (drawTypes[d.kind] ?? 0) + 1
    const summary = [
      `${r.plots.length} plots`,
      `${r.markers.length} markers`,
      `${r.hlines.length} hlines`,
      `${r.fills.length} fills`,
      `${r.candles.length} candles`,
      `${r.drawings.length} drawings ${JSON.stringify(drawTypes)}`,
      `${r.alerts.length} alerts`,
      r.strategy ? `strategy(net=${r.strategy.netProfit.toFixed(2)}, trades=${r.strategy.closedTrades.length})` : '',
    ].filter(Boolean).join(' · ')
    console.log(`  ✓ ${name} — ${summary}`)
    pass++
  } else {
    const isLib = /library registry/i.test(res.error.message)
    if (isLib) {
      console.log(`  ⚠ ${name} — SKIPPED (imports a community library not registered locally)`)
      libSkipped++
    } else {
      console.log(`  ✗ ${name} — ${res.error.stage}: ${res.error.message.slice(0, 140)}`)
      failures.push(name)
      fail++
    }
  }
}

console.log(`Candles: ${candles.length} bars · timeframe=${toPineTimeframe(5)} (5s)`)

console.log('\n── samples/ ──')
for (const f of readdirSync(join(import.meta.dirname, '../samples')).filter((x) => x.endsWith('.pine'))) {
  await test(f, readFileSync(join(import.meta.dirname, '../samples', f), 'utf8'))
}

console.log('\n── TradingView_pine_scripts_samples/ ──')
const dir = join(import.meta.dirname, '../TradingView_pine_scripts_samples')
for (const f of readdirSync(dir).filter((x) => x.endsWith('.pine')).sort()) {
  await test(f, readFileSync(join(dir, f), 'utf8'))
}

console.log('\n──────────── RESULT ────────────')
console.log(`PASS: ${pass} · FAIL: ${fail} · LIB-SKIPPED: ${libSkipped}`)
if (failures.length) console.log('Failed:', failures.join(', '))
console.log(toPineTimeframe(5) === '5S' && toPineTimeframe(60) === '1' && toPineTimeframe(300) === '5' && toPineTimeframe(86400) === '1D' ? 'toPineTimeframe: OK' : 'toPineTimeframe: FAIL')
process.exit(fail === 0 ? 0 : 1)
