/**
 * test-auto-trade-socket.ts
 * Test d'intégration socket.io : vérifie le câblage des nouveaux handlers
 * auto-trade du backend (sans login Pocket Option).
 */
import { io } from 'socket.io-client';

const URL = 'http://localhost:3030';

let passed = 0, failed = 0;
function check(name: string, cond: boolean, detail?: string): void {
  if (cond) { passed++; console.log(`  ✓ ${name}`); }
  else { failed++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`); }
}

const socket = io(URL, { transports: ['websocket'], path: '/' });

const timeout = setTimeout(() => {
  console.log(`\nTIMEOUT — ${passed} passed, ${failed} failed`);
  process.exit(1);
}, 20000);

// Le status initial (émis à la connexion) doit inclure autoTrade.
let statusChecked = false;
socket.on('status', (st: any) => {
  if (statusChecked) return;
  statusChecked = true;
  check('status initial inclut autoTrade (min 3s)',
    st?.autoTrade && st.autoTrade.minExpirySeconds === 3,
    JSON.stringify(st?.autoTrade)?.slice(0, 120));
});

socket.on('connect', () => {
  console.log('connected to backend');

  // 1. get-auto-status → statut complet avec stratégies
  socket.emit('get-auto-status');
  socket.once('auto-trade-status', (s: any) => {
    check('get-auto-status renvoie le statut complet', s && typeof s === 'object');
    check('liste de stratégies présente', Array.isArray(s.strategies) && s.strategies.length >= 10, `${s.strategies?.length}`);
    // FIX (audit v6.5) — la liste a évolué : ai_coach et longui_lucien ont
    // été ajoutés EN TÊTE (v6.1+). L'intention du test (bos_magnet présent
    // dans le catalogue) est préservée sans dépendre de l'ordre.
    check('bos_magnet présent dans le catalogue', s.strategies?.some((x: any) => x.id === 'bos_magnet'));
    check('next_m1 présent dans le catalogue', s.strategies?.some((x: any) => x.id === 'next_m1'));
    check('minimum expiration = 3s', s.minExpirySeconds === 3);
    check('stats initiales', s.stats && typeof s.stats.signals === 'number');
    check('prochaine mise calculée', typeof s.nextBetAmount === 'number' && s.nextBetAmount >= 1);

    // 2. set-auto-strategy
    socket.emit('set-auto-strategy', { strategyId: 'pattern_engine' });
    socket.once('auto-trade-status', (s2: any) => {
      check('set-auto-strategy pattern_engine OK', s2.strategyId === 'pattern_engine');

      socket.emit('set-auto-strategy', { strategyId: 'bos_magnet' });
      socket.once('auto-trade-status', (s3: any) => {
        check('set-auto-strategy bos_magnet OK', s3.strategyId === 'bos_magnet');

        // 3. set-auto-config : martingale + expiration fixe 3s
        socket.emit('set-auto-config', {
          bettingStrategy: 'martingale',
          baseAmount: 2,
          expirationMode: 'fixed',
          expirySeconds: 3,
        });
        socket.once('auto-trade-status', (s4: any) => {
          check('set-auto-config martingale OK', s4.bettingStrategy === 'martingale');
          check('set-auto-config baseAmount=2 OK', s4.baseAmount === 2);
          check('set-auto-config mode fixed OK', s4.expirationMode === 'fixed');
          check('set-auto-config expiration 3s (minimum) OK', s4.fixedExpirySeconds === 3);

          // 4. expiration 1s → clamped au minimum 3s
          socket.emit('set-auto-config', { expirySeconds: 1 });
          socket.once('auto-trade-status', (s5: any) => {
            check('expiration 1s → clamped à 3s', s5.fixedExpirySeconds === 3, `${s5.fixedExpirySeconds}`);

            // 5. fibonacci + expiration 7s
            // FIX (audit v6.5) — v6.3 : l'expiration du champ est respectée À LA
            // SECONDE PRÈS (plus de snap vers BROKER_SUPPORTED_EXPIRIES) —
            // cf. RAPPORT-FINAL v6.3 §1 et tests I6-I8 de test-v63-integration.
            socket.emit('set-auto-config', { bettingStrategy: 'fibonacci', expirySeconds: 7 });
            socket.once('auto-trade-status', (s6: any) => {
              check('fibonacci OK', s6.bettingStrategy === 'fibonacci');
              check('expiration 7s respectée à la seconde près (v6.3)', s6.fixedExpirySeconds === 7, `${s6.fixedExpirySeconds}`);

              // 6. reset config + fin
              socket.emit('set-auto-config', { bettingStrategy: 'fixed', expirationMode: 'engine' });
              socket.once('auto-trade-status', (s7: any) => {
                check('reset fixed/engine OK', s7.bettingStrategy === 'fixed' && s7.expirationMode === 'engine');

                setTimeout(() => {
                  if (!statusChecked) check('status initial inclut autoTrade', false, 'aucun status reçu');
                  console.log(`\n${passed} passed, ${failed} failed`);
                  clearTimeout(timeout);
                  socket.disconnect();
                  process.exit(failed > 0 ? 1 : 0);
                }, 500);
              });
            });
          });
        });
      });
    });
  });
});

socket.on('connect_error', (err: any) => {
  console.log('CONNECT ERROR:', err.message);
  process.exit(1);
});
