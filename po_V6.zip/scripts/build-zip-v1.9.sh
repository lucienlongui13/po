#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v1.9.sh — Livraison v1.9 « Alignement live définitif »
#
# Le bug : à chaque nouvelle bougie, TOUTE la couche Pine se décalait d'une
# bougie vers la gauche (décalage cumulatif). Cause racine : le debounce de
# 350 ms de la ré-exécution Pine était annulé par chaque nouvelle référence
# de `candles` (une par flush rAF de tick) → il ne tirait JAMAIS pendant le
# stream → résultats figés sur l'historique initial.
#
# Le correctif v1.9 (spécification 33 sections) :
#   1. COORDINATEUR D'EXÉCUTION (pine-executor.ts) : snapshots immuables à
#      révision monotone, scheduler single-flight latest-result-wins, commit
#      atomique multi-scripts, throttle des ticks de bougie en formation,
#      barrière de contexte asset/timeframe ;
#   2. IDENTITÉ TEMPORELLE CANONIQUE (pine-time-axis.ts) : conversions
#      sec/ms uniques, alignement PAR TIMESTAMP UNIQUEMENT (les fallbacks
#      positionnels `values[len-n+i]` sont supprimés), validation de timeline,
#      diagnostics [PINE ALIGNMENT] ;
#   3. STORE à enveloppe de cohérence : un résultat obsolète ou étranger ne
#      peut JAMAIS réécrire un résultat plus récent.
#
# Sortie : /home/z/my-project/download/pine_v6_engine_v1.9.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v1.9"
FOLDER=pine_v6_engine_v1.9
OUT="$ROOT/download/pine_v6_engine_v1.9.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (mêmes exclusions que v1.0→v1.8) ─────────────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude 'upload/' \
  --exclude 'download/' \
  --exclude 'tool-results/' \
  --exclude '.stage-v1.1/' \
  --exclude '.stage-v1.2/' \
  --exclude '.stage-v1.3/' \
  --exclude '.stage-v1.4/' \
  --exclude '.stage-v1.5/' \
  --exclude '.stage-v1.6/' \
  --exclude '.stage-v1.7/' \
  --exclude '.stage-v1.8/' \
  --exclude '.stage-v1.9/' \
  --exclude 'skills/' \
  --exclude 'bun.lock' \
  --exclude '*.tmp' \
  --exclude 'bun-error.log' \
  --exclude '.env.local' \
  --exclude 'tsconfig.tsbuildinfo' \
  --exclude 'next-env.d.ts' \
  --exclude '*.log' \
  --exclude '.logs/' \
  --exclude 'v12_*.png' \
  --exclude 'scripts/*.png' \
  --exclude 'scripts/diag/' \
  --exclude 'scripts/e2e-v18-*.png' \
  --exclude 'scripts/vlm_*.json' \
  --exclude 'scripts/search*.json' \
  --exclude 'scripts/e2e-v18-probe.txt' \
  --exclude 'db/' \
  "$ROOT/" "$STAGE/$FOLDER/"

# ── WaveScope v5 + guide réglages (inclus depuis v1.3) ────────────────────
cp "$ROOT/download/wavescope_ict_v5.pine" "$STAGE/$FOLDER/wavescope_ict_v5.pine"
cp "$ROOT/download/GUIDE-REGLAGES-V5.md" "$STAGE/$FOLDER/GUIDE-REGLAGES-V5.md"

# ── Pack d'exemple (celui fourni par l'utilisateur) pour test immédiat ────
mkdir -p "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies/libs"
cp "$ROOT/upload/piracy_extracted/Market_structures_scripts/Main.pine" \
   "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies/Main.pine"
cp "$ROOT/upload/piracy_extracted/Market_structures_scripts/libs/"*.pine \
   "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies/libs/"

# ── README de l'alignement live (doc technique complète) ──────────────────
cp "$ROOT/README-PINE-LIVE-ALIGNMENT.md" "$STAGE/$FOLDER/README-PINE-LIVE-ALIGNMENT.md"

# ── README des fonctionnalités v1.9 ───────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.9-ALIGNEMENT-LIVE.md" <<'EOF'
# Pine v6 Engine — v1.9 « Alignement live définitif »

## Le bug corrigé (définitivement)

**Symptôme** : au chargement, tout est aligné. Puis chaque nouvelle bougie
décale les indicateurs d'une bougie vers la gauche — les signaux semblent se
déplacer vers les vieilles bougies, et le décalage s'accumule. Tous les
scripts sont touchés simultanément (overlay ou non).

**Cause racine** (reproduite par test, pas devinée) : la ré-exécution Pine
passait par un timer de 350 ms **annulé à chaque tick** (chaque flush du flux
live produit une nouvelle référence de tableau → l'effet React se relançait →
`clearTimeout`). Sous un flux de ticks continu, le timer ne tirait
**jamais** : les résultats Pine restaient figés sur l'historique initial
pendant que le graphique avançait.

**L'architecture v1.9** (détails complets dans `README-PINE-LIVE-ALIGNMENT.md`) :

1. **`src/lib/pine-time-axis.ts`** — l'identité temporelle canonique.
   Le timestamp est LA clé primaire d'une bougie. Conversions sec↔ms uniques,
   alignement des outputs PAR TIMESTAMP (jamais par index de tableau),
   validation des timelines, diagnostics `[PINE ALIGNMENT]`.

2. **`src/lib/pine-executor.ts`** — le coordinateur d'exécution.
   Chaque dataset devient un **snapshot immuable** avec une **révision
   monotone**. Une seule exécution à la fois (single-flight), le dernier
   snapshot gagne (latest-result-wins), commit **atomique** de tous les
   scripts sur le même snapshot. Nouvelle bougie → recalcul immédiat ;
   tick de bougie en formation → recalcul throttlé (1 s, même barTime).
   Changement d'actif/timeframe → tout est invalidé, aucun résultat de
   l'ancien marché ne peut rester ni atterrir tard.

3. **`src/lib/pine-store.ts`** — enveloppe de cohérence.
   Chaque résultat porte sa révision/son contexte ; le store REFUSE tout
   commit obsolète ou étranger. Un ancien calcul asynchrone ne peut jamais
   réécrire le store après qu'une nouvelle bougie a été traitée.

4. **Rendu** — les fallbacks positionnels
   (`values[values.length - n + i]` sur `visible[offset + i]`) sont
   SUPPRIMÉS des trois composants de rendu. Timeline absente ou incohérente
   = refus de dessiner + diagnostic explicite. Les drawings restent résolus
   en timestamp À l'exécution (`bar_index → barTime`).

## Ce que vous devez observer

- nouvelle bougie → les indicateurs **suivent** (recalcul immédiat) ;
- un signal à T **reste à T** pour toujours (+1, +10, +100 bougies) ;
- replay, changement d'actif/timeframe, multi-scripts : jamais de dérive ;
- les alertes de main.pine apparaissent désormais à chaque nouvelle bougie
  (elles étaient gelées par le même bug de starvation) ;
- en mode dev, la console signale `[PINE ALIGNMENT] PINE_RESULT_STALE`
  si un résultat affiché traîne derrière le graphique (il ne devrait plus).

## Tests (110 nouveaux + non-régression complète)

```
npx tsx scripts/test-pine-timestamp-mapping.ts      # 30 ✓ conversions + validation
npx tsx scripts/test-pine-live-alignment.ts         # 28 ✓ +1/+5/+10/+100 bougies, T reste T
npx tsx scripts/test-pine-new-bar-shift.ts          #  8 ✓ anti-starvation (le bug v1.8 prouvée)
npx tsx scripts/test-pine-stale-result.ts           # 13 ✓ obsolète ne peut jamais écraser
npx tsx scripts/test-pine-multiscript-alignment.ts  # 15 ✓ 5 scripts synchronisés
npx tsx scripts/test-pine-drawing-time-anchor.ts    # 16 ✓ drawings ancrés barTime
```

Non-régression : pine-alignment (27), pine-libraries (50), pine-engine-libs
(21), martingale (12), stop/rejet (17), log trades (21), CALL/PUT (9),
adaptateurs — tout passe. `tsc` 0 erreur, build production OK.

## Lancer sur Termux

```bash
unzip pine_v6_engine_v1.9.zip
cd pine_v6_engine_v1.9
npm install --no-audit --no-fund   # le postinstall applique le patch piner
./start-dev.sh
```
EOF

# ── ZIP du pack d'exemple (prêt à importer pour tester) ───────────────────
(cd "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies" && zip -qr9 "$STAGE/EXEMPLE-Pack-Multi-Librairies.zip" .)
mv "$STAGE/EXEMPLE-Pack-Multi-Librairies.zip" "$STAGE/$FOLDER/EXEMPLE-Pack-Multi-Librairies.zip"

# ── Création du zip ───────────────────────────────────────────────────────
rm -f "$OUT"
(cd "$STAGE" && zip -qr9 "$OUT" "$FOLDER")

# ── Vérification ──────────────────────────────────────────────────────────
echo "=== Archive créée : $OUT ==="
du -h "$OUT"
unzip -l "$OUT" | tail -1
echo "=== Fichiers clés présents ==="
unzip -l "$OUT" | grep -E 'pine-time-axis|pine-executor|README-V1.9|README-PINE-LIVE|EXEMPLE-Pack|wavescope_ict_v5|GUIDE-REGLAGES-V5|package-lock.json$|test-pine-(live-alignment|new-bar-shift|stale-result|multiscript|timestamp-mapping|drawing-time-anchor)' | awk '{print $1, $4}'
echo "=== Marqueurs de fonctionnalités (vérification rapide) ==="
unzip -p "$OUT" "$FOLDER/src/lib/pine-executor.ts" | grep -c 'latest-result-wins\|latest wins' | xargs echo "latest-wins documenté (>=1 attendu) :"
unzip -p "$OUT" "$FOLDER/src/lib/pine-executor.ts" | grep -c 'PineExecutionCoordinator' | xargs echo "coordinateur (>=2 attendus) :"
unzip -p "$OUT" "$FOLDER/src/lib/pine-time-axis.ts" | grep -c 'alignPineSeries' | xargs echo "alignement timestamp canonique (>=3 attendus) :"
unzip -p "$OUT" "$FOLDER/src/components/trading/chart/chart-workspace.tsx" | grep -c 'values.length - n + i\|values\[values.length' | xargs echo "fallbacks positionnels restants (0 attendu) :"
unzip -p "$OUT" "$FOLDER/src/components/trading/chart/pine-sub-pane.tsx" | grep -c 'values.length - n + j\|values\[values.length' | xargs echo "fallback positionnel pane (0 attendu) :"
unzip -p "$OUT" "$FOLDER/src/components/trading/chart/pine-script-editor.tsx" | grep -c 'setTimeout(async () => {' | xargs echo "debounce affamé restant (0 attendu) :"
unzip -p "$OUT" "$FOLDER/src/lib/pine-store.ts" | grep -c 'commitExecution' | xargs echo "commit atomique store (>=3 attendus) :"
unzip -p "$OUT" "$FOLDER/src/components/trading/chart/chart-workspace.tsx" | grep -c 'PINE ALIGNMENT' | xargs echo "diagnostic alignment (>=3 attendus) :"
unzip -p "$OUT" "$FOLDER/src/lib/pine-executor.ts" | grep -c 'CONTEXT BARRIER' | xargs echo "barrière de contexte (1 attendu) :"
unzip -p "$OUT" "$FOLDER/src/lib/pine-store.ts" | grep -c 'clearAllResults' | xargs echo "invalidation asset (>=3 attendus) :"
unzip -t "$OUT" > /dev/null && echo "=== Intégrité zip OK ==="

# Nettoyage du staging
rm -rf "$STAGE"
