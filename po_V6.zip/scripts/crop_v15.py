"""Recadre les captures E2E v1.5 sur le panneau droit (Signal Strategy) / le bas (Strategy Tester)."""
from PIL import Image

def crop_right(src, dst, frac=0.28):
    im = Image.open(src)
    w, h = im.size
    im.crop((int(w * (1 - frac)), 0, w, h)).save(dst)
    print(f"{dst}: {im.size} -> right {frac}")

def crop_bottom(src, dst, frac=0.45):
    im = Image.open(src)
    w, h = im.size
    im.crop((0, int(h * (1 - frac)), w, h)).save(dst)
    print(f"{dst}: {im.size} -> bottom {frac}")

base = "/home/z/my-project/scripts/"
crop_right(base + "e2e_v15_01_call_stop_sections.png", base + "e2e_v15_01_crop.png")
crop_right(base + "e2e_v15_02_put_stop_sections.png", base + "e2e_v15_02_crop.png")
crop_bottom(base + "e2e_v15_03_strategy_tester_log.png", base + "e2e_v15_03_crop.png")
