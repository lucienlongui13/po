#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
# DIAGNOSTIC — reproduce "indicators drift away from candles"
# Injects Main.pine + PiracyChecker.zip, waits for live execution,
# captures TWO screenshots ~75s apart (2+ new S30 candles) and dumps
# in-page geometry probes (price scale range, drawing store stats).
# ═══════════════════════════════════════════════════════════════════
cd /home/z/my-project
mkdir -p scripts/diag
shot() { agent-browser screenshot "scripts/diag/$1" >/dev/null 2>&1 && echo "📸 $1"; }

if ! curl -s -m 3 -o /dev/null http://localhost:3000/ 2>/dev/null; then
  echo "front mort → ./po.sh"
  setsid nohup ./po.sh > .logs/po-restart.log 2>&1
  for i in $(seq 1 30); do sleep 4; curl -s -m 5 -o /dev/null http://localhost:3000/ && break; done
fi
curl -s -m 3 -o /dev/null http://localhost:3000/ && echo "front OK" || { echo "✗ front mort"; exit 1; }

echo "── 1. Injection Main.pine + import ZIP"
B64=$(base64 -w0 upload/piracy_extracted/Market_structures_scripts/Main.pine)
agent-browser open http://localhost:3000 >/dev/null 2>&1
sleep 10
agent-browser eval "(() => {
  localStorage.clear();
  const src = atob('$B64');
  const scripts = [{ id: 'pine-e2e-main', name: 'BOS, CHoCH and CISD [PiracyChecker]', source: src,
    meta: { version: 6, declaration: 'indicator', title: 'BOS, CHoCH and CISD [PiracyChecker]', overlay: true },
    enabled: true }];
  localStorage.setItem('pine-scripts-v1', JSON.stringify(scripts));
  return 'injected';
})()" >/dev/null 2>&1
agent-browser reload >/dev/null 2>&1
sleep 10

agent-browser find role button click --name "Login with Pocket Option" >/dev/null 2>&1
for i in $(seq 1 12); do
  sleep 5
  if agent-browser snapshot -i -c 2>/dev/null | grep -q "PINE SCRIPT"; then break; fi
done
agent-browser snapshot -i -c 2>/dev/null | grep -q "PINE SCRIPT" && echo "loggé" || { echo "✗ login"; exit 1; }
sleep 10

# ouvrir l'éditeur Pine (les inputs fichier y sont montés)
agent-browser eval "
(() => {
  const b = [...document.querySelectorAll('button')].find(x => (x.textContent || '').includes('PINE SCRIPT'));
  if (!b) return 'BOUTON ABSENT';
  b.click(); return 'ÉDITEUR OUVERT';
})()" 2>&1 | tail -1
sleep 5

# import du pack
B64ZIP=$(base64 -w0 upload/PiracyChecker.zip)
agent-browser eval "window.__zipB64 = '$B64ZIP'; 'ok'" >/dev/null 2>&1
agent-browser eval '(() => {
  const b64 = window.__zipB64;
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const file = new File([bytes], "PiracyChecker.zip", { type: "application/zip" });
  const input = [...document.querySelectorAll("input[type=file]")].find(i => (i.accept || "").includes("zip"));
  if (!input) return "INPUT ABSENT";
  const dt = new DataTransfer();
  dt.items.add(file);
  input.files = dt.files;
  input.dispatchEvent(new Event("change", { bubbles: true }));
  return "imported";
})()' 2>&1 | tail -1
sleep 15   # ré-exécution automatique

echo "── 2. Probe T0 (geometry in-page)"
agent-browser eval '(() => {
  const out = { t: "T0", ts: Date.now() };
  // candle data from the chart canvases is not directly readable; use the
  // pine store via the exposed React tree? Not exposed — instead measure the
  // DOM canvases pixel content.
  const container = document.querySelector(".relative.flex-1");
  out.containerFound = !!container;
  const canvases = container ? [...container.querySelectorAll("canvas")] : [];
  out.canvases = canvases.length;
  // LWC main canvas = the biggest one
  let main = null;
  for (const c of canvases) if (!main || (c.width*c.height) > (main.width*main.height)) main = c;
  if (main) {
    const ctx = main.getContext("2d");
    const { width, height } = main;
    const img = ctx.getImageData(0, 0, width, height).data;
    let minCandleY = 1e9, maxCandleY = -1;
    const isCandle = (r,g,b) => (g > 120 && r < 120 && b > 100 && Math.abs(g-b) < 90 && g > b) || (r > 180 && g < 120 && b < 120);
    for (let y = 0; y < height; y += 2) {
      for (let x = 0; x < width; x += 4) {
        const i = (y * width + x) * 4;
        if (isCandle(img[i], img[i+1], img[i+2])) {
          if (y < minCandleY) minCandleY = y;
          if (y > maxCandleY) maxCandleY = y;
        }
      }
    }
    out.mainCanvas = { width, height };
    out.candleYRange = maxCandleY >= 0 ? [+(minCandleY/height).toFixed(3), +(maxCandleY/height).toFixed(3)] : null;
  }
  // console text of the editor
  const txt = document.body.textContent;
  const dm = txt.match(/(\d+) drawing object\(s\)/);
  out.drawings = dm ? dm[1] : "0";
  return JSON.stringify(out);
})()' 2>&1 | tail -1

shot t0.png
echo "── 3. Attente 75s (2-3 nouvelles bougies S30)…"
sleep 75
echo "── 4. Probe T1"
agent-browser eval '(() => {
  const out = { t: "T1", ts: Date.now() };
  const container = document.querySelector(".relative.flex-1");
  const canvases = container ? [...container.querySelectorAll("canvas")] : [];
  let main = null;
  for (const c of canvases) if (!main || (c.width*c.height) > (main.width*main.height)) main = c;
  if (main) {
    const ctx = main.getContext("2d");
    const { width, height } = main;
    const img = ctx.getImageData(0, 0, width, height).data;
    let minCandleY = 1e9, maxCandleY = -1;
    const isCandle = (r,g,b) => (g > 120 && r < 120 && b > 100 && Math.abs(g-b) < 90 && g > b) || (r > 180 && g < 120 && b < 120);
    for (let y = 0; y < height; y += 2) {
      for (let x = 0; x < width; x += 4) {
        const i = (y * width + x) * 4;
        if (isCandle(img[i], img[i+1], img[i+2])) {
          if (y < minCandleY) minCandleY = y;
          if (y > maxCandleY) maxCandleY = y;
        }
      }
    }
    out.mainCanvas = { width, height };
    out.candleYRange = maxCandleY >= 0 ? [+(minCandleY/height).toFixed(3), +(maxCandleY/height).toFixed(3)] : null;
  }
  const txt = document.body.textContent;
  const dm = txt.match(/(\d+) drawing object\(s\)/);
  out.drawings = dm ? dm[1] : "0";
  return JSON.stringify(out);
})()' 2>&1 | tail -1

shot t1.png
echo "── 5. Analyse géométrique des captures"
python3 scripts/analyze_screenshot_geometry.py scripts/diag/t0.png 2>&1 | tail -15
echo "════ T1 ════"
python3 scripts/analyze_screenshot_geometry.py scripts/diag/t1.png 2>&1 | tail -15
