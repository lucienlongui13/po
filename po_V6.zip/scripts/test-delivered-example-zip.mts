/** Smoke test final : le ZIP d'exemple LIVRÉ dans pine_v6_engine_v1.7.zip
 *  (méthode DEFLATE) est lisible par zip-reader et s'importe correctement. */
import { readFileSync } from 'node:fs'
import { execSync } from 'node:child_process'

const backing = new Map<string, string>()
;(globalThis as any).window = {
  localStorage: {
    getItem: (k: string) => backing.get(k) ?? null,
    setItem: (k: string, v: string) => { backing.set(k, String(v)) },
    removeItem: (k: string) => { backing.delete(k) },
  },
}

// extrait le zip interne de l'archive livrée
execSync('unzip -o -q /home/z/my-project/download/pine_v6_engine_v1.7.zip pine_v6_engine_v1.7/EXEMPLE-Pack-Multi-Librairies.zip -d /tmp/v17check', { stdio: 'ignore' })

const { readZipEntries } = await import('../src/lib/zip-reader')
const bytes = readFileSync('/tmp/v17check/pine_v6_engine_v1.7/EXEMPLE-Pack-Multi-Librairies.zip')
const entries = await readZipEntries(new Uint8Array(bytes))
console.log('entrées extraites du zip DEFLATE livré :', entries.length)
for (const e of entries) console.log('  ·', e.name, e.binary ? '(binaire)' : `(${e.text.length} car.)`)

const { importLibraryBundle, computeMissingLibraries } = await import('../src/lib/pine-libraries')
const files = entries.filter((e) => !e.binary).map((e) => ({ name: e.name, source: e.text }))
const report = importLibraryBundle(files)
console.log('librairies enregistrées :', report.registered.map((r) => r.keys.join(' + ')).join(' · '))
console.log('manquantes après import :', report.missing.length)
console.log('scripts principaux :', report.mainScripts.map((m) => m.title).join(' · '))

const mainSrc = report.mainScripts[0].file.source
const missing = computeMissingLibraries(mainSrc)
console.log(missing.length === 0 ? '✓ CLOSURE COMPLÈTE — le pack livré importe sans rien manquer' : '✗ manquantes : ' + missing.map((m) => m.path).join(', '))
process.exit(missing.length === 0 && report.registered.length === 4 ? 0 : 1)
