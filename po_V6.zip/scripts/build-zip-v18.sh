#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v18.sh — Livraison v18 « Purge intégrale + L_Lucien ProTrader
# + switch Tags & labels »
#
# Le besoin (message utilisateur) :
#   1. PURGE INTÉGRALE — module Auto Trade : ne conserver QUE la stratégie
#      « BOS, CHoCH & CISD (pack Pine) » ; supprimer TOTALEMENT les
#      composants AICOACH, AI COACH · GLOSSARY, Cartes Conditions,
#      Signal Strategy, Order Book — fichiers, composants UI, dépendances,
#      imports inutilisés, variables d'état, types/interfaces TypeScript,
#      routes et éléments de menu/navigation. Aucun code mort, aucune
#      erreur de build.
#   2. RENOMMAGE — « BOS, CHoCH & CISD (pack Pine) » devient
#      « L_Lucien ProTrader » (libellés, identifiants, références).
#   3. LIGHTWEIGHT-CHARTS — switch afficher/masquer les tags et libellés
#      de la stratégie sur le graphique ; DÉFAUT DÉSACTIVÉ (masqués à
#      l'initialisation).
#
# Les correctifs v18 :
#   1. PURGE — registre backend AUTO_TRADE_STRATEGIES = 1 entrée
#      (l_lucien_protrader) ; fichiers morts supprimés
#      (scripts/backtest-ai-coach-eurusd.ts, data/coach-memory/,
#      tests/fixtures/social-frames.ts, tests/confirm-3-orders-result.json,
#      data/backend-session.json état runtime) ; ~20 scripts npm pointant
#      vers des tests supprimés retirés de package.json ; type
#      PersistedSessionConfig réduit aux champs vivants (suppression de
#      orderBookEnabled, expirationMode et ~40 champs des stratégies
#      purgées : liveFractal*, brokerBreaker*, brokerFlowTiming*,
#      liveFractalNinja*, fractalPrecision*, ichimoku*, social*) ;
#      commentaires orphelins éliminés (AI COACH ×11 blocs, Longui,
#      PatternEngine, sidecar social, mini-serveur 3031, regexes
#      [SOCIAL-BOOK] mortes, indicateur « ORDER BOOK Volume » de la
#      bibliothèque, mention CoachOverlay, traductions UI mortes) ;
#      formatStructuredLog : canaux 'AI-COACH'/'PATTERN-ENGINE' retirés ;
#      fonction morte inferCandlePeriod supprimée.
#   2. RENOMMAGE — id unique 'l_lucien_protrader', libellé « L_Lucien
#      ProTrader » partout (panneau, registre, statuts, descriptions,
#      overlay, chart-workspace, hook, tests) ; alias legacy
#      'bos_choch_cisd' conservé (restauration de session + tests e2e) ;
#      clé localStorage d'affichage 'l-lucien-protrader-display-v1'.
#   3. SWITCH TAGS & LABELS — LucienProTraderDisplaySettings { showLabels }
#      DÉFAUT FALSE (masqués à l'initialisation) ; switch dédié dans le
#      panneau Auto Trade (persisté localStorage) ; l'overlay lightweight-
#      charts ne dessine les labels BOS/CHoCH/CISD QUE si showLabels est
#      actif (les lignes d'événement et de tendance restent indépendantes).
#   4. RÉPARATION — handler set-auto-config : traitement du champ
#      expirySeconds RÉTABLI (contrat v6.3 « respecté à la seconde près »,
#      clamp [3 s, 86 400 s]) — ce champ ne contrôle JAMAIS les ordres de
#      L_Lucien ProTrader (l'expiration d'un ordre vient UNIQUEMENT de sa
#      règle CALL/PUT), il reste un réglage générique de session exposé
#      par le status et persisté.
#
# Validation : tsc root 0 erreur · tsc backend 0 erreur (les 3 erreurs
# préexistantes v14 ont disparu avec les fichiers des stratégies purgées) ·
# tsc SDK 0 erreur · build Next.js PASS (6/6 pages) · multi-assets 134 ✓ ·
# v63-features 71 ✓ · v63-intégration 14 ✓ · bos-strategy 22 ✓ ·
# martingale-streak 12 ✓ · bos-expiry-martingale 39 ✓ · bos-martingale-e2e
# 17/17 · tie-refund-e2e 24/24 · bos-multi-e2e (voir worklog) · scan de
# traces AICOACH/AI COACH/GLOSSARY/Cartes Conditions/Signal Strategy/
# Order Book/Longui/PatternEngine = 0 occurrence dans le code livré.
#
# Sortie : /home/z/my-project/download/pine_v6_engine_v18_lucien_protrader_purge.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v18"
FOLDER=pine_v6_engine
OUT="$ROOT/download/pine_v6_engine_v18_lucien_protrader_purge.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (structure identique aux zips v15-v17) ────────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude '.logs/' \
  --exclude '*.log' \
  --exclude 'winwinlogs.jsonl' \
  --exclude 'mini-services/iqoption-backend/data/backend-session.json' \
  --exclude 'mini-services/iqoption-backend/data/candle-cache/' \
  --exclude 'db/' \
  "$ROOT/pine_v6_engine/" "$STAGE/$FOLDER/"

# ── README de la version v18 ─────────────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.6-V18-LUCIEN-PROTRADER.md" <<'EOF'
# Pine v6 Engine — v18 « L_Lucien ProTrader » : purge intégrale, renommage et switch d'affichage

## 1. Purge intégrale (module Auto Trade)

Le module Auto Trade ne contient plus qu'**UNE seule stratégie** :
**L_Lucien ProTrader** (anciennement « BOS, CHoCH & CISD (pack Pine) »).
Toutes les autres stratégies ont été supprimées du registre backend et du
frontend.

Composants supprimés **totalement** (aucune trace restante — fichiers,
composants UI, dépendances, imports, variables d'état, types TypeScript,
routes, entrées de menu) :

- **AICOACH** / moteur AI Coach (events socket `coach-*`, mémoire
  `data/coach-memory/`, script `backtest:eurusd-next-m1`, commentaires) ;
- **AI COACH · GLOSSARY** (traductions UI mortes) ;
- **Cartes Conditions** ;
- **Signal Strategy** (le panneau Auto Trade est la seule interface de
  configuration des ordres) ;
- **Order Book** (composant UI, sidecar social, champ `orderBookEnabled`
  persisté, indicateur « ORDER BOOK Volume » de la bibliothèque) ;
- et les reliquats des moteurs purgés : Longui Lucien Smart Trader,
  Pattern Engine, OTC Beater, WinWin, Ninja Trader, Fractal (live/bis/
  precision/velocity), Body Imbalance, OTC Algo, Next Candle, Smart
  Trader, Ichimoku prediction (stratégie), TSRS, V3-Snapback, Hammer Win.

Nettoyage associé : ~20 scripts npm pointant vers des tests supprimés ont
été retirés de `package.json` (le `npm test` ne référence plus que des
fichiers existants) ; le type `PersistedSessionConfig` a été réduit aux
champs vivants ; les fixtures orphelins et états runtime ont été
supprimés.

## 2. Renommage de la stratégie

« BOS, CHoCH & CISD (pack Pine) » → **« L_Lucien ProTrader »** :

| Endroit | Valeur |
|---|---|
| Identifiant unique (backend + front) | `l_lucien_protrader` |
| Libellé du panneau Auto Trade | `L_Lucien ProTrader` |
| Registre / dropdown Strategy | `L_Lucien ProTrader` |
| Source des ordres (events `trade-opened`) | `l_lucien_protrader` |
| Alias legacy (sessions anciennes + tests) | `bos_choch_cisd` → mappé automatiquement vers `l_lucien_protrader` |

Le moteur (BOS / Break of Structure, CHoCH / Change of Character, CISD /
Change in State of Delivery sur swings à 2 bougies, bougies clôturées
uniquement) est inchangé : mêmes règles CALL/PUT, chaque règle porte sa
propre expiration en secondes, aucune valeur automatique.

## 3. Switch « Tags & labels » sur le graphique (lightweight-charts)

Un **bouton à bascule** dans le panneau Auto Trade (« Tags & labels sur
le graphique ») affiche ou masque les tags et libellés BOS / CHoCH / CISD
dessinés sur le graphique.

- **Désactivé par défaut** : à l'initialisation du graphique, aucun tag
  ni libellé n'est rendu — il faut activer le switch explicitement pour
  les voir ;
- préférence **persistée** (localStorage `l-lucien-protrader-display-v1`)
  et partagée entre le panneau et l'overlay (abonnement temps réel) ;
- les couleurs/taille des labels (« Labels » du pack) restent
  configurables et s'appliquent dès le réaffichage ;
- les lignes d'événement (pointillées) et de tendance (pleines) restent
  indépendantes de ce switch.

## 4. Réparation du champ « Expiration » générique

Le traitement du champ `expirySeconds` via `set-auto-config` a été
rétabli (contrat v6.3 : valeur respectée à la seconde près, clamp
[3 s, 86 400 s], jamais snappée). **Rappel** : ce champ ne contrôle
**jamais** les ordres de L_Lucien ProTrader — l'expiration d'un ordre
vient uniquement de sa règle CALL/PUT. Le champ reste un réglage générique
de session (exposé dans `auto-trade-status`, persisté, utilisé comme
repli par les consommateurs génériques du frontend).

## Validation (toutes exécutées sur cette livraison)

| Vérification | Résultat |
|---|---|
| `tsc --noEmit` (root / backend / SDK) | 0 erreur (les 3 préexistantes v14 ont disparu avec la purge) |
| `next build` | PASS — 6/6 pages |
| `tests/test-multi-assets.ts` | 134 OK / 0 échec |
| `tests/test-v63-features.ts` | 71 OK / 0 échec |
| `tests/test-v63-integration.ts` | 14 OK / 0 échec |
| `tests/test-bos-choch-cisd-strategy.ts` | 22 ✓ / 0 ✗ |
| `scripts/test-martingale-streak.ts` | 12 ✓ / 0 ✗ |
| `scripts/test-bos-choch-cisd-expiry-martingale.ts` | 39 ✓ / 0 ✗ |
| `tests/test-bos-choch-cisd-martingale-e2e.mjs` (vrai backend + mock broker) | 17/17 ✓ |
| `tests/test-martingale-tie-refund-e2e.mjs` (vrai backend + mock broker) | 24/24 ✓ |
| `tests/test-bos-choch-cisd-multi-e2e.mjs` (vrai backend, 2 assets) | 20/20 ✓ |
| Scan traces (AICOACH · AI COACH · GLOSSARY · Cartes Conditions · Signal Strategy · Order Book · Longui · PatternEngine) | 0 occurrence dans le code livré |

## Comment re-vérifier vous-même

```bash
# 1. Installer et démarrer
npm install && cd mini-services/iqoption-backend && npm install

# 2. Typecheck + build
cd ../.. && npx tsc --noEmit && npx next build

# 3. Tests
npx tsx scripts/test-martingale-streak.ts            # 12 ✓
npx tsx scripts/test-bos-choch-cisd-expiry-martingale.ts  # 39 ✓
cd mini-services/iqoption-backend
node --import tsx tests/test-multi-assets.ts        # 134 ✓
node --import tsx tests/test-v63-features.ts        # 71 ✓
node tests/test-bos-choch-cisd-martingale-e2e.mjs   # 17/17
node tests/test-martingale-tie-refund-e2e.mjs        # 24/24
```

Dans l'application : panneau Auto Trade → la liste Strategy ne propose
que « L_Lucien ProTrader » ; le switch « Tags & labels sur le graphique »
est OFF au démarrage (graphique vierge de tags/libellés) ; l'activer
affiche les labels BOS/CHoCH/CISD avec les couleurs configurées.
EOF

# ── Zippage ───────────────────────────────────────────────────────────────
cd "$STAGE"
zip -qr "$OUT" "$FOLDER"
cd "$ROOT"
rm -rf "$STAGE"

echo "─ Livraison v18 ─────────────────────────────────────────────"
echo "Zip      : $OUT"
echo "Taille   : $(du -h "$OUT" | cut -f1)"
echo "Fichiers : $(unzip -l "$OUT" | tail -1 | awk '{print $2}')"
echo "Intégrité: $(unzip -t "$OUT" > /dev/null && echo OK || echo ÉCHEC)"
