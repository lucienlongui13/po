/**
 * probe5-bare-runtime.ts — which v3 bare function calls silently return na
 * at runtime under piner? Each case plots a bare call vs its v6 namespaced
 * equivalent side by side.
 */
import { runPineScript } from '../src/lib/pine-engine'
import { readFileSync } from 'node:fs'

const raw = JSON.parse(readFileSync('scripts/dataset-eurusd-m1.json', 'utf8')) as any[]
const ds = (Array.isArray(raw) ? raw : raw.candles ?? raw.data ?? []).map((c: any) => ({
  time: Number(c.time), open: Number(c.open), high: Number(c.high), low: Number(c.low), close: Number(c.close),
  volume: Number(c.volume ?? 0),
}))

const fns = [
  { bare: 'sma(close, 21)', ns: 'ta.sma(close, 21)' },
  { bare: 'ema(close, 21)', ns: 'ta.ema(close, 21)' },
  { bare: 'wma(close, 21)', ns: 'ta.wma(close, 21)' },
  { bare: 'vwma(close, 21)', ns: 'ta.vwma(close, 21)' },
  { bare: 'min(low[2], low[1])', ns: 'math.min(low[2], low[1])' },
  { bare: 'max(high[2], high[1])', ns: 'math.max(high[2], high[1])' },
  { bare: 'round(21.4)', ns: 'math.round(21.4)' },
  { bare: 'sqrt(21)', ns: 'math.sqrt(21)' },
  { bare: 'exp(0.5)', ns: 'math.exp(0.5)' },
  { bare: 'cos(1.2)', ns: 'math.cos(1.2)' },
  { bare: 'change(close)', ns: 'ta.change(close)' },
  { bare: 'barssince(close > close[1])', ns: 'ta.barssince(close > close[1])' },
  { bare: 'cum(volume)', ns: 'math.cum(volume)' },
]

function finiteOf(plotOut: any): number {
  const data = plotOut?.data
  if (!Array.isArray(data)) return -1
  return data.filter((d: any) => d != null && Number.isFinite(Number(d?.value ?? d))).length
}

async function main() {
  for (const f of fns) {
    const src = `//@version=6\nindicator("t", overlay=true)\nplot(${f.bare}, title="bare")\nplot(${f.ns}, title="ns")`
    const res = await runPineScript(src, ds as any, { symbol: 'EURUSD_otc', timeframe: '1' })
    if (!res.ok) {
      console.log(`✗ ${f.bare.padEnd(34)} COMPILE/RUN ERROR: ${res.error.message.split('\n')[0].slice(0, 90)}`)
      continue
    }
    const bare = finiteOf(res.result.plots.find((p: any) => p.title === 'bare'))
    const ns = finiteOf(res.result.plots.find((p: any) => p.title === 'ns'))
    const ok = bare > 0
    console.log(`${ok ? '✓' : '✗'} ${f.bare.padEnd(34)} bare=${bare}/2242  namespaced=${ns}/2242 ${ok ? '' : '  <-- SILENT NA'}`)
  }
  // macd tuple
  const m1 = `//@version=6\nindicator("t", overlay=true)\n[a,b,_] = macd(close, 8, 21, 5)\nplot(a, title="bare")`
  const m2 = `//@version=6\nindicator("t", overlay=true)\n[a,b,_] = ta.macd(close, 8, 21, 5)\nplot(a, title="ns")`
  for (const [label, src] of [['macd-bare', m1], ['macd-ns', m2]] as const) {
    const res = await runPineScript(src, ds as any, { symbol: 'EURUSD_otc', timeframe: '1' })
    if (!res.ok) console.log(`✗ ${label}: ${res.error.message.split('\n')[0].slice(0, 90)}`)
    else console.log(`${finiteOf(res.result.plots[0]) > 0 ? '✓' : '✗'} ${label.padEnd(34)} = ${finiteOf(res.result.plots[0])}/2242`)
  }
}
main()
