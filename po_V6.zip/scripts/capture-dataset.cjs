/**
 * capture-dataset.cjs — Capture le même dataset de bougies que l'app
 * (socket.io → backend 3030 → broker démo) : login démo + capture-history
 * M1 EURUSD_otc, alignable par timestamp avec les runs navigateur.
 *
 * Usage : node scripts/capture-dataset.cjs [count] [size]
 */
const { io } = require('socket.io-client');
const fs = require('fs');

const COUNT = Number(process.argv[2] || 2200);
const SIZE = Number(process.argv[3] || 60);
const OUT = process.argv[4] || 'scripts/dataset-eurusd-m1.json';

const socket = io('http://localhost:3030', { transports: ['websocket'] });
const t0 = Date.now();

const die = (msg) => { console.error('✗ ' + msg); try { socket.close(); } catch {} process.exit(1); };

socket.on('connect_error', (e) => die('connexion impossible : ' + e.message));

socket.on('connect', () => {
  console.log('connecté au backend (3030)');
  socket.emit('login', { email: 'longuilcn@gmail.com', password: 'Jean-Paul@#1964', mode: 'demo' });
});

socket.on('login-result', (r) => {
  if (!r || r.ok !== true) return die('login refusé : ' + JSON.stringify(r));
  console.log('login OK (uid=' + r.user_id + ') — attente flux marché…');
  // Laisse le temps au marché de se sélectionner (session persistée EURUSD_otc)
  setTimeout(() => {
    console.log('capture-history count=' + COUNT + ' size=' + SIZE + 's …');
    socket.emit('capture-history', { count: COUNT, size: SIZE }, (result) => {
      if (!result || result.ok !== true || !Array.isArray(result.candles) || result.candles.length === 0) {
        return die('capture-history échoué : ' + JSON.stringify(result).slice(0, 300));
      }
      const candles = result.candles;
      fs.writeFileSync(OUT, JSON.stringify(candles));
      const first = candles[0], last = candles[candles.length - 1];
      console.log('✓ ' + candles.length + ' bougies sauvegardées → ' + OUT);
      console.log('  première : t=' + first.time + ' (' + new Date(first.time * 1000).toISOString() + ')');
      console.log('  dernière : t=' + last.time + ' (' + new Date(last.time * 1000).toISOString() + ')');
      // couverture de la fenêtre des runs navigateur ?
      const covers = first.time <= 1789357380 && last.time >= 1789417260;
      console.log('  couvre la fenêtre des runs navigateur (1789357380→1789417260) : ' + covers);
      socket.close();
      process.exit(0);
    });
  }, 6000);
});

setTimeout(() => die('timeout global (90 s)'), 90000);
