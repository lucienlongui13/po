/**
 * try-demo-reset.mjs — tente de réinitialiser le solde du compte DÉMO
 * Pocket Option via les endpoints HTTP connus de la plateforme web.
 * Utilise le login mobile du SDK (loginMobile + fetchCabinet) pour obtenir
 * un ci_session frais, puis essaie les candidats de reset démo.
 */
import authModule from '../mini-services/iqoption-backend/pocket-option-sdk/src/auth.js';
const { loginMobile, fetchCabinet } = authModule;

const USER_AGENT = 'Mozilla/5.0 (Linux; Android 13; SM-T870 Build/TP1A.220624.014; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/124.0.0.0 Mobile Safari/537.36, webview2_android_428';

const EMAIL = 'longuilcn@gmail.com';
const PASSWORD = 'Jean-Paul@#1964';

const userAgent = USER_AGENT;

async function main() {
  // 1. Login mobile → token
  const login = await loginMobile({
    credentials: { email: EMAIL, password: PASSWORD },
    logger: { debug: () => {}, info: () => {}, warn: () => {}, error: (m) => console.error('[auth]', m) },
  });
  console.log('login OK, uid=', login.uid);

  // 2. Cabinet → ci_session frais
  const cabinet = await fetchCabinet(login.token, login.tracking, {
    logger: { debug: () => {}, info: () => {}, warn: () => {}, error: () => {} },
  });
  console.log('cabinet OK, ci_session=', cabinet.ciSession ? cabinet.ciSession.slice(0, 20) + '…' : '(aucun)');
  console.log('demoBalance=', cabinet.demoBalance, 'currency=', cabinet.currency);

  const cookie = `ci_session=${encodeURIComponent(cabinet.ciSession ?? '')}`;
  const headers = {
    'User-Agent': userAgent,
    'Cookie': cookie,
    'Accept': 'application/json, text/plain, */*',
    'X-Requested-With': 'XMLHttpRequest',
  };

  // 3. Candidats de reset démo
  const candidates = [
    { method: 'GET', url: 'https://pocketoption.com/en/demo-reset' },
    { method: 'GET', url: 'https://pocketoption.com/en/cabinet/demo-reset' },
    { method: 'POST', url: 'https://pocketoption.com/en/api-demo-reset' },
    { method: 'POST', url: 'https://pocketoption.com/en/cabinet/refill-demo' },
    { method: 'POST', url: 'https://pocketoption.com/api/demo/reset' },
    { method: 'GET', url: 'https://m.pocketoption.com/en/demo-reset' },
  ];
  for (const c of candidates) {
    try {
      const res = await fetch(c.url, {
        method: c.method,
        headers,
        body: c.method === 'POST' ? new URLSearchParams({ demo: '1', amount: '10000' }).toString() : undefined,
        redirect: 'manual',
      });
      const text = await res.text().catch(() => '');
      console.log(`${c.method} ${c.url} → ${res.status} ${text.slice(0, 120).replace(/\n/g, ' ')}`);
    } catch (e) {
      console.log(`${c.method} ${c.url} → ERREUR ${e.message}`);
    }
  }
}

main().catch(e => { console.error('FATAL:', e.message); process.exit(1); });
