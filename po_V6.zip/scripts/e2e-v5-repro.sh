#!/bin/bash
# Repro minimal : page propre + un seul toggle + lecture immédiate du store
cd /home/z/my-project
step() { echo ""; echo "════════ $1 ════════"; }

# 1. Backend
pkill -f backend-supervisor 2>/dev/null; pkill -f "tsx index.ts" 2>/dev/null; sleep 1
setsid nohup bash scripts/backend-supervisor.sh >> backend.log 2>&1 &
sleep 16
curl -s -m 3 http://localhost:3030/health >/dev/null && echo "backend OK"

# 2. Page PROPRE (localStorage vidé avant reload)
agent-browser eval "localStorage.clear(); 'vidé'" >/dev/null 2>&1
agent-browser reload >/dev/null 2>&1
sleep 6
agent-browser console --clear >/dev/null 2>&1 || true
agent-browser find role button click --name "Login with Pocket Option" >/dev/null 2>&1
sleep 16
agent-browser eval "document.querySelectorAll('button').forEach(b=>{if(b.textContent.includes('PINE SCRIPT'))b.click()})" >/dev/null 2>&1
sleep 3
echo "page prête + éditeur ouvert"

# 3. Injecter + exécuter
agent-browser eval "
(async () => {
  const src = await (await fetch('/wavescope_ict_v5.pine')).text();
  const ta = document.querySelector('textarea');
  const setter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value').set;
  setter.call(ta, src);
  ta.dispatchEvent(new Event('input', { bubbles: true }));
  return 'injecté ' + src.length;
})()" 2>&1 | tail -1
sleep 1
agent-browser eval "document.querySelectorAll('button').forEach(b=>{if(/^(Run|Add \/ Run)$/.test(b.textContent.trim()))b.click()})" >/dev/null 2>&1
sleep 14
echo "— console éditeur :"
agent-browser eval "
(() => {
  const blocks = [...document.querySelectorAll('div')].filter(d => String(d.className||'').includes('font-semibold') && /drawing object/.test(d.textContent));
  return blocks[0] ? blocks[0].textContent.match(/(\d+) drawing object/)[0] : 'PAS DE RÉSULTAT';
})()" 2>&1 | tail -1

# 4. Ouvrir Réglages + cliquer ZigZag
agent-browser eval "document.querySelectorAll('button').forEach(b=>{if(b.textContent.includes('Réglages'))b.click()})" >/dev/null 2>&1
sleep 4
agent-browser console --clear >/dev/null 2>&1 || true
CLICK=$(agent-browser eval "
(() => {
  const inputs = [...document.querySelectorAll('input[type=checkbox]')];
  const target = inputs.find(cb => (cb.closest('div')?.textContent || '').includes('ZigZag : afficher'));
  if (target) { target.click(); return 'CLIQUÉ'; }
  return 'INTROUVABLE';
})()" 2>&1 | tail -1)
echo "checkbox : $CLICK"
sleep 4

# 5. LECTURES IMMÉDIATES
step "5. Console (fraîche — non floodée)"
agent-browser console 2>&1 | grep -E "E2E" | head -15
step "6. localStorage inputValues"
agent-browser eval "JSON.stringify(JSON.parse(localStorage.getItem('pine-scripts-v1')||'[]').map(s=>({id:s.id, iv:s.inputValues??'ABSENT'})))" 2>&1 | tail -1
step "7. État DOM de la checkbox"
agent-browser eval "JSON.stringify([...document.querySelectorAll('input[type=checkbox]')].filter(cb=>(cb.closest('div')?.textContent||'').includes('ZigZag : afficher')).map(cb=>cb.checked))" 2>&1 | tail -1
step "8. Compteur de dessins maintenant"
agent-browser eval "
(() => {
  const blocks = [...document.querySelectorAll('div')].filter(d => String(d.className||'').includes('font-semibold') && /drawing object/.test(d.textContent));
  return blocks[0] ? blocks[0].textContent.match(/(\d+) drawing object/)[0] : 'PAS DE RÉSULTAT';
})()" 2>&1 | tail -1
agent-browser screenshot scripts/v5_repro_final.png >/dev/null 2>&1
echo "📸 v5_repro_final.png"
