/**
 * validate-harness.ts — Prouve que le harness reproduit EXACTEMENT les runs
 * navigateur : mêmes trades (heure, côté, résultat, P&L) que .logs/trade.jsonl
 * (runs A / B2) sur la même fenêtre de données, ET que la voie rapide
 * (runStrategy sur table précalculée) = le vrai moteur (SignalStrategyEngine).
 *
 * Exécution : npx tsx scripts/validate-harness.ts
 */
import {
  loadCandles,
  sliceByTime,
  buildSignalTable,
  runStrategy,
  runWithRealEngine,
  type HarnessConfig,
} from './backtest-harness'
import * as fs from 'fs'

interface JsonlTrade {
  trade: {
    id: string
    side: 'call' | 'put'
    amount: number
    payout: number
    entry: { idx: number; time: number; price: number }
    exit: { idx: number; time: number; price: number } | null
    expiryCandles: number
    status: 'won' | 'lost' | 'refunded'
    profit: number
  }
}

function loadJsonl(path: string): JsonlTrade[] {
  return fs.readFileSync(path, 'utf8').trim().split('\n').map((l) => JSON.parse(l) as JsonlTrade)
}

const dataset = loadCandles('scripts/dataset-eurusd-m1.json')
console.log(`dataset capturé : ${dataset.length} bougies`)

/* ── RUN A (CALL, fixe) ── */
const runA = loadJsonl('scripts/runa_trade.jsonl')
const firstA = runA[0].trade
const t0A = firstA.entry.time - firstA.entry.idx * 60
const lastEntryA = runA[runA.length - 1].trade
// dernière bougie du dataset navigateur : la plus grande heure vue (entrée ou sortie)
const maxTimeA = Math.max(...runA.map((e) => e.trade.exit?.time ?? e.trade.entry.time))
const winA = sliceByTime(dataset, t0A, maxTimeA)
console.log(`\nRUN A — fenêtre navig : t0=${t0A} · ${winA.length} bougies (navig attendu ≈ 1044)`)
if (winA.length < 1000) { console.error('✗ fenêtre trop courte'); process.exit(1) }

// vérif prix : la bougie à l'heure de la 1re entrée navig doit avoir même close
const c0 = winA.find((c) => c.time === firstA.entry.time)
console.log(`prix 1re entrée : navig=${firstA.entry.price} · dataset=${c0?.close} · ${c0 && c0.close === firstA.entry.price ? 'IDENTIQUE' : 'DIFFÉRENT'}`)

const cfgA: HarnessConfig = {
  side: 'call',
  triggerIds: runA ? JSON.parse(fs.readFileSync('/tmp/cfg-runa.json', 'utf8')).callSignalIds : [],
  mode: 'ANY',
  windowBars: 3,
  expiryCandles: 1,
  cooldownCandles: 1,
  amount: 500,
  betting: 'fixed',
  martingaleFactor: 2,
  stopIds: [],
  rejectIds: [],
  streakMode: 'app',
}
console.log(`triggers RUN A : ${cfgA.triggerIds.length} conditions`)

console.log('\nconstruction de la table de signaux (fenêtres 3)…')
const tStart = Date.now()
const tableA = buildSignalTable(winA, winA.length - 1 - 1000, [3], 60)
console.log(`table construite en ${((Date.now() - tStart) / 1000).toFixed(1)} s`)

/* ── 1. voie rapide vs JSONL navigateur ── */
const fast = runStrategy(winA, cfgA, tableA, { barsBack: 1000, startBalance: 10000, payout: 92, candleSizeSec: 60 })
const fastSettled = fast.orders.filter((o) => o.status !== 'open').slice().sort((a, b) => a.entryTime - b.entryTime)
const navSorted = runA.map((e) => e.trade).sort((a, b) => a.entry.time - b.entry.time)

console.log(`\nvoie rapide : ${fast.orders.length} trades (${fastSettled.length} réglés) · navig : ${navSorted.length} réglés`)
let match = 0, mismatch = 0
const diffs: string[] = []
for (let k = 0; k < Math.max(fastSettled.length, navSorted.length); k++) {
  const f = fastSettled[k]
  const n = navSorted[k]
  if (!f || !n) { mismatch++; diffs.push(`${k}: ${f ? 'harness seul' : 'navig seul'}`); continue }
  if (f.entryTime === n.entry.time && f.status === n.status && Math.abs((f.profit ?? 0) - n.profit) < 0.01) match++
  else { mismatch++; if (diffs.length < 12) diffs.push(`${k}: harness t=${f.entryTime} ${f.status} ${f.profit} vs navig t=${n.entry.time} ${n.status} ${n.profit}`) }
}
console.log(`trades identiques : ${match}/${navSorted.length} · divergents : ${mismatch}`)
if (diffs.length) console.log(diffs.join('\n'))
console.log(`stats harness : net=${fast.stats.netProfit.toFixed(0)} WR=${fast.stats.winRate.toFixed(1)}% final=${fast.stats.finalBalance.toFixed(0)}`)
const navNet = navSorted.reduce((s, t) => s + t.profit, 0)
console.log(`stats navig   : net=${navNet.toFixed(0)} (attendu +3980)`)

/* ── 2. voie rapide vs VRAI moteur (SignalStrategyEngine) ── */
console.log('\nvoie rapide vs vrai moteur (émissions identiques)…')
const real = runWithRealEngine(winA, cfgA, { barsBack: 1000, startBalance: 10000, payout: 92, candleSizeSec: 60 })
const realTimes = real.orders.map((o) => o.entryTime).sort((a, b) => a - b).join(',')
const fastTimes = fast.orders.map((o) => o.entryTime).sort((a, b) => a - b).join(',')
console.log(`vrai moteur : ${real.orders.length} trades · voie rapide : ${fast.orders.length}`)
console.log(realTimes === fastTimes ? '✓ ÉMISSIONS STRICTEMENT IDENTIQUES' : '✗ émissions différentes (voir détails)')

/* ── RUN B2 (PUT, fixe) ── */
const runB2 = loadJsonl('scripts/runb2_trade.jsonl')
const firstB = runB2[0].trade
const t0B = firstB.entry.time - firstB.entry.idx * 60
// dataset navig = 1045 bougies (startIdx=44, barsBack=1000) : [t0 .. t0+1044*60]
const winB = sliceByTime(dataset, t0B, t0B + 1044 * 60)
console.log(`\nRUN B2 — fenêtre navig : t0=${t0B} · ${winB.length} bougies (attendu 1045)`)
const cfgB: HarnessConfig = {
  side: 'put',
  triggerIds: JSON.parse(fs.readFileSync('/tmp/cfg-runb2.json', 'utf8')).putSignalIds,
  mode: 'ANY',
  windowBars: 3,
  expiryCandles: 1,
  cooldownCandles: 1,
  amount: 500,
  betting: 'fixed',
  martingaleFactor: 2,
  stopIds: [],
  rejectIds: [],
  streakMode: 'app',
}
console.log(`triggers RUN B2 : ${cfgB.triggerIds.length} conditions`)
const tableB = buildSignalTable(winB, winB.length - 1 - 1000, [3], 60)
const fastB = runStrategy(winB, cfgB, tableB, { barsBack: 1000, startBalance: 10000, payout: 92, candleSizeSec: 60 })
const navBSorted = runB2.map((e) => e.trade).sort((a, b) => a.entry.time - b.entry.time)
console.log(`harness B2 : ${fastB.orders.length} trades (ruin@${fastB.stats.haltedAtBar}) · navig : ${navBSorted.length} (ruin@897)`)
let matchB = 0
const minLen = Math.min(fastB.orders.length, navBSorted.length)
for (let k = 0; k < minLen; k++) {
  const f = fastB.orders.slice().sort((a, b) => a.entryTime - b.entryTime)[k]
  if (f.entryTime === navBSorted[k].entry.time && f.status === navBSorted[k].status) matchB++
}
console.log(`trades identiques B2 : ${matchB}/${minLen}`)
console.log(`stats B2 harness : net=${fastB.stats.netProfit.toFixed(0)} WR=${fastB.stats.winRate.toFixed(1)}% ruin=${fastB.stats.ruin}`)
const navNetB = navBSorted.reduce((s, t) => s + t.profit, 0)
console.log(`stats B2 navig   : net=${navNetB.toFixed(0)} (attendu -9750)`)

console.log('\n══ VALIDATION TERMINÉE ══')
