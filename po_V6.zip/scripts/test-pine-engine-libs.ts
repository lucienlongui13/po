/**
 * test-pine-engine-libs.ts — Test end-to-end v1.7 via le VRAI pont applicatif :
 * src/lib/pine-engine.ts (runPineScript + getPineInputSchema), registre
 * multi-librairies alimenté par importLibraryBundle, pack PiracyChecker réel.
 *
 * Vérifie : compilation + exécution de Main.pine sur le dataset capturé,
 * drawings BOS/CHoCH/CISD attendus, schéma des 14 inputs, messages d'erreur
 * propres quand une librairie manque, et invalidation du cache après import.
 *
 * Exécution : npx tsx scripts/test-pine-engine-libs.ts
 */
import { readFileSync } from 'node:fs'

/* ── shim localStorage AVANT tout import de pine-libraries/pine-engine ── */
const backing = new Map<string, string>()
;(globalThis as any).window = {
  localStorage: {
    getItem: (k: string) => backing.get(k) ?? null,
    setItem: (k: string, v: string) => { backing.set(k, String(v)) },
    removeItem: (k: string) => { backing.delete(k) },
  },
}

let importLibraryBundle!: typeof import('../src/lib/pine-libraries').importLibraryBundle
let removeLibrary!: typeof import('../src/lib/pine-libraries').removeLibrary
let listLibraries!: typeof import('../src/lib/pine-libraries').listLibraries
let runPineScript!: typeof import('../src/lib/pine-engine').runPineScript
let getPineInputSchema!: typeof import('../src/lib/pine-engine').getPineInputSchema
let invalidatePineCaches!: typeof import('../src/lib/pine-engine').invalidatePineCaches

let failures = 0
let passed = 0
const check = (name: string, cond: boolean, detail = '') => {
  if (!cond) { failures++; console.error(`  ✗ ${name} ${detail}`) }
  else { passed++; console.log(`  ✓ ${name}${detail ? ' — ' + detail : ''}`) }
}

/* ── sources du pack + dataset ── */
const base = '/home/z/my-project/upload/piracy_extracted/Market_structures_scripts'
const rd = (p: string) => readFileSync(`${base}/${p}`, 'utf8')
const mainSrc = rd('Main.pine')
const packFiles = [
  { name: 'Main.pine', source: mainSrc },
  { name: 'PubLibSwing.pine', source: rd('libs/PubLibSwing.pine') },
  { name: 'PubLibTrend.pine', source: rd('libs/PubLibTrend.pine') },
  { name: 'PubLibUtility.pine', source: rd('libs/PubLibUtility.pine') },
  { name: 'PubLibCandleTrend.pine', source: rd('libs/PubLibCandleTrend.pine') },
]
const raw = JSON.parse(readFileSync('/home/z/my-project/scripts/dataset-eurusd-m1.json', 'utf8'))
const candles = (raw.candles ?? raw).map((c: any) => ({
  time: Number(c.time) * 1000,
  open: Number(c.open), high: Number(c.high), low: Number(c.low), close: Number(c.close),
  volume: Number(c.volume) || 0,
}))

const OPTS = { symbol: 'EURUSD_otc', timeframe: '1' } as const

async function main() {
  const libMod = await import('../src/lib/pine-libraries')
  const pineEngine = await import('../src/lib/pine-engine')
  importLibraryBundle = libMod.importLibraryBundle
  removeLibrary = libMod.removeLibrary
  listLibraries = libMod.listLibraries
  runPineScript = pineEngine.runPineScript
  getPineInputSchema = pineEngine.getPineInputSchema
  invalidatePineCaches = pineEngine.invalidatePineCaches

  console.log(`dataset : ${candles.length} bougies M1\n`)

  /* ── 1. AVANT import : erreur propre, librairies citées ── */
  console.log('[1] Avant import — erreur de compilation propre')
  {
    for (const lib of listLibraries()) removeLibrary(lib.key)
    invalidatePineCaches()
    const res = await runPineScript(mainSrc, candles, OPTS)
    check('échec attendu (librairies absentes)', !res.ok)
    if (!res.ok) {
      check('message cite la première librairie manquante', res.error.message.includes('PiracyChecker/PubLibSwing/3'),
        res.error.message.slice(0, 90).replace(/\n/g, ' ') + '…')
      check('message oriente vers l\'import ZIP', res.error.message.includes('Importer ZIP'), '')
      check('étape = compiler', res.error.stage === 'compiler')
    }
    // le schéma d'inputs échoue aussi proprement (pas de crash)
    const schema = await getPineInputSchema(mainSrc)
    check('schéma inputs : erreur propre (liste vide + message)', Array.isArray(schema.inputs) && schema.inputs.length === 0 && Boolean(schema.error))
  }

  /* ── 2. APRÈS import du pack : exécution complète ── */
  console.log('\n[2] Après import du pack — exécution de Main.pine (BOS/CHoCH/CISD)')
  {
    const report = importLibraryBundle(packFiles)
    check('import : 4 librairies + alias + 0 manquante',
      report.registered.length === 4 && report.missing.length === 0,
      report.registered.flatMap((r) => r.keys).join(' · '))
    invalidatePineCaches()

    const t0 = Date.now()
    const res = await runPineScript(mainSrc, candles, OPTS)
    const dt = Date.now() - t0
    check('exécution OK', res.ok, `${dt} ms`)
    if (res.ok) {
      const r = res.result
      check('titre conforme', r.title === 'BOS, CHoCH and CISD [PiracyChecker]', r.title)
      check('drawings présents (labels + lignes)', r.drawings.length > 400, `${r.drawings.length} drawings`)
      const labels = r.drawings.filter((d) => d.kind === 'label') as any[]
      const texts = labels.map((l) => String(l.text ?? '')).filter(Boolean)
      const families = ['BOS Up', 'BOS Down', 'CHoCH Up', 'CHoCH Down', 'CISD Up', 'CISD Down']
      const counts: Record<string, number> = {}
      for (const t of texts) counts[t] = (counts[t] ?? 0) + 1
      check('les 6 familles BOS/CHoCH/CISD dessinées', families.every((f) => (counts[f] ?? 0) > 0), JSON.stringify(counts))
      check('lignes d\'événements et de tendance', r.drawings.filter((d) => d.kind === 'line').length > 200,
        `${r.drawings.filter((d) => d.kind === 'line').length} lignes`)
      // x résolues en temps epoch (le pont normalise bar_index → time)
      const line0 = r.drawings.find((d) => d.kind === 'line') as any
      check('coordonnée x résolue en epoch ms', typeof line0?.x1 === 'number' && line0.x1 > 1e12, `x1=${line0?.x1}`)
    }
  }

  /* ── 3. Schéma des inputs (modale Réglages) ── */
  console.log('\n[3] Schéma des inputs (modale Réglages)')
  {
    const schema = await getPineInputSchema(mainSrc)
    check('14 inputs déclarés', schema.inputs !== null && schema.inputs.length === 14,
      `${schema.inputs?.length ?? 0} inputs`)
    if (schema.inputs) {
      const colors = schema.inputs.filter((i) => i.kind === 'color').length
      const bools = schema.inputs.filter((i) => i.kind === 'bool').length
      const selects = schema.inputs.filter((i) => i.options && i.options.length > 0).length
      check('répartition 7 couleurs (6 labels + texte) + 6 bools + 1 select', colors === 7 && bools === 6 && selects === 1,
        `couleurs=${colors} bools=${bools} selects=${selects}`)
    }
  }

  /* ── 4. Overrides d'inputs (modale Réglages → re-exécution) ── */
  console.log('\n[4] Overrides d\'inputs')
  {
    const schema = await getPineInputSchema(mainSrc)
    const sizeInput = schema.inputs?.find((i) => i.title?.includes('Label Size'))
    check('input « Label Size » trouvé', Boolean(sizeInput), sizeInput?.title ?? '')
    if (sizeInput) {
      const res = await runPineScript(mainSrc, candles, { ...OPTS, inputs: { [sizeInput.key]: 'Huge' } })
      check('re-exécution avec override Label Size=Huge', res.ok)
    }
    const colorInput = schema.inputs?.find((i) => i.kind === 'color')
    if (colorInput) {
      const res = await runPineScript(mainSrc, candles, { ...OPTS, inputs: { [colorInput.key]: '#00E676' } })
      check('re-exécution avec override couleur', res.ok)
      if (res.ok) {
        const labels = res.result.drawings.filter((d) => d.kind === 'label') as any[]
        const colored = labels.filter((l) => String(l.color ?? '').toUpperCase().startsWith('#00E676'))
        check('couleur appliquée aux labels', colored.length > 0, `${colored.length}/${labels.length} labels`)
      }
    }
  }

  /* ── 5. Suppression d'une librairie → retour à l'erreur propre ── */
  console.log('\n[5] Suppression d\'une librairie — retour à l\'erreur propre')
  {
    removeLibrary('PiracyChecker/PubLibTrend/3')
    invalidatePineCaches()
    const res = await runPineScript(mainSrc, candles, OPTS)
    check('échec propre après suppression', !res.ok)
    if (!res.ok) {
      check('message cite PubLibTrend (importée par le script principal)',
        res.error.message.includes('PiracyChecker/PubLibTrend/3'))
    }
    // ré-import → tout refonctionne (cycle complet)
    importLibraryBundle(packFiles)
    invalidatePineCaches()
    const res2 = await runPineScript(mainSrc, candles, OPTS)
    check('cycle complet : ré-import → exécution OK', res2.ok)
  }

  console.log(`\n═══ RÉSULTAT : ${passed} ✓ · ${failures} ✗ ═══`)
  process.exit(failures > 0 ? 1 : 0)
}

main().catch((err) => { console.error(err); process.exit(1) })
