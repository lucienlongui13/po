/**
 * test-fix-gaps.ts — VALIDATION DES CORRECTIONS v6.10 CONTRE fix_gaps.har.
 * ====================================================================
 *
 * Rejoue le scénario RÉEL observé dans le HAR de l'utilisateur (session
 * demo-api-eu entry[102], EURNZD_otc, period 60) :
 *
 *   T0   : sélection de l'asset → subfor + changeSymbol(S60)
 *   T0+ms : broker → `updateHistoryNewFast` = 1301 ticks [1788219222 → 1788219843]
 *   T0+  : broker → `updateStream` = 545 ticks [1788219835 → 1788220080]
 *          (8 s de RECOUVREMENT avec le snapshot fast — recouvrement réel !)
 *   T0+~min : backend → `loadHistoryPeriodFast` = 150 bougies S60
 *          [1788204900 → 1788213840] — l'historique paginé, ARRIVÉ EN RETARD
 *
 *   → COUTURE RÉELLE : [1788213840, 1788219180] = ~89 bougies que le broker
 *     n'a JAMAIS servies (le flux OTC n'est généré que pour les assets actifs).
 *
 * AVANT v6.10 : ce trou de 89 bougies était classé BLOQUANT (règle « bord
 *   live » comparée au DERNIER tick) → gapSeverity 'critical' →
 *   canTrade() = CRITICAL_GAP → « TRADING BLOQUÉ » sur la carte.
 * APRÈS v6.10 : le snapshot fast est INGÉRÉ (graine ~12 min immédiate) et
 *   le trou est reconnu COUTURE (fin ≈ PREMIER tick live) → non bloquant,
 *   trading autorisé après le warm-up (25 bougies fraîches).
 *
 * Exécution (depuis la racine du projet) : npx tsx scripts/test-fix-gaps.ts
 */
import { readFileSync } from 'node:fs'
import { join } from 'node:path'
import { CandleSyncManager, type SyncEvent } from '../mini-services/iqoption-backend/candle-sync-manager.js'
import { MarketDataHealth } from '../mini-services/iqoption-backend/market-data-health.js'
import { bucketStart } from '../mini-services/iqoption-backend/timeframe.js'

const ASSET = 'EURNZD_otc'
const TF = 60

interface Tick { time: number; price: number }
interface Candle { time: number; open: number; high: number; low: number; close: number; volume?: number }

// Chemin résolu relativement AU FICHIER DE TEST (robuste quel que soit le cwd) :
const HERE = typeof __dirname !== 'undefined' ? __dirname : process.cwd()
const FIXTURE = JSON.parse(
  readFileSync(join(HERE, 'fixtures', 'fix-gaps-fixture.json'), 'utf-8'),
) as {
  ticks: [number, number][]          // fast + stream fusionnés (chronologique)
  fast_ticks_count: number
  stream_ticks_count: number
  candles_s60_po: Candle[]           // bougies authentiques loadHistoryPeriodFast
}

// Les ticks fast et stream du HAR, reconstitués depuis le fixture fusionné :
// fast = les fast_ticks_count premiers, stream = le reste (recouvrement réel
// de 8 s — le stream démarre AVANT la fin du snapshot fast).
const fastTicks: Tick[] = FIXTURE.ticks.slice(0, FIXTURE.fast_ticks_count).map(([t, p]) => ({ time: t, price: p }))
const streamTicks: Tick[] = FIXTURE.ticks.slice(FIXTURE.fast_ticks_count).map(([t, p]) => ({ time: t, price: p }))
const poCandles = FIXTURE.candles_s60_po

let pass = 0
let fail = 0
const ok = (name: string, cond: boolean, detail = '') => {
  if (cond) { pass++; console.log(`  ✓ ${name}`) }
  else { fail++; console.log(`  ✗ ${name}${detail ? ' — ' + detail : ''}`) }
}

const nowMs = () => Date.now()

// ────────────────────────────────────────────────────────────────────────────
console.log('══ W0 — Données réelles du HAR (sanity) ══')
{
  ok(`snapshot fast : ${fastTicks.length} ticks [${fastTicks[0].time.toFixed(1)} → ${fastTicks[fastTicks.length - 1].time.toFixed(1)}]`, fastTicks.length > 1000)
  ok(`stream live : ${streamTicks.length} ticks`, streamTicks.length > 400)
  ok(`bougies PO authentiques (loadHistoryPeriodFast) : ${poCandles.length} S60 [${poCandles[0].time} → ${poCandles[poCandles.length - 1].time}]`, poCandles.length >= 140)
  const histEnd = poCandles[poCandles.length - 1].time + TF
  const liveStart = Math.floor(fastTicks[0].time / TF) * TF
  const seamCandles = Math.round((liveStart - histEnd) / TF)
  console.log(`  ℹ couture réelle identifiée : [${histEnd} → ${liveStart}] = ${seamCandles} bougies manquantes (jamais servies par le broker)`)
  ok(`la couture dépasse 5 bougies (> 5 → 'critical' AVANT le fix) : ${seamCandles} > 5`, seamCandles > 5)
}

// ────────────────────────────────────────────────────────────────────────────
console.log('══ W1 — Ingestion du snapshot updateHistoryNewFast (v6.10) ══')
const sync = new CandleSyncManager({ periods: [TF] })
sync.setActiveAssets([ASSET], TF, ASSET)
{
  const res = sync.ingestHistoryTicks(ASSET, fastTicks)
  ok(`fusion sans erreur : ${res.merged} ticks au buffer`, res.merged === fastTicks.length)
  ok(`premier tick live = ${res.firstTickSec.toFixed(1)} (getFirstLiveTickSec)`,
    Math.abs(sync.getFirstLiveTickSec(ASSET) - fastTicks[0].time) < 1e-9)
  ok(`dernier tick marché = ${res.lastTickSec.toFixed(1)}`,
    Math.abs(sync.getLatestMarketTimeSec(ASSET) - fastTicks[fastTicks.length - 1].time) < 1e-9)
  const s = sync.getSeries(ASSET, TF)
  ok(`re-seed S60 immédiat : ${s.closed.length} bougies clôturées + forming=${s.forming ? 1 : 0} (~12 min de ticks)`,
    s.closed.length >= 10)
  ok(`toutes les bougies alignées % 60 === 0`, [...s.closed, ...(s.forming ? [s.forming] : [])].every(c => c.time % TF === 0))
}

// ────────────────────────────────────────────────────────────────────────────
console.log('══ W2 — Le stream live prolonge le snapshot (recouvrement réel de 8 s) ══')
{
  let applied = 0
  let duplicates = 0
  for (const t of streamTicks) {
    const r = sync.ingestTick(ASSET, { marketTimeSec: t.time, price: t.price, receivedAtMs: nowMs() })
    if (r.applied) applied++
    else duplicates++
  }
  const buffer = sync.getTickBuffer(ASSET)
  ok(`${applied} ticks stream appliqués, ${duplicates} doublons d'horodatage tolérés (recouvrement fast ↔ stream — anti-rejeu par timestamp exact)`,
    applied + duplicates === streamTicks.length && applied > duplicates)
  ok(`buffer fusionné trié strictement croissant (${buffer.length} ticks)`,
    buffer.every((t, i) => i === 0 || t.time > buffer[i - 1].time))
  // Anti-contamination : le premier tick du buffer est TOUJOURS le début du
  // segment live contigu (le snapshot fast a été fusionné, pas écrasé).
  ok(`getFirstLiveTickSec = début du snapshot fast (${sync.getFirstLiveTickSec(ASSET).toFixed(1)}) — fusion, pas remplacement`,
    Math.abs(sync.getFirstLiveTickSec(ASSET) - fastTicks[0].time) < 1e-9)
}

// ────────────────────────────────────────────────────────────────────────────
console.log('══ W3 — Arrivée TARDIVE de l\'historique paginé (loadHistoryPeriodFast) ══')
// Le fetch paginé arrive APRÈS le live — exactement le scénario multi-assets
// 24 (file de concurrence 4). On capture l'événement gap-detected émis par la
// validation du synchroniseur.
const gapEvents: SyncEvent[] = []
syncOnEvent()
{
  const gen = sync.beginHistoryLoad(ASSET, TF)
  const ingest = sync.ingestHistory(ASSET, TF, poCandles, { generation: gen, source: 'history' })
  ok(`historique paginé accepté (fusion par bucket, priorité historique clôturé)`, ingest.accepted)
  const seriesAll = [...ingest.series.closed, ...(ingest.series.forming ? [ingest.series.forming] : [])]
  ok(`série fusionnée : ${seriesAll.length} bougies [${seriesAll[0].time} → ${seriesAll[seriesAll.length - 1].time}]`,
    seriesAll.length > 140)
  ok(`la couture est détectée par findGaps (gap-detected émis avec sa position)`,
    gapEvents.some(e => e.type === 'gap-detected'))
  const gapEv = gapEvents.find(e => e.type === 'gap-detected')
  const holes = (gapEv?.data as any)?.gapDetails as Array<{ startTime: number; endTime: number; missingCandles: number }>
  ok(`le trou détecté = la couture réelle (~89 bougies)`,
    !!holes && holes.length >= 1 && holes.every(h => h.missingCandles >= 85),
    holes ? JSON.stringify(holes) : 'aucun')
}

function syncOnEvent(): void {
  // Re-branche le manager AVEC un callback d'événement : les managers du
  // backend câblent applySyncGapsToHealth sur gap-detected/history-loaded.
  ;(sync as any).onSyncEventCb = (event: SyncEvent) => {
    if (event.type === 'gap-detected' || event.type === 'history-loaded') gapEvents.push(event)
  }
}

// ────────────────────────────────────────────────────────────────────────────
console.log('══ W4 — Classification de couture (le CŒUR du fix CRITICAL_GAP) ══')
// Warm-up identique pour les DEUX santés (comme le pipeline réel) : ticks
// vivants + historique prêt AVANT la divergence (l'ancienne/nouvelle règle
// de couture) — sinon DISCONNECTED masque la vraie raison.
const warmup = (h: MarketDataHealth): void => {
  h.onTick(nowMs())
  const s = sync.getSeries(ASSET, TF)
  h.onHistoryIngested({
    closedCount: s.closed.length,
    firstTimestamp: s.closed.length ? s.closed[0].time : null,
    // L'ingestion du snapshot fast passe les bougies CLÔTURÉES uniquement
    // (cf. ingestHistoryFastSnapshot — pas la forming).
    lastTimestamp: s.closed.length ? s.closed[s.closed.length - 1].time : null,
  })
  // Les clôtures fraîches du segment live alimentent la santé (chemin réel :
  // callback onCandleClosed du CandleSyncManager, ordre chronologique).
  const fresh = s.closed.filter(c => c.time >= Math.floor(fastTicks[0].time / TF) * TF)
  for (const c of fresh) h.onCandleClosed(c, nowMs())
  h.onTick(nowMs())
}
const health = new MarketDataHealth(ASSET, { timeframeSec: TF, minCandles: 25, minHealthScoreToTrade: 80 })
{
  // Simulation identique au backend : applySyncGapsToHealth passe
  // liveEdge (dernier tick) ET firstLiveSec (premier tick du segment).
  const gapEv = gapEvents.find(e => e.type === 'gap-detected')
  const holes = ((gapEv?.data as any)?.gapDetails ?? []).map((g: any) => ({
    endTimeSec: g.endTime as number,
    startTimeSec: g.startTime as number,
    missingCandles: g.missingCandles as number,
  }))
  const liveEdge = sync.getLatestMarketTimeSec(ASSET)
  const firstLiveSec = sync.getFirstLiveTickSec(ASSET)

  // AVANT (règle v6.5.1, comparaison au DERNIER tick) : PAS une couture.
  const healthOld = new MarketDataHealth(ASSET, { timeframeSec: TF, minCandles: 25, minHealthScoreToTrade: 80 })
  warmup(healthOld)
  healthOld.onSyncGaps(holes, nowMs(), liveEdge) // ← signature ancienne (3 args)
  const oldState = healthOld.update(nowMs())
  const oldCheck = healthOld.canTrade(nowMs())
  // v6.11 — l'ancienne règle MALCLASSE toujours le trou (sévérité critique
  // dans l'ÉTAT — observable) mais la politique structurelle fait que le
  // trading reste AUTORISÉ : plus aucune carte ne peut afficher
  // « TRADING BLOQUÉ — CRITICAL_GAP » (garde de régression).
  ok(`AVANT le fix : trou de 88 bougies MALCLASSÉ (sévérité ${healthOld.gapSeverityLevel} dans l'état) mais trading AUTORISÉ (v6.11 : les gaps ne bloquent plus)`,
    healthOld.gapSeverityLevel === 'critical' && oldCheck.allowed && oldCheck.reason == null,
    `reason=${oldCheck.reason}, status=${oldState.status}, severity=${healthOld.gapSeverityLevel}`)

  // APRÈS (règle v6.10, comparaison au PREMIER tick du segment live) : couture.
  warmup(health)
  health.onSyncGaps(holes, nowMs(), liveEdge, firstLiveSec)
  const state = health.update(nowMs())
  ok(`APRÈS le fix : sévérité ${state.gapSeverity ?? 'none'} (couture non bloquante)`,
    (state.gapSeverity ?? 'none') !== 'critical')
  const reasons = state.reasons.join(' | ')
  ok(`le motif « couture » est signalé comme NON bloquant`, reasons.includes('seam') || reasons.includes('couture') || !reasons.includes('critical candle gaps'),
    reasons)
}

// ────────────────────────────────────────────────────────────────────────────
console.log('══ W5 — Trading AUTORISÉ après warm-up (plus de TRADING BLOQUÉ) ══')
{
  // warmup() a déjà : onHistoryIngested (snapshot fast) + onCandleClosed
  // (clôtures fraîches chronologiques) + onTick. L'arrivée TARDIVE de la
  // pagination (fetchAndBroadcastHistory → processHistory, série avec
  // forming) se produit APRÈS les clôtures réelles — comme en production.
  const check = health.canTrade(nowMs())
  const s = sync.getSeries(ASSET, TF)
  const freshCount = s.closed.filter(c => c.time >= Math.floor(fastTicks[0].time / TF) * TF).length
  const totalCount = s.closed.length
  // v6.11 — comptage PLEINE SÉRIE : la profondeur se mesure sur TOUTE la
  // série canonique (historique paginé + live fusionnés), PLUS sur le seul
  // segment frais post-couture. Le warm-up artificiellement prolongé
  // (INSUFFICIENT_CANDLES perpétuel en multi-assets) disparaît.
  console.log(`  ℹ bougies fraîches depuis la couture : ${freshCount} · série complète : ${totalCount} (minCandles=25, comptage pleine série v6.11)`)
  if (totalCount >= 25) {
    ok(`série complète suffisante (${totalCount} ≥ 25) → trading AUTORISÉ même pendant le warm-up post-couture (score ${check.score}, statut ${check.status})`,
      check.allowed, JSON.stringify(check))
  } else {
    // Série complète insuffisante (cas extrême) : bloqué UNIQUEMENT par
    // INSUFFICIENT_CANDLES — JAMAIS par CRITICAL_GAP.
    ok(`série complète insuffisante → blocage par INSUFFICIENT_CANDLES uniquement (PAS CRITICAL_GAP)`,
      !check.allowed && check.reason === 'INSUFFICIENT_CANDLES',
      `reason=${check.reason}`)
  }
  const state = health.update(nowMs())
  ok(`statut final : ${state.status} (READY attendu après warm-up, GAP attendu pendant)`,
    state.status === 'READY' || state.status === 'GAP' || state.status === 'SYNCING')
}

// ────────────────────────────────────────────────────────────────────────────
console.log('══ W6 — Fidélité de l\'agrégation (S60, données réelles) ══')
{
  const s = sync.getSeries(ASSET, TF)
  const ours = [...s.closed, ...(s.forming ? [s.forming] : [])]
  // Invariants OHLC + grille
  ok(`invariant OHLC sur toute la série fusionnée (historique PO + ticks ré-agrégés)`,
    ours.every(c => c.high >= Math.max(c.open, c.close) - 1e-9 && c.low <= Math.min(c.open, c.close) + 1e-9))
  ok(`grille % 60 === 0 sur toute la série`, ours.every(c => c.time % TF === 0))
  // La bougie en formation couvre le dernier tick
  const lastTick = FIXTURE.ticks[FIXTURE.ticks.length - 1][0]
  const forming = s.forming
  ok(`bougie en formation au bucket du dernier tick (${bucketStart(lastTick, TF)})`,
    !!forming && forming.time === bucketStart(lastTick, TF))
  ok(`close de la formation = dernier prix tické`,
    Math.abs((forming?.close ?? -1) - FIXTURE.ticks[FIXTURE.ticks.length - 1][1]) < 1e-9)
  // Les bougies du segment live ré-agrégées depuis les ticks : l'OPEN de la
  // première = prix du premier tick fast (fidélité snapshot).
  const firstLiveBucket = bucketStart(fastTicks[0].time, TF)
  const firstLiveCandle = ours.find(c => c.time === firstLiveBucket)
  ok(`open de la 1re bougie live = prix du 1er tick du snapshot (${firstLiveCandle?.open})`,
    !!firstLiveCandle && Math.abs(firstLiveCandle.open - fastTicks[0].price) < 1e-9)
  // Les bougies de l'historique PO sont intactes dans la série fusionnée
  const poFirst = poCandles[0]
  const mergedFirst = ours.find(c => c.time === poFirst.time)
  ok(`première bougie PO (${poFirst.time}) préservée dans la fusion (priorité historique clôturé)`,
    !!mergedFirst && Math.abs(mergedFirst.close - poFirst.close) < 1e-9)
}

// ────────────────────────────────────────────────────────────────────────────
console.log('══ W7 — Ré-ingestion idempotente (reconnexion : le broker REPOUSSE le snapshot) ══')
{
  // À la reconnexion, activateSymbolStreams renvoie changeSymbol → le broker
  // re-pousse updateHistoryNewFast → la fusion doit être IDEMPOTENTE
  // (dédoublonnage par timestamp exact, aucun état corrompu).
  const before = sync.getTickBuffer(ASSET).length
  const res = sync.ingestHistoryTicks(ASSET, fastTicks)
  const after = sync.getTickBuffer(ASSET).length
  ok(`re-snapshot → ${res.duplicates} doublons absorbés, buffer stable (${before} → ${after})`,
    after === before && res.duplicates === fastTicks.length)
  const s = sync.getSeries(ASSET, TF)
  ok(`la série reste cohérente après re-snapshot (une seule formation, grille intacte)`,
    (!s.forming || s.forming.time === bucketStart(sync.getLatestMarketTimeSec(ASSET), TF))
    && [...s.closed, ...(s.forming ? [s.forming] : [])].every(c => c.time % TF === 0))
}

// ────────────────────────────────────────────────────────────────────────────
console.log('══ W8 — v6.10.1 : les 3 correctifs multi-assets (24 assets) ══')
{
  // ── W8.1 : la fusion du snapshot N'ÉMET PLUS de faux trous ──────────────
  // AVANT v6.10.1 : ingestHistoryTicks poussait 'history-loaded' SANS
  // gapDetails → le fallback legacy comptait 4 FAUX trous bloquants par
  // snapshot (un par timeframe) → CRITICAL_GAP après reconnexion.
  const events: SyncEvent[] = []
  ;(sync as any).onSyncEventCb = (event: SyncEvent) => { events.push(event) }
  sync.ingestHistoryTicks(ASSET, fastTicks)
  const fakeGapEvents = events.filter(e =>
    (e.type === 'gap-detected' || e.type === 'history-loaded'))
  const mergedEvents = events.filter(e => e.type === 'history-ticks-merged')
  ok(`la fusion émet 'history-ticks-merged' (${mergedEvents.length} événements, un par timeframe)`,
    mergedEvents.length >= 1)
  ok(`AUCUN événement gap/history-loaded porteur de trous n'est émis par la fusion (0 faux trou)`,
    fakeGapEvents.length === 0,
    fakeGapEvents.map(e => e.type).join(','))

  // ── W8.2 : frontière d'historique STABLE (deep: false) ──────────────────
  // Le snapshot fast ne doit PAS écraser historyEndSec (fin de PAGINATION) :
  // la règle « frontière » de couture en dépend aux ré-ingestions.
  const h = new MarketDataHealth(ASSET, { timeframeSec: TF, minCandles: 25, minHealthScoreToTrade: 80 })
  h.onStreamState(true)
  h.onTick(nowMs())
  h.onHistoryIngested({ closedCount: 1440, firstTimestamp: 1788204900, lastTimestamp: 1788213840 }, { deep: true })
  const boundaryAfterPagination = (h as any).historyEndSec
  h.onHistoryIngested({ closedCount: 24, firstTimestamp: 1788219222, lastTimestamp: 1788219840 }, { deep: false })
  ok(`historyEndSec reste la fin de PAGINATION après un snapshot fast (deep:false) — ${boundaryAfterPagination}`,
    (h as any).historyEndSec === 1788213840 && boundaryAfterPagination === 1788213840)

  // ── W8.3 : ré-détection de la couture APRÈS glissement du buffer ────────
  // Le buffer de ticks (4800) glisse après ~40 min → firstLiveSec dérive →
  // AVANT v6.10.1, la ré-ingestion classait le trou de couture BLOQUANT.
  // APRÈS : l'amarrage STICKY (trou finissant à la couture mémorisée) +
  // la frontière stable le reclassent couture.
  const liveStart = Math.floor(fastTicks[0].time / TF) * TF
  const holes = [{
    endTimeSec: liveStart,             // fin du trou = début du segment live
    startTimeSec: 1788213840 + TF,     // début = frontière pagination + 1 tf
    missingCandles: 89,
  }]
  // 1re détection : buffer frais (firstLiveSec = début du snapshot fast)
  const hA = new MarketDataHealth(ASSET, { timeframeSec: TF, minCandles: 25, minHealthScoreToTrade: 80 })
  hA.onStreamState(true); hA.onTick(nowMs())
  hA.onHistoryIngested({ closedCount: 1440, firstTimestamp: 1788204900, lastTimestamp: 1788213840 })
  hA.onSyncGaps(holes, nowMs(), sync.getLatestMarketTimeSec(ASSET), sync.getFirstLiveTickSec(ASSET))
  ok(`1re détection : couture reconnue (seam=${hA.update(nowMs()).seamGapCount})`,
    hA.update(nowMs()).seamGapCount === 89)
  // Ré-ingestion TARDIVE (reconnexion/gap-resync) : le buffer a glissé —
  // firstLiveSec (simulé) est TRÈS loin de la fin du trou → seule la règle
  // sticky + la frontière stable peuvent reconnaître la couture.
  const driftedFirstLiveSec = liveStart + 3600   // +1 h de glissement
  hA.onSyncGaps(holes, nowMs(), sync.getLatestMarketTimeSec(ASSET), driftedFirstLiveSec)
  const snapA = hA.update(nowMs())
  ok(`ré-ingestion après glissement : le trou reste COUTURE (seam=${snapA.seamGapCount}, PAS bloquant)`,
    snapA.seamGapCount === 89 && snapA.recentGapCount - snapA.seamGapCount === 0,
    JSON.stringify({ recent: snapA.recentGapCount, seam: snapA.seamGapCount }))

  // ── W8.4 : recomptage rétroactif des bougies fraîches ───────────────────
  // La couture est détectée TARD (pagination lente multi-assets) : les
  // bougies live clôturées AVANT la détection doivent compter pour le warm-up.
  const hB = new MarketDataHealth(ASSET, { timeframeSec: TF, minCandles: 25, minHealthScoreToTrade: 80 })
  hB.onStreamState(true); hB.onTick(nowMs())
  hB.onHistoryIngested({ closedCount: 1440, firstTimestamp: 1788204900, lastTimestamp: 1788213840 })
  hB.onSyncGaps(holes, nowMs(), undefined, liveStart)
  // 10 bougies live déjà clôturées depuis la couture (avant détection) :
  const closedSinceSeam = Array.from({ length: 10 }, (_, i) => ({ time: liveStart + i * TF }))
  hB.recountFreshCandles(closedSinceSeam)
  ok(`recomptage rétroactif : ${(hB as any).freshCandleCount} bougies fraîches (10 attendues)`,
    (hB as any).freshCandleCount === 10)
  hB.recountFreshCandles([...closedSinceSeam, { time: liveStart + 10 * TF }])
  ok(`le recomptage est idempotent/croissant (11 après une bougie de plus)`,
    (hB as any).freshCandleCount === 11)
}
;(sync as any).onSyncEventCb = undefined

console.log('═'.repeat(76))
console.log(`RÉSULTAT : ${pass} test(s) OK, ${fail} échec(s)`)
if (fail === 0) {
  console.log(`
✔ CORRECTIONS v6.10+v6.10.1 VALIDÉES SUR LES DONNÉES RÉELLES (fix_gaps.har) :
  1. le snapshot updateHistoryNewFast (ticks) est INGÉRÉ — graine ~12 min
     immédiate par asset (plus d'attente de la pagination lente) ;
  2. la couture historique↔live (~89 bougies jamais servies) est classée
     NON BLOQUANTE (fin du trou ≈ premier tick live, plus dernier tick) ;
  3. le trading reprend après le warm-up au lieu de rester TRADING BLOQUÉ ;
  4. la ré-ingestion (reconnexion) est idempotente ;
  5. v6.10.1 — plus de FAUX trous émis par la fusion de ticks (4 par
     snapshot AVANT → CRITICAL_GAP après reconnexion en multi-assets) ;
  6. v6.10.1 — couture ré-détectable après glissement du buffer (amarrage
     sticky + frontière de pagination stable) ;
  7. v6.10.1 — recomptage RÉTROACTIF des bougies fraîches (warm-up non
     prolongé artificiellement quand la pagination arrive tard).`)
}
process.exit(fail === 0 ? 0 : 1)
