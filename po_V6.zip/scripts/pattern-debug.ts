import { compile, Engine, ArrayFeed } from '@heyphat/piner'
import { readFileSync } from 'node:fs'

const base = readFileSync('TradingView_pine_scripts_samples/pattern_1.pine', 'utf8')
// Instrument: force-draw an orange line on every slPrice bar (4-space indent).
const debug = base.replace(
  `tripleBottom = slPrice and unbrokenPeak`,
  `if slPrice
    line.new(bar_index - 1, low, bar_index, low, color=color.orange, width=3)
tripleBottom = slPrice and unbrokenPeak`
)
const bars = []
let price = 100
let seed = 42
const rand = () => { seed = (seed * 1103515245 + 12345) % 2147483648; return seed / 2147483648 }
for (let i = 0; i < 600; i++) {
  const target = 100 + Math.sin(i / 20) * 3
  const open = price
  const close = target + (rand() - 0.5) * 0.05
  const high = Math.max(open, close) + rand() * 0.02
  const low = Math.min(open, close) - rand() * 0.02
  bars.push({ time: 1_700_000_000_000 + i * 60_000, open, high, low, close, volume: 100 })
  price = close
}
try {
  const compiled = compile(debug)
  const engine = new Engine(compiled, new ArrayFeed(bars))
  await engine.run({ symbol: 'X', timeframe: '1' })
  const drawings = engine.drawings ?? []
  const types = {}
  for (const d of drawings) types[d.type] = (types[d.type] ?? 0) + 1
  console.log('drawings:', drawings.length, JSON.stringify(types))
  for (const d of drawings.slice(0, 3)) console.log(' ', d.type, JSON.stringify(d.props).slice(0, 100))
} catch (err) {
  console.log('ERROR:', err.message.slice(0, 200))
}

// print non-NA lines
const engine2 = new Engine(compile(debug), new ArrayFeed(bars))
await engine2.run({ symbol: 'X', timeframe: '1' })
let real = 0, na = 0
for (const d of engine2.drawings) {
  const p = d.props
  const isNa = (v) => v == null || (typeof v === 'object' && v.__na === true)
  if (isNa(p.x1) && isNa(p.x2)) na++
  else { real++; if (real <= 3) console.log('REAL:', d.type, JSON.stringify(p).slice(0, 120)) }
}
console.log(`real-coord drawings: ${real}, NA-only: ${na}`)
