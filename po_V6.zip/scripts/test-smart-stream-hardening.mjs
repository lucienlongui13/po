import fs from 'node:fs';
import assert from 'node:assert/strict';

const srcPath = new URL('../mini-services/iqoption-backend/index.ts', import.meta.url);
const src = fs.readFileSync(srcPath, 'utf8');

// 1. v20 — Auto Switch Assets : le switch post-trade a été REMPLACÉ par la
// règle « payout < 92 % + dernier ordre = GAIN → asset payout == 92 % »,
// évaluée sur chaque poussée updateAssets (runPayoutGuard) + périodiquement.
// Le verrou « dernier ordre = gain » et la cible == 92 % doivent être
// présents dans le moteur de règles.
assert.match(src, /session\.config\.autoSwitchAssets !== true\) return;/);
assert.match(src, /lastOrderWinByAsset/);
assert.match(src, /AUTO_SWITCH_TRIGGER_PCT/);
assert.doesNotMatch(src, /const currentAsset = session\.market\?\.name \?\? deal\.asset/);
assert.doesNotMatch(src, /performStrictPostTradeSwitch\(io, tradedAsset/);

// 2. Multi-asset switch must replace only the triggering asset, never collapse
// the workspace back to single mode.
assert.match(src, /const isMulti = tradingMode\.mode === 'multi'/);
assert.match(src, /const uniqueNextAssets = \[\.\.\.new Set\(nextAssets\)\]/);
assert.match(src, /tradingMode\.mode = 'multi'/);
assert.match(src, /assets-selected'.*mode: 'multi'/s);

// 3. A broker snapshot may arrive immediately after changeSymbol(). A pipeline
// must therefore exist before the subscription/symbol change and as a final
// defense inside ingestHistoryFastSnapshot().
const preChange = src.slice(src.indexOf('async function switchAssetAndRefresh'), src.indexOf('function startStrategyLoop'));
const pipePos = preChange.indexOf('pipelineManager.get(nextAsset) ?? pipelineManager.getOrCreate(nextAsset)');
const subscribePos = preChange.indexOf('session.client.market.subscribe(nextAsset)');
assert.ok(pipePos >= 0 && pipePos < subscribePos, 'nextAsset pipeline must be created before subscribe/changeSymbol');
assert.match(src, /pipelineManager\.get\(asset\) \?\? pipelineManager\.getOrCreate\(asset\);/);

// 3bis. v20 — BUG « 30 min sans 1er ordre » : le switch SINGLE doit propager
// l'état Auto Trade global au nouveau contexte (plus de false codé en dur).
const singleSwitch = preChange.slice(preChange.indexOf('SINGLE-ASSET'));
assert.match(singleSwitch, /autoTradeEnabled: session\.config\.autoTradeEnabled && session\.config\.autoOpen/);
assert.doesNotMatch(singleSwitch, /autoTradeEnabled: false,/);

// 4. v20 — Re-login automatique : attend un GAIN avant de s'exécuter (pas
// d'ordre en vol, dernier ordre réglé = win), réveil immédiat au gain.
assert.match(src, /function reloginBlockReason/);
assert.match(src, /session\.lastSettledWin === false/);
assert.match(src, /reloginDeferredSince/);

// 5. Deep history may legitimately lag the live stream. Do not reject it just
// because it is old; only future timestamps are isolated.
assert.match(src, /futureSkewSec = Math\.max\(5, Math\.ceil\(size \* 0\.25\)\)/);
assert.match(src, /fetchedLast - liveNow > futureSkewSec/);
assert.match(src, /deep-history ancien conservé/);
const historyFn = src.slice(src.indexOf('async function fetchAndBroadcastHistory'), src.indexOf('/**\n * CONTIGUS', src.indexOf('async function fetchAndBroadcastHistory')));
assert.doesNotMatch(historyFn, /REJETÉ : réponse historique trop ancienne/);
assert.doesNotMatch(historyFn, /return \[\];\s*}\n    \/\/ DÉFENSE MULTI-ACTIFS/);

// 6. Asset selection must create pipelines before activating broker streams.
const selection = src.slice(src.indexOf('function applyAssetSelection'), src.indexOf('// ----- set-mode'));
const ensurePos = selection.indexOf('ensurePipelinesForSelection();');
const activatePos = selection.indexOf('activateSymbolStreams();');
assert.ok(ensurePos >= 0 && activatePos >= 0 && ensurePos < activatePos, 'selection pipeline ordering regression');
assert.match(selection, /prevAssets\.length === 0/);

// 7. Small state simulation of a multi-asset replacement.
function replaceAssetMulti(assets, focus, from, next) {
  const nextAssets = [...new Set(assets.map(a => a === from ? next : a))];
  const nextFocus = focus === from
    ? next
    : (focus && nextAssets.includes(focus) ? focus : nextAssets[0]);
  return { mode: 'multi', assets: nextAssets, focus: nextFocus };
}
assert.deepEqual(replaceAssetMulti(['EURUSD_otc','AUDCAD_otc','GBPUSD_otc'], 'EURUSD_otc', 'EURUSD_otc', 'AUDCAD_otc'), {
  mode: 'multi', assets: ['AUDCAD_otc','GBPUSD_otc'], focus: 'AUDCAD_otc'
});
assert.deepEqual(replaceAssetMulti(['EURUSD_otc','AUDCAD_otc','GBPUSD_otc'], 'GBPUSD_otc', 'EURUSD_otc', 'NZDUSD_otc'), {
  mode: 'multi', assets: ['NZDUSD_otc','AUDCAD_otc','GBPUSD_otc'], focus: 'GBPUSD_otc'
});

console.log('SMART stream hardening regression (v20): PASS');
