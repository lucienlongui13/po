#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════════════════
# build-zip-v1.4.sh — Livraison v1.4 « CALL ▲ / PUT ▼ séparés »
#   - le bouton « CALL ▲ + PUT ▼ » est remplacé par DEUX onglets ;
#   - chaque onglet affiche la LISTE COMPLÈTE des conditions (▲ et ▼) ;
#   - signaux CONTRADICTOIRES cochables (badge CONTRA + stats) ;
#   - WaveScope v5 + guides toujours inclus.
# Sortie : /home/z/my-project/download/pine_v6_engine_v1.4.zip
# ══════════════════════════════════════════════════════════════════════════
set -euo pipefail

ROOT=/home/z/my-project
STAGE="$ROOT/.stage-v1.4"
FOLDER=pine_v6_engine_v1.4
OUT="$ROOT/download/pine_v6_engine_v1.4.zip"

rm -rf "$STAGE"
mkdir -p "$STAGE/$FOLDER"

# ── Copie du projet (mêmes exclusions que v1.0→v1.3) ─────────────────────
rsync -a \
  --exclude 'node_modules/' \
  --exclude '.next/' \
  --exclude '.git/' \
  --exclude 'upload/' \
  --exclude 'download/' \
  --exclude 'tool-results/' \
  --exclude '.stage-v1.1/' \
  --exclude '.stage-v1.2/' \
  --exclude '.stage-v1.3/' \
  --exclude '.stage-v1.4/' \
  --exclude 'skills/' \
  --exclude 'bun.lock' \
  --exclude '*.tmp' \
  --exclude 'bun-error.log' \
  --exclude '.env.local' \
  --exclude 'tsconfig.tsbuildinfo' \
  --exclude 'next-env.d.ts' \
  --exclude '*.log' \
  --exclude '.logs/' \
  --exclude 'v12_*.png' \
  --exclude 'scripts/*.png' \
  --exclude 'scripts/vlm_*.json' \
  --exclude 'scripts/search*.json' \
  "$ROOT/" "$STAGE/$FOLDER/"

# ── Script WaveScope v5 + guide inclus dans le zip ─────────────────────────
cp "$ROOT/download/wavescope_ict_v5.pine" "$STAGE/$FOLDER/wavescope_ict_v5.pine"
cp "$ROOT/download/GUIDE-REGLAGES-V5.md" "$STAGE/$FOLDER/GUIDE-REGLAGES-V5.md"

# ── README des nouveautés v1.4 ────────────────────────────────────────────
cat > "$STAGE/$FOLDER/README-V1.4-CALL-PUT-SEPARES.md" <<'EOF'
# Pine v6 Engine — v1.4 « CALL ▲ / PUT ▼ séparés »

Le bouton unique « CALL ▲ + PUT ▼ » du panneau **Signal Strategy** est
remplacé par **deux onglets distincts**. Chacun affiche **la liste COMPLÈTE
des conditions** — signaux haussiers ▲ ET baissiers ▼ mélangés.

## Pourquoi ce changement ?

Pour qu'il y ait **CALL**, on peut avoir plusieurs signaux **contradictoires**
(haussiers comme baissiers) : par exemple un « LL — Lower Low » ou un grab de
liquidité baissier annonce souvent un **retournement haussier**. Même chose
pour un **PUT** avec des signaux haussiers. Chaque déclencheur peut donc
s'appuyer sur les DEUX directions.

## Ce qui change concrètement

| Avant (v1.3) | Après (v1.4) |
|---|---|
| 1 onglet « CALL ▲ + PUT ▼ » (liste mélangée, ▲ → CALL, ▼ → PUT) | 2 onglets : **CALL ▲** et **PUT ▼**, chacun avec TOUT le catalogue |

- **Onglet CALL ▲** : cocher n'importe quel signal (▲ ou ▼) → alimente
  `callSignalIds` → **CALL émis** quand les conditions sont présentes ;
- **Onglet PUT ▼** : miroir — tout signal coché alimente `putSignalIds` ;
- **Badge orange « CONTRA »** : un signal de direction OPPOSÉE coché est
  marqué contradictoire (ex. « LH — Lower High » dans l'onglet CALL) — il
  participe quand même au déclencheur (logique de retournement) ;
- **Stats par onglet** : « ▲ N · ▼ N contradictoires · N ● présentes » et
  compteur de conditions directement dans le bouton d'onglet ;
- **Déclencheurs TOUTES / AU MOINS UNE** toujours réglables séparément
  pour CALL et pour PUT ;
- **Familles dépliées** avec compteur « ⟲N » (dont contradictoires) ;
- Onglets **STOP/RJT** et **Réglages** inchangés ; le mode **AUTO TRADE**
  rebascule automatiquement sur l'onglet STRATÉGIE ;
- **Compatibilité totale** : votre configuration existante (localStorage
  `signal-strategy-config-v1`) reste valide — seules les nouvelles
  coches contradictoires s'ajoutent.

## Moteur (vérifié par tests)

`scripts/test-split-conditions.ts` (9 tests) :
- CALL émis sur signal baissier contradictoire ✓
- PUT émis sur signal haussier contradictoire ✓
- panaché ▲+▼ en mode TOUTES ✓ · AU MOINS UNE ✓
- conflit CALL+PUT simultanés toujours détecté ✓
- ids inconnus ignorés (ANY) / bloquants (ALL) ✓

## Lancer sur Termux

```bash
unzip pine_v6_engine_v1.4.zip
cd pine_v6_engine_v1.4
npm install --no-audit --no-fund
./start-dev.sh
```
EOF

# ── Création du zip ───────────────────────────────────────────────────────
rm -f "$OUT"
(cd "$STAGE" && zip -qr9 "$OUT" "$FOLDER")

# ── Vérification ──────────────────────────────────────────────────────────
echo "=== Archive créée : $OUT ==="
du -h "$OUT"
unzip -l "$OUT" | tail -1
echo "=== Fichiers clés présents ==="
unzip -l "$OUT" | grep -E 'wavescope_ict_v5|GUIDE-REGLAGES-V5|README-V1.4|signal-strategy-panel|package-lock.json$' | awk '{print $1, $4}'
echo "=== Marqueurs de fonctionnalités (vérification rapide) ==="
unzip -p "$OUT" "$FOLDER/src/components/trading/signal-strategy-panel.tsx" | grep -c 'SideConditionsTab' | xargs echo "SideConditionsTab :"
unzip -p "$OUT" "$FOLDER/src/components/trading/signal-strategy-panel.tsx" | grep -c 'CONTRA' | xargs echo "badge CONTRA :"
unzip -p "$OUT" "$FOLDER/src/components/trading/signal-strategy-panel.tsx" | grep -c "MergedConditionsTab" | xargs echo "MergedConditionsTab (0 attendu) :"
unzip -t "$OUT" > /dev/null && echo "=== Intégrité zip OK ==="

# Nettoyage du staging
rm -rf "$STAGE"
