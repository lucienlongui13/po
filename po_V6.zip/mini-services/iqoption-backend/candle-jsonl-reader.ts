/**
 * candle-jsonl-reader.ts
 * =======================
 * Lecteur incrémental temps réel de .logs/candles.jsonl (format v2).
 *
 * - Poll à intervalle court : ne lit que les NOUVEAUX octets (curseur de
 *   position), détection de réécriture du fichier (compaction/réparation).
 * - Lignes candle → bougies fusionnées par (asset, période, bucket) :
 *   le plus riche en ticks gagne, une bougie fermée reste fermée.
 * - Lignes tick → bougie EN FORMATION agrégée en temps réel.
 * - AUTO-GUÉRISON : chaque bougie est dédupliquée par horodatage de tick
 *   EXACT (t → dernier prix). Même si le fichier contenait des ticks
 *   dupliqués (format legacy non réparé), le lecteur ne propage JAMAIS
 *   de doublon.
 * - Mémoire bornée : garde au plus `maxCandles` bougies (les plus
 *   récentes), toutes périodes confondues.
 */

import * as fs from 'fs';
import * as path from 'path';

export interface JsonlCandle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  period: number;
  asset: string;
  ticks: Array<{ t: number; p: number }>;
  tickCount: number;
  closed: boolean;
  closedAt: string | null;
}

export interface ReaderStats {
  polls: number;
  linesRead: number;
  bytesRead: number;
  parseErrors: number;
  resets: number;
  candlesTracked: number;
}

const DEFAULT_MAX_CANDLES = 6000;

export class CandleJsonlReader {
  private filePath: string;
  private offset = 0;
  private lastSize = -1;
  private candles = new Map<string, JsonlCandle>();
  private forming = new Map<string, JsonlCandle>();
  private stats: ReaderStats = {
    polls: 0, linesRead: 0, bytesRead: 0, parseErrors: 0, resets: 0, candlesTracked: 0,
  };

  constructor(filePath?: string) {
    this.filePath = filePath ?? path.join(process.cwd(), '..', '..', '.logs', 'candles.jsonl');
  }

  /** Lit les nouveaux octets et met à jour l'état. */
  poll(): void {
    this.stats.polls++;
    let st: fs.Stats;
    try {
      st = fs.statSync(this.filePath);
    } catch {
      return; // fichier absent (pas encore créé)
    }

    // Fichier réécrit/tronqué (compaction, réparation) → reset du curseur.
    if (st.size < this.offset || (this.lastSize >= 0 && st.size < this.lastSize)) {
      this.offset = 0;
      this.candles.clear();
      this.forming.clear();
      this.stats.resets++;
    }
    this.lastSize = st.size;
    if (st.size <= this.offset) return;

    let chunk: string;
    try {
      const fd = fs.openSync(this.filePath, 'r');
      try {
        const len = st.size - this.offset;
        const buf = Buffer.alloc(len);
        fs.readSync(fd, buf, 0, len, this.offset);
        chunk = buf.toString('utf8');
      } finally {
        fs.closeSync(fd);
      }
    } catch {
      return;
    }

    // Ne consomme que les lignes COMPLÈTES (terminées par \n).
    const lastNewline = chunk.lastIndexOf('\n');
    if (lastNewline === -1) return;
    const complete = chunk.slice(0, lastNewline);
    this.offset += Buffer.byteLength(complete, 'utf8') + 1;
    this.stats.bytesRead += Buffer.byteLength(complete, 'utf8');

    for (const line of complete.split('\n')) {
      if (!line.trim()) continue;
      this.stats.linesRead++;
      let obj: any;
      try { obj = JSON.parse(line); } catch { this.stats.parseErrors++; continue; }
      this.ingestLine(obj);
    }

    this.enforceMemoryBound();
  }

  private ingestLine(obj: any): void {
    if (obj?.type === 'tick' || (!obj?.type && typeof obj.t === 'number' && obj.open === undefined)) {
      const t = Number(obj.t), p = Number(obj.p);
      if (!Number.isFinite(t) || !Number.isFinite(p)) return;
      const asset = String(obj.asset ?? 'UNKNOWN');
      const period = Number(obj.period ?? 30);
      const bucket = Math.floor(t / period) * period;
      const key = `${asset}|${period}|${bucket}`;

      // La bougie est peut-être déjà fermée (ligne candle déjà lue).
      if (this.candles.has(key)) return;

      let f = this.forming.get(key);
      if (!f) {
        f = {
          time: bucket, open: p, high: p, low: p, close: p,
          volume: 0, period, asset, ticks: [], tickCount: 0,
          closed: false, closedAt: null,
        };
        this.forming.set(key, f);
      }
      this.applyTick(f, t, p);
      return;
    }

    // Ligne candle (v2 ou legacy sans type).
    if (obj && typeof obj.open === 'number' && typeof obj.time === 'number') {
      const asset = String(obj.asset ?? 'UNKNOWN');
      const period = Number(obj.period ?? 30);
      const key = `${asset}|${period}|${obj.time}`;
      const rawTicks: Array<{ t: number; p: number }> = Array.isArray(obj.ticks)
        ? obj.ticks
            .filter((z: any) => z && Number.isFinite(Number(z.t)) && Number.isFinite(Number(z.p)))
            .map((z: any) => ({ t: Number(z.t), p: Number(z.p) }))
        : [];

      const prev = this.candles.get(key) ?? this.forming.get(key);
      const merged = new Map<number, number>();
      if (prev) for (const tk of prev.ticks) merged.set(tk.t, tk.p);
      for (const tk of rawTicks) merged.set(tk.t, tk.p); // dernier gagnant

      const ticks = [...merged.entries()]
        .sort((a, b) => a[0] - b[0])
        .map(([t, p]) => ({ t, p }));

      const rec: JsonlCandle = {
        time: Number(obj.time),
        open: ticks.length ? ticks[0].p : Number(obj.open),
        high: ticks.length ? Math.max(...ticks.map(x => x.p)) : Number(obj.high),
        low: ticks.length ? Math.min(...ticks.map(x => x.p)) : Number(obj.low),
        close: ticks.length ? ticks[ticks.length - 1].p : Number(obj.close),
        volume: ticks.length,
        period, asset,
        ticks, tickCount: ticks.length,
        closed: (prev?.closed ?? false) || obj.closed === true,
        closedAt: obj.closedAt ?? prev?.closedAt ?? null,
      };
      this.candles.set(key, rec);
      this.forming.delete(key);
    }
  }

  private applyTick(c: JsonlCandle, t: number, p: number): void {
    // Dédup par horodatage EXACT (garde le dernier prix) — auto-guérison.
    const idx = c.ticks.findIndex(x => x.t === t);
    if (idx >= 0) {
      c.ticks[idx] = { t, p };
    } else {
      // insertion triée
      let lo = 0, hi = c.ticks.length;
      while (lo < hi) {
        const mid = (lo + hi) >> 1;
        if (c.ticks[mid].t < t) lo = mid + 1; else hi = mid;
      }
      c.ticks.splice(lo, 0, { t, p });
    }
    c.open = c.ticks[0].p;
    c.close = c.ticks[c.ticks.length - 1].p;
    c.high = Math.max(...c.ticks.map(x => x.p));
    c.low = Math.min(...c.ticks.map(x => x.p));
    c.volume = c.ticks.length;
    c.tickCount = c.ticks.length;
  }

  private enforceMemoryBound(): void {
    const total = this.candles.size + this.forming.size;
    this.stats.candlesTracked = total;
    if (total <= DEFAULT_MAX_CANDLES) return;
    // Supprime les bougies les plus anciennes.
    const all: Array<[string, JsonlCandle]> = [
      ...this.candles.entries(), ...this.forming.entries(),
    ].sort((a, b) => a[1].time - b[1].time);
    const excess = total - DEFAULT_MAX_CANDLES;
    for (let i = 0; i < excess; i++) {
      this.candles.delete(all[i][0]);
      this.forming.delete(all[i][0]);
    }
  }

  /**
   * Bougies d'un (asset, période), triées par temps.
   * @param opts.includeForming  inclut la bougie en formation (défaut true)
   * @param opts.closedOnly      uniquement les bougies clôturées (défaut false)
   */
  getCandles(
    asset: string,
    period: number,
    opts: { includeForming?: boolean; closedOnly?: boolean; maxCandles?: number } = {},
  ): JsonlCandle[] {
    const out: JsonlCandle[] = [];
    for (const c of this.candles.values()) {
      if (c.asset === asset && c.period === period) out.push(c);
    }
    if (opts.includeForming !== false && !opts.closedOnly) {
      for (const c of this.forming.values()) {
        if (c.asset === asset && c.period === period) out.push(c);
      }
    }
    out.sort((a, b) => a.time - b.time);
    if (opts.closedOnly) {
      const closed = out.filter(c => c.closed);
      return opts.maxCandles ? closed.slice(-opts.maxCandles) : closed;
    }
    return opts.maxCandles ? out.slice(-opts.maxCandles) : out;
  }

  /** Dernière bougie clôturée (ou null). */
  getLastClosedCandle(asset: string, period: number): JsonlCandle | null {
    const closed = this.getCandles(asset, period, { closedOnly: true });
    return closed.length ? closed[closed.length - 1] : null;
  }

  getStats(): Readonly<ReaderStats> {
    return { ...this.stats, candlesTracked: this.candles.size + this.forming.size };
  }

  reset(): void {
    this.offset = 0;
    this.lastSize = -1;
    this.candles.clear();
    this.forming.clear();
    this.stats = { polls: 0, linesRead: 0, bytesRead: 0, parseErrors: 0, resets: 0, candlesTracked: 0 };
  }
}
