/**
 * @file constants.ts
 * @description Constantes globales du SDK : URLs, timeouts, valeurs par défaut.
 */

import type { ServerRegion } from './types';

/** URLs de base.
 *
 * Pour Socket.IO v4, on passe l'URL de base (https://...) au client et on
 * spécifie le `path` dans les options. `socket.io-client` gère lui-même la
 * conversion en wss:// et l'ajout des query params `EIO=4&transport=websocket`.
 */
export const URLS = {
  /** API mobile (login). Override test/mock : PO_API_BASE_URL. */
  MOBILE_API: process.env.PO_API_BASE_URL || 'https://pomob-api.com',
  /** Site web Pocket Option (cabinet). Override test/mock : PO_WEB_BASE_URL. */
  WEB: process.env.PO_WEB_BASE_URL || 'https://m.pocketoption.com',
  /** WebSocket de trading en mode DÉMO (URL de base, path = /socket.io/). */
  WS_DEMO: 'https://demo-api-eu.po.market',
  /** WebSockets de trading en mode RÉEL (multi-régions, URL de base). */
  WS_REAL: {
    eu: 'https://api-eu.po.market',
    spb: 'https://api-spb.po.market',
    msk: 'https://api-msk.po.market',
    'us-north': 'https://api-us-north.po.market',
    'us-south': 'https://api-us-south.po.market',
  } as Record<ServerRegion, string>,
  /** WebSocket FX / MT5 (Forex & CFD). */
  WS_FX: 'https://fx.po.market',
  /** WebSocket des événements marketing. */
  WS_EVENTS: 'https://events-po.com',
  /** WebSocket du chat cabinet. */
  WS_CHAT: 'https://chat-po.site',
  /** Path Socket.IO par défaut. */
  SIO_PATH: '/socket.io/',
} as const;

/**
 * Serveurs de trading réels (multi-régions).
 * Le projet Python les essaie séquentiellement jusqu'à trouver un qui répond.
 *
 * ORDRE v4 (preuve carnet.har) : api-spb EN PREMIER. La capture réelle montre
 * que le socket principal du navigateur était wss://api-spb.po.market et que
 * CE serveur pousse updateOpenedSocialDeals / updateClosedSocialDeals (594 /
 * 515 frames) en plus d'updateStream/updateAssets. Aucune preuve que api-msk
 * porte le flux social — l'ancien ordre (msk d'abord) connectait le bot sur un
 * serveur où le flux social restait vide alors que tout le reste
 * fonctionnait. On garde ensuite l'ordre géographique classique.
 */
export const MAIN_SERVERS = [
  'wss://api-spb.po.market',
  'wss://api-msk.po.market',
  'wss://api-eu.po.market',
  'wss://api-us-south.po.market',
  'wss://api-us-north.po.market',
] as const;

/** Serveurs de trading démo (un seul serveur eu).
 * Override test/mock : PO_DEMO_WS_URL redirige le transport vers un faux
 * broker local (tests E2E sans identifiants réels).
 */
export const DEMO_SERVERS: readonly string[] = [
  process.env.PO_DEMO_WS_URL || 'wss://demo-api-eu.po.market',
];

/** Endpoint de login mobile. */
export const LOGIN_PATH = '/api/webview/login';

/** Paramètres de Engine.IO / Socket.IO v4. */
export const SIO_OPTIONS = {
  /** Path Socket.IO (endpoint HTTP sous-jacent). */
  path: '/socket.io/',
  /** Forcer le transport WebSocket (pas de polling HTTP). */
  transports: ['websocket'],
  /** Engine.IO version. */
  EIO: 4,
  /** Ne pas tenter de reconnexion automatique de socket.io-client
   *  (on gère notre propre logique pour mieux contrôler la latence). */
  autoConnect: false,
  reconnection: false,
  /** Forcer le namespace par défaut "/". */
  forceNew: true,
  /** Timeout de connexion initial. */
  timeout: 10000,
} as const;

/** Timeouts et intervalles par défaut (en millisecondes). */
export const TIMINGS = {
  /** Délai avant reconnexion (backoff de base). */
  RECONNECT_BASE_DELAY: 1000,
  /** Délai max de reconnexion (backoff exponentiel plafonné). */
  RECONNECT_MAX_DELAY: 30000,
  /** Intervalle entre les pings Engine.IO (le serveur envoie 25s). */
  ENGINEIO_PING_INTERVAL: 25000,
  /** Timeout d'un ping Engine.IO (au-delà, on considère la connexion morte). */
  ENGINEIO_PING_TIMEOUT: 20000,
  /** Intervalle de l'événement `ps` (heartbeat custom Pocket Option, ~5s). */
  PS_INTERVAL: 5000,
  /** Timeout d'authentification. */
  AUTH_TIMEOUT: 15000,
  /** Timeout d'ouverture d'ordre. */
  ORDER_TIMEOUT: 20000,
  /** Timeout de chargement d'historique. */
  HISTORY_TIMEOUT: 30000,
  /** Délai max pour ack d'un event. */
  ACK_TIMEOUT: 8000,
} as const;

/** Valeurs par défaut. */
export const DEFAULTS = {
  PLATFORM: 14 as const,
  LANG: 'en',
  IS_FAST_HISTORY: true,
  IS_OPTIMIZED: true,
  MAX_HISTORY_BATCH: 9000,
  FULL_HISTORY_TARGET: 10000,
  LATENCY_SAMPLES: 50,
  /**
   * User-Agent Android WebView avec suffixe `, webview2_android_428`.
   * Le suffixe est important : le serveur Pocket Option l'utilise pour
   * identifier le client comme une webview Android légitime.
   */
  USER_AGENT:
    'Mozilla/5.0 (Linux; Android 13; SM-T870 Build/TP1A.220624.014; wv) ' +
    'AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 ' +
    'Chrome/150.0.7871.181 Safari/537.36, webview2_android_428',
  /**
   * DemoSessionId par défaut (PHPSESSID court partagé par les utilisateurs démo).
   * Vu dans le HAR capturé. Override possible via `client.setDemoSessionId(...)`.
   */
  DEFAULT_DEMO_SESSION_ID: '769eh8u56arbkqtpsf9t0dnh67',
} as const;

/** Erreurs connues. */
export const ERROR_CODES = {
  LOGIN_FAILED: 'LOGIN_FAILED',
  NETWORK_ERROR: 'NETWORK_ERROR',
  AUTH_TIMEOUT: 'AUTH_TIMEOUT',
  AUTH_FAILED: 'AUTH_FAILED',
  ORDER_REJECTED: 'ORDER_REJECTED',
  ORDER_TIMEOUT: 'ORDER_TIMEOUT',
  HISTORY_EMPTY: 'HISTORY_EMPTY',
  NOT_AUTHENTICATED: 'NOT_AUTHENTICATED',
  ASSET_NOT_FOUND: 'ASSET_NOT_FOUND',
  INVALID_PARAMS: 'INVALID_PARAMS',
  CONNECTION_CLOSED: 'CONNECTION_CLOSED',
} as const;

// ============================================================================
//  EVENT NAMES (Socket.IO)
// ============================================================================

/** Noms des événements WebSocket émis par le client (SEND : client -> serveur). */
export const CLIENT_EVENTS = {
  AUTH: 'auth',
  SUBFOR: 'subfor',
  UNSUBFOR: 'unsubfor',
  SUBSCRIBE_SYMBOL: 'subscribeSymbol',
  CHANGE_SYMBOL: 'changeSymbol',
  LOAD_HISTORY_PERIOD: 'loadHistoryPeriod',
  OPEN_ORDER: 'openOrder',
  OPEN_EXPRESS: 'openExpress',
  COPY_SIGNAL_ORDER: 'copySignalOrder',
  UPDATE_CLOSED_EXPRESSES: 'updateClosedExpresses',
  UPDATE_CLOSED_DEALS: 'updateClosedDeals',
  SAVE_CHARTS: 'saveCharts',
  PS: 'ps',
  SIGNALS_SUBSCRIBE: 'signals/subscribe',
  SIGNALS_UNSUBSCRIBE: 'signals/unsubscribe',
  SIGNALS_STATS: 'signals/stats',
  INDICATOR_LOAD: 'indicator/load',
  FAVORITE_LOAD: 'favorite/load',
  FAVORITE_CHANGE: 'favorite/change',
  PRICE_ALERT_LOAD: 'price-alert/load',
  DEALS_AI: 'deals/ai',
  AI_STRATEGY_GET_STATE: 'ai-strategy-multi/get-state',
  // FX / MT5
  QUOTE_SUBSCRIBE: 'quote_subscribe',
  LOAD_HISTORY_LAST: 'load_history_last',
} as const;

/** Noms des événements WebSocket reçus du serveur (RECV : serveur -> client). */
export const SERVER_EVENTS = {
  SUCCESS_AUTH: 'successauth',
  FAIL_AUTH: 'failauth',
  UPDATE_ASSETS: 'updateAssets',
  UPDATE_STREAM: 'updateStream',
  CHAFOR: 'chafor',
  UPDATE_HISTORY_NEW_FAST: 'updateHistoryNewFast',
  LOAD_HISTORY_PERIOD_FAST: 'loadHistoryPeriodFast',
  UPDATE_OPENED_DEALS: 'updateOpenedDeals',
  UPDATE_CLOSED_DEALS: 'updateClosedDeals',
  UPDATE_CHARTS: 'updateCharts',
  SUCCESS_OPEN_ORDER: 'successopenOrder',
  FAIL_OPEN_ORDER: 'failopenOrder',
  SUCCESS_CLOSE_ORDER: 'successcloseOrder',
  SUCCESS_UPDATE_BALANCE: 'successupdateBalance',
  SUCCESS_UPDATE_PENDING: 'successupdatePending',
  SUCCESS_UPDATE_OPENED_EXPRESSES: 'successupdateOpenedExpresses',
  SUCCESS_INDICATOR_LOAD: 'successindicator/load',
  SUCCESS_FAVORITE_LOAD: 'successfavorite/load',
  SUCCESS_FAVORITE_CHANGE: 'successfavorite/change',
  SUCCESS_PRICE_ALERT_LOAD: 'successprice-alert/load',
  SUCCESS_SIGNALS_STATS: 'successsignals/stats',
  SIGNALS_LOAD: 'signals/load',
  SIGNALS_UPDATE: 'signals/update',
  SUCCESS_AI_STRATEGY_GET_STATE: 'successai-strategy-multi/get-state',
  // FX / MT5
  AUTH_SUCCESS: 'auth_success',
  ACCOUNT: 'account',
  SETTINGS: 'settings',
  DEALS: 'deals',
  ORDERS: 'orders',
  POSITIONS: 'positions',
  LOAD_CHARTS: 'loadCharts',
  UPDATE_QUOTES: 'update_quotes',
  UPDATE_TIME: 'updateTime',
  LOAD_HISTORY_LAST: 'load_history_last',
  SUCCESS_INDICATOR_LOAD_FX: 'successindicator/load',
} as const;

/** Type d'un nom d'événement client. */
export type ClientEventName = (typeof CLIENT_EVENTS)[keyof typeof CLIENT_EVENTS];

/** Type d'un nom d'événement serveur. */
export type ServerEventName = (typeof SERVER_EVENTS)[keyof typeof SERVER_EVENTS];
