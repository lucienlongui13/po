/**
 * @file session.ts
 * @description Utilitaires de session pour Pocket Option.
 *
 * Historiquement, ce module construisait une session PHP CodeIgniter sérialisée
 * et la signait avec un hash MD5. Cette approche ne fonctionnait PAS en production
 * car le serveur attend le `ci_session` brut (récupéré depuis le Set-Cookie de
 * `/en/cabinet`), URL-décodé, et non une construction manuelle.
 *
 * Désormais, ce module ne contient plus que les helpers génériques :
 *  - generateRequestId : entier aléatoire 32 bits pour les ordres
 *  - buildSignalId : ID au format Pocket Option pour les signaux
 *
 * La construction de la session est gérée dans `src/auth.ts` (fonction
 * `authenticate` + `buildSessionData`).
 */

/**
 * Génère un requestId aléatoire pour les ordres.
 * Pocket Option utilise un entier 32 bits (souvent un timestamp tronqué,
 * mais un random fonctionne aussi).
 */
export function generateRequestId(): number {
  // Comme le projet Python : random.randint(10_000_000, 99_999_999)
  return Math.floor(Math.random() * 90_000_000) + 10_000_000;
}

/**
 * Génère un signalId au format Pocket Option : "<ts>-<asset>-<timeframe>".
 */
export function buildSignalId(asset: string, timeframe: number, ts?: number): string {
  return `${ts ?? Math.floor(Date.now() / 1000)}-${asset}-${timeframe}`;
}
