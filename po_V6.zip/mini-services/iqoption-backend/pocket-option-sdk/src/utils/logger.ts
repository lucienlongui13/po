/**
 * @file logger.ts
 * @description Logger configurable avec niveaux (debug/info/warn/error).
 *              Désactivé par défaut ; activé via options.debug = true.
 */

export type LogLevel = 'debug' | 'info' | 'warn' | 'error' | 'silent';

const LEVEL_ORDER: Record<LogLevel, number> = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
  silent: 100,
};

export class Logger {
  private level: number;
  private prefix: string;

  constructor(prefix = 'PO', level: LogLevel = 'silent') {
    this.prefix = prefix;
    this.level = LEVEL_ORDER[level];
  }

  setLevel(level: LogLevel): void {
    this.level = LEVEL_ORDER[level];
  }

  debug(...args: unknown[]): void {
    if (this.level <= LEVEL_ORDER.debug) {
      console.debug(`[${this.prefix} DEBUG]`, ...args);
    }
  }

  info(...args: unknown[]): void {
    if (this.level <= LEVEL_ORDER.info) {
      console.log(`[${this.prefix} INFO ]`, ...args);
    }
  }

  warn(...args: unknown[]): void {
    if (this.level <= LEVEL_ORDER.warn) {
      console.warn(`[${this.prefix} WARN ]`, ...args);
    }
  }

  error(...args: unknown[]): void {
    if (this.level <= LEVEL_ORDER.error) {
      console.error(`[${this.prefix} ERROR]`, ...args);
    }
  }
}
