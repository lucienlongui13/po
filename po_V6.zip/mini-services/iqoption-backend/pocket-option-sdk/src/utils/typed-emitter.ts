/**
 * @file typed-emitter.ts
 * @description EventEmitter typé minimal (sans dépendance externe).
 *              Utilisé par le client Pocket Option pour exposer une API
 *              d'abonnement aux événements fortement typés.
 *
 * La contrainte `EventMap` est intentionnellement permissive : on accepte
 * toute interface dont les membres sont des fonctions (sans signature
 * d'index explicite), car TypeScript ne sait pas inférer qu'une interface
 * satisfait `Record<string, ...>` même si tous ses membres sont des fonctions.
 */

export type Listener<F extends (...args: any[]) => any> = F;

/**
 * Contrainte souple pour les maps d'événements.
 * On accepte n'importe quelle interface ; la cohérence est garantie par
 * l'usage (chaque handler doit être une fonction).
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type EventMap = Record<string, (...args: any[]) => any>;

export class TypedEmitter<E> {
  private listeners: { [K in keyof E]?: Set<any> } = {} as any;

  on<K extends keyof E>(event: K, listener: E[K] extends (...args: any[]) => any ? E[K] : never): this {
    if (!this.listeners[event]) {
      this.listeners[event] = new Set<any>();
    }
    this.listeners[event]!.add(listener);
    return this;
  }

  once<K extends keyof E>(event: K, listener: E[K] extends (...args: any[]) => any ? E[K] : never): this {
    const wrap = ((...args: any[]) => {
      this.off(event, wrap);
      (listener as any)(...args);
    }) as any;
    return this.on(event, wrap);
  }

  off<K extends keyof E>(event: K, listener: E[K] extends (...args: any[]) => any ? E[K] : never): this {
    const set = this.listeners[event];
    if (set) {
      set.delete(listener);
      if (set.size === 0) {
        delete this.listeners[event];
      }
    }
    return this;
  }

  removeAllListeners<K extends keyof E>(event?: K): this {
    if (event === undefined) {
      this.listeners = {} as any;
    } else {
      delete this.listeners[event];
    }
    return this;
  }

  /**
   * Émet un événement vers les listeners LOCAUX (sous-classes et handlers SDK).
   *
   * Cette méthode est `public` (et non `protected`) parce que les sous-classes
   * comme `SocketIoTransport` ont besoin de propager des événements internes
   * (`connect`, `disconnect`, `state`, `latency`, ...) aux listeners du SDK,
   * tout en exposant une méthode séparée `send()` pour envoyer des messages
   * au serveur distant. Sans cette séparation, `socket.emit('connect')` du
   * socket.io-client réservait le nom `connect` et plantait.
   */
  emit<K extends keyof E>(event: K, ...args: any[]): boolean {
    const set = this.listeners[event];
    if (!set || set.size === 0) return false;
    const arr = Array.from(set);
    for (const fn of arr) {
      try {
        (fn as any)(...args);
      } catch (err) {
        // On log mais on continue à propager aux autres listeners
        // (ne pas casser la chaîne à cause d'un listener fautif).
        // eslint-disable-next-line no-console
        console.error(`[TypedEmitter] listener for "${String(event)}" threw:`, err);
      }
    }
    return true;
  }

  listenerCount<K extends keyof E>(event: K): number {
    return this.listeners[event]?.size ?? 0;
  }
}
