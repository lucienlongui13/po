/**
 * @file raw-ws.ts
 * @description Client WebSocket RFC 6455 minimal (sans dépendance externe).
 *
 * Reproduit fidèlement le `ws.py` du projet Python de référence : handshake
 * manuel, frames masked, support des opcodes text/binary/ping/pong/close,
 * fragmentation, et option `Origin` (requis par Pocket Option pour bypass
 * l'anti-bot qui détecte `socket.io-client`).
 *
 * Utilise uniquement le module `ws` (Node.js) ou le WebSocket natif (browser).
 * En Node.js 22+, le WebSocket natif est disponible ; pour les versions
 * antérieures on retombe sur le package `ws`.
 */

import { Buffer } from 'buffer';
import { randomBytes, createHash } from 'crypto';

export const OP_CONT = 0x0;
export const OP_TEXT = 0x1;
export const OP_BINARY = 0x2;
export const OP_CLOSE = 0x8;
export const OP_PING = 0x9;
export const OP_PONG = 0xa;

const WS_GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';

export class WebSocketError extends Error {}
export class WebSocketClosed extends WebSocketError {}

export interface RawWebSocketOptions {
  /** URL complète (wss://host/path?query). */
  url: string;
  /** Header Origin (requis par Pocket Option). */
  origin?: string;
  /** User-Agent. */
  userAgent?: string;
  /** Timeout de connexion et de réception (ms). */
  timeout?: number;
  /** Headers additionnels. */
  extraHeaders?: Record<string, string>;
}

/**
 * Client WebSocket RFC 6455 minimal pour Node.js, sans dépendance externe.
 *
 * Implémente :
 *  - Handshake HTTP Upgrade avec Sec-WebSocket-Key/Accept
 *  - Frames masked (client -> serveur)
 *  - Frames unmasked (serveur -> client)
 *  - Fragmentation (messages multi-frames)
 *  - Ping/Pong/Close transparents
 *  - Mode texte ET binaire (requis pour Socket.IO Binary Event)
 */
export class RawWebSocket {
  private url: string;
  private origin?: string;
  private userAgent: string;
  private timeout: number;
  private extraHeaders: Record<string, string>;
  private sock: import('net').Socket | import('tls').TLSSocket | null = null;
  private secure: boolean;
  private host: string;
  private port: number;
  private path: string;
  private recvBuffer: Buffer = Buffer.alloc(0);

  constructor(opts: RawWebSocketOptions) {
    this.url = opts.url;
    this.origin = opts.origin;
    this.userAgent = opts.userAgent ?? 'po-client/1.0';
    this.timeout = opts.timeout ?? 30000;
    this.extraHeaders = opts.extraHeaders ?? {};

    // Parse URL
    if (!this.url.startsWith('ws://') && !this.url.startsWith('wss://')) {
      throw new WebSocketError(`unsupported url scheme: ${this.url.slice(0, 8)}`);
    }
    this.secure = this.url.startsWith('wss://');
    const rest = this.url.slice(this.secure ? 6 : 5);
    const [hostport, ...pathParts] = rest.split('/');
    const path = pathParts.length > 0 ? '/' + pathParts.join('/') : '/';
    if (hostport.includes(':')) {
      const idx = hostport.lastIndexOf(':');
      this.host = hostport.slice(0, idx);
      this.port = parseInt(hostport.slice(idx + 1), 10);
    } else {
      this.host = hostport;
      this.port = this.secure ? 443 : 80;
    }
    this.path = path;
  }

  /** Établit la connexion TCP + handshake WebSocket. */
  async connect(): Promise<void> {
    const net = await import('net');
    const tls = await import('tls');

    return new Promise<void>((resolve, reject) => {
      const raw = net.createConnection({ host: this.host, port: this.port });
      raw.setTimeout(this.timeout);

      let tlsSock: import('tls').TLSSocket;
      const onError = (err: Error) => {
        raw.destroy();
        reject(new WebSocketError(`connection failed: ${err.message}`));
      };
      raw.once('error', onError);

      raw.once('connect', () => {
        if (!this.secure) {
          this.sock = raw;
          this.startHandshake(raw, resolve, reject);
          return;
        }
        // Wrap en TLS
        tlsSock = tls.connect({
          socket: raw,
          servername: this.host,
          // Accepter les certificats auto-signés si nécessaire (jamais en prod)
          rejectUnauthorized: true,
        });
        tlsSock.once('secureConnect', () => {
          this.sock = tlsSock;
          this.startHandshake(tlsSock, resolve, reject);
        });
        tlsSock.once('error', onError);
      });
    });
  }

  private startHandshake(
    sock: import('net').Socket | import('tls').TLSSocket,
    resolve: () => void,
    reject: (err: Error) => void,
  ): void {
    const key = randomBytes(16).toString('base64');
    const lines = [
      `GET ${this.path} HTTP/1.1`,
      `Host: ${this.host}:${this.port}`,
      'Upgrade: websocket',
      'Connection: Upgrade',
      `Sec-WebSocket-Key: ${key}`,
      'Sec-WebSocket-Version: 13',
      `User-Agent: ${this.userAgent}`,
    ];
    if (this.origin) {
      lines.push(`Origin: ${this.origin}`);
    }
    for (const [k, v] of Object.entries(this.extraHeaders)) {
      lines.push(`${k}: ${v}`);
    }
    const request = lines.join('\r\n') + '\r\n\r\n';
    sock.write(request);

    // Parse la réponse HTTP jusqu'au premier \r\n\r\n
    let buf = Buffer.alloc(0);
    const onData = (chunk: Buffer) => {
      buf = Buffer.concat([buf, chunk]);
      const idx = buf.indexOf('\r\n\r\n');
      if (idx === -1) return;
      sock.removeListener('data', onData);
      const head = buf.slice(0, idx).toString('utf-8');
      const remainder = buf.slice(idx + 4);
      this.recvBuffer = remainder;

      const firstLine = head.split('\r\n')[0];
      if (!firstLine.includes(' 101 ')) {
        reject(new WebSocketError(`handshake failed: ${firstLine}`));
        return;
      }
      // Vérifie Sec-WebSocket-Accept
      const expected = createHash('sha1').update(key + WS_GUID).digest('base64');
      const acceptMatch = head.match(/sec-websocket-accept:\s*(.+)/i);
      if (!acceptMatch || acceptMatch[1].trim() !== expected) {
        reject(new WebSocketError('bad Sec-WebSocket-Accept'));
        return;
      }
      sock.setTimeout(0); // reset timeout pour la suite
      resolve();
    };
    sock.on('data', onData);
    sock.once('error', (err: Error) => {
      sock.removeListener('data', onData);
      reject(new WebSocketError(`socket error during handshake: ${err.message}`));
    });
  }

  /** Envoie une frame texte. */
  sendText(text: string): void {
    this.sendFrame(OP_TEXT, Buffer.from(text, 'utf-8'));
  }

  /** Envoie une frame binaire. */
  sendBinary(data: Buffer): void {
    this.sendFrame(OP_BINARY, data);
  }

  /** Envoie une frame brute (masked, FIN=1). */
  private sendFrame(opcode: number, payload: Buffer): void {
    if (!this.sock) throw new WebSocketError('socket not connected');
    const header: number[] = [];
    header.push(0x80 | opcode); // FIN=1 + opcode
    const len = payload.length;
    const maskBit = 0x80;
    if (len < 126) {
      header.push(maskBit | len);
    } else if (len < 65536) {
      header.push(maskBit | 126);
      header.push((len >> 8) & 0xff, len & 0xff);
    } else {
      header.push(maskBit | 127);
      // 64-bit length (on suppose < 2^32)
      const high = Math.floor(len / 2 ** 32);
      const low = len >>> 0;
      header.push(
        (high >>> 24) & 0xff,
        (high >>> 16) & 0xff,
        (high >>> 8) & 0xff,
        high & 0xff,
        (low >>> 24) & 0xff,
        (low >>> 16) & 0xff,
        (low >>> 8) & 0xff,
        low & 0xff,
      );
    }
    // Mask (client -> serveur : obligatoire)
    const mask = randomBytes(4);
    const masked = Buffer.alloc(len);
    for (let i = 0; i < len; i++) {
      masked[i] = payload[i] ^ mask[i % 4];
    }
    this.sock.write(Buffer.from(header));
    this.sock.write(mask);
    this.sock.write(masked);
  }

  /**
   * Attend le prochain message complet et retourne [opcode, payload].
   * Gère ping (répond pong), pong (ignore), close (throw WebSocketClosed),
   * et la fragmentation (frames continuation).
   */
  async recvMessage(): Promise<{ opcode: number; payload: Buffer }> {
    if (!this.sock) throw new WebSocketError('socket not connected');
    while (true) {
      // Attend d'avoir au moins 2 octets (header)
      await this.waitForBytes(2);
      const b1 = this.recvBuffer[0];
      const b2 = this.recvBuffer[1];
      const fin = Boolean(b1 & 0x80);
      const opcode = b1 & 0x0f;
      const masked = Boolean(b2 & 0x80);
      let length = b2 & 0x7f;
      let headerLen = 2;

      if (length === 126) {
        await this.waitForBytes(4);
        length = this.recvBuffer.readUInt16BE(2);
        headerLen = 4;
      } else if (length === 127) {
        await this.waitForBytes(10);
        // Lecture 64-bit (on suppose high=0)
        const high = this.recvBuffer.readUInt32BE(2);
        const low = this.recvBuffer.readUInt32BE(6);
        if (high > 0) throw new WebSocketError('frame too large (>2^32 bytes)');
        length = low;
        headerLen = 10;
      }

      let maskOffset = headerLen;
      if (masked) {
        await this.waitForBytes(headerLen + 4);
        maskOffset = headerLen;
        headerLen += 4;
      }
      await this.waitForBytes(headerLen + length);
      const mask = masked ? this.recvBuffer.slice(maskOffset, maskOffset + 4) : null;
      let payload = this.recvBuffer.slice(headerLen, headerLen + length);
      if (mask) {
        const unmasked = Buffer.alloc(length);
        for (let i = 0; i < length; i++) {
          unmasked[i] = payload[i] ^ mask[i % 4];
        }
        payload = unmasked;
      }
      // Consomme les octets lus
      this.recvBuffer = this.recvBuffer.slice(headerLen + length);

      if (opcode === OP_PING) {
        this.sendFrame(OP_PONG, payload);
        continue;
      }
      if (opcode === OP_PONG) {
        continue;
      }
      if (opcode === OP_CLOSE) {
        throw new WebSocketClosed('close frame received');
      }
      if (opcode === OP_TEXT || opcode === OP_BINARY) {
        // Gère fragmentation
        if (fin) {
          return { opcode, payload };
        }
        const chunks = [payload];
        while (true) {
          await this.waitForBytes(2);
          const c1 = this.recvBuffer[0];
          const c2 = this.recvBuffer[1];
          const cFin = Boolean(c1 & 0x80);
          const cOp = c1 & 0x0f;
          const cMasked = Boolean(c2 & 0x80);
          let cLen = c2 & 0x7f;
          let cHl = 2;
          if (cLen === 126) {
            await this.waitForBytes(4);
            cLen = this.recvBuffer.readUInt16BE(2);
            cHl = 4;
          } else if (cLen === 127) {
            await this.waitForBytes(10);
            cLen = this.recvBuffer.readUInt32BE(6);
            cHl = 10;
          }
          let cMaskOffset = cHl;
          if (cMasked) {
            await this.waitForBytes(cHl + 4);
            cMaskOffset = cHl;
            cHl += 4;
          }
          await this.waitForBytes(cHl + cLen);
          const cMask = cMasked ? this.recvBuffer.slice(cMaskOffset, cMaskOffset + 4) : null;
          let cPayload = this.recvBuffer.slice(cHl, cHl + cLen);
          if (cMask) {
            const u = Buffer.alloc(cLen);
            for (let i = 0; i < cLen; i++) u[i] = cPayload[i] ^ cMask[i % 4];
            cPayload = u;
          }
          this.recvBuffer = this.recvBuffer.slice(cHl + cLen);
          chunks.push(cPayload);
          if (cFin && cOp === OP_CONT) {
            return { opcode, payload: Buffer.concat(chunks) };
          }
        }
      }
    }
  }

  /** Attend que le buffer contienne au moins n octets. */
  private waitForBytes(n: number): Promise<void> {
    if (this.recvBuffer.length >= n) return Promise.resolve();
    return new Promise<void>((resolve, reject) => {
      if (!this.sock) {
        reject(new WebSocketError('socket not connected'));
        return;
      }
      const onData = (chunk: Buffer) => {
        this.recvBuffer = Buffer.concat([this.recvBuffer, chunk]);
        if (this.recvBuffer.length >= n) {
          this.sock?.removeListener('data', onData);
          this.sock?.removeListener('error', onError);
          this.sock?.removeListener('close', onClose);
          resolve();
        }
      };
      const onError = (err: Error) => {
        this.sock?.removeListener('data', onData);
        this.sock?.removeListener('error', onError);
        this.sock?.removeListener('close', onClose);
        reject(new WebSocketError(`socket error: ${err.message}`));
      };
      const onClose = () => {
        this.sock?.removeListener('data', onData);
        this.sock?.removeListener('error', onError);
        this.sock?.removeListener('close', onClose);
        reject(new WebSocketClosed('connection closed by peer'));
      };
      this.sock.on('data', onData);
      this.sock.once('error', onError);
      this.sock.once('close', onClose);
    });
  }

  /** Ferme la connexion proprement. */
  close(): void {
    if (!this.sock) return;
    try {
      // Envoie une frame CLOSE (1000 Normal Closure)
      const closePayload = Buffer.alloc(2);
      closePayload.writeUInt16BE(1000, 0);
      this.sendFrame(OP_CLOSE, closePayload);
    } catch {
      // ignore
    }
    try {
      this.sock.destroy();
    } catch {
      // ignore
    }
    this.sock = null;
  }

  /** True si la socket est encore ouverte. */
  get isOpen(): boolean {
    return this.sock !== null && !this.sock.destroyed;
  }
}
