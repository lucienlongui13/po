/**
 * @file raw-socketio-transport.ts
 * @description Transport Socket.IO v4 / Engine.IO v4 basé sur RawWebSocket.
 *
 * Pourquoi ne pas utiliser `socket.io-client` ?
 *  - Le serveur Pocket Option détecte `socket.io-client` (via User-Agent et
 *    headers spécifiques) et ferme la connexion immédiatement après le
 *    handshake Engine.IO, avant même l'envoi de l'event `auth`.
 *  - Le projet Python de référence (po_client/pocket.py + ws.py) utilise un
 *    WebSocket RFC 6455 brut et envoie manuellement les frames Engine.IO
 *    (texte `0{...}`, `40`, `42[event,...]`, `451-[event,...]`, `2` ping,
 *    `3` pong). Ça bypass la détection.
 *
 * Ce transport reproduit fidèlement le flux Python :
 *  1. TCP/TLS connect + WebSocket handshake avec Origin: https://m.pocketoption.com
 *  2. Reçoit `0{sid, pingInterval, pingTimeout}` (Engine.IO OPEN)
 *  3. Envoie `40` (Socket.IO CONNECT namespace /)
 *  4. Reçoit `40{sid}` (Socket.IO CONNECT_ACK)
 *  5. Envoie `42["auth",{session,isDemo,uid,platform,isFastHistory,isOptimized}]`
 *  6. Reçoit `451-["successauth",{_placeholder:true,num:0}]` + frame binaire (Binary Event)
 *  7. Répond aux pings Engine.IO (`2` -> `3`)
 *  8. Envoie `ps` (heartbeat custom PO) toutes les 5s
 *  9. Envoie `42["changeSymbol",{asset,period}]`, `42["openOrder",...]`, etc.
 *
 * Latence : pas de parsing overhead, pas de lib tierce, frames écrites directement.
 */

import { RawWebSocket, OP_TEXT, OP_BINARY, WebSocketError, WebSocketClosed } from './raw-ws';
import { Logger } from '../utils/logger';
import { TypedEmitter } from '../utils/typed-emitter';
import { LatencyTracker } from './latency-tracker';
import { URLS, TIMINGS, DEFAULTS } from '../constants';
import type { TransportEvents } from './itransport';
import type { ConnectionState, LatencySample } from '../types';

export interface RawSocketIoTransportOptions {
  /**
   * URL unique (rétro-compat) — si fournie, devient le seul serveur de la liste.
   * Préférez `urls` pour activer le failover multi-serveurs.
   */
  url?: string;
  /**
   * Liste d'URLs à essayer séquentiellement (failover).
   *
   * En mode RÉEL, le projet Python essaie chaque serveur de MAIN_SERVERS
   * (api-msk, api-spb, api-eu, api-us-south, api-us-north) jusqu'à trouver
   * un qui répond. On reproduit ce comportement ici.
   *
   * Si `urls` est fourni, il prend la priorité sur `url`.
   */
  urls?: string[];
  /** Données d'authentification à envoyer dans l'event `auth`. */
  authPayload: () => Record<string, unknown> | Record<string, unknown>;
  /** Logger. */
  logger?: Logger;
  /** Délai de base pour la reconnexion (ms). */
  reconnectDelay?: number;
  /** Nombre max de tentatives (0 = infini). */
  maxReconnectAttempts?: number;
  /** User-Agent (default: DEFAULTS.USER_AGENT). */
  userAgent?: string;
  /** Origin (default: https://m.pocketoption.com). */
  origin?: string;
  /** Active l'envoi périodique de l'event `ps` (heartbeat custom PO). */
  enablePsHeartbeat?: boolean;
  /** Hook exécuté juste avant une reconnexion automatique. Peut rafraîchir l'auth HTTP/session. */
  beforeReconnect?: () => Promise<void> | void;
  /** Timeout de connexion et de réception (ms). */
  timeout?: number;
  /**
   * Nombre de cycles de failover complets avant abandon.
   * Un cycle = essayer tous les serveurs de `urls` une fois.
   * Default: 5 (comme le Python : `connect(attempts=5)`).
   */
  connectAttempts?: number;
}

/** Pending binary event (en attente de frame(s) binaire(s) suite à un 451-). */
interface PendingBinary {
  attachments: number;
  payload: unknown[];
  got: unknown[];
}

// ------------------------------------------------------------------------
//  DUAL-LANE DISPATCH — isolation MARKET / SOCIAL (tunnels asynchrones)
// ------------------------------------------------------------------------
//  PROBLÈME (couplage C1 du diagnostic) : la recvLoop traitait TOUTES les
//  frames SÉQUENTIELLEMENT — un handler lent (snapshot social O(n), coach
//  market) retardait les frames suivantes, y compris pongs Engine.IO et
//  l'AUTRE flux. En mode RÉEL, market et social partagent LE MÊME socket.
//
//  SOLUTION : la recvLoop ne fait plus que DÉCODER + ROUTER. Chaque event
//  décodé est classé :
//    - MARKET lane  : updateStream, updateHistoryNewFast, chafor,
//                     loadHistoryPeriodFast → file dédiée + worker dédié ;
//    - SOCIAL lane  : updateOpenedSocialDeals, updateClosedSocialDeals
//                     → file dédiée + worker dédié ;
//    - CONTROL lane : successauth/failauth, updateAssets, balance, deals,
//                     order results… → traitement IMMÉDIAT dans la recvLoop
//                     (events basse fréquence, résolution de promesses et
//                     timings d'auth qui DOIVENT rester immédiats).
//
//  Chaque worker traite sa file dans l'ordre (FIFO par lane — l'ordre
//  tick→tick et opened→closed est préservé) puis YIELD (setImmediate) à
//  l'event loop : l'AUTRE lane continue d'être servie pendant qu'une
//  lane traite — le marché ne bloque plus le social, le social ne bloque
//  plus le marché (§ « aucune dépendance bloquante entre les tunnels »).
//
//  BACKPRESSURE (§13) :
//    - MARKET : cap 10 000. En dépassement, les updateStream EN ATTENTE
//      sont FUSIONNÉS (concaténation des batches — ordre et nombre de
//      ticks strictement préservés : le normaliseur sous-seconde voit la
//      MÊME séquence). Aucune clôture de bougie n'est jamais perdue
//      (chafor/loadHistoryPeriodFast/loadHistoryPeriodFast jamais droppés).
//    - SOCIAL : cap 10 000. opened/closed = événements CRITIQUES → JAMAIS
//      droppés (la file grossit avec un warning en cas de burst extrême,
//      perte silencieuse interdite).
// ------------------------------------------------------------------------

/** Events du flux MARKET (tunnel A — ticks/candles/historique). */
const MARKET_LANE_EVENTS = new Set([
  'updateStream',
  'updateHistoryNewFast',
  'chafor',
  'loadHistoryPeriodFast',
]);

/** Events du flux SOCIAL (tunnel B — ordres sociaux ouverts/clôturés). */
const SOCIAL_LANE_EVENTS = new Set([
  'updateOpenedSocialDeals',
  'updateClosedSocialDeals',
]);

interface LaneItem {
  event: string;
  args: unknown[];
}

export interface LaneStats {
  name: 'market' | 'social';
  queued: number;
  processed: number;
  overflowCoalesced: number;
  overflowGrown: number;
}

/** File bornée + worker asynchrone indépendant pour UNE lane. */
class EventLane {
  private queue: LaneItem[] = [];
  private running = false;
  processed = 0;
  overflowCoalesced = 0;
  overflowGrown = 0;

  constructor(
    readonly name: 'market' | 'social',
    private readonly cap: number,
    private readonly dispatch: (event: string, args: unknown[]) => void,
    private readonly onError: (err: unknown, event: string) => void,
  ) {}

  enqueue(event: string, args: unknown[]): void {
    if (this.queue.length >= this.cap) this.applyBackpressure();
    this.queue.push({ event, args });
    if (!this.running) void this.drain();
  }

  /**
   * Backpressure par lane (§13) :
   *  - market : fusionner les updateStream en attente (SANS perte — ordre
   *    et ticks préservés) jusqu'à repasser sous le cap ;
   *  - social : jamais de drop — croissance contrôlée (les opened/closed
   *    sont critiques, une perte silencieuse est interdite §13).
   */
  private applyBackpressure(): void {
    if (this.name !== 'market') {
      // Social : opened/closed = critique → croissance, jamais de perte.
      this.overflowGrown++;
      return;
    }
    // Fusion de TOUS les updateStream en attente en UN seul item
    // (concaténation) — opération idempotente, sans perte.
    const mergedUpdates: unknown[] = [];
    const rest: LaneItem[] = [];
    let coalescedItems = 0;
    for (const item of this.queue) {
      if (item.event === 'updateStream') {
        const batch = Array.isArray(item.args?.[0]) ? (item.args[0] as unknown[]) : [item.args?.[0]];
        mergedUpdates.push(...batch);
        coalescedItems++;
      } else {
        rest.push(item);
      }
    }
    if (coalescedItems > 1) {
      this.queue = mergedUpdates.length
        ? [...rest, { event: 'updateStream', args: [mergedUpdates] }]
        : rest;
      this.overflowCoalesced += coalescedItems - 1;
    }
    // Toujours plein (historiques volumineux) → croissance contrôlée,
    // JAMAIS de drop : une clôture de bougie perdue est interdite (§13).
    if (this.queue.length >= this.cap) {
      this.overflowGrown++;
    }
  }

  private async drain(): Promise<void> {
    this.running = true;
    try {
      while (this.queue.length > 0) {
        const item = this.queue.shift() as LaneItem;
        try {
          this.dispatch(item.event, item.args);
          this.processed++;
        } catch (err) {
          this.onError(err, item.event);
        }
        // YIELD par événement : laisse la recvLoop réseau, l'AUTRE lane et
        // les timers s'exécuter — c'est CE yield qui matérialise l'indépendance
        // des deux tunnels sur l'event loop Node unique.
        await new Promise<void>((resolve) => setImmediate(resolve));
      }
    } finally {
      this.running = false;
    }
  }

  /** Vide la file (déconnexion/destroy — les events d'une connexion morte
   *  ne doivent pas fuiter vers les handlers). */
  clear(): void {
    this.queue = [];
  }

  stats(): LaneStats {
    return {
      name: this.name,
      queued: this.queue.length,
      processed: this.processed,
      overflowCoalesced: this.overflowCoalesced,
      overflowGrown: this.overflowGrown,
    };
  }
}

export class RawSocketIoTransport extends TypedEmitter<TransportEvents> {
  /** Liste des serveurs à essayer séquentiellement (failover). */
  private urls: string[];
  /** Index du serveur actuellement actif dans `urls`. */
  private currentUrlIndex = 0;
  /** Serveur actuellement connecté (null si pas connecté). */
  private connectedServer: string | null = null;
  private authPayload: RawSocketIoTransportOptions['authPayload'];
  private logger: Logger;
  private userAgent: string;
  private origin: string;
  private timeout: number;
  private reconnectDelay: number;
  private maxReconnectAttempts: number;
  private enablePsHeartbeat: boolean;
  private beforeReconnect?: () => Promise<void> | void;
  private connectAttempts: number;

  private ws: RawWebSocket | null = null;
  private state: ConnectionState = 'disconnected';
  private reconnectAttempts = 0;
  private reconnectTimer: NodeJS.Timeout | null = null;
  private pingTimer: NodeJS.Timeout | null = null;
  private psTimer: NodeJS.Timeout | null = null;
  private latency: LatencyTracker;
  private manuallyClosed = false;
  private recvLoopRunning = false;
  private pendingBinary: PendingBinary | null = null;
  private outBuffer: Array<{ event: string; args: unknown[] }> = [];

  /** Tunnel A — file de traitement MARKET (worker indépendant). */
  private marketLane: EventLane;
  /** Tunnel B — file de traitement SOCIAL (worker indépendant). */
  private socialLane: EventLane;

  constructor(opts: RawSocketIoTransportOptions) {
    super();
    // Construit la liste des URLs (priorité à `urls`, fallback à `url`)
    if (opts.urls && opts.urls.length > 0) {
      this.urls = [...opts.urls];
    } else if (opts.url) {
      this.urls = [opts.url];
    } else {
      throw new Error('RawSocketIoTransport: either `url` or `urls` must be provided');
    }
    this.authPayload = opts.authPayload;
    this.logger = opts.logger ?? new Logger('PO-RawTransport', 'silent');
    this.userAgent = opts.userAgent ?? DEFAULTS.USER_AGENT;
    this.origin = opts.origin ?? URLS.WEB;
    this.timeout = opts.timeout ?? 30000;
    this.reconnectDelay = opts.reconnectDelay ?? TIMINGS.RECONNECT_BASE_DELAY;
    this.maxReconnectAttempts = opts.maxReconnectAttempts ?? 0;
    this.enablePsHeartbeat = opts.enablePsHeartbeat ?? true;
    this.beforeReconnect = opts.beforeReconnect;
    this.connectAttempts = opts.connectAttempts ?? 5;
    this.latency = new LatencyTracker();

    // Dual-lane dispatch : deux files indépendantes, deux workers
    // indépendants (isolation market/social — voir le bloc doc plus haut).
    const laneDispatch = (event: string, args: unknown[]): void => {
      this.emit('event', event, args);
    };
    const laneError = (err: unknown, event: string): void => {
      this.logger.error(`lane dispatch error (${event}):`, err instanceof Error ? err.message : String(err));
      this.emit('error', err instanceof Error ? err : new Error(String(err)));
    };
    this.marketLane = new EventLane('market', 10_000, laneDispatch, laneError);
    this.socialLane = new EventLane('social', 10_000, laneDispatch, laneError);
  }

  /** État courant. */
  getState(): ConnectionState {
    return this.state;
  }

  /** Statistiques de latence. */
  getLatency() {
    return this.latency.getStats();
  }

  /** Retourne le serveur actuellement connecté (null si pas connecté). */
  getConnectedServer(): string | null {
    return this.connectedServer;
  }

  /** Retourne la liste des serveurs configurés. */
  getUrls(): string[] {
    return [...this.urls];
  }

  /**
   * Met à jour la liste des serveurs (utile après fetch cabinet qui
   * peut renvoyer une liste différente de servers-list).
   */
  setUrls(urls: string[]): void {
    if (urls.length === 0) {
      this.logger.warn('setUrls() called with empty list, ignoring');
      return;
    }
    this.urls = [...urls];
    this.logger.debug('setUrls:', this.urls.length, 'serveurs');
  }

  /**
   * Démarre la connexion avec failover multi-serveurs.
   *
   * Reproduit le `connect(attempts=5)` du projet Python :
   *   for attempt in range(5):
   *     for server in self.servers:
   *       try: connect_to(server); return
   *       except: continue
   *     sleep(backoff)
   *
   * Si tous les serveurs échouent, on planifie une reconnexion
   * (avec backoff exponentiel) via `scheduleReconnect()`.
   */
  async connect(): Promise<void> {
    if (this.ws && this.ws.isOpen) {
      this.logger.debug('connect() called but already connected');
      return;
    }
    this.manuallyClosed = false;
    this.setState('connecting');

    let lastError: Error | null = null;

    for (let attempt = 0; attempt < this.connectAttempts; attempt++) {
      if (this.manuallyClosed) break;

      for (let i = 0; i < this.urls.length; i++) {
        if (this.manuallyClosed) break;
        const url = this.urls[i];
        this.currentUrlIndex = i;
        this.logger.info(
          `Transport connecting to [${i + 1}/${this.urls.length}] ${url} (attempt ${attempt + 1}/${this.connectAttempts})`,
        );
        try {
          await this.connectToSingle(url);
          this.connectedServer = url;
          this.logger.info(`Connected to ${url}`);
          return;
        } catch (err) {
          lastError = err instanceof Error ? err : new Error(String(err));
          this.logger.warn(
            `Failed to connect to ${url}: ${lastError.message}`,
          );
          // Ferme proprement avant d'essayer le suivant
          if (this.ws) {
            try { this.ws.close(); } catch { /* ignore */ }
            this.ws = null;
          }
          // Petite pause avant le prochain serveur
          await sleep(200 + Math.random() * 300);
        }
      }

      if (attempt < this.connectAttempts - 1 && !this.manuallyClosed) {
        const backoff = 500 + 1000 * attempt + Math.random() * 500;
        this.logger.info(
          `All servers failed for attempt ${attempt + 1}, retrying in ${Math.round(backoff)}ms`,
        );
        await sleep(backoff);
      }
    }

    // Tous les serveurs ont échoué après tous les cycles
    const msg = `could not connect to any server after ${this.connectAttempts} attempts: ${lastError?.message ?? 'unknown'}`;
    this.logger.error(msg);
    this.emit('error', new Error(msg));
    if (!this.manuallyClosed) {
      this.scheduleReconnect();
    } else {
      this.setState('disconnected');
    }
  }

  /**
   * Tente de se connecter à un seul serveur (handshake + auth + recv loop).
   * Throw si la connexion échoue.
   */
  private async connectToSingle(url: string): Promise<void> {
    // 1. WebSocket handshake
    this.ws = new RawWebSocket({
      url,
      origin: this.origin,
      userAgent: this.userAgent,
      timeout: this.timeout,
    });
    await this.ws.connect();
    this.emit('open');

    // 2. Attend le packet Engine.IO OPEN (0{sid,...})
    const openMsg = await this.ws.recvMessage();
    if (openMsg.opcode !== OP_TEXT || !openMsg.payload.toString('utf-8').startsWith('0{')) {
      throw new WebSocketError(
        `expected Engine.IO open packet, got ${openMsg.payload.toString('utf-8').slice(0, 80)}`,
      );
    }
    this.logger.debug('Engine.IO open:', openMsg.payload.toString('utf-8').slice(0, 120));

    // 3. Envoie `40` (Socket.IO CONNECT namespace /)
    this.ws.sendText('40');

    // 4. Attend `40` ou `40{sid}` (CONNECT_ACK) avec timeout
    const ackDeadline = Date.now() + this.timeout;
    let ackReceived = false;
    while (Date.now() < ackDeadline) {
      const msg = await this.ws.recvMessage();
      if (msg.opcode !== OP_TEXT) continue;
      const text = msg.payload.toString('utf-8');
      if (text === '40' || text.startsWith('40{')) {
        this.logger.debug('Socket.IO connected:', text.slice(0, 80));
        ackReceived = true;
        break;
      }
      if (text.startsWith('44')) {
        throw new WebSocketError(`socket.io connect error: ${text}`);
      }
    }
    if (!ackReceived) {
      throw new WebSocketError('timeout waiting for Socket.IO CONNECT_ACK');
    }

    // 5. État connected, envoie auth
    this.reconnectAttempts = 0;
    this.setState('connected');
    this.emit('connect');
    this.sendAuth();
    this.startPsHeartbeat();
    this.flushOutBuffer();

    // 6. Démarre la boucle de réception
    this.startRecvLoop();
  }

  /** Ferme la connexion proprement. */
  disconnect(): void {
    this.manuallyClosed = true;
    this.clearTimers();
    this.clearLanes();
    if (this.ws) {
      try {
        this.ws.close();
      } catch {
        // ignore
      }
      this.ws = null;
    }
    this.setState('disconnected');
  }

  /** Vide les files des lanes (events d'une connexion morte). */
  private clearLanes(): void {
    this.marketLane.clear();
    this.socialLane.clear();
  }

  /** Détruit le transport. */
  destroy(): void {
    this.disconnect();
    this.removeAllListeners();
  }

  /**
   * Envoie un event Socket.IO au serveur.
   * Format : `42["eventName", arg1, arg2, ...]`
   * Bufferisé si pas connecté.
   */
  send(event: string, ...args: unknown[]): boolean {
    if (this.ws && this.ws.isOpen) {
      const text = `42${JSON.stringify([event, ...args])}`;
      this.ws.sendText(text);
      return true;
    }
    this.outBuffer.push({ event, args });
    this.logger.debug('send() buffered (not connected):', event);
    return false;
  }

  /** Alias de `send`. */
  emitToServer(event: string, ...args: unknown[]): boolean {
    return this.send(event, ...args);
  }

  // ------------------------------------------------------------------------
  //  RECV LOOP
  // ------------------------------------------------------------------------

  private startRecvLoop(): void {
    if (this.recvLoopRunning) return;
    this.recvLoopRunning = true;
    this.recvLoop().catch((err) => {
      this.logger.error('recvLoop crashed:', err);
      this.handleDisconnect(`recv_loop_crash: ${err instanceof Error ? err.message : err}`);
    });
  }

  private async recvLoop(): Promise<void> {
    if (!this.ws) return;
    this.logger.debug('recvLoop started');
    try {
      while (!this.manuallyClosed && this.ws.isOpen) {
        const msg = await this.ws.recvMessage();
        this.logger.debug('recvLoop: got message opcode=' + msg.opcode + ' len=' + msg.payload.length);
        if (msg.opcode === OP_TEXT) {
          this.handleText(msg.payload.toString('utf-8'));
        } else if (msg.opcode === OP_BINARY) {
          this.handleBinary(msg.payload);
        }
      }
      this.logger.debug('recvLoop: exited (manuallyClosed=' + this.manuallyClosed + ', isOpen=' + this.ws?.isOpen + ')');
    } catch (err) {
      if (err instanceof WebSocketClosed) {
        this.logger.warn('recvLoop: connection closed by peer');
      } else {
        this.logger.error('recvLoop error:', err instanceof Error ? err.message : err);
      }
    } finally {
      this.recvLoopRunning = false;
      if (!this.manuallyClosed) {
        this.handleDisconnect('recv_loop_ended');
      }
    }
  }

  /** Traite une frame texte Engine.IO / Socket.IO. */
  private handleText(text: string): void {
    if (!text) return;
    this.logger.debug('handleText:', text.slice(0, 120));

    // Engine.IO PING (`2`) -> répond PONG (`3`)
    if (text === '2') {
      const sentAt = Date.now();
      this.latency.recordPing(sentAt);
      this.emit('ping', sentAt);
      this.safeSend('3');
      return;
    }

    // Engine.IO PONG (`3`) — ne devrait pas arriver côté client (le serveur
    // envoie `2` et attend `3`), mais si on reçoit un `3` on le compte comme pong.
    if (text === '3') {
      const sample = this.latency.recordAnyPong(Date.now());
      if (sample) this.emit('pong', sample);
      return;
    }

    // Engine.IO OPEN (re-negotiation) — ignore
    if (text.startsWith('0{')) {
      return;
    }

    // Engine.IO CLOSE (`1`)
    if (text === '1') {
      this.logger.debug('Engine.IO close packet received');
      this.handleDisconnect('engineio_close');
      return;
    }

    // Socket.IO BINARY EVENT (`451-[event, {_placeholder:true,num:0}]`)
    // Format : `4` + `5` (BINARY_EVENT) + `<count>-` + JSON array
    if (text.startsWith('451') || (text.startsWith('45') && text.length > 2 && /\d/.test(text[2]))) {
      const dashIdx = text.indexOf('-');
      if (dashIdx === -1) return;
      const header = text.slice(2, dashIdx); // ex: "1"
      const body = text.slice(dashIdx + 1);
      const attachments = parseInt(header, 10);
      try {
        const payload = JSON.parse(body) as unknown[];
        this.pendingBinary = { attachments, payload, got: [] };
      } catch (err) {
        this.logger.warn('Failed to parse binary event header:', err);
      }
      return;
    }

    // Socket.IO EVENT (`42[event, data]`)
    if (text.startsWith('42')) {
      this.handleEvent(text.slice(2));
      return;
    }

    // Socket.IO CONNECT_ERROR (`44...`)
    if (text.startsWith('44')) {
      this.emit('error', new Error(`socket.io connect error: ${text}`));
      return;
    }

    // Socket.IO DISCONNECT (`41`)
    if (text.startsWith('41')) {
      this.logger.debug('Socket.IO disconnect packet');
      this.handleDisconnect('sio_disconnect');
      return;
    }

    this.logger.debug('Unhandled text frame:', text.slice(0, 100));
  }

  /** Traite une frame binaire (suite d'un Binary Event 451-). */
  private handleBinary(payload: Buffer): void {
    const pending = this.pendingBinary;
    if (!pending) {
      this.logger.debug('Received binary frame without pending event, len=' + payload.length);
      return;
    }
    this.logger.debug('handleBinary: pending event, attachments=' + pending.attachments + ' got=' + pending.got.length + ' payload=' + payload.length + 'b');
    // Tente de parser comme JSON (Pocket Option envoie du JSON en binaire)
    let decoded: unknown;
    try {
      decoded = JSON.parse(payload.toString('utf-8'));
    } catch {
      decoded = payload.toString('utf-8');
    }
    pending.got.push(decoded);
    if (pending.got.length < pending.attachments) {
      return;
    }
    // Tous les attachments reçus : substitute placeholders
    this.pendingBinary = null;
    const data = substitutePlaceholders(pending.payload, pending.got);
    if (Array.isArray(data) && data.length >= 1) {
      const name = data[0] as string;
      const eventData = data.length > 1 ? data.slice(1) : [];
      this.logger.debug('handleBinary: dispatching event "' + name + '" with ' + eventData.length + ' args');
      this.ingest(name, eventData);
    } else {
      this.logger.warn('handleBinary: substituted data is not a non-empty array:', JSON.stringify(data).slice(0, 100));
    }
  }

  /** Traite un event Socket.IO texte (`42[event, data]`). */
  private handleEvent(body: string): void {
    let data: unknown[];
    try {
      const parsed = JSON.parse(body);
      if (!Array.isArray(parsed)) return;
      data = parsed;
    } catch {
      return;
    }
    const name = data[0] as string;
    const eventData = data.length > 1 ? data.slice(1) : [];
    this.ingest(name, eventData);
  }

  /**
   * Ingest un event décodé (texte ou binaire) et le propage.
   *
   * DUAL-LANE : les events MARKET et SOCIAL sont placés dans leur file
   * dédiée (traitement asynchrone indépendant — la recvLoop continue de
   * lire le socket) ; les events de CONTRÔLE (auth/acks/assets/balance/
   * deals/résultats d'ordres) restent traités immédiatement pour préserver
   * les timings d'authentification (ordre exact du carnet.har) et la
   * résolution synchrone des promesses (loadHistory, openOrder…).
   */
  private ingest(name: string, args: unknown[]): void {
    if (name === 'NotAuthorized') {
      this.logger.warn('NotAuthorized event received');
    }
    // DIAGNOSTIC (test réel martingale) : dump des payloads de règlement bruts
    if (typeof process !== 'undefined' && process.env.PO_DUMP_RAW_SETTLEMENTS === '1' &&
        /updateClosedDeals|successclose|closepair|updateOpenedDeals|successopenOrder|updateBalance/i.test(name)) {
      try {
        const fs = require('fs') as typeof import('fs');
        fs.appendFileSync(
          '/home/z/my-project/.sdk-raw-events.log',
          `${new Date().toISOString()} ${name} ${JSON.stringify(args).slice(0, 4000)}\n`,
        );
      } catch { /* fail-safe */ }
    }
    if (SOCIAL_LANE_EVENTS.has(name)) {
      this.socialLane.enqueue(name, args);
      return;
    }
    if (MARKET_LANE_EVENTS.has(name)) {
      this.marketLane.enqueue(name, args);
      return;
    }
    this.emit('event', name, args);
  }

  /** Statistiques des voies de traitement (diagnostic /social-debug). */
  getLaneStats(): LaneStats[] {
    return [this.marketLane.stats(), this.socialLane.stats()];
  }

  // ------------------------------------------------------------------------
  //  AUTH + HEARTBEAT
  // ------------------------------------------------------------------------

  /** Envoie l'event `auth` au serveur. */
  private sendAuth(): void {
    try {
      const payload =
        typeof this.authPayload === 'function'
          ? (this.authPayload as () => Record<string, unknown>)()
          : this.authPayload;
      this.logger.debug('Sending auth event', { ...payload, session: '<hidden>' });
      // Format exact : `42["auth",{...}]` (pas d'espaces, comme le Python)
      const text = `42${JSON.stringify(['auth', payload])}`;
      this.ws?.sendText(text);
      this.setState('authenticating');
    } catch (err) {
      this.logger.error('sendAuth failed:', err);
      this.emit('error', err instanceof Error ? err : new Error(String(err)));
    }
  }

  /** Démarre le heartbeat custom `ps` (toutes les 5 secondes). */
  private startPsHeartbeat(): void {
    if (!this.enablePsHeartbeat) return;
    this.stopPsHeartbeat();
    this.psTimer = setInterval(() => {
      if (this.ws?.isOpen) {
        this.ws.sendText('42["ps"]');
      }
    }, TIMINGS.PS_INTERVAL);
  }

  private stopPsHeartbeat(): void {
    if (this.psTimer) {
      clearInterval(this.psTimer);
      this.psTimer = null;
    }
  }

  /** Flush les events mis en buffer. */
  private flushOutBuffer(): void {
    if (this.outBuffer.length === 0) return;
    this.logger.debug('Flushing', this.outBuffer.length, 'buffered events');
    const buf = this.outBuffer;
    this.outBuffer = [];
    for (const { event, args } of buf) {
      this.send(event, ...args);
    }
  }

  /** Envoie un texte brutalement (catch les erreurs). */
  private safeSend(text: string): void {
    try {
      this.ws?.sendText(text);
    } catch {
      // ignore
    }
  }

  // ------------------------------------------------------------------------
  //  RECONNEXION
  // ------------------------------------------------------------------------

  private handleDisconnect(reason: string): void {
    if (this.state === 'disconnected') return;
    this.logger.warn('Disconnected:', reason);
    this.clearTimers();
    this.clearLanes();
    this.emit('disconnect', reason);
    if (this.ws) {
      try {
        this.ws.close();
      } catch {
        // ignore
      }
      this.ws = null;
    }
    if (!this.manuallyClosed) {
      this.scheduleReconnect();
    } else {
      this.setState('disconnected');
    }
  }

  private scheduleReconnect(): void {
    if (this.reconnectTimer) return;
    if (
      this.maxReconnectAttempts > 0 &&
      this.reconnectAttempts >= this.maxReconnectAttempts
    ) {
      this.logger.error('Max reconnect attempts reached, giving up');
      this.emit('reconnect_failed');
      this.setState('error');
      return;
    }
    this.reconnectAttempts++;
    const delay = Math.min(
      this.reconnectDelay * Math.pow(1.5, this.reconnectAttempts - 1),
      TIMINGS.RECONNECT_MAX_DELAY,
    );
    this.logger.info(
      `Scheduling reconnect #${this.reconnectAttempts} in ${Math.round(delay)}ms`,
    );
    this.setState('reconnecting');
    this.emit('reconnect_attempt', this.reconnectAttempts);
    this.reconnectTimer = setTimeout(async () => {
      this.reconnectTimer = null;
      if (this.manuallyClosed) return;
      try {
        // Pocket Option peut invalider une session côté broker sans fermer
        // immédiatement le socket avec un code explicite. Le hook permet au
        // client de rafraîchir la session HTTP avant le prochain handshake.
        await this.beforeReconnect?.();
      } catch (err) {
        this.logger.warn('beforeReconnect failed:', err instanceof Error ? err.message : String(err));
      }
      if (!this.manuallyClosed) void this.connect();
    }, delay);
  }

  private clearTimers(): void {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    if (this.pingTimer) {
      clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
    this.stopPsHeartbeat();
  }

  private setState(state: ConnectionState): void {
    if (this.state === state) return;
    this.state = state;
    this.emit('state', state);
  }
}

// ------------------------------------------------------------------------
//  Placeholder substitution (Socket.IO Binary Event)
// ------------------------------------------------------------------------

/**
 * Remplace les `{_placeholder: true, num: N}` par les N-ièmes attachments.
 * Reproduit le `_substitute_placeholders` du Python.
 *
 * IMPORTANT : on vérifie `Array.isArray` AVANT le cas `object`, sinon les
 * arrays sont traités comme des objets et transformés en `{"0":..., "1":...}`.
 */
function substitutePlaceholders(obj: unknown, attachments: unknown[]): unknown {
  if (Array.isArray(obj)) {
    return obj.map((v) => substitutePlaceholders(v, attachments));
  }
  if (obj && typeof obj === 'object') {
    const o = obj as Record<string, unknown>;
    if (o['_placeholder'] === true) {
      const num = (o['num'] as number) ?? 0;
      return num < attachments.length ? attachments[num] : attachments[attachments.length - 1];
    }
    const result: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(o)) {
      result[k] = substitutePlaceholders(v, attachments);
    }
    return result;
  }
  return obj;
}

/** Helper : sleep Promise. */
function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
