/**
 * @file latency-tracker.ts
 * @description Suivi de latence round-trip (RTT) basé sur les ping/pong
 *              Engine.IO. Maintient un échantillon glissant et calcule
 *              min / max / avg / courant.
 */

import type { LatencySample, LatencyStats } from '../types';
import { DEFAULTS } from '../constants';

export class LatencyTracker {
  private samples: number[] = [];
  private maxSamples: number;
  private totalPings = 0;
  private current = 0;
  private min = Infinity;
  private max = 0;
  private sum = 0;
  private pendingPings = new Map<number, number>(); // key: arbitrary id, value: sentAt

  constructor(maxSamples: number = DEFAULTS.LATENCY_SAMPLES) {
    this.maxSamples = maxSamples;
  }

  /** Enregistre l'envoi d'un ping. Retourne un id à passer à recordPong. */
  recordPing(sentAt: number = Date.now()): number {
    const id = ++this.totalPings;
    this.pendingPings.set(id, sentAt);
    return id;
  }

  /** Enregistre la réception d'un pong. */
  recordPong(id: number, receivedAt: number = Date.now()): LatencySample | null {
    const sentAt = this.pendingPings.get(id);
    if (sentAt === undefined) return null;
    this.pendingPings.delete(id);
    const rttMs = receivedAt - sentAt;
    this.pushSample(rttMs);
    return { sentAt, receivedAt, rttMs };
  }

  /** Record a pong without an id (Engine.IO basic ping/pong). */
  recordAnyPong(receivedAt: number = Date.now()): LatencySample | null {
    if (this.pendingPings.size === 0) return null;
    // Take the oldest pending ping
    const entries = Array.from(this.pendingPings.entries()).sort((a, b) => a[0] - b[0]);
    const [id, sentAt] = entries[0];
    this.pendingPings.delete(id);
    const rttMs = receivedAt - sentAt;
    this.pushSample(rttMs);
    return { sentAt, receivedAt, rttMs };
  }

  private pushSample(rttMs: number): void {
    this.samples.push(rttMs);
    if (this.samples.length > this.maxSamples) {
      this.samples.shift();
    }
    this.current = rttMs;
    if (rttMs < this.min) this.min = rttMs;
    if (rttMs > this.max) this.max = rttMs;
    this.sum += rttMs;
  }

  /** Retourne les statistiques de latence courantes. */
  getStats(): LatencyStats {
    const avg = this.samples.length > 0 ? this.sum / this.samples.length : 0;
    return {
      current: this.current,
      min: this.samples.length > 0 ? this.min : 0,
      max: this.samples.length > 0 ? this.max : 0,
      avg: Math.round(avg * 100) / 100,
      samples: [...this.samples],
      totalPings: this.totalPings,
    };
  }

  /** Réinitialise les statistiques (utile après reconnexion). */
  reset(): void {
    this.samples = [];
    this.pendingPings.clear();
    this.totalPings = 0;
    this.current = 0;
    this.min = Infinity;
    this.max = 0;
    this.sum = 0;
  }
}
