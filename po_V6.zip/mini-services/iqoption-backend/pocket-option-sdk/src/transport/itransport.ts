/**
 * @file itransport.ts
 * @description Interface commune pour les transports WebSocket Socket.IO.
 *
 * Permet aux sous-APIs (MarketDataApi, TradingApi, AccountApi, etc.) de
 * dépendre d'une abstraction plutôt que d'une implémentation concrète.
 *
 * Deux implémentations existent :
 *  - `SocketIoTransport` : basé sur `socket.io-client` (détecté par l'anti-bot
 *    de Pocket Option, donc inutilisable en production).
 *  - `RawSocketIoTransport` : basé sur `RawWebSocket` (RFC 6455 brut),
 *    bypass la détection. C'est l'implémentation utilisée par défaut.
 */

import type { ConnectionState, LatencySample, LatencyStats } from '../types';

/** Événements internes du transport (communs à toutes les implémentations). */
export interface TransportEvents {
  open: () => void;
  connect: () => void;
  disconnect: (reason: string) => void;
  reconnect_attempt: (attempt: number) => void;
  reconnect_failed: () => void;
  reconnect: () => void;
  error: (err: Error) => void;
  ping: (sentAt: number) => void;
  pong: (sample: LatencySample) => void;
  state: (state: ConnectionState) => void;
  /** Tout event Socket.IO reçu (event name + args). */
  event: (event: string, args: unknown[]) => void;
}

export interface ITransport {
  /** État courant. */
  getState(): ConnectionState;
  /** Statistiques de latence. */
  getLatency(): LatencyStats;
  /** Démarre la connexion (peut être async ou fire-and-forget). */
  connect(): void | Promise<void>;
  /** Ferme la connexion proprement. */
  disconnect(): void;
  /** Détruit le transport (libère toutes les ressources). */
  destroy(): void;
  /** Envoie un event Socket.IO au serveur (bufferisé si pas connecté). */
  send(event: string, ...args: unknown[]): boolean;
  /** Alias de `send`. */
  emitToServer(event: string, ...args: unknown[]): boolean;
  /** S'abonne à un événement interne du transport. */
  on<K extends keyof TransportEvents>(event: K, listener: TransportEvents[K]): this;
  once<K extends keyof TransportEvents>(event: K, listener: TransportEvents[K]): this;
  off<K extends keyof TransportEvents>(event: K, listener: TransportEvents[K]): this;
  removeAllListeners<K extends keyof TransportEvents>(event?: K): this;
}

/** Type alias pour la compatibilité avec le code existant. */
export type Transport = ITransport;
