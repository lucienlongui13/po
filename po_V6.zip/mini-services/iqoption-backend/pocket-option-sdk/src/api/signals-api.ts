/**
 * @file signals-api.ts
 * @description API des signaux de trading Pocket Option :
 *  - Souscription / désinscription au flux de signaux (signals/subscribe, signals/unsubscribe)
 *  - Récupération des statistiques de signaux (signals/stats)
 *  - Réception des signaux temps réel (signals/update, signals/load)
 *  - Récupération de l'état de la stratégie IA (ai-strategy-multi/get-state)
 *
 * Pocket Option expose un système de copie sociale : chaque "signal" est
 * l'ouverture d'un ordre par un trader, et peut être copié via copySignalOrder.
 */

import type { ITransport } from '../transport/itransport';
import type { TradingSignal, SignalStats } from '../types';
import { CLIENT_EVENTS } from '../constants';
import { Logger } from '../utils/logger';

export class SignalsApi {
  private transport: ITransport;
  private logger: Logger;
  private signalsCache = new Map<string, TradingSignal>();
  private isSubscribed = false;

  constructor(transport: ITransport, logger: Logger) {
    this.transport = transport;
    this.logger = logger;
    this.bindTransportEvents();
  }

  /** Souscrit au flux de signaux temps réel. */
  subscribe(): void {
    if (this.isSubscribed) return;
    this.transport.send(CLIENT_EVENTS.SIGNALS_SUBSCRIBE);
    this.isSubscribed = true;
    this.logger.info('Signals subscribed');
  }

  /** Se désabonne du flux de signaux. */
  unsubscribe(): void {
    if (!this.isSubscribed) return;
    this.transport.send(CLIENT_EVENTS.SIGNALS_UNSUBSCRIBE);
    this.isSubscribed = false;
    this.logger.info('Signals unsubscribed');
  }

  /**
   * Demande les statistiques de signaux pour une liste d'actifs/timeframes.
   *
   * Format envoyé (d'après le HAR) :
   *   [[<timestamp>, [[<asset>, <timeframe>], ...]], ...]
   *
   * @param requests Liste de { time, asset, timeframe }
   */
  fetchStats(requests: Array<{ time: number; asset: string; timeframe: number }>): void {
    // Grouper par timestamp
    const grouped = new Map<number, Array<[string, number]>>();
    for (const r of requests) {
      if (!grouped.has(r.time)) grouped.set(r.time, []);
      grouped.get(r.time)!.push([r.asset, r.timeframe]);
    }
    const payload = Array.from(grouped.entries()).map(([time, list]) => [time, list] as [number, Array<[string, number]>]);
    this.transport.send(CLIENT_EVENTS.SIGNALS_STATS, payload);
    this.logger.debug('signals/stats: requested', payload.length, 'time buckets');
  }

  /** Demande l'état de la stratégie IA multi-actifs. */
  getAiStrategyState(): void {
    this.transport.send(CLIENT_EVENTS.AI_STRATEGY_GET_STATE);
  }

  /** Retourne tous les signaux en cache. */
  getSignals(): TradingSignal[] {
    return Array.from(this.signalsCache.values());
  }

  /** Retourne un signal par ID. */
  getSignal(signalId: string): TradingSignal | undefined {
    return this.signalsCache.get(signalId);
  }

  /** Met à jour le cache (appelé par le handler). */
  updateSignal(signal: TradingSignal): void {
    this.signalsCache.set(signal.signalId, signal);
  }

  // ------------------------------------------------------------------------
  //  BINDINGS TRANSPORT
  // ------------------------------------------------------------------------

  private bindTransportEvents(): void {
    this.transport.on('event', (event: string, args: unknown[]) => {
      switch (event) {
        case 'signals/load':
          this.handleSignalsLoad(args);
          break;
        case 'signals/update':
          this.handleSignalsUpdate(args);
          break;
        case 'successsignals/stats':
          this.handleSuccessSignalsStats(args);
          break;
        case 'successai-strategy-multi/get-state':
          this.logger.debug('AI strategy state received');
          break;
      }
    });
  }

  /** Parse un signal depuis le payload serveur. */
  static parseSignal(raw: unknown): TradingSignal | null {
    if (!raw || typeof raw !== 'object') return null;
    const r = raw as Record<string, unknown>;
    const signalId = String(r.signalId ?? r.id ?? '');
    if (!signalId) return null;
    return {
      signalId,
      symbol: String(r.symbol ?? r.asset ?? ''),
      action: (r.action ?? 'call') as 'call' | 'put',
      timeframe: Number(r.timeframe ?? r.period ?? 0),
      createdAt: Number(r.createdAt ?? 0),
      expiredAt: Number(r.expiredAt ?? 0),
      stats: r.stats as SignalStats | undefined,
      raw: r,
    };
  }

  private handleSignalsLoad(args: unknown[]): void {
    const data = args[0];
    let list: unknown[] = [];
    if (Array.isArray(data)) {
      list = data;
    } else if (data && typeof data === 'object') {
      const obj = data as Record<string, unknown>;
      list = Array.isArray(obj.signals) ? obj.signals : [];
    }
    for (const raw of list) {
      const signal = SignalsApi.parseSignal(raw);
      if (signal) this.updateSignal(signal);
    }
    this.logger.debug('signals/load:', list.length, 'signals');
  }

  private handleSignalsUpdate(args: unknown[]): void {
    const data = args[0];
    let list: unknown[] = [];
    if (Array.isArray(data)) {
      list = data;
    } else if (data && typeof data === 'object') {
      list = [data];
    }
    for (const raw of list) {
      const signal = SignalsApi.parseSignal(raw);
      if (signal) this.updateSignal(signal);
    }
  }

  private handleSuccessSignalsStats(args: unknown[]): void {
    // Format variable : tableau de {asset, timeframe, copies, wins, ...}
    this.logger.debug('successsignals/stats:', args[0]);
  }
}
