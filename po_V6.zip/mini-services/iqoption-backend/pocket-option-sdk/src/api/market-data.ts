/**
 * @file market-data.ts
 * @description API pour les données de marché :
 *  - Liste des actifs (assets / markets)
 *  - Abonnement aux streams de prix temps réel (subfor / unsubfor)
 *  - Changement de symbole actif (changeSymbol)
 *  - Chargement de l'historique paginé des chandeliers (loadHistoryPeriod)
 *  - Chargement de l'historique initial (les 10000 derniers chandeliers)
 *  - Souscription aux chandeliers temps réel (chafor / updateHistoryNewFast)
 */

import type { ITransport } from '../transport/itransport';
import type {
  AssetsMap,
  Asset,
  Candle,
  HistoryPeriod,
  LoadHistoryParams,
  Period,
  RawCandle,
  StreamUpdate,
} from '../types';
import { DEFAULTS, TIMINGS, CLIENT_EVENTS } from '../constants';
import { Logger } from '../utils/logger';

export class MarketDataApi {
  private transport: ITransport;
  private logger: Logger;
  private subscribedAssets = new Set<string>();
  private assetsCache: AssetsMap = {};
  private historyResolvers = new Map<string, (h: HistoryPeriod) => void>();
  private historyRejecters = new Map<string, (e: Error) => void>();
  private historyTimers = new Map<string, NodeJS.Timeout>();

  constructor(transport: ITransport, logger: Logger) {
    this.transport = transport;
    this.logger = logger;
    this.bindTransportEvents();
  }

  // ------------------------------------------------------------------------
  //  ASSETS
  // ------------------------------------------------------------------------

  /** Retourne le cache courant des actifs. */
  getAssets(): AssetsMap {
    return this.assetsCache;
  }

  /** Recherche un actif par ID. */
  getAsset(assetId: string): Asset | undefined {
    return this.assetsCache[assetId];
  }

  /** Met à jour le cache interne des actifs (appelé par le handler `updateAssets`). */
  updateAssetsCache(assets: AssetsMap): void {
    this.assetsCache = { ...this.assetsCache, ...assets };
  }

  // ------------------------------------------------------------------------
  //  SUBSCRIPTIONS
  // ------------------------------------------------------------------------

  /**
   * S'abonne aux streams d'un actif (prix temps réel + chandeliers).
   * Émet l'event `subfor` avec l'asset ID.
   */
  subscribe(asset: string): void {
    if (this.subscribedAssets.has(asset)) {
      this.logger.debug('subscribe() already subscribed:', asset);
      return;
    }
    this.subscribedAssets.add(asset);
    this.transport.send(CLIENT_EVENTS.SUBFOR, asset);
    this.logger.debug('subscribe():', asset);
  }

  /** Se désabonne d'un actif. */
  unsubscribe(asset: string): void {
    if (!this.subscribedAssets.has(asset)) {
      return;
    }
    this.subscribedAssets.delete(asset);
    this.transport.send(CLIENT_EVENTS.UNSUBFOR, asset);
    this.logger.debug('unsubscribe():', asset);
  }

  /** Alias alternatif : `subscribeSymbol` (utilisé pour les signaux). */
  subscribeSymbol(asset: string): void {
    this.transport.send(CLIENT_EVENTS.SUBSCRIBE_SYMBOL, asset);
    this.logger.debug('subscribeSymbol():', asset);
  }

  /**
   * Change le symbole actif (l'actif affiché sur le chart courant).
   * Le serveur commence à pousser les chandeliers temps réel pour ce symbole.
   *
   * @param asset Asset ID
   * @param period Période en secondes (5, 15, 30, 60, 120, 180, 240, 300, ...)
   */
  changeSymbol(asset: string, period: Period): void {
    this.transport.send(CLIENT_EVENTS.CHANGE_SYMBOL, { asset, period });
    this.logger.debug('changeSymbol():', asset, period);
  }

  /** Retourne la liste des actifs actuellement abonnés. */
  getSubscribedAssets(): string[] {
    return Array.from(this.subscribedAssets);
  }

  // ------------------------------------------------------------------------
  //  HISTORIQUE
  // ------------------------------------------------------------------------

  /**
   * Charge une période d'historique (jusqu'à `offset` chandeliers, max 9000 par batch).
   *
   * @param params Paramètres du chargement
   * @returns Promesse résolue avec les chandeliers reçus
   */
  loadHistoryPeriod(params: LoadHistoryParams): Promise<HistoryPeriod> {
    const offset = params.offset ?? DEFAULTS.MAX_HISTORY_BATCH;
    const index = params.index ?? Date.now();
    const key = this.historyKey(params.asset, params.period, index);

    return new Promise<HistoryPeriod>((resolve, reject) => {
      // Timeout
      const timer = setTimeout(() => {
        this.historyResolvers.delete(key);
        this.historyRejecters.delete(key);
        this.historyTimers.delete(key);
        reject(new Error(`History timeout for ${key}`));
      }, TIMINGS.HISTORY_TIMEOUT);
      this.historyTimers.set(key, timer);
      this.historyResolvers.set(key, resolve);
      this.historyRejecters.set(key, reject);

      this.transport.send(CLIENT_EVENTS.LOAD_HISTORY_PERIOD, {
        asset: params.asset,
        index,
        time: params.time,
        offset,
        period: params.period,
      });
      this.logger.debug('loadHistoryPeriod():', { ...params, index, offset });
    });
  }

  /**
   * Charge l'historique complet jusqu'à atteindre ~10000 chandeliers.
   * Effectue plusieurs appels `loadHistoryPeriod` en paginant à rebours.
   *
   * @param asset Asset ID
   * @param period Période en secondes
   * @param targetCount Nombre cible de chandeliers (default: 10000)
   * @param startTimeSec Timestamp marché LIVE à utiliser comme ancre de la
   * première page. Cela évite de demander une histoire décalée lorsque
   * l'horloge de l'hôte diffère de celle du broker.
   * @returns Tous les chandeliers (du plus ancien au plus récent)
   */
  async loadFullHistory(
    asset: string,
    period: Period,
    targetCount: number = DEFAULTS.FULL_HISTORY_TARGET,
    startTimeSec?: number,
  ): Promise<Candle[]> {
    const allCandles: Candle[] = [];
    // Pocket Option market timestamps can be ahead of the host/device clock
    // (notably by the local timezone offset). Always let the caller anchor
    // the first history request to a known LIVE market timestamp when one is
    // available. Pagination then follows the broker's own candle timestamps.
    const requestedAnchor = Number.isFinite(startTimeSec) && (startTimeSec ?? 0) > 0
      ? Math.floor(startTimeSec!)
      : Math.floor(Date.now() / 1000);
    let endTime = requestedAnchor;
    const batchSize = DEFAULTS.MAX_HISTORY_BATCH;
    let iterations = 0;
    // Each server batch returns ~150 candles (not 9000), so we need more iterations
    const maxIterations = Math.ceil(targetCount / 50) + 5;
    // v6.5 — résilience de pagination : un batch en échec (timeout/serveur)
    // ne doit PLUS faire sauter `batchSize` périodes (9000 × period ≈ 75 h à
    // S30 → trous géants dans la série → assets DEGRADED en cascade). On
    // réessaie le MÊME endTime une fois, puis on recule d'un batch typique.
    let consecutiveFailures = 0;
    const typicalBatch = 150;

    this.logger.info(
      `loadFullHistory(): asset=${asset} period=${period}s target=${targetCount}`,
    );

    while (allCandles.length < targetCount && iterations < maxIterations) {
      iterations++;
      try {
        const history = await this.loadHistoryPeriod({
          asset,
          time: endTime,
          offset: batchSize,
          period,
        });
        if (history.candles.length === 0) break;

        // Insère au début (les plus anciens d'abord)
        allCandles.unshift(...history.candles);

        // Le prochain batch commence juste avant le plus ancien reçu
        const oldest = history.candles[0];
        endTime = oldest.time - period;
        consecutiveFailures = 0;

        this.logger.debug(
          `loadFullHistory batch #${iterations}: +${history.candles.length} candles, total=${allCandles.length}`,
        );

        // NE PAS s'arrêter si le serveur renvoie moins que batchSize.
        // Le serveur Pocket Option a sa propre limite de batch (~150 candles pour period=60s).
        // On continue à paginer jusqu'à atteindre targetCount ou jusqu'à recevoir une réponse vide.
        // On s'arrête seulement si on reçoit 0 chandelier (fin de l'historique disponible).
      } catch (err) {
        this.logger.error('loadFullHistory batch failed:', err);
        consecutiveFailures++;
        if (consecutiveFailures === 1) {
          // Premier échec : RÉESSAIE la même plage (le serveur peut avoir eu
          // un hoquet passager — ne surtout pas sauter de données).
          continue;
        }
        if (consecutiveFailures >= 3) {
          // Échecs répétés : on s'arrête PROPREMENT — les bougies déjà
          // chargées sont contiguës, la réparation ciblée (§13) pourra
          // combler plus tard si nécessaire.
          this.logger.error(
            `loadFullHistory: ${consecutiveFailures} échecs consécutifs — arrêt propre à ${allCandles.length} bougies (pas de saut de plage)`,
          );
          break;
        }
        // Deuxième échec : recule d'UN batch typique (≈ 150 bougies) et non
        // de batchSize (9000) — la plage sautée reste réparable.
        endTime = endTime - typicalBatch * (period as number);
      }
    }

    // Dédoublonnage par timestamp (au cas où des batches se chevauchent)
    const seen = new Set<number>();
    const deduped = allCandles.filter((c) => {
      if (seen.has(c.time)) return false;
      seen.add(c.time);
      return true;
    });

    this.logger.info(
      `loadFullHistory(): done, ${deduped.length} candles loaded in ${iterations} batches`,
    );
    return deduped;
  }

  // ------------------------------------------------------------------------
  //  PARSING (handlers pour les events serveur)
  // ------------------------------------------------------------------------

  /**
   * Parse un tableau de chandeliers bruts en Candle[].
   *
   * Deux formats supportés :
   *  1. Array compact : [ts, open, high, low, close, volume?] (format FX/MT5)
   *  2. Objet : {time, open, high, low, close, volume?} (format binaire PO)
   *
   * Le format PO binaire (observé en live sur EURUSD_otc) :
   *   {"symbol_id":66,"time":1787109420,"open":1.24173,"close":1.24132,
   *    "high":1.24174,"low":1.24114,"volume":88}
   */
  static parseCandles(raw: RawCandle[] | unknown): Candle[] {
    if (!Array.isArray(raw)) return [];
    return raw.map((c): Candle => {
      // Format objet : {time, open, high, low, close, volume?}
      if (c && typeof c === 'object' && !Array.isArray(c)) {
        const o = c as Record<string, unknown>;
        return {
          time: Number(o.time ?? o.from ?? o.t ?? 0),
          open: Number(o.open ?? 0),
          high: Number(o.high ?? o.max ?? 0),
          low: Number(o.low ?? o.min ?? 0),
          close: Number(o.close ?? 0),
          volume: typeof o.volume === 'number' ? o.volume : undefined,
        };
      }
      // Format array compact : [ts, open, high, low, close, volume?]
      const arr = c as RawCandle;
      return {
        time: arr[0],
        open: arr[1],
        high: arr[2],
        low: arr[3],
        close: arr[4],
        volume: arr[5],
      } as Candle;
    });
  }

  /**
   * Parse une mise à jour de stream (format binaire déserialisé).
   *
   * Format observé en live (mode réel) :
   *   - `args` reçu par le client = `[[[asset, ts, price]]]`  (triple-nested)
   *   - `args[0]` passé au parser   = `[[asset, ts, price]]`   (double-nested)
   *
   * Donc `raw` = `[[asset, ts, price], ...]` où chaque item est
   * `[asset (string), timestamp (ms avec décimales), price (number)]`.
   *
   * On détecte ce format en vérifiant que `raw[0]` est un array dont le
   * premier élément est une string.
   *
   * Autres formats possibles (rétro-compat) :
   *   - [[asset, bid, ask, time, change, changePercent, volume], ...]
   *   - [{asset, bid, ask, time, ...}, ...]
   */
  static parseStreamUpdate(raw: unknown): StreamUpdate[] {
    const out: StreamUpdate[] = [];
    if (!Array.isArray(raw)) return out;

    // Détecte le format double-nested : [[asset, ts, price], ...]
    // (le premier élément de raw[0] doit être une string)
    if (
      raw.length > 0 &&
      Array.isArray(raw[0]) &&
      raw[0].length >= 3 &&
      typeof raw[0][0] === 'string'
    ) {
      for (const item of raw) {
        if (!Array.isArray(item) || item.length < 3) continue;
        const [asset, ts, price] = item as [string, number, number];
        if (
          typeof asset === 'string' &&
          typeof ts === 'number' &&
          typeof price === 'number'
        ) {
          out.push({
            asset,
            bid: price,
            ask: price,
            time: Math.floor(ts),
            raw: item,
          });
        }
      }
      return out;
    }

    // Format classique : [[asset, bid, ask, time, ...], ...] ou [{asset, ...}, ...]
    for (const item of raw) {
      if (Array.isArray(item)) {
        // [asset, bid, ask, time, change, changePercent, volume]
        const [asset, bid, ask, time, change, changePercent, volume] = item as [
          string, number, number, number, number?, number?, number?
        ];
        if (asset && typeof bid === 'number' && typeof ask === 'number') {
          out.push({
            asset: String(asset),
            bid,
            ask,
            time: Number(time) || Math.floor(Date.now() / 1000),
            change,
            changePercent,
            volume,
            raw: item,
          });
        }
      } else if (item && typeof item === 'object') {
        const obj = item as Record<string, unknown>;
        if (typeof obj.asset === 'string') {
          out.push({
            asset: obj.asset as string,
            bid: Number(obj.bid ?? 0),
            ask: Number(obj.ask ?? 0),
            time: Number(obj.time ?? Math.floor(Date.now() / 1000)),
            change: obj.change as number | undefined,
            changePercent: obj.changePercent as number | undefined,
            volume: obj.volume as number | undefined,
            raw: obj,
          });
        }
      }
    }
    return out;
  }

  // ------------------------------------------------------------------------
  //  BINDINGS TRANSPORT
  // ------------------------------------------------------------------------

  private bindTransportEvents(): void {
    this.transport.on('event', (event: string, args: unknown[]) => {
      switch (event) {
        case 'loadHistoryPeriodFast':
          this.handleHistoryPeriodFast(args);
          break;
        case 'updateHistoryNewFast':
          this.handleHistoryNewFast(args);
          break;
        case 'updateAssets':
          this.handleUpdateAssets(args);
          break;
        case 'chafor':
          this.handleChafor(args);
          break;
        // Les autres events (updateStream, etc.) sont gérés au niveau du client
      }
    });
  }

  private historyKey(asset: string, period: number, index: number | string): string {
    return `${asset}|${period}|${index}`;
  }

  private handleHistoryPeriodFast(args: unknown[]): void {
    // Format observé en live (PO binaire) :
    //   { asset, period, index, data: [{symbol_id, time, open, high, low, close, volume}, ...] }
    // Autres formats possibles (rétro-compat) :
    //   { asset, period, index, candles: [[ts,o,h,l,c,v], ...] }
    //   { asset, period, index, bars: [[ts,o,h,l,c,v], ...] }
    const data = (args[0] ?? {}) as Record<string, unknown>;
    const asset = String(data.asset ?? '');
    const period = Number(data.period ?? 0);
    const index = Number(data.index ?? Date.now());
    const key = this.historyKey(asset, period, index);

    const candles = MarketDataApi.parseCandles(data.data ?? data.candles ?? data.bars);
    const history: HistoryPeriod = {
      asset,
      period,
      candles,
      hasMore: Boolean(data.hasMore ?? data.nextTime),
      nextIndex: data.nextTime ? Number(data.nextTime) : undefined,
      raw: data,
    };

    // Try exact key match first
    let resolve = this.historyResolvers.get(key);
    if (resolve) {
      clearTimeout(this.historyTimers.get(key) as NodeJS.Timeout);
      this.historyResolvers.delete(key);
      this.historyRejecters.delete(key);
      this.historyTimers.delete(key);
      resolve(history);
      return;
    }

    // Fallback: if exact index doesn't match, resolve ANY pending request
    // for the same asset+period (the server might echo a different index).
    // ⚠️ ANTI CROSS-RESOLUTION : si PLUSIEURS requêtes sont pendantes pour
    // le même asset+period (ex. cache 90 j + fetch graphique concurrents),
    // répondre au hasard échangerait les batches entre appelants (données
    // d'une autre plage horaire, cache contaminé). On ne résout que si la
    // requête pendante est UNIQUE — sinon la réponse est abandonnée (les
    // timers des requêtes concernées déclencheront un refetch propre).
    const prefix = `${asset}|${period}|`;
    const matches: Array<string> = [];
    for (const pendingKey of this.historyResolvers.keys()) {
      if (pendingKey.startsWith(prefix)) matches.push(pendingKey);
    }
    if (matches.length === 1) {
      const pendingKey = matches[0];
      const pendingResolve = this.historyResolvers.get(pendingKey);
      if (pendingResolve) {
        clearTimeout(this.historyTimers.get(pendingKey) as NodeJS.Timeout);
        this.historyResolvers.delete(pendingKey);
        this.historyRejecters.delete(pendingKey);
        this.historyTimers.delete(pendingKey);
        pendingResolve(history);
      }
    }
    // No unique matching resolver — drop (avoid cross-resolution corruption)
  }

  private handleHistoryNewFast(args: unknown[]): void {
    // Format attendu : { asset, period, candles: [candle] } pour les nouveaux chandeliers
    // Le client principal traitera cet event pour émettre `candles_update`.
    // Ici on ne fait rien de spécial : le client écoute déjà via onAny.
    void args;
  }

  private handleUpdateAssets(args: unknown[]): void {
    // Format réel Pocket Option (observé dans le HAR, mode démo ET réel) :
    //   une LISTE d'actifs au format tableau compact :
    //   [
    //     0  : asset_id numérique (ex: 66)
    //     1  : symbole           (ex: "EURUSD_otc", "#AAPL")
    //     2  : nom affiché       (ex: "EUR/USD OTC", "Apple")
    //     3  : type              ("currency" | "stock" | "index" | "cryptocurrency" | "commodity")
    //     4  : groupe de marché
    //     5  : payout en pourcentage (dynamique — varie pour les actifs OTC)
    //     9  : isOtc             (1 = OTC)
    //     10 : id de l'actif OTC correspondant (actifs standard)
    //     11 : id de l'actif standard correspondant (actifs OTC)
    //     13 : timestamp d'ouverture du prochain marché
    //     14 : isOpen            (true = marché actuellement ouvert, OTC toujours true)
    //     15 : expirations disponibles [{time}, ...]
    //     18 : timestamp de fermeture (-1 = OTC / toujours ouvert)
    //   ]
    const data = args[0];
    const assets: AssetsMap = {};

    if (Array.isArray(data)) {
      // Format tableau (production Pocket Option — 183 actifs observés)
      for (const raw of data) {
        if (!Array.isArray(raw) || typeof raw[1] !== 'string') continue;
        const [
          rawId, symbol, longName, type, , payout, , , , rawOtc,
          , , , , rawOpen,
        ] = raw as unknown[];
        const id = String(rawId);
        assets[id] = {
          id,
          name: String(symbol),
          type: (type ?? 'currency') as Asset['type'],
          payout: typeof payout === 'number' && payout > 0 ? payout : undefined,
          isOtc: rawOtc === 1 || String(symbol).includes('_otc'),
          longName: longName ? String(longName) : undefined,
          isOpen: rawOpen === true,
          raw,
        };
      }
    } else if (data && typeof data === 'object') {
      // Format objet (rétro-compatibilité — ancien format supposé)
      for (const [id, raw] of Object.entries(data as Record<string, unknown>)) {
        if (raw && typeof raw === 'object') {
          const r = raw as Record<string, unknown>;
          assets[id] = {
            id,
            name: String(r.name ?? r.n ?? id),
            type: (r.type ?? r.t ?? 'currency') as Asset['type'],
            currency: r.currency as string | undefined,
            payout: r.payout ? Number(r.payout) : undefined,
            isOtc: id.includes('_otc') || Boolean(r.isOtc),
            longName: r.longName as string | undefined,
            isOpen: typeof r.isOpen === 'boolean' ? r.isOpen : undefined,
            precision: r.precision ? Number(r.precision) : undefined,
            minVolume: r.minVolume ? Number(r.minVolume) : undefined,
            maxVolume: r.maxVolume ? Number(r.maxVolume) : undefined,
            volumeStep: r.volumeStep ? Number(r.volumeStep) : undefined,
            swapLong: r.swapLong ? Number(r.swapLong) : undefined,
            swapShort: r.swapShort ? Number(r.swapShort) : undefined,
            leverage: r.leverage ? Number(r.leverage) : undefined,
            schedule: r.schedule as Asset['schedule'],
            raw: r,
          };
        }
      }
    }
    this.updateAssetsCache(assets);
  }

  private handleChafor(args: unknown[]): void {
    // `chafor` (chart for) : mise à jour de chandeliers temps réel pour un actif.
    // Format attendu : { asset, period, candles: [...] } ou [asset, period, candles]
    // Le client principal émettra `candles_update` à partir de ça.
    void args;
  }
}
