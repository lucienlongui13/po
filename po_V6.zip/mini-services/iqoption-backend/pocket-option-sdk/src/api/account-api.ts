/**
 * @file account-api.ts
 * @description API de gestion du compte :
 *  - Récupération des balances (toutes poches : demo / real / MT4 / MT5 / CFD)
 *  - Mise à jour de balance temps réel (successupdateBalance)
 *  - Récupération / suivi des deals ouverts et clôturés
 *  - Sauvegarde des charts (saveCharts)
 *  - Chargement des indicateurs / favoris / price-alerts
 *
 * Une partie des données vient du WS (events `successupdateBalance`,
 * `updateOpenedDeals`, `updateClosedDeals`), une autre partie vient du HTTP
 * (route `m.pocketoption.com/en/cabinet/user-get-balances`).
 */

import type { ITransport } from '../transport/itransport';
import type {
  BalanceUpdate,
  Balances,
  OpenedDeal,
  ClosedDeal,
} from '../types';
import { CLIENT_EVENTS, URLS } from '../constants';
import { Logger } from '../utils/logger';
import { TradingApi } from './trading-api';

export interface AccountSnapshot {
  isDemo: 0 | 1;
  balance: number;
  balances: Balances;
  openedDeals: OpenedDeal[];
  closedDeals: ClosedDeal[];
}

export class AccountApi {
  private transport: ITransport;
  private logger: Logger;
  private currentBalance: BalanceUpdate = { isDemo: 1, balance: 0 };
  private balances: Balances = {};
  private openedDeals: OpenedDeal[] = [];
  private closedDeals: ClosedDeal[] = [];
  private fetchImpl: typeof fetch;

  constructor(
    transport: ITransport,
    logger: Logger,
    fetchImpl: typeof fetch = fetch,
  ) {
    this.transport = transport;
    this.logger = logger;
    this.fetchImpl = fetchImpl;
    this.bindTransportEvents();
  }

  // ------------------------------------------------------------------------
  //  BALANCES
  // ------------------------------------------------------------------------

  /** Retourne le snapshot courant des balances (mis à jour via WS). */
  getBalances(): Balances {
    return { ...this.balances };
  }

  /** Retourne la balance courante (démo ou réel selon le mode). */
  getCurrentBalance(): number {
    return this.currentBalance.balance;
  }

  /**
   * Récupère toutes les balances via l'endpoint HTTP web.
   * Nécessite une session web valide (cookie ci_session).
   *
   * @param cookies Cookies HTTP à envoyer (format "name1=val1; name2=val2")
   */
  async fetchBalancesHttp(cookies?: string): Promise<Balances> {
    const url = `${URLS.WEB}/en/cabinet/user-get-balances`;
    const headers: Record<string, string> = {
      'X-Requested-With': 'XMLHttpRequest',
      Accept: 'application/json',
    };
    if (cookies) {
      headers.Cookie = cookies;
    }
    try {
      const res = await this.fetchImpl(url, { method: 'POST', headers });
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }
      const json = (await res.json()) as { status: boolean; data?: { balances: Balances } };
      if (json.status && json.data?.balances) {
        this.balances = { ...this.balances, ...json.data.balances };
        this.logger.debug('fetchBalancesHttp: success', this.balances);
        return this.balances;
      }
      throw new Error('Invalid response');
    } catch (err) {
      this.logger.error('fetchBalancesHttp failed:', err);
      throw err;
    }
  }

  /** Met à jour le cache interne de balance (appelé par le handler WS). */
  updateBalance(update: BalanceUpdate): void {
    this.currentBalance = update;
    if (update.balances) {
      this.balances = { ...this.balances, ...update.balances };
    }
  }

  // ------------------------------------------------------------------------
  //  DEALS
  // ------------------------------------------------------------------------

  /** Retourne les deals actuellement ouverts. */
  getOpenedDeals(): OpenedDeal[] {
    return [...this.openedDeals];
  }

  /** Retourne les deals clôturés (historique récent). */
  getClosedDeals(): ClosedDeal[] {
    return [...this.closedDeals];
  }

  /** Met à jour le cache des deals ouverts (appelé par le handler WS). */
  setOpenedDeals(deals: OpenedDeal[]): void {
    this.openedDeals = deals;
  }

  /** Met à jour le cache des deals clôturés (appelé par le handler WS). */
  setClosedDeals(deals: ClosedDeal[]): void {
    this.closedDeals = deals;
  }

  // ------------------------------------------------------------------------
  //  CHARTS / INDICATORS / FAVORITES
  // ------------------------------------------------------------------------

  /**
   * Sauvegarde la configuration d'un chart.
   * Le serveur persiste ces settings pour l'utilisateur.
   */
  saveCharts(chartId: string, settings: Record<string, unknown>): void {
    const payload = { chartId, settings };
    this.transport.send(CLIENT_EVENTS.SAVE_CHARTS, payload);
    this.logger.debug('saveCharts:', chartId);
  }

  /** Charge la liste des indicateurs sauvegardés. */
  loadIndicators(): void {
    this.transport.send(CLIENT_EVENTS.INDICATOR_LOAD);
  }

  /** Charge la liste des favoris. */
  loadFavorites(): void {
    this.transport.send(CLIENT_EVENTS.FAVORITE_LOAD);
  }

  /** Charge la liste des alertes de prix. */
  loadPriceAlerts(): void {
    this.transport.send(CLIENT_EVENTS.PRICE_ALERT_LOAD);
  }

  // ------------------------------------------------------------------------
  //  SNAPSHOT
  // ------------------------------------------------------------------------

  /** Retourne un snapshot complet du compte. */
  getSnapshot(): AccountSnapshot {
    return {
      isDemo: this.currentBalance.isDemo,
      balance: this.currentBalance.balance,
      balances: { ...this.balances },
      openedDeals: [...this.openedDeals],
      closedDeals: [...this.closedDeals],
    };
  }

  // ------------------------------------------------------------------------
  //  BINDINGS TRANSPORT
  // ------------------------------------------------------------------------

  private bindTransportEvents(): void {
    this.transport.on('event', (event: string, args: unknown[]) => {
      switch (event) {
        case 'successupdateBalance':
          this.handleUpdateBalance(args);
          break;
        case 'updateOpenedDeals':
          this.handleUpdateOpenedDeals(args);
          break;
        case 'updateClosedDeals':
          this.handleUpdateClosedDeals(args);
          break;
      }
    });
  }

  private handleUpdateBalance(args: unknown[]): void {
    const data = (args[0] ?? {}) as Record<string, unknown>;
    // Format attendu : { balance, isDemo, balances: {...} } ou { balance: <number> }
    const balance = Number(data.balance ?? 0);
    const isDemo = (data.isDemo ?? this.currentBalance.isDemo) as 0 | 1;
    const balances = (data.balances ?? {}) as Balances;
    this.updateBalance({ balance, isDemo, balances, raw: data });
    this.logger.debug('successupdateBalance:', balance, 'isDemo=', isDemo);
  }

  private handleUpdateOpenedDeals(args: unknown[]): void {
    const data = args[0];
    let deals: OpenedDeal[] = [];
    if (Array.isArray(data)) {
      deals = data
        .map((d) => TradingApi.parseOpenedDeal(d))
        .filter((d): d is OpenedDeal => d !== null);
    } else if (data && typeof data === 'object') {
      const obj = data as Record<string, unknown>;
      const list = obj.deals ?? obj.openedDeals ?? obj.list;
      if (Array.isArray(list)) {
        deals = list
          .map((d) => TradingApi.parseOpenedDeal(d))
          .filter((d): d is OpenedDeal => d !== null);
      }
    }
    this.setOpenedDeals(deals);
    this.logger.debug('updateOpenedDeals:', deals.length, 'deals');
  }

  private handleUpdateClosedDeals(args: unknown[]): void {
    const data = args[0];
    let deals: ClosedDeal[] = [];
    if (Array.isArray(data)) {
      deals = data
        .map((d) => TradingApi.parseClosedDeal(d))
        .filter((d): d is ClosedDeal => d !== null);
    } else if (data && typeof data === 'object') {
      const obj = data as Record<string, unknown>;
      const list = obj.deals ?? obj.closedDeals ?? obj.list;
      if (Array.isArray(list)) {
        deals = list
          .map((d) => TradingApi.parseClosedDeal(d))
          .filter((d): d is ClosedDeal => d !== null);
      }
    }
    this.setClosedDeals(deals);
    this.logger.debug('updateClosedDeals:', deals.length, 'deals');
  }
}
