/**
 * @file trading-api.ts
 * @description API de trading binaire :
 *  - Placement d'ordres CALL / PUT (openOrder)
 *  - Placement d'ordres express multi-actifs (openExpress)
 *  - Fermeture d'ordre anticipée (closeOrder, via un event custom)
 *  - Copie de signaux (copySignalOrder)
 *  - Suivi des résultats (successopenOrder / failopenOrder / successcloseOrder)
 *
 * Latence : on maintient une Map de pending orders indexée par requestId
 * pour pouvoir résoudre la promesse dès que le serveur répond.
 */

import type { ITransport } from '../transport/itransport';
import type {
  OpenOrderParams,
  OpenOrderResult,
  OpenExpressParams,
  OpenedDeal,
  ClosedDeal,
  OrderAction,
  OptionType,
} from '../types';
import { CLIENT_EVENTS, ERROR_CODES, TIMINGS } from '../constants';
import { Logger } from '../utils/logger';
import { generateRequestId } from '../utils/session';

export class TradingApi {
  private transport: ITransport;
  private logger: Logger;
  private isDemo: 0 | 1 = 1;
  private pendingOrders = new Map<number, {
    resolve: (r: OpenOrderResult) => void;
    reject: (e: Error) => void;
    timer: NodeJS.Timeout;
    asset: string;
    action: OrderAction;
    amount: number;
  }>();

  constructor(transport: ITransport, logger: Logger) {
    this.transport = transport;
    this.logger = logger;
    this.bindTransportEvents();
  }

  /** Définit le mode (démo ou réel) pour les futurs ordres. */
  setMode(isDemo: boolean): void {
    this.isDemo = isDemo ? 1 : 0;
  }

  /**
   * Recent order actions (requestId → action), kept for 30 seconds after resolution.
   * Used to fix the deal action when the server doesn't echo it back in
   * successopenOrder / updateOpenedDeals responses.
   */
  private recentActions: Map<number, { action: OrderAction; ts: number }> = new Map();

  /**
   * Get the action ('call' or 'put') for a pending or recently-resolved order by requestId.
   * Used to fix the deal action when the server doesn't echo it back.
   * Returns undefined if the order is unknown or expired (>30s ago).
   */
  getPendingAction(requestId: number): OrderAction | undefined {
    // First check pending orders
    const pending = this.pendingOrders.get(requestId);
    if (pending) return pending.action;
    // Then check recent actions (resolved within last 30s)
    const recent = this.recentActions.get(requestId);
    if (recent && Date.now() - recent.ts < 30000) return recent.action;
    return undefined;
  }

  /** Record an order action for later lookup (called when openOrder is sent) */
  private recordAction(requestId: number, action: OrderAction): void {
    this.recentActions.set(requestId, { action, ts: Date.now() });
    // Clean up old entries (>60s)
    const now = Date.now();
    for (const [id, entry] of this.recentActions) {
      if (now - entry.ts > 60000) this.recentActions.delete(id);
    }
  }

  // ------------------------------------------------------------------------
  //  OPEN ORDER (binary CALL/PUT)
  // ------------------------------------------------------------------------

  /**
   * Place un ordre binaire CALL ou PUT.
   *
   * @param params Paramètres de l'ordre
   * @returns Promesse résolue à la réception de `successopenOrder` ou `failopenOrder`
   */
  openOrder(params: OpenOrderParams): Promise<OpenOrderResult> {
    const requestId = params.requestId ?? generateRequestId();
    const isDemo = params.isDemo ?? this.isDemo;
    const optionType: OptionType = params.optionType ?? 100;

    const payload = {
      asset: params.asset,
      amount: params.amount,
      action: params.action,
      isDemo,
      requestId,
      optionType,
      time: params.time,
    };

    return new Promise<OpenOrderResult>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pendingOrders.delete(requestId);
        reject(new Error(`${ERROR_CODES.ORDER_TIMEOUT}: requestId=${requestId}`));
      }, TIMINGS.ORDER_TIMEOUT);

      // Record the action so we can fix the deal later if the server doesn't echo it
      this.recordAction(requestId, params.action);

      this.pendingOrders.set(requestId, {
        resolve,
        reject,
        timer,
        asset: params.asset,
        action: params.action,
        amount: params.amount,
      });

      this.transport.send(CLIENT_EVENTS.OPEN_ORDER, payload);
      this.logger.info(
        `openOrder: ${params.action.toUpperCase()} ${params.asset} amount=${params.amount} time=${params.time}s reqId=${requestId}`,
      );
    });
  }

  /** Raccourci pour ouvrir un ordre CALL (montant haussier). */
  call(asset: string, amount: number, time: number, optionType?: OptionType): Promise<OpenOrderResult> {
    return this.openOrder({ asset, amount, action: 'call', time, optionType });
  }

  /** Raccourci pour ouvrir un ordre PUT (montant baissier). */
  put(asset: string, amount: number, time: number, optionType?: OptionType): Promise<OpenOrderResult> {
    return this.openOrder({ asset, amount, action: 'put', time, optionType });
  }

  // ------------------------------------------------------------------------
  //  OPEN EXPRESS (multi-actifs)
  // ------------------------------------------------------------------------

  /**
   * Ouvre un ordre express (multi-actifs).
   *
   * Format envoyé au serveur (d'après le HAR) :
   *   [amount, [[asset, action, expireAt], ...]]
   *
   * @param params Paramètres de l'ordre express
   */
  openExpress(params: OpenExpressParams): void {
    const isDemo = params.isDemo ?? this.isDemo;
    const legs = params.legs.map((l) => [l.asset, l.action, l.expireAt] as [string, OrderAction, number]);
    // Format Pocket Option : [isDemo, legs]
    const payload = [isDemo, legs];
    this.transport.send(CLIENT_EVENTS.OPEN_EXPRESS, payload);
    this.logger.info(
      `openExpress: ${legs.length} legs, amount=${params.amount}, isDemo=${isDemo}`,
    );
  }

  // ------------------------------------------------------------------------
  //  COPY SIGNAL
  // ------------------------------------------------------------------------

  /**
   * Copie un signal de trading (copie sociale).
   *
   * @param signalId ID du signal à copier
   * @param symbol Asset
   * @param amount Montant
   * @param action Direction
   * @param expiredAt Timestamp d'expiration (secondes)
   * @param timeframe Période (60, 180, etc.)
   * @param createdAt Timestamp de création (default: now)
   * @param requestId ID de requête (default: généré)
   */
  copySignalOrder(opts: {
    signalId: string;
    symbol: string;
    amount: number;
    action: OrderAction;
    expiredAt: number;
    timeframe: number;
    createdAt?: number;
    requestId?: number;
  }): void {
    const isDemo = this.isDemo;
    const requestId = opts.requestId ?? generateRequestId();
    const createdAt = opts.createdAt ?? Math.floor(Date.now() / 1000);
    const payload = {
      symbol: opts.symbol,
      amount: opts.amount,
      expiredAt: opts.expiredAt,
      action: opts.action,
      isDemo,
      requestId,
      createdAt,
      timeframe: opts.timeframe,
      signalId: opts.signalId,
    };
    this.transport.send(CLIENT_EVENTS.COPY_SIGNAL_ORDER, payload);
    this.logger.info(
      `copySignalOrder: signal=${opts.signalId} ${opts.action.toUpperCase()} ${opts.symbol} amount=${opts.amount}`,
    );
  }

  // ------------------------------------------------------------------------
  //  REQUEST CLOSED EXPRESSES UPDATE
  // ------------------------------------------------------------------------

  /** Demande au serveur de rafraîchir la liste des ordres express clôturés. */
  updateClosedExpresses(): void {
    this.transport.send(CLIENT_EVENTS.UPDATE_CLOSED_EXPRESSES);
  }

  // ------------------------------------------------------------------------
  //  PARSING des réponses serveur
  // ------------------------------------------------------------------------

  private bindTransportEvents(): void {
    this.transport.on('event', (event: string, args: unknown[]) => {
      switch (event) {
        case 'successopenOrder':
          this.handleSuccessOpenOrder(args);
          break;
        case 'failopenOrder':
          this.handleFailOpenOrder(args);
          break;
        case 'successcloseOrder':
          // Le client principal émettra `deal_closed` à partir de ça.
          break;
        case 'updateOpenedDeals':
          // Le client principal émettra `deal_opened` (×N).
          break;
        case 'updateClosedDeals':
          // Le client principal émettra `deal_closed` (×N).
          break;
      }
    });
  }

  /** Parse un deal ouvert depuis le payload serveur. */
  static parseOpenedDeal(raw: unknown): OpenedDeal | null {
    if (!raw || typeof raw !== 'object') return null;
    const r = raw as Record<string, unknown>;
    // Helper local: Number() qui renvoie 0 au lieu de NaN (Number(undefined)=NaN, Number("xyz")=NaN).
    // Sans ça, openTime/expireTime/amount peuvent être NaN côté frontend → keys React comme "deal-NaN-ETHUSD_otc".
    const safeNum = (v: unknown): number => {
      const n = Number(v);
      return Number.isFinite(n) ? n : 0;
    };
    // L'ID peut être un UUID string (deals récents) ou un number.
    // IMPORTANT: ne JAMAIS faire Number(uuid) → NaN, sinon tous les deals ont id=NaN
    // et le frontend React voit des key="NaN" dupliqués (erreur "two children with same key NaN").
    const rawId = r.id ?? r.orderId ?? r.dealId ?? r.deal_id;
    const id: number | string = typeof rawId === 'string'
      ? rawId
      : (typeof rawId === 'number' && Number.isFinite(rawId) ? rawId : 0);
    // FORMAT NATIF PO (capture 2026-09-17) : `command` (0 = CALL, 1 = PUT)
    // remplace `action` ; openTime/closeTime sont des STRINGS datetime →
    // utiliser openTimestamp/closeTimestamp (secondes Unix fiables).
    // Sans openTime réel, l'EMPREINTE du deal suivi (rattachement des
    // règlements par le backend) perd ses fenêtres temporelles et des deals
    // fantômes du cache broker peuvent être rattachés par erreur.
    const nativeCommand = Number(r.command ?? NaN);
    const action: OrderAction = nativeCommand === 1
      ? 'put'
      : nativeCommand === 0
        ? 'call'
        : ((r.action as OrderAction | undefined) ?? 'call');
    // openTime: essayer plusieurs noms de champs possibles, jamais NaN.
    // Le serveur PO utilise parfois `openAt`, `createdAt`, `created_at`, `time` selon le payload.
    const rawOpenTime = r.openTimestamp ?? r.openTime ?? r.open_time ?? r.openAt ?? r.open_at
      ?? r.createdAt ?? r.created_at ?? r.created ?? r.time ?? r.timestamp ?? 0;
    const rawExpireTime = r.closeTimestamp ?? r.expireTime ?? r.expire_time ?? r.expiredAt ?? r.expired_at
      ?? r.expire ?? r.expiresAt ?? r.expires_at ?? r.closeTime ?? r.close_time ?? 0;
    return {
      id,
      asset: String(r.asset ?? r.symbol ?? ''),
      action,
      amount: safeNum(r.amount ?? 0),
      openPrice: safeNum(r.openPrice ?? r.open_price ?? r.price ?? 0),
      openTime: safeNum(rawOpenTime),
      expireTime: safeNum(rawExpireTime),
      time: safeNum(r.time ?? r.expire ?? 0),
      optionType: (r.optionType ?? 100) as OptionType,
      isDemo: (r.isDemo ?? 0) as 0 | 1,
      requestId: r.requestId ? safeNum(r.requestId) : undefined,
      raw: r,
    };
  }

  /**
   * Secondes Unix depuis un champ payload : accepte un nombre (unix s ou ms)
   * ou une string de chiffres ; les strings datetime ("2026-09-17 19:09:06",
   * fuseau broker ≠ UTC) et les valeurs absentes donnent 0.
   * CAPTURE RÉELLE 2026-09-17 : le broker natif porte openTime/closeTime en
   * STRINGS datetime + openTimestamp/closeTimestamp en secondes Unix — seuls
   * les timestamps sont fiables (la string est en heure locale broker).
   */
  private static toUnixSeconds(value: unknown): number {
    if (typeof value === 'number' && Number.isFinite(value) && value > 0) {
      return value > 1e12 ? Math.floor(value / 1000) : value;
    }
    if (typeof value === 'string' && /^\d{9,13}$/.test(value.trim())) {
      const n = Number(value);
      return n > 1e12 ? Math.floor(n / 1000) : n;
    }
    return 0;
  }

  /** Parse un deal clôturé depuis le payload serveur. */
  static parseClosedDeal(raw: unknown): ClosedDeal | null {
    if (!raw || typeof raw !== 'object') return null;
    const r = raw as Record<string, unknown>;
    const profit = Number(r.profit ?? r.winAmount ?? 0);
    const amount = Number(r.amount ?? 0);
    // L'ID peut être un UUID string (deals clôturés) ou un number
    const rawId = r.id ?? r.orderId ?? r.dealId ?? r.deal_id;
    const id: number | string = typeof rawId === 'string' ? rawId : Number(rawId ?? 0);
    // FORMAT NATIF PO (capture 2026-09-17) : pas de champ `action`, mais
    // `command` (0 = CALL, 1 = PUT). Les horodatages fiables sont
    // openTimestamp/closeTimestamp (Unix) — openTime/closeTime sont des
    // strings datetime dont Number() = NaN (brisait le matcher d'empreinte
    // du backend : fenêtres temporelles vides → deals fantômes du cache
    // broker rattachés par erreur à des ordres suivis).
    const nativeCommand = Number(r.command ?? NaN);
    const action: OrderAction = nativeCommand === 1
      ? 'put'
      : nativeCommand === 0
        ? 'call'
        : ((r.action as OrderAction | undefined) ?? 'call');
    const openTime = TradingApi.toUnixSeconds(r.openTimestamp) || TradingApi.toUnixSeconds(r.openTime) || Number(r.openTime ?? r.open_time ?? 0) || 0;
    const closeTime = TradingApi.toUnixSeconds(r.closeTimestamp) || TradingApi.toUnixSeconds(r.closeTime) || Number(r.closeTime ?? r.close_time ?? 0) || 0;
    return {
      id,
      asset: String(r.asset ?? r.symbol ?? ''),
      action,
      amount,
      openPrice: Number(r.openPrice ?? r.open_price ?? r.openQuote ?? 0),
      closePrice: Number(r.closePrice ?? r.close_price ?? r.closeQuote ?? 0),
      openTime,
      closeTime,
      profit,
      isWin: profit > 0 || (profit === 0 && Boolean(r.isWin)),
      isDemo: (r.isDemo ?? 0) as 0 | 1,
      raw: r,
    };
  }

  private handleSuccessOpenOrder(args: unknown[]): void {
    const data = (args[0] ?? {}) as Record<string, unknown>;
    const requestId = Number(data.requestId ?? 0);
    const pending = this.pendingOrders.get(requestId);
    if (!pending) {
      this.logger.debug('successopenOrder: no pending order for requestId=', requestId);
      return;
    }
    clearTimeout(pending.timer);
    this.pendingOrders.delete(requestId);
    const deal = TradingApi.parseOpenedDeal(data.deal ?? data);
    // BUG FIX: The server's successopenOrder response does NOT include the `action` field.
    // It defaults to 'call' in parseOpenedDeal, which causes PUT orders to be logged as CALL.
    // This cascades to: wrong lastTradeAction → wrong algo performance tracking → fake 100% winRate.
    // Fix: use the action from the pending order (the action we actually requested).
    if (deal && pending.action) {
      deal.action = pending.action;
    }
    const result: OpenOrderResult = {
      success: true,
      requestId,
      deal: deal ?? undefined,
      raw: data,
    };
    pending.resolve(result);
    this.logger.info(
      `successopenOrder: requestId=${requestId} dealId=${deal?.id} action=${deal?.action}`,
    );
  }

  private handleFailOpenOrder(args: unknown[]): void {
    const data = (args[0] ?? {}) as Record<string, unknown>;
    const requestId = Number(data.requestId ?? 0);
    const pending = this.pendingOrders.get(requestId);
    if (!pending) {
      this.logger.debug('failopenOrder: no pending order for requestId=', requestId);
      return;
    }
    clearTimeout(pending.timer);
    this.pendingOrders.delete(requestId);
    const errorMsg = String(data.message ?? data.error ?? data.reason ?? 'Unknown error');
    const result: OpenOrderResult = {
      success: false,
      requestId,
      error: errorMsg,
      raw: data,
    };
    pending.resolve(result);
    this.logger.warn(
      `failopenOrder: requestId=${requestId} error=${errorMsg}`,
    );
  }
}
