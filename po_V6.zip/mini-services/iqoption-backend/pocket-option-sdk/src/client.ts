/**
 * @file client.ts
 * @description Client principal Pocket Option.
 *
 * Orchestre :
 *  1. L'authentification HTTP (login mobile + détection IP + session PHP)
 *  2. Le transport WebSocket Socket.IO v4 (reconnexion, heartbeat, latence)
 *  3. Les sous-modules API :
 *     - MarketDataApi (actifs, prix, historique, chandeliers temps réel)
 *     - TradingApi (ordres CALL/PUT, express, copy signals)
 *     - AccountApi (balances, deals, charts, indicators)
 *     - SignalsApi (signaux de trading)
 *  4. Le dispatch des events serveur vers les handlers typés du SDK
 *
 * Usage type :
 *
 *   const client = new PocketOptionClient({
 *     credentials: { email: '...', password: '...' },
 *     mode: 'demo',
 *     debug: true,
 *   });
 *   await client.connect();
 *   client.on('authenticated', () => {
 *     client.market.subscribe('EURUSD_otc');
 *     client.market.changeSymbol('EURUSD_otc', 60);
 *     client.trading.call('EURUSD_otc', 1, 60).then(console.log);
 *   });
 *   client.on('stream', (updates) => console.log(updates));
 *   client.on('balance', (b) => console.log('balance:', b.balance));
 */

import { authenticate, buildSessionData } from './auth';
import { RawSocketIoTransport } from './transport/raw-socketio-transport';
import type { LaneStats } from './transport/raw-socketio-transport';
import { MarketDataApi } from './api/market-data';
import { TradingApi } from './api/trading-api';
import { AccountApi } from './api/account-api';
import { SignalsApi } from './api/signals-api';
import { Logger } from './utils/logger';
import { TypedEmitter } from './utils/typed-emitter';
import { URLS, DEFAULTS, ERROR_CODES, TIMINGS, MAIN_SERVERS, DEMO_SERVERS, CLIENT_EVENTS } from './constants';
import type {
  PocketOptionClientOptions,
  PocketOptionEvents,
  SessionData,
  ConnectionState,
  AccountMode,
  ServerRegion,
  LatencySample,
  StreamUpdate,
  Candle,
  AssetsMap,
  BalanceUpdate,
  OpenedDeal,
  ClosedDeal,
  OpenOrderResult,
  TradingSignal,
  SocialTrade,
  HistoryPeriod,
  HistoryTick,
} from './types';


function parseSocialTradeEvent(raw: unknown): SocialTrade | null {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  const id = String(r.id ?? '').trim();
  const uid = Number(r.uid ?? 0);
  const asset = String(r.asset ?? r.symbol ?? '').trim();
  const command = Number(r.command ?? -1);
  if (!id || !Number.isFinite(uid) || uid <= 0 || !asset || (command !== 0 && command !== 1)) return null;
  return {
    id,
    uid,
    asset,
    direction: command === 0 ? 'call' : 'put',
    amount: Number(r.amount ?? 0),
    openTime: Number(r.openTimestamp ?? r.openTime ?? 0),
    closeTime: r.closeTimestamp == null ? undefined : Number(r.closeTimestamp),
    openPrice: Number(r.openPrice ?? 0),
    closePrice: r.closePrice == null ? undefined : Number(r.closePrice),
    profit: r.profit == null ? undefined : Number(r.profit),
    percentProfit: r.percentProfit == null ? undefined : Number(r.percentProfit),
    isDemo: r.isDemo == null ? undefined : Number(r.isDemo),
    nickname: r.nickname == null ? undefined : String(r.nickname),
    avatarUser: r.avatarUser == null ? undefined : String(r.avatarUser),
    currency: r.currency == null ? undefined : String(r.currency),
    raw,
  };
}

export class PocketOptionClient extends TypedEmitter<PocketOptionEvents> {
  public readonly market: MarketDataApi;
  public readonly trading: TradingApi;
  public readonly account: AccountApi;
  public readonly signals: SignalsApi;

  /** Force Pocket Option to resend recent closed deals. */
  public refreshClosedDeals(): boolean {
    return this.transport.send(CLIENT_EVENTS.UPDATE_CLOSED_DEALS, {});
  }

  private options: Omit<Required<PocketOptionClientOptions>, 'session' | 'ipAddress' | 'encryptionKey'> &
    Pick<PocketOptionClientOptions, 'session' | 'ipAddress' | 'encryptionKey'>;
  private logger: Logger;
  private transport: RawSocketIoTransport;
  private session: SessionData | null = null;
  private state: ConnectionState = 'disconnected';
  private demoSessionId: string | undefined;
  private fetchImpl: typeof fetch;
  /** Anti-expiration : évite de réutiliser indéfiniment une session HTTP vieillissante. */
  private lastAuthRefreshAt = 0;
  private authRefreshInFlight: Promise<void> | null = null;

  constructor(options: PocketOptionClientOptions) {
    super();
    // Merge options with defaults. Keep `session`, `ipAddress`, `encryptionKey`
    // optional (they may be undefined).
    type ResolvedOptions = Omit<Required<PocketOptionClientOptions>, 'session' | 'ipAddress' | 'encryptionKey'> &
      Pick<PocketOptionClientOptions, 'session' | 'ipAddress' | 'encryptionKey'>;
    this.options = {
      mode: 'demo',
      region: 'eu',
      platform: DEFAULTS.PLATFORM,
      lang: DEFAULTS.LANG,
      userAgent: DEFAULTS.USER_AGENT,
      debug: false,
      reconnectDelay: TIMINGS.RECONNECT_BASE_DELAY,
      maxReconnectAttempts: 0,
      authTimeout: TIMINGS.AUTH_TIMEOUT,
      isFastHistory: DEFAULTS.IS_FAST_HISTORY,
      isOptimized: DEFAULTS.IS_OPTIMIZED,
      session: undefined,
      ipAddress: undefined,
      encryptionKey: undefined,
      ...options,
    } as ResolvedOptions;

    this.logger = new Logger(
      'PO-Client',
      this.options.debug ? 'debug' : 'silent',
    );
    this.fetchImpl = fetch;

    // Transport RawSocketIo : bypass la détection anti-bot de Pocket Option
    // (socket.io-client est détecté et déconnecté immédiatement après le handshake).
    // On passe une LISTE d'URLs pour activer le failover multi-serveurs
    // (en mode réel, le Python essaie api-msk, api-spb, api-eu, api-us-south,
    // api-us-north jusqu'à trouver un qui répond).
    // La liste sera mise à jour avec `cabinet.servers` après le fetch cabinet.
    this.transport = new RawSocketIoTransport({
      urls: this.resolveWsUrls(),
      authPayload: () => this.buildAuthPayload(),
      logger: this.logger,
      userAgent: this.options.userAgent,
      origin: URLS.WEB,
      reconnectDelay: this.options.reconnectDelay,
      maxReconnectAttempts: this.options.maxReconnectAttempts,
      enablePsHeartbeat: true,
      beforeReconnect: () => this.refreshAuthBeforeReconnect(),
      timeout: 30000,
      connectAttempts: 5,
    });

    this.market = new MarketDataApi(this.transport, this.logger);
    this.trading = new TradingApi(this.transport, this.logger);
    this.account = new AccountApi(this.transport, this.logger, this.fetchImpl);
    this.signals = new SignalsApi(this.transport, this.logger);

    this.trading.setMode(this.options.mode === 'demo');
    this.bindTransportEvents();
  }

  // ------------------------------------------------------------------------
  //  LIFECYCLE
  // ------------------------------------------------------------------------

  /**
   * Connexion complète :
   *  1. Login HTTP (POST pomob-api.com/api/webview/login) -> uid, token, secret, ci_session
   *  2. Fetch cabinet (GET m.pocketoption.com/en/cabinet?token=...) -> ci_session frais + servers + demo_balance
   *  3. URL-décodage du ci_session (comportement js-cookie du navigateur)
   *  4. Connexion WebSocket (demo-api-eu.po.market en démo, api-*.po.market en réel)
   *  5. Authentification WS (envoi de l'event `auth` avec la session ci_session)
   *
   * En MODE DÉMO : la session envoyée au WS est le `demoSessionId` (PHPSESSID
   * court de 26 chars partagé par tous les utilisateurs démo).
   * Override possible via `client.setDemoSessionId(...)`.
   *
   * En MODE RÉEL : la session envoyée au WS est le ci_session URL-décodé
   * récupéré depuis le cabinet.
   *
   * Si `options.session` est fournie, le login HTTP et le fetch cabinet sont
   * skip et la session fournie est utilisée directement (utile pour rejouer
   * une session existante).
   *
   * Résout quand l'event `successauth` est reçu du serveur.
   */
  async connect(): Promise<SessionData> {
    this.setState('connecting');

    // 1. Login HTTP (ou réutilisation d'une session pré-construite)
    if (this.options.session) {
      this.logger.info('Reusing provided session (bypassing HTTP login)');
      this.session = this.options.session;
    } else {
      this.logger.info('Connecting: performing HTTP login + fetch cabinet...');
      const { loginResult, cabinet, session: ciSession } = await authenticate({
        credentials: this.options.credentials,
        userAgent: this.options.userAgent,
        lang: this.options.lang,
        logger: this.logger,
        fetchImpl: this.fetchImpl,
      });
      this.session = buildSessionData(loginResult, ciSession);
      this.lastAuthRefreshAt = Date.now();
      if (cabinet) {
        this.session.servers = cabinet.servers;
        this.session.demoBalance = cabinet.demoBalance;
        this.session.currency = cabinet.currency;
        // En mode démo, l'uid peut venir du cabinet (différent du login uid)
        if (cabinet.uid && this.options.mode === 'demo') {
          this.session.uid = cabinet.uid;
        }
        /**
         * Si le cabinet a renvoyé une `servers-list` (liste de serveurs réels
         * ordonnée par géo IP), on met à jour la liste d'URLs du transport
         * pour privilégier ces serveurs en mode RÉEL.
         *
         * Le projet Python fait : `servers = cabinet.servers or MAIN_SERVERS`.
         * On reproduit : si cabinet.servers est non vide, on l'utilise ;
         * sinon on garde la liste par défaut (MAIN_SERVERS).
         */
        if (this.options.mode === 'real' && cabinet.servers && cabinet.servers.length > 0) {
          const suffix = '/socket.io/?EIO=4&transport=websocket';
          const urls = cabinet.servers.map((s) => s + suffix);
          this.logger.info(
            'Using cabinet servers-list (' + urls.length + ' serveurs) pour le mode réel',
          );
          this.transport.setUrls(urls);
        }
      }
      /**
       * En MODE DÉMO, on utilise le demoSessionId partagé `769eh8u56arbkqtpsf9t0dnh67`
       * (vu dans le HAR capturé et dans le projet Python de référence). Ce
       * demoSessionId est un PHPSESSID court qui fonctionne pour tous les
       * utilisateurs démo — le serveur l'accepte et renvoie successauth +
       * successupdateBalance + updateAssets + updateClosedDeals, etc.
       *
       * Le `ci_session` du cabinet fonctionne aussi en mode démo MAIS le
       * serveur ne renvoie QUE `updateAssets` (pas de successauth/balance).
       * C'est pourquoi on doit utiliser le demoSessionId partagé en mode démo.
       *
       * Override possible via `client.setDemoSessionId(...)`.
       */
      if (this.options.mode === 'demo' && !this.demoSessionId) {
        this.demoSessionId = DEFAULTS.DEFAULT_DEMO_SESSION_ID;
      }
    }

    // 2. Connect WS (async — RawSocketIoTransport fait le handshake + recv loop)
    this.logger.info('Connecting WebSocket...', this.resolveWsUrl());
    // On lance connect() sans attendre (la résolution se fait sur `successauth`)
    void this.transport.connect();

    // 3. Wait for `successauth` (with timeout)
    return new Promise<SessionData>((resolve, reject) => {
      const timer = setTimeout(() => {
        reject(new Error(`${ERROR_CODES.AUTH_TIMEOUT}: no successauth after ${this.options.authTimeout}ms`));
      }, this.options.authTimeout);

      const onAuth = (s: SessionData) => {
        clearTimeout(timer);
        resolve(s);
      };
      const onFail = (err: Error) => {
        clearTimeout(timer);
        reject(err);
      };
      this.once('authenticated', onAuth);
      this.once('auth_failed', onFail);
    });
  }

  /**
   * Rafraîchit l'authentification HTTP avant une reconnexion automatique
   * lorsque la session a vieilli. Le mode démo garde son demoSessionId
   * stable et n'effectue donc pas de login HTTP inutile.
   *
   * Cette protection cible notamment les déconnexions silencieuses observées
   * après ~2 minutes : le transport reconnecte alors avec une session fraîche
   * au lieu de boucler avec une session broker devenue invalide.
   */
  private async refreshAuthBeforeReconnect(): Promise<void> {
    if (this.options.mode === 'demo') return;
    if (this.options.session) return;
    if (!this.options.credentials) return;

    const now = Date.now();
    // Une reconnexion rapprochée ne doit pas déclencher une rafale de logins HTTP.
    if (now - this.lastAuthRefreshAt < 60_000) return;
    if (this.authRefreshInFlight) return this.authRefreshInFlight;

    this.authRefreshInFlight = (async () => {
      this.logger.info('Refreshing HTTP authentication before broker reconnect...');
      const { loginResult, cabinet, session: ciSession } = await authenticate({
        credentials: this.options.credentials,
        userAgent: this.options.userAgent,
        lang: this.options.lang,
        logger: this.logger,
        fetchImpl: this.fetchImpl,
      });
      const refreshed = buildSessionData(loginResult, ciSession);
      if (cabinet) {
        refreshed.servers = cabinet.servers;
        refreshed.demoBalance = cabinet.demoBalance;
        refreshed.currency = cabinet.currency;
        if (cabinet.uid && this.options.mode === 'demo') refreshed.uid = cabinet.uid;
        if (this.options.mode === 'real' && cabinet.servers?.length) {
          const suffix = '/socket.io/?EIO=4&transport=websocket';
          this.transport.setUrls(cabinet.servers.map((server) => server + suffix));
        }
      }
      this.session = refreshed;
      this.lastAuthRefreshAt = Date.now();
      this.logger.info(`HTTP authentication refreshed for reconnect (uid=${refreshed.uid})`);
    })().finally(() => {
      this.authRefreshInFlight = null;
    });

    return this.authRefreshInFlight;
  }

  /** Ferme la connexion. */
  disconnect(): void {
    this.transport.disconnect();
    this.setState('disconnected');
  }

  /** Détruit le client (libère toutes les ressources). */
  destroy(): void {
    this.transport.destroy();
    this.removeAllListeners();
    this.setState('disconnected');
  }

  // ------------------------------------------------------------------------
  //  ACCESSORS
  // ------------------------------------------------------------------------

  /** État de la connexion. */
  getState(): ConnectionState {
    return this.state;
  }

  /** Session courante (null si pas encore authentifié). */
  getSession(): SessionData | null {
    return this.session;
  }

  /**
   * Retourne l'URL du serveur actuellement connecté (null si pas connecté).
   * En mode réel avec failover multi-serveurs, permet de savoir quel serveur
   * a répondu (par exemple `wss://api-eu.po.market/socket.io/?EIO=4&...`).
   */
  getConnectedServer(): string | null {
    return this.transport.getConnectedServer();
  }

  /** Retourne la liste des serveurs configurés (pour failover). */
  getConfiguredServers(): string[] {
    return this.transport.getUrls();
  }

  /** Active l'option Social Trading côté cabinet, comme le fait le client web.
   * Le HAR montre GET /en/cabinet/save-var?key=enabled_social&value=1 avant
   * l'abonnement WebSocket. Sans ce flag, le flux social peut rester vide.
   */
  async enableSocialTradingMonitoring(): Promise<boolean> {
    const session = this.session;
    if (!session?.serializedSession) return false;
    try {
      const cookie = `ci_session=${encodeURIComponent(session.serializedSession)}`;
      const res = await this.fetchImpl(
        `${URLS.WEB}/${this.options.lang || 'en'}/cabinet/save-var?key=enabled_social&value=1`,
        {
          method: 'GET',
          headers: {
            'Cookie': cookie,
            'X-Requested-With': 'XMLHttpRequest',
            'User-Agent': this.options.userAgent,
            'Accept': '*/*',
            'Referer': `${URLS.WEB}/${this.options.lang || 'en'}/cabinet`,
          },
        },
      );
      return res.ok;
    } catch {
      return false;
    }
  }

  /**
   * Souscrit au flux social global observé dans carnet.har.
   * showOnlyWatched=false est volontaire : le monitoring n'est PAS limité au Top-24.
   */
  subscribeSocialOrderFlow(symbols: string[]): boolean {
    const clean = [...new Set(symbols.map((s) => String(s).trim()).filter(Boolean))];
    if (!clean.length) return false;
    return this.transport.send('sto', { showOnlyWatched: false, symbols: clean });
  }

  /** Met à jour les symboles du flux social sans réinitialiser le mode global. */
  updateSocialTradingSymbols(symbols: string[]): boolean {
    const clean = [...new Set(symbols.map((s) => String(s).trim()).filter(Boolean))];
    if (!clean.length) return false;
    return this.transport.send('sts', { symbols: clean });
  }

  /** Mode courant (demo / real). */
  getMode(): AccountMode {
    return this.options.mode;
  }

  /**
   * Change le mode (demo / real). Nécessite une RECONNEXION pour prendre effet :
   *
   * ```ts
   * client.setMode('real');
   * await client.connect(); // reconnecte en mode réel
   * ```
   *
   * En mode réel, le SDK utilisera :
   *  - `cabinet.servers` (si disponible) comme liste de serveurs prioritaires
   *  - sinon `MAIN_SERVERS` (api-msk, api-spb, api-eu, api-us-south, api-us-north)
   *  - essaie chaque serveur séquentiellement jusqu'à trouver un qui répond
   *  - envoie `isDemo: 0` dans l'event `auth`
   *  - utilise le `ci_session` du cabinet (pas le demoSessionId)
   *  - utilise `login_result.uid` (pas cabinet.uid)
   */
  setMode(mode: AccountMode): void {
    this.options.mode = mode;
    this.trading.setMode(mode === 'demo');
    // Met à jour la liste d'URLs du transport selon le nouveau mode
    this.transport.setUrls(this.resolveWsUrls());
  }

  /** Région courante. */
  getRegion(): ServerRegion {
    return this.options.region;
  }

  /** Statistiques de latence RTT. */
  getLatency() {
    return this.transport.getLatency();
  }

  /**
   * Statistiques des voies de traitement (dual-lane dispatch market/social) :
   * files en attente, events traités, coalescence/overflow (§13 backpressure).
   * Diagnostic tunnels — cf. raw-socketio-transport.ts.
   */
  getLaneStats(): LaneStats[] {
    return this.transport.getLaneStats();
  }

  /** Définit une session démo courte (PHPSESSID de 26 chars). */
  setDemoSessionId(sessionId: string): void {
    this.demoSessionId = sessionId;
  }

  // ------------------------------------------------------------------------
  //  INTERNALS
  // ------------------------------------------------------------------------

  /**
   * Construit la liste initiale des URLs WebSocket à essayer (failover).
   *
   * - Mode DÉMO : `DEMO_SERVERS` (un seul serveur `wss://demo-api-eu.po.market`).
   * - Mode RÉEL : `MAIN_SERVERS` (5 serveurs : msk, spb, eu, us-south, us-north).
   *   On ajoute le suffixe `/socket.io/?EIO=4&transport=websocket` à chaque URL.
   *
   * Après le fetch cabinet, `client.connect()` met à jour cette liste via
   * `transport.setUrls(...)` si le cabinet a renvoyé une `servers-list`
   * (potentiellement ordonnée par géo IP, plus proche de l'utilisateur).
   */
  private resolveWsUrls(): string[] {
    const suffix = '/socket.io/?EIO=4&transport=websocket';
    if (this.options.mode === 'demo') {
      return [...DEMO_SERVERS].map((s) => s + suffix);
    }
    // Mode réel : tous les serveurs principaux
    return [...MAIN_SERVERS].map((s) => s + suffix);
  }

  /** @deprecated Utilisez `resolveWsUrls()` (retourne une liste pour failover). */
  private resolveWsUrl(): string {
    return this.resolveWsUrls()[0];
  }

  private buildAuthPayload(): Record<string, unknown> {
    if (!this.session) {
      throw new Error(`${ERROR_CODES.NOT_AUTHENTICATED}: no session, call connect() first`);
    }
    /**
     * Session envoyée au WS :
     *
     * Historiquement, le projet Python utilisait un `demoSessionId` partagé
     * (`769eh8u56arbkqtpsf9t0dnh67`) en mode démo, et le `ci_session` du
     * cabinet en mode réel.
     *
     * Mais ce `demoSessionId` partagé finit par expirer. En pratique, le
     * `ci_session` du cabinet fonctionne AUSSI en mode démo (avec `isDemo: 1`),
     * c'est ce que le HAR capturé montre (l'app Android envoie `session:
     * "769eh8u56arbkqtpsf9t0dnh67"` qui est un PHPSESSID obtenu depuis un
     * cookie cabinet précédent).
     *
     * Donc : par défaut on envoie le `ci_session` du cabinet (URL-décodé).
     * Si l'utilisateur fournit explicitement un `demoSessionId` via
     * `setDemoSessionId(...)`, on l'utilise à la place.
     */
    const sessionStr =
      this.options.mode === 'demo' && this.demoSessionId
        ? this.demoSessionId
        : this.session.serializedSession;
    return {
      session: sessionStr,
      isDemo: this.options.mode === 'demo' ? 1 : 0,
      uid: this.session.uid,
      platform: this.options.platform,
      isFastHistory: this.options.isFastHistory,
      isOptimized: this.options.isOptimized,
    };
  }

  private setState(state: ConnectionState): void {
    if (this.state === state) return;
    this.state = state;
    this.emit('state_changed', state);
  }

  // ------------------------------------------------------------------------
  //  TRANSPORT EVENT BINDING
  // ------------------------------------------------------------------------

  private bindTransportEvents(): void {
    this.transport.on('state', (state) => {
      this.setState(state);
    });

    this.transport.on('connect', () => {
      this.emit('connected');
    });

    this.transport.on('disconnect', (reason) => {
      this.emit('disconnected', reason);
    });

    this.transport.on('reconnect_attempt', (attempt) => {
      this.emit('reconnecting', attempt);
    });

    this.transport.on('error', (err) => {
      this.emit('error', err);
    });

    this.transport.on('pong', (sample: LatencySample) => {
      this.emit('latency', sample);
    });

    this.transport.on('event', (event: string, args: unknown[]) => {
      this.dispatchServerEvent(event, args);
    });
  }

  /**
   * Dispatch des events serveur vers les handlers typés du SDK.
   * Le dispatch est centralisé ici pour émettre les events publics
   * (stream, balance, deal_opened, etc.) en plus du dispatch spécifique
   * aux sous-modules (qui se fait dans leurs propres bindTransportEvents).
   */
  private dispatchServerEvent(event: string, args: unknown[]): void {
    // Toujours émettre l'event brut
    this.emit('raw', event, ...args);

    switch (event) {
      case 'successauth':
        // L'authentification a réussi : on notifie et on demande les données initiales
        if (this.session) {
          this.setState('authenticated');
          this.emit('authenticated', this.session);
          this.requestInitialData();
        }
        break;
      case 'failauth': {
        const err = new Error(`${ERROR_CODES.AUTH_FAILED}: ${JSON.stringify(args[0] ?? {})}`);
        this.emit('auth_failed', err);
        this.emit('error', err);
        break;
      }
      case 'updateStream': {
        const updates = MarketDataApi.parseStreamUpdate(args[0]);
        if (updates.length > 0) this.emit('stream', updates);
        break;
      }
      case 'updateHistoryNewFast': {
        // FORMAT RÉEL (validé sur fix_gaps.har — mode démo ET réel, Pocket
        // Option pousse ce snapshot APRÈS chaque `changeSymbol`) :
        //   { asset, period, history: [[time, price], ...] }
        //   → ~1300-1600 TICKS couvrant ~12 minutes, DERNIER tick CONTIGU
        //     (< 1 s) avec le premier tick `updateStream` qui suit.
        // Ce sont des TICKS [timestamp_sous_seconde, prix] (2 éléments) et
        // NON des bougies OHLC — l'ancien parser cherchait `candles/bars/
        // data` (jamais présents) → le snapshot rapide était PERDU → le
        // backend ne disposait que de la pagination `loadHistoryPeriod`
        // (lente, ~150 bougies/batch) → trous géants historique↔live en
        // multi-assets → CRITICAL_GAP / TRADING BLOQUÉ sur 24 assets.
        const data = (args[0] ?? {}) as Record<string, unknown>;
        const asset = String(data.asset ?? data.symbol ?? '');
        const period = Number(data.period ?? data.timeframe ?? 0);
        const historyRaw = data.history;
        if (asset && period && Array.isArray(historyRaw)) {
          const ticks: HistoryTick[] = [];
          for (const item of historyRaw) {
            if (
              Array.isArray(item) && item.length >= 2 &&
              typeof item[0] === 'number' && Number.isFinite(item[0]) &&
              typeof item[1] === 'number' && Number.isFinite(item[1]) && item[1] > 0
            ) {
              ticks.push({ time: item[0] as number, price: item[1] as number });
            }
          }
          if (ticks.length > 0) {
            // Les ticks sont PÉRIODE-AGNOSTIQUES : le consommateur les
            // fusionne dans son buffer canonique et ré-agrège TOUS ses
            // timeframes (S5/S30/M1/M5) depuis la même chronologie.
            this.emit('history_ticks', asset, period, ticks);
            break;
          }
        }
        // Rétro-compat : format OHLC (candles/bars/data) si le broker
        // change de format un jour.
        const candlesRaw = data.candles ?? data.bars ?? data.data;
        if (asset && period && Array.isArray(candlesRaw)) {
          const candles = MarketDataApi.parseCandles(candlesRaw);
          if (candles.length > 0) {
            this.emit('candles_update', asset, period, candles);
          }
        }
        break;
      }
      case 'chafor': {
        // Bougies temps réel du symbole ACTIF (format OHLC). Le client
        // principal émet `candles_update` — inchangé.
        const data = (args[0] ?? {}) as Record<string, unknown>;
        const asset = String(data.asset ?? data.symbol ?? '');
        const period = Number(data.period ?? data.timeframe ?? 0);
        const candlesRaw = data.candles ?? data.bars ?? data.data;
        if (asset && period && Array.isArray(candlesRaw)) {
          const candles = MarketDataApi.parseCandles(candlesRaw);
          if (candles.length > 0) {
            this.emit('candles_update', asset, period, candles);
          }
        }
        break;
      }
      case 'updateAssets': {
        // Le handler interne de MarketDataApi a déjà mis à jour le cache.
        const assets = this.market.getAssets();
        if (Object.keys(assets).length > 0) {
          this.emit('assets', assets);
        }
        break;
      }
      case 'successupdateBalance': {
        // AccountApi a déjà mis à jour le cache.
        const b = this.account.getBalances();
        const balance = this.account.getCurrentBalance();
        const update: BalanceUpdate = {
          isDemo: this.options.mode === 'demo' ? 1 : 0,
          balance,
          balances: b,
        };
        this.emit('balance', update);
        break;
      }
      case 'updateOpenedDeals': {
        const deals = this.account.getOpenedDeals();
        for (const d of deals) this.emit('deal_opened', d);
        break;
      }
      case 'updateClosedDeals': {
        const deals = this.account.getClosedDeals();
        for (const d of deals) this.emit('deal_closed', d);
        break;
      }
      case 'successopenOrder':
      case 'failopenOrder': {
        // TradingApi a déjà résolu la promesse. On émet aussi l'event public.
        const data = (args[0] ?? {}) as Record<string, unknown>;
        const deal = TradingApi.parseOpenedDeal(data.deal ?? data);
        // BUG FIX: server doesn't echo `action` — preserve from the order request if available.
        // The TradingApi already fixed this in handleSuccessOpenOrder, but the client also
        // parses independently here. We need to match by requestId to get the correct action.
        if (deal && !data.action && !((data.deal as any)?.action)) {
          // Try to find the action from the trading API's pending orders
          const requestId = Number(data.requestId ?? 0);
          const pendingAction = this.trading.getPendingAction(requestId);
          if (pendingAction) {
            deal.action = pendingAction;
          }
        }
        const result: OpenOrderResult = {
          success: event === 'successopenOrder',
          requestId: Number(data.requestId ?? 0),
          deal: deal ?? undefined,
          error: event === 'failopenOrder' ? String(data.message ?? data.error ?? 'Unknown') : undefined,
          raw: data,
        };
        this.emit('order_result', result);
        if (result.success && result.deal) {
          this.emit('deal_opened', result.deal);
        }
        break;
      }
      case 'successcloseOrder': {
        const data = (args[0] ?? {}) as Record<string, unknown>;
        // CAPTURE RÉELLE 2026-09-17 (broker PO démo, identifiants par défaut) :
        // chaque règlement est publié sous la forme
        //   { "profit": <retour TOTAL (mise + gain), 0 si perte>,
        //     "deals": [ { id: <UUID>, asset, amount, profit: <NET>,
        //                  openPrice, closePrice, command, openTimestamp,
        //                  closeTimestamp, ... } ] }
        // Le deal réel vit dans data.deals[0]. L'ancienne lecture
        // `data.deal ?? data` parsait l'ENVELOPPE (sans id ni asset) →
        // ClosedDeal { id: 0, asset: '', profit: retour total } → le backend
        // ne pouvait JAMAIS attribuer le règlement à un ordre suivi → la
        // Martingale n'avançait plus (bug « les ordres continuent de
        // s'enchaîner sur la mise de base »).
        const rawDeal = Array.isArray(data.deals) && data.deals.length > 0
          ? data.deals[0]
          : (data.deal ?? data);
        const deal = TradingApi.parseClosedDeal(rawDeal);
        if (deal) this.emit('deal_closed', deal);
        break;
      }
      case 'updateOpenedSocialDeals': {
        const list = Array.isArray(args[0]) ? args[0] : [args[0]];
        const trades = list.map(parseSocialTradeEvent).filter(Boolean) as SocialTrade[];
        if (trades.length) this.emit('social_opened', trades);
        break;
      }
      case 'updateClosedSocialDeals': {
        const list = Array.isArray(args[0]) ? args[0] : [args[0]];
        const trades = list.map(parseSocialTradeEvent).filter(Boolean) as SocialTrade[];
        if (trades.length) this.emit('social_closed', trades);
        break;
      }
      case 'signals/update':
      case 'signals/load': {
        // SignalsApi a déjà mis à jour le cache. On émet pour les subscribers.
        const data = args[0];
        const list = Array.isArray(data) ? data : [data];
        for (const raw of list) {
          const sig = SignalsApi.parseSignal(raw);
          if (sig) this.emit('signal', sig);
        }
        break;
      }
      case 'loadHistoryPeriodFast': {
        // MarketDataApi a déjà résolu la promesse si pending. On émet aussi l'event public.
        const data = (args[0] ?? {}) as Record<string, unknown>;
        const asset = String(data.asset ?? '');
        const period = Number(data.period ?? 0);
        const candles = MarketDataApi.parseCandles(data.data ?? data.candles ?? data.bars);
        if (asset) {
          const history: HistoryPeriod = {
            asset,
            period,
            candles,
            hasMore: Boolean(data.hasMore ?? data.nextTime),
            nextIndex: data.nextTime ? Number(data.nextTime) : undefined,
            raw: data,
          };
          this.emit('history', history);
        }
        break;
      }
      default:
        // Evenement non géré explicitement
        this.emit('unknown', event, args);
        break;
    }
  }

  /** Demande les données initiales après authentification réussie. */
  private requestInitialData(): void {
    this.logger.debug('Requesting initial data: indicators, favorites, price-alerts');
    this.account.loadIndicators();
    this.account.loadFavorites();
    this.account.loadPriceAlerts();
  }
}
