/**
 * @file types.ts
 * @description Types TypeScript exhaustifs pour l'API Pocket Option.
 *
 * Ces types modélisent :
 *  - Les actifs / marchés (currency pairs, crypto, stocks, commodities, OTC)
 *  - Les chandeliers (candles / OHLCV)
 *  - Les ordres binaires (CALL / PUT) et express (multi-actifs)
 *  - Les balances (réel / démo / MT4 / MT5 / CFD)
 *  - Les deals ouverts et clôturés
 *  - Les streams de prix temps réel (quote stream)
 *  - Les signaux de trading
 *  - Les paramètres de configuration du SDK
 *
 * Tous les noms d'événements WebSocket et leur direction (client -> serveur
 * ou serveur -> client) sont repris du fichier HAR analysé.
 */

// ============================================================================
//  CONFIGURATION
// ============================================================================

/** Mode de compte : démo (argent virtuel) ou réel (argent réel). */
export type AccountMode = 'demo' | 'real';

/** Région du serveur de trading réel. */
export type ServerRegion =
  | 'eu'
  | 'spb'    // Saint-Pétersbourg
  | 'msk'    // Moscou
  | 'us-north'
  | 'us-south';

/** Plateforme client (représente le client d'origine : 14 = Android WebView). */
export type Platform = 2 | 14 | 1;

/** Options du client Pocket Option. */
export interface PocketOptionClientOptions {
  /** Identifiants de connexion. */
  credentials: Credentials;
  /** Mode de compte. */
  mode?: AccountMode;
  /** Région du serveur (utilisé seulement en mode 'real'). */
  region?: ServerRegion;
  /** Plateforme cliente signalée au serveur (default: 14). */
  platform?: Platform;
  /** Langue (default: 'en'). */
  lang?: string;
  /** User-Agent utilisé pour les requêtes HTTP et la session. */
  userAgent?: string;
  /** Active les logs détaillés. */
  debug?: boolean;
  /** Délai de reconnexion automatique en ms (default: 2000). */
  reconnectDelay?: number;
  /** Nombre max de tentatives de reconnexion (0 = infini). */
  maxReconnectAttempts?: number;
  /** Timeout d'authentification en ms (default: 15000). */
  authTimeout?: number;
  /** Utiliser l'historique rapide (format binaire compressé). */
  isFastHistory?: boolean;
  /** Active les optimisations de streaming. */
  isOptimized?: boolean;
  /** Session pré-construite (bypass du login HTTP).
   *  Si fournie, le SDK saute l'appel à `/api/webview/login` et utilise
   *  directement cette session pour authentifier le WebSocket.
   *  Utile si vous avez déjà un token valide (par ex. récupéré depuis un HAR
   *  récent ou via un autre canal). */
  session?: SessionData;
  /** IP publique à utiliser pour la session (default: auto-détectée). */
  ipAddress?: string;
  /** Clé d'encryption CodeIgniter pour signer la session PHP. */
  encryptionKey?: string;
}

/** Identifiants de connexion Pocket Option. */
export interface Credentials {
  email: string;
  password: string;
  /** Token Google Play optionnel (requis par l'API mobile pour authentifier
   *  la provenance de l'app Android). Si vide, le serveur peut renvoyer 400.
   *  Vous pouvez le récupérer en sniffant le trafic d'une vraie app Android. */
  googlePlayToken?: string;
  /** ID de l'app Google Play (default: "2"). */
  googlePlayAppId?: string;
}

// ============================================================================
//  AUTHENTIFICATION
// ============================================================================

/** Réponse de l'endpoint de login mobile `pomob-api.com/api/webview/login`. */
export interface LoginResponse {
  /** Code d'erreur (0 = succès). */
  code: number;
  /** Message d'erreur éventuel. */
  message: string;
  /** User ID Pocket Option. */
  uid: number;
  /** Token de session (32 chars hex). Utilisé comme session_id. */
  token: string;
  /** Secret utilisateur. */
  secret: string;
  /** Customer UID (format xxx-xxxx-xxxx-xxxxx). */
  cuid: string;
  /** True si le compte vient d'être créé. */
  is_register: boolean;
}

/** Données de session internes (construites après login + fetch cabinet).
 *
 * Dans le flux stateless (sans cookies persistants), `serializedSession`
 * contient simplement le `ci_session` URL-décodé récupéré depuis le
 * Set-Cookie de `/en/cabinet` (ou à défaut, de la réponse de login).
 *
 * Pour le MODE DÉMO, le SDK utilise par défaut le `demoSessionId` (un
 * PHPSESSID court de 26 chars partagé par tous les utilisateurs démo)
 * au lieu du ci_session — voir `PocketOptionClient.setDemoSessionId()`.
 *
 * Pour le MODE RÉEL, le `serializedSession` (= ci_session décodé) est
 * envoyé tel quel dans l'event `auth` du WebSocket. */
export interface SessionData {
  /** UID utilisateur. */
  uid: number;
  /** Token brut (32 chars hex). */
  token: string;
  /** Secret utilisateur. */
  secret: string;
  /** ci_session URL-décodé (utilisé tel quel pour l'auth WS en mode réel). */
  serializedSession: string;
  /** Customer UID. */
  cuid?: string;
  /** Adresse IP publique détectée (non requis en flux stateless). */
  ipAddress: string;
  /** User-Agent utilisé. */
  userAgent: string;
  /** Timestamp de dernière activité (en secondes). */
  lastActivity: number;
  /** Liste des serveurs réels extraite du cabinet (si fetché). */
  servers?: string[];
  /** Solde démo extrait du cabinet (si fetché). */
  demoBalance?: number;
  /** Devise du compte. */
  currency?: string;
}

// ============================================================================
//  MARCHÉS / ACTIFS
// ============================================================================

/** Type d'actif financier. */
export type AssetType =
  | 'currency'    // Paires de devises Forex
  | 'crypto'      // Cryptomonnaies
  | 'stock'       // Actions
  | 'commodity'   // Matières premières
  | 'otc'         // Over-The-Counter (hors marché)
  | 'index';      // Indices boursiers

/** Représentation d'un actif / marché. */
export interface Asset {
  /** Identifiant interne (ex: "#MCD_otc", "EURUSD", "UKBrent_otc"). */
  id: string;
  /** Nom affiché. */
  name: string;
  /** Type d'actif. */
  type: AssetType;
  /** Devise de base (ex: "USD"). */
  currency?: string;
  /** Pourcentage de payout (ex: 92 = 92%). */
  payout?: number;
  /** Indique si l'actif est OTC. */
  isOtc?: boolean;
  /** Nom complet fourni par Pocket Option (ex: "EUR/USD OTC", "Apple OTC"). */
  longName?: string;
  /** Marché actuellement ouvert (OTC toujours true ; false = fermé hors heures). */
  isOpen?: boolean;
  /** Volume minimum (pour FX). */
  minVolume?: number;
  /** Volume maximum. */
  maxVolume?: number;
  /** Step de volume. */
  volumeStep?: number;
  /** Précision décimale des prix. */
  precision?: number;
  /** Horaires de marché (sessions, en minutes depuis minuit UTC). */
  schedule?: Record<string, Array<[number, number]>>;
  /** Pourcentage de change fee (FX). */
  swapLong?: number;
  swapShort?: number;
  /** Levier maximum. */
  leverage?: number;
  /** Données brutes additionnelles. */
  raw?: unknown;
}

/** Liste complète des actifs indexée par ID. */
export type AssetsMap = Record<string, Asset>;

/** Périodes de temps supportées (en secondes pour binaire, en minutes pour FX). */
export type Period =
  | 1 | 2 | 3 | 5 | 10 | 15 | 30 | 45 | 60 | 120 | 180 | 240 | 300 | 600 | 900 | 1800 | 3600;

// ============================================================================
//  CHANDELIERS (OHLCV)
// ============================================================================

/** Chandelier brut (format tableau compact : [ts, open, high, low, close, volume?]). */
export type RawCandle = [number, number, number, number, number, number?];

/** Chandelier structuré. */
export interface Candle {
  /** Timestamp d'ouverture (en secondes Unix). */
  time: number;
  /** Prix d'ouverture. */
  open: number;
  /** Prix haut. */
  high: number;
  /** Prix bas. */
  low: number;
  /** Prix de clôture. */
  close: number;
  /** Volume (optionnel, surtout pour FX). */
  volume?: number;
}

/** Snapshot de prix temps réel (format flux). */
export interface QuoteTick {
  /** Symbole / actif. */
  asset: string;
  /** Timestamp en secondes. */
  time: number;
  /** Prix bid. */
  bid: number;
  /** Prix ask. */
  ask: number;
  /** Prix moyen (mid). */
  mid?: number;
}

/**
 * Tick du snapshot `updateHistoryNewFast` (HAR fix_gaps.har) :
 * [timestamp_sous_seconde, prix]. ~1300-1600 ticks couvrant ~12 minutes,
 * contigus avec le flux `updateStream` qui suit. Période-agnostique —
 * l'agrégation en bougies S5/S30/M1/M5 se fait côté consommateur.
 */
export interface HistoryTick {
  /** Timestamp marché en secondes (résolution sous-seconde). */
  time: number;
  /** Prix du tick. */
  price: number;
}

/** Entrée du flux `updateStream` (un ou plusieurs actifs). */
export interface StreamUpdate {
  /** Asset ID. */
  asset: string;
  /** Prix bid. */
  bid: number;
  /** Prix ask. */
  ask: number;
  /** Timestamp en secondes. */
  time: number;
  /** Variation absolue depuis l'ouverture de la séance. */
  change?: number;
  /** Variation en pourcentage. */
  changePercent?: number;
  /** Volume échangé. */
  volume?: number;
  /** Données brutes. */
  raw?: unknown;
}

// ============================================================================
//  ORDRES BINAIRE (CALL / PUT)
// ============================================================================

/** Direction d'un ordre binaire. */
export type OrderAction = 'call' | 'put';

/** Type d'option (100 = binaire standard). */
export type OptionType = 100 | 200 | 300;

/** Paramètres pour ouvrir un ordre binaire. */
export interface OpenOrderParams {
  /** Asset ID (ex: "#MCD_otc", "EURUSD_otc"). */
  asset: string;
  /** Montant à risquer (dans la devise du compte). */
  amount: number;
  /** Direction : 'call' = montant haussier, 'put' = montant baissier. */
  action: OrderAction;
  /** Durée d'expiration en secondes (le "time" de clôture). */
  time: number;
  /** Type d'option (default: 100). */
  optionType?: OptionType;
  /** Force le mode démo/réel pour cet ordre. */
  isDemo?: 0 | 1;
  /** ID de requête personnalisé (sinon généré automatiquement). */
  requestId?: number;
}

/** Ordre ouvert (en cours, en attente d'expiration). */
export interface OpenedDeal {
  /** ID unique de l'ordre côté serveur (peut être un UUID string côté PO,
   *  comme pour ClosedDeal — cf. trading-api.ts). */
  id: number | string;
  /** Asset tradé. */
  asset: string;
  /** Direction. */
  action: OrderAction;
  /** Montant misé. */
  amount: number;
  /** Prix d'ouverture. */
  openPrice: number;
  /** Timestamp d'ouverture (secondes Unix). */
  openTime: number;
  /** Timestamp d'expiration (secondes Unix). */
  expireTime: number;
  /** Durée d'expiration en secondes. */
  time: number;
  /** Type d'option. */
  optionType: OptionType;
  /** Mode démo (1) ou réel (0). */
  isDemo: 0 | 1;
  /** ID de requête client. */
  requestId?: number;
  /** Données brutes. */
  raw?: unknown;
}

/** Deal clôturé (résolu, gagné ou perdu). */
export interface ClosedDeal {
  /** ID unique de l'ordre (peut être un UUID string côté PO). */
  id: number | string;
  /** Asset tradé. */
  asset: string;
  /** Direction. */
  action: OrderAction;
  /** Montant misé. */
  amount: number;
  /** Prix d'ouverture. */
  openPrice: number;
  /** Prix de clôture. */
  closePrice: number;
  /** Timestamp d'ouverture. */
  openTime: number;
  /** Timestamp de clôture. */
  closeTime: number;
  /** Montant gagné (positif si gain, négatif si perte = -amount). */
  profit: number;
  /** True si l'ordre a gagné. */
  isWin: boolean;
  /** Mode démo ou réel. */
  isDemo: 0 | 1;
  /** Données brutes. */
  raw?: unknown;
}

/** Réponse à l'ouverture d'un ordre (`successopenOrder` / `failopenOrder`). */
export interface OpenOrderResult {
  /** True si l'ouverture a réussi. */
  success: boolean;
  /** ID de requête client. */
  requestId: number;
  /** Deal ouvert si succès. */
  deal?: OpenedDeal;
  /** Message d'erreur si échec. */
  error?: string;
  /** Données brutes. */
  raw?: unknown;
}

/** Paramètres pour un ordre express (multi-actifs). */
export interface ExpressLeg {
  asset: string;
  action: OrderAction;
  /** Timestamp d'expiration commun. */
  expireAt: number;
}

/** Paramètres pour ouvrir un ordre express. */
export interface OpenExpressParams {
  /** Montant total à risquer. */
  amount: number;
  /** Legs (sous-ordres). */
  legs: ExpressLeg[];
  /** Mode démo (1) ou réel (0). */
  isDemo?: 0 | 1;
}

// ============================================================================
//  COMPTE / BALANCE
// ============================================================================

/** Différentes balances disponibles (toutes les "poches" du compte). */
export interface Balances {
  /** Solde réel MT4. */
  'balance-mt4-real'?: number;
  /** Solme démo MT4. */
  'balance-mt4-demo'?: number;
  /** Solde réel MT5. */
  'balance-mt5-real'?: number;
  /** Solde démo MT5. */
  'balance-mt5-demo'?: number;
  /** Solde réel MT5 CFD. */
  'balance-mt5-cfd-real'?: number;
  /** Solde démo MT5 CFD. */
  'balance-mt5-cfd-demo'?: number;
  /** Solde démo binaire (quick high/low). */
  'balance-demo'?: number;
  /** Solde réel binaire. */
  'balance-real'?: number;
  /** Clés dynamiques additionnelles. */
  [key: string]: number | undefined;
}

/** Snapshot de balance. */
export interface BalanceUpdate {
  /** Mode (démo ou réel). */
  isDemo: 0 | 1;
  /** Solde courant. */
  balance: number;
  /** Toutes les balances (toutes poches). */
  balances?: Balances;
  /** Données brutes. */
  raw?: unknown;
}

// ============================================================================
//  COMPTE MT5 (FX)
// ============================================================================

/** Infos compte MT5 (FX). */
export interface MT5Account {
  server: string;
  login: number;
  group: string;
  balance: number;
  credit: number;
  leverage: number;
  enable: number;
  enableReadonly: number;
  currency: string;
}

/** Position MT5 ouverte. */
export interface MT5Position {
  ticket: number;
  symbol: string;
  volume: number;
  type: 'buy' | 'sell';
  openPrice: number;
  openTime: number;
  sl?: number;
  tp?: number;
  profit?: number;
  raw?: unknown;
}

/** Ordre MT5 en attente. */
export interface MT5Order {
  ticket: number;
  symbol: string;
  volume: number;
  type: string;
  price: number;
  raw?: unknown;
}

// ============================================================================
//  SIGNAUX
// ============================================================================

/** Signal de trading (copie sociale). */
export interface TradingSignal {
  /** ID du signal (format: <ts>-<asset>-<timeframe>). */
  signalId: string;
  /** Asset. */
  symbol: string;
  /** Direction. */
  action: OrderAction;
  /** Timeframe (période). */
  timeframe: number;
  /** Timestamp de création. */
  createdAt: number;
  /** Timestamp d'expiration. */
  expiredAt: number;
  /** Statistiques (nombre de copies, winrate, etc.). */
  stats?: SignalStats;
  /** Données brutes. */
  raw?: unknown;
}

/** Statistiques d'un signal. */
export interface SignalStats {
  copies?: number;
  wins?: number;
  losses?: number;
  profit?: number;
}

// ============================================================================
//  HISTORIQUE
// ============================================================================

/** Paramètres pour charger une période d'historique. */
export interface LoadHistoryParams {
  /** Asset. */
  asset: string;
  /** Timestamp de fin (en secondes). */
  time: number;
  /** Nombre de chandeliers à charger (offset, default: 9000). */
  offset?: number;
  /** Période en secondes (60, 180, 300, etc.). */
  period: number;
  /** Index de continuation (pour pagination). */
  index?: number;
}

/** Réponse d'historique paginé. */
export interface HistoryPeriod {
  /** Asset. */
  asset: string;
  /** Période. */
  period: number;
  /** Chandeliers (du plus ancien au plus récent). */
  candles: Candle[];
  /** Indique s'il y a encore de l'historique à charger. */
  hasMore?: boolean;
  /** Index pour la suite. */
  nextIndex?: number;
  /** Données brutes. */
  raw?: unknown;
}

// ============================================================================
//  TRANSPORT / LATENCE
// ============================================================================

/** État de la connexion WebSocket. */
export type ConnectionState =
  | 'disconnected'
  | 'connecting'
  | 'connected'
  | 'authenticating'
  | 'authenticated'
  | 'reconnecting'
  | 'error';

/** Mesure de latence round-trip (ping Engine.IO). */
export interface LatencySample {
  /** Timestamp du ping envoyé. */
  sentAt: number;
  /** Timestamp du pong reçu. */
  receivedAt: number;
  /** Latence round-trip en ms. */
  rttMs: number;
}

/** Statistiques de latence. */
export interface LatencyStats {
  /** Latence courante. */
  current: number;
  /// Latence minimale observée.
  min: number;
  /// Latence maximale observée.
  max: number;
  /// Latence moyenne.
  avg: number;
  /// Échantillons récents (RTT en ms).
  samples: number[];
  /// Nombre total de pings envoyés.
  totalPings: number;
}

// ============================================================================
//  ÉVÉNEMENTS SDK (API PUBLIQUE)
// ============================================================================

/** Carte d'événements émis par le SDK. */
export interface SocialTrade {
  id: string;
  uid: number;
  asset: string;
  direction: OrderAction;
  amount: number;
  openTime: number;
  closeTime?: number;
  openPrice: number;
  closePrice?: number;
  profit?: number;
  percentProfit?: number;
  isDemo?: number;
  nickname?: string;
  avatarUser?: string;
  currency?: string;
  raw?: unknown;
}

export interface PocketOptionEvents {
  /** Connexion établie. */
  connected: () => void;
  /** Connexion perdue. */
  disconnected: (reason: string) => void;
  /** Reconnexion en cours. */
  reconnecting: (attempt: number) => void;
  /** Erreur fatale. */
  error: (err: Error) => void;
  /** Authentification réussie. */
  authenticated: (session: SessionData) => void;
  /** Authentification échouée. */
  auth_failed: (err: Error) => void;
  /** État de connexion changé. */
  state_changed: (state: ConnectionState) => void;
  /** Latence mesurée (après chaque pong). */
  latency: (sample: LatencySample) => void;
  /** Stream de prix temps réel. */
  stream: (updates: StreamUpdate[]) => void;
  /** Mise à jour des chandeliers en temps réel. */
  candles_update: (asset: string, period: number, candles: Candle[]) => void;
  /**
   * Snapshot d'historique rapide `updateHistoryNewFast` — ticks bruts du
   * broker (~12 min), poussé après chaque `changeSymbol`. Le consommateur
   * les fusionne dans son buffer de ticks canonique (miroir du broker).
   */
  history_ticks: (asset: string, period: number, ticks: HistoryTick[]) => void;
  /** Liste des actifs mise à jour. */
  assets: (assets: AssetsMap) => void;
  /** Balance mise à jour. */
  balance: (update: BalanceUpdate) => void;
  /** Deal ouvert. */
  deal_opened: (deal: OpenedDeal) => void;
  /** Deal clôturé. */
  deal_closed: (deal: ClosedDeal) => void;
  /** Résultat d'ouverture d'ordre. */
  order_result: (result: OpenOrderResult) => void;
  /** Signal reçu. */
  signal: (signal: TradingSignal) => void;
  social_opened: (trades: SocialTrade[]) => void;
  social_closed: (trades: SocialTrade[]) => void;
  /** Historique chargé. */
  history: (history: HistoryPeriod) => void;
  /** Message brut non traité. */
  raw: (event: string, ...args: unknown[]) => void;
  /** Événement non reconnu. */
  unknown: (event: string, args: unknown[]) => void;
}

/** Type d'un handler d'événement. */
export type EventHandler<E extends keyof PocketOptionEvents> = PocketOptionEvents[E];
