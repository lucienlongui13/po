/**
 * @file auth.ts
 * @description Authentification Pocket Option — flux stateless sans cookies.
 *
 * Reproduit fidèlement le flux du projet Python de référence (po_client/pocket.py) :
 *
 *  1. POST https://pomob-api.com/api/webview/login
 *     - Headers : User-Agent Android WebView, x-po-bid: 2, Content-Type form-urlencoded
 *     - Body    : token=&email=<email>&password=<password>&lang=en&google_play_app_id=2
 *       (PAS de google_play_token — c'est ce qui faisait échouer notre login avant)
 *     - Query   : appsflyer_id=<rand>&app_instance_id=<uuid>&utm_source=organic&
 *                 utm_medium=organic&install_time=<ts>&af_message=organic_install&
 *                 af_status=Organic&gaid=<uuid>
 *     - Réponse : {code, message, uid, token, secret, cuid, is_register}
 *     - Set-Cookie : ci_session=<value> (récupéré depuis les headers de réponse)
 *
 *  2. GET https://m.pocketoption.com/en/cabinet?token=<token>&<tracking>
 *     - Permet d'obtenir un ci_session FRAIS (le serveur le set à chaque GET)
 *       + la liste des serveurs réels + le solde démo + la currency
 *     - L'AppData est embarquée dans le HTML sous forme de JSON inline
 *
 *  3. URL-décoder le ci_session (le navigateur js-cookie utilise la forme décodée
 *     pour comparer avec la session PHP stockée en base).
 *
 *  4. Pour le MODE DÉMO : utiliser un demoSessionId distinct (PHPSESSID court
 *     de 26 chars, partagé entre tous les utilisateurs démo sur le serveur).
 *     Pour le MODE RÉEL : utiliser le ci_session récupéré ci-dessus.
 *
 * Pas besoin de construire manuellement une session PHP CodeIgniter sérialisée
 * ni de la signer avec un hash MD5 : le serveur compare directement le cookie
 * ci_session (URL-décodé) avec la valeur stockée en base.
 */

import type {
  Credentials,
  LoginResponse,
  SessionData,
  AccountMode,
} from './types';
import { URLS, LOGIN_PATH, DEFAULTS, ERROR_CODES } from './constants';
import { Logger } from './utils/logger';

// --------------------------------------------------------------------------
//  Types spécifiques à l'authentification
// --------------------------------------------------------------------------

/** Résultat complet du login (équivalent du LoginResult Python). */
export interface LoginResult {
  /** User ID Pocket Option. */
  uid: number;
  /** Token de session (32 chars hex). */
  token: string;
  /** Secret utilisateur. */
  secret: string;
  /** Customer UID (format xxx-xxxx-xxxx-xxxxx). */
  cuid: string;
  /** ci_session récupéré depuis le Set-Cookie de la réponse de login. */
  ciSession: string | undefined;
  /** Paramètres de tracking (appsflyer_id, etc.) réutilisés pour fetch_cabinet. */
  tracking: TrackingParams;
  /** True si le compte vient d'être créé. */
  isRegister: boolean;
}

/** Paramètres de tracking envoyés dans la query string du login et du cabinet. */
export interface TrackingParams {
  appsflyer_id: string;
  app_instance_id: string;
  utm_source: string;
  utm_medium: string;
  install_time: string;
  af_message: string;
  af_status: string;
  gaid: string;
}

/** Infos extraites de la page cabinet (AppData inline dans le HTML). */
export interface CabinetInfo {
  /** ci_session frais récupéré depuis le Set-Cookie du cabinet. */
  ciSession: string | undefined;
  /** AppData complète parsée depuis le HTML. */
  appData: Record<string, unknown>;
  /** Liste des serveurs réels extraite de AppData.servers-list. */
  servers: string[];
  /** Solde démo extrait de AppData.user-demo-balance. */
  demoBalance: number | undefined;
  /** Devise du compte extraite de AppData.currency_code. */
  currency: string;
  /** UID extrait de AppData.uid (peut différer de login uid en démo). */
  uid: number | undefined;
  /** HTML brut (utile pour debug). */
  html: string;
}

/** Options du module d'authentification. */
export interface AuthModuleOptions {
  credentials: Credentials;
  userAgent?: string;
  lang?: string;
  logger?: Logger;
  /** Fonction fetch personnalisée (pour tests / environnement browser). */
  fetchImpl?: typeof fetch;
}

// --------------------------------------------------------------------------
//  Helpers
// --------------------------------------------------------------------------

/** Génère un appsflyer_id factice (format : <ts_ms>-<rand 19 digits>). */
function generateAppsflyerId(): string {
  const ts = Date.now();
  // 18-19 digit random number
  const rand = Math.floor(Math.random() * 9e18) + 1e18;
  return `${ts}-${rand}`;
}

/** Génère un app_instance_id / gaid factice (UUID v4-ish, 36 chars). */
function generateUuid(): string {
  // Equivalent to Python's uuid.uuid4()
  const chars = '0123456789abcdef';
  let s = '';
  for (let i = 0; i < 36; i++) {
    if (i === 8 || i === 13 || i === 18 || i === 23) {
      s += '-';
    } else if (i === 14) {
      s += '4'; // version 4
    } else if (i === 19) {
      s += chars[(Math.random() * 4) | 0 | 8]; // variant 10xx
    } else {
      s += chars[(Math.random() * 16) | 0];
    }
  }
  return s;
}

/** Formate une date ISO pour le paramètre `install_time` (YYYY-MM-DD_HH:mm:ss.000). */
function formatInstallTime(d: Date): string {
  const pad = (n: number, w = 2) => n.toString().padStart(w, '0');
  return (
    `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` +
    `_${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.000`
  );
}

/** Génère les paramètres de tracking pour login et cabinet. */
export function generateTrackingParams(): TrackingParams {
  const now = new Date();
  return {
    appsflyer_id: generateAppsflyerId(),
    app_instance_id: generateUuid(),
    utm_source: 'organic',
    utm_medium: 'organic',
    install_time: formatInstallTime(now),
    af_message: 'organic_install',
    af_status: 'Organic',
    gaid: generateUuid(),
  };
}

/** Construit la query string à partir d'un objet de params. */
function buildQuery(params: Record<string, string>): string {
  return new URLSearchParams(params).toString();
}

/**
 * Construit le body form-urlencoded pour le login.
 *
 * IMPORTANT : `google_play_token` est OMIS par défaut (et c'est ce qui fait
 * fonctionner le login sans jeton Firebase). Le projet Python de référence
 * ne l'envoie que si explicitement fourni via `--google-play-token` ou
 * `PO_GOOGLE_PLAY_TOKEN`, et dans la pratique aucun utilisateur n'en fournit.
 */
function buildLoginBody(credentials: Credentials, lang: string): string {
  const params: Record<string, string> = {
    token: '',
    email: credentials.email,
    password: credentials.password,
    lang,
    google_play_app_id: '2',
  };
  // On n'ajoute google_play_token QUE s'il est explicitement fourni.
  // Sinon on l'omet totalement (et le serveur accepte le login sans ce jeton).
  if (credentials.googlePlayToken) {
    params.google_play_token = credentials.googlePlayToken;
  }
  return new URLSearchParams(params).toString();
}

/**
 * Extrait toutes les valeurs d'un cookie donné depuis les headers de réponse.
 *
 * Le header `Set-Cookie` peut apparaître plusieurs fois dans une réponse HTTP
 * (et c'est important : Pocket Option envoie plusieurs cookies ci_session,
 * le bon étant souvent le dernier). On utilise donc `resp.headers.getSetCookie()`
 * si disponible (Node 18+ / undici), sinon on retombe sur `getSetCookie` polyfill.
 */
function extractCookieValues(headers: Headers, name: string): string[] {
  const out: string[] = [];
  const lower = name.toLowerCase();
  // Méthode moderne : getSetCookie() retourne un tableau de toutes les valeurs Set-Cookie
  const setCookies =
    typeof (headers as any).getSetCookie === 'function'
      ? (headers as any).getSetCookie() as string[]
      : [];
  if (setCookies.length > 0) {
    for (const sc of setCookies) {
      if (sc.toLowerCase().startsWith(lower + '=')) {
        const value = sc.split(';')[0].split('=').slice(1).join('=');
        out.push(value);
      }
    }
    return out;
  }
  // Fallback : header unique combiné (navigateur ou ancien runtime)
  const combined = headers.get('set-cookie');
  if (combined) {
    for (const sc of combined.split(/,(?=\s*[A-Za-z0-9_-]+=)/)) {
      if (sc.trim().toLowerCase().startsWith(lower + '=')) {
        const value = sc.split(';')[0].split('=').slice(1).join('=');
        out.push(value);
      }
    }
  }
  return out;
}

// --------------------------------------------------------------------------
//  Login HTTP
// --------------------------------------------------------------------------

/**
 * Effectue le login mobile Pocket Option.
 *
 * @param options Options d'authentification
 * @returns LoginResult (uid, token, secret, cuid, ciSession, tracking)
 */
export async function loginMobile(options: AuthModuleOptions): Promise<LoginResult> {
  const fetchImpl = options.fetchImpl || fetch;
  const userAgent = options.userAgent || DEFAULTS.USER_AGENT;
  const lang = options.lang || DEFAULTS.LANG;
  const logger = options.logger;

  const tracking = generateTrackingParams();
  const query = buildQuery(tracking as unknown as Record<string, string>);
  const body = buildLoginBody(options.credentials, lang);

  // Headers critiques :
  //  - x-po-bid: 2 ( identifie le build client, requis par le serveur )
  //  - Content-Type: application/x-www-form-urlencoded
  //  - Accept: application/json
  //  - User-Agent Android WebView avec suffixe ", webview2_android_428"
  const headers: Record<string, string> = {
    'User-Agent': userAgent,
    'x-po-bid': '2',
    'Content-Type': 'application/x-www-form-urlencoded',
    Accept: 'application/json',
  };

  const url = `${URLS.MOBILE_API}${LOGIN_PATH}?${query}`;
  logger?.debug('loginMobile: POST', url);
  logger?.debug('loginMobile: body', body.replace(/password=[^&]+/, 'password=***'));

  try {
    const res = await fetchImpl(url, { method: 'POST', headers, body });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(
        `${ERROR_CODES.LOGIN_FAILED}: HTTP ${res.status} ${res.statusText} - ${text.slice(0, 300)}`,
      );
    }
    const json = (await res.json()) as LoginResponse;
    if (json.code !== 0) {
      throw new Error(
        `${ERROR_CODES.LOGIN_FAILED}: code=${json.code} message=${json.message}`,
      );
    }
    if (!json.token || !json.uid) {
      throw new Error(
        `${ERROR_CODES.LOGIN_FAILED}: missing token/uid in response`,
      );
    }

    // Récupère le ci_session depuis le Set-Cookie (le serveur le set à chaque login).
    const cookies = extractCookieValues(res.headers, 'ci_session');
    const ciSession = cookies.length > 0 ? cookies[cookies.length - 1] : undefined;

    logger?.info(
      'loginMobile: success uid=', json.uid,
      'is_register=', json.is_register,
      'ci_session=', ciSession ? `${ciSession.slice(0, 24)}...` : '(none)',
    );

    return {
      uid: json.uid,
      token: json.token,
      secret: json.secret,
      cuid: json.cuid ?? '',
      ciSession,
      tracking,
      isRegister: Boolean(json.is_register),
    };
  } catch (err) {
    if (err instanceof Error && err.message.startsWith(ERROR_CODES.LOGIN_FAILED)) {
      throw err;
    }
    const msg = err instanceof Error ? err.message : String(err);
    throw new Error(`${ERROR_CODES.NETWORK_ERROR}: ${msg}`);
  }
}

// --------------------------------------------------------------------------
//  Fetch cabinet (récupère ci_session frais + AppData + servers list)
// --------------------------------------------------------------------------

/** URL de la page cabinet. */
const CABINET_PATH = '/en/cabinet';

/**
 * Extrait l'objet AppData embarqué dans le HTML du cabinet.
 *
 * Le HTML contient une ligne du type :
 *   AppData = {...}; ou var AppData = {...};
 *
 * On parse manuellement le JSON en suivant la profondeur des accolades
 * (équivalent du _extract_appdata Python).
 */
function extractAppData(html: string): Record<string, unknown> {
  const match = /AppData\s*=\s*(\{)/.exec(html);
  if (!match) {
    throw new Error('AppData config not found in cabinet page');
  }
  const start = match.index + match[0].length - 1; // position du '{'
  let depth = 0;
  let inString = false;
  let escaped = false;
  let i = start;
  while (i < html.length) {
    const ch = html[i];
    if (inString) {
      if (escaped) {
        escaped = false;
      } else if (ch === '\\') {
        escaped = true;
      } else if (ch === '"') {
        inString = false;
      }
    } else {
      if (ch === '"') {
        inString = true;
      } else if (ch === '{') {
        depth++;
      } else if (ch === '}') {
        depth--;
        if (depth === 0) {
          break;
        }
      }
    }
    i++;
  }
  const jsonStr = html.slice(start, i + 1);
  try {
    return JSON.parse(jsonStr);
  } catch (err) {
    throw new Error(`Failed to parse AppData JSON: ${err instanceof Error ? err.message : err}`);
  }
}

/**
 * Fetch le cabinet Pocket Option pour récupérer un ci_session frais.
 *
 * @param token Token récupéré depuis la réponse de login
 * @param tracking Paramètres de tracking (réutilisés depuis le login)
 * @param options Options (logger, fetchImpl, userAgent)
 * @returns CabinetInfo (ciSession, appData, servers, demoBalance, currency, uid)
 */
export async function fetchCabinet(
  token: string,
  tracking: TrackingParams,
  options: AuthModuleOptions,
): Promise<CabinetInfo> {
  const fetchImpl = options.fetchImpl || fetch;
  const userAgent = options.userAgent || DEFAULTS.USER_AGENT;
  const logger = options.logger;

  const query = buildQuery({ token, ...(tracking as unknown as Record<string, string>) });
  const url = `${URLS.WEB}${CABINET_PATH}?${query}`;
  const headers: Record<string, string> = {
    'User-Agent': userAgent,
    Accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  };

  logger?.debug('fetchCabinet: GET', url);

  try {
    const res = await fetchImpl(url, { method: 'GET', headers });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(
        `fetchCabinet: HTTP ${res.status} ${res.statusText} - ${text.slice(0, 200)}`,
      );
    }
    const html = await res.text();
    const cookies = extractCookieValues(res.headers, 'ci_session');
    const ciSession = cookies.length > 0 ? cookies[cookies.length - 1] : undefined;
    const appData = extractAppData(html);

    // Extraction des champs utiles de AppData
    const serversList = (appData['servers-list'] as Array<{ server: string }>) ?? [];
    const servers = serversList.map((s) => s.server);
    const demoBalance = appData['user-demo-balance'] as number | undefined;
    const currency = (appData['currency_code'] as string) ?? 'USD';
    const uid = appData['uid'] as number | undefined;

    logger?.info(
      'fetchCabinet: success servers=', servers.length,
      'demo_balance=', demoBalance,
      'ci_session=', ciSession ? `${ciSession.slice(0, 24)}...` : '(none)',
    );

    return { ciSession, appData, servers, demoBalance, currency, uid, html };
  } catch (err) {
    if (options.logger) {
      options.logger.warn('fetchCabinet failed:', err instanceof Error ? err.message : err);
    }
    throw err;
  }
}

// --------------------------------------------------------------------------
//  Authenticate (login + fetch cabinet + URL-decode ci_session)
// --------------------------------------------------------------------------

/**
 * Authentification complète stateless :
 *  1. login() -> LoginResult (uid, token, secret, ci_session du login)
 *  2. fetchCabinet(token) -> CabinetInfo (ci_session frais + servers + demo_balance)
 *  3. Sélection du ci_session final (celui du cabinet si dispo, sinon du login)
 *  4. URL-décodage du ci_session (le navigateur js-cookie l'utilise sous forme décodée)
 *
 * @returns { loginResult, cabinet, session }
 */
export async function authenticate(
  options: AuthModuleOptions,
): Promise<{
  loginResult: LoginResult;
  cabinet: CabinetInfo | null;
  session: string;
}> {
  const logger = options.logger;
  const loginResult = await loginMobile(options);

  let cabinet: CabinetInfo | null = null;
  try {
    cabinet = await fetchCabinet(loginResult.token, loginResult.tracking, options);
  } catch (err) {
    // Le cabinet est optionnel : si on n'arrive pas à le fetcher, on retombe
    // sur le ci_session du login (qui fonctionne aussi pour le mode réel).
    logger?.warn('fetchCabinet failed, falling back to login ci_session');
  }

  // Sélection du ci_session final : priorité au cabinet (plus frais)
  let session: string | undefined;
  if (cabinet && cabinet.ciSession) {
    session = cabinet.ciSession;
  } else if (loginResult.ciSession) {
    session = loginResult.ciSession;
  }
  if (!session) {
    throw new Error(`${ERROR_CODES.AUTH_FAILED}: no ci_session received from server`);
  }

  // URL-décodage : le navigateur (js-cookie) utilise la forme décodée pour
  // comparer avec la session PHP stockée en base. Sans ça, l'auth WS échoue.
  session = decodeURIComponent(session);

  logger?.debug('authenticate: final session (decoded):', session.slice(0, 60) + '...');
  return { loginResult, cabinet, session };
}

// --------------------------------------------------------------------------
//  SessionData (pour rétro-compat avec l'API publique du SDK)
// --------------------------------------------------------------------------

/**
 * Construit l'objet SessionData utilisé par PocketOptionClient.
 *
 * Cette fonction est conservée pour rétro-compatibilité, mais dans le flux
 * normal le `session` envoyé au WS est simplement le ci_session URL-décodé
 * (PAS une session PHP CodeIgniter sérialisée manuellement).
 *
 * @param loginResult Résultat du login
 * @param ciSession ci_session final (URL-décodé)
 */
export function buildSessionData(
  loginResult: LoginResult,
  ciSession: string,
): SessionData {
  return {
    uid: loginResult.uid,
    token: loginResult.token,
    secret: loginResult.secret,
    // Pour le mode réel : le session envoyé au WS est directement le ci_session
    // (et non une construction PHP sérialisée). On le stocke dans serializedSession
    // pour rétro-compat avec l'API publique du SDK.
    serializedSession: ciSession,
    ipAddress: '', // non requis dans le flux stateless
    userAgent: '',
    lastActivity: Math.floor(Date.now() / 1000),
  };
}

// --------------------------------------------------------------------------
//  Détection IP publique (legacy, conservée pour rétro-compat)
// --------------------------------------------------------------------------

/**
 * Détecte l'IP publique du client. N'est plus nécessaire dans le flux stateless
 * (le serveur identifie l'IP depuis la connexion TCP elle-même, pas depuis la
 * session sérialisée). Conservé pour rétro-compat avec les anciennes options.
 */
export async function detectPublicIp(
  fetchImpl: typeof fetch = fetch,
  logger?: Logger,
): Promise<string> {
  const services = [
    'https://api.ipify.org?format=json',
    'https://ifconfig.me/all.json',
  ];
  for (const url of services) {
    try {
      const res = await fetchImpl(url, { method: 'GET' });
      const json = (await res.json()) as { ip?: string; ip_addr?: string };
      const ip = json.ip || json.ip_addr;
      if (ip) return ip;
    } catch (err) {
      logger?.warn('detectPublicIp: service failed', url, err);
    }
  }
  return '127.0.0.1';
}
