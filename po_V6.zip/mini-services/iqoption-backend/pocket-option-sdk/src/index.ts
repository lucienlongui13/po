/**
 * @file index.ts
 * @description Point d'entrée principal du SDK Pocket Option.
 *
 * Exports :
 *  - PocketOptionClient : le client principal
 *  - Tous les types TypeScript
 *  - Les constantes (URLS, CLIENT_EVENTS, SERVER_EVENTS, etc.)
 *  - Les utilitaires (buildSessionData, generateRequestId, etc.)
 *  - Logger et TypedEmitter pour extension
 */

// Client principal
export { PocketOptionClient } from './client';

// Modules API (avancé : accès direct aux sous-APIs)
export { MarketDataApi } from './api/market-data';
export { TradingApi } from './api/trading-api';
export { AccountApi } from './api/account-api';
export { SignalsApi } from './api/signals-api';

// Transport (avancé)
export { LatencyTracker } from './transport/latency-tracker';

// Authentification
export {
  loginMobile,
  authenticate,
  fetchCabinet,
  detectPublicIp,
  buildSessionData,
} from './auth';
export type { LoginResult, TrackingParams, CabinetInfo, AuthModuleOptions } from './auth';

// Utilitaires
export { Logger } from './utils/logger';
export { TypedEmitter } from './utils/typed-emitter';
export { generateRequestId, buildSignalId } from './utils/session';

// Constantes
export {
  URLS,
  LOGIN_PATH,
  SIO_OPTIONS,
  TIMINGS,
  DEFAULTS,
  ERROR_CODES,
  CLIENT_EVENTS,
  SERVER_EVENTS,
  MAIN_SERVERS,
  DEMO_SERVERS,
} from './constants';
export type { ClientEventName, ServerEventName } from './constants';

// Types (réexport pour faciliter l'import)
export type {
  AccountMode,
  ServerRegion,
  Platform,
  PocketOptionClientOptions,
  Credentials,
  LoginResponse,
  SessionData,
  AssetType,
  Asset,
  AssetsMap,
  Period,
  RawCandle,
  Candle,
  QuoteTick,
  HistoryTick,
  StreamUpdate,
  OrderAction,
  OptionType,
  OpenOrderParams,
  OpenedDeal,
  ClosedDeal,
  OpenOrderResult,
  ExpressLeg,
  OpenExpressParams,
  Balances,
  BalanceUpdate,
  MT5Account,
  MT5Position,
  MT5Order,
  TradingSignal,
  SignalStats,
  LoadHistoryParams,
  HistoryPeriod,
  ConnectionState,
  LatencySample,
  LatencyStats,
  SocialTrade,
  PocketOptionEvents,
  EventHandler,
} from './types';
