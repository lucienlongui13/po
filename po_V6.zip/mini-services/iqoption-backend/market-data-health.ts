/**
 * market-data-health.ts — SANTÉ DES DONNÉES DE MARCHÉ, PAR ASSET.
 * ====================================================================
 *
 * Exigences du cahier des charges (§9 à §16, §19, §20) :
 *   - UN état de santé INDÉPENDANT par asset (aucun partage global) ;
 *   - un score 0–100 : 100 = excellent · 80–99 bon · 60–79 dégradé ·
 *     40–59 dangereux · 0–39 inutilisable ;
 *   - détection des GAPS (bougies manquantes) sans jamais les masquer ;
 *   - détection des données STALE avec seuils DÉRIVÉS du timeframe
 *     (jamais hardcodés pour un seul timeframe) ;
 *   - `canTrade()` consulté par CHAQUE stratégie AVANT toute décision
 *     CALL/PUT/BUY/SELL ;
 *   - conditions minimales (v6.11 — STRUCTURELLES uniquement) : historyReady,
 *     streamConnected, candleCount suffisant (PLEINE SÉRIE), flux vivant ;
 *   - sévérité de gap graduée (léger / important / critique) — OBSERVABLE
 *     (score + reasons + badge), jamais bloquante depuis v6.11 ;
 *   - diagnostic lisible par asset (§19) + reasons explicites ;
 *
 * v6.11 — POLITIQUE DE GATING STRUCTURELLE (fix CRITICAL_GAP multi-assets) :
 *   les imperfections de qualité de données (trous, micro-staleness, doublons)
 *   sont CONSTITUTIVES des flux OTC multi-assets (la source ne génère un
 *   symbole que lorsqu'il est actif ; 24 assets se partagent UNE connexion).
 *   Les traiter comme des événements BLOQUANTS laissait les cartes en
 *   « TRADING BLOQUÉ — CRITICAL_GAP » pendant 50+ minutes et empêchait TOUTES
 *   les stratégies de trader en multi-assets.
 *
 *   Depuis v6.11, `canTrade()` ne bloque PLUS QUE sur des conditions
 *   STRUCTURELLES (impossibilité factuelle d'évaluer) :
 *     1. STREAM_DISCONNECTED — le flux est coupé (socket niveau transport) ;
 *     2. HISTORY_NOT_READY   — aucun historique ingéré ;
 *     3. INSUFFICIENT_CANDLES — moins de minCandles bougies clôturées dans
 *        TOUTE la série canonique (comptage PLEINE SÉRIE : l'historique
 *        paginé/nappe compte, plus de warm-up « frais depuis la couture ») ;
 *     4. STREAM_STALE (filet) — aucun tick depuis 10 × timeframe (flux
 *        zombie : le transport est vivant mais la source est morte).
 *   Tout le reste — gaps (toute sévérité), staleness léger, doublons,
 *   OHLC, score — reste OBSERVABLE (score + reasons + badge §27, journal
 *   §19/§20, réparations §13) mais n'interdit JAMAIS le trading. Les
 *   stratégies conservent leurs propres exigences de profondeur de données.
 *
 * v6.11 — ISOLATION PAR TIMEFRAME (côté orchestrateur) : seuls les trous du
 *   timeframe GRAPHIQUE alimentent la santé (les trous S5/M1/M5 sont comptés
 *   dans leurs propres unités : 45 s = 9 bougies S5 = 1-2 bougies S30 ; les
 *   injecter dans une santé S30 amplifiait les micro-pertes par 6×).
 *
 * v6.5 — VIEILLISSEMENT DES GAPS (fenêtre d'analyse) :
 *   un trou VIEUX (hors de la fenêtre d'analyse des stratégies ~100 bougies)
 *   n'affecte plus le score/statut : les stratégies ne lisent que les ~100
 *   dernières bougies clôturées, un trou derrière cette fenêtre ne peut pas
 *   fausser une décision. Il reste COMPTÉ et SIGNALÉ (jamais masqué — §11)
 *   via gapCount + agedGapCount, mais ne dégrade plus l'asset pour toujours.
 *   Un trou RÉCENT (dans la fenêtre) dégrade le score (pénalité plafonnée)
 *   mais ne bloque PLUS le trading (v6.11).
 *
 * Seuils dynamiques (§12) — pour un timeframe T (secondes) :
 *   tick   : warning > T/6  (30 s → 5 s)   · stale > T/2 (30 s → 15 s)
 *   bougie : warning > 1.5T (30 s → 45 s)  · stale > 3T  (30 s → 90 s)
 *
 * Module PUR (aucune dépendance socket/io) — testable isolément.
 */

// ─────────────────────────────────────────────────────────────────────────────
// Types publics
// ─────────────────────────────────────────────────────────────────────────────

export type MarketDataHealthStatus =
  | 'BOOTING'
  | 'LOADING_HISTORY'
  | 'SYNCING'
  | 'READY'
  | 'STALE'
  | 'GAP'
  | 'INVALID'
  | 'DISCONNECTED';

export interface MarketDataHealthState {
  asset: string;

  status: MarketDataHealthStatus;

  lastTickAt: number | null;
  lastCandleAt: number | null;

  /** Âge du dernier tick (ms, calculé au dernier update()). */
  tickAgeMs: number | null;
  /** Âge de la dernière bougie clôturée (ms). */
  candleAgeMs: number | null;

  candleCount: number;

  /** Nombre de bougies attendues entre la première et la dernière. */
  expectedCandleCount: number;

  /** Total des gaps détectés (récents + vieillis) — JAMAIS masqué (§11). */
  gapCount: number;

  /** Gaps dans la fenêtre d'analyse (~100 bougies) — ceux qui dégradent. */
  recentGapCount: number;

  /** Gaps vieillis hors fenêtre d'analyse — informatifs, ne bloquent pas. */
  agedGapCount: number;

  /**
   * v6.5.1 — Trous de COUTURE historique↔live (dans la fenêtre d'analyse) :
   * bougies que le broker n'a JAMAIS servies (limite de la source : le flux
   * OTC d'un symbole n'est généré que lorsqu'il est actif quelque part).
   * Comptés et signalés (§11 — jamais masqués) mais NON bloquants : les
   * lectures d'analyse (stratégies, coach) s'arrêtent à la couture
   * (cf. AssetPipeline.getLastClosedCandles) et le trading attend
   * minCandles bougies FRAÎCHES depuis la couture (§14).
   */
  seamGapCount: number;

  /**
   * v6.5.1 — Début (s marché) du segment LIVE courant quand une couture est
   * active (null = série contiguë). Les lectures d'analyse ne remontent
   * JAMAIS au-delà de ce point tant que la couture est dans la fenêtre.
   */
  seamFirstLiveSec: number | null;

  duplicateCount: number;

  outOfOrderCount: number;

  timeframeSec: number;

  currentCandleValid: boolean;

  historyReady: boolean;

  streamConnected: boolean;

  /** Score global 0–100. */
  healthScore: number;

  /** Motifs explicites de dégradation / blocage. */
  reasons: string[];
}

export type GapSeverity = 'none' | 'light' | 'medium' | 'critical';

export interface HealthCheckResult {
  allowed: boolean;
  score: number;
  status: MarketDataHealthStatus;
  reason?: string;
  reasons: string[];
}

export interface MarketDataHealthConfig {
  /** Timeframe de référence (secondes) — dérive tous les seuils. */
  timeframeSec: number;
  /** Nombre minimal de bougies clôturées pour trader (défaut 25). */
  minCandles: number;
  /** Score minimal pour autoriser le trading (défaut 80, configurable §14). */
  minHealthScoreToTrade: number;
  /** Connexion stream supposée active au départ (défaut false). */
  streamConnected: boolean;
  /**
   * v6.5 — Fenêtre d'analyse (en bougies) utilisée pour vieillir les gaps :
   * un trou plus VIEUX que N bougies derrière le bord live sort de la
   * fenêtre des stratégies (elles lisent ~100 bougies clôturées) et ne
   * dégrade plus la santé. Défaut 100, minimum plancher 10 min.
   */
  gapAgingCandles: number;
}

const DEFAULT_MIN_CANDLES = 25;
const DEFAULT_MIN_HEALTH_SCORE = 80;
const DEFAULT_GAP_AGING_CANDLES = 100;

/** Clamp utilitaire. */
const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));

/**
 * v6.5 — Événement de gap, avec sa position marché quand elle est connue.
 * `endSec` = timestamp (s) du premier bucket PRÉSENT après le trou —
 * permet de vieillir le gap par sa POSITION et non par sa détection.
 * v6.5.1 — `seam` : trou de COUTURE historique↔live (limite de la source,
 * bougies jamais servies) — signalé, non bloquant, lectures coupées.
 */
interface GapEvent {
  /** Bougies manquantes couvertes par ce trou. */
  count: number;
  /** Détection (ms locaux). */
  detectedAtMs: number;
  /** Début du trou (temps marché, s) — optionnel (v6.5.1). */
  startSec?: number;
  /** Fin du trou (temps marché, s) — optionnel. */
  endSec?: number;
  /** v6.5.1 — Trou de couture historique↔live (non bloquant). */
  seam?: boolean;
}

// ─────────────────────────────────────────────────────────────────────────────
// Seuils dynamiques (§12 — dérivés du timeframe, JAMAIS hardcodés)
// ─────────────────────────────────────────────────────────────────────────────

export interface DynamicThresholds {
  tickWarnMs: number;
  tickStaleMs: number;
  candleWarnMs: number;
  candleStaleMs: number;
}

/**
 * Calcule les seuils de fraîcheur depuis le timeframe.
 * Exemple (spécification, T = 30 s) : tick 5 s/15 s · bougie 45 s/90 s.
 */
export function computeThresholds(timeframeSec: number): DynamicThresholds {
  const t = Math.max(1, timeframeSec) * 1000;
  return {
    tickWarnMs: Math.round(t / 6),      // 30 s → 5 s
    tickStaleMs: Math.round(t / 2),     // 30 s → 15 s
    candleWarnMs: Math.round(t * 1.5),  // 30 s → 45 s
    candleStaleMs: Math.round(t * 3),   // 30 s → 90 s
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// Validation OHLC (§14 — OHLC valides)
// ─────────────────────────────────────────────────────────────────────────────

export function isCandleOhlcValid(c: {
  open: number; high: number; low: number; close: number; time: number;
}): boolean {
  return (
    Number.isFinite(c.time) &&
    Number.isFinite(c.open) && Number.isFinite(c.high) &&
    Number.isFinite(c.low) && Number.isFinite(c.close) &&
    c.low <= Math.min(c.open, c.close) + 1e-9 &&
    c.high >= Math.max(c.open, c.close) - 1e-9 &&
    c.high >= c.low - 1e-9
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MarketDataHealth — UNE instance PAR asset
// ─────────────────────────────────────────────────────────────────────────────

/**
 * État de santé des données de marché d'UN asset.
 *
 * Ne partage AUCUN état avec les autres assets : chaque pipeline construit
 * sa propre instance. Toutes les méthodes `onX` sont des points d'entrée
 * factuels (tick, bougie clôturée, historique ingéré, gaps détectés, état
 * du stream) ; le score et le statut sont recalculés dans `update()`.
 */
export class MarketDataHealth {
  readonly asset: string;

  private config: MarketDataHealthConfig;
  private thresholds: DynamicThresholds;

  private status: MarketDataHealthStatus = 'BOOTING';
  private lastTickAt: number | null = null;
  private lastCandleAt: number | null = null;
  private tickAgeMs: number | null = null;
  private candleAgeMs: number | null = null;

  private candleCount = 0;
  private expectedCandleCount = 0;
  private firstCandleTime: number | null = null;
  private lastCandleTime: number | null = null;

  /**
   * v6.5 — Gaps en deux niveaux :
   *   · syncGapEvents     : snapshot AUTORITAIRE de la validation du
   *     synchroniseur (série complète historique + ticks fusionnés) ;
   *   · internalGapEvents : trous détectés à la volée (delta de clôture —
   *     bord live), comblés/résolus par la prochaine validation sync.
   * Le score/statut ne dépend que des gaps RÉCENTS (fenêtre d'analyse).
   */
  private syncGapEvents: GapEvent[] = [];
  private internalGapEvents: GapEvent[] = [];
  private gapSeverity: GapSeverity = 'none';
  private recentGapCount = 0;
  private agedGapCount = 0;
  private seamGapCount = 0;
  private duplicateCount = 0;
  private outOfOrderCount = 0;

  // ── v6.5.1 — état de la COUTURE historique↔live ──────────────────────
  /** Dernière bougie (s) de l'historique le plus récemment ingéré. */
  private historyEndSec: number | null = null;
  /** Début (s) du segment live courant (null = série contiguë). */
  private seamFirstLiveSec: number | null = null;
  /** Bougies clôturées (live) dans le segment frais depuis la couture. */
  private freshCandleCount = 0;

  private currentCandleValid = true;
  private historyReady = false;
  private streamConnected: boolean;
  private healthScore = 0;
  private reasons: string[] = [];

  constructor(asset: string, config: Partial<MarketDataHealthConfig> = {}) {
    this.asset = asset;
    this.config = {
      timeframeSec: config.timeframeSec ?? 30,
      minCandles: config.minCandles ?? DEFAULT_MIN_CANDLES,
      minHealthScoreToTrade: config.minHealthScoreToTrade ?? DEFAULT_MIN_HEALTH_SCORE,
      streamConnected: config.streamConnected ?? false,
      gapAgingCandles: Math.max(10, config.gapAgingCandles ?? DEFAULT_GAP_AGING_CANDLES),
    };
    this.thresholds = computeThresholds(this.config.timeframeSec);
    this.streamConnected = this.config.streamConnected;
    this.recompute(0);
  }

  // ── Configuration ────────────────────────────────────────────────────────

  /** Change le timeframe de référence (recalcule les seuils dynamiques). */
  setTimeframeSec(timeframeSec: number): void {
    if (timeframeSec <= 0 || timeframeSec === this.config.timeframeSec) return;
    this.config.timeframeSec = timeframeSec;
    this.thresholds = computeThresholds(timeframeSec);
  }

  get timeframeSec(): number {
    return this.config.timeframeSec;
  }

  get minHealthScoreToTrade(): number {
    return this.config.minHealthScoreToTrade;
  }

  setMinHealthScoreToTrade(score: number): void {
    this.config.minHealthScoreToTrade = clamp(score, 0, 100);
  }

  /**
   * v6.5 — Fenêtre d'analyse des gaps (ms) : max(gapAgingCandles × TF, 10 min).
   * Un trou derrière cette fenêtre est vieilli (informatif, non bloquant).
   */
  get recentGapWindowMs(): number {
    return Math.max(
      this.config.gapAgingCandles * this.config.timeframeSec * 1000,
      600_000,
    );
  }

  get dynamicThresholds(): DynamicThresholds {
    return { ...this.thresholds };
  }

  // ── Points d'entrée factuels ─────────────────────────────────────────────

  /** Un tick de CET asset a été reçu (receivedAtMs = ms locaux). */
  onTick(receivedAtMs: number): void {
    this.lastTickAt = receivedAtMs;
    // Un tick vivant reconnecte implicitement le stream si l'on croyait
    // qu'il était coupé (source de vérité = les données elles-mêmes).
    if (!this.streamConnected) this.streamConnected = true;
  }

  /**
   * Une bougie CLÔTURÉE de CET asset a été observée.
   * Détecte : doublons (même timestamp), hors-ordre, gaps (timestamp
   * manquant), OHLC invalides. `nowMs` injectable pour les tests.
   */
  onCandleClosed(
    candle: { time: number; open: number; high: number; low: number; close: number },
    nowMs: number = Date.now(),
  ): void {
    if (!Number.isFinite(candle.time)) return;

    // Hors-ordre : timestamp STRICTEMENT inférieur au dernier vu.
    if (this.lastCandleTime != null && candle.time < this.lastCandleTime) {
      this.outOfOrderCount++;
      return; // une bougie retardée n'avance pas la chronologie
    }
    // Doublon : même timestamp → la bougie est corrigée/remplace, pas un gap.
    if (this.lastCandleTime != null && candle.time === this.lastCandleTime) {
      this.duplicateCount++;
    } else {
      // Gap : delta > timeframe → bougies manquantes (§11).
      if (this.lastCandleTime != null) {
        const delta = candle.time - this.lastCandleTime;
        if (delta > this.config.timeframeSec) {
          const missing = Math.max(1, Math.round(delta / this.config.timeframeSec) - 1);
          // v6.5.1 — un trou détecté à la clôture reste BLOQUANT (sévérité
          // §15) et déclenche un re-fetch de réparation côté orchestrateur
          // (scheduleGapResync). C'est la REVALIDATION du synchroniseur
          // (onSyncGaps — autorité) qui reclassera le trou en COUTURE
          // historique↔live si le broker ne peut pas le combler (le trou
          // finit alors au bord live) — jamais la détection à la volée, qui
          // ne peut pas distinguer « perte réparable » de « limite source ».
          this.internalGapEvents.push({
            count: missing,
            detectedAtMs: nowMs,
            endSec: candle.time - this.config.timeframeSec,
          });
        }
      }
      if (this.firstCandleTime == null) this.firstCandleTime = candle.time;
      this.lastCandleTime = candle.time;
      this.candleCount++;
      // v6.5.1 — comptage du segment frais (tant que la couture est active).
      if (this.seamFirstLiveSec != null && candle.time >= this.seamFirstLiveSec) {
        this.freshCandleCount++;
      }
    }

    // OHLC de la dernière bougie clôturée (§14).
    this.currentCandleValid = isCandleOhlcValid(candle);
    this.lastCandleAt = nowMs;
  }

  /**
   * Historique INGÉRÉ pour CET asset (après validation length / bornes /
   * timeframe — cf. AssetPipeline). Marque historyReady (§4).
   *
   * v6.10.1 — `deep` (pagination loadHistoryPeriod, défaut) vs snapshot fast
   * (`updateHistoryNewFast`) : la FRONTIÈRE d'historique (`historyEndSec` —
   * limite de la source profonde) ne doit être posée QUE par la pagination.
   * Le snapshot fast (~12 min de ticks) est du LIVE seedé : l'écraser avec
   * sa propre fin cassait la règle « frontière » de détection de couture
   * (startsAtHistoryBoundary) → après ré-ingestion, le trou de couture
   * n'était plus reconnu → CRITICAL_GAP massif en multi-assets.
   */
  onHistoryIngested(report: {
    closedCount: number;
    firstTimestamp: number | null;
    lastTimestamp: number | null;
    duplicateCount?: number;
    outOfOrderCount?: number;
  }, opts?: { deep?: boolean }): void {
    const deep = opts?.deep !== false; // défaut : pagination (source profonde)
    this.historyReady = report.closedCount > 0;
    this.candleCount = report.closedCount;
    this.firstCandleTime = report.firstTimestamp;
    this.lastCandleTime = report.lastTimestamp;
    // v6.5.1 — fin de l'historique ingéré : marqueur de la future couture
    // (un trou qui démarre pile après ce point = limite de la source).
    // v6.10.1 — frontière STABLE : seule la PAGINATION définit la limite
    // profonde ; le snapshot fast ne l'écrase JAMAIS (il est en aval).
    if (deep || this.historyEndSec == null) {
      this.historyEndSec = report.lastTimestamp;
    }
    if (report.duplicateCount) this.duplicateCount += report.duplicateCount;
    if (report.outOfOrderCount) this.outOfOrderCount += report.outOfOrderCount;
    // L'attendu = bougies couvrant [first, last] au pas du timeframe.
    if (report.firstTimestamp != null && report.lastTimestamp != null) {
      const span = Math.max(0, report.lastTimestamp - report.firstTimestamp);
      this.expectedCandleCount = Math.round(span / this.config.timeframeSec) + 1;
    }
    if (this.status === 'BOOTING' || this.status === 'LOADING_HISTORY') {
      this.status = this.historyReady ? 'SYNCING' : 'LOADING_HISTORY';
    }
  }

  /** Le chargement d'historique DÉMARRE (§4 → LOADING_HISTORY). */
  onHistoryLoadStart(): void {
    if (this.status === 'BOOTING') this.status = 'LOADING_HISTORY';
  }

  /**
   * v6.5 — Snapshot AUTORITAIRE des trous vu par la VALIDATION du
   * synchroniseur (série complète : historique + ticks fusionnés).
   *   · `gaps` non vide → remplace l'état sync-level ET reset les trous
   *     internes (le snapshot couvre toute la série, y compris le bord live) ;
   *   · `gaps` VIDE (validation OK « history-loaded ») → la série canonique
   *     est contiguë → TOUS les trous (sync + internes) sont résolus.
   * Chaque trou porte sa position (`startTimeSec`/`endTimeSec`) pour le
   * vieillissement.
   * v6.5.1 — Identification de la COUTURE historique↔live (bougies que le
   * broker n'a jamais servies — le flux OTC d'un symbole n'est généré que
   * lorsqu'il est actif) : un trou est une COUTURE si
   *   · il DÉMARRE à la frontière de l'historique ingéré (startTime ≈
   *     historyEnd + un timeframe — la source n'a rien au-delà), OU
   *   · il FINIT au bord live (première bougie live / bougie en formation).
   * Un trou ailleurs = vraie perte de données → sévérité graduée §15.
   * v6.10 — `firstLiveSec` (début du segment live CONTIGU, HAR fix_gaps.har) :
   * la règle « bord live » comparait la fin du trou au DERNIER tick
   * (liveEdgeSec) — un trou de plusieurs MINUTES (24 assets, historique
   * paginé lent) ne pouvait jamais matcher → faux CRITICAL_GAP massif.
   * La fin d'un trou de couture est le PREMIER bucket du segment live :
   * on compare désormais à `firstLiveSec` (fallback liveEdgeSec si absent).
   */
  onSyncGaps(
    gaps: Array<{ endTimeSec?: number; startTimeSec?: number; missingCandles: number }>,
    nowMs: number = Date.now(),
    liveEdgeSec?: number,
    firstLiveSec?: number,
  ): void {
    let newSeamSec: number | null = null;
    const tf = this.config.timeframeSec;
    this.syncGapEvents = gaps
      .filter(g => g.missingCandles > 0)
      .map(g => {
        // v6.5.1 — Règle FRONTIÈRE : le trou DÉMARRE juste après la fin de
        // l'historique PRÉCÉDEMMENT ingéré (état courant — l'ingestion en
        // cours met historyEndSec à jour APRÈS cette validation). Ces
        // bougies n'ont jamais été servies par la source → couture.
        // v6.10.1 — historyEndSec n'est plus écrasé par le snapshot fast
        // (frontière de la PAGINATION uniquement) → cette règle reste VRAIE
        // à CHAQUE ré-ingestion (reconnexion, gap-resync, repair).
        const startsAtHistoryBoundary = g.startTimeSec != null && this.historyEndSec != null
          && Math.abs(g.startTimeSec - (this.historyEndSec + tf)) <= tf;
        // v6.10 — Règle BORD LIVE (CORRIGÉE) : le trou FINIT sur la PREMIÈRE
        // bougie du segment live CONTIGU (fin du trou = début du segment de
        // ticks que le broker génère). L'ancienne comparaison au DERNIER
        // tick (liveEdgeSec) rendait la couture INDÉTECTABLE dès qu'elle
        // dépassait quelques secondes → CRITICAL_GAP erroné.
        // v6.10.1 — AMARRAGE STICKY : le buffer de ticks (4800 ≈ 40 min)
        // GLISSE en continu → firstLiveSec (buffer[0]) DÉRIVE après ~40 min
        // → à la ré-ingestion, |firstLiveSec - gap.end| dépassait la
        // tolérance → le trou de couture devenait BLOQUANT (CRITICAL_GAP
        // sur les 24 assets). Un trou qui finit À L'ENDROIT MÊME d'une
        // couture déjà mémorisée reste une couture, QUEL QUE SOIT l'état
        // du buffer vivant.
        const endsAtKnownSeam = this.seamFirstLiveSec != null && g.endTimeSec != null
          && Math.abs(this.seamFirstLiveSec - g.endTimeSec) <= tf + 1;
        // Fallback liveEdgeSec (chemin legacy 3-args — couture NAISSANTE :
        // le segment live démarre au bucket courant) — v6.10 : firstLiveSec
        // est TOUJOURS préféré (couvre les coutures de tout âge, le bord
        // live ne matchait que les coutures < 1-2 bougies).
        const liveSegmentStart = firstLiveSec != null && firstLiveSec > 0 ? firstLiveSec : liveEdgeSec;
        const endsAtLiveEdge = endsAtKnownSeam
          || (liveSegmentStart != null && liveSegmentStart > 0 && g.endTimeSec != null
              && Math.abs(liveSegmentStart - g.endTimeSec) <= tf + 1);
        const isSeam = startsAtHistoryBoundary || endsAtLiveEdge;
        if (isSeam && g.endTimeSec != null
            && (newSeamSec == null || g.endTimeSec < newSeamSec)) {
          newSeamSec = g.endTimeSec;
        }
        return {
          count: g.missingCandles,
          detectedAtMs: nowMs,
          ...(g.startTimeSec != null ? { startSec: g.startTimeSec } : {}),
          ...(g.endTimeSec != null ? { endSec: g.endTimeSec } : {}),
          ...(isSeam ? { seam: true } : {}),
        };
      });
    // Le snapshot de validation couvre la série ENTIÈRE : il remplace la
    // détection interne (un trou interne réparé depuis n'existe plus).
    this.internalGapEvents = [];
    // v6.5.1 — Autorité sur l'état de couture : la validation voit TOUTE la
    // série → si AUCUN trou n'existe, la série est contiguë (couture comblée
    // par le re-fetch) → couture résorbée ; sinon le segment frais démarre
    // à la fin du trou de couture (première bougie live après le trou).
    if (this.syncGapEvents.length === 0) {
      this.seamFirstLiveSec = null;
      this.freshCandleCount = 0;
    } else if (newSeamSec != null) {
      this.seamFirstLiveSec = this.seamFirstLiveSec != null
        ? Math.min(this.seamFirstLiveSec, newSeamSec)
        : newSeamSec;
    }
  }

  /**
   * Gaps détectés par le synchroniseur (chemin léger/legacy — sans détails
   * de position). v6.5 : enregistre un événement avec l'heure de détection
   * (vieillissement par détection en l'absence de position).
   */
  onGapsDetected(
    missingCandles: number,
    opts: { endSec?: number; detectedAtMs?: number } = {},
  ): void {
    if (missingCandles <= 0) return;
    this.internalGapEvents.push({
      count: missingCandles,
      detectedAtMs: opts.detectedAtMs ?? Date.now(),
      ...(opts.endSec != null ? { endSec: opts.endSec } : {}),
    });
  }

  /**
   * Réparation de gap aboutie → trous résorbés (recovery §15/§31).
   * Retire les événements les plus récents jusqu'à `resolvedCandles` bougies.
   */
  onGapsRepaired(resolvedCandles: number): void {
    let remaining = Math.max(0, resolvedCandles);
    const levels: Array<GapEvent[]> = [this.syncGapEvents, this.internalGapEvents];
    for (const events of levels) {
      for (let i = events.length - 1; i >= 0 && remaining > 0; i--) {
        if (events[i]!.count <= remaining) {
          remaining -= events[i]!.count;
          events.splice(i, 1);
        } else {
          events[i]!.count -= remaining;
          remaining = 0;
        }
      }
    }
  }

  /** La bougie en formation a été revalidée (formingCandle). */
  onFormingCandleValid(valid: boolean): void {
    this.currentCandleValid = valid;
  }

  /** État de la connexion stream POUR CET ASSET (§10 streamConnected). */
  onStreamState(connected: boolean): void {
    this.streamConnected = connected;
  }

  // ── Calcul ───────────────────────────────────────────────────────────────

  /** Recalcule âges / sévérité / score / statut. Appelé avant chaque usage. */
  update(nowMs: number = Date.now()): MarketDataHealthState {
    this.recompute(nowMs);
    return this.getSnapshot(nowMs);
  }

  private recompute(nowMs: number): void {
    const reasons: string[] = [];
    let score = 100;

    this.tickAgeMs = this.lastTickAt != null ? Math.max(0, nowMs - this.lastTickAt) : null;
    this.candleAgeMs = this.lastCandleAt != null ? Math.max(0, nowMs - this.lastCandleAt) : null;

    // ── v6.5 : classement des gaps récents / vieillis (fenêtre d'analyse) ──
    // Un trou est RÉCENT si sa FIN est dans la fenêtre d'analyse (~100
    // bougies derrière le bord live) — c'est la ZONE que les stratégies
    // lisent. Sans position connue, on vieillit par l'heure de détection.
    const windowSec = this.recentGapWindowMs / 1000;
    const liveEdgeSec = this.lastCandleTime ?? null;
    const isRecent = (e: GapEvent): boolean => {
      if (e.endSec != null && liveEdgeSec != null && liveEdgeSec > 0) {
        return (liveEdgeSec - e.endSec) < windowSec;
      }
      return (nowMs - e.detectedAtMs) < windowSec * 1000;
    };
    const allEvents = [...this.syncGapEvents, ...this.internalGapEvents];
    const totalGaps = allEvents.reduce((a, e) => a + e.count, 0);
    const recentEvents = allEvents.filter(isRecent);
    const recentGaps = recentEvents.reduce((a, e) => a + e.count, 0);
    // v6.5.1 — séparation couture (limite de source, non bloquante) /
    // trous bloquants (vraies pertes de données dans la fenêtre d'analyse).
    const seamGaps = recentEvents.filter(e => e.seam).reduce((a, e) => a + e.count, 0);
    const blockingGaps = recentGaps - seamGaps;
    this.recentGapCount = recentGaps;
    this.seamGapCount = seamGaps;
    this.agedGapCount = Math.max(0, totalGaps - recentGaps);

    // v6.5.1 — vieillissement de la COUTURE : quand le segment frais a glissé
    // hors de la fenêtre d'analyse, la couture sort de la zone lue → purge
    // (les lectures d'analyse redeviennent la fenêtre standard).
    if (this.seamFirstLiveSec != null && liveEdgeSec != null
        && liveEdgeSec - this.seamFirstLiveSec > windowSec + this.config.timeframeSec) {
      this.seamFirstLiveSec = null;
      this.freshCandleCount = 0;
    }

    // ── Connexion stream (§10) — BLOCAGE net ─────────────────────────────
    if (!this.streamConnected) {
      reasons.push('stream disconnected');
      score = Math.min(score, 5);
      this.status = 'DISCONNECTED';
      this.apply(score, reasons);
      return;
    }

    // ── Historique (§4) — BLOCAGE tant que non chargé ────────────────────
    if (!this.historyReady) {
      reasons.push('history not loaded');
      score = Math.min(score, this.status === 'BOOTING' ? 10 : 25);
      if (this.status !== 'LOADING_HISTORY' && this.status !== 'SYNCING') {
        this.status = this.candleCount > 0 ? 'SYNCING' : 'LOADING_HISTORY';
      }
      this.apply(score, reasons);
      return;
    }

    // ── Fraîcheur du tick (§12 — seuils dynamiques) ──────────────────────
    const tickStale = this.tickAgeMs == null || this.tickAgeMs > this.thresholds.tickStaleMs;
    const tickWarn = this.tickAgeMs != null && this.tickAgeMs > this.thresholds.tickWarnMs;
    if (this.tickAgeMs == null) {
      reasons.push('no tick received');
      score -= 35;
    } else if (tickStale) {
      reasons.push(`stale tick (${(this.tickAgeMs / 1000).toFixed(1)}s > ${(this.thresholds.tickStaleMs / 1000).toFixed(0)}s)`);
      score -= 35;
    } else if (tickWarn) {
      reasons.push(`tick age warning (${(this.tickAgeMs / 1000).toFixed(1)}s)`);
      score -= 12;
    }

    // ── Fraîcheur de la dernière bougie (§12) ────────────────────────────
    const candleStale = this.candleAgeMs != null && this.candleAgeMs > this.thresholds.candleStaleMs;
    const candleWarn = this.candleAgeMs != null && this.candleAgeMs > this.thresholds.candleWarnMs;
    if (this.candleAgeMs == null) {
      reasons.push('no closed candle yet');
      score -= 20;
    } else if (candleStale) {
      reasons.push(`stale candle (${(this.candleAgeMs / 1000).toFixed(1)}s > ${(this.thresholds.candleStaleMs / 1000).toFixed(0)}s)`);
      score -= 25;
    } else if (candleWarn) {
      reasons.push(`candle age warning (${(this.candleAgeMs / 1000).toFixed(1)}s)`);
      score -= 10;
    }

    // ── Gaps (§11/§15 — sévérité graduée, OBSERVABLE depuis v6.11 : pénalité
    //    de score plafonnée pour préserver un badge DEGRADED informatif,
    //    JAMAIS de blocage de trading ; v6.5.1 : les trous de COUTURE
    //    historique↔live sont signalés mais ne pénalisent pas) ──
    if (blockingGaps <= 0) {
      this.gapSeverity = 'none';
    } else if (blockingGaps === 1) {
      this.gapSeverity = 'light';
      reasons.push('1 candle gap detected');
      score -= 8;
    } else if (blockingGaps <= 5) {
      this.gapSeverity = 'medium';
      reasons.push(`${blockingGaps} candle gaps detected`);
      score -= 18;
    } else {
      this.gapSeverity = 'critical';
      reasons.push(`critical candle gaps (${blockingGaps}) — informational, trading NOT blocked (v6.11)`);
      // v6.11 — pénalité PLAFONNÉE (− 18, niveau « medium ») : les trous
      // critiques restent visibles (reason + statut GAP) mais ne poussent
      // plus le score sous le seuil DEGRADED par eux-mêmes.
      score -= 18;
    }
    // Trou(s) vieilli(s) : signalés (jamais masqués §11), non pénalisants —
    // hors de la fenêtre que lisent les stratégies.
    if (this.agedGapCount > 0) {
      reasons.push(`${this.agedGapCount} aged gap(s) outside analysis window (informational)`);
    }
    // v6.5.1 — Couture historique↔live : signalée (§11 — jamais masquée),
    // non pénalisante (limite de la source ; v6.11 : les lectures d'analyse
    // lisent la série canonique complète, comme le graphique).
    if (seamGaps > 0) {
      reasons.push(`history-live seam: ${seamGaps} candle(s) never served by source (informational)`);
    }

    // ── Intégrité de série : doublons / ordre / OHLC (§10/§14) ───────────
    if (this.duplicateCount > 0) {
      reasons.push(`${this.duplicateCount} duplicate candle timestamp(s)`);
      score -= Math.min(12, this.duplicateCount * 4);
    }
    if (this.outOfOrderCount > 0) {
      reasons.push(`${this.outOfOrderCount} out-of-order timestamp(s)`);
      score -= Math.min(15, this.outOfOrderCount * 5);
    }
    if (!this.currentCandleValid) {
      reasons.push('invalid OHLC on latest candle');
      score -= 25;
    }

    // ── Profondeur d'historique (§14 : candleCount suffisante) ───────────
    // v6.11 — COMPTAGE PLEINE SÉRIE : la profondeur se mesure sur TOUTE la
    // série canonique (historique + live fusionnés). L'ancien comptage
    // « frais depuis la couture » (v6.5.1) exigeait minCandles bougies
    // ADDITIONNELLES après une couture qui se ré-armait à CHAQUE
    // ré-ingestion (reconnexion / gap-resync / repair) → en multi-assets,
    // l'asset restait INSUFFICIENT_CANDLES indéfiniment.
    const effectiveCandles = this.candleCount;
    if (effectiveCandles < this.config.minCandles) {
      const ratio = effectiveCandles / Math.max(1, this.config.minCandles);
      const penalty = Math.round(25 * (1 - clamp(ratio, 0, 1)));
      reasons.push(`insufficient candle count (${effectiveCandles}/${this.config.minCandles})`);
      score -= penalty;
    }

    score = clamp(Math.round(score), 0, 100);

    // ── Statut final (précédence : INVALID > GAP critique > STALE >
    //    GAP > SYNCING > READY) — v6.5 : GAP uniquement pour un trou RÉCENT. ──
    let status: MarketDataHealthStatus;
    if (!this.currentCandleValid) {
      status = 'INVALID';
    } else if (this.gapSeverity === 'critical') {
      status = 'GAP';
    } else if (tickStale || candleStale) {
      status = 'STALE';
    } else if (this.gapSeverity !== 'none') {
      status = 'GAP';
    } else if (this.status === 'SYNCING' && score >= 80) {
      status = 'READY';
    } else if (this.status === 'SYNCING' || this.status === 'LOADING_HISTORY') {
      status = this.historyReady ? 'SYNCING' : 'LOADING_HISTORY';
    } else {
      status = 'READY';
    }
    this.status = status;
    this.apply(score, reasons);
  }

  private apply(score: number, reasons: string[]): void {
    this.healthScore = clamp(Math.round(score), 0, 100);
    this.reasons = reasons;
  }

  // ── Décision de trading (§13/§14 — v6.11 : GATING STRUCTUREL) ───────────

  /**
   * CHAQUE stratégie doit appeler canTrade() AVANT de produire
   * CALL/PUT/BUY/SELL. Retourne un résultat explicite.
   *
   * v6.11 — POLITIQUE STRUCTURELLE : la décision ne bloque PLUS que sur des
   * conditions qui rendent l'évaluation FACTUELLEMENT impossible :
   *   1. STREAM_DISCONNECTED — transport coupé ;
   *   2. HISTORY_NOT_READY   — aucune donnée ingérée ;
   *   3. INSUFFICIENT_CANDLES — moins de minCandles bougies dans TOUTE la
   *      série canonique (pleine série — l'historique paginé/snapshot compte) ;
   *   4. STREAM_STALE — aucun tick depuis `streamDeadMs` (10 × timeframe,
   *      plancher 60 s) : filet anti flux zombie (transport vivant, source
   *      morte — ex. marché fermé, symbole désactivé côté broker).
   *
   * Les trous (TOUTES sévérités, y compris critiques), la staleness LÉGÈRE
   * (< streamDeadMs), les doublons, l'OHLC et le score ne bloquent PLUS le
   * trading : ils restent OBSERVABLES (score, reasons, badge, journal) et la
   * profondeur requise par CHAQUE stratégie reste gérée par ELLE-MÊME.
   * C'est ce qui garantit qu'aucune carte multi-assets n'affiche plus
   * « TRADING BLOQUÉ — CRITICAL_GAP » sur des micro-pertes de données
   * constitutives des flux OTC multi-assets.
   */
  canTrade(nowMs: number = Date.now()): HealthCheckResult {
    this.recompute(nowMs);
    const base: HealthCheckResult = {
      allowed: false,
      score: this.healthScore,
      status: this.status,
      reasons: [...this.reasons],
    };

    // 1. Structure : le flux est-il transporté ?
    if (!this.streamConnected) {
      return { ...base, reason: 'STREAM_DISCONNECTED' };
    }
    // 2. Structure : existe-t-il des données ?
    if (!this.historyReady) {
      return { ...base, reason: 'HISTORY_NOT_READY' };
    }
    // 3. Structure : la profondeur minimale (PLEINE SÉRIE) est-elle là ?
    if (this.candleCount < this.config.minCandles) {
      return { ...base, reason: 'INSUFFICIENT_CANDLES' };
    }
    // 4. Filet anti flux zombie : plus AUCUN tick depuis 10 × timeframe.
    //    (La staleness LÉGÈRE — jitter multi-assets, rafales, throttling —
    //    reste un simple avertissement de score.)
    if (this.tickAgeMs == null || this.tickAgeMs > this.streamDeadMs) {
      return { ...base, reason: 'STREAM_STALE' };
    }
    // v6.11 — tout le reste (gaps critiques, staleness léger, doublons,
    // OHLC, score) est OBSERVABLE et NON BLOQUANT. Les raisons restent
    // disponibles dans `reasons` pour l'UI et le journal (§28).
    return { ...base, allowed: true };
  }

  /**
   * v6.11 — Seuil de MORT du flux (ms) : 10 × timeframe, plancher 60 s.
   * Au-delà, le flux est considéré ZOMBIE (source morte) → STREAM_STALE.
   * En deçà, l'âge du tick reste un simple signal de qualité (score).
   */
  get streamDeadMs(): number {
    return Math.max(this.config.timeframeSec * 10 * 1000, 60_000);
  }

  /** Le trading est-il autorisé (raccourci booléen) ? */
  isTradable(nowMs: number = Date.now()): boolean {
    return this.canTrade(nowMs).allowed;
  }

  /** Sévérité courante des gaps. */
  get gapSeverityLevel(): GapSeverity {
    return this.gapSeverity;
  }

  /**
   * v6.5.1 — Début (s) du segment live courant quand une couture
   * historique↔live est active (null = série contiguë). Les lectures
   * d'analyse (stratégies, coach, indicateurs) ne remontent JAMAIS
   * au-delà tant que la couture est dans la fenêtre d'analyse.
   */
  get liveSeamFirstSec(): number | null {
    return this.seamFirstLiveSec;
  }

  /** v6.5.1 — Bougies clôturées dans le segment frais (couture active). */
  get freshClosedCandleCount(): number {
    return this.seamFirstLiveSec != null ? this.freshCandleCount : this.candleCount;
  }

  /**
   * v6.10.1 — RECOMPTE RÉTROACTIF des bougies fraîches depuis la couture.
   *
   * La couture n'est détectée qu'à l'ARRIVÉE de la validation paginée —
   * potentiellement plusieurs MINUTES après le début du segment live (file
   * de concurrence 4 × 24 assets). Or `freshCandleCount` n'incrémentait
   * qu'à partir de l'ACTIVATION de la couture (onCandleClosed) → toutes les
   * bougies live clôturées AVANT la détection étaient PERDUES pour le
   * warm-up → INSUFFICIENT_CANDLES artificiellement prolongé (jusqu'à
   * minCandles × timeframe en plus).
   *
   * Appelé par l'orchestrateur après `onSyncGaps` avec les bougies
   * CLÔTURÉES de la série canonique de l'asset (timeframe graphique).
   */
  recountFreshCandles(closedCandles: ReadonlyArray<{ time: number }>): void {
    if (this.seamFirstLiveSec == null) return;
    const seam = this.seamFirstLiveSec;
    let n = 0;
    for (const c of closedCandles) {
      if (c.time >= seam) n++;
    }
    if (n > this.freshCandleCount) this.freshCandleCount = n;
  }

  // ── Sorties ──────────────────────────────────────────────────────────────

  getSnapshot(nowMs: number = Date.now()): MarketDataHealthState {
    const tickAgeMs = this.lastTickAt != null ? Math.max(0, nowMs - this.lastTickAt) : null;
    const candleAgeMs = this.lastCandleAt != null ? Math.max(0, nowMs - this.lastCandleAt) : null;
    return {
      asset: this.asset,
      status: this.status,
      lastTickAt: this.lastTickAt,
      lastCandleAt: this.lastCandleAt,
      tickAgeMs,
      candleAgeMs,
      candleCount: this.candleCount,
      expectedCandleCount: this.expectedCandleCount,
      gapCount: this.recentGapCount + this.agedGapCount,
      recentGapCount: this.recentGapCount,
      agedGapCount: this.agedGapCount,
      seamGapCount: this.seamGapCount,
      seamFirstLiveSec: this.seamFirstLiveSec,
      duplicateCount: this.duplicateCount,
      outOfOrderCount: this.outOfOrderCount,
      timeframeSec: this.config.timeframeSec,
      currentCandleValid: this.currentCandleValid,
      historyReady: this.historyReady,
      streamConnected: this.streamConnected,
      healthScore: this.healthScore,
      reasons: [...this.reasons],
    };
  }

  /**
   * Diagnostic lisible par asset (§19) :
   *   EURUSD — Ticks: LIVE · Last Tick: 120ms · Candles: 100 · ...
   */
  getDiagnostic(nowMs: number = Date.now()): string {
    const s = this.getSnapshot(nowMs);
    const tickInfo = s.tickAgeMs == null
      ? 'NEVER'
      : s.tickAgeMs > this.thresholds.tickStaleMs ? `STALE ${fmt(s.tickAgeMs)}` : `LIVE ${fmt(s.tickAgeMs)}`;
    const candleInfo = s.candleAgeMs == null
      ? 'NEVER'
      : s.candleAgeMs > this.thresholds.candleStaleMs ? `STALE ${fmt(s.candleAgeMs)}` : `FRESH ${fmt(s.candleAgeMs)}`;
    const trading = this.canTrade(nowMs).allowed ? 'ENABLED' : 'BLOCKED';
    const lines = [
      `${this.asset}`,
      '──────────────',
      `Ticks:        ${tickInfo}`,
      `Candles:      ${s.candleCount}${s.expectedCandleCount ? `/${s.expectedCandleCount}` : ''}`,
      `Last Candle:  ${candleInfo}`,
      `Gaps:         ${s.gapCount} (récents: ${s.recentGapCount} · vieillis: ${s.agedGapCount} · couture: ${s.seamGapCount})`,
      `Duplicates:   ${s.duplicateCount}`,
      `OutOfOrder:   ${s.outOfOrderCount}`,
      `Timeframe:    S${s.timeframeSec}`,
      `History:      ${s.historyReady ? 'READY' : 'LOADING'}`,
      `Stream:       ${s.streamConnected ? 'CONNECTED' : 'DISCONNECTED'}`,
      `Seam:         ${s.seamFirstLiveSec != null ? `active @ ${new Date(s.seamFirstLiveSec * 1000).toISOString()} (lectures coupées)` : 'none'}`,
      `Health:       ${s.healthScore}/100 (${s.status})`,
      `Trading:      ${trading}`,
    ];
    if (s.reasons.length > 0) {
      lines.push('Reason:');
      for (const r of s.reasons) lines.push(`  - ${r}`);
    }
    return lines.join('\n');
  }
}

function fmt(ms: number): string {
  if (ms < 1000) return `${Math.round(ms)}ms`;
  return `${(ms / 1000).toFixed(1)}s`;
}

// ─────────────────────────────────────────────────────────────────────────────
// Fabrique + helpers de statut dérivés pour l'UI (§27)
// ─────────────────────────────────────────────────────────────────────────────

export type UiHealthBadge = 'LIVE' | 'DEGRADED' | 'BLOCKED';

/**
 * Badge UI dérivé (§27 — bandes de SCORE + verdict canTrade) :
 *   BLOCKED  : trading non autorisé (canTrade() = false) ou état
 *              DISCONNECTED/INVALID — la cause précise est dans `reasons` ;
 *   LIVE     : trading autorisé ET score ≥ seuil (80) — l'asset est sain ET
 *              tradable (un léger gap récent -8 ne descend pas sous 80) ;
 *   DEGRADED : trading autorisé mais score < seuil — données affaiblies.
 * v6.5 : LIVE n'exige PLUS le statut READY — un asset AUTORISÉ avec un score
 * ≥ seuil est vivant et tradable ; le statut détaillé (GAP/STALE…) reste
 * visible dans le tooltip et les diagnostics (§19).
 */
export function healthBadge(state: MarketDataHealthState, tradeAllowed: boolean, minScore = 80): UiHealthBadge {
  if (!tradeAllowed || state.status === 'DISCONNECTED' || state.status === 'INVALID') return 'BLOCKED';
  if (state.healthScore >= minScore) return 'LIVE';
  return 'DEGRADED';
}
