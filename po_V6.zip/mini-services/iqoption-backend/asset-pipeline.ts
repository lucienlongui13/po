/**
 * asset-pipeline.ts — PIPELINE DE DÉCISION INDÉPENDANT PAR ASSET.
 * ====================================================================
 *
 * CŒUR de l'architecture multi-assets v6.4 (cahier des charges §1-§3) :
 * chaque asset sélectionné possède son PROPRE pipeline (candles + santé des
 * données + snapshot synchronisé). AUCUN composant ne dépend de l'asset
 * « focus » — le focus n'existe que pour l'AFFICHAGE (UI).
 *
 * Composition d'un AssetPipeline :
 *   - candleStore / candleSync : la vue PAR ASSET du CandleSyncManager ;
 *   - marketDataHealth : MarketDataHealth DÉDIÉ (§9-§12) ;
 *   - strategyContext : AssetTradingContext existant (mises, stats — déjà
 *     isolés par asset) ;
 *   - lastDecision / lastTickAt / lastClosedCandleAt.
 *
 * Module PUR (aucune dépendance socket/io) — testable isolément.
 */

import {
  MarketDataHealth,
  type MarketDataHealthState,
  type HealthCheckResult,
} from './market-data-health.js';
import type { CandleSyncManager, TickIngestResult } from './candle-sync-manager.js';
import type { AssetTradingContext } from './asset-contexts.js';
import type { CandleLike } from './candle-builder.js';

// ─────────────────────────────────────────────────────────────────────────────
// Tick / Candle contracts
// ─────────────────────────────────────────────────────────────────────────────

/** Tick normalisé entrant (§3) — asset OBLIGATOIRE. */
export interface PipelineTick {
  asset: string;
  price: number;
  /** Temps MARCHÉ (secondes, sous-seconde possible). */
  marketTimeSec: number;
  /** Temps local de réception (ms). */
  receivedAtMs?: number;
}

/** Bougie clôturée observée (§16 — jamais la bougie en formation). */
export interface PipelineClosedCandle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

export interface PipelineTickResult {
  asset: string;
  /** Résultat de l'ingestion dans le CandleSyncManager de CET asset. */
  ingest: TickIngestResult | null;
  /** Santé recalculée après le tick. */
  health: MarketDataHealthState;
}

// ─────────────────────────────────────────────────────────────────────────────
// MarketDecisionSnapshot (§17/§18)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Snapshot SYNCHRONISÉ construit avant CHAQUE décision (§17).
 *
 * Toutes les stratégies reçoivent CE snapshot : elles décident donc sur le
 * MÊME instant de marché. `generatedAt` (ms locaux) + `marketTimestamp`
 * (temps marché) permettent de vérifier la cohérence (§18 — anti
 * race-condition : toutes les stratégies lisent la même version des bougies).
 */
export interface MarketDecisionSnapshot {
  asset: string;
  /** Date de construction (ms locaux). */
  generatedAt: number;
  /** Dernier temps MARCHÉ connu (s) du snapshot. */
  marketTimestamp: number;
  /** Timeframe de référence (s). */
  timeframeSec: number;

  /** Bougies CLÔTURÉES du timeframe graphique (les plus récentes d'abord ? non : ordre chronologique). */
  candles: CandleLike[];
  lastClosedCandle: CandleLike | null;
  formingCandle: CandleLike | null;

  /** Indicateurs calculés SUR LES BOUGIES DU SNAPSHOT (même instant). */
  indicators: SnapshotIndicators;

  /** Santé des données de CET asset au moment du snapshot (§17). */
  marketDataHealth: MarketDataHealthState;

  /** Verdict de trading recalculé au snapshot (§13/§14). */
  tradingCheck: HealthCheckResult;

  /** Contexte de stratégie existant de CET asset (mises, stats). */
  strategyContext: AssetTradingContext | null;
}

export interface SnapshotIndicators {
  ema9: number | null;
  ema21: number | null;
  ema50: number | null;
  rsi14: number | null;
  trend: 'bullish' | 'bearish' | 'ranging';
  lastClose: number | null;
}

// ─────────────────────────────────────────────────────────────────────────────
// Assertions d'isolation (§29)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * assert(context.asset === tick.asset) — toute violation génère une erreur
 * explicite : [ASSET-CONTEXT-VIOLATION] expected=EURUSD received=GBPJPY
 */
export function assertAssetMatch(component: string, expected: string, received: string): void {
  if (expected !== received) {
    throw new Error(`[ASSET-CONTEXT-VIOLATION] ${component}: expected=${expected} received=${received}`);
  }
}

/** Vérifie qu'un snapshot appartient bien à l'asset attendu (§18/§29). */
export function assertSnapshotAsset(snapshot: MarketDecisionSnapshot, asset: string, component: string): void {
  assertAssetMatch(`Snapshot:${component}`, asset, snapshot.asset);
}

// ─────────────────────────────────────────────────────────────────────────────
// AssetPipeline (§2)
// ─────────────────────────────────────────────────────────────────────────────

export interface AssetPipelineDeps {
  /** Synchroniseur partagé (UNE connexion réseau §22 — données séparées PAR asset). */
  candleSync: CandleSyncManager;
  /** Timeframe graphique courant (s) — résolu dynamiquement. */
  timeframeSec: () => number;
  /** Contexte de stratégie existant (registry par asset) — optionnel. */
  strategyContext?: AssetTradingContext | null;
  /** Score minimal pour trader (§14 — configurable, défaut 80). */
  minHealthScoreToTrade?: number;
  /** Nombre minimal de bougies clôturées (§14). */
  minCandles?: number;
}

/**
 * Pipeline complet d'UN asset : données + moteurs + santé.
 * Aucune méthode ne lit les données d'un autre asset ; toute donnée
 * étrangère lève une AssetContextViolationError (§29).
 */
export class AssetPipeline {
  readonly asset: string;

  /** Synchroniseur (données séparées par asset à l'intérieur). */
  readonly candleSync: CandleSyncManager;

  /** Santé des données de CET asset (§9). */
  readonly marketDataHealth: MarketDataHealth;

  /** Contexte de stratégie existant (mises, stats). */
  strategyContext: AssetTradingContext | null;

  private readonly timeframeSecResolver: () => number;

  lastDecision: unknown = null;
  lastTickAt: number | null = null;
  lastClosedCandleAt: number | null = null;

  constructor(asset: string, deps: AssetPipelineDeps) {
    this.asset = asset;
    this.candleSync = deps.candleSync;
    this.strategyContext = deps.strategyContext ?? null;
    this.timeframeSecResolver = deps.timeframeSec;
    this.marketDataHealth = new MarketDataHealth(asset, {
      timeframeSec: deps.timeframeSec(),
      minHealthScoreToTrade: deps.minHealthScoreToTrade ?? 80,
      minCandles: deps.minCandles ?? 25,
    });
  }

  // ── Flux live (§3) ───────────────────────────────────────────────────────

  /**
   * Traite UN tick DE CET ASSET : santé → candleSync.
   * (L'évaluation des stratégies est pilotée par les callbacks de clôture et
   *   par l'orchestrateur serveur — elle lit exclusivement CET asset.)
   */
  processTick(tick: PipelineTick): PipelineTickResult {
    assertAssetMatch('AssetPipeline.processTick', this.asset, tick.asset); // §29
    const receivedAtMs = tick.receivedAtMs ?? Date.now();

    // 1. Santé : le tick vient d'arriver (fraîcheur §12).
    this.marketDataHealth.onTick(receivedAtMs);
    this.lastTickAt = receivedAtMs;

    // 2. Synchroniseur : le tick nourrit la série canonique DE CET asset.
    let ingest: TickIngestResult | null = null;
    try {
      ingest = this.candleSync.ingestTick(this.asset, {
        marketTimeSec: tick.marketTimeSec,
        price: tick.price,
        receivedAtMs,
      });
    } catch {
      ingest = null; // le sync manager peut rejeter (hors contexte) — santé le reflète
    }

    return {
      asset: this.asset,
      ingest,
      health: this.marketDataHealth.update(receivedAtMs),
    };
  }

  /**
   * Traite UNE bougie CLÔTURÉE DE CET ASSET : santé + chronologie.
   * (Le seed d'historique passe par processHistory.)
   */
  processCandle(candle: PipelineClosedCandle, nowMs: number = Date.now()): MarketDataHealthState {
    this.marketDataHealth.onCandleClosed(candle, nowMs);
    this.lastClosedCandleAt = nowMs;
    return this.marketDataHealth.update(nowMs);
  }

  /**
   * Ingestion d'un historique VALIDÉ (§4) : marque historyReady pour CET
   * ASSET (§5).
   *
   * v6.10.1 — `opts.deep` (défaut true) : source = pagination profonde
   * (loadHistoryPeriod) → pose la frontière d'historique STABLE.
   * `deep: false` = snapshot fast (updateHistoryNewFast) → NE pose PAS la
   * frontière (le snapshot est du live seedé — cf. MarketDataHealth).
   */
  processHistory(
    report: {
      candles: Array<{ time: number; open: number; high: number; low: number; close: number; volume: number }>;
      firstTimestamp: number | null;
      lastTimestamp: number | null;
    },
    opts?: { deep?: boolean },
  ): void {
    this.marketDataHealth.onHistoryIngested({
      closedCount: report.candles.length,
      firstTimestamp: report.firstTimestamp,
      lastTimestamp: report.lastTimestamp,
    }, opts);
  }

  // ── Lecture isolée (§16 — bougie clôturée ≠ bougie en formation) ─────────

  /**
   * v6.5.1 — Début du segment d'ANALYSE (s) : quand une couture
   * historique↔live est active, ce marqueur reste disponible à titre
   * DIAGNOSTIQUE (badge/reasons de santé). v6.11 : il ne TRONQUE PLUS les
   * lectures — les stratégies lisent la série canonique complète, comme le
   * graphique (l'ancienne truncature laissait les stratégies sur ~20
   * bougies après la couture → leur warm-up n'était jamais satisfait →
   * aucune stratégie ne tradait en multi-assets).
   */
  get analysisStartSec(): number | null {
    return this.marketDataHealth.liveSeamFirstSec;
  }

  /**
   * N dernières bougies CLÔTURÉES de CET asset (timeframe courant).
   * v6.11 — SÉRIE CANONIQUE COMPLÈTE : la lecture n'est PLUS tronquée à la
   * couture historique↔live. Les flux OTC concatènent naturellement des
   * segments que la source n'a jamais servis (symbole inactif) — le
   * graphique affiche exactement cette série fusionnée, et c'est ELLE que
   * les stratégies analysent (comportement identique au mode mono-asset,
   * qui n'a jamais eu de couture). La couture reste SIGNALÉE par la santé
   * (seamGapCount, reasons) sans couper les lectures.
   */
  getLastClosedCandles(n: number, timeframeSec = this.timeframeSecResolver()): CandleLike[] {
    return this.candleSync.getClosed(this.asset, timeframeSec, n) as CandleLike[];
  }

  /** Bougie en FORMATION de CET asset (jamais traitée comme clôturée). */
  getFormingCandle(timeframeSec = this.timeframeSecResolver()): CandleLike | null {
    return this.candleSync.getForming(this.asset, timeframeSec) as CandleLike | null;
  }

  /** Série complète (clôturées + forming) de CET asset. */
  getAllCandles(timeframeSec = this.timeframeSecResolver()): CandleLike[] {
    return this.candleSync.getAllCandles(this.asset, timeframeSec) as CandleLike[];
  }

  // ── Santé (§13) ──────────────────────────────────────────────────────────

  /** Verdict de trading — CHAQUE stratégie doit le consulter AVANT de trader. */
  canTrade(nowMs: number = Date.now()): HealthCheckResult {
    return this.marketDataHealth.canTrade(nowMs);
  }

  getHealth(nowMs: number = Date.now()): MarketDataHealthState {
    return this.marketDataHealth.update(nowMs);
  }

  /** Diagnostic lisible (§19). */
  getDiagnostic(nowMs: number = Date.now()): string {
    return this.marketDataHealth.getDiagnostic(nowMs);
  }

  // ── Snapshot synchronisé (§17/§18) ───────────────────────────────────────

  /**
   * Construit le MarketDecisionSnapshot : TOUTES les stratégies qui le
   * reçoivent décident sur le MÊME instant de marché.
   */
  buildSnapshot(): MarketDecisionSnapshot {
    const timeframeSec = this.timeframeSecResolver();
    const closed = this.getLastClosedCandles(100, timeframeSec);
    const forming = this.getFormingCandle(timeframeSec);
    const lastClosed = closed.length > 0 ? closed[closed.length - 1] : null;

    const tradingCheck = this.marketDataHealth.canTrade();
    const now = Date.now();

    return {
      asset: this.asset,
      generatedAt: now,
      marketTimestamp: this.candleSync.getLatestMarketTimeSec(this.asset),
      timeframeSec,
      candles: closed,
      lastClosedCandle: lastClosed,
      formingCandle: forming,
      indicators: computeSnapshotIndicators([...closed, ...(forming ? [forming] : [])]),
      marketDataHealth: this.marketDataHealth.getSnapshot(now),
      tradingCheck,
      strategyContext: this.strategyContext,
    };
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Indicateurs du snapshot (même instant pour tous les consommateurs §18)
// ─────────────────────────────────────────────────────────────────────────────

function computeSnapshotIndicators(candles: CandleLike[]): SnapshotIndicators {
  if (candles.length === 0) {
    return { ema9: null, ema21: null, ema50: null, rsi14: null, trend: 'ranging', lastClose: null };
  }
  const closes = candles.map(c => c.close);
  const lastClose = closes[closes.length - 1];

  const calcEma = (period: number): number | null => {
    if (closes.length < period) return null;
    const k = 2 / (period + 1);
    let e = closes[0];
    for (let i = 1; i < closes.length; i++) e = closes[i] * k + e * (1 - k);
    return e;
  };
  const ema9 = calcEma(9);
  const ema21 = calcEma(21);
  const ema50 = closes.length >= 50 ? calcEma(50) : ema21;

  let rsi14: number | null = null;
  if (closes.length >= 15) {
    let gain = 0;
    let loss = 0;
    for (let i = closes.length - 14; i < closes.length; i++) {
      const d = closes[i] - closes[i - 1];
      if (d > 0) gain += d; else loss -= d;
    }
    const avgGain = gain / 14;
    const avgLoss = loss / 14;
    rsi14 = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  }

  let trend: SnapshotIndicators['trend'] = 'ranging';
  if (ema9 != null && ema21 != null) {
    const diff = (lastClose - ema21) / ema21;
    if (diff > 0.0002) trend = 'bullish';
    else if (diff < -0.0002) trend = 'bearish';
  }

  return { ema9, ema21, ema50, rsi14, trend, lastClose };
}

// ─────────────────────────────────────────────────────────────────────────────
// AssetPipelineManager (§2)
// ─────────────────────────────────────────────────────────────────────────────

export interface AssetPipelineManagerDeps extends Omit<AssetPipelineDeps, 'strategyContext'> {
  /**
   * Résolution du contexte de stratégie par asset (ex. registry.getAssetContext).
   * Retourne null si l'asset n'est pas sélectionné — le pipeline n'est alors
   * PAS créé (isolation §6 : un tick d'un asset non sélectionné est ignoré).
   */
  resolveStrategyContext?: (asset: string) => AssetTradingContext | null;
  /** Autorise la création automatique de pipeline (défaut : non, §6). */
  autoCreate?: boolean;
}

/**
 * Gestionnaire central des pipelines par asset.
 *
 *   getOrCreate(asset) · remove(asset) · has(asset) · getAll() ·
 *   processTick(asset, tick) · processCandle(asset, candle) ·
 *   getHealth(asset)
 *
 * Ne contient AUCUNE logique de trading (§23) — uniquement du routage et
 * de la gestion de cycle de vie.
 */
export class AssetPipelineManager {
  private pipelines = new Map<string, AssetPipeline>();
  private readonly deps: AssetPipelineManagerDeps;

  constructor(deps: AssetPipelineManagerDeps) {
    this.deps = deps;
  }

  /** Pipeline de l'asset — créé si un contexte de stratégie existe (§6). */
  getOrCreate(asset: string): AssetPipeline {
    assertIsAssetName(asset);
    let pipeline = this.pipelines.get(asset);
    if (!pipeline) {
      const strategyContext = this.deps.resolveStrategyContext?.(asset) ?? null;
      pipeline = new AssetPipeline(asset, {
        candleSync: this.deps.candleSync,
        timeframeSec: this.deps.timeframeSec,
        strategyContext,
        minHealthScoreToTrade: this.deps.minHealthScoreToTrade,
        minCandles: this.deps.minCandles,
      });
      this.pipelines.set(asset, pipeline);
    }
    return pipeline;
  }

  /** Pipeline existant uniquement (null sinon — pas de création). */
  get(asset: string): AssetPipeline | null {
    return this.pipelines.get(asset) ?? null;
  }

  has(asset: string): boolean {
    return this.pipelines.has(asset);
  }

  getAll(): AssetPipeline[] {
    return [...this.pipelines.values()];
  }

  assets(): string[] {
    return [...this.pipelines.keys()];
  }

  get size(): number {
    return this.pipelines.size;
  }

  /**
   * Supprime le pipeline d'un asset (§30 — arrêt d'un asset) : libère le
   * contexte de stratégie et la santé. N'affecte JAMAIS les
   * autres pipelines.
   */
  remove(asset: string): boolean {
    const pipeline = this.pipelines.get(asset);
    if (!pipeline) return false;
    this.pipelines.delete(asset);
    return true;
  }

  /** Supprime tous les pipelines SAUF ceux listés (déselection en masse). */
  retainOnly(assets: string[]): void {
    const keep = new Set(assets);
    for (const asset of [...this.pipelines.keys()]) {
      if (!keep.has(asset)) this.remove(asset);
    }
  }

  clear(): void {
    for (const asset of [...this.pipelines.keys()]) this.remove(asset);
  }

  /** Attache / rafraîchit le contexte de stratégie (ex. re-sélection d'asset). */
  attachStrategyContext(asset: string, ctx: AssetTradingContext | null): void {
    const pipeline = this.pipelines.get(asset);
    if (pipeline) pipeline.strategyContext = ctx;
  }

  // ── Routage (§3) ─────────────────────────────────────────────────────────

  /**
   * Traite UN tick : route vers le pipeline de SON asset.
   * Retourne null si l'asset n'a pas de pipeline (asset non sélectionné —
   * isolation §6) et que la création auto est interdite.
   */
  processTick(tick: PipelineTick): PipelineTickResult | null {
    const pipeline = this.getOrCreate(tick.asset);
    return pipeline.processTick(tick);
  }

  /** Traite UNE bougie clôturée de l'asset donné. */
  processCandle(asset: string, candle: PipelineClosedCandle, nowMs: number = Date.now()): MarketDataHealthState | null {
    const pipeline = this.get(asset);
    if (!pipeline) return null;
    return pipeline.processCandle(candle, nowMs);
  }

  /** Santé d'un asset (null si pas de pipeline). */
  getHealth(asset: string, nowMs: number = Date.now()): MarketDataHealthState | null {
    const pipeline = this.get(asset);
    return pipeline ? pipeline.getHealth(nowMs) : null;
  }

  /** Verdict de trading d'un asset. */
  canTrade(asset: string, nowMs: number = Date.now()): HealthCheckResult | null {
    const pipeline = this.get(asset);
    return pipeline ? pipeline.canTrade(nowMs) : null;
  }

  /** Snapshot de décision d'un asset (null si pas de pipeline). */
  buildSnapshot(asset: string): MarketDecisionSnapshot | null {
    const pipeline = this.get(asset);
    return pipeline ? pipeline.buildSnapshot() : null;
  }

  /** Diffuse l'état de connexion stream à TOUS les pipelines (§10). */
  setStreamState(connected: boolean): void {
    for (const pipeline of this.pipelines.values()) {
      pipeline.marketDataHealth.onStreamState(connected);
    }
  }

  /** Change le timeframe de référence : recalcule les seuils dynamiques (§12). */
  setTimeframeSec(timeframeSec: number): void {
    for (const pipeline of this.pipelines.values()) {
      pipeline.marketDataHealth.setTimeframeSec(timeframeSec);
    }
  }

  /** Diagnostic multi-assets complet (§19). */
  getDiagnostics(): string {
    return this.getAll().map(p => p.getDiagnostic()).join('\n\n');
  }
}

function assertIsAssetName(asset: string): void {
  if (typeof asset !== 'string' || asset.trim().length === 0) {
    throw new Error(`[ASSET-CONTEXT-VIOLATION] invalid asset name: ${JSON.stringify(asset)}`);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// MultiAssetTickRouter (§23)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Routeur de ticks multi-assets — SANS AUCUNE logique de trading (§23).
 *
 *   WebSocket unique (§22)
 *       │
 *       ▼
 *   MultiAssetTickRouter.routeTick(tick)
 *       │
 *  ┌────┼────┐
 *  ▼    ▼    ▼
 * EURUSD GBPJPY XAUUSD → AssetPipelineManager.getOrCreate(tick.asset)
 */
export class MultiAssetTickRouter {
  constructor(
    private readonly pipelineManager: AssetPipelineManager,
    /** Prédicat d'autorisation (ex. registry.has) — défaut : tout asset. */
    private readonly isAllowed: (asset: string) => boolean = () => true,
  ) {}

  /**
   * Route UN tick vers le pipeline de SON asset.
   * Le tick d'un asset NON autorisé est ignoré (isolation §6).
   */
  routeTick(tick: PipelineTick): PipelineTickResult | null {
    if (!this.isAllowed(tick.asset)) return null;
    return this.pipelineManager.processTick(tick);
  }

  /** Diagnostic : nombre de pipelines actifs. */
  getStats(): { pipelines: number } {
    return { pipelines: this.pipelineManager.size };
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Logs structurés (§20)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Formate un log structuré :
 *   [MARKET-DATA] asset=EURUSD event=HEALTH_UPDATE health=97 status=READY
 * Le consommateur (io/log) choisit le niveau et la diffusion.
 */
export function formatStructuredLog(
  channel: 'MARKET-DATA' | 'ASSET-PIPELINE' | 'AUTO-TRADE' | 'HISTORY',
  fields: Record<string, string | number | boolean | null | undefined>,
): string {
  const parts: string[] = [];
  for (const [key, value] of Object.entries(fields)) {
    if (value == null) continue;
    parts.push(`${key}=${typeof value === 'string' ? value : String(value)}`);
  }
  return `[${channel}] ${parts.join(' ')}`;
}
