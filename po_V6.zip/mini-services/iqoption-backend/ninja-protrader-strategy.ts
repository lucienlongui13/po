/**
 * ninja-protrader-strategy.ts — Stratégie Auto Trade « Ninja ProTrader »
 * (backend, ordres réels).
 * ====================================================================
 * Copie conforme de la stratégie « L_Lucien ProTrader » avec UNE
 * différence fondamentale, demandée explicitement :
 *
 *   L_Lucien ProTrader : les événements BOS Down, BOS Up, CHoCH Up,
 *   CHoCH Down, CISD Up et CISD Down sont détectés À LA CLÔTURE des
 *   bougies (barstate.isconfirmed du pack Pine).
 *
 *   Ninja ProTrader    : la détection se fait AVANT LA CLÔTURE des
 *   bougies — le moteur évalue la bougie EN FORMATION (prix temps réel)
 *   à chaque itération (polling 500 ms) : dès que le prix courant
 *   franchit un niveau de swing dans les conditions du pack, l'ordre est
 *   placé IMMÉDIATEMENT, sans attendre la clôture.
 *
 * Tout le reste est la copie conforme de L_Lucien ProTrader :
 *   - le MÊME moteur partagé (shared/bos-choch-cisd.ts) ;
 *   - les MÊMES combinaisons CALL ▲ / PUT ▼ (règles d'alertes + expiration
 *     propre à chaque règle) ;
 *   - le MÊME switch « Confirmation bougie précédente » (v19) ;
 *   - la MÊME « Candles Validation » (v22) : règle par combinaison
 *     (ex. RGRR) vérifiée en temps réel sur les dernières bougies
 *     CLÔTURÉES, de la plus récente à la plus ancienne — la bougie EN
 *     FORMATION n'est jamais validée : l'ancre est la dernière bougie
 *     clôturée (option validationSkipForming du moteur partagé).
 *
 * Garde anti re-trade : UN ordre (tentative) par bougie EN FORMATION —
 * la stratégie marque la bougie dès que le signal est accepté pour
 * l'exécution, ce qui évite de re-déclencher le même événement aux
 * itérations suivantes de la même bougie.
 */

import {
  createCisdGuardState,
  evaluateBosChochCisdOrderRules,
  type BosChochCisdCandle,
  type BosChochCisdOrderRule,
  type BosChochCisdSignal,
  type CisdGuardState,
  type ConfirmPreviousCandleOptions,
} from '../../shared/bos-choch-cisd.js'

export type { BosChochCisdOrderRule } from '../../shared/bos-choch-cisd.js'

/** Dernière bougie EN FORMATION déjà tradée par asset (garde un-ordre-par-bougie). */
const lastTradedFormingCandleByAsset = new Map<string, number>()

/** v23 — état de la vérification CISD (swing intact + confirmation), PAR
 * ASSET, séparé de L_Lucien ProTrader : chaque stratégie suit SES propres
 * séquences « CISD vérifié → signal combiné ». */
const cisdGuardStates = new Map<string, CisdGuardState>()

/** Réinitialise l'état de garde Ninja (changement d'asset / reset Auto Trade). */
export function resetNinjaProTraderState(asset?: string): void {
  if (asset) {
    lastTradedFormingCandleByAsset.delete(asset)
    cisdGuardStates.delete(asset)
  } else {
    lastTradedFormingCandleByAsset.clear()
    cisdGuardStates.clear()
  }
}

/** v23 — état de garde CISD d'un asset (créé à la demande). */
export function getNinjaCisdGuardState(asset: string): CisdGuardState {
  let s = cisdGuardStates.get(asset)
  if (!s) {
    s = createCisdGuardState()
    cisdGuardStates.set(asset, s)
  }
  return s
}

/**
 * Évalue la bougie EN FORMATION et produit le signal de trading Ninja.
 *
 * Le moteur partagé reçoit [bougies clôturées…, bougie en formation] : les
 * événements de la DERNIÈRE barre sont ceux de la bougie en formation
 * (prix temps réel). Les combinaisons (règles CALL/PUT) sont matchées à
 * l'identique de L_Lucien ProTrader ; la Candles Validation est ancrée
 * sur la dernière bougie CLÔTURÉE (la bougie en formation n'est jamais
 * validée) ; la confirmation « bougie précédente » (v19) examine la
 * bougie clôturée précédant la bougie en formation.
 *
 * La garde anti re-trade bloque la bougie en formation déjà consommée.
 */
export function evaluateNinjaProTraderStrategy(
  closedCandles: BosChochCisdCandle[],
  formingCandle: BosChochCisdCandle | null,
  asset: string,
  orderRules: { callRules: BosChochCisdOrderRule[]; putRules: BosChochCisdOrderRule[] },
  options: ConfirmPreviousCandleOptions = {},
): BosChochCisdSignal {
  if (!formingCandle) {
    return {
      action: 'HOLD',
      confidence: 0,
      reason: 'Ninja ProTrader : aucune bougie en formation (flux temps réel indisponible)',
      events: [],
      candleTime: 0,
    }
  }
  const lastClosedTime = closedCandles.length > 0 ? closedCandles[closedCandles.length - 1].time : 0
  if (formingCandle.time <= lastClosedTime) {
    return {
      action: 'HOLD',
      confidence: 0,
      reason: 'Ninja ProTrader : bougie en formation incohérente avec l’historique clôturé',
      events: [],
      candleTime: 0,
    }
  }
  const all = [...closedCandles, formingCandle]
  const sig = evaluateBosChochCisdOrderRules(all, orderRules.callRules, orderRules.putRules, {
    ...options,
    // v22 — la bougie EN FORMATION (dernier élément) n'est JAMAIS validée :
    // la Candles Validation commence à la dernière bougie CLÔTURÉE.
    validationSkipForming: true,
    // v23 — vérification CISD (swing intact + confirmation par signal
    // combiné) pour les combinaisons CISD : état PAR ASSET détenu par ce
    // wrapper (Ninja ProTrader). L'armement et sa confirmation doivent
    // être DEUX signaux distincts (deux bougies).
    // v24 — les ÉTAPES sont OPTIONNELLES (cases à cocher du panneau Auto
    // Trade) : options.cisdGuardConfig (up/down, swingMode violé/intact,
    // combinaisons de confirmation BOS/CHoCH). Défaut = v23 intégral.
    cisdGuard: { state: getNinjaCisdGuardState(asset), config: options.cisdGuardConfig },
  })
  if (sig.action === 'HOLD') return sig

  const lastTraded = lastTradedFormingCandleByAsset.get(asset)
  if (lastTraded != null && lastTraded === formingCandle.time) {
    return {
      action: 'HOLD',
      confidence: 0,
      reason: `Ninja ProTrader : bougie en formation ${formingCandle.time} déjà tradée sur ${asset}`,
      events: [],
      candleTime: formingCandle.time,
    }
  }
  return { ...sig, candleTime: formingCandle.time }
}

/**
 * Marque la bougie en formation comme consommée pour cet asset (appelé à
 * l'acceptation du signal — une tentative d'ordre par bougie en formation).
 */
export function markNinjaProTraderTraded(asset: string, formingCandleTime: number): void {
  lastTradedFormingCandleByAsset.set(asset, formingCandleTime)
}
