/**
 * bos-choch-cisd-strategy.ts — Stratégie Auto Trade « BOS, CHoCH & CISD »
 * (backend, ordres réels).
 * ====================================================================
 * Conversion de l'indicateur « BOS, CHoCH and CISD [PiracyChecker] »
 * (pack Pine v6 + PubLibSwing/3 + PubLibTrend/3 + PubLibUtility/2 +
 * PubLibCandleTrend/2) en stratégie d'options binaires :
 *
 *   événement BOS/CHoCH/CISD Up   → CALL
 *   événement BOS/CHoCH/CISD Down → PUT
 *   évaluation sur bougies CLÔTURÉES uniquement (jamais la bougie en
 *   formation) — même sémantique que le pack (barstate.isconfirmed).
 *
 * Le moteur (shared/bos-choch-cisd.ts) est partagé avec le frontend
 * (Strategy Tester + visuels du graphique) et a été validé bougie par
 * bougie contre l'exécution du VRAI pack Pine par piner :
 * scripts/test-bos-choch-cisd.ts — 44/44 (labels, lignes d'événements,
 * lignes de tendance, positions Y et couleurs exacts sur 2 242 bougies).
 *
 * Garde anti re-trade : UN ordre (tentative) par bougie clôturée — la
 * stratégie marque la bougie dès que le signal est accepté pour
 * l'exécution, ce qui évite de re-déclencher le même événement à chaque
 * itération d'une même bougie.
 */

import {
  createCisdGuardState,
  evaluateBosChochCisd,
  evaluateBosChochCisdOrderRules,
  type BosChochCisdCandle,
  type BosChochCisdOrderRule,
  type CisdGuardState,
  type ConfirmPreviousCandleOptions,
} from '../../shared/bos-choch-cisd.js'

export type { BosChochCisdOrderRule, CisdGuardConfig } from '../../shared/bos-choch-cisd.js'

export interface BosChochCisdToggles {
  bosUp: boolean
  bosDown: boolean
  chochUp: boolean
  chochDown: boolean
  cisdUp: boolean
  cisdDown: boolean
}

export const DEFAULT_BOS_CHOCH_CISD_TOGGLES: BosChochCisdToggles = {
  bosUp: true,
  bosDown: true,
  chochUp: true,
  chochDown: true,
  cisdUp: true,
  cisdDown: true,
}

export interface BosChochCisdTradeSignal {
  action: 'CALL' | 'PUT' | 'HOLD'
  matchedRuleId?: string
  expirationSeconds?: number
  /** v26 — mode d'expiration résolu ('seconds' | 'candles' | 'remaining'). */
  expirationMode?: 'seconds' | 'candles' | 'remaining'
  /** v26 — expiration en bougies (mode 'candles'). */
  expirationCandles?: number
  /** v26 — conditions de la règle (alertes pack + patterns candle). */
  matchedRuleConditions?: string[]
  confidence: number
  reason: string
  events: string[]
  candleTime: number
  /** v23 — confirmation CISD (séquence swing-intact + signal combiné). */
  cisdConfirmation?: {
    direction: 'up' | 'down'
    armedCandleTime: number
    swingPrice: number
    confirmedBy: string[]
    /** v24/v25 — exigence swing au moment de l'armement ('intact' par défaut). */
    swingMode?: 'intact' | 'violated' | 'none'
  }
}

/** Dernière bougie déjà tradée par asset (garde un-ordre-par-bougie). */
const lastTradedCandleByAsset = new Map<string, number>()

/** v23 — état de la vérification CISD (swing intact + confirmation), PAR ASSET :
 * chaque asset possède sa propre séquence « CISD vérifié → signal combiné ». */
const cisdGuardStates = new Map<string, CisdGuardState>()

/** Réinitialise l'état de garde (changement d'asset / reset Auto Trade). */
export function resetBosChochCisdState(asset?: string): void {
  if (asset) {
    lastTradedCandleByAsset.delete(asset)
    cisdGuardStates.delete(asset)
  } else {
    lastTradedCandleByAsset.clear()
    cisdGuardStates.clear()
  }
}

/** v23 — état de garde CISD d'un asset (créé à la demande). */
export function getCisdGuardState(asset: string): CisdGuardState {
  let s = cisdGuardStates.get(asset)
  if (!s) {
    s = createCisdGuardState()
    cisdGuardStates.set(asset, s)
  }
  return s
}

/**
 * Évalue la dernière bougie CLÔTURÉE et produit le signal de trading.
 * Les toggles (réglages « Alerts » du pack) sélectionnent les événements
 * tradés ; la garde anti re-trade bloque la bougie déjà consommée.
 *
 * v19 — `options.confirmPreviousCandle` : si ON, un CALL ▲ n'est émis que
 * si la bougie PRÉCÉDANT la bougie signalée est BAISSIÈRE, et un PUT ▼ que
 * si elle est HAUSSIÈRE (switch « Confirmation bougie précédente » du
 * panneau Auto Trade). Défaut OFF — comportement inchangé.
 */
export function evaluateBosChochCisdStrategy(
  candles: BosChochCisdCandle[],
  asset: string,
  toggles: Partial<BosChochCisdToggles> = {},
  orderRules?: { callRules: BosChochCisdOrderRule[]; putRules: BosChochCisdOrderRule[] },
  options: ConfirmPreviousCandleOptions = {},
): BosChochCisdTradeSignal {
  if (orderRules) {
    // v23 — la vérification CISD (swing intact + confirmation par signal
    // combiné) est active pour les combinaisons CISD : l'état de garde est
    // détenu PAR ASSET par ce wrapper (L_Lucien ProTrader).
    // v24 — les ÉTAPES sont OPTIONNELLES (cases à cocher du panneau Auto
    // Trade) : options.cisdGuardConfig (up/down, swingMode violé/intact,
    // combinaisons de confirmation BOS/CHoCH). Défaut = v23 intégral.
    const ruleSig = evaluateBosChochCisdOrderRules(candles, orderRules.callRules, orderRules.putRules, {
      ...options,
      cisdGuard: { state: getCisdGuardState(asset), config: options.cisdGuardConfig },
    })
    if (ruleSig.action === 'HOLD') return ruleSig
    const lastTraded = lastTradedCandleByAsset.get(asset)
    if (lastTraded != null && lastTraded === ruleSig.candleTime) {
      return { action: 'HOLD', confidence: 0, reason: `BOS/CHoCH/CISD : bougie ${ruleSig.candleTime} déjà tradée sur ${asset}`, events: [], candleTime: ruleSig.candleTime }
    }
    return ruleSig
  }

  const t = { ...DEFAULT_BOS_CHOCH_CISD_TOGGLES, ...toggles }
  const sig = evaluateBosChochCisd(candles, {
    bosUpAlert: t.bosUp,
    bosDownAlert: t.bosDown,
    chochUpAlert: t.chochUp,
    chochDownAlert: t.chochDown,
    cisdUpAlert: t.cisdUp,
    cisdDownAlert: t.cisdDown,
  }, options)
  if (sig.action === 'HOLD') return sig

  const lastTraded = lastTradedCandleByAsset.get(asset)
  if (lastTraded != null && lastTraded === sig.candleTime) {
    return {
      action: 'HOLD',
      confidence: 0,
      reason: `BOS/CHoCH/CISD : bougie ${sig.candleTime} déjà tradée sur ${asset}`,
      events: [],
      candleTime: sig.candleTime,
    }
  }
  return sig
}

/** Marque la bougie comme consommée pour cet asset (appelé à l'acceptation
 * du signal — une tentative d'ordre par bougie clôturée). */
export function markBosChochCisdTraded(asset: string, candleTime: number): void {
  lastTradedCandleByAsset.set(asset, candleTime)
}
