/**
 * payout-guard.ts — v20 : AUTO SWITCH ASSETS (nouvelles règles utilisateur).
 * ============================================================================
 *
 * Demande utilisateur (v20) :
 *   « On modifie les règles de Auto Switch Assets. Désormais, dès que le
 *     pourcentage de profit de l'asset en cours baisse à une valeur < 92 % et
 *     que le dernier ordre est un gain et non une perte, alors on switch
 *     d'assets automatiquement — que sur des assets avec profit == 92 %. »
 *
 * POLITIQUE v20 (remplace les anciennes règles switch-post-trade + 90s idle) :
 *   - DÉCLENCHEUR : un asset ACTIF dont le payout passe sous 92 % est
 *     éligible au remplacement (le payout est DYNAMIQUE — poussé par le
 *     broker via updateAssets à chaque tick de marché).
 *   - VERROU « DERNIER ORDRE = GAIN » : on ne quitte JAMAIS un asset dont le
 *     dernier ordre réglé est une PERTE (ou un Tie) — une Martingale en
 *     cours de récupération ne doit pas être abandonnée en cours de route.
 *     Aucun ordre réglé (asset neuf) → switch autorisé. Ordre en cours
 *     (position ouverte) → on attend sa clôture.
 *   - CIBLE DE REMPLACEMENT : payout == 92 % EXACTEMENT (arrondi demi-entier
 *     pour tolérer le bruit float du broker), marché OUVERT, NON déjà
 *     sélectionné, payout le plus proche de 92 par défaut, tie-break
 *     alphabétique pour le déterminisme.
 *   - GARDE-FOUS anti-churn :
 *       · un asset avec des positions OUVERTES n'est PAS remplacé ;
 *       · cooldown par asset (2 min par défaut) — anti flip-flop ;
 *       · quota horaire global (12 par défaut) ;
 *       · un asset récemment écarté ne peut pas revenir immédiatement.
 *   - MODES single ET multi : « l'asset en cours » = l'asset focus en mono,
 *     chaque asset actif en multi (le remplacement conserve la position
 *     dans la liste).
 *   - v21 — « Stay on Forex OTC Only » : quand le switch est ON
 *     (config.stayOnForexOtcOnly), les candidats de remplacement sont
 *     FILTRÉS sur les seules paires FOREX OTC (CADJPY_otc, AUDUSD_OTC…).
 *
 * Le garde tourne CÔTÉ BACKEND (sur chaque poussée `updateAssets` du
 * broker) : il fonctionne donc MÊME SI LE FRONTEND EST FERMÉ (v6.3 —
 * continuité).
 *
 * Module PUR (aucune dépendance socket/io/fs) → importé par index.ts + tests.
 */

// ---------------------------------------------------------------------------
//  Constantes
// ---------------------------------------------------------------------------

/** Seuil de déclenchement : sous ce payout l'asset actif est éligible. */
export const AUTO_SWITCH_TRIGGER_PCT = 92;

/** Payout cible de remplacement : UNIQUEMENT un asset == 92 %. */
export const AUTO_SWITCH_TARGET_PCT = 92;

/** Payout EXACT requis d'un candidat de remplacement (== 92 %).
 * Tolérance ± 0,05 pour immuniser contre le bruit de représentation float —
 * les payouts broker sont des ENTIERS (91, 92, 95…) : 91,9 et 92,4 sont
 * REFUSÉS (ils ne sont pas « == 92 % »). */
export function isPayoutTarget(payout: number): boolean {
  return Number.isFinite(payout) && Math.abs(payout - AUTO_SWITCH_TARGET_PCT) <= 0.05;
}

// ---------------------------------------------------------------------------
//  v21 — « Stay on Forex OTC Only » : classification FOREX OTC
// ---------------------------------------------------------------------------

/**
 * Codes de devises FIAT (ISO-4217 actives, 3 lettres) reconnus comme FOREX.
 * Extrait des paires OTC réelles du catalogue Pocket Option + complément ISO.
 */
const FIAT_CURRENCY_CODES = new Set([
  // Majors + crosses PO (extraites du catalogue HAR — 80 paires « currency »)
  'USD', 'EUR', 'JPY', 'GBP', 'CHF', 'AUD', 'CAD', 'NZD',
  'CNY', 'AED', 'BHD', 'HUF', 'NOK', 'RUB', 'TRY', 'SEK',
  'DKK', 'PLN', 'CZK', 'RON', 'BGN', 'HRK', 'RSD', 'MKD', 'ALL', 'BAM',
  // Complément ISO-4217 courant (paires exotiques PO potentielles)
  'SGD', 'HKD', 'MXN', 'ZAR', 'ILS', 'SAR', 'QAR', 'KWD', 'BRL',
  'INR', 'IDR', 'MYR', 'PHP', 'THB', 'KRW', 'TWD', 'VND', 'ARS',
  'CLP', 'COP', 'PEN', 'EGP', 'NGN', 'KES', 'GHS', 'MAD', 'TND',
  'DZD', 'ISK', 'UAH', 'KZT', 'GEL', 'AZN', 'AMD', 'LBP', 'JOD',
  'OMR', 'LKR', 'PKR', 'BDT', 'NPR', 'MMK', 'KHR', 'LAK', 'UZS',
  'MNT', 'IQD', 'SYP', 'YER', 'BOB', 'PYG', 'UYU', 'VES', 'DOP',
  'GTQ', 'HNL', 'NIO', 'CRC', 'PAB', 'JMD', 'TTD', 'BSD', 'BMD',
  'KYD', 'XCD', 'AWG', 'HTG', 'BBD', 'BND', 'FJD', 'PGK', 'WST',
  'TOP', 'SBD', 'VUV', 'BIF', 'CDF', 'DJF', 'ETB', 'MUR',
  'MZN', 'RWF', 'SCR', 'SLL', 'SZL', 'TZS', 'UGX', 'XOF', 'XAF',
  'ZMW', 'MWK', 'AOA', 'MVR', 'NAD', 'LRD', 'GMD', 'GNF',
  'CVE', 'ERN', 'SOS', 'SDG', 'LYD', 'TMT', 'TJS', 'KGS', 'BYN',
  'MDL', 'CUC', 'CUP', 'IRR', 'CNH',
]);

/** Préfixes 3 lettres MÉTaux/CRYPTO — explicitement exclus du « Forex OTC ». */
const NON_FIAT_PREFIXES = new Set([
  'XAU', 'XAG', 'XPT', 'XPD',            // métaux précieux (or, argent…)
  'BTC', 'ETH', 'LTC', 'XRP', 'BCH',     // cryptos
  'DOGE', 'SOL', 'TON', 'TRX', 'ADA',
  'DASH', 'XMR', 'ETC', 'DOT', 'LINK', 'AVAX', 'MATIC', 'SHIB',
]);

/**
 * v21 — « Stay on Forex OTC Only » : un asset est-il une PAIRE FOREX OTC ?
 *
 * Définition : suffixe « _otc » (insensible à la casse — le broker pousse
 * parfois « AUDUSD_OTC ») + symbole 6 lettres A-Z = deux codes de devises
 * FIAT (ex. CADJPY_otc, AUDUSD_OTC). Sont EXCLUS : métaux (XAUUSD_otc =
 * or), cryptos (BTCUSD_otc), indices, actions (« #AAPL_otc ») et tout
 * actif non-OTC (EURUSD sans suffixe).
 */
export function isForexOtcAsset(asset: string): boolean {
  const name = String(asset ?? '').trim();
  const m = /^(.+)_otc$/i.exec(name);
  if (!m) return false;
  const symbol = m[1].toUpperCase();
  if (!/^[A-Z]{6}$/.test(symbol)) return false;
  const base = symbol.slice(0, 3);
  const quote = symbol.slice(3);
  if (NON_FIAT_PREFIXES.has(base) || NON_FIAT_PREFIXES.has(quote)) return false;
  return FIAT_CURRENCY_CODES.has(base) && FIAT_CURRENCY_CODES.has(quote);
}

// ---------------------------------------------------------------------------
//  Configuration
// ---------------------------------------------------------------------------

export interface PayoutGuardConfig {
  /** Garde actif ou non (master gate : config.autoSwitchAssets). */
  enabled: boolean;
  /** Délai minimal entre 2 remplacements DU MÊME asset (ms). */
  swapCooldownMs: number;
  /** Nombre maximal de remplacements par fenêtre glissante d'1 heure. */
  maxSwapsPerHour: number;
}

export const DEFAULT_PAYOUT_GUARD_CONFIG: PayoutGuardConfig = {
  enabled: true,
  swapCooldownMs: 120_000,
  maxSwapsPerHour: 12,
};

// ---------------------------------------------------------------------------
//  Types
// ---------------------------------------------------------------------------

/** Payout d'un asset tel que poussé par le broker (updateAssets). */
export interface PayoutSnapshot {
  /** Payout en pourcentage (ex. 92 = 92 %). null/undefined = inconnu. */
  payout?: number | null;
  /** Marché ouvert ? (undefined = considéré ouvert). */
  isOpen?: boolean;
}

/** Décision de remplacement prête à être appliquée. */
export interface PayoutSwapDecision {
  /** Asset à retirer (payout < 92 % confirmé, dernier ordre = gain). */
  from: string;
  /** Dernier payout constaté de l'asset retiré (%). */
  fromPayout: number;
  /** Asset de remplacement (payout == 92 %, ouvert, non actif). */
  to: string;
  /** Payout de l'asset de remplacement (%). */
  toPayout: number;
}

/** Entrée du journal des remplacements. */
export interface PayoutSwapRecord {
  ts: number;
  from: string;
  to: string;
  fromPayout: number;
  toPayout: number;
}

/** État mutable du garde (détention : index.ts — une instance PAR SESSION). */
export interface PayoutGuardState {
  /** Dernier remplacement PAR ASSET retiré (ms) — anti flip-flop. */
  lastSwapTs: Record<string, number>;
  /** Journal des remplacements (le plus récent EN DERNIER). */
  swaps: PayoutSwapRecord[];
}

export function createPayoutGuardState(): PayoutGuardState {
  return { lastSwapTs: {}, swaps: [] };
}

// ---------------------------------------------------------------------------
//  Entrée d'évaluation
// ---------------------------------------------------------------------------

export interface PayoutGuardInput {
  /** Mode de trading — single : seul le FOCUS est gardé ; multi : tous. */
  mode: 'single' | 'multi';
  /** Assets ACTIFS (sélectionnés — source de vérité backend). */
  activeAssets: string[];
  /** Asset FOCUS (affiché) — en mode single c'est L'asset en cours. */
  focus: string | null;
  /** Payouts courants de TOUS les actifs du broker. */
  payouts: Record<string, PayoutSnapshot>;
  /** Positions OUVERTES par asset actif (garde anti-remplacement). */
  openPositionsByAsset: Record<string, number>;
  /**
   * v20 — Résultat du DERNIER ordre réglé PAR ASSET ACTIF :
   * true = gain, false = perte/tie, absent/null = aucun ordre réglé.
   * Le switch n'est autorisé QUE si le dernier ordre de l'asset est un
   * GAIN (ou qu'aucun ordre n'a encore été réglé sur cet asset).
   */
  lastOrderWinByAsset: Record<string, boolean | null | undefined>;
  /**
   * v21 — « Stay on Forex OTC Only » : true = les candidats de remplacement
   * sont FILTRÉS sur les seules paires Forex OTC (CADJPY_otc, AUDUSD_OTC…).
   */
  forexOtcOnly?: boolean;
  /** Horloge (ms) — injectée pour des tests déterministes. */
  now: number;
  /** Surcharge partielle de la configuration. */
  config?: Partial<PayoutGuardConfig>;
}

// ---------------------------------------------------------------------------
//  Cœur : choix du candidat de remplacement
// ---------------------------------------------------------------------------

/**
 * Meilleur candidat de remplacement (payout == 92 %, ouvert, non actif).
 *
 * Critères : isPayoutTarget(payout) (== 92 %, arrondi demi-entier), marché
 * ouvert, non sélectionné, non récemment écarté. Classement : payout le plus
 * proche de 92 (par différence absolue), puis ordre alphabétique.
 *
 * v21 — `forexOtcOnly` (switch « Stay on Forex OTC Only ») : si true, les
 * candidats NON Forex OTC (métaux, cryptos, indices, actions…) sont exclus —
 * l'Auto Switch ne choisit ALORS que des paires de devises OTC
 * (CADJPY_otc, AUDUSD_OTC…).
 */
export function pickReplacementCandidate(
  activeAssets: string[],
  payouts: Record<string, PayoutSnapshot>,
  recentRemoved: Record<string, number> = {},
  now = 0,
  cooldownMs = 0,
  forexOtcOnly = false,
): { asset: string; payout: number } | null {
  const active = new Set(activeAssets);
  let best: { asset: string; payout: number; dist: number } | null = null;
  for (const [asset, snap] of Object.entries(payouts)) {
    if (active.has(asset)) continue;
    if (forexOtcOnly && !isForexOtcAsset(asset)) continue; // v21 — Forex OTC uniquement
    const payout = snap?.payout;
    if (typeof payout !== 'number' || !Number.isFinite(payout)) continue;
    if (!isPayoutTarget(payout)) continue; // UNIQUEMENT == 92 %
    if (snap.isOpen === false) continue; // marché fermé → non éligible
    // Anti flip-flop : un asset écarté depuis < cooldown ne revient pas.
    const removedAt = recentRemoved[asset];
    if (typeof removedAt === 'number' && cooldownMs > 0 && now - removedAt < cooldownMs) continue;
    const dist = Math.abs(payout - AUTO_SWITCH_TARGET_PCT);
    if (
      !best ||
      dist < best.dist ||
      (dist === best.dist && asset < best.asset)
    ) {
      best = { asset, payout, dist };
    }
  }
  return best ? { asset: best.asset, payout: best.payout } : null;
}

// ---------------------------------------------------------------------------
//  Cœur : évaluation complète (pure — ne mute PAS l'état)
// ---------------------------------------------------------------------------

/**
 * Évalue la politique de remplacement et retourne les décisions à APPLIQUER
 * par l'appelant (journalisation via commitPayoutSwap uniquement).
 *
 * @returns 0..N décisions (au plus UNE par asset éligible).
 */
export function evaluatePayoutGuard(
  state: PayoutGuardState,
  input: PayoutGuardInput,
): PayoutSwapDecision[] {
  const decisions: PayoutSwapDecision[] = [];
  // Master gate : le garde doit être activé (surcharge partielle ou défaut).
  const enabled = input.config?.enabled ?? DEFAULT_PAYOUT_GUARD_CONFIG.enabled;
  if (!enabled) return decisions;
  const activeSet = new Set(input.activeAssets);

  // En mode SINGLE : « l'asset en cours » = le FOCUS uniquement — on ne
  // remplace jamais un asset non affiché (l'utilisateur l'a choisi
  // explicitement). En MULTI : chaque asset actif est gardé.
  const guarded = input.mode === 'single'
    ? (input.focus && activeSet.has(input.focus) ? [input.focus] : [])
    : [...input.activeAssets];

  // Quota horaire global.
  const hourAgo = input.now - 3_600_000;
  const swapsLastHour = state.swaps.filter((s) => s.ts >= hourAgo).length;
  if (swapsLastHour >= (input.config?.maxSwapsPerHour ?? DEFAULT_PAYOUT_GUARD_CONFIG.maxSwapsPerHour)) {
    return decisions;
  }

  // Décisions pour chaque asset éligible. `taken` accumule les candidats
  // choisis : si DEUX assets sont éligibles dans la même passe, chacun doit
  // recevoir un candidat DIFFÉRENT.
  const taken = new Set<string>();
  for (const asset of guarded) {
    const payout = input.payouts[asset]?.payout;
    // 1) DÉCLENCHEUR : payout connu et < 92 %.
    if (typeof payout !== 'number' || !Number.isFinite(payout)) continue;
    if (payout >= AUTO_SWITCH_TRIGGER_PCT) continue;

    // 2) VERROU « dernier ordre = gain » : une perte ou un Tie sur le
    //    dernier ordre réglé de CET asset BLOQUE le switch (Martingale en
    //    récupération). Aucun ordre réglé (null/absent) → autorisé.
    const lastWin = input.lastOrderWinByAsset[asset];
    if (lastWin === false) continue;

    // 3) Positions ouvertes → on attend la clôture du deal en vol.
    if ((input.openPositionsByAsset[asset] ?? 0) > 0) continue;

    // 4) Cooldown par asset (anti flip-flop).
    const lastSwap = state.lastSwapTs[asset] ?? 0;
    if (input.now - lastSwap < (input.config?.swapCooldownMs ?? DEFAULT_PAYOUT_GUARD_CONFIG.swapCooldownMs)) continue;

    // 5) Candidat de remplacement (== 92 %, ouvert, non actif, non récent,
    //    Forex OTC uniquement si le switch « Stay on Forex OTC Only » est ON).
    const candidate = pickReplacementCandidate(
      [...input.activeAssets, ...taken],
      input.payouts,
      state.lastSwapTs,
      input.now,
      input.config?.swapCooldownMs ?? DEFAULT_PAYOUT_GUARD_CONFIG.swapCooldownMs,
      input.forexOtcOnly === true,
    );
    if (!candidate) continue; // aucun candidat == 92 % → pas de remplacement
    taken.add(candidate.asset);

    decisions.push({
      from: asset,
      fromPayout: payout,
      to: candidate.asset,
      toPayout: candidate.payout,
    });
  }

  return decisions;
}

/**
 * Journalise un remplacement APPLIQUÉ (appelé par index.ts après
 * applyAssetSelection / switchAssetAndRefresh) — met à jour cooldown +
 * journal horaire.
 */
export function commitPayoutSwap(
  state: PayoutGuardState,
  decision: PayoutSwapDecision,
  now: number,
): void {
  state.lastSwapTs[decision.from] = now;
  state.swaps.push({
    ts: now,
    from: decision.from,
    to: decision.to,
    fromPayout: decision.fromPayout,
    toPayout: decision.toPayout,
  });
  if (state.swaps.length > 200) state.swaps.splice(0, state.swaps.length - 200);
}

/** Supprime la surveillance des assets retirés de la sélection. */
export function prunePayoutGuardState(state: PayoutGuardState, activeAssets: string[]): void {
  const active = new Set(activeAssets);
  for (const asset of Object.keys(state.lastSwapTs)) {
    if (!active.has(asset)) delete state.lastSwapTs[asset];
  }
}

// ---------------------------------------------------------------------------
//  Résumé pour le frontend / les logs
// ---------------------------------------------------------------------------

export interface PayoutGuardSummary {
  enabled: boolean;
  triggerPct: number;
  targetPct: number;
  /** 5 derniers remplacements (plus récent en premier). */
  lastSwaps: PayoutSwapRecord[];
  swapsLastHour: number;
  maxSwapsPerHour: number;
}

export function payoutGuardSummary(
  state: PayoutGuardState,
  config: Partial<PayoutGuardConfig> = {},
  now = Date.now(),
): PayoutGuardSummary {
  const cfg: PayoutGuardConfig = { ...DEFAULT_PAYOUT_GUARD_CONFIG, ...config };
  const hourAgo = now - 3_600_000;
  return {
    enabled: cfg.enabled,
    triggerPct: AUTO_SWITCH_TRIGGER_PCT,
    targetPct: AUTO_SWITCH_TARGET_PCT,
    lastSwaps: [...state.swaps].reverse().slice(0, 5),
    swapsLastHour: state.swaps.filter((s) => s.ts >= hourAgo).length,
    maxSwapsPerHour: cfg.maxSwapsPerHour,
  };
}
