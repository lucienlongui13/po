/**
 * stream-tick-normalizer.ts
 * ==========================
 * NORMALISE LE FLUX `updateStream` DE POCKET OPTION — ZÉRO DUPLICATION,
 * ZÉRO LATENCE AJOUTÉE.
 *
 * CONSTAT EMPIRIQUE (validé sur 257 bougies croisées avec les bougies
 * broker authentiques `chafor` du candle-cache, dataset 27/08/2026) :
 *
 * Pocket Option pousse DEUX updates `updateStream` par seconde pour le
 * même actif — et ce sont DEUX VRAIS points du graphique :
 *
 *   1. arrivée n°1 : prix au DÉBUT de la seconde t
 *      → matche l'OPEN broker dans 98,4 % des cas
 *   2. arrivée n°2 : prix à la FIN de la seconde t
 *      → matche le CLOSE broker dans 90,7 % des cas
 *      → le DERNIER tick d'une bougie matche le CLOSE broker à 100 %
 *
 * Continuité vérifiée : B(t) == A(t+1) à 90 % près d'un pip.
 * Le graphique OTC échantillonne donc ~2 points/seconde.
 *
 * PROBLÈME D'ORIGINE : les deux points partagent la même seconde
 * tronquée (`Math.floor(ts)`), donc dans candles.jsonl chaque seconde
 * apparaissait 2-3 fois avec le même `t` → toute lecture naïve voyait
 * des ticks "dupliqués", et le moteur BOS calculait des vitesses
 * faussées (paires dt=0 ignorées) → décisions CALL/PUT inversées.
 *
 * SOLUTION : attribuer à chaque arrivée un HORODATAGE SOUS-SECONDE
 * strictement croissant (halving) :
 *
 *   arrivée 1 de la seconde t → t         (début de seconde)
 *   arrivée 2 de la seconde t → t + 0.5   (fin de seconde)
 *   arrivée 3 de la seconde t → t + 0.75  (point intermédiaire réel)
 *   arrivée 4 de la seconde t → t + 0.875
 *   arrivées suivantes       → t + 0.9375, ... (strictement croissant)
 *
 * Fidélité mesurée vs bougies broker (257 bougies) :
 *   open 98,4 % | high 98,8 % | low 98,4 % | close 93,0 %
 *   (contre 62-66 % si on ne garde qu'une des deux séries)
 *
 * GARANTIES :
 *   - horodatages strictement croissants par actif (invariant) ;
 *   - les ticks rejoués / en retard (reconnexion) sont DROPPÉS ;
 *   - émission immédiate (aucune latence ajoutée) ;
 *   - le dernier point de chaque seconde = dernier prix reçu
 *     (validé = close broker).
 */

export interface NormalizedTick {
  asset: string;
  /** Prix réel du graphique. */
  price: number;
  /**
   * marketTimeSec — horodatage MARCHÉ unix en secondes, résolution
   * sous-seconde (t + 0.5, ...). Origine : flux broker `updateStream`.
   * Utilisé pour choisir/ordonner/clôturer les bougies — JAMAIS le temps
   * de réception réseau (§3/§4 du ToDo synchronisation).
   */
  marketTimeSec: number;
  /**
   * receivedAtMs — temps LOCAL (Date.now()) de réception. Réservé aux
   * métriques de latence, logs, détection de timeout et reconnexion.
   * JAMAIS utilisé pour la logique de bougies.
   */
  receivedAtMs: number;
}

/**
 * Slot sous-seconde de la n-ième arrivée d'une seconde :
 *   1re → t, 2e → t+0.5, 3e → t+0.75, 4e → t+0.875, 5e → t+0.9375, ...
 * (halving infini : horodatages STRICTEMENT croissants, jamais de
 * remplacement nécessaire, tous les points restent dans la seconde.)
 */
function subSecondOffset(arrivalIndex: number): number {
  if (arrivalIndex <= 1) return 0;
  return 1 - Math.pow(2, -(arrivalIndex - 1));
}

interface AssetState {
  /** Dernier horodatage normalisé émis (invariant anti-rejeu). */
  lastTime: number;
  /** Seconde en cours de construction (floored). */
  currentSecond: number;
  /** Nombre d'arrivées déjà vues pour currentSecond. */
  arrivalsThisSecond: number;
  lastActivity: number;
}

export interface NormalizerStats {
  received: number;
  emitted: number;
  /** Ticks droppés : en retard / rejoués (horodatage <= dernier émis).
   * Alias historique conservé pour le frontend — détaillé ci-dessous. */
  droppedStale: number;
  /** Ticks rejoués à l'identique (même horodatage exact). */
  duplicateTickDropped: number;
  /** Ticks en retard (horodatage strictement antérieur au dernier émis). */
  lateTickDropped: number;
  /** Ticks hors ordre (horodatage futur mais seconde antérieure à la
   * seconde en cours de construction — agrégation désynchronisée). */
  outOfOrderTickDropped: number;
}

export class StreamTickNormalizer {
  private static readonly ASSET_TTL_MS = 120_000;

  private states = new Map<string, AssetState>();
  private stats: NormalizerStats = {
    received: 0, emitted: 0, droppedStale: 0,
    duplicateTickDropped: 0, lateTickDropped: 0, outOfOrderTickDropped: 0,
  };

  constructor(
    private onTick: (tick: NormalizedTick) => void,
    private onError?: (err: unknown) => void,
  ) {}

  /**
   * Ingest un batch d'updates `updateStream` (ordre d'arrivée serveur).
   * Chaque update est normalisé puis émis immédiatement en aval.
   * Retourne le nombre de ticks émis.
   */
  ingestBatch(updates: Array<{ asset: string; bid: number; time: number }>): number {
    let emitted = 0;
    for (const u of updates) {
      if (!u || typeof u.bid !== 'number' || !Number.isFinite(u.bid) || !u.asset) continue;
      if (this.ingestOne(u.asset, u.bid, u.time)) emitted++;
    }
    this.cleanupAssets();
    return emitted;
  }

  private ingestOne(asset: string, price: number, rawTime: number): boolean {
    this.stats.received++;
    const second = Math.floor(rawTime);

    let st = this.states.get(asset);
    if (!st) {
      st = { lastTime: -Infinity, currentSecond: -1, arrivalsThisSecond: 0, lastActivity: 0 };
      this.states.set(asset, st);
    }
    st.lastActivity = Date.now();

    // Slot sous-seconde : début de seconde si nouvelle seconde, sinon
    // l'arrivée suivante de la même seconde (halving : 0.5, 0.75, 0.875...).
    if (second !== st.currentSecond) {
      // Tick hors ordre : une seconde STRICTEMENT antérieure à la seconde en
      // cours de construction alors que l'horodatage est postérieur au
      // dernier émis (désynchronisation amont) — compteur dédié (§8).
      if (second < st.currentSecond) this.stats.outOfOrderTickDropped++;
      st.currentSecond = second;
      st.arrivalsThisSecond = 1;
    } else {
      st.arrivalsThisSecond++;
    }
    const marketTimeSec = second + subSecondOffset(st.arrivalsThisSecond);

    // Invariant : horodatages strictement croissants par actif.
    // Un tick rejoué/en retard (reconnexion, rejeu subfor) est droppé.
    if (marketTimeSec <= st.lastTime) {
      this.stats.droppedStale++;
      if (marketTimeSec === st.lastTime) this.stats.duplicateTickDropped++;
      else this.stats.lateTickDropped++;
      return false;
    }

    st.lastTime = marketTimeSec;
    this.emit({ asset, price, marketTimeSec, receivedAtMs: Date.now() });
    return true;
  }

  private emit(tick: NormalizedTick): void {
    this.stats.emitted++;
    try {
      this.onTick(tick);
    } catch (err) {
      this.onError?.(err);
    }
  }

  private cleanupAssets(): void {
    const now = Date.now();
    for (const [asset, st] of this.states) {
      if (now - st.lastActivity > StreamTickNormalizer.ASSET_TTL_MS) {
        this.states.delete(asset);
      }
    }
  }

  getStats(): Readonly<NormalizerStats> {
    return { ...this.stats };
  }

  reset(): void {
    this.states.clear();
    this.stats = {
      received: 0, emitted: 0, droppedStale: 0,
      duplicateTickDropped: 0, lateTickDropped: 0, outOfOrderTickDropped: 0,
    };
  }

  destroy(): void {
    this.reset();
  }
}

/**
 * Répare une série de ticks LEGACY dupliquée (même `t` entier, plusieurs
 * arrivées) en lui appliquant les slots sous-seconde — utilisée par la
 * réparation automatique de candles.jsonl au démarrage.
 *
 * `ticks` doit être dans l'ordre d'arrivée d'origine.
 * Retourne les ticks normalisés (triés, horodatages strictement
 * croissants) + le nombre de ticks remplacés/droppés.
 */
export function normalizeLegacyTicks(
  ticks: Array<{ t: number; p: number }>,
): { ticks: Array<{ t: number; p: number }>; dropped: number } {
  const out: Array<{ t: number; p: number }> = [];
  let dropped = 0;
  let lastTime = -Infinity;
  let currentSecond = -1;
  let arrivals = 0;

  for (const tk of ticks) {
    const second = Math.floor(tk.t);
    if (second !== currentSecond) {
      currentSecond = second;
      arrivals = 1;
    } else {
      arrivals++;
    }
    const time = second + subSecondOffset(arrivals);

    if (time <= lastTime) {
      dropped++;
      continue;
    }
    lastTime = time;
    out.push({ t: time, p: tk.p });
  }
  return { ticks: out, dropped };
}
