/**
 * expiry.ts — Expiration des ordres binaires : LE CHAMP AUTO TRADE EST LA
 * SOURCE DE VÉRITÉ (requête utilisateur v6.1).
 * ============================================================================
 *
 * La stratégie d'auto-trade (L_Lucien ProTrader) utilise
 * `config.expirySeconds` — la valeur du champ « Expiration » du panneau
 * Auto Trade — comme durée d'expiration de l'ordre. La valeur par
 * stratégie n'est PAS codée en dur :
 *
 *   - Stratégie    : champ Auto Trade (fallback : durée de la bougie du TF
 *                    si le champ est null) — la patience reste par timeframe.
 *   - Polling      : champ Auto Trade, clamp [3 s, 86 400 s] sur TOUTE la
 *                    plage (v6.3 : la valeur est respectée à la seconde
 *                    près — plus de snap qui écrasait 6 s en 5 s).
 *
 * Valable en mode mono-asset ET multi-assets (config globale partagée, les
 * mises Martingale/Fibonacci restent PAR ASSET — voir asset-contexts.ts).
 *
 * Module PUR (aucune dépendance socket/io) → importé par index.ts et les tests.
 */

/** Expiration minimale autorisée en auto-trade (secondes) — minimum broker. */
export const AUTO_TRADE_MIN_EXPIRY = 3;

/** Expiration maximale autorisée en auto-trade (secondes) — maximum pratique : 24 h (D1). */
export const AUTO_TRADE_MAX_EXPIRY = 86400;

/**
 * Valeurs d'expiration HISTORIQUEMENT associées au broker (secondes).
 * ⚠️ v6.3 : cette liste n'est PLUS utilisée pour écraser la valeur du champ —
 * le broker accepte toute expiration entière ≥ 3 s (l'ordre est envoyé tel
 * quel via openOrder). Elle reste exportée à titre documentaire.
 */
export const BROKER_SUPPORTED_EXPIRIES: readonly number[] = [
  3, 5, 10, 15, 20, 30, 60, 120, 180, 300, 600, 900,
  1800, 3600, 7200, 14400, 28800, 86400,
];

/**
 * Normalise une expiration pour l'ordre broker (v6.3).
 *
 * AVANT (v6.1/v6.2) : la valeur était snappée sur BROKER_SUPPORTED_EXPIRIES,
 * ce qui RÉÉCRIVAIT silencieusement le champ Auto Trade — ex. 6 s → 5 s
 * (bug utilisateur v6.3 : « je mets 6 s, tous les écrans affichent exp 5s »).
 *
 * MAINTENANT : le champ Auto Trade est respecté À LA SECONDE PRÈS —
 * arrondi à l'entier + clamp [AUTO_TRADE_MIN_EXPIRY, AUTO_TRADE_MAX_EXPIRY].
 * Si le broker refusait une valeur, il répondrait `failopenOrder` (géré et
 * loggé) — c'est préférable à une réécriture silencieuse.
 */
export function snapExpiry(seconds: number): number {
  // NaN → minimum ; ±Infinity → bornes du clamp (défensif).
  const v = Number.isFinite(seconds)
    ? Math.round(seconds)
    : (seconds > 0 ? AUTO_TRADE_MAX_EXPIRY : AUTO_TRADE_MIN_EXPIRY);
  return Math.max(AUTO_TRADE_MIN_EXPIRY, Math.min(AUTO_TRADE_MAX_EXPIRY, v));
}

/**
 * Résout l'expiration effective d'un ordre d'auto-trade :
 *
 *   1. VALEUR DU CHAMP AUTO TRADE (`config.expirySeconds`) si définie ;
 *   2. sinon `fallback` (durée de bougie du timeframe, …) ;
 *   3. clamp [3 s, 86 400 s] — la valeur du champ est respectée telle
 *      quelle (v6.3 : 6 s reste 6 s, 45 s reste 45 s, …).
 *
 * @param expirySeconds Valeur du champ « Expiration » du panneau Auto Trade
 *                      (peut être null/undefined si jamais configuré).
 * @param fallback      Valeur de repli si le champ est absent.
 */
export function resolveAutoTradeExpiry(
  expirySeconds: number | null | undefined,
  fallback: number,
): number {
  const raw = (expirySeconds == null || !Number.isFinite(expirySeconds) || expirySeconds <= 0)
    ? fallback
    : expirySeconds;
  return snapExpiry(raw);
}
