/**
 * indicators.ts — algorithmic technical indicators
 * ================================================
 *
 * Every indicator takes a list of close prices (and optionally high/low/volume)
 * and returns a list of indicator values aligned with the input (so
 * indicators[i] corresponds to prices[i]). The first few elements will
 * be `null` while the indicator "warms up".
 *
 * All formulas use the standard definitions you'd find in any
 * technical-analysis textbook (the same ones TradingView uses).
 */

export type Series = (number | null)[]
export type CandleLike = {
  time: number  // unix seconds
  open: number
  high: number
  low: number
  close: number
  volume: number
}

// ---------------------------------------------------------------------------
// Moving averages
// ---------------------------------------------------------------------------

export function sma(prices: number[], period: number): Series {
  const out: Series = []
  let sum = 0
  for (let i = 0; i < prices.length; i++) {
    sum += prices[i]
    if (i >= period) sum -= prices[i - period]
    out.push(i >= period - 1 ? sum / period : null)
  }
  return out
}

export function ema(prices: number[], period: number): Series {
  const out: Series = []
  if (prices.length === 0) return out
  const k = 2 / (period + 1)
  let prev = prices[0]
  for (let i = 0; i < prices.length; i++) {
    if (i === 0) {
      prev = prices[0]
      out.push(i >= period - 1 ? prev : null)
    } else {
      prev = prices[i] * k + prev * (1 - k)
      out.push(i >= period - 1 ? prev : null)
    }
  }
  return out
}

export function wma(prices: number[], period: number): Series {
  const out: Series = []
  const denom = (period * (period + 1)) / 2
  for (let i = 0; i < prices.length; i++) {
    if (i < period - 1) {
      out.push(null)
      continue
    }
    let sum = 0
    for (let j = 0; j < period; j++) {
      const weight = period - j
      sum += prices[i - j] * weight
    }
    out.push(sum / denom)
  }
  return out
}

// ---------------------------------------------------------------------------
// RSI (Relative Strength Index)
// ---------------------------------------------------------------------------

export function rsi(prices: number[], period = 14): Series {
  const out: Series = []
  if (prices.length === 0) return out
  let avgGain = 0
  let avgLoss = 0
  for (let i = 0; i < prices.length; i++) {
    if (i === 0) {
      out.push(null)
      continue
    }
    const change = prices[i] - prices[i - 1]
    const gain = change > 0 ? change : 0
    const loss = change < 0 ? -change : 0
    if (i <= period) {
      avgGain = (avgGain * (i - 1) + gain) / i
      avgLoss = (avgLoss * (i - 1) + loss) / i
      out.push(i === period ? (avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss)) : null)
    } else {
      avgGain = (avgGain * (period - 1) + gain) / period
      avgLoss = (avgLoss * (period - 1) + loss) / period
      out.push(avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss))
    }
  }
  return out
}

// ---------------------------------------------------------------------------
// MACD (Moving Average Convergence Divergence)
// ---------------------------------------------------------------------------

export interface MACDResult {
  macd: Series
  signal: Series
  histogram: Series
}

export function macd(prices: number[],
                      fastPeriod = 12,
                      slowPeriod = 26,
                      signalPeriod = 9): MACDResult {
  const fastEma = ema(prices, fastPeriod)
  const slowEma = ema(prices, slowPeriod)
  const macdLine: Series = prices.map((_, i) =>
    fastEma[i] !== null && slowEma[i] !== null
      ? (fastEma[i] as number) - (slowEma[i] as number)
      : null
  )
  // signal = EMA of macdLine (ignoring nulls)
  const validMacd: number[] = []
  const startIndex = macdLine.findIndex((v) => v !== null)
  for (let i = startIndex; i < macdLine.length; i++) {
    if (macdLine[i] !== null) validMacd.push(macdLine[i] as number)
  }
  const signalRaw = ema(validMacd, signalPeriod)
  const signalLine: Series = new Array(prices.length).fill(null)
  for (let i = 0; i < signalRaw.length; i++) {
    signalLine[startIndex + i] = signalRaw[i]
  }
  const histogram: Series = prices.map((_, i) =>
    macdLine[i] !== null && signalLine[i] !== null
      ? (macdLine[i] as number) - (signalLine[i] as number)
      : null
  )
  return { macd: macdLine, signal: signalLine, histogram }
}

// ---------------------------------------------------------------------------
// Bollinger Bands
// ---------------------------------------------------------------------------

export interface BollingerResult {
  upper: Series
  middle: Series
  lower: Series
}

export function bollingerBands(prices: number[],
                                period = 20,
                                stdDevMult = 2): BollingerResult {
  const middle = sma(prices, period)
  const upper: Series = []
  const lower: Series = []
  for (let i = 0; i < prices.length; i++) {
    if (i < period - 1) {
      upper.push(null)
      lower.push(null)
      continue
    }
    const mean = middle[i] as number
    let variance = 0
    for (let j = 0; j < period; j++) {
      const diff = prices[i - j] - mean
      variance += diff * diff
    }
    const sd = Math.sqrt(variance / period)
    upper.push(mean + stdDevMult * sd)
    lower.push(mean - stdDevMult * sd)
  }
  return { upper, middle, lower }
}

// ---------------------------------------------------------------------------
// Stochastic Oscillator
// ---------------------------------------------------------------------------

export interface StochasticResult {
  k: Series
  d: Series
}

export function stochastic(highs: number[],
                            lows: number[],
                            closes: number[],
                            kPeriod = 14,
                            dPeriod = 3): StochasticResult {
  const k: Series = []
  for (let i = 0; i < closes.length; i++) {
    if (i < kPeriod - 1) {
      k.push(null)
      continue
    }
    let hh = -Infinity
    let ll = Infinity
    for (let j = 0; j < kPeriod; j++) {
      hh = Math.max(hh, highs[i - j])
      ll = Math.min(ll, lows[i - j])
    }
    const close = closes[i]
    k.push(hh === ll ? 50 : ((close - ll) / (hh - ll)) * 100)
  }
  // D = SMA of K
  const validK: number[] = []
  const startIndex = k.findIndex((v) => v !== null)
  for (let i = startIndex; i < k.length; i++) {
    if (k[i] !== null) validK.push(k[i] as number)
  }
  const dRaw = sma(validK, dPeriod)
  const d: Series = new Array(closes.length).fill(null)
  for (let i = 0; i < dRaw.length; i++) {
    d[startIndex + i] = dRaw[i]
  }
  return { k, d }
}

// ---------------------------------------------------------------------------
// ATR (Average True Range)
// ---------------------------------------------------------------------------

export function atr(highs: number[],
                    lows: number[],
                    closes: number[],
                    period = 14): Series {
  const out: Series = []
  let prevAtr = 0
  for (let i = 0; i < closes.length; i++) {
    if (i === 0) {
      out.push(null)
      continue
    }
    const tr = Math.max(
      highs[i] - lows[i],
      Math.abs(highs[i] - closes[i - 1]),
      Math.abs(lows[i] - closes[i - 1]),
    )
    if (i < period) {
      prevAtr = (prevAtr * (i - 1) + tr) / i
      out.push(i === period - 1 ? prevAtr : null)
    } else {
      prevAtr = (prevAtr * (period - 1) + tr) / period
      out.push(prevAtr)
    }
  }
  return out
}

// ---------------------------------------------------------------------------
// Volume Weighted Average Price (VWAP)
// ---------------------------------------------------------------------------

export function vwap(highs: number[],
                     lows: number[],
                     closes: number[],
                     volumes: number[]): Series {
  const out: Series = []
  let cumPV = 0
  let cumV = 0
  for (let i = 0; i < closes.length; i++) {
    const typical = (highs[i] + lows[i] + closes[i]) / 3
    cumPV += typical * volumes[i]
    cumV += volumes[i]
    out.push(cumV === 0 ? null : cumPV / cumV)
  }
  return out
}

// ---------------------------------------------------------------------------
// SuperTrend — ATR-based trend-following indicator
// ---------------------------------------------------------------------------
// When price > SuperTrend → bullish (green line below price)
// When price < SuperTrend → bearish (red line above price)
// ---------------------------------------------------------------------------

export interface SuperTrendResult {
  /** The SuperTrend line value at each bar (null while warming up). */
  superTrend: Series
  /** Trend direction at each bar: 1 = bullish (buy), -1 = bearish (sell). */
  trend: (1 | -1 | null)[]
}

export function superTrend(highs: number[],
                            lows: number[],
                            closes: number[],
                            period = 10,
                            multiplier = 3): SuperTrendResult {
  const atrSeries = atr(highs, lows, closes, period)
  const superTrend: Series = []
  const trend: (1 | -1 | null)[] = []
  let prevUpper = 0
  let prevLower = 0
  let prevSuper = 0
  let prevTrend: 1 | -1 = 1

  for (let i = 0; i < closes.length; i++) {
    if (i < period || atrSeries[i] === null) {
      superTrend.push(null)
      trend.push(null)
      continue
    }
    const atrVal = atrSeries[i] as number
    const mid = (highs[i] + lows[i]) / 2
    let upper = mid + multiplier * atrVal
    let lower = mid - multiplier * atrVal

    // Final upper/lower bands: carry forward if previous close broke them
    if (i === period) {
      // First valid bar
      prevUpper = upper
      prevLower = lower
    } else {
      if (closes[i - 1] > prevUpper) {
        // was bullish, lower can rise but not fall
        lower = Math.max(lower, prevLower)
        upper = mid + multiplier * atrVal  // upper resets
      } else if (closes[i - 1] < prevLower) {
        // was bearish, upper can fall but not rise
        upper = Math.min(upper, prevUpper)
        lower = mid - multiplier * atrVal  // lower resets
      } else {
        // carry both forward, with new ATR adjustments
        upper = (prevUpper === 0 || upper < prevUpper) ? upper : prevUpper
        lower = (prevLower === 0 || lower > prevLower) ? lower : prevLower
      }
    }

    // Determine trend: flip when close crosses the opposite band
    let newTrend: 1 | -1
    if (prevTrend === 1) {
      newTrend = closes[i] < lower ? -1 : 1
    } else {
      newTrend = closes[i] > upper ? 1 : -1
    }

    const newSuper = newTrend === 1 ? lower : upper
    superTrend.push(newSuper)
    trend.push(newTrend)

    prevUpper = upper
    prevLower = lower
    prevSuper = newSuper
    prevTrend = newTrend
  }

  return { superTrend, trend }
}

// ---------------------------------------------------------------------------
// Kalman Filter (1D, price + velocity state)
// ---------------------------------------------------------------------------
// State vector: [price, velocity]
// Transition matrix: [[1, 1], [0, 1]]   (price_next = price + velocity)
// Measurement: H = [1, 0]   (we observe price directly)
// Process noise: Q (tuned to allow velocity drift)
// Measurement noise: R (derived from recent residuals)
// ---------------------------------------------------------------------------

export interface KalmanResult {
  /** Smoothed price estimate at each bar. */
  price: Series
  /** Smoothed velocity (trend) estimate at each bar. */
  velocity: Series
  /** Confidence 0..1 — higher when prediction error is low. */
  confidence: number
}

export function kalmanFilter(prices: number[],
                              processNoise = 0.01,
                              measurementNoise = 0.5): KalmanResult {
  const priceOut: Series = []
  const velocityOut: Series = []
  if (prices.length === 0) {
    return { price: priceOut, velocity: velocityOut, confidence: 0 }
  }
  // State: [price, velocity]
  let xPrice = prices[0]
  let xVel = 0
  // Covariance: 2x2
  let p11 = 1, p12 = 0, p22 = 1
  // Adapt measurement noise based on residuals
  let residualSqSum = 0
  let observationCount = 0
  let totalResidual = 0

  for (let i = 0; i < prices.length; i++) {
    // PREDICT
    const predPrice = xPrice + xVel
    const predVel = xVel
    // P' = F P F^T + Q
    // F = [[1,1],[0,1]]
    // After multiplication: P' = [[p11 + 2*p12 + p22 + Q, p12 + p22], [p12 + p22, p22 + Q]]
    const newP11 = p11 + 2 * p12 + p22 + processNoise
    const newP12 = p12 + p22
    const newP22 = p22 + processNoise
    p11 = newP11
    p12 = newP12
    p22 = newP22
    xPrice = predPrice
    xVel = predVel

    // UPDATE
    const y = prices[i] - xPrice   // innovation
    const S = p11 + measurementNoise  // innovation covariance
    if (S > 0) {
      const k1 = p11 / S
      const k2 = p12 / S
      xPrice = xPrice + k1 * y
      xVel = xVel + k2 * y
      // P = (I - K H) P
      p11 = (1 - k1) * p11
      p12 = (1 - k1) * p12
      p22 = p22 - k2 * p12
    }

    // Track residuals for confidence
    residualSqSum += y * y
    observationCount++
    if (observationCount >= 5) {
      totalResidual = Math.sqrt(residualSqSum / observationCount)
    }

    priceOut.push(xPrice)
    velocityOut.push(xVel)
  }

  // Confidence: higher when residuals are small relative to price
  const meanPrice = prices.reduce((a, b) => a + b, 0) / prices.length
  const relResidual = totalResidual / (meanPrice || 1)
  const confidence = Math.max(0, Math.min(1, 1 - relResidual * 10))

  return { price: priceOut, velocity: velocityOut, confidence }
}

// ---------------------------------------------------------------------------
// Helper: align a series to candle timestamps
// ---------------------------------------------------------------------------

export interface IndicatorPoint {
  time: number
  value: number
}

export function toIndicatorPoints(candles: CandleLike[],
                                    series: Series): IndicatorPoint[] {
  const out: IndicatorPoint[] = []
  for (let i = 0; i < candles.length && i < series.length; i++) {
    if (series[i] !== null && series[i] !== undefined) {
      out.push({ time: candles[i].time, value: series[i] as number })
    }
  }
  return out
}
