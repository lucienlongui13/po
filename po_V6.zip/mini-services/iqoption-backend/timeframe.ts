/**
 * timeframe.ts — SOURCE DE VÉRITÉ TEMPORELLE UNIQUE.
 * ==================================================
 *
 * RÈGLE CENTRALE (ToDo « Synchronisation historique ↔ stream des bougies
 * par timeframe », validée sur `History_Live_Fix.har`) :
 *
 *   Le timestamp canonique d'une bougie est TOUJOURS le DÉBUT de son
 *   intervalle UTC :  bucket = floor(t / period) * period.
 *
 *   S5  → ...00, ...05, ...10, ...15, ...20, ...25, ...30...
 *   S30 → ...00, ...30
 *   M1  → multiples de 60
 *   M5  → multiples de 300
 *
 * Ne JAMAIS décaler une bougie avec l'heure locale, `Date.now()` seul, un
 * délai réseau, ou le moment de réception du paquet.
 *
 * Preuve .har (S5) : le premier chargement live part d'un timestamp AVEC
 * fraction de seconde `1787915506.001`. Ce timestamp n'est PAS un début de
 * bougie — le bucket canonique est :
 *
 *   bucketStart(1787915506.001, 5) = 1787915505
 *
 * Ce module centralise TOUT calcul de grille. Interdiction d'écrire
 * `Math.floor(t / period) * period` ailleurs dans le code (les calculs
 * dispersés ont créé les bugs de désynchronisation historique ↔ live).
 *
 * TROIS NOTIONS DE TEMPS STRICTEMENT DISTINCTES (§4 du ToDo) :
 *   - `marketTimeSec`   : temps du flux broker (choisir/trier/clôturer) ;
 *   - `receivedAtMs`    : temps local de réception (latence, logs, timeout) ;
 *   - `bucketTimeSec`   : début UTC canonique = clé unique
 *                         (asset + period + bucketTimeSec).
 */

// ─────────────────────────────────────────────────────────────────────────────
// Grille temporelle
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Début UTC canonique du bucket contenant `timeSec`.
 * Accepte les timestamps sous-seconde (ex. 1787915506.001 → 1787915505 en S5).
 */
export function bucketStart(timeSec: number, periodSec: number): number {
  return Math.floor(timeSec / periodSec) * periodSec;
}

/** Fin exclusive du bucket contenant `timeSec` : [start, start + period). */
export function bucketEnd(timeSec: number, periodSec: number): number {
  return bucketStart(timeSec, periodSec) + periodSec;
}

/** Vrai ssi `timeSec` est un entier exactement aligné sur la grille. */
export function isBucketAligned(timeSec: number, periodSec: number): boolean {
  return Number.isInteger(timeSec) && timeSec % periodSec === 0;
}

// ─────────────────────────────────────────────────────────────────────────────
// Validation OHLC (§18 — vérifications après chaque fusion)
// ─────────────────────────────────────────────────────────────────────────────

export interface GridCandle {
  /** bucketTimeSec — début UTC canonique de la bougie. */
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

/**
 * Invariants OHLC d'une bougie :
 *   low  <= min(open, close)
 *   high >= max(open, close)
 *   high >= low
 *   aucune valeur NaN ; timestamp fini.
 */
export function isOhlcValid(c: GridCandle): boolean {
  return (
    Number.isFinite(c.time) &&
    Number.isFinite(c.open) && Number.isFinite(c.high) &&
    Number.isFinite(c.low) && Number.isFinite(c.close) &&
    c.low <= Math.min(c.open, c.close) + 1e-9 &&
    c.high >= Math.max(c.open, c.close) - 1e-9 &&
    c.high >= c.low - 1e-9
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Détection de trous (§13)
// ─────────────────────────────────────────────────────────────────────────────

export interface CandleGap {
  /** Début (bucketTimeSec) du premier bucket manquant. */
  startTime: number;
  /** Début du bucket présent qui suit le trou. */
  endTime: number;
  /** Nombre de bougies manquantes dans le trou. */
  missingCandles: number;
  /** Timeframe (secondes) de la série analysée. */
  periodSec: number;
}

/**
 * Trouve les trous d'une série TRIÉE : deux bougies consécutives séparées de
 * plus d'une période créent un trou. Un trou dans le live ne doit JAMAIS être
 * comblé par des timestamps synthétiques — la procédure est : détection →
 * demande d'historique ciblée → normalisation → déduplication → fusion →
 * revalidation.
 */
export function findGaps(candles: GridCandle[], periodSec: number): CandleGap[] {
  const gaps: CandleGap[] = [];
  for (let i = 1; i < candles.length; i++) {
    const prev = candles[i - 1].time;
    const cur = candles[i].time;
    const delta = cur - prev;
    if (delta > periodSec) {
      const missing = Math.round(delta / periodSec) - 1;
      gaps.push({
        startTime: prev + periodSec,
        endTime: cur,
        missingCandles: missing,
        periodSec,
      });
    }
  }
  return gaps;
}

// ─────────────────────────────────────────────────────────────────────────────
// Normalisation d'une série (alignement + dédup + tri + validation)
// ─────────────────────────────────────────────────────────────────────────────

export interface NormalizeResult<T extends GridCandle> {
  /** Série canonique : alignée, dédupliquée par bucket, triée, valide. */
  candles: T[];
  /** Bougies dont le timestamp n'était PAS aligné → rebucketisées. */
  realigned: number;
  /** Bougies écrasées par un doublon du même bucket. */
  duplicates: number;
  /** Bougies rejetées (OHLC invalide / timestamp non fini). */
  invalid: number;
  /** Trous détectés dans la série normalisée. */
  gaps: CandleGap[];
}

/**
 * Normalise une série de bougies vers la grille canonique du timeframe :
 *
 *   1. rejet des bougies invalides (OHLC/NaN/timestamp non fini) ;
 *   2. alignement : `time = bucketStart(time, period)` ;
 *   3. déduplication par `bucketTimeSec` — pour un même bucket on garde la
 *      bougie la plus complète (volume le plus élevé ; à volume égal, la
 *      dernière reçue) ;
 *   4. tri croissant strict (un bucket = une bougie = une clé unique) ;
 *   5. détection des trous.
 *
 * Utilisée par le `CandleSyncManager` avant TOUTE fusion historique ↔ live
 * et par le cache persistant au chargement (schemaVersion 2).
 */
export function normalizeCandleSeries<T extends GridCandle>(
  candles: T[],
  periodSec: number,
): NormalizeResult<T> {
  const byBucket = new Map<number, T>();
  let realigned = 0;
  let duplicates = 0;
  let invalid = 0;

  for (const c of candles) {
    if (!c || !Number.isFinite(c?.time) || !isOhlcValid(c)) {
      invalid++;
      continue;
    }
    const bucket = bucketStart(c.time, periodSec);
    if (bucket !== c.time) realigned++;
    const existing = byBucket.get(bucket);
    if (existing) {
      duplicates++;
      // Garde la bougie la plus complète (volume supérieur), sinon la dernière.
      const incomingVol = c.volume ?? 0;
      const existingVol = existing.volume ?? 0;
      if (incomingVol >= existingVol) byBucket.set(bucket, { ...c, time: bucket });
    } else {
      byBucket.set(bucket, { ...c, time: bucket });
    }
  }

  const sorted = [...byBucket.keys()].sort((a, b) => a - b).map(t => byBucket.get(t)!);
  return {
    candles: sorted,
    realigned,
    duplicates,
    invalid,
    gaps: findGaps(sorted, periodSec),
  };
}
