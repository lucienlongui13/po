/**
 * pattern-performance-logger.ts
 * ==============================
 * Tracks performance of every detected pattern strategy.
 *
 * For each pattern that triggers a trade, we record:
 *   - Pattern ID + name + category
 *   - Action (CALL/PUT)
 *   - Entry price, stop loss, take profit
 *   - Order placed (amount, expiry, timestamp)
 *   - Final result (WIN/LOSS, profit)
 *   - Signal confidence
 *   - Asset, strategy ID, mode (demo/real)
 *
 * File: .logs/pattern-performance.json
 */

import * as fs from 'fs';
import * as path from 'path';

export interface PatternTradeRecord {
  tradeId: string;
  patternId: string;        // e.g. "#0044"
  patternName: string;
  patternCategory: string;
  signalAction: 'CALL' | 'PUT';
  confidence: number;
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  amount: number;
  expirySeconds: number;
  asset: string;
  strategyId: string;
  mode: 'demo' | 'real';
  timestamp: string;        // ISO when signal detected
  result: 'PENDING' | 'WIN' | 'LOSS';
  profit: number;
  closedAt: string | null;  // ISO when trade closed
  dealId: string | null;
}

export interface PatternStats {
  patternId: string;
  patternName: string;
  category: string;
  totalTrades: number;
  wins: number;
  losses: number;
  pending: number;
  winRate: number;          // 0..1 (excludes pending)
  totalProfit: number;
  avgConfidence: number;
  lastTraded: string | null;
}

export interface PatternPerformanceFile {
  trades: PatternTradeRecord[];
  stats: Record<string, PatternStats>;
  lastUpdated: string;
}

const LOG_FILE = path.join(process.cwd(), '..', '..', '.logs', 'pattern-performance.json');
const MAX_TRADES = 5000;  // keep last 5000 trades

function ensureLogFile(): void {
  const dir = path.dirname(LOG_FILE);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(LOG_FILE)) {
    const empty: PatternPerformanceFile = { trades: [], stats: {}, lastUpdated: new Date().toISOString() };
    fs.writeFileSync(LOG_FILE, JSON.stringify(empty, null, 2));
  }
}

export function readPatternPerformance(): PatternPerformanceFile {
  try {
    ensureLogFile();
    const data = fs.readFileSync(LOG_FILE, 'utf-8');
    return JSON.parse(data) as PatternPerformanceFile;
  } catch {
    return { trades: [], stats: {}, lastUpdated: new Date().toISOString() };
  }
}

/**
 * Record a new pattern trade (when signal fires and order is placed).
 * Returns the tradeId for later update when the deal closes.
 */
export function recordPatternTrade(
  record: Omit<PatternTradeRecord, 'tradeId' | 'result' | 'profit' | 'closedAt' | 'dealId'>,
): string {
  try {
    const log = readPatternPerformance();
    const tradeId = `PT-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
    const fullRecord: PatternTradeRecord = {
      ...record,
      tradeId,
      result: 'PENDING',
      profit: 0,
      closedAt: null,
      dealId: null,
    };
    log.trades.push(fullRecord);
    // Prune
    if (log.trades.length > MAX_TRADES) {
      log.trades = log.trades.slice(-MAX_TRADES);
    }

    // Update stats
    if (!log.stats[record.patternId]) {
      log.stats[record.patternId] = {
        patternId: record.patternId,
        patternName: record.patternName,
        category: record.patternCategory,
        totalTrades: 0, wins: 0, losses: 0, pending: 0,
        winRate: 0, totalProfit: 0, avgConfidence: 0,
        lastTraded: null,
      };
    }
    const stats = log.stats[record.patternId];
    stats.totalTrades++;
    stats.pending++;
    stats.lastTraded = new Date().toISOString();
    // Recalculate avg confidence
    const patternTrades = log.trades.filter(t => t.patternId === record.patternId);
    stats.avgConfidence = patternTrades.reduce((a, t) => a + t.confidence, 0) / patternTrades.length;

    log.lastUpdated = new Date().toISOString();
    ensureLogFile();
    fs.writeFileSync(LOG_FILE, JSON.stringify(log, null, 2));
    return tradeId;
  } catch (e) {
    console.error('[pattern-performance] recordPatternTrade error:', e);
    return '';
  }
}

/**
 * Update a pattern trade when the deal closes.
 * Matches by tradeId (if available) or by patternId + timestamp proximity.
 */
export function updatePatternTradeResult(
  tradeId: string | null,
  patternId: string | null,
  dealId: string,
  won: boolean,
  profit: number,
): void {
  try {
    const log = readPatternPerformance();
    let updated = false;

    // Try to match by tradeId first
    if (tradeId) {
      const trade = log.trades.find(t => t.tradeId === tradeId);
      if (trade && trade.result === 'PENDING') {
        trade.result = won ? 'WIN' : 'LOSS';
        trade.profit = profit;
        trade.closedAt = new Date().toISOString();
        trade.dealId = dealId;
        updated = true;
      }
    }

    // Fallback: match by patternId + most recent PENDING trade
    if (!updated && patternId) {
      const pending = log.trades
        .filter(t => t.patternId === patternId && t.result === 'PENDING')
        .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      if (pending.length > 0) {
        const trade = pending[0];
        trade.result = won ? 'WIN' : 'LOSS';
        trade.profit = profit;
        trade.closedAt = new Date().toISOString();
        trade.dealId = dealId;
        updated = true;
      }
    }

    if (updated) {
      // Recalculate stats for this pattern
      if (patternId && log.stats[patternId]) {
        const stats = log.stats[patternId];
        const patternTrades = log.trades.filter(t => t.patternId === patternId);
        const closed = patternTrades.filter(t => t.result !== 'PENDING');
        stats.wins = closed.filter(t => t.result === 'WIN').length;
        stats.losses = closed.filter(t => t.result === 'LOSS').length;
        stats.pending = patternTrades.filter(t => t.result === 'PENDING').length;
        stats.winRate = closed.length > 0 ? stats.wins / closed.length : 0;
        stats.totalProfit = closed.reduce((a, t) => a + t.profit, 0);
      }
      log.lastUpdated = new Date().toISOString();
      ensureLogFile();
      fs.writeFileSync(LOG_FILE, JSON.stringify(log, null, 2));
    }
  } catch (e) {
    console.error('[pattern-performance] updatePatternTradeResult error:', e);
  }
}

/**
 * Get a summary of pattern performance sorted by winRate (best first).
 */
export function getPatternPerformanceSummary(limit: number = 20): string {
  const log = readPatternPerformance();
  const stats = Object.values(log.stats)
    .filter(s => s.totalTrades > 0)
    .sort((a, b) => b.winRate - a.winRate)
    .slice(0, limit);

  if (stats.length === 0) return 'No pattern trades recorded yet.';

  return stats.map(s =>
    `${s.patternId} ${s.patternName.substring(0, 40).padEnd(40)} — ${s.wins}W/${s.losses}L/${s.pending}P winRate=${Math.round(s.winRate * 100)}% profit=${s.totalProfit.toFixed(2)}`
  ).join('\n');
}

/**
 * Get all pattern stats for the frontend.
 */
export function getAllPatternStats(): PatternStats[] {
  const log = readPatternPerformance();
  return Object.values(log.stats)
    .filter(s => s.totalTrades > 0)
    .sort((a, b) => b.winRate - a.winRate);
}

/**
 * Get recent trades for the frontend.
 */
export function getRecentPatternTrades(limit: number = 50): PatternTradeRecord[] {
  const log = readPatternPerformance();
  return log.trades.slice(-limit).reverse();
}
