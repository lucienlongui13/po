/**
 * candle-history-cache.ts
 * ========================
 * Persistent candle history cache stored as JSON.
 *
 * Features:
 *   - On startup: cache is strictly capped to the latest 100 candles.
 *   - On startup: if cache exists, compare last candle timestamp with current time
 *     and fetch only the missing candles (days/hours/minutes/seconds gap).
 *   - In real-time: append live ticks as they arrive (deduplicated by time bucket).
 *   - Periodic flush to disk (every 30 seconds) to avoid data loss.
 *
 * File format (JSON):
 *   {
 *     "asset": "EURUSD_otc",
 *     "period": 5,
 *     "lastUpdated": 1787478594,
 *     "candleCount": 1555200,
 *     "candles": [
 *       { "time": 1787478590, "open": 1.08234, "high": 1.08240, "low": 1.08230, "close": 1.08238, "volume": 42 },
 *       ...
 *     ]
 *   }
 *
 * Hard safety limit: 100 candles maximum per asset/timeframe.
 */

import * as fs from 'fs';
import * as path from 'path';
import { bucketStart, findGaps, isOhlcValid } from './timeframe.js';
import { retainLatestPriceRegime } from './candle-integrity.js';

export interface CachedCandle {
  time: number;   // Unix seconds (bucket-aligned to period)
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

/**
 * Schéma v2 du fichier de cache (§12 du ToDo synchronisation) :
 *   - `schemaVersion`  : version du format (2 = grille canonique) ;
 *   - `timeBasis`      : origine du temps — TOUJOURS le début de bucket UTC ;
 *   - `lastMarketTimeSec` : dernier temps MARCHÉ vu (ticks), jamais l'horloge
 *     locale — utilisé pour la couture historique ↔ live au prochain boot.
 *
 * Les fichiers v1 (sans schemaVersion) restent lisibles : ils sont
 * rebucketisés + dédupliqués + triés + validés au chargement.
 */
export const CACHE_SCHEMA_VERSION = 2;
export const CACHE_TIME_BASIS = 'UTC_UNIX_BUCKET_START' as const;

export interface CandleHistoryFile {
  schemaVersion?: number;      // absent = legacy v1
  asset: string;
  period: number;
  timeBasis?: typeof CACHE_TIME_BASIS;
  /** Dernier temps marché (ticks) vu au moment de la sauvegarde. */
  lastMarketTimeSec?: number;
  lastUpdated: number;      // Unix seconds when cache was last refreshed
  candleCount: number;
  candles: CachedCandle[];
}

export class CandleHistoryCache {
  private asset: string;
  private period: number;
  private cacheDir: string;
  private candles: Map<number, CachedCandle> = new Map();
  private sortedTimes: number[] = [];
  private dirty: boolean = false;
  private flushTimer: NodeJS.Timeout | null = null;
  private maxCandles: number;
  /** Dernier temps MARCHÉ (ticks) vu — §4/§7 : jamais Date.now(). */
  private lastMarketTimeSec = 0;

  /**
   * @param asset e.g. "EURUSD_otc"
   * @param period e.g. 5 (S5)
   * @param cacheDir Directory where the JSON file is stored
   * @param maxCandles Max candles to keep (hard cap 300)
   */
  constructor(asset: string, period: number, cacheDir: string, maxCandles?: number) {
    this.asset = asset;
    this.period = period;
    this.cacheDir = cacheDir;
    // Hard cap: CandleHistoryCache is a bounded seam buffer, not a long-term DB.
    this.maxCandles = Math.max(1, Math.min(300, Math.floor(maxCandles ?? 300)));
    // Create the cache directory if it doesn't exist (recursive)
    try {
      if (!fs.existsSync(cacheDir)) {
        fs.mkdirSync(cacheDir, { recursive: true });
      }
      // Verify the directory is writable
      fs.accessSync(cacheDir, fs.constants.W_OK);
    } catch (e: any) {
      console.error(`[CandleHistoryCache] ERROR creating cache dir "${cacheDir}": ${e.message}`);
      console.error(`[CandleHistoryCache] Falling back to /tmp/candle-cache`);
      this.cacheDir = '/tmp/candle-cache';
      try {
        if (!fs.existsSync(this.cacheDir)) {
          fs.mkdirSync(this.cacheDir, { recursive: true });
        }
      } catch (e2: any) {
        console.error(`[CandleHistoryCache] FATAL: cannot create fallback dir: ${e2.message}`);
      }
    }
    console.log(`[CandleHistoryCache] Initialized for ${asset} S${period} → ${this.getFilePath()}`);
  }

  /** Get the file path for this asset+period combination */
  private getFilePath(): string {
    // Sanitize asset name for filesystem
    const safeAsset = this.asset.replace(/[^a-zA-Z0-9_-]/g, '_');
    return path.join(this.cacheDir, `candles_${safeAsset}_S${this.period}.json`);
  }

  /**
   * Load the cache from disk.
   *
   * VALIDATION DE GRILLE AU CHARGEMENT (§12) — quel que soit le schéma :
   *   1. bougies OHLC invalides (NaN, high < low…) → REJETÉES ;
   *   2. timestamps non alignés → REBUCKETISÉS sur la grille du timeframe ;
   *   3. doublons de bucket → DÉDUPLIQUÉS (volume le plus élevé gagne) ;
   *   4. tri croissant strict ;
   *   5. trous détectés et journalisés (jamais comblés par des timestamps
   *      synthétiques — la réparation passe par un fetch historique ciblé).
   *
   * Les caches de timeframes DIFFÉRENTS ne sont jamais fusionnés (un
   * fichier = un couple asset+period).
   *
   * @returns true if cache was loaded, false if no cache file exists
   */
  load(): boolean {
    const filePath = this.getFilePath();
    if (!fs.existsSync(filePath)) {
      return false;
    }
    try {
      const raw = fs.readFileSync(filePath, 'utf-8');
      const data: CandleHistoryFile = JSON.parse(raw);
      if (data.asset !== this.asset || data.period !== this.period) {
        // Cache is for a different asset/period — ignore
        return false;
      }
      this.candles.clear();
      this.sortedTimes = [];

      // ── Validation de grille + dédup + tri ──
      let rejected = 0, realigned = 0, duplicates = 0;
      const bucketOf = (t: number) => bucketStart(t, this.period);
      for (const c of data.candles) {
        if (!c || !isOhlcValid(c)) {
          rejected++;
          continue;
        }
        const bucket = bucketOf(c.time);
        if (bucket !== c.time) realigned++;
        const existing = this.candles.get(bucket);
        if (existing) {
          duplicates++;
          if ((c.volume ?? 0) >= (existing.volume ?? 0)) {
            this.candles.set(bucket, { ...c, time: bucket });
          }
        } else {
          this.candles.set(bucket, { ...c, time: bucket });
        }
      }
      this.rebuildSortedTimes();
      // Old cache files can be huge. Trim immediately on load.
      this.trimToMax();

      // ── Détection des trous (journalisée, jamais comblée synthétiquement) ──
      const gaps = findGaps(this.getSortedCandles(), this.period);
      const schemaLabel = data.schemaVersion ? `v${data.schemaVersion}` : 'legacy v1 → migré';
      console.log(
        `[CandleHistoryCache] Loaded ${this.candles.size} candles from ${filePath} ` +
        `(${schemaLabel}, lastUpdated: ${new Date(data.lastUpdated * 1000).toISOString()})` +
        (rejected || realigned || duplicates
          ? ` — validation grille: ${rejected} rejetées, ${realigned} réalignées, ${duplicates} doublons`
          : '') +
        (gaps.length > 0
          ? ` — ${gaps.length} trou(s) détecté(s): ${gaps.slice(0, 3).map(g => `[${g.startTime}..${g.endTime}] ${g.missingCandles} manquantes`).join(', ')}${gaps.length > 3 ? '…' : ''}`
          : '')
      );
      if (rejected > 0 || realigned > 0 || duplicates > 0) this.dirty = true;

      // Resture le dernier temps marché connu (couture live au boot).
      const lastCandleTime = this.getLastCandleTime();
      this.lastMarketTimeSec = Math.max(
        Number.isFinite(data.lastMarketTimeSec) ? (data.lastMarketTimeSec as number) : 0,
        lastCandleTime,
      );
      return true;
    } catch (e: any) {
      console.error(`[CandleHistoryCache] Failed to load cache: ${e.message}`);
      return false;
    }
  }

  /**
   * Save the cache to disk (only if dirty).
   */
  save(force: boolean = false): void {
    if (!this.dirty && !force) return;
    const filePath = this.getFilePath();
    const sortedCandles = this.getSortedCandles();
    const data: CandleHistoryFile = {
      schemaVersion: CACHE_SCHEMA_VERSION,
      asset: this.asset,
      period: this.period,
      timeBasis: CACHE_TIME_BASIS,
      lastMarketTimeSec: this.lastMarketTimeSec,
      lastUpdated: Math.floor(Date.now() / 1000),
      candleCount: sortedCandles.length,
      candles: sortedCandles,
    };
    try {
      const jsonStr = JSON.stringify(data);
      const sizeMB = (jsonStr.length / 1024 / 1024).toFixed(2);
      // Write to a temp file first, then rename (atomic write)
      const tmpPath = filePath + '.tmp';
      fs.writeFileSync(tmpPath, jsonStr);
      fs.renameSync(tmpPath, filePath);
      this.dirty = false;
      console.log(`[CandleHistoryCache] SAVED ${sortedCandles.length} candles (${sizeMB} MB) → ${filePath}`);
    } catch (e: any) {
      console.error(`[CandleHistoryCache] Failed to save cache to ${filePath}: ${e.message}`);
      // If save fails (e.g. disk full), try saving only the last 100 candles.
      try {
        const reduced = sortedCandles.slice(-100);
        const reducedData: CandleHistoryFile = {
          ...data,
          candleCount: reduced.length,
          candles: reduced,
        };
        fs.writeFileSync(filePath, JSON.stringify(reducedData));
        this.dirty = false;
        console.warn(`[CandleHistoryCache] Saved REDUCED cache (${reduced.length} candles) after full save failed`);
      } catch (e2: any) {
        console.error(`[CandleHistoryCache] FATAL: even reduced save failed: ${e2.message}`);
      }
    }
  }

  /** Start periodic flush to disk (every 30 seconds) */
  startPeriodicFlush(intervalMs: number = 30000): void {
    if (this.flushTimer) clearInterval(this.flushTimer);
    this.flushTimer = setInterval(() => {
      this.save();
    }, intervalMs);
  }

  /** Stop periodic flush and save final state */
  stop(): void {
    if (this.flushTimer) {
      clearInterval(this.flushTimer);
      this.flushTimer = null;
    }
    this.save(true);
  }

  /**
   * Get the timestamp of the last candle in the cache.
   * @returns Unix seconds, or 0 if cache is empty
   */
  getLastCandleTime(): number {
    if (this.sortedTimes.length === 0) return 0;
    return this.sortedTimes[this.sortedTimes.length - 1];
  }

  /**
   * Get the timestamp of the first candle in the cache.
   * @returns Unix seconds, or 0 if cache is empty
   */
  getFirstCandleTime(): number {
    if (this.sortedTimes.length === 0) return 0;
    return this.sortedTimes[0];
  }

  /** Vide entièrement le cache courant (utilisé pour quarantiner un cache périmé). */
  clear(): void {
    if (this.candles.size === 0) return;
    this.candles.clear();
    this.sortedTimes = [];
    // Le temps marché appartient au flux live, pas au contenu du cache.
    // On le préserve pour éviter de recréer une couture au prochain démarrage.
    this.dirty = true;
  }

  /**
   * Get the number of candles in the cache.
   */
  size(): number {
    return this.candles.size;
  }

  /**
   * Add a batch of historical candles (from server fetch).
   * Duplicates (same time bucket) are merged — the new candle overwrites the old one
   * if it has more recent data (higher volume or later close).
   *
   * DÉFENSE MULTI-ACTIFS : toute bougie dont le prix s'écarte de plus de
   * ×10 de la médiane récente du cache est REJETÉE (le broker peut servir
   * des bougies d'un autre actif lors de requêtes croisées/auto-switch).
   */
  addHistoricalBatch(candles: CachedCandle[]): { added: number; updated: number; rejected: number } {
    let added = 0;
    let updated = 0;
    let rejected = 0;
    const refPrice = this.referencePrice();
    for (const c of candles) {
      if (!this.isPlausiblePrice(c.close, refPrice)) {
        rejected++;
        continue;
      }
      // Align time to period bucket (grille canonique — timeframe.ts)
      const bucket = bucketStart(c.time, this.period);
      const existing = this.candles.get(bucket);
      if (existing) {
        // Merge: keep the one with higher volume (more complete)
        if (c.volume > existing.volume) {
          this.candles.set(bucket, { ...c, time: bucket });
          updated++;
        }
      } else {
        this.candles.set(bucket, { ...c, time: bucket });
        added++;
      }
    }
    if (added > 0 || updated > 0) {
      this.rebuildSortedTimes();
      this.dirty = true;
    }
    this.trimToMax();
    return { added, updated, rejected };
  }

  /**
   * Add or update a single candle (from real-time tick).
   * If the candle bucket doesn't exist, create it.
   * If it exists, update OHLCV incrementally.
   *
   * DÉFENSE MULTI-ACTIFS : un tick dont le prix s'écarte de plus de ×10 de
   * la médiane récente est IGNORÉ (changement d'actif non encore propagé).
   */
  addTick(time: number, price: number): CachedCandle | null {
    if (!Number.isFinite(price) || price <= 0) return null;
    const refPrice = this.referencePrice();
    if (!this.isPlausiblePrice(price, refPrice)) {
      return null; // tick d'un autre actif — jamais écrit dans CE cache
    }
    // §3/§4 : le temps marché du tick est conservé SOUS-SECONDE pour la
    // référence lastMarketTimeSec ; seul le bucket est aligné au timeframe.
    if (time > this.lastMarketTimeSec) this.lastMarketTimeSec = time;
    const bucket = bucketStart(time, this.period);
    const existing = this.candles.get(bucket);
    let candle: CachedCandle;
    if (existing) {
      candle = {
        time: bucket,
        open: existing.open,
        high: Math.max(existing.high, price),
        low: Math.min(existing.low, price),
        close: price,
        volume: existing.volume + 1,
      };
    } else {
      candle = {
        time: bucket,
        open: price,
        high: price,
        low: price,
        close: price,
        volume: 1,
      };
      this.sortedTimes.push(bucket);
      this.sortedTimes.sort((a, b) => a - b);
    }
    this.candles.set(bucket, candle);
    this.dirty = true;
    return candle;
  }

  /**
   * Retourne uniquement le dernier régime de prix continu.
   * Un vieux cache peut contenir un ancien actif ou une ancienne session :
   * la priorité est toujours donnée au segment le plus récent.
   */
  getLatestPriceRegime(opts: { maxRelativeStep?: number; maxRelativeToAnchor?: number } = {}):
    { candles: CachedCandle[]; dropped: number; breakIndex: number | null } {
    const result = retainLatestPriceRegime(this.getSortedCandles(), opts)
    return { candles: result.clean, dropped: result.dropped, breakIndex: result.breakIndex }
  }

  /**
   * Get all candles sorted by time (ascending).
   * @param maxCount If provided, return only the last N candles
   */
  getSortedCandles(maxCount?: number): CachedCandle[] {
    if (maxCount && this.sortedTimes.length > maxCount) {
      const startIdx = this.sortedTimes.length - maxCount;
      const times = this.sortedTimes.slice(startIdx);
      return times.map(t => this.candles.get(t)!).filter(Boolean);
    }
    return this.sortedTimes.map(t => this.candles.get(t)!).filter(Boolean);
  }

  /**
   * Get candles within a time range [startTime, endTime] (inclusive).
   */
  getCandlesInRange(startTime: number, endTime: number): CachedCandle[] {
    const result: CachedCandle[] = [];
    for (const t of this.sortedTimes) {
      if (t >= startTime && t <= endTime) {
        result.push(this.candles.get(t)!);
      }
      if (t > endTime) break;
    }
    return result;
  }

  /** Dernier temps MARCHÉ (ticks) vu par ce cache (0 = aucun). */
  getLastMarketTimeSec(): number {
    return this.lastMarketTimeSec;
  }

  /** Dernier temps marché connu — utilisé comme référence de couture live. */
  setLastMarketTimeSec(timeSec: number): void {
    if (Number.isFinite(timeSec) && timeSec > this.lastMarketTimeSec) {
      this.lastMarketTimeSec = timeSec;
    }
  }

  /**
   * Calculate the missing time gap between the last candle and now.
   * NOTE : Date.now() est légitime ICI (planification de fraîcheur d'un fetch,
   * pas de clôture de bougie) ; lastMarketTimeSec protège contre une horloge
   * locale en retard sur le marché.
   */
  getMissingRange(): { startTime: number; candleCount: number } {
    const lastTime = Math.max(this.getLastCandleTime(), 0);
    const now = Math.max(Math.floor(Date.now() / 1000), this.lastMarketTimeSec);
    if (lastTime === 0) {
      // No cache — fetch only the latest 100 candles.
      const candleCount = 100;
      const startTime = now - candleCount * this.period;
      return { startTime, candleCount };
    }
    // Resume from last candle + period
    const startTime = lastTime + this.period;
    const candleCount = Math.min(100, Math.floor((now - startTime) / this.period) + 1);
    return { startTime, candleCount: Math.max(0, candleCount) };
  }

  /** Rebuild the sorted times array from the map keys */
  private rebuildSortedTimes(): void {
    this.sortedTimes = Array.from(this.candles.keys()).sort((a, b) => a - b);
  }

  // ────────────────────────────────────────────────────────────────────
  // DÉFENSE MULTI-ACTIFS (contamination des caches 90 j)
  // ────────────────────────────────────────────────────────────────────

  /** Prix de référence = médiane des closes des 200 dernières bougies. */
  private referencePrice(): number {
    const n = this.sortedTimes.length;
    if (n === 0) return 0;
    const closes: number[] = [];
    for (let i = n - 1; i >= 0 && closes.length < 200; i--) {
      const c = this.candles.get(this.sortedTimes[i]);
      if (c && Number.isFinite(c.close) && c.close > 0) closes.push(c.close);
    }
    if (closes.length === 0) return 0;
    closes.sort((a, b) => a - b);
    return closes[Math.floor(closes.length / 2)];
  }

  /** Un prix est plausible s'il reste dans ±1 décade (×10) de la référence. */
  private isPlausiblePrice(price: number, refPrice: number): boolean {
    if (!Number.isFinite(price) || price <= 0) return false;
    if (refPrice <= 0) return true; // cache vide — première bougie acceptée
    return Math.abs(Math.log10(price) - Math.log10(refPrice)) <= 1;
  }

  /**
   * PURGE des bougies contaminantes déjà présentes sur disque.
   *
   * Auto-guérison au chargement : les fichiers créés avant les garde-fous
   * peuvent contenir des bougies d'autres actifs (ex. cache EURGBP avec
   * XAUUSD ~4400 / EURJPY ~185 mélangés). Supprime toute bougie dont le
   * close s'écarte de plus de ×10 de la médiane des bougies récentes.
   * @returns nombre de bougies supprimées.
   */
  purgePriceOutliers(maxDecades: number = 1): number {
    const n = this.sortedTimes.length;
    if (n === 0) return 0;
    const refPrice = this.referencePrice();
    if (refPrice <= 0) return 0;
    const logRef = Math.log10(refPrice);
    let removed = 0;
    for (const t of this.sortedTimes) {
      const c = this.candles.get(t);
      if (!c) continue;
      const bad = !Number.isFinite(c.close) || c.close <= 0
        || Math.abs(Math.log10(Math.max(c.close, Number.MIN_VALUE)) - logRef) > maxDecades
        || !Number.isFinite(c.open) || !Number.isFinite(c.high) || !Number.isFinite(c.low);
      if (bad) {
        this.candles.delete(t);
        removed++;
      }
    }
    if (removed > 0) {
      this.rebuildSortedTimes();
      this.dirty = true;
    }
    return removed;
  }

  /** Trim the cache to maxCandles (remove oldest) */
  private trimToMax(): void {
    if (this.candles.size <= this.maxCandles) return;
    const excess = this.candles.size - this.maxCandles;
    const toRemove = this.sortedTimes.slice(0, excess);
    for (const t of toRemove) {
      this.candles.delete(t);
    }
    this.sortedTimes = this.sortedTimes.slice(excess);
    this.dirty = true;
  }
}
