/**
 * candle-builder.ts — Construction des bougies OHLC depuis les ticks marché.
 * =======================================================================
 *
 * Extraits d'index.ts et durcis selon le ToDo « Synchronisation historique ↔
 * stream des bougies par timeframe » :
 *
 * §7 — CLÔTURE PAR LE TEMPS MARCHÉ UNIQUEMENT :
 *   la bougie [t, t+period) est définitivement terminée uniquement quand un
 *   tick du marché appartient à un bucket STRICTEMENT supérieur. JAMAIS
 *   `Date.now()` seul comme source de vérité OHLC.
 *
 * §8 — POLITIQUE DES TICKS (3 cas, compteurs dédiés) :
 *   - tick dans le bucket courant  → mise à jour OHLC ;
 *   - tick dans un bucket futur    → clôture du courant puis avancement ;
 *   - tick dans un bucket déjà clôturé → DROP + métrique (jamais de
 *     ré-ouverture d'une bougie clôturée).
 *   Compteurs : `duplicateTickDropped` (timestamp rejoué/antérieur),
 *   `lateTickDropped` (bucket déjà clôturé), `outOfOrderTickDropped`
 *   (timestamp plus récent mais bucket antérieur à la formation).
 *
 * §9 — SEED SÛR :
 *   `seed(candles, { referenceMarketTimeSec, periodSec, source })` :
 *   référence OBLIGATOIRE (temps marché, jamais Date.now()), alignement sur
 *   la grille via `bucketStart`, déduplication, ordre strict vérifié, et
 *   séparation explicite closed / forming.
 *
 * Invariants garantis après chaque opération :
 *
 *   closed[i].time < closed[i + 1].time
 *   closed[i].time % period === 0
 *   forming === null || forming.time % period === 0
 *   forming === null || forming.time > lastClosed.time
 */

import { bucketStart, normalizeCandleSeries } from './timeframe.js';

export interface CandleLike {
  /** bucketTimeSec — début UTC canonique de la bougie (aligné au timeframe). */
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
}

/** Origine du seed — détermine la confiance de la série initiale. */
export type SeedSource = 'history' | 'reaggregated-ticks' | 'cache';

export interface SeedOptions {
  /**
   * Référence = DERNIER TEMPS MARCHÉ connu (temps broker, jamais l'horloge
   * locale). Le bucket courant est `bucketStart(referenceMarketTimeSec)`.
   * Si aucune session live n'existe encore (seed cache au login), utiliser
   * `lastCandleTime + periodSec` (tout est alors clôturé) — jamais Date.now().
   */
  referenceMarketTimeSec: number;
  /** Timeframe en secondes de la série seedée. */
  periodSec: number;
  /** Origine des bougies (priorité : history > reaggregated-ticks > cache). */
  source: SeedSource;
  /**
   * Dernier tick LIVE marché réellement reçu (anti-rejeu). 0 / absent =
   * aucune session live (boot cache) → le normaliseur amont garantit déjà
   * l'anti-rejeu, et le comparateur de buckets prend le relais ici.
   */
  latestLiveTickTimeSec?: number;
}

export interface CandleBuilderStats {
  ticksAccepted: number;
  /** Tick rejoué / timestamp <= dernier tick vu (anti-rejeu reconnexion). */
  duplicateTickDropped: number;
  /** Tick atterrissant dans un bucket déjà clôturé. */
  lateTickDropped: number;
  /** Tick au timestamp plus récent mais bucket antérieur à la formation. */
  outOfOrderTickDropped: number;
  /** Bougies clôturées (avancement de bucket). */
  candlesClosed: number;
  /** Callbacks de clôture effectivement invoqués (== candlesClosed). */
  callbacksFired: number;
  /** Nombre de seeds reçus. */
  seeded: number;
  /** Dernière bougie clôturée « réanimée » : tick live prouvé dans le bucket
   *  du dernier bucket clôturé (cache frais au login). */
  revivedForming: number;
}

export class CandleBuilder {
  private closed: CandleLike[] = [];
  private forming: CandleLike | null = null;
  private periodSec: number;
  private onCandleClosedCb: ((c: CandleLike) => void) | null = null;
  /** Dernier timestamp de tick marché INGÉRÉ (invariant anti-rejeu). */
  private lastTickTime = 0;
  private readonly maxCandles: number;
  private stats: CandleBuilderStats = {
    ticksAccepted: 0, duplicateTickDropped: 0, lateTickDropped: 0,
    outOfOrderTickDropped: 0, candlesClosed: 0, callbacksFired: 0,
    seeded: 0, revivedForming: 0,
  };

  constructor(periodSec: number, opts: { maxCandles?: number } = {}) {
    this.periodSec = periodSec;
    this.maxCandles = Math.max(1, Math.min(300, Math.floor(opts.maxCandles ?? 300)));
  }

  /** Change de timeframe : la formation courante est invalidée. */
  setPeriod(periodSec: number): void {
    if (periodSec !== this.periodSec) {
      this.periodSec = periodSec;
      this.forming = null;
      this.lastTickTime = 0;
    }
  }

  getPeriod(): number {
    return this.periodSec;
  }

  /**
   * SEED — remplace la série par une série canonique normalisée.
   *
   * La dernière bougie devient la bougie EN FORMATION si et seulement si son
   * bucket === bucketStart(referenceMarketTimeSec, periodSec) ; sinon tout est
   * clôturé et le prochain tick vivant du bucket du dernier close « réanime »
   * cette bougie (un tick marché dans un bucket prouve que ce bucket est
   * vivant — logique temps marché pur, sans horloge locale).
   */
  seed(candles: CandleLike[], opts: SeedOptions): void {
    this.stats.seeded++;
    if (this.periodSec !== opts.periodSec) {
      this.periodSec = opts.periodSec;
    }
    const norm = normalizeCandleSeries(candles, opts.periodSec);
    const arr = norm.candles.slice(-this.maxCandles);

    if (arr.length === 0) {
      this.closed = [];
      this.forming = null;
      this.lastTickTime = 0;
      return;
    }

    const refBucket = bucketStart(opts.referenceMarketTimeSec, opts.periodSec);
    const last = arr[arr.length - 1];
    if (last.time === refBucket) {
      // bucket encore ouvert → bougie en formation (le live la mettra à jour)
      this.closed = arr.slice(0, -1);
      this.forming = { ...last };
    } else {
      this.closed = arr;
      this.forming = null;
    }
    this.trim();
    // Anti-rejeu : quand une session live tourne, le dernier tick marché réel
    // interdit tout rejeu antérieur. Pour un seed 'reaggregated-ticks', la
    // référence EST le dernier tick. Un seed history/cache sans session live
    // n'a pas de ticks → 0 (le comparateur de buckets suffit, et le
    // normaliseur amont garantit déjà des timestamps strictement croissants).
    const liveRef = opts.latestLiveTickTimeSec
      ?? (opts.source === 'reaggregated-ticks' ? opts.referenceMarketTimeSec : 0);
    this.lastTickTime = Math.max(0, liveRef);
  }

  /**
   * ADD TICK — politique stricte §8. Retourne la bougie en formation mise à
   * jour, ou null si le tick a été droppé.
   */
  addTick(marketTimeSec: number, price: number): CandleLike | null {
    if (!Number.isFinite(marketTimeSec) || !Number.isFinite(price) || price <= 0) return null;

    // Anti-rejeu : timestamp rejoué ou en retard → drop (reconnexion, rejeu).
    if (marketTimeSec <= this.lastTickTime) {
      this.stats.duplicateTickDropped++;
      return null;
    }

    const bucket = bucketStart(marketTimeSec, this.periodSec);

    if (this.forming && bucket === this.forming.time) {
      // 1. Tick dans le bucket courant → mise à jour OHLC.
      this.applyTick(this.forming, price);
      this.lastTickTime = marketTimeSec;
      this.stats.ticksAccepted++;
      return this.forming;
    }

    if (!this.forming || bucket > this.forming.time) {
      // 2. Bucket futur → clôture du courant (UN SEUL callback) puis avance.
      if (this.forming) {
        this.closed.push(this.forming);
        this.stats.candlesClosed++;
        this.trim();
        if (this.onCandleClosedCb) {
          this.stats.callbacksFired++;
          try { this.onCandleClosedCb({ ...this.forming }); } catch { /* best-effort */ }
        }
      } else if (this.closed.length > 0 && bucket === this.closed[this.closed.length - 1].time) {
        // Cas « cache frais au login » : un tick marché vivant atterrit dans
        // le bucket du DERNIER bucket clôturé → ce bucket est en réalité
        // toujours ouvert → on le réanime comme bougie en formation.
        const revived = this.closed.pop()!;
        this.forming = revived;
        this.applyTick(this.forming, price);
        this.stats.revivedForming++;
        this.lastTickTime = marketTimeSec;
        this.stats.ticksAccepted++;
        return this.forming;
      }
      this.forming = { time: bucket, open: price, high: price, low: price, close: price, volume: 1 };
      this.lastTickTime = marketTimeSec;
      this.stats.ticksAccepted++;
      return this.forming;
    }

    // 3. bucket < forming.time (ou bucket <= dernier clôturé) → déjà clôturé.
    if (this.forming && marketTimeSec > this.lastTickTime) {
      // timestamp plus récent mais bucket antérieur : hors ordre (saut arrière).
      this.stats.outOfOrderTickDropped++;
    } else {
      this.stats.lateTickDropped++;
    }
    return null;
  }

  private applyTick(c: CandleLike, price: number): void {
    c.high = Math.max(c.high, price);
    c.low = Math.min(c.low, price);
    c.close = price;
    c.volume = (c.volume ?? 0) + 1;
  }

  private trim(): void {
    if (this.closed.length > this.maxCandles) {
      this.closed.splice(0, this.closed.length - this.maxCandles);
    }
  }

  /** Callback invoqué à CHAQUE clôture (exactement une fois par bougie). */
  setOnCandleClosed(cb: ((c: CandleLike) => void) | null): void {
    this.onCandleClosedCb = cb;
  }

  /** Dernières bougies CLÔTURÉES (sans la formation). */
  getClosedCandles(n = 100): CandleLike[] {
    return this.closed.slice(-n).map(c => ({ ...c }));
  }

  /** Bougie en formation (copie défensive ; null si aucune). */
  getFormingCandle(): CandleLike | null {
    return this.forming ? { ...this.forming } : null;
  }

  /** Série complète : clôturées + formation (même ordre que le graphique). */
  getCandles(): CandleLike[] {
    const out = this.closed.map(c => ({ ...c }));
    if (this.forming) out.push({ ...this.forming });
    return out;
  }

  getStats(): Readonly<CandleBuilderStats> {
    return { ...this.stats };
  }

  /** Remise à zéro complète (changement d'actif). */
  reset(): void {
    this.closed = [];
    this.forming = null;
    this.lastTickTime = 0;
  }
}
