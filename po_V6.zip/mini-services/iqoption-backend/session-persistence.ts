/**
 * session-persistence.ts — v6.3 : la session de trading SURVIT à la fermeture
 * du frontend ET aux redémarrages du backend.
 * ============================================================================
 *
 * Demande utilisateur :
 *   « je veux que le programme continue de fonctionner en backend même si
 *     j'ai fermé le frontend sur Chrome. »
 *
 * DEUX mécanismes complémentaires :
 *
 *   1. HEADLESS (aucune persistance nécessaire) : le backend est un PROCESSUS
 *      SÉPARÉ (port 3030) qui détient la connexion broker, les subscriptions,
 *      les contextes par asset et l'auto-trade. Fermer Chrome ne coupe QUE le
 *      socket.io UI — le trading continue intégralement. À la réouverture du
 *      frontend, le flux `status` (1 Hz) restaure l'affichage automatiquement.
 *
 *   2. PERSISTANCE DISQUE (ce module) : si le PROCESSUS backend lui-même
 *      s'arrête (redémarrage machine, crash, relance manuelle), tout l'état
 *      de trading est réappliqué au login suivant :
 *        - mode (single/multi) + assets sélectionnés (+ focus) ;
 *        - config auto-trade (stratégie, expiration, mise, Martingale/…) ;
 *        - état du Payout Guard ;
 *      → le login devient IDEMPOTENT : mêmes identifiants = REPRISE de la
 *        session précédente, pas de remise à zéro.
 *
 *      ⚠️ Les MOTS DE PASSE ne sont JAMAIS persistés (sécurité) : l'utilisateur
 *      ressaisit ses identifiants après un redémarrage du backend, puis la
 *      session est restaurée automatiquement (aucune re-sélection d'assets).
 *
 * Fichier : <backend>/data/backend-session.json — écriture atomique (tmp+rename).
 * Overridable via env SESSION_SNAPSHOT_DIR=0|off pour désactiver.
 *
 * Module isolé (fs) → importé par index.ts + tests.
 */

import { promises as fs } from 'node:fs';
import path from 'node:path';

/** Version du format (toute évolution du schéma doit incrémenter). */
export const PERSISTED_SESSION_VERSION = 3;

export interface PersistedSessionConfig {
  /** Forward-compatible: Save/Load may persist future UI/backend config fields. */
  [key: string]: unknown;
  strategyId?: string;
  bettingStrategy?: 'fixed' | 'martingale' | 'fibonacci';
  /** Mise de base ($). */
  baseAmount?: number;
  /** Expiration (s) — CHAMP AUTO TRADE (v6.1/v6.3 : respecté à la seconde). */
  expirySeconds?: number | null;
  /** Timeframe graphique (s). */
  candleSize?: number;
  /** Auto-trade global ON/OFF au moment de la sauvegarde. */
  autoTradeEnabled?: boolean;
  autoSwitchAssets?: boolean;
  /** v21 — « Stay on Forex OTC Only » : cibles Auto Switch limitées au Forex OTC. */
  stayOnForexOtcOnly?: boolean;
  /** v19 — L_Lucien ProTrader : switch « Confirmation bougie précédente ». */
  bosChochCisdConfirmCandle?: boolean;
  /** v19 — Garde-fou Martingale : nombre max de doublements (0 = illimité). */
  maxMartingaleSteps?: number;
  /** v24 — étapes de vérification CISD optionnelles (cases à cocher). */
  cisdGuardUp?: boolean;
  cisdGuardDown?: boolean;
  /** v25 — 'none' = les deux cases swing décochées (étape swing ignorée). */
  cisdGuardSwingMode?: 'intact' | 'violated' | 'none';
  cisdGuardConfirmBosUp?: boolean;
  cisdGuardConfirmChochUp?: boolean;
  cisdGuardConfirmBosDown?: boolean;
  cisdGuardConfirmChochDown?: boolean;
}

export interface PersistedSession {
  version: number;
  /** Horodatage de la sauvegarde (ms). */
  savedAt: number;
  mode: 'single' | 'multi';
  assets: string[];
  focus: string | null;
  config: PersistedSessionConfig;
  payoutGuardEnabled?: boolean;
}

const FILE_NAME = 'backend-session.json';

/** Chemin par défaut : <backend>/data/backend-session.json. */
export function defaultSessionSnapshotPath(backendDir: string): string | null {
  const env = (process.env.SESSION_SNAPSHOT_DIR ?? '').trim().toLowerCase();
  if (env === '0' || env === 'off' || env === 'false' || env === 'none') return null;
  if (env && env.length > 0) return path.join(env, FILE_NAME);
  return path.join(backendDir, 'data', FILE_NAME);
}

// ---------------------------------------------------------------------------
//  Validation / sanitization (le fichier peut être corrompu ou périmé)
// ---------------------------------------------------------------------------

function sanitizeMode(v: unknown): 'single' | 'multi' | null {
  return v === 'single' || v === 'multi' ? v : null;
}

/**
 * Valide un objet brut (JSON lu ou test) → PersistedSession ou null.
 * Tolérant : champs optionnels omis, mais mode + ≥ 1 asset obligatoires.
 */
export function sanitizePersistedSession(raw: unknown): PersistedSession | null {
  if (!raw || typeof raw !== 'object') return null;
  const r = raw as Record<string, unknown>;
  const mode = sanitizeMode(r.mode);
  if (!mode) return null;
  if (!Array.isArray(r.assets)) return null;
  const assets: string[] = [];
  const seen = new Set<string>();
  for (const a of r.assets) {
    if (typeof a !== 'string') continue;
    const name = a.trim();
    if (!name || seen.has(name)) continue;
    seen.add(name);
    assets.push(name);
  }
  if (assets.length === 0) return null;
  const cfgRaw = (r.config && typeof r.config === 'object' ? r.config : {}) as Record<string, unknown>;
  const config: PersistedSessionConfig = {};
  if (typeof cfgRaw.strategyId === 'string' && cfgRaw.strategyId.length > 0) {
    config.strategyId = cfgRaw.strategyId;
  }
  if (cfgRaw.bettingStrategy === 'fixed' || cfgRaw.bettingStrategy === 'martingale' || cfgRaw.bettingStrategy === 'fibonacci') {
    config.bettingStrategy = cfgRaw.bettingStrategy;
  }
  if (typeof cfgRaw.baseAmount === 'number' && Number.isFinite(cfgRaw.baseAmount) && cfgRaw.baseAmount >= 1) {
    config.baseAmount = cfgRaw.baseAmount;
  }
  if (typeof cfgRaw.expirySeconds === 'number' && Number.isFinite(cfgRaw.expirySeconds) && cfgRaw.expirySeconds > 0) {
    config.expirySeconds = cfgRaw.expirySeconds;
  }
  if (typeof cfgRaw.candleSize === 'number' && Number.isFinite(cfgRaw.candleSize) && cfgRaw.candleSize >= 1) {
    config.candleSize = cfgRaw.candleSize;
  }
  if (typeof cfgRaw.autoTradeEnabled === 'boolean') {
    config.autoTradeEnabled = cfgRaw.autoTradeEnabled;
  }
  if (typeof cfgRaw.autoSwitchAssets === 'boolean') config.autoSwitchAssets = cfgRaw.autoSwitchAssets;
  // v21 — « Stay on Forex OTC Only » (Auto Switch cibles Forex OTC uniquement).
  if (typeof cfgRaw.stayOnForexOtcOnly === 'boolean') config.stayOnForexOtcOnly = cfgRaw.stayOnForexOtcOnly;
  // v19 — switch « Confirmation bougie précédente » (L_Lucien ProTrader).
  if (typeof cfgRaw.bosChochCisdConfirmCandle === 'boolean') {
    config.bosChochCisdConfirmCandle = cfgRaw.bosChochCisdConfirmCandle;
  }
  // v19 — garde-fou Martingale : entier [0, 1000] (0 = illimité).
  if (typeof cfgRaw.maxMartingaleSteps === 'number' && Number.isFinite(cfgRaw.maxMartingaleSteps) && cfgRaw.maxMartingaleSteps >= 0) {
    config.maxMartingaleSteps = Math.min(1000, Math.floor(cfgRaw.maxMartingaleSteps));
  }
  // v24 — étapes de vérification CISD optionnelles (cases à cocher) :
  // booléens stricts + swingMode ∈ {'intact','violated','none'} (v25 —
  // 'none' = les deux cases swing décochées : étape swing ignorée).
  if (typeof cfgRaw.cisdGuardUp === 'boolean') config.cisdGuardUp = cfgRaw.cisdGuardUp;
  if (typeof cfgRaw.cisdGuardDown === 'boolean') config.cisdGuardDown = cfgRaw.cisdGuardDown;
  if (cfgRaw.cisdGuardSwingMode === 'intact' || cfgRaw.cisdGuardSwingMode === 'violated' || cfgRaw.cisdGuardSwingMode === 'none') {
    config.cisdGuardSwingMode = cfgRaw.cisdGuardSwingMode;
  }
  if (typeof cfgRaw.cisdGuardConfirmBosUp === 'boolean') config.cisdGuardConfirmBosUp = cfgRaw.cisdGuardConfirmBosUp;
  if (typeof cfgRaw.cisdGuardConfirmChochUp === 'boolean') config.cisdGuardConfirmChochUp = cfgRaw.cisdGuardConfirmChochUp;
  if (typeof cfgRaw.cisdGuardConfirmBosDown === 'boolean') config.cisdGuardConfirmBosDown = cfgRaw.cisdGuardConfirmBosDown;
  if (typeof cfgRaw.cisdGuardConfirmChochDown === 'boolean') config.cisdGuardConfirmChochDown = cfgRaw.cisdGuardConfirmChochDown;
  const focus = typeof r.focus === 'string' && r.focus.trim().length > 0 ? r.focus.trim() : null;
  return {
    version: typeof r.version === 'number' ? r.version : PERSISTED_SESSION_VERSION,
    savedAt: typeof r.savedAt === 'number' ? r.savedAt : 0,
    mode,
    assets,
    focus: focus && assets.includes(focus) ? focus : assets[0],
    config,
    payoutGuardEnabled: typeof r.payoutGuardEnabled === 'boolean' ? r.payoutGuardEnabled : undefined,
  };
}

// ---------------------------------------------------------------------------
//  Écriture / lecture (atomique)
// ---------------------------------------------------------------------------

/** Sauvegarde atomique (tmp + rename). Retourne false si désactivé/erreur. */
export async function savePersistedSession(
  filePath: string | null,
  snapshot: PersistedSession,
): Promise<boolean> {
  if (!filePath) return false;
  try {
    const payload: PersistedSession = { ...snapshot, version: PERSISTED_SESSION_VERSION, savedAt: Date.now() };
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    const tmp = `${filePath}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(payload, null, 2), 'utf-8');
    await fs.rename(tmp, filePath);
    return true;
  } catch {
    return false; // persistance best-effort — JAMAIS bloquante
  }
}

/** Charge la dernière session persistée (null si absente/corrompue/off). */
export async function loadPersistedSession(
  filePath: string | null,
): Promise<PersistedSession | null> {
  if (!filePath) return null;
  try {
    const text = await fs.readFile(filePath, 'utf-8');
    return sanitizePersistedSession(JSON.parse(text));
  } catch {
    return null;
  }
}

/** Supprime le fichier de session (déconnexion volontaire / réinitialisation). */
export async function clearPersistedSession(filePath: string | null): Promise<void> {
  if (!filePath) return;
  try {
    await fs.unlink(filePath);
  } catch {
    // absent → rien à faire
  }
}
