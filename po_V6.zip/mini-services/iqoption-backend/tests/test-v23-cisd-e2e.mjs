/**
 * test-v23-cisd-e2e.mjs — E2E Vérification CISD (swing intact + confirmation
 * par signal combiné) sur le VRAI backend + faux broker Pocket Option.
 * ============================================================================
 *
 * MISSION v23 : « sur les combinaisons CISD UP on vérifie que le swing high
 * le plus proche n'a pas été violé, et on attend le prochain signal — s'il
 * est le combiné BOS UP + CISD UP ou CHoCH UP + CISD UP alors on place le
 * CALL ; miroir CISD DOWN → PUT ».
 *
 * Géométrie du flux (S5, pathScript v23 du mock, B = 0.00012, W = 0.00004) :
 *   corps par bucket (×B, signe = direction), cycle de 10 bougies :
 *     [+3, -2, +1, -2.5, +0.5, +5, -1, +1, -0.5, +1.5]
 *   swings (par paires G→R / R→G) :
 *     sh : 3B+W@1 puis 2B+W@3 (descendants → dt) ;
 *     sl : 1B-W@2 puis -0.5B-W@4 (descendants → ut FAUX) ;
 *   bougie %10==5 (G, +5B) : cassure de sh0 2B+W au-delà de sh1 →
 *     CISD Up SEUL (swing INTACT : aucunes mèches au-dessus depuis la
 *     formation) → séquence ARMÉE, AUCUN ordre ;
 *   bougies 6-8 : aucun événement (l'armement attend) ;
 *   bougie %10==9 (G, +1.5B) : cassure du swing 5B+W avec sl ascendants
 *     (ut) → BOS Up + CISD Up = signal COMBINÉ de confirmation → CALL ▲.
 *
 * Phases :
 *   [A] L_LUCIEN PROTRADER (bougies clôturées) : ARMÉE visible dans
 *       strategy-state (swing high intact + EN ATTENTE), AUCUN ordre sur le
 *       CISD seul, puis ordre CALL sur le combiné — libellé complet
 *       « L_Lucien ProTrader · CALL ▲ · call-1 [CISD Up] · sans validation ·
 *       CISD Up confirmé (armé bougie T, swing P intact) » ;
 *   [B] NINJA PROTRADER : même séquence, ordre placé AVANT la clôture de la
 *       bougie de confirmation (ofs ≥ 2 dans le bucket %10==9) ;
 *   [C] PROTECTION DU SOLDE : flux RGG (BOS Up + CISD Up d'emblée à chaque
 *       3e bougie — JAMAIS de CISD seul car ut toujours vrai) → séquence
 *       vierge → AUCUN ordre, refus « SANS CISD Up vérifié préalable ».
 *
 * Exécution : node tests/test-v23-cisd-e2e.mjs
 */
import { spawn } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { io } from 'socket.io-client';
import { MockPoBroker } from './mock-po-broker.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BACKEND_DIR = path.resolve(__dirname, '..');
const BACKEND_PORT = 3030; // socket.io backend (codé en dur dans index.ts)

const RULE_EXPIRY = 4;    // expiration de la RÈGLE (jamais le global)
const GLOBAL_EXPIRY = 37; // piège : si le global fuit, on le voit

/** Corps signés par bucket (cycle de 10) — cf. en-tête. */
const PATH_SCRIPT = [3, -2, 1, -2.5, 0.5, 5, -1, 1, -0.5, 1.5];

let failures = 0, checks = 0;
function ok(cond, label) {
  checks++;
  if (cond) console.log(`  ✓ ${label}`);
  else { failures++; console.error(`  ✗ ${label}`); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

function main() {
  console.log('\n=== E2E Vérification CISD v23 — backend réel + faux broker (S5, pathScript, mèches) ===\n');

  const broker = new MockPoBroker({
    httpPort: 4540,             // ports dédiés — aucun conflit
    wsPort: 4541,
    candleSec: 5,
    settleDelayMs: 2500,
    historyBuckets: 300,
    pathScript: PATH_SCRIPT,    // v23 — géométrie exacte (CISD seul → combiné)
    bodySize: 0.00012,         // B
    wickSize: 0.00004,         // W (croisements STRICTS des swings)
    realtimeClosePush: true,    // chemin réel de règlement (2026-09-17)
    outcomeScript: ['win'],     // déterministe — le E2E teste le placement
  });
  let backend = null;
  let socket = null;

  const cleanupAll = (code) => {
    try {
      if (backend && backend.exitCode === null) {
        try { process.kill(-backend.pid, 'SIGKILL'); }
        catch { try { backend.kill('SIGKILL'); } catch { /* ignore */ } }
      }
    } catch { /* ignore */ }
    try { broker.stop(); } catch { /* ignore */ }
    try { if (socket) socket.close(); } catch { /* ignore */ }
    if (code != null) {
      console.log(`\n=== RÉSULTAT E2E : ${checks - failures}/${checks} vérifications OK ===`);
      process.exit(failures > 0 ? 1 : code);
    }
  };
  process.on('SIGINT', () => cleanupAll(130));
  process.on('uncaughtException', e => { console.error('UNCAUGHT:', e); cleanupAll(1); });

  (async () => {
    // ── 1. Faux broker ──
    const ports = await broker.start();
    console.log(`[1] faux broker PO démarré (http :${ports.httpPort}, ws :${ports.wsPort})`);

    // ── 2. VRAI backend, redirigé vers le faux broker ──
    console.log('[2] démarrage du VRAI backend (tsx index.ts)…');
    const backendLog = fs.openSync(path.join(BACKEND_DIR, 'e2e-v23-cisd.log'), 'w');
    backend = spawn('npx', ['tsx', 'index.ts'], {
      cwd: BACKEND_DIR,
      env: {
        ...process.env,
        PO_API_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_WEB_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_DEMO_WS_URL: `ws://127.0.0.1:${ports.wsPort}`,
        SESSION_SNAPSHOT_DIR: '0',
        PO_STARTUP_RANDOM_ASSET: '0',
        SOCIAL_DEBUG_PORT: '4340',
        NODE_ENV: 'development',
      },
      stdio: ['ignore', backendLog, backendLog],
      detached: true,
    });

    let connected = false;
    for (let i = 0; i < 40 && !connected; i++) {
      await sleep(500);
      socket = io(`http://127.0.0.1:${BACKEND_PORT}`, { transports: ['websocket'], path: '/', reconnection: false, timeout: 3000 });
      connected = await new Promise(r => { socket.once('connect', () => r(true)); socket.once('connect_error', () => r(false)); });
      if (!connected) { try { socket.close(); } catch { /* ignore */ } }
    }
    ok(connected, `backend joignable sur :${BACKEND_PORT} (socket.io connecté)`);
    if (!connected) { cleanupAll(1); return; }

    // ── 3. Séquence identique au frontend ──
    console.log('[3] login démo sur le faux broker…');
    const loginResult = await new Promise(r => {
      socket.once('login-result', r);
      socket.emit('login', { email: 'demo@e2e.test', password: 'demo-pass', mode: 'demo' });
      setTimeout(() => r({ ok: false, error: 'timeout login' }), 30000);
    });
    ok(loginResult?.ok === true, `login démo OK (uid=${loginResult?.user_id ?? '?'})`);
    if (!loginResult?.ok) { console.error('login échoué:', loginResult); cleanupAll(1); return; }

    socket.emit('set-config', { candleSize: 5, cooldownSeconds: 3, expirySeconds: GLOBAL_EXPIRY });
    await sleep(300);

    const selected = await new Promise(r => {
      socket.once('assets-selected', r);
      socket.emit('select-assets', { mode: 'single', assets: ['EURUSD_otc'] });
      setTimeout(() => r({ ok: false }), 15000);
    });
    ok(selected?.ok === true, 'asset sélectionné : EURUSD_otc (mode single)');

    socket.emit('set-auto-strategy', { strategyId: 'l_lucien_protrader' });
    await sleep(200);
    socket.emit('set-auto-config', { bettingStrategy: 'fixed', baseAmount: 1 });
    await sleep(300);

    // Règle CISD (LA cible de la mission) + PUT symétrique.
    socket.emit('set-auto-config', {
      bosChochCisdCallRules: [{ id: 'call-1', alerts: ['CISD Up'], expirationSeconds: RULE_EXPIRY }],
      bosChochCisdPutRules: [{ id: 'put-1', alerts: ['CISD Down'], expirationSeconds: RULE_EXPIRY }],
    });
    await sleep(300);

    const autoOn = await new Promise(r => {
      socket.once('auto-trade-status', r);
      socket.emit('set-auto-trade', { enabled: true });
      setTimeout(() => r(null), 10000);
    });
    ok(autoOn?.enabled !== false, 'auto-trade ON');
    ok(autoOn?.strategyId === 'l_lucien_protrader', `stratégie active = l_lucien_protrader (${autoOn?.strategyId})`);

    // ── Collecte globale ──
    const orders = [];        // { source, label, expirationSeconds, openTime, action, phase }
    const strategyStates = []; // { phase, strategyName, reason, cisdConfirmation }
    let phase = 'A';
    socket.on('trade-opened', (ev) => {
      if (ev?.source === 'l_lucien_protrader' || ev?.source === 'ninja_protrader') {
        orders.push({
          phase,
          source: ev.source,
          label: String(ev?.label ?? ''),
          expirationSeconds: Number(ev.expirationSeconds ?? 0),
          openTime: Number(ev.deal?.openTime ?? 0),
          action: String(ev.deal?.action ?? ''),
        });
        const o = orders[orders.length - 1];
        console.log(`    [ordre #${orders.length} · phase ${phase} · ${ev.source}] ${o.action.toUpperCase()} exp=${o.expirationSeconds}s bucketPos10=${Math.floor(o.openTime / 5) % 10} ofs=${o.openTime % 5} — ${o.label}`);
      }
    });
    socket.on('strategy-state', (st) => {
      if (st?.asset === 'EURUSD_otc') {
        strategyStates.push({
          phase,
          strategyName: String(st?.strategyName ?? ''),
          reason: String(st?.reason ?? ''),
          cisdConfirmation: st?.cisdConfirmation ?? null,
          action: String(st?.action ?? ''),
        });
      }
    });

    // ── [A] L_Lucien ProTrader : ARMÉE → AUCUN ordre → combiné → CALL ──
    console.log('[4] Phase A — L_Lucien ProTrader : CISD seul (armement) puis combiné (ordre)…');
    const phaseADeadline = Date.now() + 115_000; // 2 cycles complets + marge
    while (orders.length < 1 && Date.now() < phaseADeadline) await sleep(1000);
    ok(orders.length >= 1, `ordre L_Lucien placé sur le signal COMBINÉ (${orders.length} observé(s))`);
    const a = orders[0];
    if (a) {
      ok(a.source === 'l_lucien_protrader' && a.action === 'call', 'ordre A = CALL (L_Lucien)');
      ok(a.label.includes('L_Lucien ProTrader'), 'libellé A : stratégie L_Lucien ProTrader');
      ok(a.label.includes('call-1 [CISD Up]'), 'libellé A : combinaison call-1 [CISD Up]');
      ok(a.label.includes('CISD Up confirmé (armé bougie'), 'libellé A : « CISD Up confirmé (armé bougie …, swing … intact) »', a.label);
      ok(a.label.includes('swing') && a.label.includes('intact'), 'libellé A : swing vérifié intact documenté');
      ok(a.expirationSeconds === RULE_EXPIRY, `expiration A = ${RULE_EXPIRY}s (règle) — le global ${GLOBAL_EXPIRY}s n'a jamais fuité`);
      // L_Lucien évalue les bougies CLÔTURÉES : l'ordre part à la frontière
      // de la bougie de confirmation (%10==9) → bucket d'ouverture %10==0.
      ok(Math.floor(a.openTime / 5) % 10 === 0, `ordre A placé juste APRÈS la clôture de la bougie de confirmation (bucket %10=${Math.floor(a.openTime / 5) % 10})`);
    }
    const armeeA = strategyStates.filter(s => s.phase === 'A' && s.reason.includes('ARMÉE'));
    ok(armeeA.length > 0, `strategy-state « séquence CISD ARMÉE » observée avant l’ordre (${armeeA.length} états)`);
    ok(armeeA.some(s => s.reason.includes('swing high') && s.reason.includes('intact')), 'l’armement documente le swing high intact');
    ok(armeeA.some(s => s.reason.includes('EN ATTENTE')), 'l’armement documente l’attente du signal combiné');
    const confirmA = strategyStates.filter(s => s.phase === 'A' && s.cisdConfirmation);
    ok(confirmA.length > 0, `strategy-state porte cisdConfirmation (up) sur l’ordre (${confirmA.length} états)`);
    ok(confirmA.every(s => s.cisdConfirmation?.direction === 'up'), 'cisdConfirmation : direction up');
    // AUCUN ordre pendant la bougie d'armement (%10==5) ni entre les deux.
    const noEarlyA = orders.filter(o => o.phase === 'A' && o.source === 'l_lucien_protrader')
      .every(o => Math.floor(o.openTime / 5) % 10 === 0);
    ok(noEarlyA, 'AUCUN ordre pendant la bougie CISD seule — l’ordre ne vient QUE du combiné');

    // ── [B] Ninja ProTrader : même séquence, ordre AVANT la clôture ──
    console.log('[5] Phase B — Ninja ProTrader : détection du combiné AVANT la clôture…');
    phase = 'B';
    // Le changement de stratégie réinitialise les gardes (séquence vierge).
    socket.emit('set-auto-strategy', { strategyId: 'ninja_protrader' });
    await sleep(200);
    const bOrderIdx = orders.length;
    const phaseBDeadline = Date.now() + 115_000;
    while (orders.length <= bOrderIdx && Date.now() < phaseBDeadline) await sleep(1000);
    const b = orders[bOrderIdx];
    ok(!!b, 'ordre Ninja placé sur le signal COMBINÉ');
    if (b) {
      ok(b.source === 'ninja_protrader' && b.action === 'call', 'ordre B = CALL (Ninja)');
      ok(b.label.includes('Ninja ProTrader'), 'libellé B : stratégie Ninja ProTrader');
      ok(b.label.includes('call-1 [CISD Up]'), 'libellé B : combinaison call-1 [CISD Up]');
      ok(b.label.includes('CISD Up confirmé (armé bougie'), 'libellé B : confirmation CISD documentée', b.label);
      ok(b.expirationSeconds === RULE_EXPIRY, `expiration B = ${RULE_EXPIRY}s (règle)`);
      // PREUVE AVANT-CLÔTURE : l'ordre part PENDANT la bougie de
      // confirmation (%10==9), en pleine bougie (ofs ≥ 2).
      ok(Math.floor(b.openTime / 5) % 10 === 9, `ordre B placé PENDANT la bougie de confirmation (bucket %10=${Math.floor(b.openTime / 5) % 10})`);
      ok(b.openTime % 5 >= 2, `ordre B AVANT la clôture (ofs=${b.openTime % 5} dans le bucket de 5 s)`);
    }
    const armeeB = strategyStates.filter(s => s.phase === 'B' && s.reason.includes('ARMÉE'));
    ok(armeeB.length > 0, `Phase B : armement CISD observé avant l’ordre (${armeeB.length} états)`);

    // ── [C] Protection du solde : combiné SANS CISD vérifié → refus ──
    console.log('[6] Phase C — flux RGG (BOS Up + CISD Up d’emblée, jamais de CISD seul) → AUCUN ordre…');
    phase = 'C';
    // Flux RGG : ut toujours vrai → jamais de CISD seul → jamais d'armement.
    const def = broker.assetDefs.get('EURUSD_otc');
    def.pathScript = null;
    def.script = 'RGG';
    // Ré-émettre la stratégie réinitialise les gardes (séquence vierge).
    socket.emit('set-auto-strategy', { strategyId: 'ninja_protrader' });
    await sleep(300);
    const cOrderIdx = orders.length;
    const phaseCDeadline = Date.now() + 34_000; // ~6 bougies S5
    while (Date.now() < phaseCDeadline) await sleep(1000);
    ok(orders.length === cOrderIdx, `AUCUN nouvel ordre en flux combiné-seul (${orders.length - cOrderIdx} en ${34}s)`);
    const refusedC = strategyStates.filter(s => s.phase === 'C' && s.reason.includes('SANS CISD Up vérifié préalable'));
    ok(refusedC.length > 0, `strategy-state « SANS CISD Up vérifié préalable » observé (${refusedC.length} états) — la faiblesse des CISD est neutralisée`);
    ok(refusedC.every(s => s.action === 'hold'), 'les signaux combinés non confirmés restent HOLD (aucun ordre)');

    cleanupAll(failures > 0 ? 1 : 0);
  })().catch(e => { console.error('ERREUR E2E:', e); cleanupAll(1); });
}

main();
