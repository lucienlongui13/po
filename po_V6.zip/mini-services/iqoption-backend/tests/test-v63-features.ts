/**
 * test-v63-features.ts — TESTS v6.3 (4 demandes utilisateur).
 * =================================================================
 *
 *   1. EXPIRATION RÉELLE : le champ Auto Trade est respecté à la seconde
 *      près (bug « je mets 6 s → tous les écrans affichent exp 5s »).
 *   2. AUTO SWITCH ASSETS (v20) : dès que le payout de l'asset en cours
 *      baisse < 92 % ET que le dernier ordre est un GAIN → switch vers un
 *      asset payout == 92 % (remplace l'ancien Payout Guard 80-92 %).
 *   3. LIMITE MULTI-ASSETS : 10 → 24 assets simultanés (10 + 14).
 *   4. CONTINUITÉ BACKEND : la session survit à la fermeture du frontend
 *      (login idempotent) ET aux redémarrages du backend (persistance
 *      disque de la sélection + config auto-trade).
 *
 * Modules PURS testés : expiry.ts, payout-guard.ts, session-persistence.ts,
 * asset-contexts.ts (validation de sélection).
 *
 * Exécution : node --import tsx tests/test-v63-features.ts
 */

import {
  snapExpiry,
  resolveAutoTradeExpiry,
  AUTO_TRADE_MIN_EXPIRY,
} from '../expiry.js';
import {
  AUTO_SWITCH_TRIGGER_PCT,
  AUTO_SWITCH_TARGET_PCT,
  isPayoutTarget,
  DEFAULT_PAYOUT_GUARD_CONFIG,
  createPayoutGuardState,
  evaluatePayoutGuard,
  commitPayoutSwap,
  prunePayoutGuardState,
  payoutGuardSummary,
  pickReplacementCandidate,
  type PayoutSnapshot,
} from '../payout-guard.js';
import {
  defaultSessionSnapshotPath,
  savePersistedSession,
  loadPersistedSession,
  clearPersistedSession,
  sanitizePersistedSession,
  PERSISTED_SESSION_VERSION,
  type PersistedSession,
} from '../session-persistence.js';
import { validateAssetSelection, MAX_SELECTED_ASSETS } from '../asset-contexts.js';
import { promises as fs } from 'node:fs';
import path from 'node:path';
import os from 'node:os';

// ─────────────────────────────────────────────────────────────────────────────
//  Runner
// ─────────────────────────────────────────────────────────────────────────────
let passed = 0;
let failed = 0;
const failures: string[] = [];
function section(title: string): void {
  console.log(`\n${'─'.repeat(72)}\n  ${title}\n${'─'.repeat(72)}`);
}
function check(label: string, cond: boolean): void {
  if (cond) {
    passed++;
    console.log(`  ✓ ${label}`);
  } else {
    failed++;
    failures.push(label);
    console.log(`  ✗ ${label}`);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION A — EXPIRATION : le champ Auto Trade est la source de vérité (bug v6.3)
// ─────────────────────────────────────────────────────────────────────────────
section('SECTION A — BUG « exp 5s » : 6 s reste 6 s (champ respecté à la seconde près)');

{
  check('A1. LE BUG UTILISATEUR : champ=6 s → 6 s (avant : écrasé en 5 s)', snapExpiry(6) === 6);
  check('A2. pipeline complet : resolve(6, fallback TF 5 s) === 6 s', resolveAutoTradeExpiry(6, 5) === 6);
  check('A3. resolve(6, fallback M1 60 s) === 6 s (le champ PRIME)', resolveAutoTradeExpiry(6, 60) === 6);
  check('A4. affichage carte : 6 s → badge « exp 6s » (plus de snap)', resolveAutoTradeExpiry(6, 5) === 6);
  check('A5. chaque seconde est valide : 3..20 passent tels quels',
    Array.from({ length: 18 }, (_, i) => i + 3).every((v) => snapExpiry(v) === v));
  check('A6. 45 s reste 45 s (avant : snappé à 30 s)', snapExpiry(45) === 45);
  check('A7. 61 s reste 61 s (avant : snappé à 60 s)', snapExpiry(61) === 61);
  check('A8. 1000 s reste 1000 s (avant : snappé à 900 s)', snapExpiry(1000) === 1000);
  check('A9. clamp bas : 1 s → 3 s (minimum broker)', snapExpiry(1) === AUTO_TRADE_MIN_EXPIRY && AUTO_TRADE_MIN_EXPIRY === 3);
  check('A10. clamp haut : 90000 s → 86400 s', snapExpiry(90000) === 86400);
  check('A11. arrondi : 45.6 → 46, 45.4 → 45', snapExpiry(45.6) === 46 && snapExpiry(45.4) === 45);
  check('A12. NaN/infini → 3 s (défensif)', snapExpiry(NaN) === 3 && snapExpiry(Infinity) === 86400);
  check('A13. champ invalide → fallback TF (durée de bougie)', resolveAutoTradeExpiry(null, 5) === 5 && resolveAutoTradeExpiry(0, 5) === 5);
  check('A14. identique sur 24 assets (config globale, isolement = mises/stats)',
    Array.from({ length: 24 }, () => resolveAutoTradeExpiry(6, 5)).every((v) => v === 6));
}

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION B — AUTO SWITCH ASSETS v20 : payout < 92 % + dernier ordre GAIN
//              → switch vers un asset payout == 92 % (module pur)
// ─────────────────────────────────────────────────────────────────────────────
section('SECTION B — AUTO SWITCH v20 : détection < 92 %, cible == 92 %, verrou gain');

/** Payouts factices d'un broker : actifs + candidats. */
function makePayouts(): Record<string, PayoutSnapshot> {
  return {
    // Assets actifs
    EURUSD_otc: { payout: 92, isOpen: true },
    GBPUSD_otc: { payout: 76, isOpen: true },   // < 92 → éligible au switch
    XAUUSD_otc: { payout: 92, isOpen: true },   // == 92 → PAS sous le seuil
    // Candidats
    USDJPY_otc: { payout: 85, isOpen: true },   // ≠ 92 → EXCLU
    AUDCAD_otc: { payout: 81, isOpen: true },    // ≠ 92 → EXCLU
    NZDUSD_otc: { payout: 92, isOpen: true },    // == 92 → CIBLE
    EURGBP_otc: { payout: 92, isOpen: true },    // == 92 → CIBLE
    EURJPY_otc: { payout: 95, isOpen: true },    // > 92 → EXCLU
    GBPJPY_otc: { payout: 79, isOpen: true },    // < 92 → EXCLU
    USDCAD_otc: { payout: 92, isOpen: false },   // marché FERMÉ → exclu
    USDCHF_otc: { payout: 87, isOpen: true },    // ≠ 92 → EXCLU
    // Payout inconnu
    MYSTERY_otc: { isOpen: true },
  };
}

const T0 = 1_700_000_000_000; // horloge factice déterministe

// B1 — Déclencheur « dès que » : payout < 92 % → décision IMMÉDIATE, cible == 92 %
{
  const state = createPayoutGuardState();
  const payouts = makePayouts();
  const active = ['EURUSD_otc', 'GBPUSD_otc', 'XAUUSD_otc'];
  const base = {
    mode: 'multi' as const,
    activeAssets: active,
    focus: 'EURUSD_otc',
    payouts,
    openPositionsByAsset: {},
    lastOrderWinByAsset: {},
    now: T0,
  };

  const decisions = evaluatePayoutGuard(state, base);
  check('B1.1 GBPUSD 76 % (< 92 %) → REMPLACEMENT décidé immédiatement (« dès que »)',
    decisions.length === 1 && decisions[0].from === 'GBPUSD_otc');
  check('B1.2 le candidat est EXACTEMENT == 92 % (exigence utilisateur)',
    decisions.length === 1 && decisions[0].toPayout === 92);
  check('B1.3 tie-break alphabétique entre les deux == 92 (EURGBP avant NZDUSD)',
    decisions.length === 1 && decisions[0].to === 'EURGBP_otc');
  check('B1.4 les candidats ≠ 92 (85/81/95/79/87) sont EXCLUS',
    decisions.length === 1 &&
    !['USDJPY_otc', 'AUDCAD_otc', 'EURJPY_otc', 'GBPJPY_otc', 'USDCHF_otc'].includes(decisions[0].to));
  check('B1.5 le marché FERMÉ (USDCAD 92 %, isOpen=false) est EXCLU',
    decisions.length === 1 && decisions[0].to !== 'USDCAD_otc');
  check('B1.6 XAUUSD 88 % (< 92 %) est AUSSI éligible — mais un seul ordre reste ≥ 92',
    evaluatePayoutGuard(
      createPayoutGuardState(),
      { ...base, activeAssets: ['XAUUSD_otc'], payouts: { ...payouts, XAUUSD_otc: { payout: 88, isOpen: true } } },
    ).length === 1);
  check('B1.7 le payout EXACTEMENT 92 % n\'est PAS « sous le seuil » (92 = OK, pas de switch)',
    evaluatePayoutGuard(
      createPayoutGuardState(),
      { ...base, activeAssets: ['EURUSD_otc'], payouts: { ...payouts, EURUSD_otc: { payout: 92, isOpen: true } } },
    ).length === 0);
  check('B1.8 payout 91.9 % → switch (seuil STRICT < 92)',
    evaluatePayoutGuard(
      createPayoutGuardState(),
      { ...base, activeAssets: ['EURUSD_otc'], payouts: { ...payouts, EURUSD_otc: { payout: 91.9, isOpen: true } } },
    ).length === 1);
  check('B1.9 payout inconnu (null) → PAS de switch',
    evaluatePayoutGuard(
      createPayoutGuardState(),
      { ...base, activeAssets: ['MYSTERY_otc'] },
    ).length === 0);
  check('B1.10 isPayoutTarget : 92 → vrai · 91.9/92.4 → faux (arrondi demi-entier)',
    isPayoutTarget(92) === true && isPayoutTarget(91.9) === false && isPayoutTarget(92.4) === false && isPayoutTarget(NaN) === false);
}

// B2 — VERROU « DERNIER ORDRE = GAIN » (cœur de la demande v20)
{
  const state = createPayoutGuardState();
  const payouts = makePayouts();
  const active = ['EURUSD_otc', 'GBPUSD_otc'];
  const base = {
    mode: 'multi' as const,
    activeAssets: active,
    focus: 'EURUSD_otc',
    payouts,
    openPositionsByAsset: {},
    lastOrderWinByAsset: {},
    now: T0,
  };

  check('B2.1 dernier ordre de l\'asset = PERTE → AUCUN switch (Martingale en récupération)',
    evaluatePayoutGuard(state, { ...base, lastOrderWinByAsset: { GBPUSD_otc: false } }).length === 0);
  check('B2.2 dernier ordre = GAIN → switch décidé',
    evaluatePayoutGuard(createPayoutGuardState(), { ...base, lastOrderWinByAsset: { GBPUSD_otc: true } }).length === 1);
  check('B2.3 AUCUN ordre réglé sur l\'asset (absent) → switch autorisé (asset neuf)',
    evaluatePayoutGuard(createPayoutGuardState(), { ...base, lastOrderWinByAsset: {} }).length === 1);
  check('B2.4 AUCUN ordre réglé sur l\'asset (null explicite) → switch autorisé',
    evaluatePayoutGuard(createPayoutGuardState(), { ...base, lastOrderWinByAsset: { GBPUSD_otc: null } }).length === 1);
  check('B2.5 une PERTE sur un AUTRE asset ne bloque PAS le switch de GBPUSD',
    evaluatePayoutGuard(createPayoutGuardState(), { ...base, lastOrderWinByAsset: { EURUSD_otc: false } }).length === 1);
}

// B3 — Positions ouvertes → switch différé
{
  const state = createPayoutGuardState();
  const payouts = makePayouts();
  const base = {
    mode: 'multi' as const,
    activeAssets: ['EURUSD_otc', 'GBPUSD_otc'],
    focus: 'EURUSD_otc',
    payouts,
    openPositionsByAsset: { GBPUSD_otc: 1 }, // 1 position ouverte sur l'asset qui chute
    lastOrderWinByAsset: {},
    now: T0,
  };
  check('B3.1 position OUVERTE → PAS de switch',
    evaluatePayoutGuard(state, base).length === 0);
  const afterClose = evaluatePayoutGuard(state, { ...base, openPositionsByAsset: { GBPUSD_otc: 0 } });
  check('B3.2 position clôturée → switch décidé à la passe suivante',
    afterClose.length === 1 && afterClose[0].from === 'GBPUSD_otc');
}

// B4 — Anti flip-flop : un asset récemment écarté ne revient pas
{
  const state = createPayoutGuardState();
  state.lastSwapTs['EURGBP_otc'] = T0; // EURGBP vient d'être écarté
  const candidate = pickReplacementCandidate(
    ['EURUSD_otc'],
    makePayouts(),
    state.lastSwapTs,
    T0 + 10_000,            // 10 s après son éviction (< cooldown 2 min)
    DEFAULT_PAYOUT_GUARD_CONFIG.swapCooldownMs,
  );
  check('B4.1 EURGBP écarté depuis 10 s → EXCLU du choix (anti flip-flop)',
    candidate !== null && candidate.asset !== 'EURGBP_otc');
  const later = pickReplacementCandidate(
    ['EURUSD_otc'],
    makePayouts(),
    state.lastSwapTs,
    T0 + 3 * 60_000,        // 3 min après (> cooldown)
    DEFAULT_PAYOUT_GUARD_CONFIG.swapCooldownMs,
  );
  check('B4.2 après le cooldown (3 min) → à nouveau éligible',
    later !== null && (later.asset === 'NZDUSD_otc' || later.asset === 'EURGBP_otc'));
}

// B5 — Deux assets qui chutent en même temps → deux candidats DIFFÉRENTS
{
  const state = createPayoutGuardState();
  const payouts = makePayouts();
  // GBPUSD (76) et XAUUSD (70) chutent tous deux
  payouts['GBPUSD_otc'] = { payout: 76, isOpen: true };
  payouts['XAUUSD_otc'] = { payout: 70, isOpen: true };
  const active = ['EURUSD_otc', 'GBPUSD_otc', 'XAUUSD_otc'];
  const decisions = evaluatePayoutGuard(state, {
    mode: 'multi', activeAssets: active, focus: 'EURUSD_otc', payouts,
    openPositionsByAsset: {}, lastOrderWinByAsset: {}, now: T0,
  });
  check('B5.1 deux assets confirmés < 92 % → deux décisions', decisions.length === 2);
  check('B5.2 candidats DISTINCTS (pas deux fois le même)',
    decisions.length === 2 && decisions[0].to !== decisions[1].to);
  check('B5.3 les deux candidats sont == 92 %',
    decisions.every((d) => d.toPayout === 92));
}

// B6 — Quota horaire + mode single (FOCUS seul) + désactivation
{
  const state = createPayoutGuardState();
  const payouts = makePayouts();
  // Simule maxSwapsPerHour remplaces déjà effectués.
  for (let i = 0; i < DEFAULT_PAYOUT_GUARD_CONFIG.maxSwapsPerHour; i++) {
    state.swaps.push({ ts: T0 - i * 60_000, from: `A${i}_otc`, to: `B${i}_otc`, fromPayout: 70, toPayout: 92 });
  }
  const base = { mode: 'multi' as const, activeAssets: ['EURUSD_otc', 'GBPUSD_otc'], focus: 'EURUSD_otc', payouts, openPositionsByAsset: {} as Record<string, number>, lastOrderWinByAsset: {} as Record<string, boolean | null>, now: T0 };
  check('B6.1 quota horaire atteint (12/12) → PLUS AUCUN switch',
    evaluatePayoutGuard(state, base).length === 0);

  check('B6.2 mode SINGLE : SEUL l\'asset FOCUS est gardé (« l\'asset en cours »)',
    evaluatePayoutGuard(
      createPayoutGuardState(),
      { ...base, mode: 'single', focus: 'GBPUSD_otc' },
    ).length === 1);
  check('B6.3 mode SINGLE : un asset NON focus n\'est PAS remplacé',
    evaluatePayoutGuard(
      createPayoutGuardState(),
      { ...base, mode: 'single', focus: 'EURUSD_otc' },
    ).length === 0);
  check('B6.4 guard DÉSACTIVÉ → aucun switch',
    evaluatePayoutGuard(
      createPayoutGuardState(),
      { ...base, config: { enabled: false } },
    ).length === 0);
}

// B7 — Aucun candidat == 92 % disponible → pas de switch (on garde l'asset)
{
  const state = createPayoutGuardState();
  const payouts: Record<string, PayoutSnapshot> = {
    EURUSD_otc: { payout: 90, isOpen: true },
    GBPUSD_otc: { payout: 60, isOpen: true }, // actif, très bas
    // AUCUN autre actif à 92 % (aucun candidat)
  };
  const base = { mode: 'multi' as const, activeAssets: ['EURUSD_otc', 'GBPUSD_otc'], focus: 'EURUSD_otc', payouts, openPositionsByAsset: {}, lastOrderWinByAsset: {}, now: T0 };
  check('B7.1 aucun candidat == 92 % disponible → PAS de switch',
    evaluatePayoutGuard(state, base).length === 0);
}

// B8 — commit + résumé + prune
{
  const state = createPayoutGuardState();
  const payouts = makePayouts();
  const active = ['EURUSD_otc', 'GBPUSD_otc', 'XAUUSD_otc'];
  const decisions = evaluatePayoutGuard(state, {
    mode: 'multi', activeAssets: active, focus: 'EURUSD_otc', payouts,
    openPositionsByAsset: {}, lastOrderWinByAsset: {}, now: T0,
  });
  check('B8.1 décision prête (GBPUSD → candidat == 92)', decisions.length === 1);
  if (decisions.length === 1) {
    const d = decisions[0];
    const before = state.swaps.length;
    commitPayoutSwap(state, d, T0);
    check('B8.2 commit : journal +1, cooldown enregistré',
      state.swaps.length === before + 1 && state.lastSwapTs['GBPUSD_otc'] === T0);
    const summary = payoutGuardSummary(state, {}, T0 + 1_000);
    check('B8.3 résumé : seuils v20 exposés (trigger 92, cible 92)',
      summary.swapsLastHour === 1 && summary.triggerPct === AUTO_SWITCH_TRIGGER_PCT && summary.targetPct === AUTO_SWITCH_TARGET_PCT);
    check('B8.4 résumé : dernier switch lisible (from/to/payouts)',
      summary.lastSwaps.length === 1 && summary.lastSwaps[0].from === 'GBPUSD_otc' && summary.lastSwaps[0].to === d.to);
  } else {
    check('B8.2 décision indisponible (échec en cascade)', false);
    check('B8.3 résumé indisponible (échec en cascade)', false);
    check('B8.4 dernier switch indisponible (échec en cascade)', false);
  }
  // Prune : l'asset retiré de la sélection n'est plus refroidi.
  state.lastSwapTs['REMOVED_otc'] = T0;
  prunePayoutGuardState(state, ['EURUSD_otc']);
  check('B8.5 prune : les cooldowns des assets retirés sont libérés', !state.lastSwapTs['REMOVED_otc']);
}

// B9 — Le remplacement conserve la POSITION dans la liste (comme switch-asset)
{
  const assets = ['EURUSD_otc', 'GBPUSD_otc', 'XAUUSD_otc'];
  const decision = { from: 'GBPUSD_otc', to: 'NZDUSD_otc' };
  const next = assets.map((a) => (a === decision.from ? decision.to : a));
  check('B9.1 le remplaçant prend la position (index 1) de l\'asset écarté',
    next[1] === 'NZDUSD_otc' && next.length === 3 && next[0] === 'EURUSD_otc' && next[2] === 'XAUUSD_otc');
  check('B9.2 le remplaçant passe la validation backend (multi, 3 assets)',
    validateAssetSelection({ mode: 'multi', assets: next }).ok);
}

// ─────────────────────────────────────────────────────────────────────────────
//  SECTION C — CONTINUITÉ : la session survit aux redémarrages du backend
// ─────────────────────────────────────────────────────────────────────────────
section('SECTION C — PERSISTANCE DE SESSION (fermeture frontend + restart backend)');

async function mainAsync(): Promise<void> {
  const tmpDir = await fs.mkdtemp(path.join(os.tmpdir(), 'po-session-test-'));
  const filePath = path.join(tmpDir, 'backend-session.json');

  // C1 — Round-trip complet : sauvegarde → (redémarrage) → chargement.
  const snapshot: PersistedSession = {
    version: PERSISTED_SESSION_VERSION,
    savedAt: Date.now(),
    mode: 'multi',
    assets: ['EURUSD_otc', 'GBPUSD_otc', 'XAUUSD_otc', 'BTCUSD_otc', 'AUDCAD_otc'],
    focus: 'XAUUSD_otc',
    config: {
      strategyId: 'l_lucien_protrader',
      bettingStrategy: 'martingale',
      baseAmount: 2,
      expirySeconds: 6,           // ← le champ de l'utilisateur (v6.3)
      candleSize: 5,
      autoTradeEnabled: true,
    },
    payoutGuardEnabled: true,
  };
  check('C1.1 sauvegarde atomique OK', await savePersistedSession(filePath, snapshot));
  const loaded = await loadPersistedSession(filePath);
  check('C1.2 rechargement : mode multi + 5 assets', !!loaded && loaded.mode === 'multi' && loaded.assets.length === 5);
  check('C1.3 expiration 6 s INTACTE après restart (bug v6.3 exorcisé)',
    loaded?.config.expirySeconds === 6);
  check('C1.4 stratégie/mise/auto-trade restaurés',
    loaded?.config.strategyId === 'l_lucien_protrader' && loaded?.config.bettingStrategy === 'martingale' &&
    loaded?.config.baseAmount === 2 && loaded?.config.autoTradeEnabled === true);
  check('C1.5 focus restauré', loaded?.focus === 'XAUUSD_otc');
  check('C1.6 Payout Guard restauré ON', loaded?.payoutGuardEnabled === true);

  // C2 — La session restaurée est IMMÉDIATEMENT tradable (validation backend).
  if (loaded) {
    const validation = validateAssetSelection({ mode: loaded.mode, assets: loaded.assets });
    check('C2.1 restart → login → sélection réappliquée SANS écran de sélection',
      validation.ok && validation.assets.length === 5);
    check('C2.2 l\'expiration restaurée reste 6 s après snapExpiry (clamp seul)',
      snapExpiry(loaded.config.expirySeconds ?? 0) === 6);
  }

  // C3 — Sanitization défensive (fichier corrompu/périmé).
  check('C3.1 JSON invalide → null (pas de crash)', sanitizePersistedSession('nonsense') === null);
  check('C3.2 mode invalide → null', sanitizePersistedSession({ mode: 'grid', assets: ['A'] }) === null);
  check('C3.3 zéro asset → null', sanitizePersistedSession({ mode: 'multi', assets: [] }) === null);
  check('C3.4 doublons → dédupliqués', sanitizePersistedSession({ mode: 'multi', assets: ['A_otc', 'A_otc', 'B_otc'] })?.assets.length === 2);
  check('C3.5 focus absent → premier asset', sanitizePersistedSession({ mode: 'multi', assets: ['A_otc', 'B_otc'], focus: null })?.focus === 'A_otc');
  check('C3.6 focus hors liste → premier asset', sanitizePersistedSession({ mode: 'multi', assets: ['A_otc', 'B_otc'], focus: 'ZZZ_otc' })?.focus === 'A_otc');
  check('C3.7 config invalide ignorée, sélection conservée',
    sanitizePersistedSession({ mode: 'multi', assets: ['A_otc'], config: { baseAmount: -5, expirySeconds: 'abc' } })?.assets.length === 1);
  check('C3.8 fichier absent → null', (await loadPersistedSession(path.join(tmpDir, 'inexistant.json'))) === null);

  // C4 — Désactivation via env (SESSION_SNAPSHOT_DIR=0).
  const prevEnv = process.env.SESSION_SNAPSHOT_DIR;
  process.env.SESSION_SNAPSHOT_DIR = '0';
  check('C4.1 SESSION_SNAPSHOT_DIR=0 → persistance désactivée', defaultSessionSnapshotPath(tmpDir) === null);
  if (prevEnv === undefined) delete process.env.SESSION_SNAPSHOT_DIR;
  else process.env.SESSION_SNAPSHOT_DIR = prevEnv;
  check('C4.2 chemin par défaut → <backend>/data/backend-session.json',
    defaultSessionSnapshotPath('/x/backend') === path.join('/x/backend', 'data', 'backend-session.json'));
  check('C4.3 savePersistedSession(null) → false (no-op silencieux)', (await savePersistedSession(null, snapshot)) === false);

  // C5 — Effacement (réinitialisation volontaire).
  await clearPersistedSession(filePath);
  check('C5.1 clear → fichier supprimé', (await loadPersistedSession(filePath)) === null);
  await clearPersistedSession(null);
  check('C5.2 clear(null) → no-op sans crash', true);

  await fs.rm(tmpDir, { recursive: true, force: true });

  // ─────────────────────────────────────────────────────────────────────────
  //  SECTION D — LIMITE MULTI-ASSETS : 24 (10 + 14 demandés)
  // ─────────────────────────────────────────────────────────────────────────
  section('SECTION D — LIMITE 24 ASSETS (10 + 14 supplémentaires)');

  check('D1. backend : MAX_SELECTED_ASSETS === 24', MAX_SELECTED_ASSETS === 24);
  const fs2 = await import('node:fs');
  // Résolution défensive (ESM/CJS selon tsx) : tests/ → iqoption-backend →
  // mini-services → racine du projet).
  const backendDir = typeof __dirname !== 'undefined'
    ? __dirname
    : path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Z]:)/, '$1'));
  const frontendCatalogPath = path.resolve(backendDir, '..', '..', '..', 'src', 'lib', 'markets-catalog.ts');
  const frontendCatalog = fs2.readFileSync(frontendCatalogPath, 'utf-8');
  check('D2. frontend : miroir MAX_SELECTED_ASSETS = 24',
    /MAX_SELECTED_ASSETS\s*=\s*24/.test(frontendCatalog));

  const twentyFour = Array.from({ length: 24 }, (_, i) => `ASSET${i}_otc`);
  check('D3. 24 assets VALIDÉS par le backend (limite inclusive)',
    validateAssetSelection({ mode: 'multi', assets: twentyFour }).ok);
  check('D4. 25 assets REJETÉS',
    !validateAssetSelection({ mode: 'multi', assets: [...twentyFour, 'EXTRA_otc'] }).ok);
  check('D5. l\'erreur mentionne 24',
    (validateAssetSelection({ mode: 'multi', assets: [...twentyFour, 'EXTRA_otc'] }).error ?? '').includes('24'));

  // ─────────────────────────────────────────────────────────────────────────
  //  Résultat
  // ─────────────────────────────────────────────────────────────────────────
  console.log('\n' + '='.repeat(72));
  console.log(`RÉSULTAT : ${passed} test(s) OK, ${failed} échec(s)`);
  if (failed > 0) {
    console.log('\nÉchecs :');
    for (const f of failures) console.log(`  ✗ ${f}`);
    process.exit(1);
  } else {
    console.log('\n✔ v20 VALIDÉE : expiration respectée à la seconde, Auto Switch (payout < 92% + gain → == 92%),');
    console.log('  24 assets, session persistante + login idempotent.');
    process.exit(0);
  }
}

void mainAsync();
