/**
 * test-martingale-tie-refund-e2e.mjs — E2E « état neutre Tie/Refund » (v17)
 * sur le VRAI backend + faux broker Pocket Option.
 * ============================================================================
 *
 * SPÉCIFICATION UTILISATEUR (P&L = 0 $ = Tie ou Refund) :
 *   1. Gain (Win)          → Réinitialiser la mise au montant initial ;
 *   2. Perte (Loss)        → Incrémenter la mise selon le multiplicateur ;
 *   3. Remboursement/Égalité → Conserver le niveau de mise courant pour
 *      l'ordre suivant (l'index de la suite de mises ne bouge PAS).
 *
 * CAS DE VALIDATION (base 1$, martingale ×2, S5, règle BOS 3 s — config
 * production utilisateur) :
 *   CAS 1 : Ordre 1 (1$) → Remboursé (0$) → Ordre 2 = 1$ (AU LIEU de 2$).
 *   CAS 2 : Ordre 1 (1$) → Perdu ; Ordre 2 (2$) → Perdu ; Ordre 3 (4$) →
 *           Remboursé (0$) → Ordre 4 = 4$ (MAINTENUE) ; Ordre 5 (perdu) = 8$.
 *
 * Scénario fusionné (5 ordres, résultats imposés via outcomeScript) :
 *   O1 (1$) TIE → O2 (1$) LOSS → O3 (2$) LOSS → O4 (4$) TIE → O5 (4$) LOSS
 *   mises placées  : 1, 1, 2, 4, 4
 *   prochaine mise : 1, 2, 4, 4, 8
 *   streak après règlement : 0, 1, 2, 2, 3
 *
 * Chemin RÉEL reproduit (capture 2026-09-17) : chaque règlement arrive en
 * temps réel par successcloseOrder { profit: <retour total = mise sur un
 * Tie>, deals: [deal natif UUID/profit NET = 0] } — le SDK lit deals[0],
 * le backend classe profit NET = 0 en 'push' et la Martingale conserve le
 * niveau courant.
 *
 * Vérifie AUSSI :
 *   - les règlements Tie portent P&L = 0 et outcome 'push' (event trade-closed) ;
 *   - stats.pushes = 2, ni wins ni losses pour les Ties ;
 *   - l'expiration de chaque ordre = 3 s (règle BOS) ;
 *   - le log backend affiche bien les TIE (mise conservée).
 *
 * Exécution : node tests/test-martingale-tie-refund-e2e.mjs
 */
import { spawn } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { io } from 'socket.io-client';
import { MockPoBroker } from './mock-po-broker.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BACKEND_DIR = path.resolve(__dirname, '..');
const BACKEND_PORT = 3030; // socket.io backend (codé en dur dans index.ts)

const BASE = 1;
const RULE_EXPIRY = 3;    // expiration de la RÈGLE BOS (config utilisateur)
const OUTCOMES = ['tie', 'loss', 'loss', 'tie', 'loss'];
// CAS 1 : O1 TIE → O2 = 1$ (pas 2$). CAS 2 : O3 4$ TIE → O4 = 4$ maintenu.
const EXPECTED_STAKES = [1, 1, 2, 4, 4];
const EXPECTED_NEXT = [1, 2, 4, 4, 8];
const EXPECTED_STREAK = [0, 1, 2, 2, 3];

let failures = 0, checks = 0;
function ok(cond, label) {
  checks++;
  if (cond) console.log(`  ✓ ${label}`);
  else { failures++; console.error(`  ✗ ${label}`); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

function main() {
  console.log('\n=== E2E Tie/Refund (v17) — backend réel + faux broker (S5, règle 3 s, TIE = P&L 0, mise conservée) ===\n');

  const broker = new MockPoBroker({
    httpPort: 4530,             // ports dédiés — aucun conflit avec un
    wsPort: 4531,               // quelconque autre process/.session
    candleSec: 5,
    settleDelayMs: 2500,
    historyBuckets: 300,
    script: 'RGG',                    // BOS Up + CISD Up toutes les 3 bougies
    outcomeScript: OUTCOMES,          // résultats imposés dans l'ordre
    wickSize: 0.00010,                // mèches réalistes → croisements STRICTS des swings
    // CAPTURE RÉELLE 2026-09-17 : le broker pousse chaque règlement en temps
    // réel via successcloseOrder { profit: <retour total>, deals: [deal natif] }.
    // Sur un TIE : retour total = mise (remboursée), profit NET du deal = 0.
    realtimeClosePush: true,
  });
  let backend = null;
  let socket = null;

  const cleanupAll = (code) => {
    try {
      if (backend && backend.exitCode === null) {
        try { process.kill(-backend.pid, 'SIGKILL'); }
        catch { try { backend.kill('SIGKILL'); } catch { /* ignore */ } }
      }
    } catch { /* ignore */ }
    try { broker.stop(); } catch { /* ignore */ }
    try { if (socket) socket.close(); } catch { /* ignore */ }
    if (code != null) {
      console.log(`\n=== RÉSULTAT E2E : ${checks - failures}/${checks} vérifications OK ===`);
      process.exit(failures > 0 ? 1 : code);
    }
  };
  process.on('SIGINT', () => cleanupAll(130));
  process.on('uncaughtException', e => { console.error('UNCAUGHT:', e); cleanupAll(1); });

  (async () => {
    // ── 1. Faux broker (règlements temps réel successcloseOrder) ──
    const ports = await broker.start();
    console.log(`[1] faux broker PO démarré (http :${ports.httpPort}, ws :${ports.wsPort})`);

    // ── 2. VRAI backend, redirigé vers le faux broker ──
    console.log('[2] démarrage du VRAI backend (tsx index.ts)…');
    const backendLog = fs.openSync(path.join(BACKEND_DIR, 'e2e-tie-refund.log'), 'w');
    backend = spawn('npx', ['tsx', 'index.ts'], {
      cwd: BACKEND_DIR,
      env: {
        ...process.env,
        PO_API_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_WEB_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_DEMO_WS_URL: `ws://127.0.0.1:${ports.wsPort}`,
        SESSION_SNAPSHOT_DIR: '0',
        PO_STARTUP_RANDOM_ASSET: '0',  // v21 — pas de sélection aléatoire 92% au démarrage (test contrôlé)
        // pas de restauration de session
        SOCIAL_DEBUG_PORT: '4330',    // évite tout conflit de port local
        NODE_ENV: 'development',
      },
      stdio: ['ignore', backendLog, backendLog],
      detached: true,
    });

    let connected = false;
    for (let i = 0; i < 40 && !connected; i++) {
      await sleep(500);
      socket = io(`http://127.0.0.1:${BACKEND_PORT}`, { transports: ['websocket'], path: '/', reconnection: false, timeout: 3000 });
      connected = await new Promise(r => { socket.once('connect', () => r(true)); socket.once('connect_error', () => r(false)); });
      if (!connected) { try { socket.close(); } catch { /* ignore */ } }
    }
    ok(connected, `backend joignable sur :${BACKEND_PORT} (socket.io connecté)`);
    if (!connected) { cleanupAll(1); return; }

    // ── 3. Séquence identique au frontend ──
    console.log('[3] login démo sur le faux broker…');
    const loginResult = await new Promise(r => {
      socket.once('login-result', r);
      socket.emit('login', { email: 'demo@e2e.test', password: 'demo-pass', mode: 'demo' });
      setTimeout(() => r({ ok: false, error: 'timeout login' }), 30000);
    });
    ok(loginResult?.ok === true, `login démo OK (uid=${loginResult?.user_id ?? '?'})`);
    if (!loginResult?.ok) { console.error('login échoué:', loginResult); cleanupAll(1); return; }

    socket.emit('set-config', { candleSize: 5, cooldownSeconds: 3 });
    await sleep(300);

    const selected = await new Promise(r => {
      socket.once('assets-selected', r);
      socket.emit('select-assets', { mode: 'single', assets: ['EURUSD_otc'] });
      setTimeout(() => r({ ok: false }), 15000);
    });
    ok(selected?.ok === true, 'asset sélectionné : EURUSD_otc (mode single)');

    socket.emit('set-auto-strategy', { strategyId: 'l_lucien_protrader' });
    await sleep(200);

    // Martingale + base 1 (cas de validation utilisateur : 1$ → 2$ → 4$ → 8$).
    socket.emit('set-auto-config', {
      bettingStrategy: 'martingale',
      baseAmount: BASE,
    });
    socket.emit('set-config', { margin: String(BASE), bettingStrategy: 'martingale', cooldownSeconds: 3, expirySeconds: 61 });
    await sleep(300);

    // Règles BOS CALL+PUT avec expiration 3 s (config production utilisateur).
    socket.emit('set-auto-config', {
      bosChochCisdCallRules: [{ id: 'call-bos-up', alerts: ['BOS Up'], expirationSeconds: RULE_EXPIRY }],
      bosChochCisdPutRules: [{ id: 'put-bos-down', alerts: ['BOS Down'], expirationSeconds: RULE_EXPIRY }],
    });
    await sleep(300);

    const autoOn = await new Promise(r => {
      socket.once('auto-trade-status', r);
      socket.emit('set-auto-trade', { enabled: true });
      setTimeout(() => r(null), 10000);
    });
    ok(autoOn && autoOn.enabled !== false, `auto-trade ON (stratégie=${autoOn?.strategyId ?? '?'})`);
    ok(autoOn?.strategyId === 'l_lucien_protrader', `stratégie active = bos_choch_cisd (${autoOn?.strategyId})`);
    ok(autoOn?.bettingStrategy === 'martingale', `mise = martingale (${autoOn?.bettingStrategy})`);

    // ── 4. Collecte des ordres + règlements ──
    // Séquençage STRICT : chaque mise suivante doit être calculée APRÈS la
    // résolution du trade précédent. L'auto-trade est suspendu pendant le vol
    // de chaque deal — le règlement broker (temps réel successcloseOrder,
    // TIE = profit NET 0) est traité par deal_closed PUIS l'auto-trade
    // reprend et la prochaine mise reflète le résultat (TIE = niveau conservé).
    console.log(`[4] trading — ${OUTCOMES.join(', ')} imposés (S5, règle ${RULE_EXPIRY}s, base ${BASE}$, TIE = mise conservée)…`);
    /** Ordres réellement placés : [{ amount, expirationSeconds, action }] */
    const placedOrders = [];
    /** Règlements reçus (event trade-closed) : [{ profit, outcome, isWin }] */
    const closedEvents = [];
    /** Dernier statut auto-trade reçu (focus EURUSD_otc). */
    let lastStatus = null;
    socket.on('auto-trade-status', (s) => { if (s) lastStatus = s; });
    socket.on('trade-closed', (ev) => {
      if (ev?.asset !== 'EURUSD_otc') return;
      closedEvents.push({
        profit: Number(ev?.profit ?? NaN),
        outcome: ev?.outcome ?? null,
        isWin: !!ev?.isWin,
        id: String(ev?.deal?.id ?? ''),
      });
    });
    socket.on('trade-opened', (ev) => {
      if (ev?.source === 'l_lucien_protrader') {
        placedOrders.push({
          id: String(ev.deal?.id ?? ''),
          amount: Number(ev.deal?.amount ?? 0),
          expirationSeconds: Number(ev.expirationSeconds ?? 0),
          action: String(ev.deal?.action ?? '?'),
        });
        console.log(`    [t+${placedOrders.length}] ordre BOS #${placedOrders.length} : ${ev.deal?.action?.toUpperCase()} ${ev.deal?.amount}$ expiration=${ev.expirationSeconds}s (deal ${String(ev.deal?.id).slice(0, 8)}…)`);
        // Suspend l'auto-trade : le deal en vol doit être RÉGLÉ avant le
        // calcul de la prochaine mise.
        socket.emit('set-auto-trade', { enabled: false });
      }
    });

    // Attends chaque ordre + son règlement traité (mise suivante = EXPECTED_NEXT[i]).
    const nextAfterSettlement = [];
    const deadline = Date.now() + 420_000;
    for (let i = 0; i < EXPECTED_STAKES.length; i++) {
      // 4.a — l'ordre i est placé
      while (placedOrders.length <= i) {
        if (Date.now() > deadline) break;
        await sleep(500);
      }
      if (placedOrders.length <= i) break;
      // 4.b — le règlement est poussé en temps réel (TIE : profit NET = 0)
      //       puis traité : la prochaine mise calculée devient EXPECTED_NEXT[i]
      //       et le streak devient EXPECTED_STREAK[i] (TIE → inchangé).
      const target = EXPECTED_NEXT[i];
      const targetStreak = EXPECTED_STREAK[i];
      let settled = false;
      const settleDeadline = Date.now() + 90_000;
      while (Date.now() < settleDeadline) {
        await sleep(1000);
        const nextBet = lastStatus?.nextBetAmount;
        if (typeof nextBet === 'number' && nextBet === target &&
            (lastStatus?.stats?.consecutiveLosses ?? -1) === targetStreak) {
          settled = true;
          break;
        }
      }
      nextAfterSettlement.push(settled ? target : (lastStatus?.nextBetAmount ?? null));
      console.log(`    [t+${i + 1}] règlement ${OUTCOMES[i].toUpperCase()} traité → prochaine mise ${lastStatus?.nextBetAmount}$ (streak ${lastStatus?.stats?.consecutiveLosses}, pushes ${lastStatus?.stats?.pushes ?? '?'})`);
      // 4.c — reprise de l'auto-trade : la prochaine mise part du résultat.
      if (i < EXPECTED_STAKES.length - 1) {
        socket.emit('set-auto-trade', { enabled: true });
      }
    }

    // Drain : plus aucun ordre ne doit partir.
    await sleep(3000);
    socket.emit('set-auto-trade', { enabled: false });

    // ── 5. VÉRIFICATIONS ──
    console.log('\n[5] vérification de la séquence Martingale réelle (Tie/Refund = état neutre)…');
    console.log(`    ordres placés      : ${placedOrders.map(o => o.amount).join(' → ')}`);
    console.log(`    prochaines mises   : ${nextAfterSettlement.join(' → ')}`);
    console.log(`    broker (mock)      : ordres=${broker.stats.orders} réglés=${broker.stats.settled} publiés=${broker.stats.published}`);

    ok(placedOrders.length === EXPECTED_STAKES.length,
      `exactement ${EXPECTED_STAKES.length} ordres BOS placés (${placedOrders.length} observés)`);
    ok(placedOrders.every((o, i) => o.amount === EXPECTED_STAKES[i]),
      `mises placées = 1 → 1 → 2 → 4 → 4 : [${placedOrders.map(o => o.amount).join(', ')}]`);
    ok(nextAfterSettlement.every((v, i) => v === EXPECTED_NEXT[i]),
      `prochaines mises après règlement = 1 → 2 → 4 → 4 → 8 : [${nextAfterSettlement.join(', ')}]`);
    ok(placedOrders.every(o => o.expirationSeconds === RULE_EXPIRY),
      `expiration de CHAQUE ordre = ${RULE_EXPIRY}s (règle) : [${placedOrders.map(o => o.expirationSeconds).join(', ')}]`);

    // CAS 1 (spéc. utilisateur) : Ordre 1 (1$) remboursé → Ordre 2 = 1$.
    ok(OUTCOMES[0] === 'tie' && placedOrders[0]?.amount === 1 && placedOrders[1]?.amount === 1,
      'CAS 1 — Ordre 1 (1$) REMBOURSÉ → Ordre 2 = 1$ (AU LIEU d\'incrémenter à 2$)');

    // CAS 2 (spéc. utilisateur) : progression 1→2→4→TIE→4 maintenu→8.
    ok(OUTCOMES[3] === 'tie' && placedOrders[3]?.amount === 4 && placedOrders[4]?.amount === 4,
      'CAS 2 — Ordre 3 (4$) REMBOURSÉ → Ordre 4 = 4$ (mise MAINTENUE au niveau courant)');
    ok(nextAfterSettlement[4] === 8,
      'CAS 2 — Ordre 4 (4$) perdu → Ordre 5 = 8$ (passage au niveau suivant APRÈS le Tie)');

    // Séquence complète obligatoire : mises placées + prochaine mise finale.
    const fullSeq = [...placedOrders.map(o => o.amount), nextAfterSettlement[nextAfterSettlement.length - 1]];
    ok(fullSeq.join(',') === '1,1,2,4,4,8',
      `SÉQUENCE OBLIGATOIRE 1 → 1 → 2 → 4 → 4 → 8 : ${fullSeq.join(' → ')}`);

    // Le streak n'a JAMAIS été incrémenté par un Tie (0, 1, 2, 2, 3).
    ok(lastStatus?.stats?.consecutiveLosses === 3,
      `streak final = 3 (le Tie n'a JAMAIS incrémenté l'index) — obtenu ${lastStatus?.stats?.consecutiveLosses}`);
    ok(lastStatus?.stats?.pushes === 2,
      `stats.pushes = 2 (les deux Ties comptés comme neutres) — obtenu ${lastStatus?.stats?.pushes}`);
    ok(lastStatus?.stats?.wins === 0 && lastStatus?.stats?.losses === 3,
      `stats finales = 0W/3L/2T (un Tie n'est ni un win ni un loss) — obtenu ${lastStatus?.stats?.wins}W/${lastStatus?.stats?.losses}L`);

    // Les règlements Tie portent P&L = 0 et outcome 'push' (event §21).
    // NB : le faux broker republie AUSSI chaque règlement via son cache lazy
    // (ids numériques ≠ UUID) et injecte des deals fantômes permanents (v19)
    // — la Martingale doit les IGNORER (prouvé par pushes = 2 et la séquence
    // strictement correcte ci-dessus). On vérifie ici UNIQUEMENT les
    // règlements attribués aux ordres réellement placés (UUID d'ouverture,
    // chemin temps réel successcloseOrder → deals[0]).
    const placedIds = new Set(placedOrders.map(o => o.id));
    const ownClosed = closedEvents.filter(e => placedIds.has(e.id));
    const EXPECTED_PROFIT = [0, -1, -2, 0, -4];
    ok(ownClosed.length === EXPECTED_STAKES.length,
      `${EXPECTED_STAKES.length} règlements attribués aux ordres placés via l'UUID d'ouverture (obtenu ${ownClosed.length}, hors republications lazy + fantômes : ${closedEvents.length} events)`);
    ok(ownClosed.map(e => e.outcome).join(',') === 'push,loss,loss,push,loss',
      `règlements dans l'ordre = push, loss, loss, push, loss : [${ownClosed.map(e => e.outcome).join(', ')}]`);
    ok(ownClosed.every((e, i) => Math.abs(e.profit - EXPECTED_PROFIT[i]) < 1e-9 && e.isWin === (e.outcome === 'win')),
      `P&L des règlements = 0, -1, -2, 0, -4 (Tie = 0$) : [${ownClosed.map(e => e.profit).join(', ')}]`);
    ok(ownClosed.filter(e => e.outcome === 'push').every(e => e.profit === 0 && e.isWin === false),
      'chaque règlement Tie porte P&L = 0 et isWin = false (état neutre)');

    // Logs backend : les Ties sont affichés comme neutres (mise conservée).
    const e2eLog = fs.readFileSync(path.join(BACKEND_DIR, 'e2e-tie-refund.log'), 'utf8');
    ok(/TIE/.test(e2eLog),
      'le backend a bien journalisé les règlements TIE (état neutre, mise conservée)');
    ok(/deal #\S+ TIE/.test(e2eLog) || /TIE ⟲/.test(e2eLog) || /TIE \(remboursé\)/.test(e2eLog),
      'le log du deal réglé affiche le résultat TIE (et non LOSS)');
    ok(!/false WIN|ghost settlement/i.test(e2eLog), 'aucun règlement fantôme détecté dans les logs backend');

    socket.close();
    cleanupAll(failures > 0 ? 1 : 0);
  })().catch(e => {
    console.error('E2E FATAL:', e);
    cleanupAll(1);
  });
}

main();
