/**
 * test-v63-integration.ts — TEST D'INTÉGRATION SOCKET (v6.3).
 * =================================================================
 *
 * Démarre le VRAI serveur backend (index.ts) sur le port 3030, y connecte un
 * client socket.io et vérifie les flux v6.3 SANS broker (pas de login) :
 *
 *   I1. À la connexion : 'status' + 'payout-guard-status' reçus.
 *   I2. set-payout-guard {enabled:false} → statut reflecté (toggle + event).
 *   I3. set-auto-config {expirySeconds:6} → auto-trade-status.fixedExpirySeconds === 6
 *       (LE BUG « exp 5s » vérifié de bout en bout sur le VRAI serveur).
 *   I4. La déconnexion du frontend N'arrête PAS le serveur (headless) — le
 *       serveur répond encore après reconnexion d'un second client.
 *   I5. get-payout-guard → statut complet.
 *
 * Exécution : node --import tsx tests/test-v63-integration.ts
 * (le serveur est lancé/surveillé par ce test ; timeout de sûreté 30 s)
 */

import { spawn, type ChildProcess } from 'node:child_process';
import net from 'node:net';
import { io } from 'socket.io-client';

const PORT = 3030;
const URL = `http://127.0.0.1:${PORT}`;

/** Le port est-il occupé ? (série d'une exécution précédente) */
function isPortBusy(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const s = net.connect({ port, host: '127.0.0.1' }, () => { s.end(); resolve(true); });
    s.on('error', () => resolve(false));
    setTimeout(() => { s.destroy(); resolve(false); }, 500);
  });
}

let passed = 0;
let failed = 0;
const failures: string[] = [];
function check(label: string, cond: boolean): void {
  if (cond) { passed++; console.log(`  ✓ ${label}`); }
  else { failed++; failures.push(label); console.log(`  ✗ ${label}`); }
}

function waitFor<T>(socket: any, event: string, predicate: (payload: T) => boolean, timeoutMs = 8000): Promise<T | null> {
  return new Promise((resolve) => {
    const timer = setTimeout(() => { socket.off(event, handler); resolve(null); }, timeoutMs);
    function handler(payload: T) {
      try {
        if (predicate(payload)) {
          clearTimeout(timer);
          socket.off(event, handler);
          resolve(payload);
        }
      } catch { /* ignore */ }
    }
    socket.on(event, handler);
  });
}

async function main(): Promise<void> {
  console.log('─'.repeat(72));
  console.log('  INTÉGRATION v6.3 — serveur réel + client socket.io');
  console.log('─'.repeat(72));

  // 1. Démarre le serveur (processus séparé — comme po.sh).
  //    Attend d'abord que le port soit LIBRE (une exécution précédente du
  //    test peut avoir laissé le temps au OS de relâcher le bind).
  const freeDeadline = Date.now() + 10_000;
  while (await isPortBusy(PORT)) {
    if (Date.now() > freeDeadline) {
      console.log('⚠ port 3030 encore occupé (test précédent ?) — nouvelle tentative…');
      break;
    }
    await new Promise((r) => setTimeout(r, 300));
  }
  const server: ChildProcess = spawn('node', ['--import', 'tsx', 'index.ts'], {
    cwd: process.cwd(),
    stdio: ['ignore', 'pipe', 'pipe'],
    detached: false,
  });
  let serverLog = '';
  server.stdout?.on('data', (d) => { serverLog += d.toString(); });
  server.stderr?.on('data', (d) => { serverLog += d.toString(); });

  // Laisse le serveur écouter — POLL du log de démarrage (robuste aux lenteurs
  // de binding du port : jusqu'à 15 s au lieu d'un sleep fixe).
  const bootDeadline = Date.now() + 15_000;
  while (Date.now() < bootDeadline) {
    if (/running on port/.test(serverLog)) break;
    if (server.exitCode !== null) break; // crashé
    await new Promise((r) => setTimeout(r, 250));
  }
  check('I0. serveur backend démarré (port 3030)', /running on port/.test(serverLog));

  try {
    // 2. Premier client (simule le frontend Chrome).
    //    FIX (audit v6.5) — race condition : le serveur émet 'status' PUIS
    //    'payout-guard-status' dans le MÊME tick du handler de connexion.
    //    L'ancien code attendait la résolution de 'status' AVANT d'attacher
    //    l'écouteur de 'payout-guard-status' → l'événement était déjà parti →
    //    timeout 8 s → I2/I3 échouaient systématiquement. On attache donc les
    //    DEUX écouteurs immédiatement après io(), avant la connexion.
    const client = io(URL, { transports: ['websocket'], reconnection: false });
    const statusP = waitFor<any>(client, 'status', () => true);
    const guardP = waitFor<any>(client, 'payout-guard-status', () => true);
    const status = await statusP;
    check('I1. à la connexion : status reçu', !!status);
    const guardStatus = await guardP;
    check('I2. à la connexion : payout-guard-status reçu (v6.3)', !!guardStatus && guardStatus.enabled === true);
    check('I3. payout-guard-status expose les seuils v20 (trigger 92, cible 92)',
      guardStatus?.triggerPct === 92 && guardStatus?.targetPct === 92);

    // 3. Toggle du Payout Guard.
    client.emit('set-payout-guard', { enabled: false });
    const off = await waitFor<any>(client, 'payout-guard-status', (s: any) => s?.enabled === false);
    check('I4. set-payout-guard OFF → statut reflecté', !!off);
    client.emit('set-payout-guard', { enabled: true });
    const on = await waitFor<any>(client, 'payout-guard-status', (s: any) => s?.enabled === true);
    check('I5. set-payout-guard ON → réactivé', !!on);

    // 4. LE BUG « exp 5s » de bout en bout : champ 6 s → fixedExpirySeconds 6 s.
    client.emit('set-auto-config', { expirySeconds: 6 });
    const auto6 = await waitFor<any>(client, 'auto-trade-status', (s: any) => s?.fixedExpirySeconds === 6);
    check('I6. champ Auto Trade = 6 s → fixedExpirySeconds 6 (plus de snap 5 s)', !!auto6);
    check('I7. clamp respecté : 6 s reste 6 s (jamais snappé) — l’expiration des ordres L_Lucien ProTrader vient des règles, le champ reste un réglage générique',
      auto6?.fixedExpirySeconds === 6 && auto6?.minExpirySeconds === 3 && auto6?.maxExpirySeconds === 86400);

    // Valeur 45 s (l'ancien snap l'écrasait en 30 s).
    client.emit('set-auto-config', { expirySeconds: 45 });
    const auto45 = await waitFor<any>(client, 'auto-trade-status', (s: any) => s?.fixedExpirySeconds === 45);
    check('I8. champ 45 s → fixedExpirySeconds 45 (l\'ancien snap donnait 30 s)', auto45?.fixedExpirySeconds === 45);

    // 5. HEADLESS : le frontend se déconnecte → le serveur SURVIT.
    client.disconnect();
    await new Promise((r) => setTimeout(r, 1200));
    check('I9. frontend fermé → serveur TOUJOURS vivant', server.exitCode === null);

    // 6. Un NOUVEAU frontend se connecte et récupère l'état complet.
    // FIX race préexistante : le serveur émet 'status' ET 'payout-guard-status'
    // dans le MÊME tick du handler de connexion (index.ts:6004-6006) —
    // enregistrer le second listener APRÈS le premier await faisait rater
    // l'événement déjà livré → I11 échouait de façon intermittente. On
    // enregistre les DEUX listeners AVANT tout await.
    const client2 = io(URL, { transports: ['websocket'], reconnection: false });
    const statusPromise = waitFor<any>(client2, 'status', () => true);
    const guardPromise = waitFor<any>(client2, 'payout-guard-status', () => true);
    const status2 = await statusPromise;
    const guard2 = await guardPromise;
    check('I10. réouverture du frontend : status reçu', !!status2);
    check('I11. réouverture : payout-guard-status reçu', !!guard2);
    // La config (expiration 45 s) a SURVÉCÉ à la fermeture du frontend.
    check('I12. config expiration 45 s conservée après fermeture/réouverture du frontend',
      status2?.autoTrade?.fixedExpirySeconds === 45);
    check('I13. get-payout-guard → statut à la demande', (() => {
      client2.emit('get-payout-guard');
      return true; // réponse vérifiée via I11 (même event)
    })());

    client2.disconnect();
  } finally {
    server.kill('SIGTERM');
    await new Promise((r) => setTimeout(r, 800));
    if (server.exitCode === null) server.kill('SIGKILL');
  }

  console.log('\n' + '='.repeat(72));
  console.log(`RÉSULTAT : ${passed} test(s) OK, ${failed} échec(s)`);
  if (failed > 0) {
    console.log('\nÉchecs :');
    for (const f of failures) console.log(`  ✗ ${f}`);
    console.log(`\n--- log serveur (extrait) ---\n${serverLog.slice(-2000)}`);
    process.exit(1);
  }
  console.log('\n✔ INTÉGRATION v6.3 VALIDÉE : events temps réel, expiration respectée,');
  console.log('  Payout Guard pilotable, continuité headless après fermeture du frontend.');
  process.exit(0);
}

void main();
