/**
 * test-confirm-candle-cap-e2e.mjs — E2E v19 sur le VRAI backend + faux broker.
 * ============================================================================
 *
 * Deux nouvelles fonctionnalités Auto Trade (spéc. utilisateur) :
 *
 * PHASE A — GARDE-FOU MARTINGALE (sémantique v20 : N = N MISES) :
 *   base 1$, Martingale ×2, maxMartingaleSteps = 2, 5 pertes imposées :
 *     ordres placés : 1 → 2 → 1 → 2 → 1   (2 MISES dans la séquence ; après
 *                                          l'échec de la 2e mise (2$) —
 *                                          RETOUR à la mise initiale 1$,
 *                                          la « 3e mise » n'existe pas)
 *     prochaine mise : 2 → 1 → 2 → 1 → 2
 *     streak         : 1   0   1   0   1
 *
 * PHASE B — SWITCH « CONFIRMATION BOUGIE PRÉCÉDENTE » :
 *   Script broker 'RGG' : BOS Up + CISD Up toutes les 3 bougies — la bougie
 *   PRÉCÉDANT la bougie signalée est VERTE (haussière).
 *     1. switch ON  → TOUS les signaux CALL ▲ sont REFUSÉS (confirmation
 *                    exige une bougie BAISSIÈRE) : AUCUN ordre pendant ≥ 3
 *                    cycles de signal, reason « REFUSÉ par la confirmation
 *                    de bougie » visible dans strategy-state ;
 *     2. switch OFF → un ordre CALL ▲ repart immédiatement ;
 *     3. switch ON  → plus AUCUN nouvel ordre (re-blocage).
 *
 * Vérifie AUSSI : auto-trade-status expose bosChochCisdConfirmCandle +
 * maxMartingaleSteps (sync UI), et le cap est propagé aux contextes.
 *
 * Exécution : node tests/test-confirm-candle-cap-e2e.mjs
 */
import { spawn } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { io } from 'socket.io-client';
import { MockPoBroker } from './mock-po-broker.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BACKEND_DIR = path.resolve(__dirname, '..');
const BACKEND_PORT = 3030;

const BASE = 1;
const CAP = 2;                  // maxMartingaleSteps (2 MISES — sémantique v20)
const RULE_EXPIRY = 3;          // expiration de la règle BOS (secondes)
const OUTCOMES = ['loss', 'loss', 'loss', 'loss', 'loss', 'loss'];
// Phase A : 5 pertes avec cap 2 → mises 1, 2 (2 mises) puis reset → 1, 2, 1
const EXPECTED_STAKES = [1, 2, 1, 2, 1];
const EXPECTED_NEXT = [2, 1, 2, 1, 2];
const EXPECTED_STREAK = [1, 0, 1, 0, 1];

let failures = 0, checks = 0;
function ok(cond, label) {
  checks++;
  if (cond) console.log(`  ✓ ${label}`);
  else { failures++; console.error(`  ✗ ${label}`); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

function main() {
  console.log('\n=== E2E v19 — confirmation bougie précédente + garde-fou Martingale (backend réel + faux broker) ===\n');

  const broker = new MockPoBroker({
    httpPort: 4540,
    wsPort: 4541,
    candleSec: 5,
    settleDelayMs: 2500,
    historyBuckets: 300,
    script: 'RGG',                    // BOS Up + CISD Up toutes les 3 bougies (précédente VERTE)
    outcomeScript: OUTCOMES,          // 6 pertes imposées dans l'ordre
    wickSize: 0.00010,                // mèches réalistes → croisements STRICTS des swings
    realtimeClosePush: true,          // chemin réel successcloseOrder
  });
  let backend = null;
  let socket = null;

  const cleanupAll = (code) => {
    try {
      if (backend && backend.exitCode === null) {
        try { process.kill(-backend.pid, 'SIGKILL'); }
        catch { try { backend.kill('SIGKILL'); } catch { /* ignore */ } }
      }
    } catch { /* ignore */ }
    try { broker.stop(); } catch { /* ignore */ }
    try { if (socket) socket.close(); } catch { /* ignore */ }
    if (code != null) {
      console.log(`\n=== RÉSULTAT E2E : ${checks - failures}/${checks} vérifications OK ===`);
      process.exit(failures > 0 ? 1 : code);
    }
  };
  process.on('SIGINT', () => cleanupAll(130));
  process.on('uncaughtException', e => { console.error('UNCAUGHT:', e); cleanupAll(1); });

  (async () => {
    // ── 1. Faux broker ──
    const ports = await broker.start();
    console.log(`[1] faux broker PO démarré (http :${ports.httpPort}, ws :${ports.wsPort})`);

    // ── 2. VRAI backend ──
    console.log('[2] démarrage du VRAI backend (tsx index.ts)…');
    const backendLog = fs.openSync(path.join(BACKEND_DIR, 'e2e-confirm-cap.log'), 'w');
    backend = spawn('npx', ['tsx', 'index.ts'], {
      cwd: BACKEND_DIR,
      env: {
        ...process.env,
        PO_API_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_WEB_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_DEMO_WS_URL: `ws://127.0.0.1:${ports.wsPort}`,
        SESSION_SNAPSHOT_DIR: '0',
        PO_STARTUP_RANDOM_ASSET: '0',  // v21 — pas de sélection aléatoire 92% au démarrage (test contrôlé)
        SOCIAL_DEBUG_PORT: '4340',
        NODE_ENV: 'development',
      },
      stdio: ['ignore', backendLog, backendLog],
      detached: true,
    });

    let connected = false;
    for (let i = 0; i < 40 && !connected; i++) {
      await sleep(500);
      socket = io(`http://127.0.0.1:${BACKEND_PORT}`, { transports: ['websocket'], path: '/', reconnection: false, timeout: 3000 });
      connected = await new Promise(r => { socket.once('connect', () => r(true)); socket.once('connect_error', () => r(false)); });
      if (!connected) { try { socket.close(); } catch { /* ignore */ } }
    }
    ok(connected, `backend joignable sur :${BACKEND_PORT} (socket.io connecté)`);
    if (!connected) { cleanupAll(1); return; }

    // ── 3. Séquence identique au frontend ──
    console.log('[3] login démo sur le faux broker…');
    const loginResult = await new Promise(r => {
      socket.once('login-result', r);
      socket.emit('login', { email: 'demo@e2e.test', password: 'demo-pass', mode: 'demo' });
      setTimeout(() => r({ ok: false, error: 'timeout login' }), 30000);
    });
    ok(loginResult?.ok === true, `login démo OK (uid=${loginResult?.user_id ?? '?'})`);
    if (!loginResult?.ok) { console.error('login échoué:', loginResult); cleanupAll(1); return; }

    socket.emit('set-config', { candleSize: 5, cooldownSeconds: 3 });
    await sleep(300);

    const selected = await new Promise(r => {
      socket.once('assets-selected', r);
      socket.emit('select-assets', { mode: 'single', assets: ['EURUSD_otc'] });
      setTimeout(() => r({ ok: false }), 15000);
    });
    ok(selected?.ok === true, 'asset sélectionné : EURUSD_otc (mode single)');

    socket.emit('set-auto-strategy', { strategyId: 'l_lucien_protrader' });
    await sleep(200);

    // Martingale + base 1 + garde-fou 2 doublements.
    const cfgAck = await new Promise(r => {
      socket.once('auto-trade-status', r);
      socket.emit('set-auto-config', {
        bettingStrategy: 'martingale',
        baseAmount: BASE,
        maxMartingaleSteps: CAP,
      });
      setTimeout(() => r(null), 10000);
    });
    socket.emit('set-config', { margin: String(BASE), bettingStrategy: 'martingale', cooldownSeconds: 3, expirySeconds: 61 });
    await sleep(300);

    // Règles BOS CALL+PUT avec expiration 3 s.
    socket.emit('set-auto-config', {
      bosChochCisdCallRules: [{ id: 'call-bos-up', alerts: ['BOS Up'], expirationSeconds: RULE_EXPIRY }],
      bosChochCisdPutRules: [{ id: 'put-bos-down', alerts: ['BOS Down'], expirationSeconds: RULE_EXPIRY }],
    });
    await sleep(300);

    const autoOn = await new Promise(r => {
      socket.once('auto-trade-status', r);
      socket.emit('set-auto-trade', { enabled: true });
      setTimeout(() => r(null), 10000);
    });
    ok(autoOn && autoOn.enabled !== false, `auto-trade ON (stratégie=${autoOn?.strategyId ?? '?'})`);
    ok(autoOn?.strategyId === 'l_lucien_protrader', `stratégie active = l_lucien_protrader (${autoOn?.strategyId})`);
    ok(autoOn?.bettingStrategy === 'martingale', `mise = martingale (${autoOn?.bettingStrategy})`);
    ok(autoOn?.maxMartingaleSteps === CAP, `auto-trade-status expose maxMartingaleSteps=${CAP} (obtenu ${autoOn?.maxMartingaleSteps})`);
    ok(autoOn?.bosChochCisdConfirmCandle === false, `switch confirmation OFF par défaut (obtenu ${autoOn?.bosChochCisdConfirmCandle})`);

    // ── 4. PHASE A : 5 pertes avec cap 2 → mises 1, 2, 4, 1, 2 ──
    console.log(`[4] PHASE A — trading : 5 pertes imposées, Martingale ×2, cap ${CAP} doublements…`);
    const placedOrders = [];
    let lastStatus = null;
    const strategyStates = [];
    socket.on('auto-trade-status', (s) => { if (s) lastStatus = s; });
    socket.on('strategy-state', (s) => {
      if (s?.asset === 'EURUSD_otc' || s?.asset == null) strategyStates.push(s);
    });
    socket.on('trade-opened', (ev) => {
      if (ev?.source === 'l_lucien_protrader') {
        placedOrders.push({
          id: String(ev.deal?.id ?? ''),
          amount: Number(ev.deal?.amount ?? 0),
          action: String(ev.deal?.action ?? '?'),
        });
        console.log(`    [A] ordre #${placedOrders.length} : ${ev.deal?.action?.toUpperCase()} ${ev.deal?.amount}$ (deal ${String(ev.deal?.id).slice(0, 8)}…)`);
        // Suspend : le deal doit être RÉGLÉ avant le calcul de la mise suivante.
        socket.emit('set-auto-trade', { enabled: false });
      }
    });

    const deadline = Date.now() + 300_000;
    for (let i = 0; i < EXPECTED_STAKES.length; i++) {
      while (placedOrders.length <= i) {
        if (Date.now() > deadline) break;
        await sleep(500);
      }
      if (placedOrders.length <= i) break;
      const target = EXPECTED_NEXT[i];
      const targetStreak = EXPECTED_STREAK[i];
      let settled = false;
      const settleDeadline = Date.now() + 90_000;
      while (Date.now() < settleDeadline) {
        await sleep(1000);
        const nextBet = lastStatus?.nextBetAmount;
        if (typeof nextBet === 'number' && nextBet === target &&
            (lastStatus?.stats?.consecutiveLosses ?? -1) === targetStreak) {
          settled = true;
          break;
        }
      }
      ok(settled, `ordre ${i + 1} (${EXPECTED_STAKES[i]}$) LOSS réglé → prochaine mise ${target}$ (streak ${targetStreak})`);
      if (i < EXPECTED_STAKES.length - 1) {
        socket.emit('set-auto-trade', { enabled: true });
      }
    }
    await sleep(2000);
    socket.emit('set-auto-trade', { enabled: false });
    await sleep(1500);

    console.log(`    ordres placés : ${placedOrders.map(o => o.amount).join(' → ')}`);
    ok(placedOrders.length === EXPECTED_STAKES.length,
      `${EXPECTED_STAKES.length} ordres placés (obtenu ${placedOrders.length})`);
    ok(JSON.stringify(placedOrders.map(o => o.amount)) === JSON.stringify(EXPECTED_STAKES),
      `PHASE A — mises 1→2→4→1→2 avec cap ${CAP} : RETOUR À LA MISE INITIALE après la perte au niveau max (obtenu ${placedOrders.map(o => o.amount).join('→')})`);

    // ── 5. PHASE B : switch « Confirmation bougie précédente » ──
    console.log('[5] PHASE B — switch « Confirmation bougie précédente »…');
    const ordersBefore = placedOrders.length;

    // 5.a — switch ON : les signaux CALL ▲ de 'RGG' (précédente VERTE =
    //       haussière) doivent être TOUS refusés (exige une BAISSIÈRE).
    const onAck = await new Promise(r => {
      socket.once('auto-trade-status', r);
      socket.emit('set-auto-config', { bosChochCisdConfirmCandle: true });
      setTimeout(() => r(null), 10000);
    });
    ok(onAck?.bosChochCisdConfirmCandle === true, `switch ON confirmé par auto-trade-status (${onAck?.bosChochCisdConfirmCandle})`);
    ok(onAck?.maxMartingaleSteps === CAP, `cap préservé à ${CAP} après le switch (${onAck?.maxMartingaleSteps})`);
    socket.emit('set-auto-trade', { enabled: true });

    strategyStates.length = 0;
    let blockedSeen = false;
    const blockDeadline = Date.now() + 40_000; // ≥ 8 bougies S5 = ≥ 2 cycles de signal
    while (Date.now() < blockDeadline && placedOrders.length === ordersBefore) {
      await sleep(1000);
      if (!blockedSeen && strategyStates.some(s => /REFUSÉ par la confirmation de bougie/.test(String(s?.reason ?? '')))) {
        blockedSeen = true;
      }
    }
    ok(placedOrders.length === ordersBefore,
      `switch ON : AUCUN ordre pendant la fenêtre (signaux CALL refusés — ordres: ${placedOrders.length}, attendus: ${ordersBefore})`);
    ok(blockedSeen, 'reason « REFUSÉ par la confirmation de bougie » observé dans strategy-state');
    const blockedSample = strategyStates.find(s => /REFUSÉ par la confirmation de bougie/.test(String(s?.reason ?? '')));
    if (blockedSample) {
      console.log(`    reason bloqué : ${String(blockedSample.reason).slice(0, 150)}`);
      ok(String(blockedSample.reason).includes('exige une bougie baissière'),
        'le reason précise la règle (CALL ▲ exige une bougie baissière)');
    }
    socket.emit('set-auto-trade', { enabled: false });
    await sleep(1500);

    // 5.b — switch OFF : un ordre CALL ▼ doit repartir immédiatement.
    const offAck = await new Promise(r => {
      socket.once('auto-trade-status', r);
      socket.emit('set-auto-config', { bosChochCisdConfirmCandle: false });
      setTimeout(() => r(null), 10000);
    });
    ok(offAck?.bosChochCisdConfirmCandle === false, `switch OFF confirmé (${offAck?.bosChochCisdConfirmCandle})`);
    socket.emit('set-auto-trade', { enabled: true });
    let resumed = false;
    const resumeDeadline = Date.now() + 40_000;
    while (Date.now() < resumeDeadline && placedOrders.length === ordersBefore) {
      await sleep(500);
    }
    resumed = placedOrders.length > ordersBefore;
    ok(resumed, `switch OFF : un ordre CALL ▲ repart (ordres: ${placedOrders.length})`);
    if (resumed) {
      const last = placedOrders[placedOrders.length - 1];
      ok(last.action === 'call', `l'ordre repris est bien un CALL (action=${last.action})`);
      // Cap toujours actif : après la 6e perte (ordre 6 = 2$, streak 2 → next serait 4$)…
      // (pas besoin d'attendre le règlement — le cap a déjà été prouvé en phase A)
    }
    await sleep(2000);

    // 5.c — switch ON à nouveau : plus AUCUN nouvel ordre.
    const ordersAfterResume = placedOrders.length;
    await new Promise(r => {
      socket.once('auto-trade-status', r);
      socket.emit('set-auto-config', { bosChochCisdConfirmCandle: true });
      setTimeout(() => r(null), 10000);
    });
    const reblockDeadline = Date.now() + 25_000; // ≥ 5 bougies = ≥ 1 cycle de signal
    while (Date.now() < reblockDeadline && placedOrders.length === ordersAfterResume) {
      await sleep(1000);
    }
    ok(placedOrders.length === ordersAfterResume,
      `switch ON (re) : plus aucun nouvel ordre (ordres: ${placedOrders.length} vs ${ordersAfterResume})`);

    // ── 6. Bilan ──
    socket.emit('set-auto-trade', { enabled: false });
    console.log(`\n[6] BILAN — mises placées : ${placedOrders.map(o => o.amount).join(' → ')}`);
    cleanupAll(failures > 0 ? 1 : 0);
  })().catch(e => { console.error('FATAL:', e); cleanupAll(1); });
}

main();
