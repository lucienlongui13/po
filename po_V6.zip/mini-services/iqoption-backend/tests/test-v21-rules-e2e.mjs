/**
 * test-v21-rules-e2e.mjs — E2E v21 : 4 nouvelles règles utilisateur.
 * ============================================================================
 *
 * PHASE A — Démarrage du programme : asset 92 % ALÉATOIRE (plus d'EURUSD_otc
 *   par défaut) :
 *   1. Faux broker : EURUSD_otc 92 % · GBPUSD_otc 92 % · XAUUSD_otc 92 %
 *      (l'OR — alphabétiquement PREMIER, piège du filtre Forex) · USDJPY_otc
 *      88 % (non éligible).
 *   2. Login SANS session persistée (SESSION_SNAPSHOT_DIR=0) et SANS la
 *      garde PO_STARTUP_RANDOM_ASSET → le backend DOIT sélectionner
 *      lui-même un asset : assets-selected reason='startup-random-92'
 *      ≤ 45 s, payout == 92 %, focus = cet asset.
 *
 * PHASE B — Refresh de la page : l'asset en cours est conservé :
 *   3. Fermer le socket, en rouvrir un NOUVEAU (simulation du reload
 *      navigateur : le backend headless ne change JAMAIS d'asset) → le
 *      status 1 Hz rapporte LE MÊME market.name ; un login idempotent
 *      (mêmes identifiants) reprend la session avec le MÊME focus.
 *
 * PHASE C — « Stay on Forex OTC Only » ON :
 *   4. Sélection manuelle single EURUSD_otc ; Auto Switch ON ;
 *      Stay on Forex OTC Only ON ; payout EURUSD → 56 %.
 *   5. Le switch part vers GBPUSD_otc (FOREX) — JAMAIS XAUUSD_otc (l'or
 *      92 % pourtant alphabétiquement premier) — et l'événement
 *      force-frontend-refresh (reason 'auto-switch') est bien émis.
 *
 * PHASE D — « Stay on Forex OTC Only » OFF :
 *   6. Toggle OFF ; payout GBPUSD → 56 % → le switch part vers
 *      XAUUSD_otc (seul 92 % restant) : sans le filtre, tout asset 92 %
 *      redevient éligible.
 *
 * Exécution : node tests/test-v21-rules-e2e.mjs
 */
import { spawn } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { io } from 'socket.io-client';
import { MockPoBroker } from './mock-po-broker.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BACKEND_DIR = path.resolve(__dirname, '..');
const BACKEND_PORT = 3030;

const EUR = 'EURUSD_otc';
const GBP = 'GBPUSD_otc';
const XAU = 'XAUUSD_otc';   // l'or — 92 %, alphabétiquement AVANT GBPUSD_otc
const JPY = 'USDJPY_otc';   // 88 % — jamais éligible

let failures = 0, checks = 0;
function ok(cond, label) {
  checks++;
  if (cond) console.log(`  ✓ ${label}`);
  else { failures++; console.error(`  ✗ ${label}`); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

function main() {
  console.log('\n=== E2E v21 — démarrage aléatoire 92 % · refresh conserve l\u2019asset · Stay on Forex OTC Only · refresh frontend obligatoire ===\n');

  const broker = new MockPoBroker({
    httpPort: 4670,
    wsPort: 4671,
    candleSec: 5,
    settleDelayMs: 2500,
    historyBuckets: 300,
    script: 'RGG',
    wickSize: 0.00010,
    realtimeClosePush: true,
    assets: [
      { symbol: EUR, startPrice: 1.18000, bodySize: 0.00030, payout: 92 },
      { symbol: GBP, startPrice: 1.27000, bodySize: 0.00040, payout: 92 },
      { symbol: XAU, startPrice: 2315.000, bodySize: 0.35000, payout: 92 },
      { symbol: JPY, startPrice: 1.48000, bodySize: 0.00050, payout: 88 },
    ],
    outcomeScriptByAsset: {},
  });
  let backend = null;
  let socket = null;

  const cleanupAll = (code) => {
    try {
      if (backend && backend.exitCode === null) {
        try { process.kill(-backend.pid, 'SIGKILL'); }
        catch { try { backend.kill('SIGKILL'); } catch { /* ignore */ } }
      }
    } catch { /* ignore */ }
    try { broker.stop(); } catch { /* ignore */ }
    try { if (socket) socket.close(); } catch { /* ignore */ }
    if (code != null) {
      console.log(`\n=== RÉSULTAT E2E v21 : ${checks - failures}/${checks} vérifications OK ===`);
      process.exit(failures > 0 ? 1 : code);
    }
  };
  process.on('SIGINT', () => cleanupAll(130));
  process.on('SIGTERM', () => cleanupAll(143)); // timeout(1) envoie SIGTERM — sans ça, le backend détaché SURVIT et bloque le port 3030 des runs suivantes
  process.on('uncaughtException', e => { console.error('UNCAUGHT:', e); cleanupAll(1); });

  (async () => {
    // ── 1. Faux broker + VRAI backend ──
    const ports = await broker.start();
    console.log(`[1] faux broker PO démarré (http :${ports.httpPort}, ws :${ports.wsPort})`);
    const logPath = path.join(BACKEND_DIR, 'e2e-v21-rules.log');
    const backendLog = fs.openSync(logPath, 'w');
    backend = spawn('npx', ['tsx', 'index.ts'], {
      cwd: BACKEND_DIR,
      env: {
        ...process.env,
        PO_API_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_WEB_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_DEMO_WS_URL: `ws://127.0.0.1:${ports.wsPort}`,
        SESSION_SNAPSHOT_DIR: '0',   // pas de session persistée → DÉMARRAGE PUR
        SOCIAL_DEBUG_PORT: '4470',
        NODE_ENV: 'development',
        // NB : PO_STARTUP_RANDOM_ASSET volontairement NON défini — Phase A.
      },
      stdio: ['ignore', backendLog, backendLog],
      detached: true,
    });

    const connect = async () => {
      for (let i = 0; i < 40; i++) {
        const s = io(`http://127.0.0.1:${BACKEND_PORT}`, { transports: ['websocket'], path: '/', reconnection: false, timeout: 3000 });
        const connected = await new Promise(r => { s.once('connect', () => r(true)); s.once('connect_error', () => r(false)); });
        if (connected) return s;
        try { s.close(); } catch { /* ignore */ }
        await sleep(500);
      }
      return null;
    };
    socket = await connect();
    ok(!!socket, `backend joignable sur :${BACKEND_PORT} (socket.io connecté)`);
    if (!socket) { cleanupAll(1); return; }

    // ── 2. PHASE A — login → sélection ALÉATOIRE d'un asset 92 % ──
    console.log('[2] PHASE A — login : le backend DOIT choisir seul un asset 92 % (plus de défaut EURUSD_otc)…');
    const loginResult = await new Promise(r => {
      socket.once('login-result', r);
      socket.emit('login', { email: 'demo@e2e.test', password: 'demo-pass', mode: 'demo' });
      setTimeout(() => r({ ok: false, error: 'timeout login' }), 30000);
    });
    ok(loginResult?.ok === true, `login démo OK (uid=${loginResult?.user_id ?? '?'})`);
    if (!loginResult?.ok) { console.error('login échoué:', loginResult); cleanupAll(1); return; }

    // Le faux broker ne diffuse l'historique qu'en période 5 (candleSec: 5) :
    // aligner le timeframe comme le fait le e2e v20 (sinon le fetch :30 du
    // mock ne répond jamais et le switch reste en attente indéfiniment).
    socket.emit('set-config', { candleSize: 5, cooldownSeconds: 3 });
    await sleep(300);

    let startupSelection = null;
    socket.on('assets-selected', (ev) => {
      if (ev?.reason === 'startup-random-92') startupSelection = ev;
    });
    const startupDeadline = Date.now() + 45_000;
    while (Date.now() < startupDeadline && !startupSelection) await sleep(500);
    ok(!!startupSelection, `asset sélectionné ALÉATOIREMENT au démarrage ≤ 45 s (reason=startup-random-92, obtenu ${startupSelection ? startupSelection.assets?.[0] : 'AUCUN'})`);
    const startupAsset = startupSelection?.assets?.[0] ?? null;
    ok(startupAsset === EUR || startupAsset === GBP || startupAsset === XAU,
      `l'asset de démarrage est un des assets 92 % (obtenu ${startupAsset})`);
    ok(startupAsset !== JPY, `l'asset 88 % n'est JAMAIS choisi (obtenu ${startupAsset})`);
    ok(startupSelection?.mode === 'single' && startupSelection?.focus === startupAsset,
      `mode single, focus = l'asset tiré au hasard (${startupSelection?.focus})`);

    // Le status 1 Hz rapporte bien CET asset (plus d'EURUSD_otc codé en dur).
    console.log('[2b] attente du status 1 Hz (max 10 s)…');
    let statusA = null;
    const statusDeadline = Date.now() + 10_000;
    while (Date.now() < statusDeadline && !statusA) {
      // NOTE : le listener DOIT aussi résoudre r() — clearTimeout(t) seul
      // annulerait la SEULE source de résolution si l'événement gagne la
      // course contre le timeout → promesse jamais résolue → hang.
      await new Promise(r => { const t = setTimeout(() => r(undefined), 1000); socket.once('status', (s) => { clearTimeout(t); statusA = s; r(s); }); });
    }
    console.log(`[2b] status reçu: ${statusA ? `market=${statusA?.market?.name} config.market=${statusA?.config?.market}` : 'AUCUN (timeout 10 s)'}`);
    ok(statusA?.market?.name === startupAsset,
      `status.market.name = l'asset aléatoire (${statusA?.market?.name} vs ${startupAsset})`);
    ok(statusA?.config?.market === startupAsset,
      `status.config.market = l'asset aléatoire (${statusA?.config?.market})`);

    // ── 3. PHASE B — refresh navigateur : l'asset en cours est conservé ──
    console.log(`[3] PHASE B — refresh simulé (nouveau socket) : ${startupAsset} doit être conservé…`);
    socket.close();
    console.log('[3] ancien socket fermé — reconnexion…');
    await sleep(800);
    socket = await connect();
    console.log(`[3] nouveau socket ${socket ? 'connecté' : 'EN ÉCHEC'}`);
    ok(!!socket, 'nouveau socket connecté (page rechargée)');
    let statusB = null;
    const statusBDeadline = Date.now() + 10_000;
    while (Date.now() < statusBDeadline && !statusB) {
      // Même garde que [2b] : le listener résout AUSSI la promesse.
      await new Promise(r => { const t = setTimeout(() => r(undefined), 1000); socket.once('status', (s) => { clearTimeout(t); statusB = s; r(s); }); });
    }
    ok(statusB?.market?.name === startupAsset,
      `après refresh : MÊME asset en cours (${statusB?.market?.name} vs ${startupAsset}) — il ne repart PAS sur EURUSD_otc`);

    // Login idempotent (l'utilisateur re-clique Login après le refresh) :
    // les DEUX listeners sont attachés AVANT l'émission — le backend émet
    // login-result PUIS assets-selected dans la même micro-tâche (attacher
    // le 2e listener après réception du 1er = événement perdu = faux échec).
    const resumed = await new Promise((r) => {
      let loginEv = null, selEv = null;
      const done = () => { if (loginEv && selEv) r({ login: loginEv, sel: selEv }); };
      socket.once('login-result', (ev) => { loginEv = ev; done(); });
      socket.once('assets-selected', (ev) => { selEv = ev; done(); });
      socket.emit('login', { email: 'demo@e2e.test', password: 'demo-pass', mode: 'demo' });
      setTimeout(() => r({ login: loginEv ?? { ok: false, error: 'timeout' }, sel: selEv }), 20000);
    });
    ok(resumed.login?.ok === true && resumed.login?.resumed === true, `login idempotent — session REPRISE (resumed=${resumed.login?.resumed})`);
    ok(resumed.sel?.focus === startupAsset && resumed.sel?.assets?.[0] === startupAsset,
      `re-login → focus restauré sur l'asset en cours (${resumed.sel?.focus} vs ${startupAsset})`);

    // ── 4. PHASE C — Stay on Forex OTC Only ON ──
    console.log('[4] PHASE C — Auto Switch ON + Stay on Forex OTC Only ON → la cible est FOREX, jamais l\u2019or…');
    const selected = await new Promise(r => {
      socket.once('assets-selected', r);
      socket.emit('select-assets', { mode: 'single', assets: [EUR] });
      setTimeout(() => r({ ok: false }), 15000);
    });
    ok(selected?.ok === true, `sélection manuelle single ${EUR} OK`);

    socket.emit('set-config', { autoSwitchAssets: true, stayOnForexOtcOnly: true });
    await sleep(500);

    let switchEv = null;
    let ffrEv = null;
    socket.on('market-switched', (ev) => { if (!switchEv) switchEv = ev; });
    socket.on('force-frontend-refresh', (ev) => { if (!ffrEv) ffrEv = ev; });
    broker.setPayout(EUR, 56);

    const switchCDeadline = Date.now() + 20_000;
    while (Date.now() < switchCDeadline && !switchEv) await sleep(500);
    ok(!!switchEv, `switch déclenché ≤ 20 s après payout 56 % (obtenu ${switchEv ? 'oui' : 'NON'})`);
    if (switchEv) {
      ok(switchEv.from === EUR, `switch part de ${EUR} (${switchEv.from})`);
      ok(switchEv.to === GBP, `Stay on Forex OTC Only ON → cible FOREX ${GBP} (obtenu ${switchEv.to}) — l'or ${XAU} 92 % a été EXCLU`);
      ok(switchEv.payout === 92, `payout de la cible == 92 % (obtenu ${switchEv.payout})`);
    }
    // force-frontend-refresh est émis APRÈS le fetch d'historique du switch
    // (reconstruction backend complète) — budget dédié, indépendant du switch.
    const ffrCDeadline = Date.now() + 45_000;
    while (Date.now() < ffrCDeadline && !ffrEv) await sleep(500);
    ok(!!ffrEv, `événement force-frontend-refresh émis au switch (obtenu ${ffrEv ? `reason=${ffrEv.reason} ${ffrEv.from}→${ffrEv.to}` : 'AUCUN'})`);
    if (ffrEv) ok(ffrEv.reason === 'auto-switch', `reason du refresh = 'auto-switch' (obtenu ${ffrEv.reason})`);

    // ── 5. PHASE D — Stay on Forex OTC Only OFF ──
    console.log('[5] PHASE D — Stay on Forex OTC Only OFF → tout asset 92 % redevient éligible…');
    // La réception de force-frontend-refresh garantit que le switch C est
    // ENTIÈREMENT terminé (assetSwitchInProgress libéré) : Phase D saine.
    await sleep(1500);
    socket.emit('set-config', { stayOnForexOtcOnly: false });
    await sleep(500);

    switchEv = null;
    ffrEv = null;
    broker.setPayout(GBP, 56); // GBPUSD (nouvel asset en cours) passe < 92 %

    const switchDDeadline = Date.now() + 30_000;
    while (Date.now() < switchDDeadline && !switchEv) await sleep(500);
    ok(!!switchEv, `switch déclenché après la chute de ${GBP} (obtenu ${switchEv ? 'oui' : 'NON'})`);
    if (switchEv) {
      ok(switchEv.from === GBP, `switch part de ${GBP} (${switchEv.from})`);
      ok(switchEv.to === XAU, `filtre OFF → l'or ${XAU} (seul 92 % restant) redevient éligible (obtenu ${switchEv.to})`);
      ok(switchEv.payout === 92, `payout de la cible == 92 % (obtenu ${switchEv.payout})`);
    }

    // ── 6. Logs backend : les lignes explicites v21 ──
    await sleep(1000);
    try {
      const logs = fs.readFileSync(logPath, 'utf-8');
      ok(/ALÉATOIREMENT parmi \d+ asset\(s\) à profit 92 %/.test(logs),
        'log backend « asset sélectionné ALÉATOIREMENT parmi N asset(s) à profit 92 % » présent');
      ok(/Stay on Forex OTC Only ON — cibles limitées aux paires Forex OTC/.test(logs),
        'log backend « Stay on Forex OTC Only ON » présent');
      ok(/Stay on Forex OTC Only OFF/.test(logs),
        'log backend « Stay on Forex OTC Only OFF » présent');
      ok(/Forex OTC uniquement/.test(logs),
        'log AUTO-SWITCH avec mention « Forex OTC uniquement »');
      ok(/front end refresh demandé|refresh frontend demandé|frontend reload demandé/.test(logs),
        'log backend « refresh frontend demandé » présent (auto-switch et/ou re-login)');
    } catch (e) {
      ok(false, `lecture des logs backend impossible (${e.message})`);
    }

    console.log('\n[6] BILAN — règles v21 validées E2E.');
    cleanupAll(failures > 0 ? 1 : 0);
  })().catch(e => { console.error('FATAL:', e); cleanupAll(1); });
}

main();
