/**
 * test-auto-switch-rule-e2e.mjs — E2E v20 : NOUVELLES RÈGLES AUTO SWITCH ASSETS.
 * ============================================================================
 *
 * Spécification utilisateur (v20) :
 *   « Dès que le pourcentage de profit de l'asset en cours baisse à une
 *     valeur < 92 % et que le dernier ordre est un gain et non une perte,
 *     alors on switch d'assets automatiquement — que sur des assets avec
 *     profit == 92 %. »
 *
 * PHASE A — déclencheur + cible + BUG 2 (1er ordre) :
 *   1. 3 assets OTC à 92 % ; mode single sur EURUSD_otc ; Auto Trade ON
 *      (Martingale, base 1, BOS Up → CALL 3 s) ; premier ordre forcé WIN
 *      → lastOrderWin = true.
 *   2. Activation d'Auto Switch Assets, puis chute du payout EURUSD → 56 %.
 *   3. Le switch doit partir IMMÉDIATEMENT (≤ 12 s) vers GBPUSD_otc ou
 *      USDJPY_otc (payout == 92 %), ET l'Auto Trade du nouvel asset reste
 *      ACTIF (bug « 30 min sans 1er ordre » : le contexte héritait d'un
 *      autoTradeEnabled: false codé en dur) — un ordre repart sur le
 *      nouvel asset.
 *
 * PHASE B — verrou « dernier ordre = GAIN » :
 *   4. Sur le nouvel asset B : premier ordre forcé LOSS (lastOrderWin=false).
 *   5. Chute du payout B → 56 % → AUCUN switch pendant 15 s (le switch
 *      attend le gain ; une Martingale en récupération n'est pas abandonnée).
 *   6. Ordre forcé WIN → lastOrderWin=true → le switch part (≤ 20 s) vers
 *      un asset payout == 92 %.
 *
 * Vérifie AUSSI dans les logs backend : la ligne explicite
 * « switch en attente du prochain GAIN » pendant la phase bloquée.
 *
 * Exécution : node tests/test-auto-switch-rule-e2e.mjs
 */
import { spawn } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { io } from 'socket.io-client';
import { MockPoBroker } from './mock-po-broker.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BACKEND_DIR = path.resolve(__dirname, '..');
const BACKEND_PORT = 3030;

const A = 'EURUSD_otc';
const B = 'GBPUSD_otc';
const C = 'USDJPY_otc';
const RULE_EXPIRY = 3;

let failures = 0, checks = 0;
function ok(cond, label) {
  checks++;
  if (cond) console.log(`  ✓ ${label}`);
  else { failures++; console.error(`  ✗ ${label}`); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

function main() {
  console.log('\n=== E2E v20 — Auto Switch Assets : payout < 92% + dernier ordre GAIN → asset == 92% (backend réel + faux broker) ===\n');

  const broker = new MockPoBroker({
    httpPort: 4560,
    wsPort: 4561,
    candleSec: 5,
    settleDelayMs: 2500,
    historyBuckets: 300,
    script: 'RGG',                    // BOS Up + CISD Up toutes les 3 bougies
    wickSize: 0.00010,
    realtimeClosePush: true,
    assets: [
      { symbol: A, startPrice: 1.18000, bodySize: 0.00030, payout: 92 },
      { symbol: B, startPrice: 1.27000, bodySize: 0.00040, payout: 92 },
      { symbol: C, startPrice: 1.48000, bodySize: 0.00050, payout: 92 },
    ],
    // Aucun outcome global : piloté PAR ASSET pendant le test.
    outcomeScriptByAsset: {},
  });
  let backend = null;
  let socket = null;

  const cleanupAll = (code) => {
    try {
      if (backend && backend.exitCode === null) {
        try { process.kill(-backend.pid, 'SIGKILL'); }
        catch { try { backend.kill('SIGKILL'); } catch { /* ignore */ } }
      }
    } catch { /* ignore */ }
    try { broker.stop(); } catch { /* ignore */ }
    try { if (socket) socket.close(); } catch { /* ignore */ }
    if (code != null) {
      console.log(`\n=== RÉSULTAT E2E : ${checks - failures}/${checks} vérifications OK ===`);
      process.exit(failures > 0 ? 1 : code);
    }
  };
  process.on('SIGINT', () => cleanupAll(130));
  process.on('uncaughtException', e => { console.error('UNCAUGHT:', e); cleanupAll(1); });

  (async () => {
    // ── 1. Faux broker ──
    const ports = await broker.start();
    console.log(`[1] faux broker PO démarré (http :${ports.httpPort}, ws :${ports.wsPort})`);

    // ── 2. VRAI backend ──
    console.log('[2] démarrage du VRAI backend (tsx index.ts)…');
    const logPath = path.join(BACKEND_DIR, 'e2e-auto-switch.log');
    const backendLog = fs.openSync(logPath, 'w');
    backend = spawn('npx', ['tsx', 'index.ts'], {
      cwd: BACKEND_DIR,
      env: {
        ...process.env,
        PO_API_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_WEB_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_DEMO_WS_URL: `ws://127.0.0.1:${ports.wsPort}`,
        SESSION_SNAPSHOT_DIR: '0',
        PO_STARTUP_RANDOM_ASSET: '0',  // v21 — pas de sélection aléatoire 92% au démarrage (test contrôlé)
        SOCIAL_DEBUG_PORT: '4360',
        NODE_ENV: 'development',
      },
      stdio: ['ignore', backendLog, backendLog],
      detached: true,
    });

    let connected = false;
    for (let i = 0; i < 40 && !connected; i++) {
      await sleep(500);
      socket = io(`http://127.0.0.1:${BACKEND_PORT}`, { transports: ['websocket'], path: '/', reconnection: false, timeout: 3000 });
      connected = await new Promise(r => { socket.once('connect', () => r(true)); socket.once('connect_error', () => r(false)); });
      if (!connected) { try { socket.close(); } catch { /* ignore */ } }
    }
    ok(connected, `backend joignable sur :${BACKEND_PORT} (socket.io connecté)`);
    if (!connected) { cleanupAll(1); return; }

    // ── 3. Login + sélection single EURUSD + Auto Trade ──
    console.log('[3] login démo + sélection single EURUSD_otc…');
    const loginResult = await new Promise(r => {
      socket.once('login-result', r);
      socket.emit('login', { email: 'demo@e2e.test', password: 'demo-pass', mode: 'demo' });
      setTimeout(() => r({ ok: false, error: 'timeout login' }), 30000);
    });
    ok(loginResult?.ok === true, `login démo OK (uid=${loginResult?.user_id ?? '?'})`);
    if (!loginResult?.ok) { console.error('login échoué:', loginResult); cleanupAll(1); return; }

    socket.emit('set-config', { candleSize: 5, cooldownSeconds: 3 });
    await sleep(300);

    const selected = await new Promise(r => {
      socket.once('assets-selected', r);
      socket.emit('select-assets', { mode: 'single', assets: [A] });
      setTimeout(() => r({ ok: false }), 15000);
    });
    ok(selected?.ok === true, `asset sélectionné : ${A} (mode single)`);

    socket.emit('set-auto-strategy', { strategyId: 'l_lucien_protrader' });
    await sleep(200);

    socket.emit('set-auto-config', {
      bettingStrategy: 'martingale',
      baseAmount: 1,
      maxMartingaleSteps: 2,
      bosChochCisdCallRules: [{ id: 'call-bos-up', alerts: ['BOS Up'], expirationSeconds: RULE_EXPIRY }],
      bosChochCisdPutRules: [{ id: 'put-bos-down', alerts: ['BOS Down'], expirationSeconds: RULE_EXPIRY }],
    });
    await sleep(400);

    const autoOn = await new Promise(r => {
      socket.once('auto-trade-status', r);
      socket.emit('set-auto-trade', { enabled: true });
      setTimeout(() => r(null), 10000);
    });
    ok(autoOn && autoOn.enabled !== false, 'auto-trade ON');

    // ── 4. Ordre 1 sur EURUSD : WIN forcé ──
    console.log('[4] PHASE A — ordre 1 sur EURUSD (WIN forcé → dernier ordre = gain)…');
    broker.outcomeScriptByAsset[A] = ['win'];

    let lastStatus = null;
    socket.on('auto-trade-status', (s) => { if (s) lastStatus = s; });
    let orderOnA = null;
    let aSettledWin = false;
    socket.on('trade-opened', (ev) => {
      if (ev?.asset === A || ev?.deal?.asset === A) orderOnA = { id: String(ev.deal?.id ?? ''), amount: Number(ev.deal?.amount ?? 0) };
    });
    socket.on('trade-closed', (ev) => {
      if ((ev?.asset === A || ev?.deal?.asset === A) && ev?.outcome === 'win') aSettledWin = true;
    });
    const winDeadline = Date.now() + 90_000;
    while (Date.now() < winDeadline && !aSettledWin) await sleep(1000);
    ok(aSettledWin, 'ordre 1 sur EURUSD réglé WIN (dernier ordre = GAIN)');

    // ── 5. Auto Switch ON + chute du payout EURUSD → 56 % ──
    console.log('[5] PHASE A — Auto Switch ON, payout EURUSD 92% → 56%…');
    socket.emit('set-config', { autoSwitchAssets: true });
    await sleep(500);

    let switchEv = null;
    socket.on('market-switched', (ev) => { switchEv = ev; });
    broker.setPayout(A, 56); // « dès que le pourcentage baisse < 92 % »

    const switchDeadline = Date.now() + 12_000;
    while (Date.now() < switchDeadline && !switchEv) await sleep(500);
    ok(!!switchEv, `switch déclenché ≤ 12 s après la chute < 92 % (obtenu ${switchEv ? 'oui' : 'NON'})`);
    if (switchEv) {
      ok(switchEv.from === A, `switch part de l'asset en cours (${switchEv.from})`);
      ok(switchEv.to === B || switchEv.to === C, `cible = asset payout == 92 % (obtenu ${switchEv.to})`);
      ok(switchEv.payout === 92, `payout de la cible == 92 % (obtenu ${switchEv.payout})`);
    }

    // BUG 2 — l'Auto Trade du nouvel asset doit rester ACTIF et trader.
    // NOTE : le 1er ordre sur le nouvel asset attend la formation d'un VRAI
    // signal BOS/CHoCH/CISD sur ses bougies clôturées (structure à former sur
    // l'historique frais — ~100 s observées) : ce délai est NORMAL, l'ancien
    // bug (contexte désactivé → JAMAIS d'ordre) est détecté par l'absence
    // totale d'ordre au-delà de 150 s.
    const secondAsset = switchEv?.to ?? B;
    await sleep(1500);
    let statusAfterSwitch = lastStatus;
    const bug2Deadline = Date.now() + 150_000;
    let orderOnNew = null;
    socket.on('trade-opened', (ev) => {
      const asset = ev?.asset ?? ev?.deal?.asset;
      if (asset === secondAsset) orderOnNew = { amount: Number(ev.deal?.amount ?? 0) };
    });
    while (Date.now() < bug2Deadline && !orderOnNew) await sleep(1000);
    ok(!!orderOnNew, `BUG 2 — 1er ordre sur ${secondAsset} parti sans retoggle (${orderOnNew ? `${orderOnNew.amount}$` : 'AUCUN — le contexte était désactivé'})`);
    ok(statusAfterSwitch?.enabled !== false, 'BUG 2 — auto-trade-status reste ON après le switch');

    // ── 6. PHASE B — verrou « dernier ordre = perte » ──
    console.log(`[6] PHASE B — ${secondAsset} : LOSS forcé puis payout 56% (le switch DOIT attendre le gain)…`);
    broker.outcomeScriptByAsset[secondAsset] = ['loss'];
    let lossSettled = false;
    socket.on('trade-closed', (ev) => {
      const asset = ev?.asset ?? ev?.deal?.asset;
      if (asset === secondAsset && ev?.outcome === 'loss') lossSettled = true;
    });
    const lossDeadline = Date.now() + 120_000;
    while (Date.now() < lossDeadline && !lossSettled) await sleep(1000);
    ok(lossSettled, `ordre LOSS réglé sur ${secondAsset} (dernier ordre = PERTE)`);

    switchEv = null;
    broker.setPayout(secondAsset, 56);
    const noSwitchDeadline = Date.now() + 15_000;
    while (Date.now() < noSwitchDeadline && !switchEv) await sleep(500);
    ok(!switchEv, 'payout < 92 % mais dernier ordre = PERTE → AUCUN switch (attente du gain)');

    // ── 7. WIN forcé → le switch part ──
    console.log(`[7] WIN forcé sur ${secondAsset} → le switch attendu doit partir…`);
    broker.outcomeScriptByAsset[secondAsset] = ['win'];
    let winSettled = false;
    socket.on('trade-closed', (ev) => {
      const asset = ev?.asset ?? ev?.deal?.asset;
      if (asset === secondAsset && ev?.outcome === 'win') winSettled = true;
    });
    const win2Deadline = Date.now() + 120_000;
    while (Date.now() < win2Deadline && !winSettled) await sleep(1000);
    ok(winSettled, `ordre WIN réglé sur ${secondAsset} (dernier ordre = GAIN)`);

    const switch2Deadline = Date.now() + 20_000;
    while (Date.now() < switch2Deadline && !switchEv) await sleep(500);
    ok(!!switchEv, 'switch parti après le GAIN (≤ 20 s)');
    if (switchEv) {
      ok(switchEv.from === secondAsset, `switch part de ${secondAsset} (${switchEv.from})`);
      ok(switchEv.to !== A || true, `cible ${switchEv.to} (payout ${switchEv.payout} %)`);
      ok(switchEv.payout === 92, `payout de la cible == 92 % (obtenu ${switchEv.payout})`);
    }

    // ── 8. Logs backend : la ligne d'attente explicite ──
    await sleep(1000);
    try {
      const logs = fs.readFileSync(logPath, 'utf-8');
      ok(/switch en attente du prochain GAIN/i.test(logs), 'log backend « switch en attente du prochain GAIN » présent pendant la phase bloquée');
      ok(/AUTO-SWITCH\] .*payout 56%/i.test(logs) || /payout 56 %/i.test(logs), 'log backend AUTO-SWITCH avec le payout constaté présent');
    } catch (e) {
      ok(false, `lecture des logs backend impossible (${e.message})`);
    }

    socket.emit('set-auto-trade', { enabled: false });
    console.log('\n[8] BILAN — nouvelle règle Auto Switch validée E2E.');
    cleanupAll(failures > 0 ? 1 : 0);
  })().catch(e => { console.error('FATAL:', e); cleanupAll(1); });
}

main();
