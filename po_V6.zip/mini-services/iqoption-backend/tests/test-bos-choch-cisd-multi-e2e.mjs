/**
 * test-bos-choch-cisd-multi-e2e.mjs — E2E MULTI-ASSETS S5, Martingale BOS.
 * ============================================================================
 * TEST EXIGÉ PAR L'UTILISATEUR — conditions exactes de son environnement :
 *
 *   - IDENTIFIANTS PAR DÉFAUT CODÉS EN DUR dans src/app/page.tsx
 *     (DEFAULT_EMAIL / DEFAULT_PASSWORD) — le login passe par le VRAI
 *     flux HTTP (api/webview/login + cabinet) du backend ;
 *   - 2 ASSETS en mode multi : EURUSD_otc + GBPUSD_otc ;
 *   - TIMEFRAME S5 (candleSize = 5) ;
 *   - Martingale, base 5 $, pertes imposées SUR LES DEUX ASSETS ;
 *   - règlements paresseux (id NUMÉRIQUE ≠ UUID d'ouverture, publication
 *     updateClosedDeals mélangée TOUS assets confondus, fantômes par asset).
 *
 * DEUX CHEMINS DE RÈGLEMENT vérifiés en parallèle :
 *   EURUSD_otc (focus)   → publication broker NORMALE (updateClosedDeals)
 *                          → rattachement par empreinte (deal_closed) ;
 *   GBPUSD_otc           → règlements JAMAIS publiés par le broker (pire
 *     cas réel soupçonné : « la Martingale ne fonctionne que sur un seul
 *     asset ») → le WATCHDOG doit régler chaque deal LOCALEMENT depuis
 *     le flux de ticks (même updateStream que les bougies).
 *
 * Scénario imposé :
 *   EURUSD_otc : LOSS, LOSS, LOSS, WIN, WIN → mises 5,10,20,40,5 puis 5
 *   GBPUSD_otc : LOSS×5 (localement déterminés par le flux de ticks — les
 *     ordres CALL partent à la clôture d'une bougie de signal, l'échéance
 *     tombe sur la bougie suivante en repli) → mises 5,10,20,40,80 puis 160
 *
 * Vérifie AUSSI :
 *   - l'isolation par asset (le WIN de EURUSD ne touche PAS GBPUSD) ;
 *   - expiration de CHAQUE ordre = celle de la RÈGLE (4 s), le champ
 *     global étant piégé à 37 s ;
 *   - le doublement indifférent CALL/PUT (moteur commun, résultat brut) ;
 *   - les fantômes du cache broker ne règlent JAMAIS nos ordres.
 *
 * Exécution : node tests/test-bos-choch-cisd-multi-e2e.mjs
 */
import { spawn } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { io } from 'socket.io-client';
import { MockPoBroker } from './mock-po-broker.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BACKEND_DIR = path.resolve(__dirname, '..');
const BACKEND_PORT = 3030; // socket.io backend (codé en dur dans index.ts)

// ── IDENTIFIANTS PAR DÉFAUT CODÉS EN DUR (src/app/page.tsx) ──────────────
const DEFAULT_EMAIL = 'longuilcn@gmail.com';
const DEFAULT_PASSWORD = 'Jean-Paul@#1964';

const A = 'EURUSD_otc';
const B = 'GBPUSD_otc';
const BASE = 5;
const RULE_EXPIRY = 4;    // expiration de la RÈGLE BOS (jamais le global)
const GLOBAL_EXPIRY = 37; // piège : si le global fuit dans BOS, on le voit
const ROUNDS = 5;

// Pertes imposées PAR ASSET. EURUSD (publication normale) : cycle
// LOSS,LOSS,LOSS,WIN,WIN → mises exactes 5,10,20,40,5. GBPUSD (publication
// SUPPRIMÉE → watchdog local) : ses résultats sont déterminés par le flux
// de ticks (cf. en-tête) ; on vérifie l'INVARIANT de Martingale sur les
// résultats observés dans les logs.
const OUTCOMES_A = ['loss', 'loss', 'loss', 'win', 'win'];
const STAKES_A = [5, 10, 20, 40, 5];
const NEXT_A = [10, 20, 40, 5, 5];

let failures = 0, checks = 0;
function ok(cond, label) {
  checks++;
  if (cond) console.log(`  ✓ ${label}`);
  else { failures++; console.error(`  ✗ ${label}`); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

function main() {
  console.log('\n=== E2E MULTI-ASSETS S5 — Martingale BOS/CHoCH/CISD · identifiants par défaut codés en dur · 2 chemins de règlement (push + watchdog) ===\n');

  const broker = new MockPoBroker({
    httpPort: 4610,             // ports dédiés — aucun conflit avec un
    wsPort: 4611,               // quelconque autre process/.session
    candleSec: 5,               // TIMEFRAME S5 exigé
    settleDelayMs: 2500,
    historyBuckets: 300,
    wickSize: 0.00010,          // mèches réalistes → croisements STRICTS des swings
    outcomeScriptByAsset: { [A]: OUTCOMES_A },
    // PIRE CAS RÉEL : le broker ne publie JAMAIS les règlements de GBPUSD
    // (ni push auto, ni refresh) — seul le watchdog local peut faire
    // avancer sa Martingale.
    suppressSettlementPushFor: [B],
    assets: [
      { symbol: A, startPrice: 1.18000, bodySize: 0.00030, payout: 92 },
      { symbol: B, startPrice: 1.27000, bodySize: 0.00040, payout: 88 },
    ],
  });
  let backend = null;
  let socket = null;

  const cleanupAll = (code) => {
    try {
      if (backend && backend.exitCode === null) {
        try { process.kill(-backend.pid, 'SIGKILL'); }
        catch { try { backend.kill('SIGKILL'); } catch { /* ignore */ } }
      }
    } catch { /* ignore */ }
    try { broker.stop(); } catch { /* ignore */ }
    try { if (socket) socket.close(); } catch { /* ignore */ }
    if (code != null) {
      console.log(`\n=== RÉSULTAT E2E : ${checks - failures}/${checks} vérifications OK ===`);
      process.exit(failures > 0 ? 1 : code);
    }
  };
  process.on('SIGINT', () => cleanupAll(130));
  process.on('uncaughtException', e => { console.error('UNCAUGHT:', e); cleanupAll(1); });

  (async () => {
    // ── 1. Faux broker multi-assets (règlements paresseux, ids numériques) ──
    const ports = await broker.start();
    console.log(`[1] faux broker PO multi-assets démarré (http :${ports.httpPort}, ws :${ports.wsPort}) — règlements de ${B} SUPPRIMÉS (watchdog requis)`);

    // ── 2. VRAI backend, redirigé vers le faux broker ──
    console.log('[2] démarrage du VRAI backend (tsx index.ts)…');
    const backendLogPath = path.join(BACKEND_DIR, 'e2e-bos-multi.log');
    const backendLog = fs.openSync(backendLogPath, 'w');
    backend = spawn('npx', ['tsx', 'index.ts'], {
      cwd: BACKEND_DIR,
      env: {
        ...process.env,
        PO_API_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_WEB_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_DEMO_WS_URL: `ws://127.0.0.1:${ports.wsPort}`,
        SESSION_SNAPSHOT_DIR: '0',
        PO_STARTUP_RANDOM_ASSET: '0',  // v21 — pas de sélection aléatoire 92% au démarrage (test contrôlé)
        // pas de restauration de session
        SOCIAL_DEBUG_PORT: '4410',     // évite tout conflit de port local
        NODE_ENV: 'development',
        // v19 — HORLOGE WATCHDOG COMPRIMÉE pour l'E2E (les défauts
        // production restent 20 s / 45 s côté backend ; ces overrides ne
        // servent qu'à garder ce test sous la limite d'exécution CI de 10 min
        // sans affaiblir CE qu'il valide : isolation multi-assets, règlement
        // watchdog LOCAL de GBPUSD (push supprimé), rattachement par
        // empreinte, Martingale stricte PAR asset [5,10,20,40,5]).
        // L'asset A (push normal ~0,6 s) reste toujours réglé par le broker
        // AVANT tout étage watchdog (tier 1 comprimé = 4 s).
        PO_WATCHDOG_TIER1_MS: '4000',
        PO_WATCHDOG_TIER2_MS: '9000',
      },
      stdio: ['ignore', backendLog, backendLog],
      detached: true,
    });

    let connected = false;
    for (let i = 0; i < 40 && !connected; i++) {
      await sleep(500);
      socket = io(`http://127.0.0.1:${BACKEND_PORT}`, { transports: ['websocket'], path: '/', reconnection: false, timeout: 3000 });
      connected = await new Promise(r => { socket.once('connect', () => r(true)); socket.once('connect_error', () => r(false)); });
      if (!connected) { try { socket.close(); } catch { /* ignore */ } }
    }
    ok(connected, `backend joignable sur :${BACKEND_PORT} (socket.io connecté)`);
    if (!connected) { cleanupAll(1); return; }

    // ── 3. IDENTIFIANTS PAR DÉFAUT CODÉS EN DUR (comme la vraie UI) ──
    console.log(`[3] login démo avec les identifiants par défaut codés en dur (${DEFAULT_EMAIL})…`);
    const loginResult = await new Promise(r => {
      socket.once('login-result', r);
      socket.emit('login', { email: DEFAULT_EMAIL, password: DEFAULT_PASSWORD, mode: 'demo' });
      setTimeout(() => r({ ok: false, error: 'timeout login' }), 30000);
    });
    ok(loginResult?.ok === true, `login OK avec les identifiants par défaut (uid=${loginResult?.user_id ?? '?'})`);
    if (!loginResult?.ok) { console.error('login échoué:', loginResult); cleanupAll(1); return; }

    socket.emit('set-config', { candleSize: 5, cooldownSeconds: 3 });
    await sleep(300);

    // ── 4. SÉLECTION MULTI : 2 ASSETS ──
    const selected = await new Promise(r => {
      socket.once('assets-selected', r);
      socket.emit('select-assets', { mode: 'multi', assets: [A, B] });
      setTimeout(() => r({ ok: false }), 20000);
    });
    ok(selected?.ok === true, `2 assets sélectionnés en mode multi : ${A} + ${B}`);
    await sleep(1500);

    socket.emit('set-auto-strategy', { strategyId: 'l_lucien_protrader' });
    await sleep(200);

    // Martingale + base 5. Le champ global est volontairement 37 s : il ne
    // doit JAMAIS piloter un ordre BOS (les règles portent 4 s).
    socket.emit('set-auto-config', {
      bettingStrategy: 'martingale',
      baseAmount: BASE,
    });
    socket.emit('set-config', { margin: String(BASE), bettingStrategy: 'martingale', cooldownSeconds: 3, expirySeconds: GLOBAL_EXPIRY });
    await sleep(300);

    socket.emit('set-auto-config', {
      bosChochCisdCallRules: [{ id: 'call-bos-up', alerts: ['BOS Up'], expirationSeconds: RULE_EXPIRY }],
      bosChochCisdPutRules: [{ id: 'put-bos-down', alerts: ['BOS Down'], expirationSeconds: RULE_EXPIRY }],
    });
    await sleep(300);

    const autoOn = await new Promise(r => {
      socket.once('auto-trade-status', r);
      socket.emit('set-auto-trade', { enabled: true });
      setTimeout(() => r(null), 10000);
    });
    ok(autoOn && autoOn.enabled !== false, `auto-trade ON (stratégie=${autoOn?.strategyId ?? '?'})`);
    ok(autoOn?.strategyId === 'l_lucien_protrader', `stratégie active = bos_choch_cisd (${autoOn?.strategyId})`);
    ok(autoOn?.bettingStrategy === 'martingale', `mise = martingale (${autoOn?.bettingStrategy})`);

    // ── 5. RONDES DÉTERMINISTES (une par ordre de chaque asset) ──
    // Chaque ronde : auto-trade ON → UN ordre par asset (clôture de bougie)
    // → auto-trade OFF (les deals en vol ne doivent plus générer d'ordres)
    // → attente des règlements des DEUX assets (A : push broker ~7 s ;
    //    B : watchdog local ~50 s) → ronde suivante. La mise de chaque
    // ordre est donc calculée avec l'état Martingale COMPLÈTEMENT à jour.
    console.log(`[5] ${ROUNDS} rondes — ${A} : publication normale · ${B} : règlements supprimés (watchdog local) · règle ${RULE_EXPIRY}s, global piégé ${GLOBAL_EXPIRY}s…`);
    const placed = { [A]: [], [B]: [] };
    let lastStatus = null;
    socket.on('auto-trade-status', (s) => { if (s) lastStatus = s; });
    socket.on('trade-opened', (ev) => {
      if (ev?.source !== 'l_lucien_protrader') return;
      const asset = ev.asset;
      if (asset !== A && asset !== B) return;
      placed[asset].push({ amount: Number(ev.deal?.amount ?? 0), expirationSeconds: Number(ev.expirationSeconds ?? 0), action: ev.deal?.action });
    });

    const settledCount = (asset) => {
      const st = lastStatus?.assets?.[asset]?.stats;
      return (st?.wins ?? 0) + (st?.losses ?? 0);
    };

    for (let round = 0; round < ROUNDS; round++) {
      // 5.a — reprise : UN ordre par asset sur la prochaine clôture de bougie.
      //      Chaque asset est suspendu DÈS que SON ordre arrive (sinon le
      //      plus rapide des deux pourrait re-signaler pendant l'attente du
      //      second). Suspension PAR ASSET : la boucle de stratégie (et donc
      //      le watchdog de règlement de B) CONTINUE de tourner — le toggle
      //      GLOBAL arrêterait la boucle (stopStrategyLoop) et B ne serait
      //      réglé qu'au redémarrage suivant.
      socket.emit('set-auto-trade', { enabled: true });
      const roundDeadline = Date.now() + 90_000;
      const seenThisRound = { [A]: placed[A].length, [B]: placed[B].length };
      while (Date.now() < roundDeadline &&
             (placed[A].length <= seenThisRound[A] || placed[B].length <= seenThisRound[B])) {
        await sleep(100);
        if (placed[A].length > seenThisRound[A]) socket.emit('set-auto-trade', { enabled: false, asset: A });
        if (placed[B].length > seenThisRound[B]) socket.emit('set-auto-trade', { enabled: false, asset: B });
      }
      // 5.b — ceinture+bretelles : les DEUX assets sont suspendus (plus
      //       AUCUN nouvel ordre pendant les règlements, boucle vivante).
      socket.emit('set-auto-trade', { enabled: false, asset: A });
      socket.emit('set-auto-trade', { enabled: false, asset: B });
      if (placed[A].length <= seenThisRound[A] || placed[B].length <= seenThisRound[B]) {
        console.error(`    [r${round + 1}] ATTENTION : ordre manquant (A=${placed[A].length}, B=${placed[B].length})`);
        break;
      }
      const aOrder = placed[A][placed[A].length - 1];
      const bOrder = placed[B][placed[B].length - 1];
      console.log(`    [r${round + 1}] ${A} : ${aOrder.action?.toUpperCase()} ${aOrder.amount}$ · ${B} : ${bOrder.action?.toUpperCase()} ${bOrder.amount}$ (expiration ${aOrder.expirationSeconds}s/${bOrder.expirationSeconds}s)`);

      // 5.c — attente des règlements : A via push broker (~7 s), B via
      //       watchdog local (~50 s après l'échéance de 4 s).
      const target = round + 1;
      const settleDeadline = Date.now() + 150_000;
      while (Date.now() < settleDeadline && (settledCount(A) < target || settledCount(B) < target)) {
        await sleep(2000);
      }
      const stA = lastStatus?.assets?.[A];
      const stB = lastStatus?.assets?.[B];
      console.log(`    [r${round + 1}] réglés : ${A} ${settledCount(A)}/${target} (streak ${stA?.stats?.consecutiveLosses}, prochaine ${stA?.nextBetAmount}$) · ${B} ${settledCount(B)}/${target} (streak ${stB?.stats?.consecutiveLosses}, prochaine ${stB?.nextBetAmount}$)`);
    }
    socket.emit('set-auto-trade', { enabled: false });

    // 5.d — DRAIN FINAL : les règlements watchdog de ${B} ne sont produits QUE
    // par la boucle de stratégie (runMartingaleSettlementWatchdog y est appelé
    // AVANT l'early-return auto-trade OFF). 'start-strategy' relance la boucle
    // SANS placer le moindre ordre → le watchdog termine le dernier règlement.
    if (settledCount(A) < ROUNDS || settledCount(B) < ROUNDS) {
      console.log('    [drain] boucle de stratégie relancée (auto-trade OFF) — le watchdog termine les règlements en retard…');
      socket.emit('start-strategy');
      const drainDeadline = Date.now() + 120_000;
      while (Date.now() < drainDeadline && (settledCount(A) < ROUNDS || settledCount(B) < ROUNDS)) {
        await sleep(2000);
      }
      socket.emit('stop-strategy');
    }
    await sleep(2000);

    // ── 6. VÉRIFICATIONS ──
    console.log('\n[6] vérification de la Martingale MULTI-ASSETS…');
    const stA = lastStatus?.assets?.[A];
    const stB = lastStatus?.assets?.[B];
    const stakesA = placed[A].map(o => o.amount);
    const stakesB = placed[B].map(o => o.amount);
    console.log(`    ${A} — ordres : ${stakesA.join(' → ')} · réglés ${settledCount(A)} (streak ${stA?.stats?.consecutiveLosses}, prochaine ${stA?.nextBetAmount}$)`);
    console.log(`    ${B} — ordres : ${stakesB.join(' → ')} · réglés ${settledCount(B)} (streak ${stB?.stats?.consecutiveLosses}, prochaine ${stB?.nextBetAmount}$)`);
    console.log(`    broker (mock)      : ordres=${broker.stats.orders} réglés=${broker.stats.settled} publiés=${broker.stats.published}`);

    // ── EURUSD (publication normale → rattachement par empreinte) ──
    ok(placed[A].length === ROUNDS, `${A} : exactement ${ROUNDS} ordres BOS placés (${placed[A].length} observés)`);
    ok(stakesA.join(',') === STAKES_A.join(','),
      `${A} : mises placées = 5 → 10 → 20 → 40 → 5 : [${stakesA.join(', ')}]`);
    ok(stA?.nextBetAmount === NEXT_A[NEXT_A.length - 1],
      `${A} : après les 2 WIN finaux, prochaine mise = 5 (base) — obtenu ${stA?.nextBetAmount}`);
    ok(stA?.stats?.consecutiveLosses === 0,
      `${A} : streak final = 0 (dernier ordre = WIN → retour immédiat à la base) — obtenu ${stA?.stats?.consecutiveLosses}`);
    ok((stA?.stats?.wins ?? 0) === 2 && (stA?.stats?.losses ?? 0) === 3,
      `${A} : 2W/3L attribués à SON contexte (${stA?.stats?.wins}W/${stA?.stats?.losses}L)`);

    // ── GBPUSD (règlements JAMAIS publiés → watchdog local) ──
    // INVARIANT de Martingale : mise[0] = base ; après WIN → base ; après
    // LOSS → double de la mise précédente. Les résultats locaux sont lus
    // dans les logs backend ([WATCHDOG] règlement LOCAL … WIN/LOSS).
    const log = fs.readFileSync(backendLogPath, 'utf8');
    const watchdogB = [...log.matchAll(new RegExp(
      `\\[ASSET:${B}\\].*?\\[WATCHDOG\\] règlement LOCAL.*?(WIN ✓|LOSS ✗)`, 'g'))].map(m => m[1]);
    ok(placed[B].length === ROUNDS, `${B} : exactement ${ROUNDS} ordres BOS placés (${placed[B].length} observés)`);
    // TIE EXCEPTION : un deal dont le tick le plus proche de l'échéance porte
    // EXACTEMENT le prix d'entrée n'est JAMAIS réglé localement (le broker
    // reste l'autorité des remboursements à l'égalité — watchdog v3 étage 2).
    // Comme la publication broker de ${B} est SUPPRIMÉE dans ce scénario, un
    // tie reste en attente jusqu'à la purge : le test accepte ROUNDS ou
    // ROUNDS-1 règlements watchdog (les mises restent vérifiées strictement
    // ci-dessous à partir des règlements réellement trouvés).
    ok(watchdogB.length >= ROUNDS - 1,
      `${B} : les règlements sont venus du WATCHDOG local (publication broker supprimée) — ${watchdogB.length} trouvés (tie possible) : [${watchdogB.join(', ')}]`);

    let martingaleOK = placed[B].length === ROUNDS && stakesB[0] === BASE;
    const expectedB = [BASE];
    for (let i = 0; i < ROUNDS - 1 && martingaleOK; i++) {
      const win = watchdogB[i] === 'WIN ✓';
      expectedB.push(win ? BASE : expectedB[expectedB.length - 1] * 2);
    }
    ok(martingaleOK && stakesB.join(',') === expectedB.join(','),
      `${B} : mises = Martingale stricte sur les résultats du watchdog — attendu [${expectedB.join(', ')}], obtenu [${stakesB.join(', ')}]`);
    const winsB = watchdogB.filter(r => r === 'WIN ✓').length;
    const lossesB = watchdogB.filter(r => r === 'LOSS ✗').length;
    ok(stB?.stats?.consecutiveLosses === (watchdogB[watchdogB.length - 1] === 'WIN ✓' ? 0 : lossesB),
      `${B} : streak final cohérent avec les règlements locaux (${stB?.stats?.consecutiveLosses})`);
    ok((stB?.stats?.wins ?? 0) === winsB && (stB?.stats?.losses ?? 0) === lossesB,
      `${B} : ${winsB}W/${lossesB}L attribués à SON contexte (${stB?.stats?.wins}W/${stB?.stats?.losses}L)`);

    // ── Isolation par asset : le WIN de EURUSD n'a PAS touché GBPUSD ──
    // (les 2 WIN de A sont arrivés aux rondes 4 et 5, alors que B enchaînait
    //  ses propres pertes — ses mises n'ont JAMAIS été réinitialisées par A.)
    ok(!stakesB.some(s => s < BASE), `${B} : aucune mise sous la base (${BASE}$) — le WIN de ${A} ne l'a jamais réinitialisé prématurément`);

    // ── Expirations : règle uniquement, pour les DEUX assets ──
    ok([...placed[A], ...placed[B]].every(o => o.expirationSeconds === RULE_EXPIRY),
      `expiration de CHAQUE ordre des 2 assets = ${RULE_EXPIRY}s (règle) — le global ${GLOBAL_EXPIRY}s n'a jamais fuité : [${[...placed[A], ...placed[B]].map(o => o.expirationSeconds).join(', ')}]`);

    // ── Chemin normal : le rattachement par empreinte a bien eu lieu ──
    ok(log.includes('rattaché par empreinte'),
      `${A} : le backend a rattaché les règlements (id numérique ≠ UUID) par empreinte`);
    ok(!/false WIN|ghost settlement/i.test(log), 'aucun règlement fantôme détecté dans les logs backend');

    socket.close();
    cleanupAll(failures > 0 ? 1 : 0);
  })().catch(e => {
    console.error('E2E FATAL:', e);
    cleanupAll(1);
  });
}

// Collecte des ordres (déclarée ici pour être branchée avant les rondes).
// [insérée dynamiquement par le premier appel ci-dessous]

main();
