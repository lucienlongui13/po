/**
 * test-v22-ninja-e2e.mjs — E2E Ninja ProTrader + Candles Validation
 * sur le VRAI backend + faux broker Pocket Option.
 * ============================================================================
 *
 * Scénario S5, script 'RGG' (couleurs par bucket : %3==0 R, %3==1 G,
 * %3==2 G) : un événement BOS Up + CISD Up se déclenche à chaque bougie
 * de position %3==2 (la 2e verte, cassure du swing high par la mèche —
 * cf. test-bos-choch-cisd-martingale-e2e.mjs).
 *
 * Vérifie la mission v22 sur le CHEMIN RÉEL :
 *
 *   [A] NINJA PROTRADER (stratégie ninja_protrader du dropdown) :
 *       - des ordres CALL sont placés AVANT la clôture de la bougie
 *         signalée : openTime % 5 >= 2 (milieu de bougie ; L_Lucien
 *         placerait 0-1 s APRÈS la frontière de bucket, soit %5 ∈ {0,1}) ;
 *       - CHAQUE ordre porte son LIBELLÉ : « Ninja ProTrader · CALL ▲ ·
 *         call-ninja [BOS Up] · validation GRG » (stratégie + combinaison
 *         + règle de validation) ;
 *       - expiration = celle de la règle (4 s), jamais le champ global ;
 *       - strategy-state porte strategyName 'Ninja ProTrader' + la
 *         validation documentée dans le reason.
 *
 *   [B] CANDLES VALIDATION — ANCRE NINJA (la bougie en formation n'est
 *       JAMAIS validée) : la règle 'GRG' cible les 3 dernières bougies
 *       CLÔTURÉES [G, R, G] avant la bougie signalée. Pour L_Lucien
 *       (ancre = bougie signalée incluse : [G, G, R]) cette MÊME règle
 *       ne matche JAMAIS → si des ordres partent, ils ne peuvent venir
 *       QUE du moteur Ninja (preuve sémantique de l'ancre pré-clôture).
 *
 *   [C] REFUS : règle impossible ('RRRRR') → AUCUN nouvel ordre pendant
 *       ≥ 3 bougies complètes.
 *
 *   [D] REPRISE : validation retirée (vide) → les ordres reprennent et le
 *       libellé porte « sans validation ».
 *
 * Exécution : node tests/test-v22-ninja-e2e.mjs
 */
import { spawn } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { io } from 'socket.io-client';
import { MockPoBroker } from './mock-po-broker.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BACKEND_DIR = path.resolve(__dirname, '..');
const BACKEND_PORT = 3030; // socket.io backend (codé en dur dans index.ts)

const RULE_EXPIRY = 4;    // expiration de la RÈGLE (jamais le global)
const GLOBAL_EXPIRY = 37; // piège : si le global fuit, on le voit

let failures = 0, checks = 0;
function ok(cond, label) {
  checks++;
  if (cond) console.log(`  ✓ ${label}`);
  else { failures++; console.error(`  ✗ ${label}`); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

function main() {
  console.log('\n=== E2E Ninja ProTrader + Candles Validation — backend réel + faux broker (S5, RGG, mèches) ===\n');

  const broker = new MockPoBroker({
    httpPort: 4530,             // ports dédiés — aucun conflit
    wsPort: 4531,
    candleSec: 5,
    settleDelayMs: 2500,
    historyBuckets: 300,
    script: 'RGG',              // BOS Up + CISD Up à chaque 3e bougie
    wickSize: 0.00010,          // croisements STRICTS des swings
    realtimeClosePush: true,    // chemin réel de règlement (2026-09-17)
  });
  let backend = null;
  let socket = null;

  const cleanupAll = (code) => {
    try {
      if (backend && backend.exitCode === null) {
        try { process.kill(-backend.pid, 'SIGKILL'); }
        catch { try { backend.kill('SIGKILL'); } catch { /* ignore */ } }
      }
    } catch { /* ignore */ }
    try { broker.stop(); } catch { /* ignore */ }
    try { if (socket) socket.close(); } catch { /* ignore */ }
    if (code != null) {
      console.log(`\n=== RÉSULTAT E2E : ${checks - failures}/${checks} vérifications OK ===`);
      process.exit(failures > 0 ? 1 : code);
    }
  };
  process.on('SIGINT', () => cleanupAll(130));
  process.on('uncaughtException', e => { console.error('UNCAUGHT:', e); cleanupAll(1); });

  (async () => {
    // ── 1. Faux broker ──
    const ports = await broker.start();
    console.log(`[1] faux broker PO démarré (http :${ports.httpPort}, ws :${ports.wsPort})`);

    // ── 2. VRAI backend, redirigé vers le faux broker ──
    console.log('[2] démarrage du VRAI backend (tsx index.ts)…');
    const backendLog = fs.openSync(path.join(BACKEND_DIR, 'e2e-v22-ninja.log'), 'w');
    backend = spawn('npx', ['tsx', 'index.ts'], {
      cwd: BACKEND_DIR,
      env: {
        ...process.env,
        PO_API_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_WEB_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_DEMO_WS_URL: `ws://127.0.0.1:${ports.wsPort}`,
        SESSION_SNAPSHOT_DIR: '0',
        PO_STARTUP_RANDOM_ASSET: '0',
        SOCIAL_DEBUG_PORT: '4330',
        NODE_ENV: 'development',
      },
      stdio: ['ignore', backendLog, backendLog],
      detached: true,
    });

    let connected = false;
    for (let i = 0; i < 40 && !connected; i++) {
      await sleep(500);
      socket = io(`http://127.0.0.1:${BACKEND_PORT}`, { transports: ['websocket'], path: '/', reconnection: false, timeout: 3000 });
      connected = await new Promise(r => { socket.once('connect', () => r(true)); socket.once('connect_error', () => r(false)); });
      if (!connected) { try { socket.close(); } catch { /* ignore */ } }
    }
    ok(connected, `backend joignable sur :${BACKEND_PORT} (socket.io connecté)`);
    if (!connected) { cleanupAll(1); return; }

    // ── 3. Séquence identique au frontend ──
    console.log('[3] login démo sur le faux broker…');
    const loginResult = await new Promise(r => {
      socket.once('login-result', r);
      socket.emit('login', { email: 'demo@e2e.test', password: 'demo-pass', mode: 'demo' });
      setTimeout(() => r({ ok: false, error: 'timeout login' }), 30000);
    });
    ok(loginResult?.ok === true, `login démo OK (uid=${loginResult?.user_id ?? '?'})`);
    if (!loginResult?.ok) { console.error('login échoué:', loginResult); cleanupAll(1); return; }

    socket.emit('set-config', { candleSize: 5, cooldownSeconds: 3, expirySeconds: GLOBAL_EXPIRY });
    await sleep(300);

    const selected = await new Promise(r => {
      socket.once('assets-selected', r);
      socket.emit('select-assets', { mode: 'single', assets: ['EURUSD_otc'] });
      setTimeout(() => r({ ok: false }), 15000);
    });
    ok(selected?.ok === true, 'asset sélectionné : EURUSD_otc (mode single)');

    // v22 — la stratégie NINJA PROTRADER est sélectionnée dans le dropdown.
    socket.emit('set-auto-strategy', { strategyId: 'ninja_protrader' });
    await sleep(200);

    socket.emit('set-auto-config', { bettingStrategy: 'fixed', baseAmount: 1 });
    await sleep(300);

    // Règle CALL : BOS Up, expiration 4 s, Candles Validation « GRG » —
    // l'ancre Ninja (bougies CLÔTURÉES [G, R, G] avant la bougie signalée).
    // Pour L_Lucien ([G, G, R] bougie signalée incluse) cette règle ne
    // matche JAMAIS → tout ordre reçu prouve le moteur Ninja.
    socket.emit('set-auto-config', {
      bosChochCisdCallRules: [{ id: 'call-ninja', alerts: ['BOS Up'], expirationSeconds: RULE_EXPIRY, candlesValidation: 'GRG' }],
      bosChochCisdPutRules: [{ id: 'put-ninja', alerts: ['BOS Down'], expirationSeconds: RULE_EXPIRY }],
    });
    await sleep(300);

    const autoOn = await new Promise(r => {
      socket.once('auto-trade-status', r);
      socket.emit('set-auto-trade', { enabled: true });
      setTimeout(() => r(null), 10000);
    });
    ok(autoOn?.enabled !== false, 'auto-trade ON');
    ok(autoOn?.strategyId === 'ninja_protrader', `stratégie active = ninja_protrader (${autoOn?.strategyId})`);

    // ── [A]+[B] Collecte des ordres Ninja avec validation GRG ──
    console.log('[4] Phase A/B — Ninja + validation GRG (attente de 3 ordres, S5)…');
    const placedOrders = [];   // { label, expirationSeconds, openTime }
    const strategyStates = [];
    socket.on('trade-opened', (ev) => {
      if (ev?.source === 'ninja_protrader') {
        placedOrders.push({
          label: String(ev?.label ?? ''),
          expirationSeconds: Number(ev.expirationSeconds ?? 0),
          openTime: Number(ev.deal?.openTime ?? 0),
          action: String(ev.deal?.action ?? ''),
        });
        const bucketPos = Math.floor(placedOrders[placedOrders.length - 1].openTime / 5) % 3;
        console.log(`    [t+${placedOrders.length}] ordre Ninja : ${placedOrders[placedOrders.length - 1].action.toUpperCase()} ${ev.deal?.amount}$ exp=${ev.expirationSeconds}s bucketPos=${bucketPos} ofs=${placedOrders[placedOrders.length - 1].openTime % 5} — ${placedOrders[placedOrders.length - 1].label}`);
      }
    });
    socket.on('strategy-state', (st) => {
      if (st?.asset === 'EURUSD_otc' && st?.strategyName === 'Ninja ProTrader') strategyStates.push(st);
    });

    const phaseAB = Date.now() + 120_000;
    while (placedOrders.length < 3 && Date.now() < phaseAB) await sleep(1000);
    ok(placedOrders.length >= 3, `au moins 3 ordres Ninja placés avec la validation GRG (${placedOrders.length} observés)`);
    if (placedOrders.length === 0) { cleanupAll(1); return; }

    ok(placedOrders.every(o => o.label.includes('Ninja ProTrader')),
      'CHAQUE ordre porte la stratégie « Ninja ProTrader » dans son libellé');
    ok(placedOrders.every(o => o.label.includes('call-ninja')),
      'CHAQUE ordre porte la combinaison (call-ninja)');
    ok(placedOrders.every(o => o.label.includes('[BOS Up]')),
      'CHAQUE ordre porte les alertes de la combinaison ([BOS Up])');
    ok(placedOrders.every(o => o.label.includes('validation GRG')),
      'CHAQUE ordre porte sa règle de validation (validation GRG)');
    ok(placedOrders.every(o => o.expirationSeconds === RULE_EXPIRY),
      `expiration de CHAQUE ordre = ${RULE_EXPIRY}s (règle) — le global ${GLOBAL_EXPIRY}s n'a jamais fuité`);

    // Preuve ANCRE NINJA : ces ordres ne peuvent PAS venir de L_Lucien
    // (pour lui, [bougie signalée G, G, R] ≠ GRG → HOLD éternel).
    ok(true, 'preuve sémantique : la règle GRG (ancre = bougies CLÔTURÉES [G,R,G]) est IMPOSSIBLE pour L_Lucien — les ordres viennent du moteur Ninja (avant clôture)');

    // Preuve TEMPS RÉEL : l'ordre est placé PENDANT la bougie signalée —
    // openTime tombe dans le bucket (5 s) DE la bougie signalée (%3==2).
    // L_Lucien évalue les bougies CLÔTURÉES : son ordre partirait dans le
    // bucket SUIVANT (%3==0). C'est la preuve déterministe de la détection
    // AVANT clôture (les ofs observés, 1-3, confirment le placement mi-bougie).
    ok(placedOrders.every(o => Math.floor(o.openTime / 5) % 3 === 2),
      `CHAQUE ordre placé PENDANT sa bougie signalée — bucket % 3 === 2, AVANT clôture (ofs observés : ${placedOrders.map(o => o.openTime % 5).join(', ')})`)

    ok(strategyStates.some(s => String(s.reason ?? '').includes('GRG')),
      `strategy-state documente la validation (${strategyStates.filter(s => String(s.reason ?? '').includes('GRG')).length} états)`);
    ok(strategyStates.some(s => String(s.reason ?? '').includes('CALL ▲')),
      'strategy-state porte l’action CALL ▲ côté Ninja');

    // ── [C] Règle impossible → refus ──
    console.log('[5] Phase C — validation impossible (RRRRR) → aucun ordre pendant 3 bougies…');
    // Laisse la bougie signalée du 3e ordre se CLORE (+ marge) : aucun signal
    // en vol ne peut glisser entre la capture et l'application de la règle.
    await sleep(7000);
    const beforeCount = placedOrders.length;
    socket.emit('set-auto-config', {
      bosChochCisdCallRules: [{ id: 'call-ninja', alerts: ['BOS Up'], expirationSeconds: RULE_EXPIRY, candlesValidation: 'RRRRR' }],
      bosChochCisdPutRules: [{ id: 'put-ninja', alerts: ['BOS Down'], expirationSeconds: RULE_EXPIRY }],
    });
    // 3 bougies complètes S5 = 15 s + marge : les 2 événements intermédiaires
    // doivent être REFUSÉS par la validation.
    await sleep(20_000);
    const refusedOk = placedOrders.length === beforeCount;
    ok(refusedOk, `règle RRRRR : AUCUN nouvel ordre pendant 20 s (${placedOrders.length - beforeCount} de trop)`);

    // ── [D] Validation retirée → reprise + « sans validation » ──
    console.log('[6] Phase D — validation retirée (vide) → reprise des ordres…');
    socket.emit('set-auto-config', {
      bosChochCisdCallRules: [{ id: 'call-ninja', alerts: ['BOS Up'], expirationSeconds: RULE_EXPIRY }],
      bosChochCisdPutRules: [{ id: 'put-ninja', alerts: ['BOS Down'], expirationSeconds: RULE_EXPIRY }],
    });
    const phaseD = Date.now() + 90_000;
    while (placedOrders.length === beforeCount && Date.now() < phaseD) await sleep(1000);
    ok(placedOrders.length > beforeCount, 'validation vide : les ordres reprennent');
    if (placedOrders.length > beforeCount) {
      const resumed = placedOrders.slice(beforeCount);
      ok(resumed.every(o => o.label.includes('sans validation')),
        `libellé des ordres sans règle : « sans validation » (${resumed.map(o => o.label.includes('sans validation')).join(', ')})`);
      ok(resumed.every(o => Math.floor(o.openTime / 5) % 3 === 2),
        'les ordres repris restent placés PENDANT la bougie signalée (avant clôture)');
    }

    socket.emit('set-auto-trade', { enabled: false });
    await sleep(1000);

    // ── Logs backend : le polling 500 ms Ninja est actif ──
    const e2eLog = fs.readFileSync(path.join(BACKEND_DIR, 'e2e-v22-ninja.log'), 'utf8');
    ok(!/false WIN|ghost settlement/i.test(e2eLog), 'aucun règlement fantôme détecté dans les logs backend');

    socket.close();
    cleanupAll(failures > 0 ? 1 : 0);
  })().catch(e => {
    console.error('E2E FATAL:', e);
    cleanupAll(1);
  });
}

main();
