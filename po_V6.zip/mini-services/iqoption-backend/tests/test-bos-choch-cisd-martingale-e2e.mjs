/**
 * test-bos-choch-cisd-martingale-e2e.mjs — E2E Martingale Auto Trade/BOS
 * sur le VRAI backend + faux broker Pocket Option.
 * ============================================================================
 *
 * Reproduit le bug utilisateur « la Martingale ne repart jamais à la mise
 * initiale dans BOS, CHoCH & CISD après un gain » sur le CHEMIN RÉEL :
 *
 *   règle BOS (S5, RGG → BOS Up + CISD Up toutes les 3 bougies)
 *     → calcul mise (martingale, base 5)
 *     → openOrder() broker (UUID d'ouverture)
 *     → règlement à l'échéance : id NUMÉRIQUE ≠ UUID + publication
 *       PARESSEUSE via updateClosedDeals (+ fantômes permanents injectés)
 *     → deal_closed → rattachement → applyDealResult → updateBettingAfterResult
 *     → prochaine mise.
 *
 * Résultats imposés (outcomeScript) : LOSS, LOSS, LOSS, WIN, WIN, LOSS
 *   → mises placées  : 5, 10, 20, 40, 5, 5
 *   → prochaine mise après chaque règlement : 10, 20, 40, 5, 5, 10
 *   c'est-à-dire la séquence OBLIGATOIRE : 5 → 10 → 20 → 40 → 5 → 5 → 10.
 *
 * Vérifie AUSSI :
 *   - l'expiration de CHAQUE ordre = celle de la RÈGLE (4 s) alors que le
 *     champ global Auto Trade est fixé à 37 s (aucune fuite du global) ;
 *   - l'attribution : le 6e deal BOS est réglé ALORS QUE l'UI a demandé une
 *     stratégie INCONNUE (rejetée par le backend — la stratégie reste
 *     L_Lucien ProTrader) — la Martingale doit quand même avancer ;
 *   - l'isolation : aucun deal d'un autre asset, pas de règlement fantôme.
 *
 * Exécution : node tests/test-bos-choch-cisd-martingale-e2e.mjs
 */
import { spawn } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { io } from 'socket.io-client';
import { MockPoBroker } from './mock-po-broker.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BACKEND_DIR = path.resolve(__dirname, '..');
const BACKEND_PORT = 3030; // socket.io backend (codé en dur dans index.ts)

const BASE = 5;
const RULE_EXPIRY = 4;   // expiration de la RÈGLE BOS (jamais le global)
const GLOBAL_EXPIRY = 37; // piège : si le global fuit dans BOS, on le voit
const EXPECTED_STAKES = [5, 10, 20, 40, 5, 5];
const EXPECTED_NEXT = [10, 20, 40, 5, 5, 10];
const OUTCOMES = ['loss', 'loss', 'loss', 'win', 'win', 'loss'];

let failures = 0, checks = 0;
function ok(cond, label) {
  checks++;
  if (cond) console.log(`  ✓ ${label}`);
  else { failures++; console.error(`  ✗ ${label}`); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

function main() {
  console.log('\n=== E2E Martingale BOS/CHoCH/CISD — backend réel + faux broker (S5, ids numériques ≠ UUID, règlements lazy) ===\n');

  const broker = new MockPoBroker({
    httpPort: 4510,             // ports dédiés — aucun conflit avec un
    wsPort: 4511,              // quelconque autre process/.session
    candleSec: 5,
    settleDelayMs: 2500,
    historyBuckets: 300,
    script: 'RGG',                    // BOS Up + CISD Up toutes les 3 bougies
    outcomeScript: OUTCOMES,          // résultats imposés dans l'ordre
    wickSize: 0.00010,                // mèches réalistes → croisements STRICTS des swings
    // CAPTURE RÉELLE 2026-09-17 : le broker pousse chaque règlement en temps
    // réel via successcloseOrder { profit: <retour total>, deals: [deal
    // natif UUID/command/timestamps] } — le chemin principal du vrai broker.
    // En plus du cache updateClosedDeals lazy (ids numériques ≠ UUID).
    realtimeClosePush: true,
  });
  let backend = null;
  let socket = null;

  const cleanupAll = (code) => {
    try {
      if (backend && backend.exitCode === null) {
        try { process.kill(-backend.pid, 'SIGKILL'); }
        catch { try { backend.kill('SIGKILL'); } catch { /* ignore */ } }
      }
    } catch { /* ignore */ }
    try { broker.stop(); } catch { /* ignore */ }
    try { if (socket) socket.close(); } catch { /* ignore */ }
    if (code != null) {
      console.log(`\n=== RÉSULTAT E2E : ${checks - failures}/${checks} vérifications OK ===`);
      process.exit(failures > 0 ? 1 : code);
    }
  };
  process.on('SIGINT', () => cleanupAll(130));
  process.on('uncaughtException', e => { console.error('UNCAUGHT:', e); cleanupAll(1); });

  (async () => {
    // ── 1. Faux broker (règlements paresseux, ids numériques, fantômes) ──
    const ports = await broker.start();
    console.log(`[1] faux broker PO démarré (http :${ports.httpPort}, ws :${ports.wsPort})`);

    // ── 2. VRAI backend, redirigé vers le faux broker ──
    console.log('[2] démarrage du VRAI backend (tsx index.ts)…');
    const backendLog = fs.openSync(path.join(BACKEND_DIR, 'e2e-bos-martingale.log'), 'w');
    backend = spawn('npx', ['tsx', 'index.ts'], {
      cwd: BACKEND_DIR,
      env: {
        ...process.env,
        PO_API_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_WEB_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_DEMO_WS_URL: `ws://127.0.0.1:${ports.wsPort}`,
        SESSION_SNAPSHOT_DIR: '0',
        PO_STARTUP_RANDOM_ASSET: '0',  // v21 — pas de sélection aléatoire 92% au démarrage (test contrôlé)
        // pas de restauration de session
        SOCIAL_DEBUG_PORT: '4310',     // évite tout conflit de port local
        NODE_ENV: 'development',
      },
      stdio: ['ignore', backendLog, backendLog],
      detached: true,
    });

    let connected = false;
    for (let i = 0; i < 40 && !connected; i++) {
      await sleep(500);
      socket = io(`http://127.0.0.1:${BACKEND_PORT}`, { transports: ['websocket'], path: '/', reconnection: false, timeout: 3000 });
      connected = await new Promise(r => { socket.once('connect', () => r(true)); socket.once('connect_error', () => r(false)); });
      if (!connected) { try { socket.close(); } catch { /* ignore */ } }
    }
    ok(connected, `backend joignable sur :${BACKEND_PORT} (socket.io connecté)`);
    if (!connected) { cleanupAll(1); return; }

    // ── 3. Séquence identique au frontend ──
    console.log('[3] login démo sur le faux broker…');
    const loginResult = await new Promise(r => {
      socket.once('login-result', r);
      socket.emit('login', { email: 'demo@e2e.test', password: 'demo-pass', mode: 'demo' });
      setTimeout(() => r({ ok: false, error: 'timeout login' }), 30000);
    });
    ok(loginResult?.ok === true, `login démo OK (uid=${loginResult?.user_id ?? '?'})`);
    if (!loginResult?.ok) { console.error('login échoué:', loginResult); cleanupAll(1); return; }

    socket.emit('set-config', { candleSize: 5, cooldownSeconds: 3 });
    await sleep(300);

    const selected = await new Promise(r => {
      socket.once('assets-selected', r);
      socket.emit('select-assets', { mode: 'single', assets: ['EURUSD_otc'] });
      setTimeout(() => r({ ok: false }), 15000);
    });
    ok(selected?.ok === true, 'asset sélectionné : EURUSD_otc (mode single)');

    socket.emit('set-auto-strategy', { strategyId: 'l_lucien_protrader' });
    await sleep(200);

    // Martingale + base 5. Le champ global est volontairement 37 s : il ne
    // doit JAMAIS piloter un ordre BOS (les règles portent 4 s).
    socket.emit('set-auto-config', {
      bettingStrategy: 'martingale',
      baseAmount: BASE,
    });
    socket.emit('set-config', { margin: String(BASE), bettingStrategy: 'martingale', cooldownSeconds: 3, expirySeconds: GLOBAL_EXPIRY });
    await sleep(300);

    socket.emit('set-auto-config', {
      bosChochCisdCallRules: [{ id: 'call-bos-up', alerts: ['BOS Up'], expirationSeconds: RULE_EXPIRY }],
      bosChochCisdPutRules: [{ id: 'put-bos-down', alerts: ['BOS Down'], expirationSeconds: RULE_EXPIRY }],
    });
    await sleep(300);

    const autoOn = await new Promise(r => {
      socket.once('auto-trade-status', r);
      socket.emit('set-auto-trade', { enabled: true });
      setTimeout(() => r(null), 10000);
    });
    ok(autoOn && autoOn.enabled !== false, `auto-trade ON (stratégie=${autoOn?.strategyId ?? '?'})`);
    ok(autoOn?.strategyId === 'l_lucien_protrader', `stratégie active = l_lucien_protrader (${autoOn?.strategyId})`);
    ok(autoOn?.bettingStrategy === 'martingale', `mise = martingale (${autoOn?.bettingStrategy})`);

    // ── 4. Collecte des ordres + règlements ──
    // Séquençage STRICT du scénario obligatoire : chaque mise suivante doit
    // être calculée APRÈS la résolution du trade précédent ("le retour à la
    // mise initiale doit être effectué immédiatement après la résolution
    // gagnante du trade, avant le calcul de la prochaine mise"). L'auto-trade
    // est donc suspendu pendant le vol de chaque deal — le règlement broker
    // (id numérique ≠ UUID, publication lazy) est traité par deal_closed,
    // PUIS l'auto-trade reprend et la prochaine mise reflète le résultat.
    console.log(`[4] trading — ${OUTCOMES.join(', ')} imposés (S5, règle ${RULE_EXPIRY}s, global ${GLOBAL_EXPIRY}s, règlements lazy)…`);
    /** Ordres réellement placés : [{ amount, expirationSeconds }] */
    const placedOrders = [];
    /** Dernier statut auto-trade reçu (focus EURUSD_otc). */
    let lastStatus = null;
    socket.on('auto-trade-status', (s) => { if (s) lastStatus = s; });
    socket.on('trade-opened', (ev) => {
      if (ev?.source === 'l_lucien_protrader') {
        placedOrders.push({ amount: Number(ev.deal?.amount ?? 0), expirationSeconds: Number(ev.expirationSeconds ?? 0) });
        console.log(`    [t+${placedOrders.length}] ordre BOS #${placedOrders.length} : ${ev.deal?.action?.toUpperCase()} ${ev.deal?.amount}$ expiration=${ev.expirationSeconds}s (deal ${String(ev.deal?.id).slice(0, 8)}…)`);
        // Suspend l'auto-trade : le deal en vol doit être RÉGLÉ avant le
        // calcul de la prochaine mise (séquence du scénario obligatoire).
        socket.emit('set-auto-trade', { enabled: false });
      }
    });

    // Attends chaque ordre + son règlement traité (mise suivante = EXPECTED_NEXT[i]).
    const nextAfterSettlement = [];
    const deadline = Date.now() + 420_000;
    for (let i = 0; i < EXPECTED_STAKES.length; i++) {
      // 4.a — l'ordre i est placé
      while (placedOrders.length <= i) {
        if (Date.now() > deadline) break;
        await sleep(500);
      }
      if (placedOrders.length <= i) break;
      // 4.b — pendant que le DERNIER deal vole, change de stratégie UI
      //       (test d'attribution §21 : le règlement ne doit PAS être ignoré).
      if (i === EXPECTED_STAKES.length - 1) {
        // Stratégie unique : on vérifie qu'une demande de stratégie INCONNUE
        // est REJETÉE (l'active reste L_Lucien ProTrader) et que le règlement
        // du deal en vol est quand même attribué (fingerprint, pas strategyId).
        socket.emit('set-auto-strategy', { strategyId: 'removed_strategy' }); // rejetée par le backend
        await sleep(300);
        console.log(`    [attribution] stratégie inconnue demandée pendant le vol du deal #${i + 1} (rejet attendu)`);
      }
      // 4.c — le règlement est publié (lazy) puis traité : la prochaine mise
      //       calculée devient EXPECTED_NEXT[i].
      const target = EXPECTED_NEXT[i];
      let settled = false;
      const settleDeadline = Date.now() + 90_000;
      while (Date.now() < settleDeadline) {
        await sleep(1000);
        const nextBet = lastStatus?.nextBetAmount;
        if (typeof nextBet === 'number' && nextBet === target &&
            (lastStatus?.stats?.consecutiveLosses ?? -1) === (OUTCOMES[i] === 'win' ? 0 : i === 5 ? 1 : i + 1)) {
          settled = true;
          break;
        }
      }
      nextAfterSettlement.push(settled ? target : (lastStatus?.nextBetAmount ?? null));
      console.log(`    [t+${i + 1}] règlement ${OUTCOMES[i].toUpperCase()} traité → prochaine mise ${lastStatus?.nextBetAmount}$ (streak ${lastStatus?.stats?.consecutiveLosses})`);
      // 4.d — reprise de l'auto-trade : la prochaine mise part du résultat.
      if (i < EXPECTED_STAKES.length - 1) {
        socket.emit('set-auto-trade', { enabled: true });
      }
    }

    // Drain final : plus aucun ordre ne doit partir.
    await sleep(3000);
    socket.emit('set-auto-trade', { enabled: false });

    // ── 5. VÉRIFICATIONS ──
    console.log('\n[5] vérification de la séquence Martingale réelle…');
    console.log(`    ordres placés      : ${placedOrders.map(o => o.amount).join(' → ')}`);
    console.log(`    prochaines mises   : ${nextAfterSettlement.join(' → ')}`);
    console.log(`    broker (mock)      : ordres=${broker.stats.orders} réglés=${broker.stats.settled} publiés=${broker.stats.published}`);
    console.log(`    fantômes injectés  : ${(broker.ghosts ?? []).length} (deals étrangers permanents)`);

    ok(placedOrders.length === EXPECTED_STAKES.length,
      `exactement ${EXPECTED_STAKES.length} ordres BOS placés (${placedOrders.length} observés)`);
    ok(placedOrders.every((o, i) => o.amount === EXPECTED_STAKES[i]),
      `mises placées = 5 → 10 → 20 → 40 → 5 → 5 : [${placedOrders.map(o => o.amount).join(', ')}]`);
    ok(nextAfterSettlement.every((v, i) => v === EXPECTED_NEXT[i]),
      `prochaines mises après règlement = 10 → 20 → 40 → 5 → 5 → 10 : [${nextAfterSettlement.join(', ')}]`);
    ok(placedOrders.every(o => o.expirationSeconds === RULE_EXPIRY),
      `expiration de CHAQUE ordre = ${RULE_EXPIRY}s (règle) — le global ${GLOBAL_EXPIRY}s n'a jamais fuité : [${placedOrders.map(o => o.expirationSeconds).join(', ')}]`);

    // Séquence complète obligatoire : mises placées + prochaine mise finale.
    const fullSeq = [...placedOrders.map(o => o.amount), nextAfterSettlement[nextAfterSettlement.length - 1]];
    ok(fullSeq.join(',') === '5,10,20,40,5,5,10',
      `SÉQUENCE OBLIGATOIRE 5 → 10 → 20 → 40 → 5 → 5 → 10 : ${fullSeq.join(' → ')}`);

    // Le WIN a bien remis la série à zéro (bug utilisateur).
    ok(lastStatus?.stats?.consecutiveLosses === 1,
      `streak final = 1 (dernier LOSS attribué au deal BOS malgré la demande de stratégie inconnue) — obtenu ${lastStatus?.stats?.consecutiveLosses}`);
    ok(typeof lastStatus?.nextBetAmount === 'number' && lastStatus.nextBetAmount === 10,
      `prochaine mise finale = 10 (base 5 après 1 perte)`);

    // Attribution : le 6e règlement a été traité alors qu'une stratégie
    // inconnue avait été demandée (rejetée — l'active n'a jamais changé).
    ok(nextAfterSettlement[5] === 10 && lastStatus?.strategyId === 'l_lucien_protrader',
      `le deal BOS #6 a été réglé et attribué, la stratégie active reste L_Lucien ProTrader (prochaine mise 10)`);

    // Aucune fuite : le global expirySeconds est resté 37 côté config.
    ok(lastStatus?.fixedExpirySeconds === GLOBAL_EXPIRY,
      `le champ global Auto Trade reste ${GLOBAL_EXPIRY}s (inchangé, non utilisé par BOS)`);

    // Logs backend : avec realtimeClosePush (chemin réel 2026-09-17), le
    // règlement porte l'UUID d'ouverture → attribution DIRECTE (deal_closed
    // → applyDealResult sans empreinte). Sans realtime push (cache lazy à
    // ids numériques ≠ UUID), c'est le rattachement par EMPREINTE qui doit
    // apparaître. Les DEUX chemins font avancer la Martingale correctement.
    const e2eLog = fs.readFileSync(path.join(BACKEND_DIR, 'e2e-bos-martingale.log'), 'utf8');
    ok(e2eLog.includes('rattaché par empreinte') || /deal #\S+ (WIN ✓|LOSS ✗) — stats/.test(e2eLog),
      'le backend a bien traité les règlements (attribution directe UUID ou rattachement par empreinte)');
    ok(!/false WIN|ghost settlement/i.test(e2eLog), 'aucun règlement fantôme détecté dans les logs backend');

    socket.close();
    cleanupAll(failures > 0 ? 1 : 0);
  })().catch(e => {
    console.error('E2E FATAL:', e);
    cleanupAll(1);
  });
}

main();
