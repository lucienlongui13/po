/**
 * test-v26-candle-rules-e2e.mjs — E2E v26 : règles CANDLE (73 patterns)
 * sur le VRAI backend + faux broker Pocket Option.
 * ============================================================================
 *
 * Géométrie (pathScript + gapScript, 12 buckets cyclés, bodySize 0.003) :
 *   pos 0..6 : déclin avec swing lows 107.8→110.5 (structure ut) ;
 *   pos 6    : petite rouge (corps 0.05) ;
 *   pos 7    : VERTE ENGLOBANTE avec GAP D'OUVERTURE (−0.1) cassant le
 *              swing high → BOS Up + CISD Up + BULLISH ENGULFING (le
 *              moteur candle détecte sur la bougie clôturée) ;
 *   pos 8..11: déclin (le cycle est NET baissier → SMA14 < SMA50,
 *              contexte dnTrend requis par l'engulfing).
 *
 * Vérifie la mission v26 sur le CHEMIN RÉEL :
 *
 *   [A] L_LUCIEN PROTRADER — règle MIXTE CALL [BOS Up + Bullish
 *       Engulfing] expiration 4 s :
 *       - ≥ 2 ordres CALL placés, libellé « call-eng [BOS Up + Bullish
 *         Engulfing] » + « EXP 4s » ;
 *       - règle PUT [BOS Down + Bearish Engulfing] : 0 ordre (miroir
 *         jamais déclenché sur cette géométrie) ;
 *       - AUCUN ordre depuis la bougie NON-engulfing (AND, pas OR).
 *
 *   [B] §37 NÉGATIF — la règle CALL passe à [BOS Up + Hammer] (le Hammer
 *       ne se déclenche JAMAIS sur cette géométrie) : AUCUN nouvel ordre
 *       pendant > 1 cycle complet (75 s) — l'absence d'UNE seule
 *       condition bloque l'ordre (logique AND stricte).
 *
 *   [C] §38 NINJA PROTRADER — règle CANDLE PURE [bullish_engulfing]
 *       (clés ninja* — règles PROPRES à Ninja §31) : ordre placé PENDANT
 *       la bougie en formation (openTime % 5 ≥ 1 — détection avant
 *       clôture, §7) avec le libellé « Bullish Engulfing ».
 *
 * Exécution : node tests/test-v26-candle-rules-e2e.mjs
 */
import { spawn } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { io } from 'socket.io-client';
import { MockPoBroker } from './mock-po-broker.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BACKEND_DIR = path.resolve(__dirname, '..');
const BACKEND_PORT = 3030;

const RULE_EXPIRY = 4;
const GLOBAL_EXPIRY = 37; // piège : si le global fuit, on le voit

/* Géométrie cyclée (multiplicateurs × bodySize) — cf. en-tête.
 * NOTE bougies CONSTRUITES : le 1er tick du mock part à 25 % du corps →
 * l'open construit d'une verte = open + 0.25×corps. Le gap d'ouverture
 * (−0.6 sur la position 7) garantit l'engulfing STRICT sur les bougies
 * construites : open_construit (O7+0.375) < close précédent (C6). */
const PATH_SCRIPT = [-1, 0.5, -1, 0.7, -0.2, 0.5, -0.05, 1.5, -1, 0.3, -1, 0.5];
const GAP_SCRIPT = [0, 0, 0, 0, 0, 0, 0, -0.6, 0, 0, 0, 0];

let failures = 0, checks = 0;
function ok(cond, label) {
  checks++;
  if (cond) console.log(`  ✓ ${label}`);
  else { failures++; console.error(`  ✗ ${label}`); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

function main() {
  console.log('\n=== E2E v26 — règles candle 73 patterns · backend réel + faux broker (S5, path+gap) ===\n');

  const broker = new MockPoBroker({
    httpPort: 4560,
    wsPort: 4561,
    candleSec: 5,
    settleDelayMs: 2500,
    historyBuckets: 300,
    bodySize: 0.00300,
    wickSize: 0.00100,
    pathScript: PATH_SCRIPT,
    gapScript: GAP_SCRIPT,
    realtimeClosePush: true,
  });
  let backend = null;
  let socket = null;

  const cleanupAll = (code) => {
    try {
      if (backend && backend.exitCode === null) {
        try { process.kill(-backend.pid, 'SIGKILL'); }
        catch { try { backend.kill('SIGKILL'); } catch { /* ignore */ } }
      }
    } catch { /* ignore */ }
    try { broker.stop(); } catch { /* ignore */ }
    try { if (socket) socket.close(); } catch { /* ignore */ }
    if (code != null) {
      console.log(`\n=== RÉSULTAT E2E : ${checks - failures}/${checks} vérifications OK ===`);
      process.exit(failures > 0 ? 1 : code);
    }
  };
  process.on('SIGINT', () => cleanupAll(130));
  process.on('uncaughtException', e => { console.error('UNCAUGHT:', e); cleanupAll(1); });

  (async () => {
    // ── 1. Faux broker (pathScript + gapScript → engulfing cyclique) ──
    const ports = await broker.start();
    console.log(`[1] faux broker PO démarré (http :${ports.httpPort}, ws :${ports.wsPort})`);

    // ── 2. VRAI backend ──
    console.log('[2] démarrage du VRAI backend (tsx index.ts)…');
    const backendLog = fs.openSync(path.join(BACKEND_DIR, 'e2e-v26-candle.log'), 'w');
    backend = spawn('npx', ['tsx', 'index.ts'], {
      cwd: BACKEND_DIR,
      env: {
        ...process.env,
        PO_API_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_WEB_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_DEMO_WS_URL: `ws://127.0.0.1:${ports.wsPort}`,
        SESSION_SNAPSHOT_DIR: '0',
        PO_STARTUP_RANDOM_ASSET: '0',
        SOCIAL_DEBUG_PORT: '4331',
        NODE_ENV: 'development',
      },
      stdio: ['ignore', backendLog, backendLog],
      detached: true,
    });

    let connected = false;
    for (let i = 0; i < 40 && !connected; i++) {
      await sleep(500);
      socket = io(`http://127.0.0.1:${BACKEND_PORT}`, { transports: ['websocket'], path: '/', reconnection: false, timeout: 3000 });
      connected = await new Promise(r => { socket.once('connect', () => r(true)); socket.once('connect_error', () => r(false)); });
      if (!connected) { try { socket.close(); } catch { /* ignore */ } }
    }
    ok(connected, `backend joignable sur :${BACKEND_PORT} (socket.io connecté)`);
    if (!connected) { cleanupAll(1); return; }

    // ── 3. Séquence identique au frontend ──
    console.log('[3] login démo sur le faux broker…');
    const loginResult = await new Promise(r => {
      socket.once('login-result', r);
      socket.emit('login', { email: 'demo@e2e.test', password: 'demo-pass', mode: 'demo' });
      setTimeout(() => r({ ok: false, error: 'timeout login' }), 30000);
    });
    ok(loginResult?.ok === true, `login démo OK (uid=${loginResult?.user_id ?? '?'})`);
    if (!loginResult?.ok) { console.error('login échoué:', loginResult); cleanupAll(1); return; }

    socket.emit('set-config', { candleSize: 5, cooldownSeconds: 3, expirySeconds: GLOBAL_EXPIRY });
    await sleep(300);

    const selected = await new Promise(r => {
      socket.once('assets-selected', r);
      socket.emit('select-assets', { mode: 'single', assets: ['EURUSD_otc'] });
      setTimeout(() => r({ ok: false }), 15000);
    });
    ok(selected?.ok === true, 'asset sélectionné : EURUSD_otc (mode single)');

    // [A] L_Lucien + règle MIXTE BOS Up + Bullish Engulfing.
    socket.emit('set-auto-strategy', { strategyId: 'l_lucien_protrader' });
    await sleep(200);
    socket.emit('set-auto-config', { bettingStrategy: 'fixed', baseAmount: 1 });
    await sleep(300);
    socket.emit('set-auto-config', {
      bosChochCisdCallRules: [{ id: 'call-eng', alerts: ['BOS Up', 'bullish_engulfing'], expirationMode: 'seconds', expirationSeconds: RULE_EXPIRY }],
      bosChochCisdPutRules: [{ id: 'put-eng', alerts: ['BOS Down', 'bearish_engulfing'], expirationMode: 'seconds', expirationSeconds: RULE_EXPIRY }],
    });
    await sleep(300);

    const autoOn = await new Promise(r => {
      socket.once('auto-trade-status', r);
      socket.emit('set-auto-trade', { enabled: true });
      setTimeout(() => r(null), 10000);
    });
    ok(autoOn?.enabled !== false, 'auto-trade ON');
    ok(autoOn?.strategyId === 'l_lucien_protrader', `stratégie active = l_lucien_protrader (${autoOn?.strategyId})`);

    console.log('[4] Phase A — règle MIXTE [BOS Up + Bullish Engulfing] (attente de 2 ordres, cycle 60 s)…');
    const orders = [];
    socket.on('trade-opened', (ev) => {
      const src = String(ev?.source ?? '');
      orders.push({
        source: src,
        action: String(ev?.deal?.action ?? ev?.deal?.command === 1 ? 'buy' : 'sell'),
        label: String(ev?.label ?? ''),
        expirationSeconds: Number(ev.expirationSeconds ?? 0),
        openTime: Number(ev.deal?.openTime ?? 0),
        amount: Number(ev.deal?.amount ?? 0),
      });
      const o = orders[orders.length - 1];
      console.log(`    [t+${orders.length}] ${o.source} : ${o.action.toUpperCase()} ${o.amount}$ exp=${o.expirationSeconds}s bucketPos12=${Math.floor(o.openTime / 5) % 12} ofs=${o.openTime % 5} — ${o.label}`);
    });

    const phaseA = Date.now() + 210_000;
    while (orders.filter(o => o.source === 'l_lucien_protrader').length < 2 && Date.now() < phaseA) await sleep(1000);
    const lucienOrders = orders.filter(o => o.source === 'l_lucien_protrader');
    ok(lucienOrders.length >= 2, `≥ 2 ordres L_Lucien avec la règle MIXTE (${lucienOrders.length} observés)`);
    if (lucienOrders.length === 0) { cleanupAll(1); return; }

    ok(lucienOrders.every(o => o.action === 'buy'), 'tous les ordres L_Lucien sont CALL (buy)');
    ok(lucienOrders.every(o => o.label.includes('call-eng')), 'libellé : règle call-eng');
    ok(lucienOrders.every(o => o.label.includes('Bullish Engulfing')), 'libellé : condition CANDLE « Bullish Engulfing » (label lisible, pas l’id machine)');
    ok(lucienOrders.every(o => o.label.includes('[BOS Up + Bullish Engulfing]')), 'libellé : combinaison complète [BOS Up + Bullish Engulfing] (AND)');
    ok(lucienOrders.every(o => o.label.includes(`EXP ${RULE_EXPIRY}s`)), `libellé : expiration ${RULE_EXPIRY}s (mode seconds)`);
    ok(lucienOrders.every(o => o.expirationSeconds === RULE_EXPIRY), `expiration réelle = ${RULE_EXPIRY}s (le global ${GLOBAL_EXPIRY}s n’a jamais fuité)`);
    ok(lucienOrders.every(o => o.openTime % 5 === 0 || o.openTime % 5 === 1), 'ordres L_Lucien placés à/juste après la clôture de la bougie signalée');
    const putOrders = orders.filter(o => o.source === 'l_lucien_protrader' && o.action === 'sell');
    ok(putOrders.length === 0, `règle PUT [BOS Down + Bearish Engulfing] : ${putOrders.length} ordre(s) (miroir jamais déclenché)`);

    // [B] §37 NÉGATIF — Hammer ne se déclenche pas sur cette géométrie.
    console.log('[5] Phase B — négatif : règle CALL [BOS Up + Hammer] (AUCUN ordre attendu > 1 cycle)…');
    socket.emit('set-auto-config', {
      bosChochCisdCallRules: [{ id: 'call-hammer', alerts: ['BOS Up', 'hammer'], expirationMode: 'seconds', expirationSeconds: RULE_EXPIRY }],
      bosChochCisdPutRules: [],
    });
    await sleep(500);
    const beforeB = orders.length;
    const phaseB = Date.now() + 80_000;
    while (Date.now() < phaseB) await sleep(1000);
    const newOrdersB = orders.slice(beforeB);
    ok(newOrdersB.length === 0, `AUCUN nouvel ordre avec [BOS Up + Hammer] pendant > 1 cycle complet (${newOrdersB.length} observé(s)) — l’absence d’UNE condition candle bloque l’ordre (AND, pas OR)`);

    // [C] §38 NINJA — règle CANDLE PURE via les clés ninja* (règles propres).
    console.log('[6] Phase C — Ninja ProTrader : règle candle PURE [bullish_engulfing] (ordre avant clôture)…');
    socket.emit('set-auto-strategy', { strategyId: 'ninja_protrader' });
    await sleep(200);
    socket.emit('set-auto-config', {
      ninjaBosChochCisdCallRules: [{ id: 'call-ninja-eng', alerts: ['bullish_engulfing'], expirationMode: 'seconds', expirationSeconds: RULE_EXPIRY }],
      ninjaBosChochCisdPutRules: [],
    });
    await sleep(500);
    const beforeC = orders.length;
    const phaseC = Date.now() + 150_000;
    while (orders.slice(beforeC).filter(o => o.source === 'ninja_protrader').length < 1 && Date.now() < phaseC) await sleep(1000);
    const ninjaOrders = orders.slice(beforeC).filter(o => o.source === 'ninja_protrader');
    ok(ninjaOrders.length >= 1, `≥ 1 ordre Ninja avec la règle CANDLE PURE (${ninjaOrders.length} observés)`);
    if (ninjaOrders.length > 0) {
      const n = ninjaOrders[0];
      ok(n.action === 'buy', 'ordre Ninja = CALL (buy)');
      ok(n.label.includes('Bullish Engulfing'), 'libellé Ninja : condition « Bullish Engulfing »');
      ok(n.label.includes('call-ninja-eng'), 'libellé Ninja : règle call-ninja-eng (clés ninja*)');
      ok(n.expirationSeconds === RULE_EXPIRY, `expiration Ninja = ${RULE_EXPIRY}s`);
      const ofs = n.openTime % 5;
      ok(ofs >= 1, `ordre placé PENDANT la bougie en formation (openTime%5=${ofs} ≥ 1 — détection avant clôture §7)`);
    }

    cleanupAll(failures > 0 ? 1 : 0);
  })().catch(e => { console.error('FATAL:', e); cleanupAll(1); });
}

main();
