/**
 * test-bos-choch-cisd-strategy.ts — Test backend de la stratégie Auto Trade
 * « BOS, CHoCH & CISD » (module bos-choch-cisd-strategy.ts).
 *
 * Vérifie : mapping événement→action (Up=CALL / Down=PUT), bougies
 * clôturées uniquement, toggles du pack (filtres d'événements), garde
 * anti re-trade (un ordre par bougie), reset d'état, HOLD informatif.
 *
 * Exécution : node --import tsx tests/test-bos-choch-cisd-strategy.ts
 */

import {
  evaluateBosChochCisdStrategy,
  markBosChochCisdTraded,
  resetBosChochCisdState,
  DEFAULT_BOS_CHOCH_CISD_TOGGLES,
} from '../bos-choch-cisd-strategy.js'
import { computeBosChochCisd, evaluateBosChochCisd, evaluateBosChochCisdOrderRules } from '../../../shared/bos-choch-cisd.js'

let failures = 0
let passed = 0
const check = (name: string, cond: boolean, detail = '') => {
  if (!cond) { failures++; console.error(`  ✗ ${name} ${detail}`) }
  else { passed++; console.log(`  ✓ ${name}${detail ? ' — ' + detail : ''}`) }
}

/* bougies synthétiques : série directionnelle avec swings et cassures */
let t = 1_700_000_000
const mk = (open: number, close: number, high: number, low: number) => {
  t += 60
  return { open, close, high, low, volume: 100, time: t }
}

function buildSeries() {
  /* se termine SUR la bougie de cassure (l'évaluateur regarde la dernière) */
  return [
    mk(10, 10.8, 11, 9.9),      // 0 verte
    mk(10.8, 10.2, 12, 10.1),   // 1 rouge → sh(1)=12
    mk(10.2, 10.9, 11.1, 10),   // 2 verte → sl(2)=10
    mk(10.9, 10.4, 11.2, 10.2), // 3 rouge → sh(3)=11.2
    mk(10.4, 10.6, 10.7, 10.3), // 4 verte → sl(4)=10.2 → uptrend
    mk(10.6, 12.5, 12.6, 10.5), // 5 verte : cassure 11.2 → BOS Up + CISD Up
  ]
}

async function main() {
  console.log('══ BOS, CHoCH & CISD — stratégie backend ══\n')

  resetBosChochCisdState()

  /* ── 1. mapping événement → action ── */
  console.log('[1] Mapping événement → action (Up=CALL / Down=PUT)')
  {
    const candles = buildSeries()
    const sig = evaluateBosChochCisdStrategy(candles, 'EURUSD_otc')
    check('cassure haussière → CALL', sig.action === 'CALL', `${sig.action} — ${sig.reason.slice(0, 60)}`)
    check('événements listés', sig.events.includes('BOS Up') && sig.events.includes('CISD Up'), sig.events.join(', '))
    check('confiance BOS 0.85', Math.abs(sig.confidence - 0.85) < 1e-9)
    check('candleTime = dernière bougie', sig.candleTime === candles[candles.length - 1].time)

    /* sans événement sur la dernière bougie → HOLD */
    const sigHold = evaluateBosChochCisdStrategy([...candles, mk(12.5, 12.2, 12.7, 12.0)], 'EURUSD_otc')
    check('bougie sans événement → HOLD informatif', sigHold.action === 'HOLD' && sigHold.reason.length > 0)
  }

  /* ── 2. toggles du pack ── */
  console.log('\n[2] Toggles « Alerts » du pack (filtres d\'événements)')
  {
    const candles = buildSeries()
    const offAll = evaluateBosChochCisdStrategy(candles, 'EURUSD_otc', {
      bosUp: false, cisdUp: false,
    })
    check('toggles OFF (BOS Up + CISD Up) → HOLD', offAll.action === 'HOLD' && offAll.reason.includes('OFF'))

    /* CHoCH only : désactive BOS + CISD, garde CHoCH — pas de CHoCH dans
     * cette série (bos_up seulement) → HOLD */
    const chochOnly = evaluateBosChochCisdStrategy(candles, 'EURUSD_otc', {
      bosUp: false, cisdUp: false, chochUp: true, chochDown: true,
    })
    check('CHoCH only sur série sans CHoCH → HOLD', chochOnly.action === 'HOLD')
    check('défauts = tous ON', Object.values(DEFAULT_BOS_CHOCH_CISD_TOGGLES).every(Boolean))
  }

  /* ── 3. garde anti re-trade ── */
  console.log('\n[3] Garde un-ordre-par-bougie (anti re-trade)')
  {
    const candles = buildSeries()
    const a1 = evaluateBosChochCisdStrategy(candles, 'EURUSD_otc')
    check('première évaluation → CALL', a1.action === 'CALL')
    markBosChochCisdTraded('EURUSD_otc', a1.candleTime)
    const a2 = evaluateBosChochCisdStrategy(candles, 'EURUSD_otc')
    check('ré-évaluation de la MÊME bougie → HOLD', a2.action === 'HOLD', a2.reason)
    /* asset différent : indépendant */
    const b1 = evaluateBosChochCisdStrategy(candles, 'GBPUSD_otc')
    check('asset différent → signal indépendant (CALL)', b1.action === 'CALL')
    markBosChochCisdTraded('GBPUSD_otc', b1.candleTime)
    /* nouvelle bougie → signal à nouveau disponible */
    const next = [...candles, mk(12.5, 12.9, 13, 12.4)]  // nouvelle cassure (12.9 > 12.6)
    const computed = computeBosChochCisd(next)
    const hasEvent = computed.events.some((e) => e.barIndex === next.length - 1)
    const a3 = evaluateBosChochCisdStrategy(next, 'EURUSD_otc')
    check('nouvelle bougie → garde libérée', !hasEvent || a3.action !== 'HOLD' || a3.reason.includes('aucun événement'),
      hasEvent ? a3.action : `pas d'événement (HOLD normal) : ${a3.action}`)
  }

  /* ── 4. reset d'état ── */
  console.log('\n[4] Reset d\'état')
  {
    const candles = buildSeries()
    const s1 = evaluateBosChochCisdStrategy(candles, 'EURUSD_otc')
    markBosChochCisdTraded('EURUSD_otc', s1.candleTime)
    resetBosChochCisdState('EURUSD_otc')
    const s2 = evaluateBosChochCisdStrategy(candles, 'EURUSD_otc')
    check('reset par asset → signal de nouveau émis', s2.action === 'CALL')
    markBosChochCisdTraded('EURUSD_otc', s2.candleTime)
    resetBosChochCisdState()
    const s3 = evaluateBosChochCisdStrategy(candles, 'EURUSD_otc')
    check('reset global → signal de nouveau émis', s3.action === 'CALL')
  }

  /* ── 5. cohérence front/back (même moteur partagé) ── */
  console.log('\n[5] Cohérence front/back — moteur partagé')
  {
    const candles = buildSeries()
    const direct = evaluateBosChochCisd(candles)
    const viaBackend = evaluateBosChochCisdStrategy(candles, 'COHERENCE_TEST')
    check('evaluateBosChochCisd ≡ evaluateBosChochCisdStrategy (hors garde)',
      direct.action === viaBackend.action && direct.reason === viaBackend.reason && direct.candleTime === viaBackend.candleTime,
      `${direct.action} vs ${viaBackend.action}`)
  }

  /* ── 6. sécurité données ── */
  console.log('\n[6] Sécurité données')
  {
    check('série vide → HOLD propre', evaluateBosChochCisdStrategy([], 'X').action === 'HOLD')
    check('2 bougies → HOLD (warm-up)', evaluateBosChochCisdStrategy([mk(1, 2, 2.5, 0.5), mk(2, 1.5, 2.6, 1)], 'X').action === 'HOLD')
  }


  /* ── 7. règles CALL/PUT à combinaisons libres + expiration ── */
  console.log('\n[7] Règles CALL ▲ / PUT ▼ — combinaison + expiration')
  {
    const candles = buildSeries() // dernière bougie = BOS Up + CISD Up
    const call = evaluateBosChochCisdOrderRules(
      candles,
      [{ id: 'call-bos-cisd', alerts: ['BOS Up', 'CISD Up'], expirationSeconds: 5 }],
      [{ id: 'put-mixed', alerts: ['BOS Up', 'CISD Up', 'CHoCH Down'], expirationSeconds: 20 }],
    )
    check('CALL : BOS Up + CISD Up correspond', call.action === 'CALL' && call.matchedRuleId === 'call-bos-cisd')
    check('CALL : expiration propre = 5s', call.expirationSeconds === 5)
    const put = evaluateBosChochCisdOrderRules(
      candles,
      [],
      [{ id: 'put-bos-only', alerts: ['BOS Up'], expirationSeconds: 20 }],
    )
    check('PUT : une combinaison peut demander une alerte Up', put.action === 'PUT' && put.matchedRuleId === 'put-bos-only')
    check('PUT : expiration propre = 20s', put.expirationSeconds === 20)
    const specific = evaluateBosChochCisdOrderRules(
      candles,
      [
        { id: 'call-generic', alerts: ['BOS Up'], expirationSeconds: 30 },
        { id: 'call-specific', alerts: ['BOS Up', 'CISD Up'], expirationSeconds: 5 },
      ],
      [],
    )
    check('combinaison la plus spécifique prioritaire', specific.matchedRuleId === 'call-specific' && specific.expirationSeconds === 5)
  }

  console.log(`\n═══ RÉSULTAT : ${passed} ✓ · ${failures} ✗ ═══`)
  process.exit(failures > 0 ? 1 : 0)
}

main().catch((err) => { console.error(err); process.exit(1) })
