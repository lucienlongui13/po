/**
 * mock-po-broker.mjs — FAUX serveur Pocket Option pour tests E2E.
 * =====================================================================
 * Reproduit fidèlement le protocole vu par le backend :
 *
 *  HTTP (login + cabinet) :
 *   - POST /api/webview/login  → {code:0, uid, token, secret} + Set-Cookie ci_session
 *   - GET  /en/cabinet          → HTML avec AppData {servers-list, demo-balance, currency}
 *
 *  WS (Engine.IO / Socket.IO v4 — frames brutes) :
 *   - `0{sid,...}` à la connexion, `40{sid}` après `40`
 *   - `42["auth",{...}]` → `451-["successauth",...]` + binaire
 *     puis updateAssets + successupdateBalance
 *   - `2` → `3` (ping/pong Engine.IO), `42["ps"]` ignoré
 *   - `42["changeSymbol",{asset,period}]` → `451-["updateHistoryNewFast",...]`
 *     + binaire {asset, period, history:[[t,p],...]} (graine ~20 min) puis
 *     flux continu `42["updateStream",[[asset,ts,price]]]` POUR CHAQUE ASSET ACTIVÉ
 *   - `42["openOrder",{...}]` → `42["successopenOrder",{requestId, deal:{UUID...}}]`
 *   - à l'expiration : WIN/LOSS par comparaison réelle des prix, deal fermé
 *     avec ID NUMÉRIQUE (≠ UUID d'ouverture — pire cas de matching), publié
 *     PARESSEUSEMENT (settleDelayMs après l'expiration) via
 *     `42["updateClosedDeals",[[...]]]` — reproduit le comportement observé
 *     chez l'utilisateur (règlement tardif > fenêtre de l'ancien watchdog).
 *   - `42["updateClosedDeals",{}]` (refresh) → renvoi de la liste publiée.
 *
 *  MULTI-ASSETS (v2) : l'option `assets` définit PLUSIEURS actifs
 *  indépendants (prix, corps de bougie, mèche, payout, script R/G par
 *  asset). Chaque changeSymbol active le flux de SON asset ; la boucle de
 *  ticks diffuse UN updateStream par asset actif ; les règlements de TOUS
 *  les assets sont poussés DANS LA MÊME liste updateClosedDeals (comme le
 *  vrai broker) — le backend doit router chaque règlement vers le contexte
 *  de SON asset. Défaut : EURUSD_otc seul (compatibilité des tests v1).
 *
 *  Résultats imposés :
 *   - `outcomeScript` (global, ordre d'arrivée des openOrder) — v1 ;
 *   - `outcomeScriptByAsset` ({ asset: ['loss','win',…] }) — prioritaire,
 *     consommé PAR ASSET dans l'ordre des ordres de CET asset.
 *   - valeurs acceptées (v17) : 'win' | 'loss' | 'tie' (alias 'push',
 *     'refund', 'draw') — tie = Tie/Refund : closePrice === openPrice,
 *     profit NET = 0, mise remboursée (état NEUTRE pour la suite de mises).
 *
 * Utilisé par tests/test-winwin-e2e.mjs et tests/test-bos-choch-cisd-*-e2e.mjs
 * pour piloter le VRAI backend.
 */

import http from 'node:http';
import crypto from 'node:crypto';
import { WebSocketServer } from 'ws';

const ASSET = 'EURUSD_otc';
const PAYOUT_PCT = 92;

export class MockPoBroker {
  constructor(opts = {}) {
    this.httpPort = opts.httpPort ?? 4010;
    this.wsPort = opts.wsPort ?? 4011;
    this.candleSec = opts.candleSec ?? 5;              // S5
    this.settleDelayMs = opts.settleDelayMs ?? 22000;  // publication lazy des deals fermés
    this.historyBuckets = opts.historyBuckets ?? 300;  // ~25 min de graine
    // Mèche (pips) ajoutée à chaque bougie du flux/historique : les ticks
    // dépassent la clôture (extrême) puis y reviennent. Par défaut 0 =
    // comportement historique (chemin monotone, sans mèche).
    // Nécessaire pour reproduire des marchés RÉELS : sans mèche, les clôtures
    // tombent EXACTEMENT sur les prix de swing et les croisements STRICTS
    // (close > swing) ne se produisent jamais.
    this.wickSize = opts.wickSize ?? 0;
    // Résultats déterministes par ordre (test Martingale) : 'win'|'loss'
    // consommés dans l'ordre des openOrder (cyclés si plus courts). La
    // comparaison réelle des prix est remplacée par le résultat imposé —
    // le reste (id NUMÉRIQUE ≠ UUID, publication paresseuse) reste réel.
    this.outcomeScript = opts.outcomeScript ?? null;
    // v2 MULTI-ASSETS : résultats imposés PAR ASSET — { asset: ['loss',…] }.
    this.outcomeScriptByAsset = opts.outcomeScriptByAsset ?? null;
    // Script de directions par asset ('R'/'G' par bougie, cyclé) :
    // 'RGG' répété déclenche un BOS Up + CISD Up à chaque 3e bougie.
    this.script = opts.script ?? 'RGG';
    // v23 — PATH SCRIPT : corps de bougie SIGNÉS par bucket (multiplicateurs
    // de bodySize, cyclés). Présent → la direction vient du SIGNE (>0 = G,
    // <0 = R) et le corps du bucket est |multiplicateur| × bodySize.
    // Permet de construire des géométries exactes (CISD seul avec swing
    // intact, puis signal combiné de confirmation) sur le flux temps réel.
    this.pathScript = Array.isArray(opts.pathScript) && opts.pathScript.length
      ? opts.pathScript.map((v) => Number(v) || 0)
      : null;
    // v26 — GAP SCRIPT : décalage d'OUVERTURE par bucket (multiplicateurs
    // de bodySize, cyclés) — OUVERT une bougie SOUS/AU-DESSUS de la
    // clôture précédente. Permet les patterns candle À GAP (Engulfing
    // strict — open < close précédent —, Stars, Kicking, Abandoned
    // Baby…) que la continuité open=close[n-1] rendait impossibles.
    this.gapScript = Array.isArray(opts.gapScript) && opts.gapScript.length
      ? opts.gapScript.map((v) => Number(v) || 0)
      : null;
    // MULTI-ASSETS PATHOLOGIQUE : assets dont les règlements ne sont JAMAIS
    // publiés (ni push auto, ni réponse au refresh) — simule un broker qui
    // ne diffuse les deals fermés que de l'asset focus (comportement réel
    // soupçonné chez l'utilisateur : « la Martingale ne fonctionne pas sur
    // les autres assets, les ordres restent à la mise de base »). Le
    // watchdog du backend doit alors régler ces deals par le flux de ticks.
    this.suppressSettlementPushFor = new Set(opts.suppressSettlementPushFor ?? []);
    // CAPTURE RÉELLE 2026-09-17 : le broker pousse AUSSI chaque clôture en
    // temps réel (~0,6 s après l'échéance) via
    //   successcloseOrder { profit: <retour TOTAL>, deals: [ <deal natif> ] }
    // avec le deal natif { id UUID, asset, amount, profit NET, openPrice,
    // closePrice, command 0/1, openTimestamp/closeTimestamp, strings
    // datetime openTime/closeTime }. C'est le chemin PRINCIPAL de règlement
    // côté réel — l'ancien mock ne publiait QUE updateClosedDeals lazy.
    // true = reproduit le broker réel (recommandé pour les E2E).
    this.realtimeClosePush = opts.realtimeClosePush ?? false;

    // ── Définitions d'assets (v2) ─────────────────────────────────────
    // Défaut : EURUSD_otc seul, comportement strictement identique à v1.
    const defs = opts.assets ?? [
      { symbol: ASSET, startPrice: 1.18000, bodySize: opts.bodySize ?? 0.00030, payout: opts.payout ?? PAYOUT_PCT },
    ];
    this.assetDefs = new Map();
    for (const d of defs) {
      this.assetDefs.set(d.symbol, {
        symbol: d.symbol,
        startPrice: d.startPrice,
        bodySize: d.bodySize ?? opts.bodySize ?? 0.00030,
        payout: d.payout ?? opts.payout ?? PAYOUT_PCT,
        wickSize: d.wickSize ?? opts.wickSize ?? 0,
        script: d.script ?? opts.script ?? 'RGG',
        pathScript: Array.isArray(d.pathScript) ? d.pathScript.map((v) => Number(v) || 0) : (this.pathScript ?? null),
        // v26 — gaps d'ouverture par bucket (multiplicateurs × bodySize).
        gapScript: Array.isArray(d.gapScript) ? d.gapScript.map((v) => Number(v) || 0) : (this.gapScript ?? null),
      });
    }
    this.primaryAsset = defs[0].symbol;

    // ── État par asset ────────────────────────────────────────────────
    this.state = new Map(); // symbol -> per-asset state (voir initAssetState)
    for (const def of this.assetDefs.keys()) this.initAssetState(def);

    // ID numériques GLOBALEMENT UNIQUES (comportement du vrai broker : les ids
    // de deals sont uniques pour TOUT le compte, tous assets confondus).
    this.nextNumericId = 900000;

    this.httpServer = null;
    this.wsServer = null;
    this.sockets = new Set();
    this.tickTimer = null;
    this.publishTimer = null;
    this.authenticated = false;
    this.stats = { orders: 0, settled: 0, published: 0, refreshRequests: 0, ticksSent: 0, historySent: 0 };
  }

  /** État privé d'UN asset (prix, bougie courante, règlements, fantômes). */
  initAssetState(symbol) {
    const def = this.assetDefs.get(symbol);
    this.state.set(symbol, {
      def,
      price: def.startPrice,
      active: false,           // activé par changeSymbol (flux live)
      lastBucket: -1,
      candleOpen: def.startPrice,
      candleDir: 'G',
      candleTick: 0,
      closedDeals: [],         // deals déjà publiés (renvoyés au refresh)
      pendingSettlements: [],   // {payload, publishAt}
      ghosts: null,            // deals étrangers permanents (cache broker)
      settled: 0,              // règlements traités POUR CET asset
    });
  }

  /** Prix de l'asset primaire (compatibilité v1 : broker.price). */
  get price() { return this.state.get(this.primaryAsset).price; }
  set price(v) { this.state.get(this.primaryAsset).price = v; }
  /** Fantômes de l'asset primaire (compatibilité v1 : broker.ghosts). */
  get ghosts() { return this.state.get(this.primaryAsset).ghosts; }

  // ------------------------------------------------------------------ prix

  dirAt(assetDef, bucket) {
    // v23 — pathScript : direction par le SIGNE du multiplicateur.
    if (Array.isArray(assetDef.pathScript) && assetDef.pathScript.length) {
      return assetDef.pathScript[bucket % assetDef.pathScript.length] >= 0 ? 'G' : 'R';
    }
    return assetDef.script[bucket % assetDef.script.length];
  }

  /** v23 — corps du bucket (|multiplicateur| × bodySize ; bodySize sinon). */
  bodyAt(assetDef, bucket) {
    if (Array.isArray(assetDef.pathScript) && assetDef.pathScript.length) {
      return Math.abs(assetDef.pathScript[bucket % assetDef.pathScript.length]) * assetDef.bodySize;
    }
    return assetDef.bodySize;
  }

  /** v26 — gap d'OUVERTURE du bucket (multiplicateur × bodySize ; 0 sinon). */
  gapAt(assetDef, bucket) {
    if (Array.isArray(assetDef.gapScript) && assetDef.gapScript.length) {
      return assetDef.gapScript[bucket % assetDef.gapScript.length] * assetDef.bodySize;
    }
    return 0;
  }

  // ------------------------------------------------------------------ payout

  /**
   * v20 — Fait varier le payout d'un asset PUIS repousse `updateAssets` à
   * toutes les sockets connectées (comportement du broker réel : le payout
   * est dynamique et repoussé régulièrement). Sert à tester les règles Auto
   * Switch Assets (déclencheur payout < 92 %, cible == 92 %).
   */
  setPayout(symbol, payout) {
    const def = this.assetDefs.get(symbol);
    if (!def) return;
    def.payout = payout;
    for (const ws of this.sockets) {
      this.sendBinaryEvent(ws, 'updateAssets', [...this.assetDefs.values()].map((d, i) => [
        66 + i, d.symbol, d.symbol.replace('_', ' '), 'currency', 2, d.payout, 60, 30, 3, 1, 66 + i, 0, [], -1, true,
        [{ time: 5 }, { time: 10 }, { time: 15 }, { time: 30 }, { time: 60 }, { time: 120 }, { time: 300 }],
        -1, 60,
      ]));
    }
  }

  // ------------------------------------------------------------------ HTTP

  startHttp(port) {
    this.httpServer = http.createServer((req, res) => {
      const url = new URL(req.url, `http://127.0.0.1:${port}`);
      if (req.method === 'POST' && url.pathname === '/api/webview/login') {
        res.writeHead(200, {
          'content-type': 'application/json',
          'set-cookie': 'ci_session=mockciphpse4455677889122334; path=/',
        });
        res.end(JSON.stringify({ code: 0, uid: 777, token: 'mocktoken123', secret: 'mocksecret', cuid: 'c777', is_register: 0 }));
        return;
      }
      if (req.method === 'GET' && url.pathname === '/en/cabinet') {
        const html = `<!DOCTYPE html><html><head><script>var AppData = ${JSON.stringify({
          uid: 777,
          'servers-list': [{ server: `ws://127.0.0.1:${this.wsPort}` }],
          'user-demo-balance': 10000,
          currency_code: 'USD',
        })};</script></head><body>cabinet</body></html>`;
        res.writeHead(200, { 'content-type': 'text/html', 'set-cookie': 'ci_session=mockciphpse4455677889122334; path=/' });
        res.end(html);
        return;
      }
      res.writeHead(404); res.end('not found');
    });
    return new Promise(r => this.httpServer.listen(port, '127.0.0.1', r));
  }

  // ------------------------------------------------------------------ WS

  startWs(port) {
    this.wsServer = new WebSocketServer({ port, host: '127.0.0.1' });
    this.wsServer.on('connection', ws => {
      ws.on('error', () => { /* ignore */ });
      // Engine.IO OPEN
      this.sendText(ws, `0${JSON.stringify({ sid: crypto.randomBytes(8).toString('hex'), upgrades: [], pingInterval: 25000, pingTimeout: 20000, maxPayload: 1000000 })}`);
      ws.on('message', (data, isBinary) => {
        if (isBinary) return; // le client n'envoie jamais de binaire utile
        const text = data.toString('utf-8');
        this.onFrame(ws, text);
      });
      ws.on('close', () => this.sockets.delete(ws));
      this.sockets.add(ws);
    });
    return new Promise(r => this.wsServer.once('listening', r));
  }

  onFrame(ws, text) {
    if (text === '2') { this.sendText(ws, '3'); return; }
    if (text === '40') { this.sendText(ws, `40${JSON.stringify({ sid: crypto.randomBytes(6).toString('hex') })}`); return; }
    if (text.startsWith('42')) {
      let arr;
      try { arr = JSON.parse(text.slice(2)); } catch { return; }
      const name = arr[0];
      const payload = arr[1];
      this.onEvent(ws, name, payload);
      return;
    }
    // `41`, `44`, pings binaires, etc. — ignorés
  }

  onEvent(ws, name, payload) {
    switch (name) {
      case 'auth': {
        this.authenticated = true;
        // successauth (binary event, comme le vrai serveur)
        this.sendBinaryEvent(ws, 'successauth', { uid: 777, isDemo: 1, currency: 'USD' });
        // updateAssets : TOUS les assets définis (payout live ≥ 80 pour ne
        // pas déclencher le Payout Guard du backend).
        this.sendBinaryEvent(ws, 'updateAssets', [...this.assetDefs.values()].map((def, i) => [
          66 + i, def.symbol, def.symbol.replace('_', ' '), 'currency', 2, def.payout, 60, 30, 3, 1, 66 + i, 0, [], -1, true,
          [{ time: 5 }, { time: 10 }, { time: 15 }, { time: 30 }, { time: 60 }, { time: 120 }, { time: 300 }],
          -1, 60,
        ]));
        this.sendTextEvent(ws, 'successupdateBalance', { balance: 10000, isDemo: 1, balances: { 1: { amount: 10000, isDemo: 1, currency: 'USD' } } });
        return;
      }
      case 'ps': return; // heartbeat
      case 'subfor':
      case 'unsubfor':
      case 'indicator/load':
      case 'favorite/load':
      case 'price-alert/load':
      case 'deals/ai':
      case 'sto': return;
      case 'loadHistoryPeriod': {
        // v21 — Réponse IMMÉDIATE avec un batch VIDE. Le vrai broker renvoie
        // `loadHistoryPeriodFast` avec les bougies paginées ; ce mock ne
        // historicalise que via updateHistoryNewFast (changeSymbol, graine
        // complète). Sans CETTE réponse, chaque fetch d'historique attend
        // le timeout SDK (30 s × N itérations ≈ 3,5 min) — un switch auto
        // reste bloqué (assetSwitchInProgress) et l'émission
        // force-frontend-refresh (post-fetch) ne part jamais.
        this.sendBinaryEvent(ws, 'loadHistoryPeriodFast', {
          asset: String(payload?.asset ?? ''),
          period: Number(payload?.period ?? 0),
          index: Number(payload?.index ?? Date.now()),
          data: [],
        });
        return;
      }
      case 'changeSymbol': {
        const asset = String(payload?.asset ?? '');
        const period = Number(payload?.period ?? 0);
        if (!this.assetDefs.has(asset)) return; // v2 : tout asset DÉFINI est activable
        const st = this.state.get(asset);
        st.active = true;
        st.streamPeriod = period || this.candleSec;
        this.sendHistorySnapshot(ws, asset, period);
        this.stats.historySent++;
        this.ensureTickLoop();
        return;
      }
      case 'openOrder': {
        this.handleOpenOrder(ws, payload);
        return;
      }
      case 'updateClosedDeals': {
        // refreshClosedDeals() du client → renvoyer la liste publiée
        this.stats.refreshRequests++;
        this.pushClosedDeals(ws);
        return;
      }
      default: return;
    }
  }

  /** Chemin de ticks d'une bougie : open → close AVEC dépassement (mèche)
   * à l'avant-dernier tick. k = 1..S. Reproduit des bougies réelles avec
   * high/low AU-DELÀ du corps — sans quoi les clôtures tombent pile sur
   * les swings et aucun croisement strict n'est possible. */
  tickPrice(open, dir, k, S, bodySize, wickSize) {
    const close = open + dir * bodySize;
    if (wickSize > 0 && S >= 3) {
      if (k <= S - 2) return open + dir * bodySize * (k / (S - 1));
      if (k === S - 1) return close + dir * wickSize; // extrême (mèche)
      return close;                                    // clôture
    }
    return open + dir * bodySize * (k / S);
  }

  sendHistorySnapshot(ws, asset, period) {
    const def = this.assetDefs.get(asset);
    const st = this.state.get(asset);
    const nowSec = Date.now() / 1000;
    const curBucket = Math.floor(nowSec / this.candleSec);
    const buckets = Math.max(this.historyBuckets, 40);
    const firstBucket = curBucket - buckets; // bougies entièrement closes
    let p = def.startPrice;
    const history = [];
    for (let b = firstBucket; b < curBucket; b++) {
      const d = this.dirAt(def, b) === 'G' ? 1 : -1;
      const body = this.bodyAt(def, b); // v23 — corps par bucket (pathScript)
      if (b > firstBucket) p += this.gapAt(def, b); // v26 — gap d'ouverture
      for (let k = 1; k <= this.candleSec; k++) {
        // ticks intra-bougie, horodatage SOUS-SECONDE strictement croissant
        const t = b * this.candleSec + (k - 1) + 0.5;
        const price = this.tickPrice(p, d, k, this.candleSec, body, def.wickSize);
        history.push([Number(t.toFixed(2)), Number(price.toFixed(5))]);
      }
      p += d * body;
    }
    // le prix courant = clôture de la dernière bougie close ; la bougie en
    // cours de formation repart de là (le tick-loop rouvre depuis st.price)
    // → continuité historique ↔ flux (< 1 s), comme le vrai broker.
    st.price = Number(p.toFixed(5));
    st.lastBucket = -1;
    this.sendBinaryEvent(ws, 'updateHistoryNewFast', { asset, period, history });
  }

  handleOpenOrder(ws, payload) {
    const asset = String(payload?.asset ?? this.primaryAsset);
    const def = this.assetDefs.get(asset) ?? this.assetDefs.get(this.primaryAsset);
    const st = this.state.get(asset) ?? this.state.get(this.primaryAsset);
    const amount = Number(payload?.amount ?? 1);
    const action = String(payload?.action ?? 'call');
    const time = Number(payload?.time ?? 60);
    const requestId = Number(payload?.requestId ?? 0);
    const openPrice = Number(st.price.toFixed(5));
    const openTime = Math.floor(Date.now() / 1000);
    const dealId = crypto.randomUUID();
    this.stats.orders++;

    // v19 — reproduction EXACTE du bug « ghost settlements » observé chez
    // l'utilisateur (JSONL du 2026-09-08) : dès le PREMIER ordre, deux deals
    // fermés ÉTRANGERS entrent dans le cache broker (updateClosedDeals) et y
    // restent — le scan périodique du watchdog les rencontre sans arrêt.
    //   - fantôme A (type 5ed07a66) : entrée 15 pips hors marché, SANS
    //     closeTime ni openTime, faux WIN +0.78 — chez l'utilisateur il a
    //     réglé 22 ordres différents ;
    //   - fantôme B (type 38095056) : horodatages frais et cohérents,
    //     direction cohérente, mais entrée 8 pips hors marché (LOSS −1).
    // Le backend v19 doit les REJETER (jamais de faux résultat). PAR ASSET.
    if (st.ghosts == null) this.injectGhostDeals(asset);

    const deal = {
      id: dealId,
      asset,
      action,
      amount,
      openPrice,
      openTime,
      expireTime: openTime + time,
      time,
      optionType: 100,
      isDemo: 1,
      requestId,
    };
    // successopenOrder en event TEXTE (le parseur lit data.deal ?? data)
    this.sendTextEvent(ws, 'successopenOrder', { requestId, deal });
    // updateOpenedDeals léger
    this.sendTextEvent(ws, 'updateOpenedDeals', [deal]);

    // Règlement à l'échéance : résultat du outcomeScript (global ou par
    // asset) si présent, sinon comparaison RÉELLE des prix.
    // v17 — TROIS états : 'win' | 'loss' | 'tie' (alias 'push'/'refund'/'draw').
    //   tie  = Tie/Refund broker : closePrice === openPrice (égalité EXACTE),
    //          profit NET = 0, isWin = false, mise remboursée (retour total =
    //          mise). Le backend v17 doit classer ce règlement en état NEUTRE
    //          ('push') : l'index de la suite de mises ne bouge PAS.
    const expiryMs = time * 1000 + 600;
    setTimeout(() => {
      const closeTime = Math.floor(Date.now() / 1000);
      // Résultat imposé : script PAR ASSET prioritaire, sinon script global.
      const normalizeForced = (v) =>
        v === 'tie' || v === 'push' || v === 'refund' || v === 'draw' ? 'tie'
        : v === 'win' ? 'win'
        : v === 'loss' ? 'loss'
        : null;
      let forced = null;
      if (this.outcomeScriptByAsset && this.outcomeScriptByAsset[asset]) {
        const script = this.outcomeScriptByAsset[asset];
        forced = normalizeForced(script[st.settled % script.length]);
      } else if (this.outcomeScript) {
        forced = normalizeForced(this.outcomeScript[this.stats.settled % this.outcomeScript.length]);
      }
      const closePrice = forced === 'tie'
        ? Number(openPrice.toFixed(5)) // égalité EXACTE → remboursement
        : forced != null
          ? Number((forced === 'win'
              ? (action === 'call' ? openPrice + def.bodySize : openPrice - def.bodySize)
              : (action === 'call' ? openPrice - def.bodySize : openPrice + def.bodySize)).toFixed(5))
          : Number(st.price.toFixed(5));
      const isWin = forced === 'tie'
        ? false // un Tie n'est PAS un gain (P&L = 0)
        : forced != null
          ? forced === 'win'
          : action === 'call' ? closePrice > openPrice : closePrice < openPrice;
      const profit = forced === 'tie' ? 0 : isWin ? Number((amount * def.payout / 100).toFixed(2)) : -amount;
      this.stats.settled++;
      st.settled++;
      this.balance = Math.max(0, (this.balance ?? 10000) + profit);
      const closedRaw = {
        id: this.nextNumericId++, // ID NUMÉRIQUE ≠ UUID : pire cas de matching
        asset,
        action,
        amount,
        openPrice,
        closePrice,
        openTime,
        closeTime,
        profit,
        isWin,
        isDemo: 1,
      };
      st.pendingSettlements.push({ payload: closedRaw, publishAt: Date.now() + this.settleDelayMs });
      this.ensurePublishLoop();

      // CHEMIN RÉEL (capture 2026-09-17) : push temps réel du règlement via
      // successcloseOrder — enveloppe { profit: RETOUR TOTAL, deals: [deal] }.
      // Le deal interne porte l'UUID d'ouverture, le profit NET, les prix,
      // `command` (0=CALL, 1=PUT) et les timestamps Unix + strings datetime
      // (fuseau broker). L'ancienne lecture `data.deal ?? data` du SDK
      // parsait l'enveloppe → deal #0 + asset vide → Martingale figée
      // (bug utilisateur « les ordres continuent sur la mise de base »).
      if (this.realtimeClosePush) {
        const dt = (unix) => new Date((unix + 7200) * 1000).toISOString().slice(0, 19).replace('T', ' ');
        // v17 — Tie/Refund : le broker rembourse la mise (retour total = mise,
        // profit NET = 0). WIN : retour total = mise + gain. LOSS : 0.
        const totalReturn = forced === 'tie'
          ? Number(amount.toFixed(2))
          : isWin ? Number((amount + profit).toFixed(2)) : 0;
        this.sendTextEvent(ws, 'successcloseOrder', {
          profit: totalReturn,
          deals: [{
            id: dealId,
            openTime: dt(openTime),
            closeTime: dt(closeTime),
            openTimestamp: openTime,
            closeTimestamp: closeTime,
            uid: 138637217,
            amount,
            profit,
            percentProfit: def.payout,
            percentLoss: 100,
            openPrice,
            closePrice,
            command: action === 'put' ? 1 : 0,
            asset,
            isDemo: 1,
            copyTicket: '',
            closeMs: 0,
            optionType: 100,
            openMs: 300,
            currency: 'USD',
            amountUSD: amount,
            isCopySignal: false,
            requestId,
          }],
        });
      }
    }, expiryMs);
  }

  ensurePublishLoop() {
    if (this.publishTimer) return;
    this.publishTimer = setInterval(() => {
      const now = Date.now();
      const due = [];
      for (const st of this.state.values()) {
        const d = st.pendingSettlements.filter(s => s.publishAt <= now);
        if (d.length === 0) continue;
        st.pendingSettlements = st.pendingSettlements.filter(s => s.publishAt > now);
        st.closedDeals.push(...d.map(s => s.payload));
        st.closedDeals = st.closedDeals.slice(-20);
        if (!this.suppressSettlementPushFor.has(st.def.symbol)) {
          due.push(...d.map(s => s.payload));
        }
        // Les règlements des assets supprimés restent dans le cache local du
        // mock (st.closedDeals) MAIS ne partent jamais — la purge slice(-20)
        // les évince naturellement au fil des deals suivants.
      }
      if (due.length === 0) return;
      this.stats.published += due.length;
      // publication (auto-push, comme le vrai broker) : TOUS les assets
      // dans la MÊME liste — le backend doit router chaque règlement vers
      // le contexte de SON asset (isolation multi-assets).
      for (const ws of this.sockets) {
        if (ws.readyState === 1) this.pushClosedDeals(ws);
      }
      // balance mise à jour après règlement
      for (const ws of this.sockets) {
        if (ws.readyState === 1) {
          this.sendTextEvent(ws, 'successupdateBalance', { balance: this.balance, isDemo: 1, balances: { 1: { amount: this.balance, isDemo: 1, currency: 'USD' } } });
        }
      }
    }, 1000);
  }

  pushClosedDeals(ws) {
    // Les deals fantômes restent TOUJOURS en tête de liste (comme le deal
    // 5ed07a66 resté des heures dans le cache broker réel) : chaque push et
    // chaque refresh les renvoie → le backend doit les ignorer indéfiniment.
    // Les règlements des TOUS les assets suivent, mélangés (vrai broker) —
    // SAUF les assets « supprimés » (jamais publiés, même au refresh).
    const list = [];
    for (const st of this.state.values()) list.push(...(st.ghosts ?? []));
    for (const st of this.state.values()) {
      if (this.suppressSettlementPushFor.has(st.def.symbol)) continue;
      list.push(...st.closedDeals);
    }
    this.sendTextEvent(ws, 'updateClosedDeals', list.map(d => ({ ...d })));
  }

  injectGhostDeals(asset) {
    const st = this.state.get(asset);
    const p = st.price;
    st.ghosts = [
      { // fantôme A — type « 5ed07a66 » (sans horodatages, faux WIN)
        id: crypto.randomUUID(), asset, action: 'put', amount: 1,
        openPrice: Number((p + 0.0015).toFixed(5)),
        closePrice: Number((p + 0.0013).toFixed(5)),
        openTime: 0, closeTime: 0,
        profit: 0.78, isWin: true, isDemo: 1,
      },
      { // fantôme B — type « 38095056 » (horodatages frais, LOSS cohérent)
        id: crypto.randomUUID(), asset, action: 'put', amount: 1,
        openPrice: Number((p - 0.0008).toFixed(5)),
        closePrice: Number((p - 0.00079).toFixed(5)),
        openTime: Math.floor(Date.now() / 1000),
        closeTime: Math.floor(Date.now() / 1000) + 9,
        profit: -1, isWin: false, isDemo: 1,
      },
    ];
    this.stats.ghostsInjected = (this.stats.ghostsInjected ?? 0) + st.ghosts.length;
  }

  // ------------------------------------------------------------------ ticks

  ensureTickLoop() {
    if (this.tickTimer) return;
    this.tickTimer = setInterval(() => {
      const t = Date.now() / 1000;
      const bucket = Math.floor(t / this.candleSec);
      for (const [asset, st] of this.state.entries()) {
        if (!st.active) continue; // seuls les assets ACTIVÉS (changeSymbol) streament
        const def = st.def;
        if (bucket !== st.lastBucket) {
          st.lastBucket = bucket;
          st.candleOpen = st.price + this.gapAt(def, bucket); // v26 — gap d'ouverture
          st.candleDir = this.dirAt(def, bucket);
          st.candleTick = 0;
        }
        st.candleTick++;
        const dir = st.candleDir === 'G' ? 1 : -1;
        const body = this.bodyAt(def, bucket); // v23 — corps par bucket (pathScript)
        st.price = Number(this.tickPrice(st.candleOpen, dir, st.candleTick, this.candleSec, body, def.wickSize).toFixed(5));
        this.stats.ticksSent++;
        if (this.stats.ticksSent % 45 === 0) {
          console.log(`    [mock] tick #${this.stats.ticksSent} — ${asset} price=${st.price} sockets=${this.sockets.size}`);
        }
        for (const ws of this.sockets) {
          if (ws.readyState === 1) {
            try {
              // FORMAT REQUIS par parseStreamUpdate (SDK) : [[asset, ts, price]]
              // — l'élément [0] est une string → le parseur lit le 2e élément
              // comme TIMESTAMP et le 3e comme PRIX. Le format
              // [[asset, bid, ask, time]] serait mal interprété (bid = ts !).
              this.sendTextEvent(ws, 'updateStream', [[asset, Number(t.toFixed(3)), st.price]]);
            } catch (e) {
              console.error(`    [mock] ENVOI TICK ÉCHOUÉ (${asset}):`, e.message);
            }
          }
        }
      }
    }, 1000);
  }

  // ------------------------------------------------------------------ frames

  sendText(ws, text) {
    if (ws.readyState === 1) ws.send(text);
  }

  /** Event Socket.IO texte : `42[name, payload]`. */
  sendTextEvent(ws, name, payload) {
    this.sendText(ws, `42${JSON.stringify([name, payload])}`);
  }

  /** Event binaire 451- + attachment (comme le vrai serveur PO). */
  sendBinaryEvent(ws, name, payload) {
    this.sendText(ws, `451-${JSON.stringify([name, { _placeholder: true, num: 0 }])}`);
    if (ws.readyState === 1) ws.send(Buffer.from(JSON.stringify(payload), 'utf-8'), { binary: true });
  }

  // ------------------------------------------------------------------ cycle de vie

  async start() {
    this.balance = 10000;
    for (const [symbol, st] of this.state.entries()) {
      st.price = this.assetDefs.get(symbol).startPrice;
      st.candleOpen = st.price;
    }
    await this.startHttp(this.httpPort);
    await this.startWs(this.wsPort);
    return { httpPort: this.httpPort, wsPort: this.wsPort };
  }

  stop() {
    if (this.tickTimer) { clearInterval(this.tickTimer); this.tickTimer = null; }
    if (this.publishTimer) { clearInterval(this.publishTimer); this.publishTimer = null; }
    for (const ws of this.sockets) { try { ws.terminate(); } catch { /* ignore */ } }
    this.sockets.clear();
    if (this.wsServer) { try { this.wsServer.close(); } catch { /* ignore */ } }
    if (this.httpServer) { try { this.httpServer.close(); } catch { /* ignore */ } }
  }
}
