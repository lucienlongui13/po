/**
 * test-v24-cisd-config-e2e.mjs — E2E Étapes de vérification CISD
 * ==================================================================== OPTIONNELLES
 * (cases à cocher) sur le VRAI backend + faux broker Pocket Option.
 *
 * MISSION v24 : l'utilisateur choisit d'activer/désactiver les étapes de
 * vérification CISD UP / CISD Down, le mode swing (violé / non violé) et
 * les combinaisons de confirmation (BOS/CHoCH) CALL ▲ et PUT ▼.
 *
 * Géométrie du flux (S5, pathScript v23 du mock, B = 0.00012, W = 0.00004) :
 *   bougie %10==5 (G, +5B) : CISD Up SEUL (swing 2B+W INTACT) ;
 *   bougie %10==9 (G, +1.5B) : BOS Up + CISD Up (signal COMBINÉ).
 *
 * Phases :
 *   [0] PLOMBERIE : set-auto-config cisdGuard* → auto-trade-status.cisdGuard
 *       reflète les cases (up/down/swingMode/confirm*) ;
 *   [A] L_LUCIEN, CASE UP DÉCOCHÉE : ordre CALL DIRECT sur le CISD seul
 *       (bucket %10==6, juste après sa clôture) — libellé « CISD Up direct
 *       (vérification désactivée) », AUCUNE attente du combiné ;
 *   [B] NINJA, CASE UP DÉCOCHÉE : ordre CALL PENDANT le bucket CISD seul
 *       (%10==5, ofs ≥ 2) — ordre direct AVANT clôture ;
 *   [C] MODE « SWING VIOLÉ » : le CISD seul (swing INTACT dans cette
 *       géométrie) est REFUSÉ (« INTACT alors que le mode exige un swing
 *       VIOLÉ »), le combiné est refusé « SANS CISD Up vérifié préalable »
 *       → AUCUN ordre ;
 *   [D] RETOUR MODE « INTACT » : ARMÉE au CISD seul puis CALL au combiné,
 *       libellé « CISD Up confirmé (armé bougie T, swing P intact) » ;
 *   [E] CASE « BOS Up + CISD Up » DÉCOCHÉE : le combiné BOS (seul signal
 *       produit par ce flux) est refusé « NON ACCEPTÉ » → AUCUN ordre.
 *
 * Exécution : node tests/test-v24-cisd-config-e2e.mjs
 */
import { spawn } from 'node:child_process';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { io } from 'socket.io-client';
import { MockPoBroker } from './mock-po-broker.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const BACKEND_DIR = path.resolve(__dirname, '..');
const BACKEND_PORT = 3030; // socket.io backend (codé en dur dans index.ts)

const RULE_EXPIRY = 4;    // expiration de la RÈGLE (jamais le global)
const GLOBAL_EXPIRY = 37; // piège : si le global fuit, on le voit

/** Corps signés par bucket (cycle de 10) — cf. test-v23-cisd-e2e.mjs. */
const PATH_SCRIPT = [3, -2, 1, -2.5, 0.5, 5, -1, 1, -0.5, 1.5];

let failures = 0, checks = 0;
function ok(cond, label) {
  checks++;
  if (cond) console.log(`  ✓ ${label}`);
  else { failures++; console.error(`  ✗ ${label}`); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

function main() {
  console.log('\n=== E2E v24 — Étapes de vérification CISD optionnelles (backend réel + faux broker S5) ===\n');

  const broker = new MockPoBroker({
    httpPort: 4550,             // ports dédiés — aucun conflit
    wsPort: 4551,
    candleSec: 5,
    settleDelayMs: 2500,
    historyBuckets: 300,
    pathScript: PATH_SCRIPT,    // géométrie exacte (CISD seul → combiné)
    bodySize: 0.00012,         // B
    wickSize: 0.00004,         // W (croisements STRICTS des swings)
    realtimeClosePush: true,    // chemin réel de règlement
    outcomeScript: ['win'],     // déterministe — le E2E teste le placement
  });
  let backend = null;
  let socket = null;

  const cleanupAll = (code) => {
    try {
      if (backend && backend.exitCode === null) {
        try { process.kill(-backend.pid, 'SIGKILL'); }
        catch { try { backend.kill('SIGKILL'); } catch { /* ignore */ } }
      }
    } catch { /* ignore */ }
    try { broker.stop(); } catch { /* ignore */ }
    try { if (socket) socket.close(); } catch { /* ignore */ }
    if (code != null) {
      console.log(`\n=== RÉSULTAT E2E v24 : ${checks - failures}/${checks} vérifications OK ===`);
      process.exit(failures > 0 ? 1 : code);
    }
  };
  process.on('SIGINT', () => cleanupAll(130));
  process.on('uncaughtException', e => { console.error('UNCAUGHT:', e); cleanupAll(1); });

  (async () => {
    // ── 1. Faux broker ──
    const ports = await broker.start();
    console.log(`[1] faux broker PO démarré (http :${ports.httpPort}, ws :${ports.wsPort})`);

    // ── 2. VRAI backend, redirigé vers le faux broker ──
    console.log('[2] démarrage du VRAI backend (tsx index.ts)…');
    const backendLog = fs.openSync(path.join(BACKEND_DIR, 'e2e-v24-cisd-config.log'), 'w');
    backend = spawn('npx', ['tsx', 'index.ts'], {
      cwd: BACKEND_DIR,
      env: {
        ...process.env,
        PO_API_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_WEB_BASE_URL: `http://127.0.0.1:${ports.httpPort}`,
        PO_DEMO_WS_URL: `ws://127.0.0.1:${ports.wsPort}`,
        SESSION_SNAPSHOT_DIR: '0',
        PO_STARTUP_RANDOM_ASSET: '0',
        SOCIAL_DEBUG_PORT: '4350',
        NODE_ENV: 'development',
      },
      stdio: ['ignore', backendLog, backendLog],
      detached: true,
    });

    let connected = false;
    for (let i = 0; i < 40 && !connected; i++) {
      await sleep(500);
      socket = io(`http://127.0.0.1:${BACKEND_PORT}`, { transports: ['websocket'], path: '/', reconnection: false, timeout: 3000 });
      connected = await new Promise(r => { socket.once('connect', () => r(true)); socket.once('connect_error', () => r(false)); });
      if (!connected) { try { socket.close(); } catch { /* ignore */ } }
    }
    ok(connected, `backend joignable sur :${BACKEND_PORT} (socket.io connecté)`);
    if (!connected) { cleanupAll(1); return; }

    // ── 3. Login + sélection + règles ──
    console.log('[3] login démo sur le faux broker…');
    const loginResult = await new Promise(r => {
      socket.once('login-result', r);
      socket.emit('login', { email: 'demo@e2e.test', password: 'demo-pass', mode: 'demo' });
      setTimeout(() => r({ ok: false, error: 'timeout login' }), 30000);
    });
    ok(loginResult?.ok === true, `login démo OK (uid=${loginResult?.user_id ?? '?'})`);
    if (!loginResult?.ok) { console.error('login échoué:', loginResult); cleanupAll(1); return; }

    socket.emit('set-config', { candleSize: 5, cooldownSeconds: 3, expirySeconds: GLOBAL_EXPIRY });
    await sleep(300);

    const selected = await new Promise(r => {
      socket.once('assets-selected', r);
      socket.emit('select-assets', { mode: 'single', assets: ['EURUSD_otc'] });
      setTimeout(() => r({ ok: false }), 15000);
    });
    ok(selected?.ok === true, 'asset sélectionné : EURUSD_otc (mode single)');

    socket.emit('set-auto-strategy', { strategyId: 'l_lucien_protrader' });
    await sleep(200);
    socket.emit('set-auto-config', { bettingStrategy: 'fixed', baseAmount: 1 });
    await sleep(300);

    // Règle CISD (LA cible de la mission) + PUT symétrique.
    socket.emit('set-auto-config', {
      bosChochCisdCallRules: [{ id: 'call-1', alerts: ['CISD Up'], expirationSeconds: RULE_EXPIRY }],
      bosChochCisdPutRules: [{ id: 'put-1', alerts: ['CISD Down'], expirationSeconds: RULE_EXPIRY }],
    });
    await sleep(300);

    // ── 4. [0] PLOMBERIE : les cases voyagent jusqu'au statut ──
    console.log('[4] Phase 0 — plomberie set-auto-config cisdGuard* → auto-trade-status');
    {
      const status = await new Promise(r => {
        socket.once('auto-trade-status', r);
        socket.emit('set-auto-config', {
          cisdGuardUp: false,
          cisdGuardDown: true,
          cisdGuardSwingMode: 'violated',
          cisdGuardConfirmBosUp: false,
          cisdGuardConfirmChochUp: true,
          cisdGuardConfirmBosDown: false,
          cisdGuardConfirmChochDown: false,
        });
        setTimeout(() => r(null), 5000);
      });
      const g = status?.cisdGuard;
      ok(!!g, 'auto-trade-status porte cisdGuard');
      ok(g?.up === false, 'case « Vérifier CISD UP » décochée visible dans le statut');
      ok(g?.down === true, 'case « Vérifier CISD DOWN » cochée visible dans le statut');
      ok(g?.swingMode === 'violated', 'mode swing VIOLÉ visible dans le statut');
      ok(g?.confirmBosUp === false && g?.confirmChochUp === true, 'cases combinaisons CALL visibles (BOS ✗ / CHoCH ✓)');
      ok(g?.confirmBosDown === false && g?.confirmChochDown === false, 'cases combinaisons PUT visibles (toutes ✗)');
    }

    // ── Collecte globale ──
    const orders = [];
    const strategyStates = [];
    let phase = 'A';
    socket.on('trade-opened', (ev) => {
      if (ev?.source === 'l_lucien_protrader' || ev?.source === 'ninja_protrader') {
        orders.push({
          phase,
          source: ev.source,
          label: String(ev?.label ?? ''),
          expirationSeconds: Number(ev.expirationSeconds ?? 0),
          openTime: Number(ev.deal?.openTime ?? 0),
          action: String(ev.deal?.action ?? ''),
        });
        const o = orders[orders.length - 1];
        console.log(`    [ordre #${orders.length} · phase ${phase} · ${ev.source}] ${o.action.toUpperCase()} exp=${o.expirationSeconds}s bucketPos10=${Math.floor(o.openTime / 5) % 10} ofs=${o.openTime % 5} — ${o.label}`);
      }
    });
    socket.on('strategy-state', (st) => {
      if (st?.asset === 'EURUSD_otc') {
        strategyStates.push({
          phase,
          strategyName: String(st?.strategyName ?? ''),
          reason: String(st?.reason ?? ''),
          cisdConfirmation: st?.cisdConfirmation ?? null,
          cisdGuard: st?.bosChochCisd?.cisdGuard ?? null,
          action: String(st?.action ?? ''),
        });
      }
    });

    // ── 5. [A] L_Lucien, case UP décochée → ordre DIRECT sur le CISD seul ──
    console.log('[5] Phase A — L_Lucien : case UP décochée → CALL direct sur le CISD seul (aucune attente du combiné)…');
    {
      // up reste décochée ; on repasse le reste en défaut (intact, tout coché).
      await new Promise(r => {
        socket.once('auto-trade-status', r);
        socket.emit('set-auto-config', { cisdGuardUp: false, cisdGuardSwingMode: 'intact', cisdGuardConfirmBosUp: true, cisdGuardConfirmChochUp: true, cisdGuardConfirmBosDown: true, cisdGuardConfirmChochDown: true });
        setTimeout(() => r(null), 5000);
      });
      // SYNCHRONISATION DE PHASE : activer l'auto-trade pendant les buckets
      // 6-7 du cycle — la bougie CLÔTURÉE la plus récente est alors le CISD
      // seul (%10==5) → l'ordre direct part IMMÉDIATEMENT (bucket 6-8), sans
      // attendre le combiné. (Activer aux buckets 0-4 ferait matcher le
      // combiné %10==9 clôturé — ordre direct valide mais moins démonstratif.)
      while (![6, 7].includes(Math.floor(Date.now() / 5000) % 10)) await sleep(500);
      const autoOn = await new Promise(r => {
        socket.once('auto-trade-status', r);
        socket.emit('set-auto-trade', { enabled: true });
        setTimeout(() => r(null), 10000);
      });
      ok(autoOn?.enabled !== false, 'auto-trade ON');
      ok(autoOn?.cisdGuard?.up === false && autoOn?.cisdGuard?.swingMode === 'intact', 'statut : case UP décochée + mode intact confirmés avant la phase A');

      const aOrderIdx = orders.length;
      const deadline = Date.now() + 75_000; // 1 cycle + marge
      while (orders.length <= aOrderIdx && Date.now() < deadline) await sleep(1000);
      const a = orders[aOrderIdx];
      ok(!!a, 'ordre L_Lucien placé sur le CISD SEUL (case décochée — comportement v22 restauré)');
      if (a) {
        ok(a.source === 'l_lucien_protrader' && a.action === 'call', 'ordre A = CALL (L_Lucien)');
        ok(a.label.includes('CISD Up direct (vérification désactivée)'), 'libellé A : « CISD Up direct (vérification désactivée) »', a.label);
        ok(!a.label.includes('confirmé'), 'libellé A : AUCUNE confirmation CISD (pas de séquence)');
        ok(a.expirationSeconds === RULE_EXPIRY, `expiration A = ${RULE_EXPIRY}s (règle) — le global ${GLOBAL_EXPIRY}s n'a jamais fuité`);
        // L'évaluation porte sur le bucket %10==5 clôturé (CISD seul) → l'ordre
        // part dans la seconde qui suit (bucket 6-8) — PAS au combiné (%10==9→0).
        ok([6, 7, 8].includes(Math.floor(a.openTime / 5) % 10), `ordre A part juste après la clôture du CISD seul (bucket %10=${Math.floor(a.openTime / 5) % 10})`);
      }
      const statesA = strategyStates.filter(s => s.phase === 'A' && s.cisdGuard);
      ok(statesA.length > 0 && statesA.every(s => s.cisdGuard.up === false), 'strategy-state transporte bosChochCisd.cisdGuard (up=false)');
      ok(statesA.some(s => s.reason.includes('désactivée : ordre direct')), 'le reason documente « vérification CISD Up désactivée : ordre direct »');
    }

    // ── 6. [B] Ninja, case UP décochée → ordre PENDANT le bucket CISD seul ──
    console.log('[6] Phase B — Ninja ProTrader : case UP décochée → ordre AVANT la clôture du CISD seul…');
    {
      phase = 'B';
      // SYNCHRONISATION : basculer sur Ninja pendant les buckets 0-4 — le
      // prochain événement en formation est alors le CISD seul (%10==5) et
      // l'ordre direct partira PENDANT cette bougie (bucket %10==5).
      while (Math.floor(Date.now() / 5000) % 10 >= 5) await sleep(500);
      socket.emit('set-auto-strategy', { strategyId: 'ninja_protrader' });
      await sleep(300);
      const bOrderIdx = orders.length;
      const deadline = Date.now() + 75_000;
      while (orders.length <= bOrderIdx && Date.now() < deadline) await sleep(1000);
      const b = orders[bOrderIdx];
      ok(!!b, 'ordre Ninja placé directement (case UP décochée, sans attendre de séquence)');
      if (b) {
        ok(b.source === 'ninja_protrader' && b.action === 'call', 'ordre B = CALL (Ninja)');
        ok(b.label.includes('CISD Up direct (vérification désactivée)'), 'libellé B : « CISD Up direct (vérification désactivée) »');
        // PREUVE : l'ordre part PENDANT le bucket du CISD seul (%10==5),
        // franchissement du swing atteint (ofs ≥ 1 ± alignement des ticks).
        ok(Math.floor(b.openTime / 5) % 10 === 5, `ordre B placé PENDANT la bougie CISD seule (bucket %10=${Math.floor(b.openTime / 5) % 10})`);
        ok(b.openTime % 5 >= 1 && b.openTime % 5 <= 4, `ordre B AVANT la clôture (ofs=${b.openTime % 5} dans le bucket de 5 s)`);
      }
    }

    // ── 7. [C] Mode « swing VIOLÉ » → le flux (swing intact) ne trade plus ──
    console.log('[7] Phase C — mode « swing VIOLÉ » : CISD intact refusé, combiné sans armement refusé → AUCUN ordre…');
    {
      phase = 'C';
      socket.emit('set-auto-strategy', { strategyId: 'l_lucien_protrader' });
      await sleep(200);
      await new Promise(r => {
        socket.once('auto-trade-status', r);
        socket.emit('set-auto-config', { cisdGuardUp: true, cisdGuardSwingMode: 'violated' });
        setTimeout(() => r(null), 5000);
      });
      const cOrderIdx = orders.length;
      const deadline = Date.now() + 80_000; // ~1.5 cycle : refus au CISD seul ET au combiné
      while (Date.now() < deadline) await sleep(1000);
      ok(orders.length === cOrderIdx, `AUCUN ordre en mode « swing violé » sur un flux au swing intact (${orders.length - cOrderIdx} en 80 s)`);
      const intactRefused = strategyStates.filter(s => s.phase === 'C' && s.reason.includes('INTACT alors que le mode exige un swing VIOLÉ'));
      ok(intactRefused.length > 0, `strategy-state « swing INTACT alors que le mode exige un swing VIOLÉ » observé (${intactRefused.length} états)`);
      ok(intactRefused.every(s => s.action === 'hold'), 'les CISD seuls (swing intact) restent HOLD en mode violé');
      const noArmedC = strategyStates.filter(s => s.phase === 'C' && s.reason.includes('ARMÉE'));
      ok(noArmedC.length === 0, `AUCUN armement en mode « violé » (swing intact) (${noArmedC.length} états ARMÉE)`);
      const refusedC = strategyStates.filter(s => s.phase === 'C' && s.reason.includes('SANS CISD Up vérifié préalable'));
      ok(refusedC.length > 0, `strategy-state « SANS CISD Up vérifié préalable » observé (${refusedC.length} états) — le combiné exige un armement`);
    }

    // ── 8. [D] Retour au mode « intact » → ARMÉE puis CALL confirmé ──
    console.log('[8] Phase D — retour au mode « swing non violé » : ARMÉE au CISD seul puis CALL au combiné…');
    {
      phase = 'D';
      await new Promise(r => {
        socket.once('auto-trade-status', r);
        socket.emit('set-auto-config', { cisdGuardSwingMode: 'intact' });
        setTimeout(() => r(null), 5000);
      });
      const dOrderIdx = orders.length;
      const deadline = Date.now() + 125_000; // 2 cycles + marge
      while (orders.length <= dOrderIdx && Date.now() < deadline) await sleep(1000);
      const d = orders[dOrderIdx];
      ok(!!d, 'ordre CALL placé après retour au mode intact (séquence ARMÉE → combiné)');
      if (d) {
        ok(d.source === 'l_lucien_protrader' && d.action === 'call', 'ordre D = CALL (L_Lucien)');
        ok(d.label.includes('CISD Up confirmé (armé bougie'), 'libellé D : « CISD Up confirmé (armé bougie …) »', d.label);
        ok(d.label.includes('intact'), 'libellé D : swing intact documenté');
        ok(!d.label.includes('direct'), 'libellé D : pas de mention « direct » (la protection est active)');
        ok(Math.floor(d.openTime / 5) % 10 === 0, `ordre D part après la clôture du combiné (bucket %10=${Math.floor(d.openTime / 5) % 10})`);
      }
      const armeeD = strategyStates.filter(s => s.phase === 'D' && s.reason.includes('ARMÉE'));
      ok(armeeD.length > 0, `strategy-state « séquence ARMÉE » réapparait en mode intact (${armeeD.length} états)`);
      const confirmD = strategyStates.filter(s => s.phase === 'D' && s.cisdConfirmation);
      ok(confirmD.length > 0 && confirmD.every(s => s.cisdConfirmation.direction === 'up'), 'cisdConfirmation (up) transportée à nouveau');
    }

    // ── 9. [E] Case « BOS Up + CISD Up » décochée → combiné refusé ──
    console.log('[9] Phase E — case « BOS Up + CISD Up » décochée : le combiné BOS ne confirme plus…');
    {
      phase = 'E';
      await new Promise(r => {
        socket.once('auto-trade-status', r);
        socket.emit('set-auto-config', { cisdGuardConfirmBosUp: false, cisdGuardConfirmChochUp: true });
        setTimeout(() => r(null), 5000);
      });
      const eOrderIdx = orders.length;
      const deadline = Date.now() + 80_000; // ~1.5 cycle
      while (Date.now() < deadline) await sleep(1000);
      ok(orders.length === eOrderIdx, `AUCUN ordre avec « BOS Up + CISD Up » décochée (${orders.length - eOrderIdx} en 80 s)`);
      const nonAccepte = strategyStates.filter(s => s.phase === 'E' && s.reason.includes('NON ACCEPTÉ'));
      ok(nonAccepte.length > 0, `strategy-state « NON ACCEPTÉ comme confirmation » observé (${nonAccepte.length} états)`);
      ok(nonAccepte.every(s => s.action === 'hold'), 'le combiné BOS (non coché) reste HOLD — séquence consommée sans ordre');
      const armeeE = strategyStates.filter(s => s.phase === 'E' && s.reason.includes('ARMÉE'));
      ok(armeeE.length > 0, `l'armement a bien eu lieu avant le refus (${armeeE.length} états ARMÉE)`);
      ok(armeeE.every(s => s.reason.includes('CHoCH Up + CISD Up') || s.reason.includes('BOS Up + CISD Up')), 'l\u2019armement ne propose QUE les combinaisons cochées (CHoCH)');
    }

    cleanupAll(failures > 0 ? 1 : 0);
  })().catch(e => { console.error('ERREUR E2E:', e); cleanupAll(1); });
}

main();
