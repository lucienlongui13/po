/**
 * test-multi-assets.ts — TESTS D'ISOLATION MULTI-ASSETS (§35/§36).
 * =================================================================
 *
 * Valide l'architecture des contextes indépendants par asset SANS serveur :
 * le module asset-contexts.ts est pur (aucune dépendance socket/io).
 *
 * Scénarios exigés par le cahier des charges :
 *
 *   TEST 1  Sélection de 1 asset (EURUSD)            → mode single, 1 asset
 *   TEST 2  Sélection de 3 assets                    → mode multi, 3 assets
 *   TEST 3  Tentative de sélectionner 11 assets      → REJET
 *   TEST 4  EURUSD LOSS                              → EURUSD martingale++,
 *                                                       XAUUSD/BTCUSD INTACTS
 *   TEST 5  XAUUSD WIN                               → XAUUSD reset SEUL
 *   TEST 6  EURUSD : état d’exécution isolé             → autres assets INTACTS
 *   TEST 7  BTCUSD PUT                               → aucun ordre PUT sur
 *                                                       EURUSD/XAUUSD
 *   TEST 8  deal_closed(asset=XAUUSD)                → SEUL XAUUSD modifié
 *   TEST 9  Reconnexion                              → tous les assets
 *                                                       resubscrits
 *   TEST 10 Focus XAUUSD                             → les autres assets
 *                                                       CONTINUENT d'être
 *                                                       traités
 *   TEST §36 NON-CONTAMINATION : EURUSD=LOSS, XAUUSD=WIN, BTCUSD=LOSS →
 *           vérification EXACTE des 3 contextes (doit réussir
 *           systématiquement).
 *
 * Exécution : node --import tsx tests/test-multi-assets.ts
 * (ou via le runner de transpilation — voir scripts du projet).
 */

import {
  AssetContextRegistry,
  createAssetContext,
  computeBettingAmount,
  MARTINGALE_MULTIPLIER,
  updateBettingAfterResult,
  applyDealResult,
  noteDealOpened,
  noteDealClosed,
  assertAssetContext,
  validateAssetSelection,
  planResubscription,
  shouldProcessAssetTick,
  assetLog,
  MAX_SELECTED_ASSETS,
  FIBONACCI_STEPS,
  type AssetTradingContext,
} from '../asset-contexts.js';
import {
  snapExpiry,
  resolveAutoTradeExpiry,
  AUTO_TRADE_MIN_EXPIRY,
  AUTO_TRADE_MAX_EXPIRY,
  BROKER_SUPPORTED_EXPIRIES,
} from '../expiry.js';
import { getMarket, MARKETS_CATALOG } from '../markets-catalog.js';
import type { OpenedDeal } from '../pocket-option-sdk/src/index.js';

// ─────────────────────────────────────────────────────────────────────────────
//  Mini-harnais de test
// ─────────────────────────────────────────────────────────────────────────────

let passed = 0;
let failed = 0;
const failures: string[] = [];

function check(name: string, cond: boolean, detail?: string): void {
  if (cond) {
    passed++;
    console.log(`  ✓ ${name}`);
  } else {
    failed++;
    failures.push(`${name}${detail ? ` — ${detail}` : ''}`);
    console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`);
  }
}

function section(title: string): void {
  console.log(`\n${title}`);
  console.log('='.repeat(72));
}

/** Fabrique un contexte de test (Martingale par défaut, base 1$). */
function makeCtx(asset: string, bettingStrategy: 'fixed' | 'martingale' | 'fibonacci' = 'martingale'): AssetTradingContext {
  return createAssetContext(asset, { bettingStrategy, baseAmount: 1 });
}

/** Simule un deal ouvert par le moteur d'auto-trade (§17). */
function placeTrackedDeal(ctx: AssetTradingContext, dealId: string, amount = 1, expiry = 60): void {
  const deal = { id: dealId, asset: ctx.asset, action: 'call', amount, openPrice: 1, openTime: 0, expireTime: 0, time: expiry } as unknown as OpenedDeal;
  ctx.trackedDeals.set(dealId, { asset: ctx.asset, amount, expirationSeconds: expiry });
  noteDealOpened(ctx, deal);
  ctx.stats.trades++;
}

// ─────────────────────────────────────────────────────────────────────────────
//  TEST 1 — Sélection de 1 asset : mode single, 1 asset
// ─────────────────────────────────────────────────────────────────────────────
section('TEST 1 — Sélection de 1 asset (EURUSD) → mode single');

{
  const r = validateAssetSelection({ mode: 'single', assets: ['EURUSD_otc'] });
  check('validation ok', r.ok);
  check('mode = single', r.mode === 'single');
  check('assets.length = 1', r.assets.length === 1);
  check('asset = EURUSD_otc', r.assets[0] === 'EURUSD_otc');

  // Le mode multi avec 1 asset est aussi accepté (l'utilisateur peut ajouter
  // ensuite) — comportement documenté.
  const r2 = validateAssetSelection({ mode: 'multi', assets: ['EURUSD_otc'] });
  check('multi avec 1 asset accepté', r2.ok && r2.mode === 'multi');
}

// ─────────────────────────────────────────────────────────────────────────────
//  TEST 2 — Sélection de 3 assets : mode multi
// ─────────────────────────────────────────────────────────────────────────────
section('TEST 2 — Sélection de 3 assets (EURUSD, XAUUSD, BTCUSD) → mode multi');

{
  const r = validateAssetSelection({ mode: 'multi', assets: ['EURUSD_otc', 'XAUUSD_otc', 'BTCUSD_otc'] });
  check('validation ok', r.ok);
  check('mode = multi', r.mode === 'multi');
  check('assets.length = 3', r.assets.length === 3);
  check('ordre préservé', r.assets.join(',') === 'EURUSD_otc,XAUUSD_otc,BTCUSD_otc');

  // Doublons supprimés côté backend (§3) :
  const rd = validateAssetSelection({ mode: 'multi', assets: ['EURUSD_otc', 'EURUSD_otc', 'XAUUSD_otc', 'XAUUSD_otc'] });
  check('doublons supprimés (2 assets)', rd.ok && rd.assets.length === 2 && rd.deduped === true);

  // Entrées invalides ignorées :
  const ri = validateAssetSelection({ mode: 'multi', assets: ['EURUSD_otc', '', undefined, 42, 'XAUUSD_otc'] as unknown as string[] });
  check('entrées invalides ignorées', ri.ok && ri.assets.length === 2);

  // mode single avec 2 assets → rejet :
  const rs = validateAssetSelection({ mode: 'single', assets: ['EURUSD_otc', 'XAUUSD_otc'] });
  check('single avec 2 assets → REJET', !rs.ok);

  // mode invalide → rejet :
  const rm = validateAssetSelection({ mode: 'grid', assets: ['EURUSD_otc'] });
  check('mode invalide → REJET', !rm.ok);
}

// ─────────────────────────────────────────────────────────────────────────────
//  TEST 3 — Tentative de sélectionner 25 assets → REJET (v6.3 : limite 24)
// ─────────────────────────────────────────────────────────────────────────────
section('TEST 3 — Tentative de sélectionner 25 assets → REJET (backend, limite v6.3 = 24)');

{
  const twentyFive = Array.from({ length: 25 }, (_, i) => `ASSET${i}_otc`);
  const r = validateAssetSelection({ mode: 'multi', assets: twentyFive });
  check('25 assets → REJET', !r.ok);
  check("message d'erreur explicite", (r.error ?? '').includes('24'));
  check('limite = 24 (v6.3 : 10 + 14 demandés par l\'utilisateur)', MAX_SELECTED_ASSETS === 24);

  // Exactement 24 → accepté (la limite est INCLUSIVE)
  const twentyFour = Array.from({ length: 24 }, (_, i) => `ASSET${i}_otc`);
  const r24 = validateAssetSelection({ mode: 'multi', assets: twentyFour });
  check('24 assets → ACCEPTÉ', r24.ok && r24.assets.length === 24);

  // 25 entrées avec doublons → 24 dédupliqués → accepté (les doublons ne
  // comptent pas double) :
  const dup = [...twentyFour, twentyFour[0], twentyFour[1]];
  const rd = validateAssetSelection({ mode: 'multi', assets: dup });
  check('26 avec doublons → dédupliqué → accepté (24)', rd.ok && rd.assets.length === 24);

  // 0 asset → rejet
  const r0 = validateAssetSelection({ mode: 'multi', assets: [] });
  check('0 asset → REJET', !r0.ok);
}

// ─────────────────────────────────────────────────────────────────────────────
//  TEST 4 — EURUSD LOSS → martingale++ UNIQUEMENT sur EURUSD
// ─────────────────────────────────────────────────────────────────────────────
section('TEST 4 — EURUSD LOSS : EURUSD martingale++ ; XAUUSD/BTCUSD INTACTS');

{
  const registry = new AssetContextRegistry();
  for (const a of ['EURUSD_otc', 'XAUUSD_otc', 'BTCUSD_otc']) {
    registry.ensureAssetContext(a, { bettingStrategy: 'martingale', baseAmount: 1 });
  }
  const eurusd = registry.requireAssetContext('EURUSD_otc');
  const xauusd = registry.requireAssetContext('XAUUSD_otc');
  const btcusd = registry.requireAssetContext('BTCUSD_otc');

  // Les 3 assets ont chacun un deal suivi.
  placeTrackedDeal(eurusd, 'deal-eurusd-1');
  placeTrackedDeal(xauusd, 'deal-xauusd-1');
  placeTrackedDeal(btcusd, 'deal-btcusd-1');

  // EURUSD LOSS (deal_closed EURUSD).
  const res = applyDealResult(eurusd, 'deal-eurusd-1', false);

  check('résultat LOSS retourné', res !== null && res.isWin === false);
  check('EURUSD.losses = 1', eurusd.stats.losses === 1);
  check('EURUSD.consecutiveLosses = 1 (martingale++)', eurusd.betting.consecutiveLosses === 1);
  check('EURUSD.fibIndex = 1', eurusd.betting.fibIndex === 1);
  check('prochaine mise EURUSD = 2$ (martingale ×2)', computeBettingAmount(eurusd) === 2);
  check('EURUSD trackedDeals vidée', !eurusd.trackedDeals.has('deal-eurusd-1'));

  // XAUUSD et BTCUSD : AUCUNE modification (§18).
  check('XAUUSD.losses = 0', xauusd.stats.losses === 0);
  check('XAUUSD.consecutiveLosses = 0 (INTACT)', xauusd.betting.consecutiveLosses === 0);
  check('XAUUSD mise = 1$ (INTACTE)', computeBettingAmount(xauusd) === 1);
  check('XAUUSD trackedDeals conservé', xauusd.trackedDeals.has('deal-xauusd-1'));
  check('BTCUSD.losses = 0', btcusd.stats.losses === 0);
  check('BTCUSD.consecutiveLosses = 0 (INTACT)', btcusd.betting.consecutiveLosses === 0);
  check('BTCUSD mise = 1$ (INTACTE)', computeBettingAmount(btcusd) === 1);
  check('BTCUSD trackedDeals conservé', btcusd.trackedDeals.has('deal-btcusd-1'));
}

// ─────────────────────────────────────────────────────────────────────────────
//  TEST 5 — XAUUSD WIN → reset UNIQUEMENT sur XAUUSD
// ─────────────────────────────────────────────────────────────────────────────
section('TEST 5 — XAUUSD WIN : reset XAUUSD SEUL ; EURUSD/BTCUSD INTACTS');

{
  const eurusd = makeCtx('EURUSD_otc', 'martingale');
  const xauusd = makeCtx('XAUUSD_otc', 'martingale');
  const btcusd = makeCtx('BTCUSD_otc', 'martingale');

  // État initial : EURUSD a 2 pertes consécutives, XAUUSD 3, BTCUSD 1.
  updateBettingAfterResult(eurusd, false);
  updateBettingAfterResult(eurusd, false);
  updateBettingAfterResult(xauusd, false);
  updateBettingAfterResult(xauusd, false);
  updateBettingAfterResult(xauusd, false);
  updateBettingAfterResult(btcusd, false);
  check('pré-état EURUSD=2, XAUUSD=3, BTCUSD=1',
    eurusd.betting.consecutiveLosses === 2
    && xauusd.betting.consecutiveLosses === 3
    && btcusd.betting.consecutiveLosses === 1);

  // XAUUSD WIN → reset de XAUUSD UNIQUEMENT (§19).
  placeTrackedDeal(xauusd, 'deal-x-1');
  const res = applyDealResult(xauusd, 'deal-x-1', true);

  check('résultat WIN retourné', res !== null && res.isWin === true);
  check('XAUUSD.consecutiveLosses = 0 (reset)', xauusd.betting.consecutiveLosses === 0);
  check('XAUUSD.wins = 1', xauusd.stats.wins === 1);
  check('XAUUSD mise revenue à 1$', computeBettingAmount(xauusd) === 1);
  check('EURUSD.consecutiveLosses TOUJOURS = 2 (INTACT)', eurusd.betting.consecutiveLosses === 2);
  check('EURUSD mise TOUJOURS 4$', computeBettingAmount(eurusd) === 4);
  check('BTCUSD.consecutiveLosses TOUJOURS = 1 (INTACT)', btcusd.betting.consecutiveLosses === 1);
  check('BTCUSD mise TOUJOURS 2$', computeBettingAmount(btcusd) === 2);
}

// ─────────────────────────────────────────────────────────────────────────────
//  TEST 6 — EURUSD trade simulé → états des autres assets INTACTS
// ─────────────────────────────────────────────────────────────────────────────
section('TEST 6 — EURUSD : état d’exécution isolé : XAUUSD/BTCUSD INTACTS');

{
  const registry = new AssetContextRegistry();
  for (const a of ['EURUSD_otc', 'XAUUSD_otc', 'BTCUSD_otc']) {
    registry.ensureAssetContext(a, {});
  }
  const eurusd = registry.requireAssetContext('EURUSD_otc');
  const xauusd = registry.requireAssetContext('XAUUSD_otc');
  const btcusd = registry.requireAssetContext('BTCUSD_otc');

  // Chaque contexte possède SON PROPRE état d’exécution (§10/§11).

  // L'état d'exécution est ISOLÉ PAR ASSET : un trade simulé sur BTCUSD ne
  // touche NI les compteurs ni les horodatages d'EURUSD/XAUUSD (§12/§13).
  btcusd.autoTrade.lastTradeTs = 123456;
  btcusd.autoTrade.lastTradeAction = 'put';
  check('BTCUSD a SON dernier trade', btcusd.autoTrade.lastTradeTs === 123456 && btcusd.autoTrade.lastTradeAction === 'put');
  check('EURUSD trade INTACT (aucun trade)', eurusd.autoTrade.lastTradeTs === 0 && eurusd.autoTrade.lastTradeAction === null);
  check('XAUUSD trade INTACT (aucun trade)', xauusd.autoTrade.lastTradeTs === 0 && xauusd.autoTrade.lastTradeAction === null);
  check('XAUUSD : AUCUN ordre (trackedDeals vide)', xauusd.trackedDeals.size === 0);
  check('XAUUSD : AUCUNE action', xauusd.autoTrade.lastTradeAction === null);
  check('XAUUSD stats.trades = 0', xauusd.stats.trades === 0);

  // Vérification d'intégrité (§32) : un traitement critique avec le MAUVAIS
  // contexte doit ÉCHOUER bruyamment.
  let threw = false;
  try {
    assertAssetContext('EURUSD_otc', btcusd);
  } catch {
    threw = true;
  }
  check('assertAssetContext(EURUSD, ctx BTCUSD) → THROW (§32)', threw);

  let threw2 = false;
  try {
    assertAssetContext('EURUSD_otc', null as unknown as AssetTradingContext);
  } catch {
    threw2 = true;
  }
  check('assertAssetContext(EURUSD, null) → THROW', threw2);

  // Le BON contexte ne jette jamais :
  let okNoThrow = true;
  try {
    assertAssetContext('BTCUSD_otc', btcusd);
  } catch {
    okNoThrow = false;
  }
  check('assertAssetContext(BTCUSD, ctx BTCUSD) → OK', okNoThrow);
}

// ─────────────────────────────────────────────────────────────────────────────
//  TEST 8 — deal_closed(asset = XAUUSD) → SEUL le contexte XAUUSD est modifié
// ─────────────────────────────────────────────────────────────────────────────
section('TEST 8 — deal_closed(XAUUSD) : seul le contexte XAUUSD change');

{
  const registry = new AssetContextRegistry();
  for (const a of ['EURUSD_otc', 'XAUUSD_otc', 'BTCUSD_otc']) {
    registry.ensureAssetContext(a, { bettingStrategy: 'fibonacci', baseAmount: 1 });
  }
  const eurusd = registry.requireAssetContext('EURUSD_otc');
  const xauusd = registry.requireAssetContext('XAUUSD_otc');
  const btcusd = registry.requireAssetContext('BTCUSD_otc');

  // Les 3 assets ont des positions ouvertes + deals suivis.
  placeTrackedDeal(eurusd, 'deal-e1');
  placeTrackedDeal(xauusd, 'deal-x1');
  placeTrackedDeal(btcusd, 'deal-b1');

  // LE handler deal_closed du backend fait EXACTEMENT ceci :
  //   const ctx = getAssetContext(deal.asset)   ← XAUUSD
  //   applyDealResult(ctx, dealKey, isWin)      ← SEUL XAUUSD est touché
  const closedCtx = registry.getAssetContext('XAUUSD_otc');
  check('getAssetContext(deal.asset=XAUUSD) → ctx XAUUSD', closedCtx === xauusd);
  const res = closedCtx ? applyDealResult(closedCtx, 'deal-x1', false) : null;

  check('deal XAUUSD traité (LOSS)', res !== null && res.isWin === false);
  check('XAUUSD.losses = 1', xauusd.stats.losses === 1);
  check('XAUUSD.fibIndex = 1 (progression fibonacci)', xauusd.betting.fibIndex === 1);
  check('XAUUSD.openPositions vidée', xauusd.openPositions.length === 0);
  check('EURUSD.losses TOUJOURS = 0', eurusd.stats.losses === 0);
  check('EURUSD.fibIndex TOUJOURS = 0', eurusd.betting.fibIndex === 0);
  check('EURUSD.openPositions TOUJOURS 1', eurusd.openPositions.length === 1);
  check('EURUSD trackedDeals TOUJOURS présent', eurusd.trackedDeals.has('deal-e1'));
  check('BTCUSD.losses TOUJOURS = 0', btcusd.stats.losses === 0);
  check('BTCUSD.fibIndex TOUJOURS = 0', btcusd.betting.fibIndex === 0);
  check('BTCUSD.openPositions TOUJOURS 1', btcusd.openPositions.length === 1);

  // noteDealClosed sur le MAUVAIS contexte ne corrompt rien :
  noteDealClosed(eurusd, 'deal-b1'); // ferme un id BTCUSD sur le ctx EURUSD → no-op
  check('noteDealClosed croisé = no-op (EURUSD garde sa position)', eurusd.openPositions.length === 1);
}

// ─────────────────────────────────────────────────────────────────────────────
//  TEST 9 — Connexion interrompue puis rétablie → tous les assets resubscrits
// ─────────────────────────────────────────────────────────────────────────────
section('TEST 9 — Reconnexion : tous les assets sélectionnés resubscrits (§31)');

{
  const selected = ['EURUSD_otc', 'GBPUSD_otc', 'XAUUSD_otc', 'BTCUSD_otc'];

  // Cas 1 : la reconnexion repart de ZÉRO subscription.
  const p1 = planResubscription(selected, []);
  check('0 subscription → 4 à resubscrire', p1.toSubscribe.length === 4 && p1.toSubscribe.join(',') === selected.join(','));
  check('rien à désabonner', p1.toUnsubscribe.length === 0);

  // Cas 2 : connexion PARTIELLEMENT rétablie (EURUSD seulement).
  const p2 = planResubscription(selected, ['EURUSD_otc']);
  check('EURUSD déjà abonné → 3 à resubscrire', p2.toSubscribe.length === 3);
  check('resubscribe = GBPUSD, XAUUSD, BTCUSD', p2.toSubscribe.join(',') === 'GBPUSD_otc,XAUUSD_otc,BTCUSD_otc');

  // Cas 3 : subscription obsolète (asset retiré de la sélection).
  const p3 = planResubscription(selected, ['EURUSD_otc', 'GBPUSD_otc', 'XAUUSD_otc', 'BTCUSD_otc', 'EURJPY_otc']);
  check('rien à resubscrire (tout est déjà là)', p3.toSubscribe.length === 0);
  check('EURJPY obsolète → à désabonner', p3.toUnsubscribe.join(',') === 'EURJPY_otc');

  // Cas 4 : sélection vide.
  const p4 = planResubscription([], ['EURUSD_otc']);
  check('sélection vide → désabonnement complet', p4.toSubscribe.length === 0 && p4.toUnsubscribe.length === 1);
}

// ─────────────────────────────────────────────────────────────────────────────
//  TEST 10 — Focus XAUUSD → les autres assets CONTINUENT d'être traités
// ─────────────────────────────────────────────────────────────────────────────
section('TEST 10 — Focus XAUUSD : EURUSD/GBPUSD/BTCUSD toujours traités (§26)');

{
  const selected = ['EURUSD_otc', 'GBPUSD_otc', 'XAUUSD_otc', 'BTCUSD_otc'];
  const focus = 'XAUUSD_otc'; // l'utilisateur affiche XAUUSD en plein écran

  // §26 : le focus n'arrête JAMAIS le traitement live des autres assets.
  // shouldProcessAssetTick ne dépend QUE de la sélection, pas du focus.
  for (const asset of selected) {
    check(`tick ${asset} TRAITÉ (focus = XAUUSD)`, shouldProcessAssetTick(selected, asset) === true);
  }
  // Un tick d'un asset NON sélectionné n'est jamais traité :
  check('tick EURJPY (non sélectionné) IGNORÉ', shouldProcessAssetTick(selected, 'EURJPY_otc') === false);
  check('tick vide IGNORÉ', shouldProcessAssetTick(selected, '') === false);

  // Le focus est un choix d'AFFICHAGE : il ne modifie ni le registre, ni
  // les états de mise, ni les contextes.
  const registry = new AssetContextRegistry();
  for (const a of selected) registry.ensureAssetContext(a, { bettingStrategy: 'martingale' });
  updateBettingAfterResult(registry.requireAssetContext('EURUSD_otc'), false);
  const focusCtx = registry.getAssetContext(focus);
  check('changement de focus = AUCUN effet sur le registre (4 contextes)', registry.size === 4 && focusCtx !== null);
  check('EURUSD martingale INTACTE malgré le focus XAUUSD', registry.requireAssetContext('EURUSD_otc').betting.consecutiveLosses === 1);
}

// ─────────────────────────────────────────────────────────────────────────────
//  TEST §36 — NON-CONTAMINATION (doit réussir systématiquement)
// ─────────────────────────────────────────────────────────────────────────────
section('TEST §36 — NON-CONTAMINATION : EURUSD=LOSS, XAUUSD=WIN, BTCUSD=LOSS');

{
  const registry = new AssetContextRegistry();
  const eurusd = registry.ensureAssetContext('EURUSD_otc', { bettingStrategy: 'martingale' });
  const xauusd = registry.ensureAssetContext('XAUUSD_otc', { bettingStrategy: 'martingale' });
  const btcusd = registry.ensureAssetContext('BTCUSD_otc', { bettingStrategy: 'martingale' });

  placeTrackedDeal(eurusd, 'nc-e');
  placeTrackedDeal(xauusd, 'nc-x');
  placeTrackedDeal(btcusd, 'nc-b');

  // Injection d'événements DIFFÉRENTS sur les 3 contextes.
  applyDealResult(eurusd, 'nc-e', false); // EURUSD = LOSS
  applyDealResult(xauusd, 'nc-x', true);  // XAUUSD = WIN
  applyDealResult(btcusd, 'nc-b', false); // BTCUSD = LOSS

  // Vérifications EXACTES exigées par §36 :
  check('EURUSD.losses = 1', eurusd.stats.losses === 1, `obtenu ${eurusd.stats.losses}`);
  check('EURUSD.consecutiveLosses = 1', eurusd.betting.consecutiveLosses === 1, `obtenu ${eurusd.betting.consecutiveLosses}`);
  check('XAUUSD.losses = 0', xauusd.stats.losses === 0, `obtenu ${xauusd.stats.losses}`);
  check('XAUUSD.consecutiveLosses = 0', xauusd.betting.consecutiveLosses === 0, `obtenu ${xauusd.betting.consecutiveLosses}`);
  check('BTCUSD.losses = 1', btcusd.stats.losses === 1, `obtenu ${btcusd.stats.losses}`);
  check('BTCUSD.consecutiveLosses = 1', btcusd.betting.consecutiveLosses === 1, `obtenu ${btcusd.betting.consecutiveLosses}`);
  check('XAUUSD.wins = 1 (le WIN est bien compté)', xauusd.stats.wins === 1);
  check('mises : EURUSD=2$, XAUUSD=1$, BTCUSD=2$',
    computeBettingAmount(eurusd) === 2 && computeBettingAmount(xauusd) === 1 && computeBettingAmount(btcusd) === 2);
}


// ─────────────────────────────────────────────────────────────────────────────
//  TEST MARTINGALE BOS — perte ×2, victoire retour mise initiale
// ─────────────────────────────────────────────────────────────────────────────
section('TEST BOS — Martingale ×2 / WIN → mise initiale');

{
  const bos = makeCtx('EURUSD_otc', 'martingale');
  bos.betting.baseAmount = 5;
  check('BOS Martingale — mise initiale = 5$', computeBettingAmount(bos) === 5);

  updateBettingAfterResult(bos, false);
  check(`BOS LOSS → ×${MARTINGALE_MULTIPLIER} = 10$`, computeBettingAmount(bos) === 10);

  updateBettingAfterResult(bos, false);
  check(`BOS 2e LOSS → ×${MARTINGALE_MULTIPLIER}² = 20$`, computeBettingAmount(bos) === 20);

  updateBettingAfterResult(bos, true);
  check('BOS WIN → retour exact à la mise initiale = 5$', computeBettingAmount(bos) === 5);
}

// ─────────────────────────────────────────────────────────────────────────────
//  TESTS COMPLÉMENTAIRES — déterminisme des mises (§16), fibonacci (§15),
//  arrêt d'asset (§30), logs (§37), catalogue
// ─────────────────────────────────────────────────────────────────────────────
section("COMPLÉMENTS — mises déterministes, fibonacci, arrêt d'asset, catalogue");

{
  // §16 — computeBettingAmount est DÉTERMINISTE depuis le contexte seul.
  const fixed = makeCtx('EURUSD_otc', 'fixed');
  fixed.betting.baseAmount = 5;
  updateBettingAfterResult(fixed, false);
  updateBettingAfterResult(fixed, false);
  check('fixed : mise = base (5$) quelles que soient les pertes', computeBettingAmount(fixed) === 5);

  // Martingale : chaque perte double réellement, sans plafond implicite.
  const mart = makeCtx('GBPUSD_otc', 'martingale');
  const expected = [2, 4, 8, 16, 32, 64, 128];
  let allOk = true;
  for (const exp of expected) {
    updateBettingAfterResult(mart, false);
    if (computeBettingAmount(mart) !== exp) { allOk = false; }
  }
  check('martingale 2,4,8,16,32,64,128 sans plafond implicite', allOk);
  updateBettingAfterResult(mart, true);
  check('WIN → martingale reset (1$)', computeBettingAmount(mart) === 1);

  // Fibonacci : paliers 1,1,2,3,5,8,13,21,34,55 puis PLAFOND.
  const fib = makeCtx('XAUUSD_otc', 'fibonacci');
  let fibOk = true;
  const fibExpected = [1, 2, 3, 5, 8, 13, 21, 34, 55, 55]; // mise après chaque perte
  for (const exp of fibExpected) {
    updateBettingAfterResult(fib, false);
    if (computeBettingAmount(fib) !== exp) fibOk = false;
  }
  check(`fibonacci progressive (paliers ${FIBONACCI_STEPS.join(',')}, plafond 55×)`, fibOk);
  // WIN → recule de 2 pas :
  updateBettingAfterResult(fib, true);
  check('fibonacci WIN → recule de 2 pas', computeBettingAmount(fib) === FIBONACCI_STEPS[7]);

  // Clamp balance : jamais plus que la balance (minimum 1$).
  const rich = makeCtx('BTCUSD_otc', 'martingale');
  updateBettingAfterResult(rich, false);
  check('clamp balance (mise > balance → 1$ minimum)', computeBettingAmount(rich, 1.5) === 1);
  check('mise toujours ≥ 1$', computeBettingAmount(rich, 0) >= 1);

  // §30 — arrêt d'un asset : le contexte est supprimé, les autres INTACTS.
  const registry = new AssetContextRegistry();
  for (const a of ['EURUSD_otc', 'XAUUSD_otc', 'BTCUSD_otc']) {
    registry.ensureAssetContext(a, { bettingStrategy: 'martingale' });
  }
  const beforeX = registry.requireAssetContext('XAUUSD_otc');
  updateBettingAfterResult(beforeX, false);
  const removed = registry.removeAssetContext('EURUSD_otc');
  check('removeAssetContext(EURUSD) = true', removed);
  check('registre = 2 assets', registry.size === 2);
  check("EURUSD n'est plus dans le registre", registry.getAssetContext('EURUSD_otc') === null);
  check("XAUUSD INTACT après retrait d'EURUSD", registry.requireAssetContext('XAUUSD_otc') === beforeX && beforeX.betting.consecutiveLosses === 1);
  check('retainOnly garde uniquement les listés', (() => {
    registry.retainOnly(['XAUUSD_otc']);
    return registry.size === 1 && registry.has('XAUUSD_otc');
  })());

  // §37 — format des logs de debug.
  check('assetLog format [ASSET:EURUSD_otc]', assetLog('EURUSD_otc', 'candle received') === '[ASSET:EURUSD_otc] candle received');

  // Catalogue : les assets de test existent (miroir backend/frontend).
  check('catalogue : EURUSD_otc présent', getMarket('EURUSD_otc').name === 'EURUSD_otc');
  check('catalogue : XAUUSD_otc présent', MARKETS_CATALOG.some(m => m.name === 'XAUUSD_otc'));
  check('catalogue : 183 actifs', MARKETS_CATALOG.length === 183);
  check('getMarket fallback (asset inconnu)', getMarket('ZZZUNKNOWN_otc').name === 'ZZZUNKNOWN_otc');
}

// ─────────────────────────────────────────────────────────────────────────────
//  TEST 11 — v6.1 : EXPIRATION = CHAMP AUTO TRADE (toutes stratégies)
// ─────────────────────────────────────────────────────────────────────────────
section("TEST 11 — v6.1 : LE CHAMP AUTO TRADE EST LA SOURCE DE VÉRITÉ (toutes stratégies, mono + multi)");

{
  // La résolution d'expiration est un module PUR (expiry.ts) partagé par
  // la stratégie d'auto-trade (L_Lucien ProTrader). Même code → même
  // comportement en mono et en multi-assets.
  const snap = snapExpiry;
  const resolve = resolveAutoTradeExpiry;
  const MIN = AUTO_TRADE_MIN_EXPIRY;
  const MAX = AUTO_TRADE_MAX_EXPIRY;
  const BROKER = BROKER_SUPPORTED_EXPIRIES;

  // 11.1 — LE CHAMP PRIME sur le fallback (durée de bougie TF).
  // Stratégie sur M5 : fallback TF = 300 s, mais le champ vaut 30 s → 30 s.
  check('stratégie : champ=30s PRIME sur le fallback TF M5=300s', resolve(30, 300) === 30);
  check('stratégie : champ=45s PRIME sur M5 et RESTE 45s (v6.3 : plus de snap)', resolve(45, 300) === 45);
  check('stratégie : champ=30s PRIME sur le fallback TF M1=60s', resolve(30, 60) === 30);
  check('stratégie : champ=900s PRIME sur le fallback TF S30=30s', resolve(900, 30) === 900);

  // 11.2 — FALLBACK UNIQUEMENT si le champ est absent/null/invalide.
  check('champ null → fallback TF (durée de la bougie)', resolve(null, 300) === 300);
  check('champ undefined → fallback', resolve(undefined, 60) === 60);
  check('champ 0 (invalide) → fallback', resolve(0, 60) === 60);
  check('champ NaN (invalide) → fallback', resolve(NaN, 60) === 60);

  // 11.3 — v6.3 : LE CHAMP EST RESPECTÉ À LA SECONDE PRÈS (bug « exp 5s »).
  // L'ancien snap sur BROKER_SUPPORTED_EXPIRIES réécrivait 6 s → 5 s : le
  // champ Auto Trade doit maintenant passer TEL QUEL au broker (clamp seul).
  check('BUG v6.3 : 6 s reste 6 s (était écrasé en 5 s !)', snap(6) === 6);
  check('7 s reste 7 s', snap(7) === 7);
  check('45 s reste 45 s (était snappé à 30 s)', snap(45) === 45);
  check('61 s reste 61 s', snap(61) === 61);
  check('1000 s reste 1000 s (était snappé à 900 s)', snap(1000) === 1000);
  check('900 s NON écrasé à 600 s (bug v6.0 corrigé)', snap(900) === 900);
  check('1800 s préservé', snap(1800) === 1800);
  check('86400 s (D1) préservé', snap(86400) === 86400);
  check('sous le minimum : 1 s → clamp 3 s', snap(1) === MIN && MIN === 3);
  check('au-dessus du max : 90000 s → clamp 86400 s', snap(90000) === MAX && MAX === 86400);
  check('valeur classique inchangée (60 s)', snap(60) === 60);
  check('arrondi : 45.6 s → 46 s', snap(45.6) === 46);
  check('les valeurs historiques restent des points fixes', BROKER.every(v => snap(v) === v));

  // 11.4 — COMPORTEMENT IDENTIQUE PAR ASSET (mono ↔ multi-assets).
  // La résolution ne dépend d'AUCUN contexte : le même champ s'applique à
  // chaque asset — l'isolement porte sur les mises/stats/décisions (§13/§16).
  const assets = ['EURUSD_otc', 'XAUUSD_otc', 'BTCUSD_otc'];
  const expiries = assets.map(() => resolve(30, 300));
  check('3 assets : expiration IDENTIQUE (champ global 30 s)', expiries.every(e => e === 30));
  check('stratégie : champ=120s (fallback 60s ignoré)', resolve(120, 60) === 120);
  check('stratégie sans champ → fallback conservé', resolve(null, 60) === 60);
  check('stratégie : champ=20s', resolve(20, 60) === 20);
  check('POLLING : champ=180s', resolve(180, 15) === 180);
}

// ─────────────────────────────────────────────────────────────────────────────
//  Résultat
// ─────────────────────────────────────────────────────────────────────────────
console.log('\n' + '='.repeat(72));
console.log(`RÉSULTAT : ${passed} test(s) OK, ${failed} échec(s)`);
if (failed > 0) {
  console.log('\nÉchecs :');
  for (const f of failures) console.log(`  ✗ ${f}`);
  process.exit(1);
} else {
  console.log('\n✔ ISOLATION MULTI-ASSETS VALIDÉE — aucune contamination entre assets.');
  process.exit(0);
}
