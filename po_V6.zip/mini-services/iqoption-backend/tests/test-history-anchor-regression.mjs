#!/usr/bin/env node
/**
 * Regression test for broker-vs-host clock skew.
 * Pocket Option market timestamps can be ahead of the host clock (the
 * incident observed on 2026-09-09 was ~7200s). The SDK must accept an
 * explicit LIVE market timestamp as the first history-page anchor.
 */
import fs from 'node:fs';
import assert from 'node:assert/strict';

const sdk = new URL('../pocket-option-sdk/src/api/market-data.ts', import.meta.url);
const source = fs.readFileSync(sdk, 'utf8');

assert.match(source, /startTimeSec\?:\s*number/,
  'loadFullHistory must expose an optional startTimeSec anchor');
assert.match(source, /requestedAnchor[\s\S]*startTimeSec/,
  'loadFullHistory must derive its initial endTime from the explicit anchor');
assert.match(source, /let endTime = requestedAnchor/,
  'history pagination must start at the market-time anchor');

const hostNow = 1_788_955_503;
const marketNow = hostNow + 7_200;
const anchoredStart = Math.floor(marketNow);
const unanchoredStart = Math.floor(hostNow);
assert.equal(anchoredStart - marketNow, 0);
assert.equal(unanchoredStart - marketNow, -7_200);

console.log('PASS: history requests can be anchored to live market time; 7200s clock skew is covered.');
