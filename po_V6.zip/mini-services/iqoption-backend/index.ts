/**
 * pocketoption-backend / index.ts
 * =================================
 *
 * Socket.io server exposing the PocketOptionClient (from pocket-option-sdk)
 * to the Next.js frontend.
 *
 * Frontend event API
 * ------------------
 *   client → server:
 *     login             { email, password, mode?: 'demo' | 'real' }
 *     select-assets     { mode: 'single' | 'multi', assets: string[] }   // ≤ 10, validé backend
 *     switch-asset      { from: string, to: string }                     // multi : remplace UN asset
 *     add-asset         { asset: string }                                // multi : jusqu'à 10
 *     remove-asset      { asset: string }                                // multi : arrêt d'un asset
 *     set-focus         { asset: string }                                // focus ≠ traitement
 *     select-market     { market: "EURUSD_otc" | "#AAPL_otc" | ... }     // compat mono-asset
 *     capture-history   { count, size, asset? }
 *     place-order       { action: 'call' | 'put', amount, time, optionType?, asset? }
 *     close-positions   { position_ids: number[] }   // not supported by PO binary, ignored
 *     close-all                                                       // idem
 *     set-config        { ... }
 *     set-auto-trade    { enabled, asset? }          // asset absent = TOUS les assets
 *     start-strategy
 *     stop-strategy
 *     set-mode          { mode: 'demo' | 'real' }
 *
 *   server → client:
 *     login-result      { ok, error?, user_id?, mode? }
 *     assets-selected   { ok, mode, assets, focus, error? }
 *     status            { connected, authenticated, market, tradingMode, assets[], balance, ... }
 *     candles-history   { key, asset, candles }
 *     candle             { asset, time, open, high, low, close, volume }
 *     stream             { asset, bid, ask, time }
 *     order-placed       { success, requestId, deal?, error? }
 *     trade-opened       { asset, deal, source }       // événement par asset (§21)
 *     trade-closed       { asset, deal, isWin, profit } // événement par asset (§21)
 *     deal-closed        { id, asset, isWin, profit, ... } // legacy (payload broker brut)
 *     auto-trade-status  { ..., assets: { [asset]: {...} } } // stats PAR ASSET
 *     log                { ts, level, message }
 */

import { createServer } from "http";
import { Server } from "socket.io";
import * as path from "path";
import { writeFileSync, mkdirSync } from "node:fs";
import {
  PocketOptionClient,
  type SessionData,
  type Candle,
  type StreamUpdate,
  type HistoryTick,
  type OpenedDeal,
  type ClosedDeal,
  type AccountMode,
  type AssetsMap,
  type Asset,
} from "./pocket-option-sdk/src/index.js";
import { ema, rsi, type CandleLike } from "./indicators.js";
import { sanitizeCandlesByPrice, retainLatestPriceRegime } from "./candle-integrity.js";
import { CandleHistoryCache, type CachedCandle } from "./candle-history-cache.js";
import { RiskManager } from "./risk-manager.js";
import { recordPatternTrade, updatePatternTradeResult, getAllPatternStats, getRecentPatternTrades } from "./pattern-performance-logger.js";
import { CandleTickRecorder } from "./candle-tick-recorder.js";
import { StreamTickNormalizer } from "./stream-tick-normalizer.js";
import {
  CandleSyncManager,
  type CandleSeries,
} from "./candle-sync-manager.js";
import type { CandleLike as BuilderCandle } from "./candle-builder.js";
import { CandleJsonlReader } from "./candle-jsonl-reader.js";
import {
  evaluateBosChochCisdStrategy,
  markBosChochCisdTraded,
  resetBosChochCisdState,
  DEFAULT_BOS_CHOCH_CISD_TOGGLES,
  type BosChochCisdOrderRule,
} from "./bos-choch-cisd-strategy.js";
import {
  evaluateNinjaProTraderStrategy,
  markNinjaProTraderTraded,
  resetNinjaProTraderState,
} from "./ninja-protrader-strategy.js";
import { DEFAULT_BOS_CHOCH_CISD_ORDER_RULES, normalizeBosChochCisdOrderRules, type BosChochCisdSignal, type BosChochCisdCandle } from "../../shared/bos-choch-cisd.js";
import { signalLabel } from "../../shared/signal-registry.js";
import { getMarket, type MarketInfo } from "./markets-catalog.js";
import {
  AUTO_TRADE_MIN_EXPIRY,
  AUTO_TRADE_MAX_EXPIRY,
  snapExpiry,
} from "./expiry.js";
import {
  AssetContextRegistry,
  computeBettingAmount,
  applyDealResult,
  classifySettledOutcome,
  noteDealOpened,
  noteDealClosed,
  assertAssetContext,
  findTrackedDealByFingerprint,
  validateAssetSelection,
  planResubscription,
  assetLog,
  FIBONACCI_STEPS,
  MAX_SELECTED_ASSETS,
  type AssetTradingContext,
  type BettingOutcome,
  type TradingModeConfig,
  type BettingStrategy,
  clampMaxMartingaleSteps,
} from "./asset-contexts.js";
import {
  AUTO_SWITCH_TRIGGER_PCT,
  AUTO_SWITCH_TARGET_PCT,
  DEFAULT_PAYOUT_GUARD_CONFIG,
  createPayoutGuardState,
  evaluatePayoutGuard,
  commitPayoutSwap,
  isPayoutTarget,
  prunePayoutGuardState,
  payoutGuardSummary,
  pickReplacementCandidate,
  type PayoutGuardConfig,
  type PayoutGuardState,
  type PayoutSnapshot,
  type PayoutSwapDecision,
} from "./payout-guard.js";
import {
  AssetPipelineManager,
  MultiAssetTickRouter,
  formatStructuredLog,
  type MarketDecisionSnapshot,
  type PipelineTick,
} from "./asset-pipeline.js";
import { healthBadge, type UiHealthBadge } from "./market-data-health.js";
import {
  defaultSessionSnapshotPath,
  savePersistedSession,
  loadPersistedSession,
  clearPersistedSession,
  type PersistedSession,
} from "./session-persistence.js";

const PORT = 3030;

// ─────────────────────────────────────────────────────────────────────────────
//  Persistent candle history cache (bounded 100-candle seam buffer, JSON file)
// --------------------------------------------------------------------------
//  - On startup: cache is capped at 100 candles; only recent data is fetched.
//  - On startup: if cache exists, fetch only the missing candles (incremental update).
//  - In real-time: append live ticks as they arrive.
//  - Periodic flush to disk (every 30 seconds).
// --------------------------------------------------------------------------
// NOTE: __dirname is NOT available in ESM (tsx uses ESM).
// Use process.cwd() + relative path, or derive from import.meta.url.
const CANDLE_CACHE_DIR = path.resolve(
  typeof __dirname !== 'undefined'
    ? __dirname
    : path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Z]:)/, '$1')),
  'candle-cache'
);
let candleHistoryCache: CandleHistoryCache | null = null;

// --------------------------------------------------------------------------
//  Risk Manager — enforces position sizing, loss streak protection, daily limits
// --------------------------------------------------------------------------
let riskManager: RiskManager | null = null;

// --------------------------------------------------------------------------
//  Candle Tick Recorder — records every price variation per candle to JSONL
// --------------------------------------------------------------------------
let candleTickRecorder: CandleTickRecorder | null = null;

// --------------------------------------------------------------------------
//  ANTI-DUPLICATION TICK PIPELINE + BOS MAGNET AUTO-TRADE
// --------------------------------------------------------------------------
//  Pocket Option pousse 2 updates `updateStream` par seconde par actif
//  (début + fin de seconde : les DEUX sont de vrais prix du graphique).
//  Le StreamTickNormalizer leur attribue des horodatages sous-seconde
//  strictement croissants → zéro duplication en aval, vitesse des ticks
//  restituée en 2 points/seconde. Voir stream-tick-normalizer.ts pour
//  la validation empirique complète (257 bougies vs bougies broker).
// --------------------------------------------------------------------------
let streamTickNormalizer: StreamTickNormalizer | null = null;

/** Lecteur temps réel de .logs/candles.jsonl (poll 1 s). */
const candleJsonlReader = new CandleJsonlReader();

// ─────────────────────────────────────────────────────────────────────────────
//  MULTI-ASSETS : CONTEXTES DE TRADING INDÉPENDANTS PAR ASSET (§5/§6)
// ─────────────────────────────────────────────────────────────────────────────
//  RÈGLE ARCHITECTURALE ABSOLUE : il n'existe PLUS de singleton lié au marché.
//  Chaque asset sélectionné possède son PROPRE contexte (stratégie
//  L_Lucien ProTrader, Martingale, Fibonacci, stats, deals, positions,
//  Auto Trade) :
//
//    EURUSD → contexte EURUSD (Market, Candles, Decision, Auto Trade,
//                           Martingale, Fibonacci, Deals)
//    XAUUSD → contexte XAUUSD (…)
//    BTCUSD → contexte BTCUSD (…)
//
//  ISOLATION TOTALE (§6) : une perte sur EURUSD ne modifie JAMAIS l'état de
//  mise de XAUUSD/BTCUSD. Tous les traitements critiques passent par
//  getAssetContext(asset) + assertAssetContext() (§32).
//  Cf. asset-contexts.ts (module pur) et tests/test-multi-assets.ts.
// ─────────────────────────────────────────────────────────────────────────────

/** Registre central : assetContexts = Map<string, AssetTradingContext>. */
const registry = new AssetContextRegistry();

// --------------------------------------------------------------------------
// Répertoire du backend (chemins de persistance — snapshot de session).
// --------------------------------------------------------------------------
const BACKEND_DIR = typeof __dirname !== 'undefined'
  ? __dirname
  : path.dirname(new URL(import.meta.url).pathname.replace(/^\/([A-Z]:)/, '$1'));
/**
 * Retourne le contexte UNIQUE associé à l'asset (§5).
 * C'est la fonction centrale de l'architecture multi-assets : tout traitement
 * d'un événement lié à un marché DOIT passer par elle.
 */
function getAssetContext(asset: string): AssetTradingContext | null {
  return registry.getAssetContext(asset);
}

/**
 * Configuration de trading de la session (§4) — SOURCE DE VÉRITÉ des assets
 * actifs. `assets` définit ce qui est abonné et analysé ; `focus` est
 * uniquement l'asset AFFICHÉ (§9/§26 : le focus n'arrête jamais les autres).
 */
const tradingMode: TradingModeConfig = {
  mode: 'single',
  assets: [],
  focus: null,
};

/** Statut de tick PAR ASSET (prix, horodatage, volume de ticks) — alimente
 *  le tableau `assets[]` du payload de statut. */
interface AssetTickStat { price: number; ts: number; count: number; activeId: number }
const assetTickStats = new Map<string, AssetTickStat>();

/** Garde anti-doublon des fetchs d'historique — PAR ASSET (clé `asset:size`). */
const historyFetchStates = new Map<string, boolean>();

/** Throttle des réparations de trous — PAR ASSET. */
const gapRepairStates = new Map<string, number>();

/** Génération d'init du cache 90 j — PAR ASSET (empêche les boucles croisées). */
const candleCacheInitGenerations = new Map<string, number>();

/** Asset porteur du cache 90 jours persistant (§27 : UN seul cache lourd —
 *  l'asset primaire ; les autres assets utilisent le fetch d'historique
 *  léger fetchAndBroadcastHistory). */
let primaryCacheAsset: string | null = null;

/** Asset suivi par le CandleTickRecorder (JSONL — un seul fichier à la fois,
 *  l'asset primaire en multi-assets). */
let recorderAsset: string | null = null;

/** Préréglage Ichimoku selon la durée de bougie du timeframe. */
function getIchimokuTimeframePreset(candleSizeSec: number): { conversion: number; base: number; spanB: number; displacement: number } {
  if (candleSizeSec <= 10) return { conversion: 6, base: 13, spanB: 26, displacement: 13 };
  if (candleSizeSec <= 30) return { conversion: 7, base: 22, spanB: 44, displacement: 22 };
  return { conversion: 9, base: 26, spanB: 52, displacement: 26 };
}


/** Stratégies d'auto-trade disponibles (pour le dropdown du frontend). */
const AUTO_TRADE_STRATEGIES: Array<{ id: string; name: string; description: string }> = [
  { id: 'l_lucien_protrader', name: 'L_Lucien ProTrader', description: "Stratégie L_Lucien ProTrader — moteur BOS (Break of Structure), CHoCH (Change of Character) et CISD (Change in State of Delivery) sur swings à 2 bougies, converti depuis l'indicateur Pine du pack. Bougies CLÔTURÉES uniquement (jamais la bougie en formation). L'utilisateur configure librement les placements CALL ▲ et PUT ▼ : chaque règle peut exiger une ou plusieurs des 6 alertes BOS/CHoCH/CISD et possède sa propre expiration en secondes. Une règle correspond lorsque toutes ses alertes sélectionnées sont présentes dans la même émission ; la combinaison la plus spécifique est prioritaire. Les réglages « Labels » pilotent les visuels du graphique (tags et libellés masqués par défaut via leur switch dédié)." },
  { id: 'ninja_protrader', name: 'Ninja ProTrader', description: "Stratégie Ninja ProTrader — copie conforme de L_Lucien ProTrader avec UNE différence fondamentale : les signaux BOS Down, BOS Up, CHoCH Up, CHoCH Down, CISD Up et CISD Down sont détectés AVANT LA CLÔTURE des bougies (évaluation de la bougie en formation au prix temps réel, polling 500 ms) — l'ordre est placé immédiatement dès le franchissement du niveau de swing, sans attendre la clôture. Mêmes combinaisons CALL ▲ / PUT ▼, mêmes expirations par règle, même « Candles Validation » (règle par combinaison vérifiée sur les dernières bougies CLÔTURÉES, de la plus récente à la plus ancienne — la bougie en formation n'est jamais validée)." },
];

/** Ids des stratégies BOS/CHoCH/CISD partageant les réglages du panneau Auto Trade. */
const BCC_STRATEGY_IDS = ['l_lucien_protrader', 'ninja_protrader'] as const;

/** Nom affichable d'une stratégie d'auto-trade (fallback L_Lucien ProTrader). */
function autoTradeStrategyName(strategyId: string | undefined): string {
  return AUTO_TRADE_STRATEGIES.find((s) => s.id === (strategyId ?? 'l_lucien_protrader'))?.name ?? 'L_Lucien ProTrader';
}


/** Signal d'une stratégie Auto Trade prêt pour l'exécution (ordre + journal). */
interface PatternTradeSignal {
  strategyId: string;
  strategyName: string;
  action: 'CALL' | 'PUT' | 'HOLD';
  entryPrice: number;
  stopLoss: number;
  takeProfit: number;
  confidence: number;
  reason: string;
  expirySeconds: number;
  timestamp: number;
  /**
   * v22 — LIBELLÉ D'ORDRE : présent sur CHAQUE ordre placé, il porte la
   * stratégie, la combinaison qui a placé l'ordre et sa règle de
   * validation. Ex. « Ninja ProTrader · CALL ▲ · call-1 [BOS Up + CISD Up]
   * · validation RGRR ». Émis dans trade-opened → carte de l'ordre sur le
   * graphique + journal des performances.
   */
  orderLabel: string;
  /**
   * v23 — CONFIRMATION CISD : présente sur les ordres issus d'une
   * combinaison CISD confirmée (CISD vérifié avec swing intact, PUIS signal
   * combiné BOS + CISD / CHoCH + CISD). Transportée avec le signal pour
   * diagnostics ; le libellé d'ordre porte déjà l'information.
   */
  cisdConfirmation?: {
    direction: 'up' | 'down';
    armedCandleTime: number;
    swingPrice: number;
    confirmedBy: string[];
    /** v24 — exigence swing au moment de l'armement ('intact' par défaut). */
    swingMode?: 'intact' | 'violated' | 'none';
  } | null;
}

// --------------------------------------------------------------------------
//  Strategy config (binary options oriented — no leverage/margin)
// --------------------------------------------------------------------------

interface StrategyConfig {
  market: string;
  candleSize: number;        // period in seconds (5, 15, 30, 60, 180, 300, ...)
  historyCount: number;
  lookback: number;
  fastEma: number;
  slowEma: number;
  targetPnlPct: number;      // not used for binary — kept for compat
  maxLossPnlPct: number;
  leverage: string;          // kept for UI compat (not used by PO binary)
  margin: string;            // amount per trade (used as `amount` in openOrder)
  cooldownSeconds: number;
  maxConcurrentPositions: number;
  autoOpen: boolean;
  autoTradeEnabled: boolean;
  /** Durée d'expiration des ordres binaires (en secondes) — "time" dans openOrder */
  expirySeconds: number;
  /** Strategy ID for backend auto-trade (bos_magnet, pattern_engine, ...) */
  strategyId: string;
  /** Stratégie de mise pour l'auto-trade : fixed | martingale | fibonacci */
  bettingStrategy: 'fixed' | 'martingale' | 'fibonacci';
  /** Daily profit stop enabled */
  dailyProfitStopEnabled: boolean;
  /** Daily profit target multiplier (e.g., 2.0 = stop when balance doubles) */
  dailyProfitTarget: number;
  /** Prediction horizon (from frontend slider) */
  horizon: number;
  /** Risk Management enabled (OFF by default — must be explicitly activated) */
  riskManagementEnabled: boolean;
  /** Auto-switch to a random OTC asset after each trade (win or loss), restricted to live payout 90–92%. */
  autoSwitchAssets?: boolean;
  /**
   * v21 — « Stay on Forex OTC Only » : quand ce switch est ON, tout Auto
   * Switch Assets ne choisit QUE des paires FOREX OTC (CADJPY_otc,
   * AUDUSD_OTC…) — jamais métaux, cryptos, indices ni actions.
   * Défaut : false (l'utilisateur l'active sous Auto-switch assets).
   */
  stayOnForexOtcOnly?: boolean;
  /**
   * v6.5 — Activation en masse de l'Auto Trade DÈS la validation de la
   * sélection d'assets : tous les assets validés passent AUTO ON ensemble
   * (chacun reste bloqué par sa propre MarketDataHealth jusqu'à données
   * saines). Défaut : true. Passer false via set-config pour garder
   * l'activation manuelle carte par carte.
   */
  autoEnableAfterSelection?: boolean;
  /** L_Lucien ProTrader — toggles « Alerts » du moteur (événements tradés) */
  bosChochCisdBosUp?: boolean;
  bosChochCisdBosDown?: boolean;
  bosChochCisdChochUp?: boolean;
  bosChochCisdChochDown?: boolean;
  bosChochCisdCisdUp?: boolean;
  bosChochCisdCisdDown?: boolean;
  bosChochCisdCallRules?: BosChochCisdOrderRule[];
  bosChochCisdPutRules?: BosChochCisdOrderRule[];
  /**
   * v26 — Règles PROPRES à Ninja ProTrader (§31 : les paramètres Ninja et
   * L_Lucien ne se mélangent PAS). Absentes → repli sur les règles
   * partagées ci-dessus (compatibilité des sessions existantes, §32).
   */
  ninjaBosChochCisdCallRules?: BosChochCisdOrderRule[];
  ninjaBosChochCisdPutRules?: BosChochCisdOrderRule[];
  /**
   * v19 — L_Lucien ProTrader : switch « Confirmation bougie précédente ».
   * ON → un CALL ▲ n'est émis que si la bougie précédant la bougie signalée
   * est BAISSIÈRE ; un PUT ▼ que si elle est HAUSSIÈRE. Défaut : false.
   */
  bosChochCisdConfirmCandle?: boolean;
  /**
   * v24 — Étapes de vérification CISD OPTIONNELLES (cases à cocher du
   * panneau Auto Trade, partagées L_Lucien ProTrader / Ninja ProTrader /
   * Strategy Tester) :
   *   cisdGuardUp / cisdGuardDown      : activation par direction (défaut
   *                                      true = v23) ; décochée → les
   *                                      règles CISD de cette direction
   *                                      ordonnent DIRECTEMENT (v22) ;
   *   cisdGuardSwingMode               : 'intact' (défaut v23 — arme si le
   *                                      swing le plus proche n'a PAS été
   *                                      violé) | 'violated' (arme si le
   *                                      swing a ÉTÉ violé — sweep) ;
   *   cisdGuardConfirmBosUp / cisdGuardConfirmChochUp (CALL ▲),
   *   cisdGuardConfirmBosDown / cisdGuardConfirmChochDown (PUT ▼) :
   *                                      combinaisons de confirmation
   *                                      acceptées à l'étape 3.
   */
  cisdGuardUp?: boolean;
  cisdGuardDown?: boolean;
  /** v25 — 'none' = les deux cases swing décochées : étape swing IGNORÉE. */
  cisdGuardSwingMode?: 'intact' | 'violated' | 'none';
  cisdGuardConfirmBosUp?: boolean;
  cisdGuardConfirmChochUp?: boolean;
  cisdGuardConfirmBosDown?: boolean;
  cisdGuardConfirmChochDown?: boolean;
  /**
   * v19/v20 — Garde-fou Martingale : nombre MAXIMAL de mises dans la séquence
   * après pertes consécutives. 0 = illimité (comportement historique).
   * Ex. 5 avec base 1 : 1→2→4→8→16→32 ; si le 32 perd → retour à 1.
   */
  maxMartingaleSteps?: number;
}

const DEFAULT_CONFIG: StrategyConfig = {
  // v21 — PLUS d'asset codé en dur par défaut (l'ancien 'EURUSD_otc' a été
  // RETIRÉ sur demande utilisateur) : au démarrage du programme, un asset
  // avec profit 92 % est sélectionné ALÉATOIREMENT (ensureStartupAssetSelection).
  market: '',
  candleSize: 30,  // default S30; Over The Counter is optimized for M1 but supports S30+
  historyCount: 300,         // HARD CAP — maximum 300 candles in the application
  lookback: 200,
  fastEma: 9,
  slowEma: 21,
  targetPnlPct: 0.5,
  maxLossPnlPct: -10.0,
  leverage: '1',
  margin: '1.0',
  cooldownSeconds: 15,  // wait for previous trade to expire before placing new one
  maxConcurrentPositions: 1,
  autoOpen: true,
  autoTradeEnabled: false,
  expirySeconds: 60,
  strategyId: 'l_lucien_protrader',
  // L_Lucien ProTrader — toggles « Alerts » du moteur (tous ON : la stratégie
  // trade dès sa sélection ; l'utilisateur peut couper chaque événement).
  bosChochCisdBosUp: true,
  bosChochCisdBosDown: true,
  bosChochCisdChochUp: true,
  bosChochCisdChochDown: true,
  bosChochCisdCisdUp: true,
  bosChochCisdCisdDown: true,
  bosChochCisdCallRules: DEFAULT_BOS_CHOCH_CISD_ORDER_RULES.callRules,
  bosChochCisdPutRules: DEFAULT_BOS_CHOCH_CISD_ORDER_RULES.putRules,
  // v19 — switch « Confirmation bougie précédente » : OFF par défaut
  // (les signaux L_Lucien ProTrader passent sans filtre supplémentaire).
  bosChochCisdConfirmCandle: false,
  // v24 — étapes de vérification CISD OPTIONNELLES : DÉFAUT = v23 intégral
  // (protection active des deux directions, swing intact exigé, BOS et
  // CHoCH acceptés comme confirmations). L'utilisateur peut décocher.
  cisdGuardUp: true,
  cisdGuardDown: true,
  cisdGuardSwingMode: 'intact' as 'intact' | 'violated' | 'none',
  cisdGuardConfirmBosUp: true,
  cisdGuardConfirmChochUp: true,
  cisdGuardConfirmBosDown: true,
  cisdGuardConfirmChochDown: true,
  // v19 — garde-fou Martingale : 0 = illimité (comportement historique).
  maxMartingaleSteps: 0,
  bettingStrategy: 'fixed',
  dailyProfitStopEnabled: false,
  dailyProfitTarget: 2.0,
  horizon: 10,
  riskManagementEnabled: false,   // OFF by default — pro traders choose to enable it
  autoSwitchAssets: false,       // OFF par défaut — aucun changement d'actif automatique sans consentement explicite.
  stayOnForexOtcOnly: false,    // v21 — OFF par défaut (Auto Switch libre) ; ON = uniquement des paires Forex OTC.
  autoEnableAfterSelection: false,
};
// --------------------------------------------------------------------------
//  Client session
// --------------------------------------------------------------------------

interface ClientSession {
  client: PocketOptionClient | null;
  market: MarketInfo | null;
  mode: AccountMode;
  config: StrategyConfig;
  /** v6.3 — Identifiants de la dernière connexion réussie (MÉMOIRE SEULE,
   *  jamais persistés sur disque). Sert au login idempotent : mêmes
   *  identifiants = REPRISE de session au lieu d'une destruction. */
  credentials: { email: string; password: string; mode: AccountMode } | null;
  /** v6.3 — Login idempotent déjà effectué pour CES identifiants ? */
  resumedOnce: boolean;
  /** v6.3 — Horodatage de démarrage du backend (uptime du heartbeat). */
  startedAt: number;
  /** v6.3 — Timer du heartbeat headless (log 60 s : le backend continue
   *  de trader même sans frontend connecté). */
  heartbeatTimer: NodeJS.Timeout | null;
  /** v6.3 — Dernier volume de ticks au heartbeat (calcul ticks/min). */
  heartbeatLastTicks: number;
  candlesCaptured: number;
  closeWindow: number[];
  lastTradeTs: number;
  /** Timestamp (ms) of the most recent SUCCESSFULLY PLACED order (manual or auto). */
  lastOrderPlacedTs: number;
  /** v20 — Résultat du DERNIER ordre réglé de la session (tous assets,
   *  manuel ou auto) : true = gain, false = perte/tie, null = aucun.
   *  Le re-login automatique attend un GAIN avant de s'exécuter. */
  lastSettledWin: boolean | null;
  lastSignal: string;
  strategyRunning: boolean;
  strategyLoopTimer: NodeJS.Timeout | null;
  statusBroadcastTimer: NodeJS.Timeout | null;
  liveTicksTotal: number;
  liveTicksForMarket: number;
  lastTickTs: number;
  lastTickPrice: number;
  lastTickActiveId: number;
  lastTickSize: number;
  /** Opened binary deals (CALL/PUT en cours) */
  openedDeals: OpenedDeal[];
  /** Recently closed deals (historique) */
  closedDeals: ClosedDeal[];
  /** Last prediction map (algo name → action + confidence) for performance tracking */
  /** Last trade action for performance tracking */
  lastTradeAction: 'call' | 'put';
  /** Map of pending pattern trades: tradeId → { patternId, timestamp, dealId? } */
  /** Map of pending pattern trades: tradeId → { patternId, timestamp, asset }.
   *  L'ASSET est enregistré pour le matching deal↔trade — un deal d'un asset
   *  ne peut JAMAIS matcher le trade en attente d'un autre asset (§17/§21). */
  pendingPatternTrades: Map<string, { patternId: string; patternName: string; timestamp: number; dealId?: string; asset?: string }>;
  /** Last pattern trade ID (for backward compat — DEPRECATED, use pendingPatternTrades) */
  lastPatternTradeId: string;
  /** Last pattern ID that fired (for backward compat — DEPRECATED) */
  lastPatternId: string;
  /** Starting balance for daily profit target */
  startBalance: number;
  /**
   * Set of deal IDs that were placed manually via the "place-order"
   * socket event (i.e. the Binary Trade CALL/PUT buttons in the UI).
   * When such a deal closes we MUST NOT auto-switch the asset —
   * the user explicitly chose this asset and expects to stay on it.
   * Only strategy/auto-trade deals trigger the auto-switch behaviour.
   */
  manualDealIds: Set<string>;
  /**
   * Race-condition guard: set to `true` immediately BEFORE calling
   * `client.trading.openOrder(...)` from the manual `place-order`
   * socket handler, and reset to `false` right after. The SDK often
   * emits `deal_opened` DURING the await (before openOrder resolves),
   * so without this flag the deal would be opened by the SDK without
   * us marking it as manual. The `deal_opened` handler reads this
   * flag and, if true, registers the deal id in `manualDealIds`.
   */
  manualTradePending: boolean;
  /** Timestamp (ms) of the last manual `place-order` call — used to
   *  time-gate the `manualTradePending` flag so a stale flag cannot
   *  accidentally mark an unrelated strategy deal as manual. */
  manualTradePendingTs: number;
  /**
   * Timestamp (ms) of the most recent MANUAL deal close. The Pocket
   * Option server often emits TWO `deal_closed` events for a single
   * binary trade:
   *   1. The real one with the deal's UUID (correctly caught by
   *      `manualDealIds`).
   *   2. A synthetic/aggregate one with `id=0` (or null/NaN) a few
   *      seconds later, which the server sends as part of a batch
   *      settlement update.
   * The synthetic close does NOT carry the real deal id, so
   * `manualDealIds.has("0")` returns false and the auto-switch logic
   * fires — even though the trade was manual. We work around this by
   * remembering the timestamp of the last manual close and refusing
   * to auto-switch for a short window (default 30s) afterwards.
   */
  lastManualDealCloseTs: number;
  /** Timestamp (ms) du dernier auto-switch de marché — information de
   *  diagnostic (le throttler officiel est le cooldown du payout-guard). */
  lastAutoSwitchTs: number;
  /** v20 — Re-login automatique reporté en attente d'un GAIN : horodatage
   *  du début du report (0 = aucun report en cours). */
  reloginDeferredSince: number;
  /** Guard for scheduled 30-minute credential relogin. */
  reloginInProgress: boolean;
  /** Scheduled 30-minute relogin timer (ou timer de retry du report). */
  reloginTimer: NodeJS.Timeout | null;
  /** Prevent concurrent asset switches during refresh. */
  assetSwitchInProgress: boolean;
  /** v20 — Timer de ré-évaluation périodique des règles Auto Switch (10 s,
   *  sur le cache payouts du client courant). */
  autoSwitchEvalTimer: NodeJS.Timeout | null;
  /** Live deal ids currently tracked for settlement/reconciliation. */
  liveTradeIds: Set<string>;
  /** Closed-deal fingerprints already processed. */
  seenClosedDealFingerprints: Set<string>;
}

// --------------------------------------------------------------------------
// SYNCHRONISATEUR HISTORIQUE ↔ LIVE (candle-sync-manager.ts)
// --------------------------------------------------------------------------
// Architecture cible (ToDo « Synchronisation historique ↔ stream », validée
// sur History_Live_Fix.har) :
//
//   updateStream / updateHistoryNewFast (ticks marché)
//           │  StreamTickNormalizer (anti-duplication sous-seconde)
//           ▼
//   CandleSyncManager — buffer de ticks canonique + latestMarketTimeSec
//           ├──► S5  CandleBuilder ─┐
//           ├──► S30 CandleBuilder ─┤ TOUS les timeframes lisent la MÊME
//           ├──► M1  CandleBuilder ─┤ chronologie (jamais de cascade
//           └──► M5  CandleBuilder ─┘  S5→S30→M1→M5)
//                                │
//   Historique (loadFullHistory / loadHistoryPeriod)
//     → normalize + align + dédup + fusion par bucket (§14 priorités)
//                                │
//                    closed candles / forming candle
//                                │
//                      Chart / Stratégies
//
// RÈGLE INVARIANTE : même actif + même timeframe + même bucket UTC
//                    = une seule bougie canonique.
//
// Le graphique (et tous les moteurs) lisent la série du TIMEFRAME SÉLECTIONNÉ
// via `chartSeries()` ci-dessous — plus jamais un builder global désynchronisé.
// --------------------------------------------------------------------------

/** Période (s) du timeframe graphique courant (partagé par tous les assets). */
function chartPeriodSec(): number {
  return session.config.candleSize ?? 30;
}

/**
 * Asset du contexte courant = asset FOCUS (§9). Attention : le focus est
 * l'asset AFFICHÉ — les autres assets sélectionnés continuent d'être traités
 * (§26). Toute la logique métier utilise getAssetContext(asset) et NON cet
 * helper d'affichage.
 */
function chartAsset(): string {
  return tradingMode.focus ?? session.market?.name ?? '';
}

/** Contexte du FOCUS (null si aucune sélection). */
function focusContext(): AssetTradingContext | null {
  return tradingMode.focus ? registry.getAssetContext(tradingMode.focus) : null;
}

/** Série canonique (closed + forming) du timeframe graphique — FOCUS. */
function chartSeries(): CandleSeries {
  return candleSync.getSeries(chartAsset(), chartPeriodSec());
}

/** Série complète du timeframe graphique (ordre du graphique) — FOCUS. */
function chartCandles(): CandleLike[] {
  // Le builder pose toujours `volume` (1 à l'ouverture, incrémenté ensuite) —
  // le cast sert uniquement à satisfaire le CandleLike d'indicators.ts
  // (volume requis) sans duplication de type.
  return candleSync.getAllCandles(chartAsset(), chartPeriodSec()) as CandleLike[];
}

/** Dernier temps MARCHÉ connu de l'asset focus (0 si aucun). */
function latestMarketTimeSec(): number {
  return candleSync.getLatestMarketTimeSec(chartAsset());
}

/** Dernier temps MARCHÉ connu d'un asset DONNÉ (§28 — un temps par asset). */
function assetLatestMarketTimeSec(asset: string): number {
  return candleSync.getLatestMarketTimeSec(asset);
}

/** Dernier prix connu d'un asset donné (0 si aucun tick). */
function assetLastPrice(asset: string): number {
  return assetTickStats.get(asset)?.price ?? 0;
}

let syncLogSink: ((level: string, message: string) => void) | null = null;

const candleSync = new CandleSyncManager({
  periods: [5, 10, 15, 30, 60, 120, 180, 300, 600, 900, 1800, 3600, 14400, 86400],
  // v21.1 — 15 600 ticks (au lieu de 4 800) : le health market-data exige
  // ≥ 25 bougies CLÔTURÉES au timeframe graphique avant d'autoriser le
  // trading (DEFAULT_MIN_CANDLES). À ~2 ticks/s, 4 800 ticks ≈ 40 min →
  // 13 bougies M3 / 8 bougies M5 : SANS le fetch paginé (loadFullHistory),
  // le M3 restait bloqué ~36 min et le M5 ~1 h 25 en INSUFFICIENT_CANDLES.
  // 15 600 ticks couvre ~130 min à 2 ticks/s (26 bougies M5) — la mémoire
  // reste modeste (~780 Ko/asset) et la pagination (chemin normal de
  // production, bougies profondes 1440) reste le complément de profondeur.
  maxTickBuffer: 15_600, // ≥ 25 bougies du plus grand TF supporté (S300)
  maxCandlesPerSeries: 300,
  onCandleClosed: (asset, periodSec, closedChartCandle) => {
    onChartCandleClosed(asset, periodSec, closedChartCandle);
  },
  onSyncEvent: (event) => {
    // Journal [SYNC] (§19) — toujours visible pour les événements notables.
    syncLogSink?.(
      event.type === 'gap-detected' || event.type === 'stale-response' ? 'warning' : 'info',
      `[SYNC] ${event.asset} S${event.periodSec} ${event.type}: ${event.message}`,
    );
    // v6.5 — Santé de CET asset : snapshot AUTORITAIRE des trous AVEC leur
    // position (gapDetails) — permet le vieillissement par position (un trou
    // vieux, hors fenêtre d'analyse, ne dégrade plus l'asset pour toujours).
    // SANS toucher les autres assets (isolation §6).
    // v6.10.1 — les événements 'history-ticks-merged' (fusion du snapshot
    // updateHistoryNewFast) ne déclenchent PAS la mise à jour des gaps :
    // une fusion de ticks n'est PAS une détection de trous. AVANT : le
    // fallback legacy comptait 4 FAUX trous bloquants par snapshot (un par
    // timeframe) → pénalité de score, puis CRITICAL_GAP après reconnexion.
    // v6.11 — ISOLATION PAR TIMEFRAME : seuls les trous du timeframe
    // GRAPHIQUE alimentent la santé (configurée pour CE timeframe). Les
    // événements S5/M1/M5 portent des trous comptés dans LEURS unités (une
    // micro-perte de 45 s = 9 bougies S5 = 1-2 bougies S30) : les injecter
    // dans une santé S30 amplifiait les micro-pertes live par 6× et
    // remplaçait le snapshot autoritaire par celui d'une AUTRE série à
    // chaque événement (basculement des trous entre timeframes).
    if (
      (event.type === 'gap-detected' || event.type === 'history-loaded')
      && event.periodSec === chartPeriodSec()
    ) {
      applySyncGapsToHealth(event.asset, (event.data as any)?.gapDetails);
    }
    // v6.5 — SUPPRIMÉ : le décrément de gaps sur 'repair-done'. Les événements
    // repair-done du synchroniseur correspondent à des réparations ABANDONNÉES
    // ou INTERROMPUES (échec de fetch) : décrémenter la santé à ce moment
    // MASQUAIT des trous réels. La résorption passe désormais par la
    // revalidation (gap-detected / history-loaded) qui fait autorité.
    // Réparation automatique des trous du timeframe ACTIF (§13) : demande
    // d'historique ciblée → normalisation → fusion → revalidation.
    // MULTI-ASSETS : la réparation est autorisée pour TOUT asset SÉLECTIONNÉ
    // (l'asset focus n'est qu'un cas particulier — §9).
    if (
      event.type === 'gap-detected' &&
      registry.has(event.asset) &&
      event.periodSec === chartPeriodSec()
    ) {
      repairDetectedGaps(event.asset, event.periodSec).catch(() => { /* best-effort */ });
    }
  },
});

// ─────────────────────────────────────────────────────────────────────────────
// v6.4 — ASSET PIPELINE MANAGER : PIPELINE DE DÉCISION INDÉPENDANT PAR ASSET
// ─────────────────────────────────────────────────────────────────────────────
//  Chaque asset sélectionné possède son PROPRE pipeline complet (§1-§3) :
//
//    EURUSD → AssetPipeline(EURUSD) → CandleStore + CandleSync +
//             MarketDataHealth + StrategyContext → décision EURUSD
//    GBPJPY → AssetPipeline(GBPJPY) → … (100 % indépendant)
//    XAUUSD → AssetPipeline(XAUUSD) → … (100 % indépendant)
//
//  AUCUN composant ne dépend de l'asset « focus » : le pipeline est créé par
//  la SÉLECTION (registry), jamais par l'affichage. Le focus ne contrôle QUE
//  l'UI (§1). Le routeur (§23) ne contient aucune logique de trading — il
//  route chaque tick vers le pipeline de SON asset.
//
//  Performance (§22) : UNE seule connexion WebSocket → TickRouter →
//  pipelines (données séparées logiquement immédiatement après réception).
// ─────────────────────────────────────────────────────────────────────────────

/** Gestionnaire central des pipelines par asset (§2). */
const pipelineManager = new AssetPipelineManager({
  candleSync,
  timeframeSec: chartPeriodSec,
  resolveStrategyContext: (asset) => registry.getAssetContext(asset),
  minHealthScoreToTrade: 80, // seuil configurable (§14) — exposé via set-config
});

/** Routeur de ticks multi-assets (§23) — aucune logique de trading. */
const tickRouter = new MultiAssetTickRouter(
  pipelineManager,
  (asset) => registry.has(asset), // isolation §6 : asset non sélectionné → ignoré
);

/** Dernière émission de l'événement market-data-health PAR ASSET (throttle ~2 s). */
const healthEmitTs = new Map<string, number>();

/**
 * v6.5.1 — ACTIVE LES FLUX LIVE (`updateStream`) DE TOUS LES ASSETS SÉLECTIONNÉS.
 *
 * CONSTAT BROKER (validé en live sur le serveur démo Pocket Option) :
 * `updateStream` ne diffuse les ticks QUE des symboles activés par
 * `changeSymbol` — l'abonnement `subfor` seul ne produit AUCUN tick, et un
 * `changeSymbol` supplémentaire ne coupe PAS les flux déjà activés.
 *
 * AVANT (bug v6.5) : un seul changeSymbol (le FOCUS) → les AUTRES assets
 * sélectionnés ne recevaient AUCUN tick live → STREAM_DISCONNECTED, bougies
 * figées, puis trous géants classés critiques à la réactivation.
 *
 * Stratégie : changeSymbol pour CHAQUE asset sélectionné (le FOCUS EN
 * DERNIER — le broker considère le dernier symbole envoyé comme l'actif du
 * chart, ce qui garde les candles_update alignés sur l'affichage).
 */
function activateSymbolStreams(): void {
  if (!session.client) return;
  const period = (session.config.candleSize ?? 30) as any;
  const focus = tradingMode.focus;
  const others = tradingMode.assets.filter(a => a !== focus);
  // v6.10 — STAGGER des changeSymbol (HAR fix_gaps.har) : chaque
  // `changeSymbol` déclenche un `updateHistoryNewFast` (~1500 ticks) côté
  // broker. 24 requêtes d'un coup saturent le canal → réponses perdues /
  // throttling → ticks manquants → gaps. On étale l'activation (~150 ms
  // d'intervalle, FOCUS EN DERNIER) — 24 assets = 3,6 s au total, chaque
  // flux restant actif une fois établi (un changeSymbol supplémentaire ne
  // coupe PAS les flux déjà activés).
  const sendSymbol = (asset: string) => {
    if (session.client && tradingMode.assets.includes(asset)) {
      try { session.client.market.changeSymbol(asset, period); } catch { /* best-effort */ }
    }
  };
  others.forEach((asset, i) => {
    if (i === 0) sendSymbol(asset);
    else setTimeout(() => sendSymbol(asset), i * CHANGE_SYMBOL_STAGGER_MS);
  });
  const focusDelay = others.length > 0 ? (others.length - 1) * CHANGE_SYMBOL_STAGGER_MS + CHANGE_SYMBOL_STAGGER_MS : 0;
  if (focus) {
    if (focusDelay === 0) sendSymbol(focus);
    else setTimeout(() => sendSymbol(focus), focusDelay);
  }
}

/**
 * Diffuse la santé d'un asset vers le frontend + journalise (§20/§27).
 * Throttle PAR ASSET : la santé d'EURUSD ne repousse pas celle de XAUUSD.
 */
function emitMarketDataHealth(io: Server, asset: string, force = false): void {
  const pipeline = pipelineManager.get(asset);
  if (!pipeline) return;
  const now = Date.now();
  if (!force && now - (healthEmitTs.get(asset) ?? 0) < 2000) return;
  healthEmitTs.set(asset, now);

  const state = pipeline.getHealth();
  const check = pipeline.canTrade();
  const badge = healthBadge(state, check.allowed);

  // Journal structuré (§20) :
  //   [MARKET-DATA] asset=EURUSD event=HEALTH_UPDATE health=97 status=READY
  //                 tickAge=180ms candleAge=420ms gaps=0
  log(io, 'info', formatStructuredLog('MARKET-DATA', {
    asset,
    event: 'HEALTH_UPDATE',
    health: state.healthScore,
    status: state.status,
    tickAge: state.tickAgeMs != null ? `${Math.round(state.tickAgeMs)}ms` : 'never',
    candleAge: state.candleAgeMs != null ? `${Math.round(state.candleAgeMs)}ms` : 'never',
    gaps: state.gapCount,
    candles: state.candleCount,
    trading: check.allowed ? 'ALLOWED' : `BLOCKED(${check.reason ?? 'UNKNOWN'})`,
  }));

  io.emit('market-data-health', {
    asset,
    health: state,
    trading: check,
    badge,
  });
}

/** Diffuse la santé de TOUS les assets sélectionnés (§27). */
function emitAllMarketDataHealth(io: Server, force = false): void {
  for (const pipeline of pipelineManager.getAll()) {
    emitMarketDataHealth(io, pipeline.asset, force);
  }
}

/** S'assure qu'un pipeline existe pour CHAQUE asset sélectionné (§4). */
function ensurePipelinesForSelection(): void {
  for (const asset of tradingMode.assets) {
    if (registry.has(asset)) pipelineManager.getOrCreate(asset);
  }
  pipelineManager.retainOnly(tradingMode.assets);
}

/**
 * v6.5 — Applique le snapshot des trous de la VALIDATION du synchroniseur au
 * MarketDataHealth de SON asset (avec positions exactes → vieillissement).
 *   · `gapDetails` absent (format léger/legacy) → fallback : compte global
 *     sans position (vieillissement par heure de détection) ;
 *   · `gapDetails` = [] (validation OK) → série contiguë → trous résolus.
 */
function applySyncGapsToHealth(
  asset: string,
  gapDetails: unknown,
): void {
  const pipeline = pipelineManager.get(asset);
  if (!pipeline) return;
  if (Array.isArray(gapDetails)) {
    const holes = (gapDetails as Array<Record<string, unknown>>)
      .map(g => ({
        endTimeSec: typeof g.endTime === 'number' ? g.endTime : undefined,
        startTimeSec: typeof g.startTime === 'number' ? g.startTime : undefined,
        missingCandles: typeof g.missingCandles === 'number' ? g.missingCandles : 1,
      }))
      .filter(g => g.missingCandles > 0);
    // v6.5.1 — bord live (temps marché du dernier tick de CET asset) : sert
    // au vieillissement des trous (isRecent). v6.10 — on passe AUSSI le
    // PREMIER tick du segment live contigu (début du buffer canonique) :
    // combiné à la règle de frontière d'historique (dans MarketDataHealth),
    // c'est LUI qui identifie la COUTURE historique↔live (bougies jamais
    // servies par la source — l'ancienne règle comparait la fin du trou au
    // DERNIER tick : un trou de plusieurs minutes ne pouvait jamais matcher
    // → faux CRITICAL_GAP en multi-assets) → non bloquant, lectures
    // d'analyse coupées à la couture.
    const liveEdge = candleSync.getLatestMarketTimeSec(asset);
    const firstLiveSec = candleSync.getFirstLiveTickSec(asset);
    pipeline.marketDataHealth.onSyncGaps(
      holes,
      Date.now(),
      liveEdge > 0 ? liveEdge : undefined,
      firstLiveSec > 0 ? firstLiveSec : undefined,
    );
    // v6.10.1 — RECOMPTE RÉTROACTIF : la couture vient (peut-être) d'être
    // activée TARD (pagination arrivée minutes après le début du live) → les
    // bougies fraîches clôturées AVANT cette détection n'ont jamais compté
    // pour le warm-up (INSUFFICIENT_CANDLES artificiellement prolongé en
    // multi-assets). On recompte depuis la série canonique de l'asset.
    if (pipeline.marketDataHealth.liveSeamFirstSec != null) {
      pipeline.marketDataHealth.recountFreshCandles(
        candleSync.getClosed(asset, chartPeriodSec(), 2000),
      );
    }
    return;
  }
  // Fallback legacy : nombre de trous sans position.
  const count = typeof gapDetails === 'number' ? gapDetails : 1;
  if (count > 0) pipeline.marketDataHealth.onGapsDetected(count);
}

// sanitizeCandlesByPrice : implémentation dans candle-integrity.ts (module pur partagé tests/prod)
export { sanitizeCandlesByPrice } from "./candle-integrity.js"

// ────────────────────────────────────────────────────────────────────────────
// v6.5.1 — RE-SYNCHRONISATION DES TROUS RÉCENTS BLOQUANTS (§13/§15)
// ────────────────────────────────────────────────────────────────────────────
// Les trous détectés à la clôture (onCandleClosed) n'étaient JAMAIS réparés :
// la machinerie §13 ne se déclenche que sur les événements 'gap-detected' de
// la VALIDATION (ingestHistory). Un trou récent BLOQUANT (vraie perte de
// données — coupure réseau) laissait donc l'asset TRADING BLOQUÉ jusqu'à 50
// min (vieillissement de la fenêtre d'analyse). Ce filet de sécurité
// re-fetch l'historique de l'asset (throttle 60 s, 3 tentatives max) : le
// re-fetch + re-fusion + re-validation comble le trou si le broker l'a, et
// fait autorité sur l'état de santé (onSyncGaps remplace les trous internes).
const gapResyncState = new Map<string, { lastTs: number; attempts: number }>();
const GAP_RESYNC_THROTTLE_MS = 60_000;
const GAP_RESYNC_MAX_ATTEMPTS = 3;

/**
 * Programme un re-fetch d'historique pour réparer les trous récents
 * BLOQUANTS de CET asset (les coutures ne déclenchent PAS de re-fetch :
 * les bougies n'ont jamais existé côté source, c'est une limite).
 */
function scheduleGapResync(io: Server, asset: string): void {
  if (!session.client || !registry.has(asset)) return;
  const size = session.config.candleSize ?? 30;
  const key = `${asset}:${size}`;
  const st = gapResyncState.get(key) ?? { lastTs: 0, attempts: 0 };
  const now = Date.now();
  if (now - st.lastTs < GAP_RESYNC_THROTTLE_MS) return; // throttle par asset
  if (st.attempts >= GAP_RESYNC_MAX_ATTEMPTS) return;   // max 3 tentatives
  st.lastTs = now;
  st.attempts++;
  gapResyncState.set(key, st);
  log(io, 'info', formatStructuredLog('MARKET-DATA', {
    asset,
    event: 'GAP_RESYNC',
    attempt: st.attempts,
    note: 're-fetch historique pour combler les trous récents (§13/§15)',
  }));
  fetchAndBroadcastHistory(io, asset, size, session.config.historyCount ?? 300, 'gap-resync')
    .catch(() => { /* best-effort */ });
}

function onChartCandleClosed(asset: string, periodSec: number, closedChartCandle: BuilderCandle): void {
  // §9/§26 : TOUT asset sélectionné est traité — pas seulement le focus.
  const ctx = registry.getAssetContext(asset);
  if (!ctx) return;                                     // asset non sélectionné
  if (periodSec !== chartPeriodSec()) return;           // clôture d'un AUTRE timeframe

  // ── v6.4 : PIPELINE DE CET ASSET — santé de la bougie clôturée (§10) ────
  // La clôture nourrit le MarketDataHealth DE CET asset (fraîcheur, gaps,
  // doublons, ordre, OHLC). Aucun autre pipeline n'est touché.
  const closedPipeline = pipelineManager.get(asset);
  const healthState = pipelineManager.processCandle(asset, closedChartCandle);

  // v6.5.1 — filet de sécurité : un trou récent BLOQUANT (pas une couture)
  // détecté à la clôture → re-fetch d'historique ciblé pour le réparer.
  if (healthState) {
    const blockingGaps = (healthState.recentGapCount ?? 0) - (healthState.seamGapCount ?? 0);
    if (blockingGaps > 0) {
      scheduleGapResync(io, asset);
    } else if (healthState.seamFirstLiveSec == null) {
      // Sain (aucun trou ni couture) → reset du compteur de tentatives.
      gapResyncState.delete(`${asset}:${periodSec}`);
    }
  }

  // §28 — une bougie déjà traitée pour CET asset ne l'est jamais deux fois.
  if (closedChartCandle.time <= ctx.candleState.lastProcessedCandleTime) return;
  ctx.candleState.lastProcessedCandleTime = closedChartCandle.time;
  // (Les moteurs d'analyse par asset sont nourris par les ticks et bougies
  //  du pipeline ; L_Lucien ProTrader est évalué par la boucle de polling
  //  sur bougies CLÔTURÉES.)

}

// ────────────────────────────────────────────────────────────────────────────
// RÉPARATION DES TROUS (§13/§16) — détection → demande d'historique ciblée
// (avec zone de recouvrement) → normalisation → fusion → revalidation.
// Throttle 60 s + max 3 tentatives par série (gérés par requestRepair).
// ────────────────────────────────────────────────────────────────────────────

async function repairDetectedGaps(asset: string, periodSec: number): Promise<void> {
  if (!session.client) return;
  if (!registry.has(asset) || chartPeriodSec() !== periodSec) return;
  const lastAttempt = gapRepairStates.get(asset) ?? 0;
  if (Date.now() - lastAttempt < 60_000) return; // throttle PAR ASSET
  gapRepairStates.set(asset, Date.now());

  const req = candleSync.requestRepair(asset, periodSec);
  if (!req.started) return;

  // Les gaps de couture historique↔live ou très anciens sont informatifs et
  // ne doivent jamais déclencher une rafale de fetchs. On ne répare que les
  // trous réellement récents, hors couture, avec un budget strict par passe.
  const nowSec = Math.floor(Date.now() / 1000);
  const firstLiveSec = candleSync.getFirstLiveTickSec(asset);
  const maxRepairAgeSec = Math.max(30 * 60, periodSec * 120);
  const repairableGaps = req.gaps
    .filter((gap) => {
      const age = nowSec - gap.endTime;
      if (age < -periodSec || age > maxRepairAgeSec) return false;
      if (firstLiveSec > 0 && gap.endTime <= firstLiveSec + periodSec) return false;
      return gap.missingCandles > 0;
    })
    .sort((a, b) => a.endTime - b.endTime)
    .slice(0, 4);

  if (repairableGaps.length === 0) {
    candleSync.abortRepair(asset, periodSec);
    return;
  }

  let repaired = 0;
  let failed = 0;
  for (const gap of repairableGaps) {
    try {
      // offset = bougies manquantes + 2 de recouvrement de chaque côté (§6).
      const res = await session.client.market.loadHistoryPeriod({
        asset,
        time: gap.endTime,
        offset: Math.min(gap.missingCandles + 2, 2000),
        period: periodSec as any,
      });
      if (res?.candles?.length) {
        const mapped = res.candles.map(c => ({
          time: c.time, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume ?? 0,
        }));
        candleSync.ingestHistory(asset, periodSec, mapped, { generation: req.generation, source: 'history' });
        repaired++;
      } else {
        failed++;
      }
    } catch {
      failed++;
    }
  }

  if (repaired === 0 && failed > 0) {
    candleSync.abortRepair(asset, periodSec);
  }
  const report = candleSync.getSyncReport(asset, periodSec);
  syncLogSink?.(
    report.state === 'SYNCED' ? 'info' : 'warning',
    `[SYNC] réparation ${asset} S${periodSec}: ${repaired} fetch(es) OK / ${failed} échec(s) — ` +
    `état final=${report.state}, trous restants=${report.gaps.length}`,
  );
}

// Track seen closed deal IDs to avoid processing old deals
const seenClosedDeals = new Set<string>();

// ── WATCHDOG DE RÈGLEMENT MARTINGALE (multi-assets) ─────────────────────────
// Dernier refreshClosedDeals() global (throttle ~5 s — une requête broker
// partagée par tous les assets en attente).
let lastClosedDealsRefreshTs = 0;
/** Règlements LOCAUX déjà écrits par le watchdog (clé du tracked deal) :
 *  un tracked deal ne peut jamais être réglé deux fois localement. */
const watchdogLocalSettled = new Set<string>();

/**
 * v19 — Seuils des étages du watchdog, surchargeables par env pour les tests
 * E2E (horloge comprimée) SANS toucher aux défauts production :
 *   PO_WATCHDOG_TIER1_MS (défaut 20 000) — étage (1) scan cache broker ;
 *   PO_WATCHDOG_TIER2_MS (défaut 45 000) — étage (2) règlement LOCAL.
 * En production, AUCUNE de ces variables n'est définie : comportement
 * strictement identique aux versions précédentes (20 s / 45 s).
 */
const WATCHDOG_TIER1_MS = (() => {
  const v = Number(process.env.PO_WATCHDOG_TIER1_MS);
  return Number.isFinite(v) && v >= 1_000 ? Math.floor(v) : 20_000;
})();
const WATCHDOG_TIER2_MS = (() => {
  const v = Number(process.env.PO_WATCHDOG_TIER2_MS);
  if (Number.isFinite(v) && v >= WATCHDOG_TIER1_MS + 1_000) return Math.floor(v);
  // Défaut production 45 s — mais TOUJOURS après l'étage (1).
  return Math.max(45_000, WATCHDOG_TIER1_MS + 1_000);
})();

/** Échéance attendue d'un deal suivi (ms locaux) — openTime broker si
 *  disponible, sinon l'horodatage local du placement (toujours présent). */
function trackedDealExpectedCloseMs(tracked: { openTime?: number; placedAtMs?: number; expirationSeconds: number }): number {
  const openMs = (tracked.openTime != null && tracked.openTime > 0)
    ? tracked.openTime * 1000
    : (tracked.placedAtMs ?? Date.now());
  return openMs + tracked.expirationSeconds * 1000;
}

/**
 * WATCHDOG DE RÈGLEMENT — garantit que TOUT deal suivi finit par faire
 * avancer la Martingale/Fibonacci de SON asset, même quand l'événement
 * deal_closed n'arrive jamais (règlement non publié pour un asset non
 * focus, event perdu à la reconnexion, id en collision dédoublonné, champ
 * asset absent…). Trois étages, du plus sûr au plus robuste :
 *
 *   (0) < 20 s après l'échéance : fenêtre NORMALE — le broker pousse le
 *       règlement, le watchdog ne fait RIEN (zéro interférence) ;
 *   (1) ≥ 20 s : scan du cache SDK des deals fermés (tous assets mélangés)
 *       + demande de renvoi (refreshClosedDeals, throttle 5 s) → le
 *       rattachement par empreinte s'applique au contexte de SON asset ;
 *   (2) ≥ 45 s : ULTIME RECOUS — règlement LOCAL calculé depuis les ticks
 *       du MÊME flux broker (updateStream, celui des bougies) : prix du
 *       tick le plus proche de l'instant d'échéance vs prix d'entrée.
 *       Sans ce filet, la Martingale des assets ignorés par les pushes du
 *       broker resterait figée à la mise de base POUR TOUJOURS (bug
 *       utilisateur : « les ordres continuent de s'enchaîner sur la mise
 *       de base »). Un égalité exacte (tie) n'est JAMAIS réglée localement
 *       (le broker reste l'autorité des remboursements) ; faute de données
 *       le deal est purgé après 5 min avec un log explicite.
 *
 * Ce watchdog ne fait JAMAIS double emploi : applyDealResult supprime le
 * tracked deal dès qu'un règlement (event OU watchdog) est appliqué, et
 * un règlement broker tardif ne trouve plus aucun tracked deal à régler.
 */
/** v17 — Libellé de résultat TROIS états pour les logs :
 *  WIN ✓ / LOSS ✗ / TIE ⟲ (mise conservée — Tie/Refund, P&L = 0). */
function outcomeLabel(outcome: BettingOutcome): string {
  return outcome === 'win' ? 'WIN ✓' : outcome === 'loss' ? 'LOSS ✗' : 'TIE ⟲ (remboursé, mise conservée)';
}

function runMartingaleSettlementWatchdog(io: Server): void {
  if (!session.client) return;
  const now = Date.now();
  // Cache SDK des deals fermés — lu paresseusement (une seule fois par cycle).
  let cachedDeals: unknown[] | null = null;
  let askedRefresh = false;

  for (const [asset, ctx] of registry.entries()) {
    for (const [key, tracked] of [...ctx.trackedDeals.entries()]) {
      const expectedCloseMs = trackedDealExpectedCloseMs(tracked);
      const ageMs = now - expectedCloseMs;
      if (ageMs < WATCHDOG_TIER1_MS) continue; // (0) fenêtre normale du broker

      // (1) Le règlement traîne-t-il dans le cache SDK (updateClosedDeals) ?
      if (cachedDeals === null) {
        try {
          cachedDeals = (session.client as any).account?.getClosedDeals?.() ?? [];
        } catch { cachedDeals = []; }
      }
      let settledByCache = false;
      for (const raw of cachedDeals) {
        if (!raw || typeof raw !== 'object') continue;
        const d = raw as Record<string, unknown>;
        const dAsset = String(d.asset ?? '');
        if (dAsset && dAsset !== asset) continue;
        // v17 — classification TROIS états : un Tie/Refund (profit = 0 avec
        // vraie signature de clôture) est un état NEUTRE qui ne modifie pas
        // l'index de la suite de mises (mise conservée pour l'ordre suivant).
        const settledOutcome = classifySettledOutcome({
          id: d.id as string | number | null,
          asset: dAsset,
          closeTime: Number(d.closeTime ?? 0),
          profit: Number(d.profit ?? 0),
          isWin: d.isWin == null ? null : !!d.isWin,
        });
        const match = findTrackedDealByFingerprint(ctx, {
          id: String(d.id ?? ''),
          asset: dAsset,
          amount: Number(d.amount ?? 0),
          openPrice: Number(d.openPrice ?? 0),
          closePrice: Number(d.closePrice ?? 0),
          openTime: Number(d.openTime ?? 0),
          closeTime: Number(d.closeTime ?? 0),
          profit: Number(d.profit ?? 0),
          isWin: d.isWin == null ? null : !!d.isWin,
        });
        if (match && match.key === key) {
          const res = applyDealResult(ctx, key, settledOutcome);
          if (res) {
            settledByCache = true;
            log(io, 'info', assetLog(asset,
              `deal #${String(d.id)} récupéré du cache broker par le watchdog (${Math.round(ageMs / 1000)}s après l'échéance) — ` +
              `résultat ${outcomeLabel(res.outcome)} appliqué à la Martingale/Fibonacci de ${asset} (prochaine mise ${res.nextBetAmount}).`));
            io.emit('auto-trade-status', buildAutoTradeStatus());
            break;
          }
        }
      }
      if (settledByCache || !ctx.trackedDeals.has(key)) continue;

      // Demande de renvoi des règlements (throttle global ~5 s).
      if (!askedRefresh && now - lastClosedDealsRefreshTs > 5_000) {
        lastClosedDealsRefreshTs = now;
        askedRefresh = true;
        try { session.client.refreshClosedDeals?.(); } catch { /* fail-safe */ }
      }
      if (ageMs < WATCHDOG_TIER2_MS) continue; // encore dans la fenêtre de patience

      // (2) ULTIME RECOUS : règlement LOCAL par les ticks du flux broker.
      if (watchdogLocalSettled.has(key)) continue;
      const openPrice = tracked.openPrice ?? null;
      const expSec = expectedCloseMs / 1000;
      let bestTick: { time: number; price: number } | null = null;
      try {
        for (const t of candleSync.getTickBuffer(asset)) {
          if (t.time > expSec + 10) break; // triés chronologiquement
          if (!bestTick || Math.abs(t.time - expSec) < Math.abs(bestTick.time - expSec)) bestTick = t;
        }
      } catch { /* fail-safe */ }
      // Tie (égalité exacte) ou données insuffisantes → le broker reste
      // l'autorité : pas de règlement local ce cycle.
      if (!bestTick || openPrice == null || bestTick.price === openPrice) {
        if (ageMs > 300_000) {
          // Purgé honnêtement : ce deal n'a reçu AUCUN règlement exploitable.
          ctx.trackedDeals.delete(key);
          noteDealClosed(ctx, key);
          log(io, 'warning', assetLog(asset,
            `deal #${String(key).slice(0, 8)}… purgé après 5 min sans règlement broker ni ticks exploitables — ` +
            `la Martingale de ${asset} n'a PAS été avancée par ce deal.`));
        }
        continue;
      }
      watchdogLocalSettled.add(key);
      const localWin = tracked.action === 'put' ? bestTick.price < openPrice : bestTick.price > openPrice;
      const res = applyDealResult(ctx, key, localWin);
      if (res) {
        log(io, 'warning', assetLog(asset,
          `[WATCHDOG] règlement LOCAL après ${Math.round(ageMs / 1000)}s sans publication broker — deal #${String(key).slice(0, 8)}… ` +
          `${localWin ? 'WIN ✓' : 'LOSS ✗'} (entrée ${openPrice} → clôture ${bestTick.price} du flux de ticks, ${tracked.action?.toUpperCase() ?? 'CALL'}) — ` +
          `Martingale/Fibonacci de ${asset} mise à jour (prochaine mise ${res.nextBetAmount}).`));
        io.emit('trade-closed', {
          asset,
          deal: {
            id: key, asset, action: tracked.action ?? 'call', amount: tracked.amount,
            openPrice, closePrice: bestTick.price,
            openTime: Math.floor(expSec - tracked.expirationSeconds),
            closeTime: Math.floor(bestTick.time),
            profit: localWin ? tracked.amount : -tracked.amount,
            isWin: localWin, isDemo: session.mode === 'demo' ? 1 : 0,
          },
          isWin: localWin, profit: localWin ? tracked.amount : -tracked.amount,
        });
        io.emit('auto-trade-status', buildAutoTradeStatus());
      }
      if (watchdogLocalSettled.size > 1000) {
        const arr = Array.from(watchdogLocalSettled);
        watchdogLocalSettled.clear();
        arr.slice(-400).forEach(k => watchdogLocalSettled.add(k));
      }
    }
  }
}


const session: ClientSession = {
  client: null,
  market: null,
  mode: 'demo',
  credentials: null,
  resumedOnce: false,
  startedAt: Date.now(),
  heartbeatTimer: null,
  heartbeatLastTicks: 0,
  config: { ...DEFAULT_CONFIG },
  candlesCaptured: 0,
  closeWindow: [],
  lastTradeTs: 0,
  lastOrderPlacedTs: 0,
  lastSignal: 'none',
  strategyRunning: false,
  strategyLoopTimer: null,
  statusBroadcastTimer: null,
  liveTicksTotal: 0,
  liveTicksForMarket: 0,
  lastTickTs: 0,
  lastTickPrice: 0,
  lastTickActiveId: 0,
  lastTickSize: 0,
  openedDeals: [],
  closedDeals: [],
  lastTradeAction: 'call',
  pendingPatternTrades: new Map(),
  lastPatternTradeId: '',
  lastPatternId: '',
  startBalance: 0,
  manualDealIds: new Set(),
  manualTradePending: false,
  manualTradePendingTs: 0,
  lastManualDealCloseTs: 0,
  lastAutoSwitchTs: 0,
  lastSettledWin: null,
  reloginDeferredSince: 0,
  reloginInProgress: false,
  reloginTimer: null,
  assetSwitchInProgress: false,
  autoSwitchEvalTimer: null,
  liveTradeIds: new Set(),
  seenClosedDealFingerprints: new Set(),
};

// --------------------------------------------------------------------------
//  v20 — AUTO SWITCH ASSETS : payout < 92% + dernier ordre = GAIN → switch
//         vers un asset payout == 92% (nouvelles règles utilisateur).
// --------------------------------------------------------------------------
//  Tourne côté backend sur CHAQUE poussée `updateAssets` du broker → actif
//  même sans frontend connecté (continuité headless). Détails : payout-guard.ts.
const payoutGuard: {
  config: PayoutGuardConfig;
  state: PayoutGuardState;
  /** Throttle du log « aucun candidat == 92% » (1 / min max). */
  lastNoCandidateLogTs: number;
  /** Assets dont le switch attend un GAIN (log unique, pas de spam). */
  waitForWinNoted: Set<string>;
} = {
  config: { ...DEFAULT_PAYOUT_GUARD_CONFIG },
  state: createPayoutGuardState(),
  lastNoCandidateLogTs: 0,
  waitForWinNoted: new Set(),
};

// --------------------------------------------------------------------------
//  v6.3 — PERSISTANCE DE SESSION (survit aux redémarrages du backend)
// --------------------------------------------------------------------------
//  data/backend-session.json : mode + assets + config auto-trade. Les mots de
//  passe ne sont JAMAIS persistés. SESSION_SNAPSHOT_DIR=0 pour désactiver.
const SESSION_SNAPSHOT_PATH = defaultSessionSnapshotPath(BACKEND_DIR);

/** État de trading courant → snapshot persistable (fire-and-forget). */
function buildSessionSnapshot(): PersistedSession {
  return {
    version: 1,
    savedAt: Date.now(),
    mode: tradingMode.mode,
    assets: [...tradingMode.assets],
    focus: tradingMode.focus,
    config: {
      ...(session.config as any),
      baseAmount: parseFloat(session.config.margin) || 1,
      autoTradeEnabled: session.config.autoTradeEnabled,
    },
    payoutGuardEnabled: payoutGuard.config.enabled,
  };
}

/** Sauvegarde best-effort (jamais bloquante, jamais fatale).
 *  Sans assets sélectionnés : rien à restaurer → pas d'écriture. */
function saveSessionSnapshot(): void {
  if (!SESSION_SNAPSHOT_PATH || tradingMode.assets.length === 0) return;
  void savePersistedSession(SESSION_SNAPSHOT_PATH, buildSessionSnapshot());
}

/** Applique un snapshot persisté : sélection d'assets + config auto-trade. */
function restoreSessionSnapshot(io: Server, snap: PersistedSession, resumeAutoTrade = false): void {
  // Restore the complete saved configuration first. Known fields below are
  // still sanitized/clamped individually; unknown future fields are kept so
  // Save/Load remains forward-compatible.
  const rawConfig = snap.config as Record<string, unknown>;
  const savedAutoTradeEnabled = rawConfig.autoTradeEnabled === true;
  for (const [key, value] of Object.entries(rawConfig)) {
    if (key === 'baseAmount' || value === undefined) continue;
    (session.config as any)[key] = value;
  }
  // Never let a restore arm the strategy while subscriptions/history are being rebuilt.
  session.config.autoTradeEnabled = false;
  if (typeof rawConfig.baseAmount === 'number' && Number.isFinite(rawConfig.baseAmount) && rawConfig.baseAmount >= 1) {
    session.config.margin = String(rawConfig.baseAmount);
  }

  // 1. Config auto-trade (stratégie, expiration champ Auto Trade, mise, …).
  if (snap.config.strategyId) {
    // Alias legacy : les anciens ids mappés vers L_Lucien ProTrader.
    const requested = snap.config.strategyId === 'bos_choch_cisd' ? 'l_lucien_protrader' : snap.config.strategyId;
    const s = AUTO_TRADE_STRATEGIES.find((x) => x.id === requested);
    if (s) session.config.strategyId = s.id;
  }
  if (snap.config.bettingStrategy) session.config.bettingStrategy = snap.config.bettingStrategy;
  if (typeof snap.config.baseAmount === 'number' && snap.config.baseAmount >= 1) {
    session.config.margin = String(snap.config.baseAmount);
  }
  // v19 — garde-fou Martingale + switch « Confirmation bougie précédente » :
  // valeurs déjà sanitizées par sanitizePersistedSession, re-clampées ici
  // par sécurité (le raw loop ci-dessus a copié les champs bruts).
  session.config.maxMartingaleSteps = clampMaxMartingaleSteps(snap.config.maxMartingaleSteps);
  if (typeof snap.config.bosChochCisdConfirmCandle === 'boolean') {
    session.config.bosChochCisdConfirmCandle = snap.config.bosChochCisdConfirmCandle;
  } else {
    session.config.bosChochCisdConfirmCandle = false;
  }
  // v24 — étapes de vérification CISD optionnelles : sanitisation stricte
  // (booléens sinon défaut v23 ; swingMode ∈ {'intact','violated'}).
  session.config.cisdGuardUp = snap.config.cisdGuardUp !== false;
  session.config.cisdGuardDown = snap.config.cisdGuardDown !== false;
  session.config.cisdGuardSwingMode = snap.config.cisdGuardSwingMode === 'violated' ? 'violated' : snap.config.cisdGuardSwingMode === 'none' ? 'none' : 'intact';
  session.config.cisdGuardConfirmBosUp = snap.config.cisdGuardConfirmBosUp !== false;
  session.config.cisdGuardConfirmChochUp = snap.config.cisdGuardConfirmChochUp !== false;
  session.config.cisdGuardConfirmBosDown = snap.config.cisdGuardConfirmBosDown !== false;
  session.config.cisdGuardConfirmChochDown = snap.config.cisdGuardConfirmChochDown !== false;
  if (typeof snap.config.expirySeconds === 'number' && snap.config.expirySeconds > 0) {
    session.config.expirySeconds = snapExpiry(snap.config.expirySeconds); // clamp seul (v6.3)
  }
  if (typeof snap.config.candleSize === 'number' && snap.config.candleSize >= 1) {
    session.config.candleSize = snap.config.candleSize;
  }
  // 2. Sélection d'assets (validation backend systématique — §3).
  const validation = validateAssetSelection({ mode: snap.mode, assets: snap.assets });
  if (validation.ok) {
    applyAssetSelection(io, validation.mode, validation.assets);
    // v20 — TASK « revenir sur l'asset en cours » : restaure le FOCUS sauvegardé
    // (sans cela, applyAssetSelection retombe sur assets[0] — le premier de la
    // liste — au lieu de l'asset réellement affiché avant le re-login/refresh/
    // redémarrage). Ex. : asset en cours USDJPY_OTC → retour sur USDJPY_OTC.
    if (snap.focus && validation.assets.includes(snap.focus) && tradingMode.focus !== snap.focus) {
      tradingMode.focus = snap.focus;
      session.market = registry.getAssetContext(snap.focus)?.market ?? getMarket(snap.focus);
      session.config.market = snap.focus;
      log(io, 'info', `[RESTORE] focus restauré sur l'asset en cours : ${snap.focus}`);
    }
    log(io, 'info',
      `[RESTORE] session restaurée — mode=${validation.mode}, ${validation.assets.length} asset(s): ` +
      `${validation.assets.join(', ')} · focus=${tradingMode.focus ?? '—'} · stratégie=${session.config.strategyId} · ` +
      `expiration=${session.config.expirySeconds ?? '—'}s · auto-trade=${savedAutoTradeEnabled ? 'ON' : 'OFF'}${resumeAutoTrade ? ' (resume scheduled)' : ''}`);
  }
  if (resumeAutoTrade && savedAutoTradeEnabled) {
    session.config.autoTradeEnabled = true;
    for (const [, ctx] of registry.entries()) {
      ctx.autoTrade.enabled = !!session.config.autoOpen;
    }
  } else {
    session.config.autoTradeEnabled = false;
  }
}

// --------------------------------------------------------------------------
//  v20 — AUTO SWITCH ASSETS : exécution (sur chaque poussée updateAssets)
// --------------------------------------------------------------------------
/**
 * NOUVELLES RÈGLES (v20 — remplacement des anciennes règles post-trade +
 * 90s idle) :
 *   « Dès que le pourcentage de profit de l'asset en cours baisse à une
 *     valeur < 92 % ET que le dernier ordre est un GAIN (et non une perte),
 *     on switch d'assets automatiquement — QUE sur des assets avec profit
 *     == 92 %. »
 *
 * Évalue la politique (payout-guard.ts) et APPLIQUE les décisions :
 *   - MULTI : remplace l'asset EN CONSERVANT sa position dans la liste ;
 *   - SINGLE (« l'asset en cours ») : switch complet + refresh via
 *     switchAssetAndRefresh (l'Auto Trade du nouvel asset est conservé).
 * Journalise, notifie le frontend et persiste la nouvelle sélection.
 * Les positions ouvertes ne sont jamais interrompues ; un asset dont le
 * dernier ordre est une PERTE attend son gain avant d'être quitté.
 */
function runPayoutGuard(io: Server, assetsMap: Record<string, { payout?: number; isOpen?: boolean }>): void {
  // Master asset-switch gate: when Auto-switch is OFF, no subsystem (including
  // payout protection) is allowed to replace an asset automatically.
  if (session.config.autoSwitchAssets !== true) return;
  if (session.reloginInProgress || session.assetSwitchInProgress) return;
  if (tradingMode.assets.length === 0) return;
  const now = Date.now();
  prunePayoutGuardState(payoutGuard.state, tradingMode.assets);

  const payouts: Record<string, PayoutSnapshot> = {};
  for (const a of Object.values(assetsMap)) {
    // AssetsMap est indexée par ID NUMÉRIQUE ('66', '67'…) — le moteur de
    // règles travaille par NOM d'asset ('EURUSD_otc') : on re-indexe par nom.
    const name = String((a as any)?.name ?? '').trim();
    if (!name) continue;
    payouts[name] = { payout: (a as any)?.payout, isOpen: (a as any)?.isOpen };
  }
  const openPositionsByAsset: Record<string, number> = {};
  const lastOrderWinByAsset: Record<string, boolean | null> = {};
  for (const asset of tradingMode.assets) {
    const ctx = registry.getAssetContext(asset);
    openPositionsByAsset[asset] = ctx?.openPositions.length ?? 0;
    lastOrderWinByAsset[asset] = ctx?.autoTrade.lastOrderWin ?? null;
  }

  const decisions = evaluatePayoutGuard(payoutGuard.state, {
    mode: tradingMode.mode,
    activeAssets: [...tradingMode.assets],
    focus: tradingMode.focus,
    payouts,
    openPositionsByAsset,
    lastOrderWinByAsset,
    // v21 — « Stay on Forex OTC Only » : les candidats de remplacement sont
    // filtrés sur les seules paires FOREX OTC quand le switch est ON.
    forexOtcOnly: session.config.stayOnForexOtcOnly === true,
    now,
    config: payoutGuard.config,
  });
  if (decisions.length === 0) {
    // Diagnostic « en attente de gain » — log UNE fois par asset (pas de spam
    // à chaque poussée updateAssets). Effacé dès que la condition se débloque.
    for (const asset of tradingMode.assets) {
      const payout = payouts[asset]?.payout;
      const lastWin = lastOrderWinByAsset[asset];
      const waiting = typeof payout === 'number' && payout < AUTO_SWITCH_TRIGGER_PCT && lastWin === false;
      if (waiting && !payoutGuard.waitForWinNoted.has(asset)) {
        payoutGuard.waitForWinNoted.add(asset);
        log(io, 'info', assetLog(asset,
          `[AUTO-SWITCH] payout ${payout}% (< ${AUTO_SWITCH_TRIGGER_PCT}%) mais le dernier ordre est une PERTE — switch en attente du prochain GAIN`));
      } else if (!waiting && payoutGuard.waitForWinNoted.has(asset)) {
        payoutGuard.waitForWinNoted.delete(asset);
      }
    }
    return;
  }
  payoutGuard.waitForWinNoted.clear();

  for (const d of decisions) {
    commitPayoutSwap(payoutGuard.state, d, now);
    if (tradingMode.mode === 'multi') {
      // Remplacement en conservant la POSITION dans la liste (cf. switch-asset).
      const nextAssets = tradingMode.assets.map((a) => (a === d.from ? d.to : a));
      applyAssetSelection(io, tradingMode.mode, nextAssets);
      // v21 — REFRESH OBLIGATOIRE DU FRONTEND à chaque Auto Switch Assets
      // (mode MULTI : applyAssetSelection ne passe PAS par
      // switchAssetAndRefresh — on émet ici après application de la sélection).
      io.emit('force-frontend-refresh', { reason: 'auto-switch', from: d.from, to: d.to, at: Date.now() });
    } else {
      // SINGLE : « l'asset en cours » — switch complet + refresh candles.
      // (switchAssetAndRefresh émet lui-même force-frontend-refresh une fois
      // le backend reconstruit.)
      void switchAssetAndRefresh(io, d.from, d.to, 'auto-switch payout<92% + dernier ordre GAIN', d.toPayout);
    }
    saveSessionSnapshot();
    log(io, 'info',
      `[AUTO-SWITCH] ${d.from} payout ${d.fromPayout}% (< ${AUTO_SWITCH_TRIGGER_PCT}%) · dernier ordre = GAIN ` +
      `→ remplacé par ${d.to} (${d.toPayout}% == ${AUTO_SWITCH_TARGET_PCT}%)` +
      (session.config.stayOnForexOtcOnly === true ? ' · Forex OTC uniquement' : ''));
    io.emit('payout-guard-swap', d);
    io.emit('assets-selected', {
      ok: true,
      mode: tradingMode.mode,
      assets: [...tradingMode.assets],
      focus: tradingMode.focus,
    });
  }
  io.emit('payout-guard-status', payoutGuardSummary(payoutGuard.state, payoutGuard.config));
}

// --------------------------------------------------------------------------
//  v6.3 — HEARTBEAT HEADLESS : le backend continue SANS frontend
// --------------------------------------------------------------------------
//  Fermer Chrome ne coupe que le socket.io UI : la connexion broker, les
//  subscriptions, les contextes par asset et l'auto-trade continuent. Ce
//  heartbeat loggue la preuve de vie toutes les 60 s (visible dans les logs
//  ET dans l'UI via l'event 'log').
function startBackendHeartbeat(io: Server): void {
  if (session.heartbeatTimer) clearInterval(session.heartbeatTimer);
  session.heartbeatLastTicks = session.liveTicksTotal;
  session.heartbeatTimer = setInterval(() => {
    const uptimeMs = Date.now() - session.startedAt;
    const upMin = Math.floor(uptimeMs / 60_000);
    const ticksPerMin = Math.max(0, session.liveTicksTotal - session.heartbeatLastTicks);
    session.heartbeatLastTicks = session.liveTicksTotal;
    const openPos = session.openedDeals.length;
    const balance = session.client?.account?.getCurrentBalance?.();
    log(io, 'info',
      `[BACKEND] actif (headless OK) — uptime ${Math.floor(upMin / 60)}h${String(upMin % 60).padStart(2, '0')} · ` +
      `${tradingMode.assets.length} asset(s) [${tradingMode.mode}] · auto-trade ${session.config.autoTradeEnabled ? 'ON' : 'OFF'}` +
      `${session.config.autoTradeEnabled ? ` (${session.config.strategyId})` : ''} · ${openPos} position(s) ouverte(s) · ` +
      `~${ticksPerMin} ticks/min · balance ${balance != null ? Number(balance).toFixed(2) : '—'}`);
    io.emit('backend-heartbeat', {
      ts: Date.now(),
      uptimeMs,
      assets: [...tradingMode.assets],
      mode: tradingMode.mode,
      autoTradeEnabled: session.config.autoTradeEnabled,
      strategyId: session.config.strategyId,
      openPositions: openPos,
      balance: balance != null ? Number(balance) : null,
      ticksPerMin,
    });
  }, 60_000);
}

// --------------------------------------------------------------------------
//  Helpers
// --------------------------------------------------------------------------

let lastLogKey = '';
let lastLogAt = 0;
const noisyLogPatterns = [
  /config updated:/i,
  /balance update:/i,
  /heartbeat/i,
];
function log(io: Server, level: string, message: string) {
  const verbose = process.env.LOG_VERBOSE === '1';
  if (!verbose && level === 'info' && noisyLogPatterns.some((re) => re.test(message))) return;
  const now = Date.now();
  const key = `${level}|${message}`;
  if (!verbose && level === 'info' && key === lastLogKey && now - lastLogAt < 15_000) return;
  lastLogKey = key; lastLogAt = now;
  const compact = message.length > 700 ? `${message.slice(0, 690)}…` : message;
  const ts = new Date(now).toISOString();
  console.log(`[${ts}] [${level}] ${compact}`);
  io.emit('log', { ts, level, message: compact });
}

interface FrontendPosition {
  id: string;
  external_id: number;
  active_id: number;
  side: 'call' | 'put';
  status: string;
  open_quote: number;
  invest: number;
  pnl: number;
  pnl_net: number;
  current_price: number;
  leverage: string;
  open_time: number;
  /** Asset de la position (multi-assets — §21). */
  asset?: string;
}

function toFrontendPositions(deals: OpenedDeal[], currentPrice: number): FrontendPosition[] {
  // Compteur global pour garantir l'unicité des clés même si tous les autres champs sont identiques
  // (UUID manquant + openTime=0 + même asset → clés dupliquées).
  // On utilise un compteur externe qui ne se réinitialise qu'au redémarrage du backend.
  // MULTI-ASSETS : le prix courant et l'active_id sont résolus PAR ASSET
  // (le prix d'EURUSD ne doit pas évaluer le P/L d'une position BTCUSD).
  return deals.map((d, idx) => {
    const dealAsset = (typeof d.asset === 'string' && d.asset.length > 0) ? d.asset : chartAsset();
    const ctx = registry.getAssetContext(dealAsset);
    const price = assetLastPrice(dealAsset) || currentPrice;
    // Pour les options binaires, le P/L n'est réalisé qu'à l'expiration.
    // On estime le P/L non réalisé en fonction du prix courant vs prix d'ouverture.
    const delta = price - d.openPrice;
    const inFavor = (d.action === 'call' && delta > 0) || (d.action === 'put' && delta < 0);
    const estPnl = inFavor ? d.amount * 0.87 : -d.amount; // ~87% payout typical

    // Helper: garantir qu'un nombre est fini (jamais NaN), sinon renvoyer fallback.
    const finiteOr = (v: unknown, fb: number): number =>
      (typeof v === 'number' && Number.isFinite(v)) ? v : fb;

    // L'ID peut être un UUID string ou un number.
    // On évite String(NaN) = "NaN" qui ferait que tous les deals ont le même key React "NaN".
    const cleanId = finiteOr(d.id, 0);
    const cleanOpenTime = finiteOr(d.openTime, 0);
    const cleanAsset = (typeof d.asset === 'string' && d.asset.length > 0) ? d.asset : 'unknown';

    let safeId: string;
    if (typeof d.id === 'string' && d.id.length > 0 && d.id !== 'NaN') {
      // UUID string valide → on l'utilise tel quel
      safeId = d.id;
    } else if (cleanId > 0) {
      // ID numérique valide
      safeId = String(cleanId);
    } else {
      // Fallback garanti unique: asset + openTime + index global
      // Si openTime est 0 (manquant), on ajoute idx + un compteur de session pour éviter les collisions.
      safeId = `deal-${cleanAsset}-${cleanOpenTime}-i${idx}-${toFrontendPositionsCounter++}`;
    }

    return {
      id: safeId,
      external_id: cleanId,
      active_id: ctx?.market.active_id ?? session.market?.active_id ?? 0,
      side: d.action,
      status: 'open',
      open_quote: finiteOr(d.openPrice, 0),
      invest: finiteOr(d.amount, 0),
      pnl: estPnl,
      pnl_net: estPnl,
      current_price: price,
      leverage: '1',
      open_time: cleanOpenTime,
      asset: dealAsset,
    };
  });
}
// Compteur global pour garantir l'unicité des clés de fallback à travers les appels successifs.
let toFrontendPositionsCounter = 0;

interface FrontendBalance {
  id: number;
  user_id: number;
  type: number;     // 4 = demo (pour compat UI IQOption)
  amount: number;
  currency: string;
  is_cent: boolean;
}

function toFrontendBalance(amount: number, currency: string, isDemo: boolean): FrontendBalance {
  return {
    id: 1,
    user_id: session.client?.getSession()?.uid ?? 0,
    type: isDemo ? 4 : 1,    // 4 = demo dans IQOption, 1 = real
    amount,
    currency,
    is_cent: false,
  };
}

/**
 * Statut PAR ASSET pour le payload de statut (diffusé 1 Hz).
 * Chaque entrée ne contient QUE les données de SON asset — le frontend
 * l'utilise pour les cartes AssetTradingCard (§25).
 */
function buildAssetStatusEntry(ctx: AssetTradingContext) {
  const tick = assetTickStats.get(ctx.asset);
  const positions = toFrontendPositions(ctx.openPositions, tick?.price ?? 0);
  // v6.4 — Santé des données de CET asset (§27) : badge + score + verdict.
  const pipeline = pipelineManager.get(ctx.asset);
  const healthState = pipeline ? pipeline.getHealth() : null;
  const healthCheck = pipeline ? pipeline.canTrade() : null;
  const badge: UiHealthBadge | null = healthState && healthCheck
    ? healthBadge(healthState, healthCheck.allowed)
    : null;
  return {
    asset: ctx.asset,
    active_id: ctx.market.active_id,
    long_name: ctx.market.long_name,
    payout: ctx.market.payout ?? null,
    price: tick?.price ?? 0,
    lastTickTs: tick?.ts ?? 0,
    live: !!tick && Date.now() - tick.ts < 5000,
    ticks: tick?.count ?? 0,
    isFocus: tradingMode.focus === ctx.asset,
    autoTradeEnabled: ctx.autoTrade.enabled,
    openPositions: positions,
    openPositionsCount: positions.length,
    totalPnl: positions.reduce((acc, p) => acc + (p.pnl ?? 0), 0),
    // v6.4 (§27) : santé des données + trading bloqué/autorisé PAR ASSET.
    marketDataHealth: healthState
      ? {
        status: healthState.status,
        healthScore: healthState.healthScore,
        badge,
        lastTickAt: healthState.lastTickAt,
        lastCandleAt: healthState.lastCandleAt,
        tickAgeMs: healthState.tickAgeMs,
        candleAgeMs: healthState.candleAgeMs,
        gapCount: healthState.gapCount,
        candleCount: healthState.candleCount,
        timeframeSec: healthState.timeframeSec,
        historyReady: healthState.historyReady,
        streamConnected: healthState.streamConnected,
        reasons: healthState.reasons,
        trading: healthCheck
          ? {
            enabled: healthCheck.allowed,
            reason: healthCheck.allowed ? null : healthCheck.reason ?? 'MARKET_DATA_UNHEALTHY',
          }
          : null,
      }
      : null,
    betting: {
      strategy: ctx.bettingStrategy,
      baseAmount: ctx.betting.baseAmount,
      consecutiveLosses: ctx.betting.consecutiveLosses,
      fibIndex: ctx.betting.fibIndex,
      nextBetAmount: computeBettingAmount(ctx, session.client?.account?.getCurrentBalance?.() ?? 0),
    },
    stats: { ...ctx.stats },
    createdAt: ctx.createdAt,
  };
}

function buildStatusPayload() {
  const c = session.client;
  const tradingModePayload = {
    mode: tradingMode.mode,
    assets: [...tradingMode.assets],
    focus: tradingMode.focus,
    maxAssets: MAX_SELECTED_ASSETS,
  };
  // Tableau PAR ASSET — chaque entrée est autoportante (§21/§25).
  const assetsPayload = registry.entries().map(([, ctx]) => buildAssetStatusEntry(ctx));
  if (!c) {
    return {
      connected: false,
      authenticated: false,
      market: null,
      tradingMode: tradingModePayload,
      assets: assetsPayload,
      userId: null,
      balance: null,
      openPositions: [],
      openPositionsCount: 0,
      totalPnl: 0,
      candlesCaptured: session.candlesCaptured,
      strategyRunning: session.strategyRunning,
      autoTradeEnabled: session.config.autoTradeEnabled,
      config: session.config,
      closeWindowLen: session.closeWindow.length,
      lastSignal: session.lastSignal,
      front: null,
      liveTicksTotal: session.liveTicksTotal,
      liveTicksForMarket: session.liveTicksForMarket,
      lastTickTs: session.lastTickTs,
      lastTickPrice: session.lastTickPrice,
      lastTickActiveId: session.lastTickActiveId,
      lastTickSize: session.lastTickSize,
      liveActive: Date.now() - session.lastTickTs < 5000,
      wsMessagesTotal: 0,
      wsMessagesByName: {} as Record<string, number>,
      mode: session.mode,
      server: null as string | null,
      assetsCount: 0,
      autoTrade: buildAutoTradeStatus(),
    };
  }
  const sessionData = c.getSession();
  const bal = session.client?.account?.getCurrentBalance?.() ?? 0;
  const balances = session.client?.account?.getBalances?.() ?? {};
  const currency = sessionData?.currency ?? 'USD';
  const isDemo = session.mode === 'demo';
  const currentPrice = session.lastTickPrice;
  const positions = toFrontendPositions(session.openedDeals, currentPrice);
  const totalPnl = positions.reduce((acc, p) => acc + (p.pnl ?? 0), 0);
  return {
    connected: c.getState() === 'connected' || c.getState() === 'authenticated',
    authenticated: c.getState() === 'authenticated',
    market: session.market ? {
      name: session.market.name,
      active_id: session.market.active_id,
      long_name: session.market.long_name,
      tv_symbol: session.market.tv_symbol,
      tv_exchange: session.market.tv_exchange,
      trading_hours: session.market.trading_hours,
      always_on: session.market.always_on,
    } : null,
    tradingMode: tradingModePayload,
    assets: assetsPayload,
    userId: sessionData?.uid ?? null,
    balance: toFrontendBalance(bal, currency, isDemo),
    openPositions: positions,
    openPositionsCount: positions.length,
    totalPnl,
    candlesCaptured: session.candlesCaptured,
    strategyRunning: session.strategyRunning,
    autoTradeEnabled: session.config.autoTradeEnabled,
    config: session.config,
    closeWindowLen: session.closeWindow.length,
    lastSignal: session.lastSignal,
    front: c.getConnectedServer(),
    liveTicksTotal: session.liveTicksTotal,
    liveTicksForMarket: session.liveTicksForMarket,
    lastTickTs: session.lastTickTs,
    lastTickPrice: session.lastTickPrice,
    lastTickActiveId: session.lastTickActiveId,
    lastTickSize: session.lastTickSize,
    liveActive: Date.now() - session.lastTickTs < 5000,
    wsMessagesTotal: 0,
    wsMessagesByName: {},
    mode: session.mode,
    server: c.getConnectedServer(),
    assetsCount: Object.keys(c.market.getAssets()).length,
    autoTrade: buildAutoTradeStatus(),
  };
}

// --------------------------------------------------------------------------
//  PatternContext builder — converts candleBuilder candles into a full
//  PatternContext with all indicators needed by the 1128 pattern strategies
// --------------------------------------------------------------------------


// --------------------------------------------------------------------------
//  Backend auto-trade strategy loop — Full Pattern Registry + V3-Snapback
// --------------------------------------------------------------------------
//  OLD SYSTEM (removed): 31 algorithms + consensus → fake 100% winRate, real losses
//  NEW SYSTEM: V3-Snapback mean reversion + strict risk management
//
//  The V3-Snapback strategy has ONE rule:
//    When price is >2σ from VWAP AND shows wick rejection → enter opposite direction
//
//  The Risk Manager enforces:
//    - Max 2% balance per trade (1% base, anti-martingale scaling)
//    - Stop after 3 consecutive losses (30-min cooldown)
//    - Daily profit target +5% → stop
//    - Daily loss limit -5% → stop
//    - Max 4 trades per 10 minutes (overtrading protection)
// --------------------------------------------------------------------------


async function runStrategyIteration(io: Server): Promise<void> {
  const c = session.client;
  if (!c) return;

  // Clean up expired deals (nettoyage global — les deals expirent par
  // expiration broker, toutes assets confondus ; le retrait des contextes
  // se fait dans noteDealClosed par asset).
  const now = Math.floor(Date.now() / 1000);
  const stillOpen = session.openedDeals.filter(d => d.expireTime > now);
  if (stillOpen.length < session.openedDeals.length) {
    const expired = session.openedDeals.filter(d => d.expireTime <= now);
    session.openedDeals = stillOpen;
    for (const d of expired) {
      const ctx = registry.getAssetContext((d as any).asset ?? '');
      if (ctx) noteDealClosed(ctx, String(d.id));
    }
    log(io, 'info', `${expired.length} deal(s) expired`);
  }

  // ── WATCHDOG DE RÈGLEMENT MARTINGALE (tous assets, toutes stratégies) ──
  // Avant TOUT early-return : un deal dont le règlement broker n'est jamais
  // arrivé (asset non focus, event perdu, id en collision…) doit quand même
  // faire avancer la Martingale/Fibonacci de SON asset. Voir la doc de
  // runMartingaleSettlementWatchdog() pour les trois étages.
  try {
    runMartingaleSettlementWatchdog(io);
  } catch (e: any) {
    log(io, 'error', `[WATCHDOG] martingale settlement error: ${e?.message ?? e}`);
  }

  // Don't place new orders if auto-trade is off (global)
  if (!session.config.autoTradeEnabled || !session.config.autoOpen) return;

  // PARALLÈLE PAR ASSET (§12/§13) — traitement indépendant de chaque contexte.
  for (const [asset, ctx] of registry.entries()) {
    if (!ctx.autoTrade.enabled) continue; // Auto Trade PAR ASSET
    try {
      await runStrategyIterationForAsset(io, asset, ctx);
    } catch (e: any) {
      log(io, 'error', assetLog(asset, `strategy iteration error: ${e?.message ?? e}`));
    }
  }
}

/**
 * Une itération de la stratégie L_Lucien ProTrader POUR UN ASSET DONNÉ.
 * Évaluée sur les bougies CLÔTURÉES uniquement (barstate.isconfirmed).
 */
async function runStrategyIterationForAsset(
  io: Server,
  asset: string,
  ctx: AssetTradingContext,
): Promise<void> {
  const c = session.client;
  if (!c) return;
  assertAssetContext(asset, ctx); // §32

  // Strategy id must be known before execution gates.
  const strategyId = session.config.strategyId ?? 'l_lucien_protrader';

  const maxPos = session.config.maxConcurrentPositions ?? 1;
  if (ctx.openPositions.length >= maxPos) return;

  // Cooldown check — PAR ASSET.
  const nowMs = Date.now();
  const cooldownMs = (session.config.cooldownSeconds ?? 5) * 1000;
  if (nowMs - ctx.autoTrade.lastTradeTs < cooldownMs) return;

  // ── v6.4 §13/§26 : CONTRÔLE DE SANTÉ DES DONNÉES AVANT TOUTE DÉCISION ──
  // La santé des données est vérifiée AVANT les stratégies — jamais après.
  // Un asset STALE / GAP critique / historique manquant / stream coupé /
  // OHLC invalide → HOLD explicite, AUCUNE stratégie n'évalue.
  const pipeline = pipelineManager.get(asset);
  const healthCheck = pipeline ? pipeline.canTrade() : null;
  if (!pipeline) return; // pas de pipeline : asset non sélectionné (§23)
  if (!healthCheck) return;
  if (!healthCheck.allowed) {
    // Journal + blocage explicites (§20) :
    //   [MARKET-DATA] asset=GBPJPY event=TRADE_BLOCKED reason=STALE_DATA health=38
    log(io, 'info', formatStructuredLog('MARKET-DATA', {
      asset,
      event: 'TRADE_BLOCKED',
      reason: healthCheck.reason ?? 'MARKET_DATA_UNHEALTHY',
      health: healthCheck.score,
      status: healthCheck.status,
      strategy: session.config.strategyId ?? 'v3_snapback',
    }));
    io.emit('strategy-state', {
      asset,
      action: 'hold',
      confidence: 0,
      reason: `MARKET_DATA_UNHEALTHY (${healthCheck.reason ?? 'unknown'} — health ${healthCheck.score}/100)`,
      strategyId: session.config.strategyId ?? 'v3_snapback',
      strategyName: 'Market Data Health Guard',
      marketDataHealth: { ...healthCheck },
    });
    return;
  }

  // ── v6.4 §17/§18 : SNAPSHOT SYNCHRONISÉ DE CET ASSET ─────────────────────
  // Toutes les stratégies de cette itération lisent le MÊME instant de
  // marché (mêmes bougies, même santé) — anti race-condition.
  const snapshot: MarketDecisionSnapshot = pipeline.buildSnapshot();

  // Strategy id is established above before execution gates.

  // L_Lucien ProTrader et Ninja ProTrader partagent le MÊME moteur BOS,
  // CHoCH & CISD — L_Lucien évalue les bougies CLÔTURÉES
  // (barstate.isconfirmed du pack Pine), Ninja évalue la bougie EN
  // FORMATION (détection AVANT clôture, prix temps réel).
  const candles = (snapshot.candles as CandleLike[]);
  const isNinjaStrategy = strategyId === 'ninja_protrader';
  const strategyName = autoTradeStrategyName(strategyId);

  const minCandles = 5;
  if (candles.length < minCandles) {
    io.emit('strategy-state', {
      asset,
      action: 'hold',
      confidence: 0,
      reason: `${strategyName} warm-up: ${candles.length}/${minCandles} bougies`,
      strategyId,
      strategyName,
    });
    return;
  }

  // ==========================================================
  // ROUTE: L_Lucien ProTrader / Ninja ProTrader
  // (moteur BOS, CHoCH & CISD — pack Pine)
  // ==========================================================
  let expirySeconds = session.config.expirySeconds ?? 15;

  let signalAction: 'buy' | 'sell' | 'hold' = 'hold';
  let signalConfidence = 0;
  let signalReason = '';
  let patternSignal: PatternTradeSignal | null = null;

  {
    // ========================================================
    // L_Lucien ProTrader / Ninja ProTrader — moteur BOS, CHoCH &
    // CISD (pack PiracyChecker ; moteur partagé
    // shared/bos-choch-cisd.ts, validé bougie par bougie contre
    // piner).
    //   L_Lucien : bougies CLÔTURÉES uniquement (barstate.isconfirmed).
    //   Ninja    : bougie EN FORMATION (détection AVANT clôture) +
    //             Candles Validation ancrée sur la dernière bougie
    //             CLÔTURÉE (validationSkipForming).
    // ========================================================
    const closedCandles = (snapshot.candles as CandleLike[]).map((c) => ({
      open: c.open, high: c.high, low: c.low, close: c.close,
      volume: c.volume ?? 0, time: c.time,
    }))
    // v26 — RÈGLES PAR STRATÉGIE (§31) : Ninja utilise SES règles propres
    // (ninjaBosChochCisd*) si l'utilisateur en a défini ; sinon repli sur
    // les règles partagées (compatibilité §32). L_Lucien utilise toujours
    // les règles partagées.
    const orderRules = isNinjaStrategy && (
      (session.config.ninjaBosChochCisdCallRules?.length ?? 0) > 0
      || (session.config.ninjaBosChochCisdPutRules?.length ?? 0) > 0
    )
      ? normalizeBosChochCisdOrderRules(session.config.ninjaBosChochCisdCallRules, session.config.ninjaBosChochCisdPutRules)
      : normalizeBosChochCisdOrderRules(session.config.bosChochCisdCallRules, session.config.bosChochCisdPutRules)
    // v26 — timeframe (s/bougie) pour la conversion broker des règles
    // « expiration en bougies » (§17 : conversion UNIQUEMENT ici).
    const tfSeconds = Math.max(1, Math.round(session.config.candleSize || 30))
    // v25 — HORLOGE DE BOUGIE : secondes restantes avant la clôture de la
    // bougie QUI REÇOIT le signal (le compteur affiché). Ninja : la bougie
    // EN FORMATION ; L_Lucien : la bougie en formation COURANTE au moment
    // de l'évaluation (la bougie signalée vient de se clôturer).
    let formingCandle: BosChochCisdCandle | null = null
    {
      const f = snapshot.formingCandle
      formingCandle = f ? {
        open: f.open, high: f.high, low: f.low, close: f.close,
        volume: f.volume ?? 0, time: f.time,
      } : null
    }
    const formingNow = snapshot.formingCandle
    const nowSec = Math.floor(Date.now() / 1000)
    const clockRef = formingNow ? formingNow.time : null
    const candleClockSeconds = clockRef != null && nowSec >= clockRef
      ? Math.max(1, Math.min(tfSeconds, tfSeconds - (nowSec - clockRef)))
      : null
    // v19 — switch « Confirmation bougie précédente » du panneau Auto Trade :
    // ON → CALL ▲ exige une bougie baissière avant la bougie signalée,
    // PUT ▼ une bougie haussière (sinon HOLD, aucun ordre lancé).
    // v24 — étapes de vérification CISD OPTIONNELLES (cases à cocher) :
    // up/down (activation par direction), swingMode ('intact' | 'violated' | 'none')
    // et combinaisons de confirmation acceptées (BOS/CHoCH par direction).
    const cisdGuardConfig = {
      up: session.config.cisdGuardUp ?? true,
      down: session.config.cisdGuardDown ?? true,
      swingMode: session.config.cisdGuardSwingMode === 'violated' ? 'violated' as const : session.config.cisdGuardSwingMode === 'none' ? 'none' as const : 'intact' as const,
      confirmBosUp: session.config.cisdGuardConfirmBosUp ?? true,
      confirmChochUp: session.config.cisdGuardConfirmChochUp ?? true,
      confirmBosDown: session.config.cisdGuardConfirmBosDown ?? true,
      confirmChochDown: session.config.cisdGuardConfirmChochDown ?? true,
    }
    const evalOptions = {
      confirmPreviousCandle: session.config.bosChochCisdConfirmCandle ?? false,
      cisdGuardConfig,
      // v25/v26 — horloge de bougie (remaining time) + timeframe (broker
      // candles → secondes).
      ...(candleClockSeconds != null ? { candleClockSeconds } : {}),
      timeframeSeconds: tfSeconds,
    }
    let bcc: BosChochCisdSignal
    if (isNinjaStrategy) {
      bcc = evaluateNinjaProTraderStrategy(closedCandles, formingCandle, asset, orderRules, evalOptions)
    } else {
      bcc = evaluateBosChochCisdStrategy(closedCandles, asset, {
        bosUp: session.config.bosChochCisdBosUp ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.bosUp,
        bosDown: session.config.bosChochCisdBosDown ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.bosDown,
        chochUp: session.config.bosChochCisdChochUp ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.chochUp,
        chochDown: session.config.bosChochCisdChochDown ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.chochDown,
        cisdUp: session.config.bosChochCisdCisdUp ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.cisdUp,
        cisdDown: session.config.bosChochCisdCisdDown ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.cisdDown,
      }, orderRules, evalOptions)
    }
    if (bcc.action !== 'HOLD' && !(typeof bcc.expirationSeconds === 'number' && Number.isFinite(bcc.expirationSeconds) && bcc.expirationSeconds >= AUTO_TRADE_MIN_EXPIRY)) {
      // L_Lucien/Ninja ProTrader : AUCUN fallback d'expiration — ni le champ
      // global Auto Trade (session.config.expirySeconds), ni une valeur
      // magique (3/15/30/60…). Une règle sans expirationSeconds explicite de
      // l'utilisateur est INVALIDE et ne produit JAMAIS d'ordre (HOLD).
      io.emit('strategy-state', {
        asset,
        action: 'hold',
        confidence: 0,
        reason: `${strategyName} : règle ${bcc.matchedRuleId ?? '?'} sans expiration — ordre refusé (aucune expiration automatique, définissez l'expiration de la règle).`,
        strategyId,
        strategyName,
        matchedRuleId: bcc.matchedRuleId ?? null,
        events: bcc.events,
        bosChochCisd: {
          events: bcc.events,
          candleTime: bcc.candleTime,
          matchedRuleId: bcc.matchedRuleId ?? null,
          orderExpirationSeconds: null,
          callRules: session.config.bosChochCisdCallRules ?? DEFAULT_BOS_CHOCH_CISD_ORDER_RULES.callRules,
          putRules: session.config.bosChochCisdPutRules ?? DEFAULT_BOS_CHOCH_CISD_ORDER_RULES.putRules,
          toggles: {
            bosUp: session.config.bosChochCisdBosUp ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.bosUp,
            bosDown: session.config.bosChochCisdBosDown ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.bosDown,
            chochUp: session.config.bosChochCisdChochUp ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.chochUp,
            chochDown: session.config.bosChochCisdChochDown ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.chochDown,
            cisdUp: session.config.bosChochCisdCisdUp ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.cisdUp,
            cisdDown: session.config.bosChochCisdCisdDown ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.cisdDown,
          },
          // v19 — état du switch « Confirmation bougie précédente ».
          confirmCandle: session.config.bosChochCisdConfirmCandle ?? false,
          // v24 — état des cases « Vérification CISD » (étapes optionnelles).
          cisdGuard: cisdGuardConfig,
        },
      });
      return; // la bougie N'EST PAS consommée (mark…Traded non appelé)
    }
    if (typeof bcc.expirationSeconds === 'number') {
      // Règle de placement prioritaire : SON expiration — définie explicitement
      // par l'utilisateur — est la SEULE source pour CET ordre. Le champ global
      // Auto Trade (expirySeconds ci-dessus, initialisé depuis
      // session.config.expirySeconds ?? 15) ne doit JAMAIS contrôler un ordre
      // L_Lucien/Ninja ProTrader : on l'écrase systématiquement par la valeur
      // de la règle.
      expirySeconds = bcc.expirationSeconds
    }
    signalAction = bcc.action === 'CALL' ? 'buy' : bcc.action === 'PUT' ? 'sell' : 'hold';
    signalConfidence = bcc.confidence;
    signalReason = bcc.reason;

    io.emit('strategy-state', {
      asset,
      action: signalAction,
      confidence: signalConfidence,
      reason: signalReason,
      strategyId,
      strategyName,
      matchedRuleId: bcc.matchedRuleId ?? null,
      events: bcc.events,
      // v23 — séquence CISD vérifiée (swing intact + signal combiné) quand
      // l'ordre/le signal vient d'une combinaison CISD confirmée.
      cisdConfirmation: bcc.cisdConfirmation ?? null,
      bosChochCisd: {
        events: bcc.events,
        candleTime: bcc.candleTime,
        matchedRuleId: bcc.matchedRuleId ?? null,
        orderExpirationSeconds: bcc.expirationSeconds ?? null,
        callRules: session.config.bosChochCisdCallRules ?? DEFAULT_BOS_CHOCH_CISD_ORDER_RULES.callRules,
        putRules: session.config.bosChochCisdPutRules ?? DEFAULT_BOS_CHOCH_CISD_ORDER_RULES.putRules,
        toggles: {
          bosUp: session.config.bosChochCisdBosUp ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.bosUp,
          bosDown: session.config.bosChochCisdBosDown ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.bosDown,
          chochUp: session.config.bosChochCisdChochUp ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.chochUp,
          chochDown: session.config.bosChochCisdChochDown ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.chochDown,
          cisdUp: session.config.bosChochCisdCisdUp ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.cisdUp,
          cisdDown: session.config.bosChochCisdCisdDown ?? DEFAULT_BOS_CHOCH_CISD_TOGGLES.cisdDown,
        },
        // v19 — état du switch « Confirmation bougie précédente ».
        confirmCandle: session.config.bosChochCisdConfirmCandle ?? false,
        // v24 — état des cases « Vérification CISD » (étapes optionnelles).
        cisdGuard: cisdGuardConfig,
      },
    });

    if (signalAction !== 'hold') {
      // Garde un-ordre-par-bougie : la bougie est marquée dès l'acceptation
      // du signal (une tentative d'ordre par événement).
      //   L_Lucien → bougie CLÔTURÉE signalée ; Ninja → bougie EN FORMATION.
      if (isNinjaStrategy) markNinjaProTraderTraded(asset, bcc.candleTime);
      else markBosChochCisdTraded(asset, bcc.candleTime);
      const latest = isNinjaStrategy && formingCandle
        ? formingCandle
        : closedCandles[closedCandles.length - 1];

      // v22 — LIBELLÉ D'ORDRE : chaque ordre placé porte sa stratégie, la
      // COMBINAISON qui l'a placé et sa RÈGLE DE VALIDATION. Ex. :
      //   « Ninja ProTrader · CALL ▲ · call-1 [BOS Up + CISD Up] · validation RGRR »
      // v23 — les ordres issus d'une combinaison CISD portent EN PLUS la
      // confirmation CISD (séquence swing-intact puis signal combiné) :
      //   « … · validation RGRR · CISD Up confirmé (armé bougie T, swing 1.2345 intact) »
      // v24 — le libellé reflète le MODE d'armement (« intact » ou « violé »)
      // et signale les ordres CISD DIRECTS (vérification décochée).
      const matchedRule = [...orderRules.callRules, ...orderRules.putRules].find((r) => r.id === bcc.matchedRuleId);
      const cisdConfirm = bcc.cisdConfirmation;
      const ruleHasCisd = matchedRule ? (matchedRule.alerts.includes('CISD Up') || matchedRule.alerts.includes('CISD Down')) : false;
      const ruleCisdDir: 'up' | 'down' | null = matchedRule
        ? (matchedRule.alerts.includes('CISD Up') ? 'up' : matchedRule.alerts.includes('CISD Down') ? 'down' : null)
        : null;
      const cisdDirect = ruleHasCisd && ruleCisdDir != null && !(ruleCisdDir === 'up' ? cisdGuardConfig.up : cisdGuardConfig.down);
      const orderLabel = [
        strategyName,
        bcc.action === 'CALL' ? 'CALL ▲' : 'PUT ▼',
        // v26 — conditions MIXTES : labels lisibles (BOS Up + Bullish Engulfing).
        matchedRule ? `${matchedRule.id} [${matchedRule.alerts.map((a) => signalLabel(a)).join(' + ')}]` : (bcc.matchedRuleId ?? '—'),
        matchedRule?.candlesValidation ? `validation ${matchedRule.candlesValidation}` : 'sans validation',
        // v25/v26 — expiration par MODE : seconds / candles / remaining.
        bcc.expirationMode === 'candles' ? `EXP ${bcc.expirationCandles ?? matchedRule?.expirationCandles ?? '?'} bougie(s)`
          : bcc.expirationMode === 'remaining' ? 'EXP remaining Time Before Candle Closure'
          : `EXP ${bcc.expirationSeconds ?? '?'}s`,
        ...(cisdConfirm ? [`${cisdConfirm.direction === 'up' ? 'CISD Up' : 'CISD Down'} confirmé (armé bougie ${cisdConfirm.armedCandleTime}, swing ${cisdConfirm.swingPrice} ${cisdConfirm.swingMode === 'violated' ? 'violé' : cisdConfirm.swingMode === 'none' ? 'non vérifié (étape ignorée)' : 'intact'})`] : []),
        ...(cisdDirect ? [`CISD ${ruleCisdDir === 'up' ? 'Up' : 'Down'} direct (vérification désactivée)`] : []),
      ].join(' · ');

      patternSignal = {
        action: bcc.action,
        strategyId,
        strategyName: `${strategyName}${bcc.events.length ? ` · ${bcc.events.join(' + ')}` : ''}`,
        entryPrice: latest ? latest.close : 0,
        stopLoss: 0,
        takeProfit: 0,
        confidence: signalConfidence,
        reason: signalReason,
        expirySeconds,
        timestamp: Date.now(),
        orderLabel,
        // v23 — confirmation CISD (séquence swing-intact + signal combiné)
        // transportée avec le signal (diagnostics / libellés).
        cisdConfirmation: bcc.cisdConfirmation ?? null,
      };
    }
  }

  if (signalAction === 'hold') return;


  // ==========================================================
  // STEP 2: Risk Manager check (only if enabled — OFF by default)
  // ==========================================================
  const riskEnabled = session.config.riskManagementEnabled ?? false;
  let amount: number;
  let riskDecision: { allowed: boolean; reason: string; amount: number; riskPercent: number } | null = null;

  if (riskEnabled) {
    if (!riskManager) {
      const balance = c.account?.getCurrentBalance?.() ?? 100;
      riskManager = new RiskManager(balance);
      log(io, 'info', `[RISK] RiskManager initialized with balance ${balance}`);
    }

    // Update risk manager with current balance
    const currentBalance = c.account?.getCurrentBalance?.() ?? riskManager.getState().balance;
    riskManager.updateBalance(currentBalance);
    riskManager.resetDaily();

    riskDecision = riskManager.evaluate();
    if (!riskDecision.allowed) {
      log(io, 'info', assetLog(asset, `trade bloqué par le Risk Manager : ${riskDecision.reason}`));
      return;
    }
    amount = riskDecision.amount;
  } else {
    // Mise calculée DEPUIS LE CONTEXTE DE CET ASSET (§16) — déterministe :
    // fixed | martingale (consecutiveLosses de CET asset) | fibonacci
    // (fibIndex de CET asset). Aucune variable globale.
    amount = computeBettingAmount(ctx, c.account?.getCurrentBalance?.() ?? 0);
  }

  // ==========================================================
  // STEP 3: Place the order — with balance + expiry validation
  // ==========================================================
  const action: 'call' | 'put' = signalAction === 'buy' ? 'call' : 'put';

  log(io, 'info', assetLog(asset, `[L_LUCIEN PROTRADER] signal accepted for execution: ${action.toUpperCase()} conf=${(signalConfidence * 100).toFixed(0)}% — ${signalReason}`));

  // MINIMUM BALANCE CHECK — Pocket Option minimum trade is $1
  // If balance < amount, the server silently ignores the order → timeout
  const currentBalance = c.account?.getCurrentBalance?.() ?? 0;
  if (currentBalance < amount) {
    log(io, 'warning', assetLog(asset, `[L_LUCIEN PROTRADER] BLOCKED: balance ${currentBalance.toFixed(2)} < amount ${amount}`));
    return;
  }

  // EXPIRY VALIDATION — v6.1 : LE CHAMP AUTO TRADE EST LA SOURCE DE VÉRITÉ.
  // v6.3 : CLAMP SEUL [3 s, 86 400 s] — la valeur du champ est respectée à la
  // seconde près (l'ancien snap la réécrivait : 6 s → 5 s, 45 s → 30 s…).
  let time = snapExpiry(expirySeconds);
  if (time !== expirySeconds) {
    log(io, 'info', assetLog(asset, `Expiration ${expirySeconds}s → bornée à ${time}s (plage broker 3 s – 86 400 s).`));
  }

  try {
    const logPrefix = patternSignal ? `[PATTERN ${patternSignal.strategyId}]` : '[V3]';
    const riskLog = riskEnabled && riskDecision ? `[RISK] ${riskDecision.reason}` : `[RISK] disabled (mise: ${ctx.bettingStrategy}, ${computeBettingAmount(ctx)}$)`;
    log(io, 'info', assetLog(asset, `${logPrefix} ${action.toUpperCase()} amount=${amount} conf=${(signalConfidence * 100).toFixed(0)}% — ${signalReason}`));
    log(io, 'info', riskLog);

    // Enregistre AVANT l'appel broker pour que même une expiration très courte
    // (3–20s) ne puisse perdre son résultat si `deal_closed` arrive avant la
    // résolution de `openOrder()`.
    const pendingBettingOrder = { submittedAt: Date.now(), amount, expirationSeconds: time, strategyId, action };
    ctx.pendingBettingOrders.push(pendingBettingOrder);

    const orderResult = await c.trading.openOrder({
      asset,
      amount,
      action,
      time,
      isDemo: session.mode === 'demo' ? 1 : 0,
    });

    // Le deal est maintenant connu : retire la réservation correspondante.
    const pendingIndex = ctx.pendingBettingOrders.indexOf(pendingBettingOrder);
    if (pendingIndex >= 0) ctx.pendingBettingOrders.splice(pendingIndex, 1);

    if (orderResult.success && orderResult.deal) {
      session.lastOrderPlacedTs = Date.now(); // v20 — diagnostic (plus de switch idle)
    }

    // Timestamps PAR ASSET (§18) — le trade d'EURUSD ne bloque pas XAUUSD.
    ctx.autoTrade.lastTradeTs = Date.now();
    ctx.autoTrade.lastTradeAction = action;
    session.lastTradeTs = Date.now();
    session.lastTradeAction = action;
    ctx.stats.signals++;

    // ==========================================================
    // PATTERN PERFORMANCE TRACKING (other strategies only).
    // Win-Win has its own isolated journal: Win-Win Logs.txt.
    // ==========================================================
    if (patternSignal && orderResult.success && orderResult.deal && strategyId !== 'winwin') {
      session.lastPatternId = patternSignal.strategyId;
      const tradeId = recordPatternTrade({
        patternId: patternSignal.strategyId,
        patternName: patternSignal.strategyName,
        patternCategory: 'market-structure',
        signalAction: patternSignal.action as 'CALL' | 'PUT',
        confidence: patternSignal.confidence,
        entryPrice: patternSignal.entryPrice,
        stopLoss: patternSignal.stopLoss,
        takeProfit: patternSignal.takeProfit,
        amount,
        expirySeconds: time,
        asset,
        strategyId: strategyId,
        mode: session.mode,
        timestamp: new Date().toISOString(),
      });
      session.lastPatternTradeId = tradeId;
      session.pendingPatternTrades.set(tradeId, {
        patternId: patternSignal.strategyId,
        patternName: patternSignal.strategyName,
        timestamp: Date.now(),
        asset,
        dealId: orderResult.deal ? String(orderResult.deal.id) : undefined,
      });
    }

    if (orderResult.success && orderResult.deal) {
      session.lastOrderPlacedTs = Date.now(); // v20 — diagnostic (plus de switch idle)
      noteDealOpened(ctx, orderResult.deal);
      if (!session.openedDeals.find(d => d.id === orderResult.deal!.id)) {
        session.openedDeals.push(orderResult.deal);
      }
      ctx.stats.trades++;
      // Empreinte du fill (openPrice/openTime/action) : permet au handler
      // deal_closed de rattacher le règlement broker (souvent publié avec un
      // id NUMÉRIQUE ≠ UUID d'ouverture, cf. matcher par empreinte) à CET
      // ordre suivi — sans elle, un GAIN jamais rattaché laisse la Martingale
      // figée sur sa série de pertes (bug « ne repart jamais à la mise
      // initiale »).
      ctx.trackedDeals.set(String(orderResult.deal.id), {
        asset,
        amount,
        expirationSeconds: time,
        openPrice: Number(orderResult.deal.openPrice ?? 0) || undefined,
        openTime: Number(orderResult.deal.openTime ?? 0) || undefined,
        action,
        placedAtMs: pendingBettingOrder.submittedAt,
      });
      log(io, 'info', assetLog(asset, `trade opened — ${action.toUpperCase()} @ ${orderResult.deal.openPrice} (amount=${amount}, expiry=${time}s, deal #${orderResult.deal.id})`));
      io.emit('trade-opened', { asset, deal: orderResult.deal, source: strategyId, expirationSeconds: time, label: patternSignal?.orderLabel ?? `${autoTradeStrategyName(strategyId)} · ${action.toUpperCase() === 'CALL' ? 'CALL ▲' : 'PUT ▼'} · ${patternSignal?.strategyId ?? strategyId}` }); // §21 + libellé v22
    } else {
      log(io, 'warning', assetLog(asset, `${logPrefix} ${action.toUpperCase()} rejected: ${orderResult.error ?? 'unknown'}`));
    }
  } catch (e: any) {
    // Échec avant confirmation broker : la réservation Martingale/Fibonacci
    // ne doit pas rester pendante et contaminer un prochain trade.
    const pendingIndex = ctx.pendingBettingOrders.findIndex((p) =>
      p.strategyId === strategyId && p.amount === amount && p.expirationSeconds === time,
    );
    if (pendingIndex >= 0) ctx.pendingBettingOrders.splice(pendingIndex, 1);

    const errMsg = e.message || String(e);
    log(io, 'error', assetLog(asset, `auto-trade error: ${errMsg}`));
    // On ORDER_TIMEOUT: set a longer cooldown (60s) SUR CET ASSET to avoid hammering the server
    if (errMsg.includes('ORDER_TIMEOUT')) {
      ctx.autoTrade.lastTradeTs = Date.now() + 60000;  // extra 60s cooldown (PAR ASSET)
      log(io, 'warning', assetLog(asset, `Order timeout — 60s extra cooldown to let server recover`));
      // If balance is too low, this is the likely cause
      const bal = c.account?.getCurrentBalance?.() ?? 0;
      if (bal < amount) {
        log(io, 'error', assetLog(asset, `Balance ${bal.toFixed(2)} is below trade amount ${amount}. Top up your account to resume trading.`));
      }
    }
  }
}



// --------------------------------------------------------------------------
//  MISE AUTO-TRADE (calcul PAR ASSET — moteur commun)
// --------------------------------------------------------------------------
/**
 * ⚠️ MULTI-ASSETS : la mise est calculée PAR ASSET via computeBettingAmount(ctx)
 * (importé de asset-contexts.ts — déterministe, aucune variable globale, §16).
 * Ce wrapper compat calcule la mise du FOCUS (mode mono-asset / UI legacy) ;
 * les moteurs d'auto-trade utilisent TOUS la version par contexte.
 */
function computeBettingAmountForFocus(): number {
  const ctx = focusContext();
  const bal = session.client?.account?.getCurrentBalance?.() ?? 0;
  if (!ctx) return Math.max(1, parseFloat(session.config.margin) || 1);
  return computeBettingAmount(ctx, bal);
}

/**
 * Snappe une expiration sur les valeurs supportées par le broker.
 * (Implémentation partagée dans expiry.ts — module pur, testable sans serveur.)
 */

/** Statut auto-trade PAR ASSET (§13/§21) — chaque entrée ne contient QUE les
 * données de SON asset (stats, mise, martingale, fibonacci). */
function buildAssetAutoTradeStatus(ctx: AssetTradingContext) {
  return {
    asset: ctx.asset,
    enabled: ctx.autoTrade.enabled,
    // Stratégie (globale, partagée par tous les assets — l'isolement porte
    // sur les mises/stats, §13/§16).
    strategyId: session.config.strategyId ?? 'l_lucien_protrader',
    strategyName: autoTradeStrategyName(session.config.strategyId),
    bettingStrategy: ctx.bettingStrategy,
    baseAmount: ctx.betting.baseAmount,
    // v19 — garde-fou Martingale de CET asset (0 = illimité).
    maxMartingaleSteps: ctx.betting.maxMartingaleSteps,
    nextBetAmount: computeBettingAmount(ctx, session.client?.account?.getCurrentBalance?.() ?? 0),
    stats: {
      signals: ctx.stats.signals,
      trades: ctx.stats.trades,
      wins: ctx.stats.wins,
      losses: ctx.stats.losses,
      // v17 — Tie/Refund (P&L = 0) : état neutre, ni win ni loss — n'affecte
      // jamais l'index de la suite de mises.
      pushes: ctx.stats.pushes,
      winRate: ctx.stats.trades > 0 ? ctx.stats.wins / ctx.stats.trades : null,
      consecutiveLosses: ctx.betting.consecutiveLosses,
      fibIndex: ctx.betting.fibIndex,
    },
    openPositions: ctx.openPositions.length,
  };
}

/** Contenu auto-trade complet pour le frontend : agrégat (compat mono) + PAR ASSET. */
function buildAutoTradeStatus() {
  const normStats = streamTickNormalizer?.getStats() ?? null;
  // Focus = l'asset affiché (mode mono : l'unique asset).
  const focus = focusContext();
  const entries = registry.entries();
  const assetStatuses: Record<string, ReturnType<typeof buildAssetAutoTradeStatus>> = {};
  // Agrégat global (tous contextes confondus) — compat panneau UI mono-asset.
  const agg = { signals: 0, trades: 0, wins: 0, losses: 0, pushes: 0 };
  for (const [asset, ctx] of entries) {
    assetStatuses[asset] = buildAssetAutoTradeStatus(ctx);
    agg.signals += ctx.stats.signals;
    agg.trades += ctx.stats.trades;
    agg.wins += ctx.stats.wins;
    agg.losses += ctx.stats.losses;
    agg.pushes += ctx.stats.pushes;
  }
  return {
    enabled: session.config.autoTradeEnabled,
    strategyId: session.config.strategyId,
    strategies: AUTO_TRADE_STRATEGIES,
    bettingStrategy: session.config.bettingStrategy ?? 'fixed',
    fixedExpirySeconds: session.config.expirySeconds ?? 60,
    // v19 — switch « Confirmation bougie précédente » (L_Lucien ProTrader)
    // + garde-fou Martingale (0 = illimité).
    bosChochCisdConfirmCandle: session.config.bosChochCisdConfirmCandle ?? false,
    maxMartingaleSteps: clampMaxMartingaleSteps(session.config.maxMartingaleSteps),
    // v24 — état des cases « Vérification CISD » (étapes optionnelles).
    cisdGuard: {
      up: session.config.cisdGuardUp ?? true,
      down: session.config.cisdGuardDown ?? true,
      swingMode: session.config.cisdGuardSwingMode === 'violated' ? 'violated' : session.config.cisdGuardSwingMode === 'none' ? 'none' : 'intact',
      confirmBosUp: session.config.cisdGuardConfirmBosUp ?? true,
      confirmChochUp: session.config.cisdGuardConfirmChochUp ?? true,
      confirmBosDown: session.config.cisdGuardConfirmBosDown ?? true,
      confirmChochDown: session.config.cisdGuardConfirmChochDown ?? true,
    },
    minExpirySeconds: AUTO_TRADE_MIN_EXPIRY,
    maxExpirySeconds: AUTO_TRADE_MAX_EXPIRY,
    nextBetAmount: focus
      ? computeBettingAmount(focus, session.client?.account?.getCurrentBalance?.() ?? 0)
      : Math.max(1, parseFloat(session.config.margin) || 1),
    baseAmount: parseFloat(session.config.margin) || 1,
    stats: {
      signals: agg.signals,
      trades: agg.trades,
      wins: agg.wins,
      losses: agg.losses,
      // v17 — Tie/Refund (P&L = 0) : état neutre, ni win ni loss.
      pushes: agg.pushes,
      winRate: agg.trades > 0 ? agg.wins / agg.trades : null,
      // Martingale/Fibonacci du FOCUS (mode mono = l'unique asset) —
      // les valeurs PAR ASSET sont dans `assets`.
      consecutiveLosses: focus?.betting.consecutiveLosses ?? 0,
      fibIndex: focus?.betting.fibIndex ?? 0,
    },
    // Santé du pipeline anti-duplication :
    // received = updates brutes reçues, emitted = ticks normalisés émis.
    tickNormalizer: normStats,
    // ── MULTI-ASSETS : stats complètes PAR ASSET (§21) ──
    assets: assetStatuses,
  };
}

/**
 * Construit la série de bougies pour le moteur BOS :
 *   - base = bougies du CandleBuilder (historique broker complet, sans ticks)
 *   - enrichies par les bougies du JSONL (avec ticks normalisés — priorité
 *     au plus riche) pour tous les buckets enregistrés.
 * Retourne les bougies triées, dédoublonnées par time.
 */
function buildBosCandleSeries(asset: string, period: number) {
  const byTime = new Map<number, any>();

  // 1. Série canonique du synchroniseur — SÉRIE DE CET ASSET (§8 : jamais
  //    la série du focus !). OHLC broker, volume, sans ticks.
  for (const c of candleSync.getAllCandles(asset, period)) {
    byTime.set(c.time, {
      time: c.time, open: c.open, high: c.high, low: c.low, close: c.close,
      volume: (c as any).volume ?? 0, period, asset, ticks: [],
    });
  }

  // 2. Bougies enregistrées (avec ticks) — priorité au plus riche.
  for (const c of candleJsonlReader.getCandles(asset, period, { includeForming: false })) {
    const prev = byTime.get(c.time);
    if (!prev || c.ticks.length >= prev.ticks.length) {
      byTime.set(c.time, c);
    }
  }

  return [...byTime.values()].sort((a, b) => a.time - b.time);
}

// ────────────────────────────────────────────────────────────────────────────
// FETCH HISTORIQUE + BROADCAST — chemin UNIQUE et dédupliqué.
// Utilisé par : set-config (changement de timeframe), capture-history
// (frontend), select-assets. Garde anti-doublon PAR ASSET : un seul fetch
// par (asset, size) à la fois ; un résultat superseded (nouveau changement
// de TF pendant le fetch) est jeté sans jamais toucher au CandleBuilder.
// ────────────────────────────────────────────────────────────────────────────

// ────────────────────────────────────────────────────────────────────────────
// v6.5 — FILE DE TÂCHES ASYNCHRONES À CONCURRENCE LIMITÉE
// ────────────────────────────────────────────────────────────────────────────
/** Fetchs d'historique parallèles max (24 assets × pagination = tempête sinon). */
const HISTORY_FETCH_CONCURRENCY = 4;

/**
 * v6.10 — Intervalle d'étalement des `changeSymbol` (ms). HAR fix_gaps.har :
 * chaque changeSymbol déclenque un updateHistoryNewFast (~1500 ticks) — 24
 * requêtes simultanées saturent le broker. 150 ms → 24 assets en 3,6 s.
 */
const CHANGE_SYMBOL_STAGGER_MS = 150;

/**
 * Exécute des tâches asynchrones avec au plus `limit` en parallèle.
 * Une tâche qui échoue n'interrompt PAS la file (best-effort, erreur avalée —
 * chaque tâche gère ses propres erreurs/logs).
 */
async function runWithConcurrency(
  tasks: Array<() => Promise<void>>,
  limit: number,
): Promise<void> {
  if (tasks.length === 0) return;
  let index = 0;
  const safeLimit = Math.max(1, Math.min(limit, tasks.length));
  const worker = async (): Promise<void> => {
    while (index < tasks.length) {
      const current = index++;
      try {
        await tasks[current]!();
      } catch { /* best-effort — chaque tâche journalise ses erreurs */ }
    }
  };
  await Promise.all(Array.from({ length: safeLimit }, () => worker()));
}


function getHistoryAnchorSec(asset: string): number {
  const marketNow = candleSync.getLatestMarketTimeSec(asset);
  return marketNow > 0 ? Math.floor(marketNow) : Math.floor(Date.now() / 1000);
}

/**
 * Attend qu'aucun fetch d'historique ne soit en vol pour (asset, size).
 * Utilisé par capture-history : une capture EXPLICITE ne doit jamais
 * renvoyer [] parce qu'un fetch d'arrière-plan (warm-up, gap-resync,
 * tf-switch) occupe déjà la clé — le frontend replierait sinon sur son
 * buffer visible de 300 bougies et le replay profond échouerait.
 */
async function waitForHistoryFetchIdle(asset: string, size: number, timeoutMs = 90_000): Promise<void> {
  const key = `${asset}:${size}`;
  const deadline = Date.now() + timeoutMs;
  while (historyFetchStates.get(key) && Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, 250));
  }
}

async function fetchAndBroadcastHistory(
  io: Server,
  asset: string,
  size: number,
  count: number,
  reason: string,
): Promise<any[]> {
  if (!session.client) return [];
  // Explicit history capture supports the UI range of 1–10 days.
  // The actual candle count depends on the selected timeframe.
  const maxDaysCandles = Math.max(1, Math.ceil((10 * 86400) / Math.max(1, size)));
  count = Math.min(maxDaysCandles, Math.max(1, Math.floor(count || 300)));
  const key = `${asset}:${size}`;
  // Garde anti-doublon PAR ASSET (un seul fetch par (asset, size) à la fois).
  if (historyFetchStates.get(key)) {
    log(io, 'info', `[HISTORY] fetch ${key} déjà en cours (${reason}) — ignoré`);
    return [];
  }
  historyFetchStates.set(key, true);
  // §17 — capture la GÉNÉRATION de synchronisation AVANT l'await : si un
  // changement de timeframe/actif survient pendant le fetch, la réponse sera
  // rejetée par le CandleSyncManager (elle ne peut pas écraser une
  // synchronisation plus récente).
  const generation = candleSync.beginHistoryLoad(asset, size);
  log(io, 'info', `[HISTORY] fetch ${count} bougies ${key} (raison: ${reason}, gen=${generation})...`);
  try {
    const candles = await session.client.market.loadFullHistory(asset, size as any, count, getHistoryAnchorSec(asset));
    // Post-await : l'asset a pu être DÉSÉLECTIONNÉ ou le timeframe changé
    // PENDANT le fetch — écrire maintenant contaminerait le builder d'un
    // autre contexte. La validité porte sur l'ASSET (pas le focus) : tous
    // les assets sélectionnés peuvent ingérer leur historique en parallèle.
    if (!registry.has(asset) || (session.config.candleSize ?? 0) !== size) {
      log(io, 'info', `[HISTORY] fetch ${key} superseded — résultat jeté`);
      return [];
    }
    if (candles.length === 0) {
      log(io, 'warning', `[HISTORY] fetch ${key} : 0 bougie reçue`);
      return [];
    }
    const mappedRaw = candles.map(c => ({
      time: c.time, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume ?? 0,
    }));
    // GARDE TEMPORELLE : l'historique fraîchement demandé doit atteindre le
    // segment LIVE. Une réponse ancienne ne doit jamais être recousue au flux
    // courant et déplacer le graphique.
    const liveNow = candleSync.getLatestMarketTimeSec(asset);
    const fetchedLast = mappedRaw.length > 0 ? mappedRaw[mappedRaw.length - 1].time : 0;
    // Le broker peut renvoyer une page historique plus ancienne que le segment
    // LIVE de plusieurs minutes. Ce n'est pas une erreur : la graine fast
    // (updateHistoryNewFast) sert de pont entre le deep-history et le live.
    // On ne rejette donc plus l'historique simplement parce qu'il est vieux.
    // Seule une réponse située DANS LE FUTUR est dangereuse et doit être
    // isolée pour éviter de déplacer la timeline.
    const futureSkewSec = Math.max(5, Math.ceil(size * 0.25));
    if (liveNow > 0 && fetchedLast > 0 && fetchedLast - liveNow > futureSkewSec) {
      log(io, 'warning', `[HISTORY] fetch ${key} isolé : timestamp futur de ${fetchedLast - liveNow}s > ${futureSkewSec}s`);
      return [];
    }
    if (liveNow > 0 && fetchedLast > 0 && liveNow - fetchedLast > Math.max(size * 3, 60)) {
      log(io, 'info', `[HISTORY] fetch ${key} deep-history ancien conservé : retard=${Math.round(liveNow - fetchedLast)}s — la graine LIVE sert de pont`);
    }
    // DÉFENSE MULTI-ACTIFS + CONTINUITÉ : ancrage sur le dernier prix LIVE
    // de CET asset. La médiane interne seule peut laisser passer un cache
    // étranger mais numériquement proche (ex. une autre paire FX).
    const liveTicks = candleSync.getTickBuffer(asset);
    const liveAnchorPrice = liveTicks.length > 0 ? liveTicks[liveTicks.length - 1].price : 0;
    const sanitized = sanitizeCandlesByPrice(mappedRaw, {
      referencePrice: liveAnchorPrice > 0 ? liveAnchorPrice : undefined,
      maxRelativeDistance: liveAnchorPrice > 0 ? 0.05 : undefined,
    });
    if (sanitized.dropped > 0) {
      log(io, 'warning', `[HISTORY] ${sanitized.dropped}/${mappedRaw.length} bougies REJETÉES (prix incohérent avec ${asset}) — contamination multi-actifs neutralisée`);
    }
    let mapped = sanitized.clean;
    const regime = mapped.length > 1
      ? retainLatestPriceRegime(mapped, { maxRelativeStep: 0.05, maxRelativeToAnchor: 0.05 })
      : { clean: mapped, dropped: 0, breakIndex: null };
    mapped = regime.clean;
    if (mapped.length === 0) {
      log(io, 'warning', `[HISTORY] fetch ${key} : 0 bougie saine après sanitisation`);
      return [];
    }
    // FUSION CANONIQUE (§5/§14) : normalisation grille + dédup par bucket +
    // priorité des sources (closed: broker > ticks réagrégés ; forming: live)
    // + garde de génération (§17) + validation OHLC + détection de trous.
    const ingest = candleSync.ingestHistory(asset, size, mapped, { generation, source: 'history' });
    if (!ingest.accepted) {
      log(io, 'warning', `[HISTORY] fetch ${key} IGNORÉ par le synchroniseur (${ingest.reason})`);
      return [];
    }
    const seriesAll = [...ingest.series.closed, ...(ingest.series.forming ? [ingest.series.forming] : [])];
    session.candlesCaptured = candles.length;
    // Emit AVEC l'asset (§21) : le frontend route l'historique vers le
    // LiveEngine de SON asset — jamais vers un asset global ambigu.
    // CAP DYNAMIQUE : les fetchs chauds (warm-up ≤ 300) gardent le plafond
    // historique de 300 bougies ; les captures PROFONDES (count > 300,
    // explicitement demandées par le Strategy Tester / le replay) diffusent
    // jusqu'à 5 000 bougies pour nourrir le buffer Pine étendu du frontend —
    // sinon l'historique profond n'existait QUE dans l'ack capture-history
    // et le buffer getPineCandles() restait vide après un Fetch History.
    const emitCap = count > 300 ? 5000 : 300;
    const mkt = registry.getAssetContext(asset)?.market ?? getMarket(asset);
    io.emit('candles-history', {
      asset,
      key: `${mkt.active_id}:${size}`,
      candles: seriesAll.slice(-emitCap),
      count: seriesAll.length,
    });
    const m = ingest.report.lastMerge;
    log(io, 'info',
      `[HISTORY] ${seriesAll.length} bougies canoniques ${key} → synchroniseur + frontend (graine ${reason}) ` +
      `[merged=${m?.merged} doublons=${m?.duplicates} réalignées=${m?.realigned} rejetées=${m?.invalid} ` +
      `recouvrement=${m?.overlapBuckets} buckets état=${ingest.report.state}]`);
    // v6.4 — PIPELINE DE CET ASSET : historique ingéré → historyReady (§4).
    // v6.10.1 — bougies CLÔTURÉES uniquement (la forming appartient au flux
    // live : la passer ici écrasait lastCandleTime avec le bucket en
    // formation → la clôture suivante était comptée en DOUBLON → compteur
    // de bougies faussé). deep: true (défaut) : la pagination pose la
    // frontière d'historique STABLE (règle de couture par frontière).
    const fPipeline = pipelineManager.get(asset);
    if (fPipeline) {
      fPipeline.processHistory({
        candles: ingest.series.closed.map(c => ({
          time: (c as any).time, open: (c as any).open, high: (c as any).high,
          low: (c as any).low, close: (c as any).close, volume: (c as any).volume ?? 0,
        })),
        firstTimestamp: ingest.series.closed.length > 0 ? (ingest.series.closed[0] as any).time : null,
        lastTimestamp: ingest.series.closed.length > 0 ? (ingest.series.closed[ingest.series.closed.length - 1] as any).time : null,
      }, { deep: true });
      emitMarketDataHealth(io, asset, true);
    }
    // Return the complete broker result to an explicit Fetch History caller.
    // The synchronizer intentionally keeps a small live warm-up buffer, but
    // Strategy Tester needs the requested multi-day series for replay.
    return mapped;
  } catch (e: any) {
    log(io, 'error', `[HISTORY] fetch ${key} échoué: ${e.message}`);
    return [];
  } finally {
    historyFetchStates.set(key, false);
  }
}

/**
 * v6.10 — Ingestion du snapshot `updateHistoryNewFast` (HAR fix_gaps.har).
 *
 * Après chaque `changeSymbol`, le broker pousse ~1500 ticks (~12 min)
 * CONTIGUS avec `updateStream`. Cette graine rapide rend l'asset LIVE en
 * < 1 s (plus d'attente de la pagination loadHistoryPeriod — minutes en
 * multi-assets 24) :
 *   1. `candleSync.ingestHistoryTicks` — fusion buffer canonique + re-seed
 *      de TOUS les timeframes (S5/S30/M1/M5) de CET asset ;
 *   2. `candles-history` → le frontend route vers le LiveEngine de SON
 *      asset (§21) — le graphique est immédiatement dessinable ;
 *   3. `pipeline.processHistory` — historyReady : l'asset devient TRADABLE
 *      dès qu'il a assez de bougies fraîches ;
 *   4. santé diffusée (badge LIVE/DEGRADED/BLOCKED à jour instantanément).
 *
 * Le fetch paginé (fetchAndBroadcastHistory) continue en parallèle pour la
 * profondeur (1440 bougies) — il COMPLÈTE la série (fusion par bucket,
 * rang 3 > ticks réagrégés rang 2), il ne la remplace pas.
 */
function ingestHistoryFastSnapshot(
  io: Server,
  asset: string,
  ticks: ReadonlyArray<{ time: number; price: number }>,
): void {
  if (!session.client) return;
  // Isolation multi-assets (§6) : un snapshot d'un asset non sélectionné ne
  // doit JAMAIS contaminer le workspace.
  if (!registry.has(asset)) return;
  if (!Array.isArray(ticks) || ticks.length === 0) return;

  const chartPeriod = chartPeriodSec();
  // Défense anti-race : le broker peut envoyer updateHistoryNewFast
  // immédiatement après changeSymbol. Le pipeline doit exister AVANT ce
  // snapshot, sinon historyReady reste à false et l'asset devient
  // artificiellement HISTORY_NOT_READY jusqu'au prochain tick.
  pipelineManager.get(asset) ?? pipelineManager.getOrCreate(asset);
  // Les ticks sont période-agnostiques : on ignore la période annoncée par
  // le broker (elle suit le dernier changeSymbol) et on re-seed TOUS les
  // timeframes depuis la même chronologie fusionnée.
  const res = candleSync.ingestHistoryTicks(asset, ticks);
  if (res.merged <= 0) return;

  log(io, 'info', formatStructuredLog('HISTORY', {
    asset,
    event: 'FAST_SNAPSHOT_INGESTED',
    source: 'updateHistoryNewFast',
    ticksReceived: ticks.length,
    ticksMerged: res.merged,
    duplicates: res.duplicates,
    firstTickSec: Math.round(res.firstTickSec),
    lastTickSec: Math.round(res.lastTickSec),
    note: 'graine rapide ~12 min — historyReady immédiat, pagination en complément',
  }));

  // Série du timeframe graphique recalculée → diffuser au frontend (§21).
  const series = candleSync.getSeries(asset, chartPeriod);
  const seriesAll = [...series.closed, ...(series.forming ? [series.forming] : [])];
  if (seriesAll.length > 0) {
    const ctx = registry.getAssetContext(asset);
    const mkt = ctx?.market ?? getMarket(asset);
    io.emit('candles-history', {
      asset,
      key: `${mkt.active_id}:${chartPeriod}`,
      candles: seriesAll.slice(-300),
      count: seriesAll.length,
    });
  }

  // Pipeline DE CET asset : historyReady (§4/§5).
  // ~12 min de ticks → ~24 bougies clôturées en S30 : l'asset n'attend plus
  // le fetch paginé pour devenir LIVE (minCandles = 25 couvert en < 15 min
  // de flux, la pagination complète la profondeur entre-temps).
  // v6.10.1 — deep: false : le snapshot fast est du LIVE seedé — il ne pose
  // PAS la frontière d'historique (historyEndSec reste la fin de PAGINATION)
  // → la règle « frontière » de détection de couture reste stable aux
  // ré-ingestions ultérieures (reconnexion / gap-resync / repair).
  const pipeline = pipelineManager.get(asset) ?? pipelineManager.getOrCreate(asset);
  if (pipeline && series.closed.length > 0) {
    const closed = series.closed;
    pipeline.processHistory({
      candles: closed.map(c => ({
        time: (c as any).time, open: (c as any).open, high: (c as any).high,
        low: (c as any).low, close: (c as any).close, volume: (c as any).volume ?? 0,
      })),
      firstTimestamp: closed.length > 0 ? (closed[0] as any).time : null,
      lastTimestamp: closed.length > 0 ? (closed[closed.length - 1] as any).time : null,
    }, { deep: false });
    emitMarketDataHealth(io, asset, true);
  }
}

/**
 * CHANGEMENT DE TIMEFRAME — réplique EXACTE du protocole Pocket Option
 * observé dans le .har fourni :
 *   1. `changeSymbol {asset, period}` → le serveur re-tague le flux broker
 *      (updateHistoryNewFast + updateStream + candles_update) à la NOUVELLE
 *      période : historique et live restent synchronisés.
 *   2. Ré-agrégation INSTANTANÉE du buffer de ticks local (miroir de
 *      updateHistoryNewFast) → le graphique est cohérent en < 1 s.
 *   3. Fetch paginé complet en arrière-plan → re-seed + re-emit.
 *   4. Reset + re-seed des moteurs d'analyse dans le nouveau timeframe.
 */
function applyTimeframeSwitch(io: Server, prevSize: number, newSize: number): void {
  if (!session.client) return;
  const selected = registry.assets();
  if (selected.length === 0) return;
  log(io, 'info',
    `[TF-SWITCH] ${prevSize}s → ${newSize}s sur ${selected.length} asset(s) — synchronisation historique/live ` +
    `(protocole PO : changeSymbol + ré-agrégation ticks)`);

  // 1. Bascule le contexte du flux broker à la nouvelle période (protocole
  //    .har) — changeSymbol ne concerne que l'ASSET FOCUS (le broker ne
  //    pousse candles_update que pour UN symbole à la fois ; les autres
  //    assets restent alimentés par leurs ticks updateStream).
  if (tradingMode.focus) {
    try { session.client.market.changeSymbol(tradingMode.focus, newSize as any); } catch { /* best-effort */ }
  }

  // MULTI-ASSETS : le changement de timeframe s'applique à CHAQUE asset
  // sélectionné — chacun avec SA PROPRE série, SON propre re-seed (§9/§29).
  // v6.4 — Santé : les seuils de fraîcheur (tick/bougie stale) sont
  // RECALCULÉS depuis le NOUVEAU timeframe pour TOUS les pipelines (§12 —
  // seuils dynamiques, jamais hardcodés pour un seul timeframe).
  pipelineManager.setTimeframeSec(newSize);
  for (const asset of selected) {
    const ctx = registry.getAssetContext(asset);
    if (!ctx) continue;

    // 2. Série du NOUVEAU timeframe — INSTANTANÉE (< 1 s, zéro aller-retour
    //    réseau) : le builder du nouveau timeframe est CHAUD depuis la
    //    sélection (chaque tick alimente TOUS les timeframes depuis le MÊME
    //    buffer — §10) ; une série froide est ré-agrégée depuis le buffer.
    //    + SANITISATION PRIX : le buffer étant PAR ASIF, la contamination
    //    multi-actifs est structurellement impossible ici.
    const partial = candleSync.switchPeriod(asset, newSize);
    const partialAll = [...partial.closed, ...(partial.forming ? [partial.forming] : [])];
    if (partialAll.length > 0) {
      io.emit('candles-history', {
        asset,                                  // §21 — routage par asset
        key: `${ctx.market.active_id}:${newSize}`,
        candles: partialAll,
        count: partialAll.length,
        partial: true,
      });
      log(io, 'info', assetLog(asset, `TF-SWITCH historique partiel instantané: ${partialAll.length} bougies ${newSize}s (buffer de ticks)`));
    }

    // 3. Historique complet en arrière-plan (paginé loadHistoryPeriod)
    fetchAndBroadcastHistory(io, asset, newSize, session.config.historyCount ?? 300, 'tf-switch').catch(() => {});

    // 4. Reset + re-seed des moteurs d'analyse DE CET ASSET (EngineState MTF
    //    reconstruit dans la nouvelle résolution).
  }
}

// v20 — getStrictAutoSwitchCandidates / performStrictPostTradeSwitch et le
// switch « 90s idle » ont été SUPPRIMÉS : les nouvelles règles Auto Switch
// (payout < 92% + dernier ordre = GAIN → asset payout == 92%) vivent dans
// payout-guard.ts et s'exécutent sur chaque poussée updateAssets via
// runPayoutGuard(io, assets) branché sur client.on('assets').

/**
 * Switch market atomically and FORCE a fresh bounded history refresh before
 * returning. The frontend is explicitly told to clear the old chart before
 * new candles arrive, preventing any old-asset candle from being reused.
 */
async function switchAssetAndRefresh(io: Server, fromAsset: string, nextAsset: string, reason: string, payout?: number): Promise<boolean> {
  if (!session.client || session.assetSwitchInProgress) return false;
  if (!nextAsset || nextAsset === fromAsset) return false;
  const nextMarket = getMarket(nextAsset);
  if (!nextMarket) {
    log(io, 'warning', `[ASSET-SWITCH] ${nextAsset} has no market definition`);
    return false;
  }

  const period = session.config.candleSize ?? 30;
  const isMulti = tradingMode.mode === 'multi'
    && tradingMode.assets.length > 1
    && tradingMode.assets.includes(fromAsset);

  session.assetSwitchInProgress = true;
  try {
    io.emit('market-refresh', { phase: 'start', from: fromAsset, to: nextAsset, reason, mode: isMulti ? 'multi' : 'single' });

    if (isMulti) {
      // MULTI-ASSETS : remplacer UNIQUEMENT l'asset déclencheur. Les autres
      // contextes, pipelines, abonnements, historiques et états de mise sont
      // intouchables. C'est la règle anti-contamination du workspace.
      const nextAssets = tradingMode.assets.map(a => a === fromAsset ? nextAsset : a);
      const uniqueNextAssets = [...new Set(nextAssets)];

      try { session.client.market.unsubscribe(fromAsset); } catch { /* best effort */ }
      registry.removeAssetContext(fromAsset);
      candleSync.purgeAsset(fromAsset);
      pipelineManager.remove(fromAsset);
      assetTickStats.delete(fromAsset);
      healthEmitTs.delete(fromAsset);

      registry.ensureAssetContext(nextAsset, {
        market: nextMarket,
        bettingStrategy: session.config.bettingStrategy ?? 'fixed',
        baseAmount: parseFloat(session.config.margin) || 1,
        maxMartingaleSteps: clampMaxMartingaleSteps(session.config.maxMartingaleSteps),
        autoTradeEnabled: session.config.autoTradeEnabled && session.config.autoOpen,
      });
      // CRITIQUE : le pipeline existe AVANT subscribe/changeSymbol car le
      // broker peut envoyer updateHistoryNewFast dans la même micro-tâche.
      pipelineManager.get(nextAsset) ?? pipelineManager.getOrCreate(nextAsset);

      tradingMode.assets = uniqueNextAssets;
      tradingMode.mode = 'multi';
      const focus = tradingMode.focus === fromAsset ? nextAsset : (tradingMode.focus && uniqueNextAssets.includes(tradingMode.focus) ? tradingMode.focus : uniqueNextAssets[0]);
      tradingMode.focus = focus;
      session.market = registry.getAssetContext(focus)?.market ?? getMarket(focus);
      session.config.market = focus;
      candleSync.setActiveAssets(uniqueNextAssets, period, focus);

      session.client.market.subscribe(nextAsset);
      try { session.client.market.changeSymbol(nextAsset, period as any); } catch { /* subscription remains authoritative */ }
      candleSync.switchAsset(nextAsset);

      if (candleTickRecorder && recorderAsset === fromAsset) {
        candleTickRecorder.setAsset(nextAsset);
        recorderAsset = nextAsset;
      }

      io.emit('market-switched', {
        from: fromAsset,
        to: nextAsset,
        reason,
        payout: payout ?? null,
        refreshRequired: true,
        mode: 'multi',
      });
      io.emit('assets-selected', { ok: true, mode: 'multi', assets: uniqueNextAssets, focus, refreshRequired: true });

      await fetchAndBroadcastHistory(io, nextAsset, period, Math.min(100, session.config.historyCount ?? 100), `mandatory-refresh:${reason}`);
      session.lastAutoSwitchTs = Date.now();
      saveSessionSnapshot();
      io.emit('market-refresh', { phase: 'complete', from: fromAsset, to: nextAsset, reason, refreshRequired: false, mode: 'multi' });
      // v21 — REFRESH OBLIGATOIRE DU FRONTEND à chaque Auto Switch Assets : la
      // page est rechargée intégralement une fois le backend reconstruit
      // (abonnement, contextes, historique du nouvel asset).
      io.emit('force-frontend-refresh', { reason: 'auto-switch', from: fromAsset, to: nextAsset, at: Date.now() });
      log(io, 'info', `[ASSET-SWITCH] MULTI ${fromAsset} → ${nextAsset}${payout != null ? ` (${payout}% payout)` : ''} — ${uniqueNextAssets.length} assets conservés, refresh COMPLETE (frontend reload demandé)`);
      return true;
    }

    // SINGLE-ASSET : comportement historique, mais pipeline prêt avant
    // changeSymbol pour fermer la race updateHistoryNewFast → HISTORY_NOT_READY.
    try { session.client.market.unsubscribe(fromAsset); } catch { /* best effort */ }
    if (fromAsset) {
      registry.removeAssetContext(fromAsset);
      candleSync.purgeAsset(fromAsset);
      pipelineManager.remove(fromAsset);
    }
    if (candleHistoryCache) {
      candleHistoryCache.stop();
      candleHistoryCache = null;
      primaryCacheAsset = null;
    }
    session.market = nextMarket;
    session.config.market = nextAsset;
    session.closeWindow = [];
    registry.ensureAssetContext(nextAsset, {
      market: nextMarket,
      bettingStrategy: session.config.bettingStrategy ?? 'fixed',
      baseAmount: parseFloat(session.config.margin) || 1,
      maxMartingaleSteps: clampMaxMartingaleSteps(session.config.maxMartingaleSteps),
      // v20 — BUG FIX « 30 min à attendre le 1er ordre » : le switch
      // d'asset en mode SINGLE créait le nouveau contexte avec Auto Trade
      // DÉSACTIVÉ en dur, même si le master-switch global était ON — le
      // nouvel asset ne tradait JAMAIS jusqu'à ce que l'utilisateur retoggle
      // le switch. On propage désormais l'état global, comme le mode MULTI.
      autoTradeEnabled: session.config.autoTradeEnabled && session.config.autoOpen,
    });
    pipelineManager.get(nextAsset) ?? pipelineManager.getOrCreate(nextAsset);
    session.client.market.subscribe(nextAsset);
    try { session.client.market.changeSymbol(nextAsset, period as any); } catch { /* subscription remains authoritative */ }
    tradingMode.mode = 'single';
    tradingMode.assets = [nextAsset];
    tradingMode.focus = nextAsset;
    candleSync.setActiveAssets([nextAsset], period, nextAsset);
    candleSync.switchAsset(nextAsset);
    if (candleTickRecorder) candleTickRecorder.setAsset(nextAsset);
    recorderAsset = nextAsset;

    io.emit('market-switched', { from: fromAsset, to: nextAsset, reason, payout: payout ?? null, refreshRequired: true, mode: 'single' });
    io.emit('assets-selected', { ok: true, mode: 'single', assets: [nextAsset], focus: nextAsset, refreshRequired: true });
    await fetchAndBroadcastHistory(io, nextAsset, period, Math.min(100, session.config.historyCount ?? 100), `mandatory-refresh:${reason}`);
    session.lastAutoSwitchTs = Date.now();
    saveSessionSnapshot();
    io.emit('market-refresh', { phase: 'complete', from: fromAsset, to: nextAsset, reason, refreshRequired: false, mode: 'single' });
    // v21 — REFRESH OBLIGATOIRE DU FRONTEND à chaque Auto Switch Assets : la
    // page est rechargée intégralement une fois le backend reconstruit
    // (abonnement, contextes, historique du nouvel asset).
    io.emit('force-frontend-refresh', { reason: 'auto-switch', from: fromAsset, to: nextAsset, at: Date.now() });
    log(io, 'info', `[ASSET-SWITCH] ${fromAsset || 'none'} → ${nextAsset}${payout != null ? ` (${payout}% payout)` : ''} — mandatory candle refresh COMPLETE (frontend reload demandé)`);
    return true;
  } catch (e: any) {
    log(io, 'error', `[ASSET-SWITCH] ${fromAsset} → ${nextAsset} failed: ${e?.message ?? e}`);
    io.emit('market-refresh', { phase: 'error', from: fromAsset, to: nextAsset, reason, error: e?.message ?? String(e) });
    return false;
  } finally {
    session.assetSwitchInProgress = false;
  }
}

// v20 — performStrictPostTradeSwitch, AUTO_SWITCH_IDLE_TIMEOUT_MS,
// noteSuccessfulOrderPlaced, maybeAutoSwitchAfterIdle, startAutoSwitchIdleMonitor
// et stopAutoSwitchIdleMonitor ont été SUPPRIMÉS au profit des nouvelles règles
// Auto Switch (payout-guard.ts + runPayoutGuard). L'Auto Trade n'est plus
// jamais interrompu par un switch : switchAssetAndRefresh propage désormais
// l'état global (bug « 30 min sans 1er ordre »).

function startStrategyLoop(io: Server): void {
  if (session.strategyRunning) return;
  session.strategyRunning = true;
  log(io, 'info', `backend auto-trade loop started — ${registry.size} asset(s) traité(s) en parallèle (runs even if frontend is closed)`);
  const tick = async () => {
    if (!session.strategyRunning) return;
    try {
      if (!session.assetSwitchInProgress) await runStrategyIteration(io);
    } catch (e: any) {
      log(io, 'error', `strategy iteration error: ${e.message}`);
    }
    // Loop interval: 1 s for L_Lucien ProTrader (closed candles). Ninja
    // ProTrader detects events BEFORE the candle closes (forming candle,
    // live price) → 500 ms polling narrows the pre-close detection window.
    const interval = (session.config.strategyId === 'ninja_protrader') ? 500 : 1000;
    session.strategyLoopTimer = setTimeout(tick, interval);
  };
  tick();
}

function stopStrategyLoop(io: Server): void {
  session.strategyRunning = false;
  if (session.strategyLoopTimer) {
    clearTimeout(session.strategyLoopTimer);
    session.strategyLoopTimer = null;
  }
  log(io, 'info', 'strategy loop stopped');
}

// --------------------------------------------------------------------------
//  Persistent candle history cache initialization
// --------------------------------------------------------------------------
//  On program startup (after login):
//    1. Create a CandleHistoryCache for the selected asset + S5 period
//    2. Try to load the JSON file from disk
//    3. If file doesn't exist → fetch latest 100 candles only
//    4. If file exists → compute the gap (last candle → now) and fetch only missing candles
//    5. Seed the real-time CandleBuilder with the full cache
//    6. Start periodic flush (every 30 seconds) to persist new candles
// --------------------------------------------------------------------------

// Génération courante d'initialisation du cache — PAR ASSET (Map) :
// incrémentée à chaque appel d'initializeCandleHistoryCache POUR CET asset.
// Les boucles de fetch vérifient ce compteur à chaque itération et
// s'interrompent dès qu'elles sont supplantées par une init plus récente du
// MÊME asset — l'init d'un AUTRE asset ne l'interrompt plus (multi-assets).
let candleCacheInitGeneration = 0; // legacy — voir candleCacheInitGenerations (Map)

async function initializeCandleHistoryCache(io: Server, asset: string, period: number): Promise<void> {
  const generation = (candleCacheInitGenerations.get(asset) ?? 0) + 1;
  candleCacheInitGenerations.set(asset, generation);
  const isSuperseded = () => (candleCacheInitGenerations.get(asset) ?? 0) !== generation;
  if (!session.client) {
    log(io, 'error', 'candle cache init: no client');
    return;
  }
  // §17 — génération du synchroniseur : si le timeframe/actif change pendant
  // le fetch historique, la réponse sera rejetée par ingestHistory.
  const syncGeneration = candleSync.beginHistoryLoad(asset, period);

  log(io, 'info', `[CACHE] === initializeCandleHistoryCache START === asset=${asset} period=S${period}s dir=${CANDLE_CACHE_DIR}`);

  // Stop previous cache if any (e.g. asset switch)
  if (candleHistoryCache) {
    candleHistoryCache.stop();
    candleHistoryCache = null;
  }
  // §27 — UN SEUL cache borné : l'asset qui porte le cache. Les autres
  // assets sélectionnés (mode multi) utilisent le fetch léger
  // fetchAndBroadcastHistory — pas de tempête de fetchs historiques × N assets.
  primaryCacheAsset = asset;

  candleHistoryCache = new CandleHistoryCache(asset, period, CANDLE_CACHE_DIR, 300);
  const loaded = candleHistoryCache.load();
  log(io, 'info', `[CACHE] load() returned: ${loaded ? 'EXISTING FILE LOADED' : 'NO FILE (first run)'}`);

  // ── AUTO-GUÉRISON DU CACHE (contamination multi-actifs) ──────────────
  // Les sessions passées (auto-switch pendant un fetch 90 j, requêtes
  // croisées…) ont pu écrire des bougies d'AUTRES actifs dans ce fichier
  // (ex. cache EURGBP contenant XAUUSD ~4400 et EURJPY ~185). Ces bougies
  // détruisaient le graphique à CHAQUE démarrage. On purge maintenant au
  // chargement : le fichier est réécrit proprement au prochain flush.
  if (loaded) {
    const purged = candleHistoryCache.purgePriceOutliers();
    if (purged > 0) {
      log(io, 'warning', `[CACHE] ${purged} bougies contaminantes PURGÉES du cache ${asset} S${period} (prix incohérent avec l'actif) — le graphique ne peut plus être éclaté par ce fichier`);
      candleHistoryCache.save(true);
    }
  }

  if (!loaded) {
    // Bounded cache: fetch only the latest 100 candles on first run.
    const maxInitialCandles = 300;
    log(io, 'info', `[CACHE] First run: fetching latest ${maxInitialCandles} candles only (hard cap = 300)...`);
    try {
      const candles = await session.client.market.loadFullHistory(asset, period as any, Math.min(300, maxInitialCandles), getHistoryAnchorSec(asset));
      if (isSuperseded()) {
        log(io, 'info', `[CACHE] Init for ${asset} superseded during initial fetch — aborting`);
        return;
      }
      const cached: CachedCandle[] = candles.slice(-300).map(c => ({
        time: c.time, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume ?? 0,
      }));
      const result = candleHistoryCache.addHistoricalBatch(cached);
      candleHistoryCache.save(true);
      log(io, 'info', `[CACHE] Initial fetch complete: ${cached.length} received, +${result.added}, updated ${result.updated}, rejected ${result.rejected}; retained=${candleHistoryCache.size()}`);
    } catch (e: any) {
      log(io, 'error', `[CACHE] Initial 100-candle fetch failed: ${e.message}. Continuing with empty cache.`);
    }
  } else {
    // Existing cache: repair only a recent gap of <= 100 candles.
    const lastTime = candleHistoryCache.getLastCandleTime();
    const marketNow = candleSync.getLatestMarketTimeSec(asset);
    const now = marketNow > 0 ? Math.floor(marketNow) : Math.floor(Date.now() / 1000);
    const gapSeconds = Math.max(0, now - lastTime);
    const missingCandles = Math.floor(gapSeconds / period) + 1;

    if (missingCandles <= 1) {
      log(io, 'info', `[CACHE] Cache is up-to-date (${candleHistoryCache.size()} candles). No fetch needed.`);
    } else if (missingCandles <= 300) {
      log(io, 'info', `[CACHE] Recent gap = ${missingCandles} candles; fetching at most 300.`);
      try {
        const candles = await session.client.market.loadFullHistory(asset, period as any, Math.min(300, missingCandles), getHistoryAnchorSec(asset));
        if (isSuperseded()) {
          log(io, 'info', `[CACHE] Init for ${asset} superseded during incremental fetch — aborting`);
          return;
        }
        const cached: CachedCandle[] = candles.slice(-300).map(c => ({
          time: c.time, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume ?? 0,
        }));
        const fetchedLast = cached.length > 0 ? cached[cached.length - 1].time : 0;
        const maxHistoricalLag = Math.max(period * 3, 60);
        if (marketNow > 0 && fetchedLast > 0 && marketNow - fetchedLast > maxHistoricalLag) {
          candleHistoryCache.clear();
          log(io, 'error', `[CACHE] Incremental refresh returned stale candles (lag=${marketNow - fetchedLast}s > ${maxHistoricalLag}s). OLD cache purged; continuing from live only.`);
        } else {
          const result = candleHistoryCache.addHistoricalBatch(cached);
          log(io, 'info', `[CACHE] Incremental fetch done: +${result.added}, updated ${result.updated}, rejected ${result.rejected}; retained=${candleHistoryCache.size()}`);
        }
      } catch (e: any) {
        candleHistoryCache.clear();
        log(io, 'error', `[CACHE] Incremental fetch failed: ${e.message}. OLD cache purged; continuing from live only.`);
      }
    } else {
      // PERMANENT CONTINUITY FIX : ne JAMAIS mélanger un cache ancien avec le
      // segment LIVE courant. C'est précisément ce qui produisait dans le
      // graphique une ancienne grappe puis une nouvelle grappe séparée par un
      // saut temporel (logs : S30 = 218 bougies manquantes).
      //
      // On tente un refresh des dernières bougies. Si le broker échoue, on
      // PURGE quand même le vieux cache : le flux live reste la seule source
      // visible plutôt qu'un historique périmé recousu artificiellement.
      log(io, 'warning', `[CACHE] Large gap detected (${missingCandles} candles) — stale cache quarantined; refreshing latest 300 candles.`);
      try {
        const candles = await session.client.market.loadFullHistory(asset, period as any, 300, getHistoryAnchorSec(asset));
        if (isSuperseded()) {
          log(io, 'info', `[CACHE] Init for ${asset} superseded during stale-cache refresh — aborting`);
          return;
        }
        const incoming = candles.slice(-300).map(c => ({
          time: c.time, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume ?? 0,
        }));
        const liveNow = candleSync.getLatestMarketTimeSec(asset);
        const fetchedLast = incoming.length > 0 ? incoming[incoming.length - 1].time : 0;
        const maxHistoricalLag = Math.max(period * 3, 60);
        if (liveNow > 0 && fetchedLast > 0 && liveNow - fetchedLast > maxHistoricalLag) {
          candleHistoryCache.clear();
          log(io, 'error', `[CACHE] Broker refresh returned stale candles (lag=${liveNow - fetchedLast}s > ${maxHistoricalLag}s). Data rejected; continuing from live only.`);
        } else {
          candleHistoryCache.clear();
          const result = candleHistoryCache.addHistoricalBatch(incoming);
          log(io, 'info', `[CACHE] Stale-cache quarantine complete: refreshed=${incoming.length}, +${result.added}, updated=${result.updated}, rejected=${result.rejected}`);
        }
      } catch (e: any) {
        candleHistoryCache.clear();
        log(io, 'error', `[CACHE] Stale-cache refresh failed: ${e.message}. OLD cache purged; continuing from live only.`);
      }
    }
  }

  // Save the cache immediately after init (force write)
  if (isSuperseded() || !candleHistoryCache) {
    log(io, 'info', `[CACHE] Init for ${asset} aborted before final save (cache stopped or superseded)`);
    return;
  }
  log(io, 'info', `[CACHE] Saving cache to disk (${candleHistoryCache.size()} candles)...`);
  candleHistoryCache.save(true);
  log(io, 'info', `[CACHE] Cache saved. File: ${CANDLE_CACHE_DIR}/candles_${asset.replace(/[^a-zA-Z0-9_-]/g, '_')}_S${period}.json`);

  // Seed the real-time synchronizer with the full cache.
  // ⚠️ GARDE ANTI-DESYNC : si l'utilisateur a changé de timeframe PENDANT ce
  // fetch (qui peut durer des minutes), la période du graphique n'est plus
  // `period` — seeder maintenant écraserait les bougies du nouveau
  // timeframe avec celles de l'ancien (bug « historique S30 + live M5 »).
  // Double garde : contexte session + génération du synchroniseur (§17).
  let cacheIngestSeries: CandleSeries | null = null;
  if ((session.config.candleSize ?? 30) !== period) {
    log(io, 'info', `[CACHE] Init ${asset} S${period} terminée, mais le timeframe sélectionné est maintenant ` +
      `S${session.config.candleSize} — seed du synchroniseur IGNORÉ (garde anti-désynchronisation). Le cache 90 j reste utilisé par le backtest.`);
  } else {
    // SANITISATION PRIX avant seed : le cache (même purgé au chargement)
    // n'atteint JAMAIS le synchroniseur sans validation de cohérence.
    const rawSeed = candleHistoryCache.getSortedCandles().map(c => ({
      time: c.time, open: c.open, high: c.high, low: c.low, close: c.close, volume: c.volume,
    }));
    const liveTicksForAnchor = candleSync.getTickBuffer(asset);
    const liveAnchorPrice = liveTicksForAnchor.length > 0
      ? liveTicksForAnchor[liveTicksForAnchor.length - 1].price
      : 0;
    const seedSanitized = sanitizeCandlesByPrice(rawSeed, {
      referencePrice: liveAnchorPrice > 0 ? liveAnchorPrice : undefined,
      maxRelativeDistance: liveAnchorPrice > 0 ? 0.05 : undefined,
    });
    const regime = seedSanitized.clean.length > 1
      ? retainLatestPriceRegime(seedSanitized.clean, { maxRelativeStep: 0.05, maxRelativeToAnchor: 0.05 })
      : { clean: seedSanitized.clean, dropped: 0, breakIndex: null };
    const safeSeed = regime.clean;
    const totalDropped = seedSanitized.dropped + regime.dropped;
    if (totalDropped > 0) {
      log(io, 'warning', `[CACHE] continuity firewall: ${totalDropped}/${rawSeed.length} bougies REJETÉES avant seed (régime de prix / actif / saut incohérent)`);
    }
    // FUSION cache (rang 1) + ticks live réagrégés (rang 2) : les bougies en
    // formation appartiennent au live, les clôturées récentes recouvrent le
    // cache → couture historique ↔ live sans doublon (§5/§14).
    const ingest = candleSync.ingestHistory(asset, period, safeSeed, {
      generation: syncGeneration,
      source: 'cache',
    });
    if (ingest.accepted) {
      cacheIngestSeries = ingest.series;
      log(io, 'info',
        `[CACHE] synchroniseur seedé avec ${ingest.series.closed.length + (ingest.series.forming ? 1 : 0)} bougies ` +
        `canoniques du cache (fusion ticks live, recouvrement=${ingest.report.lastMerge?.overlapBuckets ?? 0} buckets, ` +
        `état=${ingest.report.state})`);
    } else {
      log(io, 'info', `[CACHE] seed du synchroniseur IGNORÉ (${ingest.reason}) — le live poursuit la série`);
    }
  }
  // Sanitisation systématique pour TOUS les consommateurs en aval
  // (stratégies + emit candles-history) : référence = dernier prix sain.
  const allRaw = candleHistoryCache.getSortedCandles();
  const allSan = sanitizeCandlesByPrice(allRaw as unknown as Array<{ time: number; open: number; high: number; low: number; close: number; volume: number }>);
  const allCandles = allSan.clean as typeof allRaw;
  if (allSan.dropped > 0) {
    log(io, 'warning', `[CACHE] ${allSan.dropped}/${allRaw.length} bougies écartées des consommateurs aval (Pattern/emit)`);
  }

  // ==========================================================
  // v6.4 — Le pipeline DE CET ASSET reçoit SES PROPRES bougies (§5)
  // ⚠️ PLUS AUCUNE GATE FOCUS : chaque asset sélectionné qui initialise SON
  // historique marque SON pipeline historyReady. L'historique EURUSD ne
  // part JAMAIS vers le pipeline de GBPJPY (isolation §4/§5 — vérifiée par
  // assertAsset dans les entrées du pipeline, §29).
  // ==========================================================
  {
    const pipeline = registry.has(asset) ? pipelineManager.getOrCreate(asset) : null;
    if (pipeline) {
      pipeline.processHistory({
        candles: allCandles.map(c => ({
          time: c.time, open: c.open, high: c.high, low: c.low,
          close: c.close, volume: c.volume ?? 0,
        })),
        firstTimestamp: allCandles.length > 0 ? allCandles[0].time : null,
        lastTimestamp: allCandles.length > 0 ? allCandles[allCandles.length - 1].time : null,
      });
      // Santé : historique de CET asset prêt (§4 — historyReady).
      emitMarketDataHealth(io, asset, true);
    } else {
      // Asset non sélectionné (init supplantée) : rien à seeder.
      log(io, 'info', `[PATTERN] Init for ${asset} hors sélection — seed ignoré`);
    }
  }

  // Emit the full history to frontend — UNIQUEMENT si cette init est toujours
  // la plus récente (sinon une init supplantée enverrait un historique périmé
  // d'un autre actif au frontend) ET si le timeframe du graphique correspond
  // toujours à la période du cache (une émission avec une clé de l'ANCIEN
  // timeframe polluerait le dataset du nouveau).
  if (isSuperseded()) {
    log(io, 'info', `[CACHE] Init for ${asset} superseded — skipping candles-history emit`);
    return;
  }
  if ((session.config.candleSize ?? 30) !== period) {
    log(io, 'info', `[CACHE] Timeframe graphique S${session.config.candleSize} ≠ période cache S${period} — émission candles-history IGNORÉE (le graphique suit le timeframe sélectionné)`);
  } else {
    // Émet la SÉRIE CANONIQUE fusionnée (cache + ticks live) quand elle est
    // disponible — sinon le cache sanitisé (série minimale cohérente).
    const emitSeries = cacheIngestSeries
      ? [...cacheIngestSeries.closed, ...(cacheIngestSeries.forming ? [cacheIngestSeries.forming] : [])]
      : allCandles;
    io.emit('candles-history', {
      asset,                                        // §21 — routage par asset
      key: `${registry.getAssetContext(asset)?.market.active_id ?? getMarket(asset).active_id}:${period}`,
      candles: emitSeries.slice(-300),  // Hard cap: frontend receives at most 300 candles
      count: emitSeries.length,
      cached: true,
    });
  }

  // Start periodic flush (every 30 seconds)
  candleHistoryCache.startPeriodicFlush(30000);
  log(io, 'info', `[CACHE] Periodic flush started (every 30s). Real-time ticks will be appended to cache.`);
  log(io, 'info', `[CACHE] === initializeCandleHistoryCache END ===`);

  // Graceful shutdown handler — save cache on process exit
  // (only register once)
  if (!process.env._CANDLE_CACHE_SHUTDOWN_REGISTERED) {
    process.env._CANDLE_CACHE_SHUTDOWN_REGISTERED = '1';
    const gracefulShutdown = () => {
      if (candleHistoryCache) {
        console.log('[CandleHistoryCache] Graceful shutdown — saving cache...');
        candleHistoryCache.stop();
      }
      if (candleTickRecorder) {
        console.log('[CandleTickRecorder] Graceful shutdown — flushing last candle...');
        candleTickRecorder.stop();
      }
      if (streamTickNormalizer) {
        try { streamTickNormalizer.destroy(); } catch { /* ignore */ }
      }
      // v6.3 — arrête le heartbeat headless.
      if (session.heartbeatTimer) {
        clearInterval(session.heartbeatTimer);
        session.heartbeatTimer = null;
      }
      if (session.statusBroadcastTimer) {
        clearInterval(session.statusBroadcastTimer);
        session.statusBroadcastTimer = null;
      }
      // v6.3 — persiste la session de trading (reprise au prochain login).
      try {
        const snapshot = buildSessionSnapshot();
        if (SESSION_SNAPSHOT_PATH && snapshot.assets.length > 0) {
          mkdirSync(path.dirname(SESSION_SNAPSHOT_PATH), { recursive: true });
          writeFileSync(SESSION_SNAPSHOT_PATH, JSON.stringify({ ...snapshot, version: 1, savedAt: Date.now() }, null, 2), 'utf-8');
          console.log('[SessionSnapshot] Graceful shutdown — session persistée.');
        }
      } catch (e: any) {
        console.log(`[SessionSnapshot] shutdown save error: ${e?.message ?? e}`);
      }
      process.exit(0);
    };
    process.on('SIGINT', gracefulShutdown);
    process.on('SIGTERM', gracefulShutdown);
    process.on('beforeExit', gracefulShutdown);
  }
}

// --------------------------------------------------------------------------
//  Setup PocketOptionClient event handlers
// --------------------------------------------------------------------------

// --------------------------------------------------------------------------
//  Candle fusion & deduplication — SINGLE AUTHORITY per (asset, period, time)
// --------------------------------------------------------------------------
// The backend has TWO candle sources:
//   A. `stream` ticks  -> CandleBuilder (local aggregation, config.candleSize)
//   B. `candles_update` -> broker-built candles (server aggregation)
// Both used to emit `candle` events directly, so the frontend could receive
// the same bucket twice per update (A then B then A then B...), causing
// redundant chart updates. This layer merges/dedups them:
//   - key            = (asset, period, timestamp)
//   - identical OHLCV  -> dropped (pure duplicate)
//   - forming bucket   -> the CandleBuilder OWNS it (broker updates ignored
//                         while the builder is fresh, < 10s since last tick)
//   - closed bucket    -> broker corrections accepted (final value wins)
// --------------------------------------------------------------------------

interface CandleEmitRecord {
  open: number; high: number; low: number; close: number; volume: number;
  ts: number;              // Date.now() of last emission for this key
  source: 'builder' | 'broker';
}

const candleEmitRegistry = new Map<string, CandleEmitRecord>();
const CANDLE_REGISTRY_MAX = 800;

function pruneCandleRegistry(): void {
  if (candleEmitRegistry.size <= CANDLE_REGISTRY_MAX) return;
  const cutoff = Date.now() - 15 * 60 * 1000; // 15 minutes
  for (const [k, rec] of candleEmitRegistry) {
    if (rec.ts < cutoff) candleEmitRegistry.delete(k);
  }
  // Hard cap if still too large (oldest first)
  if (candleEmitRegistry.size > CANDLE_REGISTRY_MAX) {
    const keys = [...candleEmitRegistry.entries()].sort((a, b) => a[1].ts - b[1].ts);
    const excess = candleEmitRegistry.size - CANDLE_REGISTRY_MAX;
    for (let i = 0; i < excess; i++) candleEmitRegistry.delete(keys[i][0]);
  }
}

/**
 * Emit a `candle` event to the frontend, deduplicated per (asset, size, time).
 * Returns true when the event was actually emitted.
 */
function emitCandleDeduped(io: Server, candle: {
  asset: string; time: number; open: number; high: number; low: number; close: number;
  volume: number; active_id: number; size: number;
}, source: 'builder' | 'broker'): boolean {
  const key = `${candle.asset}:${candle.size}:${candle.time}`;
  const prev = candleEmitRegistry.get(key);

  if (prev) {
    const identical =
      prev.open === candle.open && prev.high === candle.high &&
      prev.low === candle.low && prev.close === candle.close &&
      prev.volume === candle.volume;
    if (identical) return false; // pure duplicate — drop

    // §7 — CLÔTURE DÉCIDÉE PAR LE TEMPS MARCHÉ UNIQUEMENT : un bucket est
    // clôturé quand un tick du marché a atteint un bucket STRICTEMENT
    // supérieur (latestMarketTimeSec). L'horloge locale n'intervient que
    // comme sécurité visuelle si aucun tick n'a jamais été reçu.
    const marketNow = assetLatestMarketTimeSec(candle.asset) || Math.floor(Date.now() / 1000);
    const isClosedBucket = candle.time + candle.size <= marketNow;
    if (!isClosedBucket && source === 'broker' && prev.source === 'builder') {
      // FORMING candle: the CandleSyncManager owns it while fresh. Ignore the
      // broker's version to avoid A/B oscillation between the two sources.
      if (Date.now() - prev.ts < 10_000) return false;
    }
    // Closed bucket with different OHLCV → broker correction: accept.
  }

  candleEmitRegistry.set(key, {
    open: candle.open, high: candle.high, low: candle.low, close: candle.close,
    volume: candle.volume,
    ts: Date.now(), source,
  });
  pruneCandleRegistry();

  io.emit('candle', {
    ...candle,
    from: candle.time,
    max: candle.high,
    min: candle.low,
  });
  return true;
}


// ─────────────────────────────────────────────────────────────────────────────
//  processAssetTick — ROUTEUR CENTRAL DES TICKS MULTI-ASSETS (§7)
// ─────────────────────────────────────────────────────────────────────────────
//  Broker Socket (UNE seule connexion)
//      ├── updateStream EURUSD ──► tick{asset:EURUSD} ──► processAssetTick
//      ├── updateStream GBPUSD ──► tick{asset:GBPUSD} ──► processAssetTick
//      ├── updateStream XAUUSD ──► tick{asset:XAUUSD} ──► processAssetTick
//      └── updateStream BTCUSD ──► tick{asset:BTCUSD} ──► processAssetTick
//
//  Le tick n'est traité QUE si son asset appartient aux assets SÉLECTIONNÉS
//  (tradingMode.assets — source de vérité §4). Chaque tick alimente :
//    - le CandleSyncManager de SON asset (§8/§10 — historique par asset) ;
//    - le cache 90 j / le recorder JSONL (asset primaire uniquement, §27) ;
//    - l'événement 'candle' avec active_id DE CET ASSET (§21).
// ─────────────────────────────────────────────────────────────────────────────


/**
 * FRACTAL LIVE CUSTOM BIS — mode événementiel ultra-réactif.
 *
 * Le polling 1s reste disponible comme filet de sécurité, mais BIS doit
 * réagir au PREMIER tick qualifiant la bougie en formation. Cela évite de
 * perdre plusieurs centaines de ms à 1 s entre la détection et la requête
 * broker, ce qui est critique pour une expiration courte.
 */


/** Tick-event gate for the BIS + Tick Velocity companion. */

function processAssetTick(io: Server, tick: { asset: string; price: number; marketTimeSec: number; receivedAtMs: number }): void {
  const ctx = registry.getAssetContext(tick.asset);
  // Statut de tick PAR ASSET (payload de statut §21/§25).
  const st = assetTickStats.get(tick.asset) ?? { price: 0, ts: 0, count: 0, activeId: 0 };
  st.price = tick.price;
  st.ts = Date.now();
  st.count++;
  st.activeId = ctx?.market.active_id ?? st.activeId;
  assetTickStats.set(tick.asset, st);

  if (!ctx) return; // tick d'un asset non sélectionné — ignoré (isolation §6)

  session.liveTicksForMarket++;
  // Champs legacy du statut : suivent l'asset FOCUS (compat UI mono-asset).
  if (tick.asset === tradingMode.focus) {
    session.lastTickPrice = tick.price;
    session.lastTickTs = Date.now();
    session.lastTickActiveId = ctx.market.active_id;
    session.lastTickSize = session.config.candleSize;
  }

  // ── PIPELINE DE CET ASSET (§3) ────────────────────────────────────────
  // Tick → AssetPipelineManager → pipeline(asset) → candleSync →
  // marketDataHealth. Le routeur ne contient
  // AUCUNE logique de trading (§23) et NE REGARDE PAS LE FOCUS (§1) :
  // CHAQUE asset sélectionné nourrit SES moteurs avec SES ticks.
  const result = tickRouter.routeTick(tick as PipelineTick);
  const ingest = result?.ingest ?? { applied: false, reason: 'no-pipeline' as const };

  // Bougie temps réel du timeframe graphique (post-ingestion) — DE CET ASSET.
  const updatedCandle = ingest.applied
    ? candleSync.getForming(tick.asset, chartPeriodSec())
    : null;
  // Cache persistant 90 jours — UNIQUEMENT si le cache appartient à cet asset.
  if (candleHistoryCache && primaryCacheAsset === tick.asset) {
    candleHistoryCache.addTick(tick.marketTimeSec, tick.price);
  }
  // v6.4 : pipeline PAR ASSET (§5) — le pipeline de CET asset traite SON tick.
  // L'ancien gate `if (tick.asset === tradingMode.focus)` est SUPPRIMÉ :
  // les pipelines de TOUS les assets sélectionnés sont alimentés.
  // Recorder JSONL temps réel — asset primaire uniquement (§27).
  if (candleTickRecorder && recorderAsset === tick.asset) {
    candleTickRecorder.recordTick(tick.price, tick.marketTimeSec);
  }
  // Santé des données de CET asset (§20/§27) — throttle PAR ASSET.
  emitMarketDataHealth(io, tick.asset);
  if (updatedCandle) {
    emitCandleDeduped(io, {
      asset: tick.asset,
      time: updatedCandle.time,
      open: updatedCandle.open,
      high: updatedCandle.high,
      low: updatedCandle.low,
      close: updatedCandle.close,
      volume: updatedCandle.volume ?? 0,
      active_id: ctx.market.active_id,   // active_id DE CET ASSET (§21)
      size: session.config.candleSize,
    }, 'builder');
  }
}

function attachClientHandlers(client: PocketOptionClient, io: Server): void {
  // --------------------------------------------------------------------
  // ANTI-DUPLICATION : normaliseur du flux `updateStream`.
  //
  // Pocket Option pousse 2 updates par seconde et par actif : le prix au
  // DÉBUT de la seconde (arrivée 1 = open broker, validé 98,4 %) puis le
  // prix à la FIN de la seconde (arrivée 2 = close broker, validé 90,7 %).
  // Les DEUX sont de vrais points du graphique — l'ancien pipeline les
  // écrivait avec le MÊME horodatage tronqué (t) → ticks "dupliqués" dans
  // candles.jsonl → décisions CALL/PUT inversées par le bruit intra-seconde.
  //
  // Le normaliser réécrit chaque arrivée avec un horodatage SOUS-SECONDE
  // strictement croissant (t, t+0.5, t+0.75, ...) : zéro duplication,
  // fidélité broker conservée (open 98,4 % / high 98,8 % / low 98,4 % /
  // close 100 %), vitesse des ticks restituée en 2 points/seconde.
  // --------------------------------------------------------------------
  if (streamTickNormalizer) {
    try { streamTickNormalizer.destroy(); } catch { /* ignore */ }
  }
  streamTickNormalizer = new StreamTickNormalizer((tick) => {
    // ── ROUTEUR MULTI-ASSETS (§7/§9/§26) ──────────────────────────────
    // Chaque tick EST associé à son asset ; il est traité si et seulement si
    // son asset est SÉLECTIONNÉ — le FOCUS n'est qu'un cas particulier et ne
    // conditionne jamais le traitement des autres assets.
    processAssetTick(io, tick);
    // Tick normalisé diffusé au frontend (forme compatible updateStream).
    io.emit('stream', {
      asset: tick.asset,
      bid: tick.price,
      ask: tick.price,
      time: tick.marketTimeSec,
      normalized: true,
    });
  }, (err) => {
    log(io, 'error', `tick normalizer error: ${err instanceof Error ? err.message : String(err)}`);
  });

  // ──────────────────────────────────────────────────────────────────────
  // Stream de prix temps réel — normalisé anti-duplication (voir ci-dessus)
  // Tunnel A — chaque batch note la fraîcheur du flux MARKET (séquence +
  // lastEventAt propres au tunnel — jamais partagés avec le social).
  client.on('stream', (updates: StreamUpdate[]) => {
    const normalizer = streamTickNormalizer;
    if (!normalizer) return;
    for (const u of updates) {
      if (u && registry.has(u.asset)) session.liveTicksTotal++;
    }
    normalizer.ingestBatch(updates);
  });

  // Tunnel A — RTT du socket market (ping/pong Engine.IO du transport).
  client.on('latency', (sample: { rttMs: number }) => {
  });

  // ──────────────────────────────────────────────────────────────────────
  // v6.10 — SNAPSHOT `updateHistoryNewFast` (HAR fix_gaps.har).
  //
  // Après chaque `changeSymbol`, le broker pousse ~1300-1600 TICKS couvrant
  // ~12 minutes, CONTIGUS avec le flux `updateStream` qui suit. C'est la
  // graine d'historique RAPIDE de CHAQUE asset : avant ce fix, elle était
  // intégralement IGNORÉE (le SDK cherchait un format OHLC inexistant) →
  // les 24 assets multi-assets n'avaient que la pagination lente
  // (loadHistoryPeriod, file de 4) → trou géant [fin historique, début
  // stream] → CRITICAL_GAP → TRADING BLOQUÉ sur toutes les cartes.
  //
  // Désormais : fusion dans le buffer canonique de l'asset → re-seed de
  // TOUS les timeframes → historyReady immédiat (~24 bougies S30 fraîches)
  // → le fetch paginé vient COMPLÉTER la profondeur (1440 bougies) sans
  // jamais créer de couture critique (trou classé couture non bloquante).
  // ──────────────────────────────────────────────────────────────────────
  client.on('history_ticks', (asset: string, _period: number, ticks: HistoryTick[]) => {
    try {
        ingestHistoryFastSnapshot(io, asset, ticks);
    } catch (e: any) {
      log(io, 'error', assetLog(asset, `snapshot updateHistoryNewFast échoué: ${e?.message ?? e}`));
    }
  });

  // ── RECONNEXION (§31) — restaurer les subscriptions des assets sélectionnés.
  //    Après une coupure/ré-authentification, le serveur broker repart avec
  //    ZÉRO subscription : on rétablit TOUTES les subscriptions depuis
  //    tradingMode.assets (source de vérité) via planResubscription.
  client.on('authenticated', async () => {
    // v6.9 — confirmation explicite de la reconnexion broker.
    io.emit('broker-connection', { state: 'connected', ts: Date.now(), server: client.getConnectedServer() });
    // v6 — TUNNELS : reconnexion market → statut immédiat des DEUX tunnels
    // (l'état social est lu en PULL : sidecar en démo, main en réel — la
    // reconnexion du market n'affecte PAS l'état social en démo §14).
    // v6.4 — Stream RECONNECTÉ pour tous les pipelines (§10).
    pipelineManager.setStreamState(true);
    try {
      const subscribed = client.market.getSubscribedAssets();
      const plan = planResubscription(tradingMode.assets, subscribed);
      for (const a of plan.toUnsubscribe) {
        try { client.market.unsubscribe(a); } catch { /* best-effort */ }
      }
      for (const a of plan.toSubscribe) {
        try { client.market.subscribe(a); } catch { /* best-effort */ }
      }
      // v6.5.1 — ré-active les flux updateStream de TOUS les assets
      // (changeSymbol par asset, focus en dernier) : la reconnexion
      // broker repart à zéro flux — un seul changeSymbol(focus)
      // laissait les autres assets sans ticks (STREAM_DISCONNECTED).
      activateSymbolStreams();
      // NOTE v4 : la souscription sociale sto est déjà partie EN TÊTE de ce
      // handler (ordre exact du carnet.har) — pas de second envoi ici. Le
      // handler updateAssets étendra aux actifs ouverts dès leur réception.
      if (plan.toSubscribe.length > 0) {
        log(io, 'info', `[MULTI] reconnexion — ${plan.toSubscribe.length}/${tradingMode.assets.length} asset(s) resubscrit(s): ${plan.toSubscribe.join(', ')}`);
      }
    } catch (e: any) {
      log(io, 'error', `[MULTI] resubscription error: ${e?.message ?? e}`);
    }
  });

  // Chandeliers temps réel (source broker).
  // Fusionnés avec les bougies du CandleBuilder via emitCandleDeduped :
  // les doublons (même asset+période+timestamp) sont éliminés, la bougie en
  // formation appartient au CandleBuilder, les corrections sur bougies
  // clôturées sont acceptées.
  client.on('candles_update', (asset: string, period: number, candles: Candle[]) => {
    // Tunnel A — fraîcheur des bougies broker (clôtures/corrections).
    // MULTI-ASSETS : les candles_update du broker concernent le symbole
    // ACTIF (changeSymbol = focus) mais on accepte TOUT asset sélectionné.
    const ctx = registry.getAssetContext(asset);
    if (ctx) {
      const last = candles[candles.length - 1];
      if (last) {
        emitCandleDeduped(io, {
          asset,
          time: last.time,
          open: last.open,
          high: last.high,
          low: last.low,
          close: last.close,
          volume: last.volume ?? 0,
          active_id: ctx.market.active_id, // active_id DE CET ASSET (§21)
          size: period,
        }, 'broker');
      }
    }
  });

  // Assets — envoie la liste complète au frontend (pas juste le count)
  client.on('assets', (assets: AssetsMap) => {
    const assetList = Object.values(assets).map(a => ({
      id: a.id,
      name: a.name,
      type: a.type,
      payout: a.payout,
      isOtc: a.isOtc,
      longName: a.longName,
      isOpen: a.isOpen,
    }));
    io.emit('assets', { count: assetList.length, list: assetList });
    // ── v20 — AUTO SWITCH ASSETS (nouvelles règles) : chaque poussée
    // updateAssets réévalue « payout asset en cours < 92% ET dernier ordre =
    // GAIN → switch vers un asset payout == 92% ». Fonctionne headless.
    try {
      runPayoutGuard(io, assets);
    } catch (e: any) {
      log(io, 'error', `[AUTO-SWITCH] évaluation impossible: ${e?.message ?? e}`);
    }
    // ── v4 — Extension du flux social : UNIQUEMENT si le flux est MORT ────
    // Principe : ne JAMAIS toucher une souscription qui vit. Si le broker
    // accepte puis remplace la souscription, chaque nouveau sto (grosse liste)
    // est un risque de couper un flux qui marchait. On n'étend donc que si
    // aucun événement brut n'est arrivé depuis > 60 s (ou jamais) — dans ce
    // cas on retente l'échelle COURANTE (qui inclut toujours le focus, cf.
  });

  // ── v20 — AUTO SWITCH : ré-évaluation périodique (10 s) sur le CACHE des
  // payouts. Le broker réel pousse updateAssets régulièrement, mais un gain
  // qui règle JUSTE APRÈS une poussée ne doit pas attendre la poussée
  // suivante (« dès que... et que le dernier ordre est un gain »). Ce timer
  // est adossé à CE client : après un re-login, les anciens intervalles
  // deviennent des no-op silencieuses (session.client !== client).
  {
    const timer = setInterval(() => {
      if (session.client !== client) {
        clearInterval(timer);
        return;
      }
      try {
        const cached = client.market?.getAssets?.();
        if (cached && Object.keys(cached).length > 0) runPayoutGuard(io, cached);
      } catch { /* best effort */ }
    }, 10_000);
    // Libère l'ancien timer s'il existe (un seul actif à la fois).
    if (session.autoSwitchEvalTimer) clearInterval(session.autoSwitchEvalTimer);
    session.autoSwitchEvalTimer = timer;
  }

  // Balance updates
  client.on('balance', (b) => {
    log(io, 'info', `balance update: ${b.balance} (isDemo=${b.isDemo})`);
  });

  // Deal ouvert
  client.on('deal_opened', (deal: OpenedDeal) => {
    // BUG FIX (MULTI-ASSETS) : les réponses updateOpenedDeals / successopenOrder
    // n'incluent PAS le champ `action` (call/put). Le SDK le met à 'call' par
    // défaut. On le surcharge avec la dernière action demandée SUR CET ASSET
    // (ctx.autoTrade.lastTradeAction) — JAMAIS avec celle d'un autre asset
    // (l'ancien override global inversait les directions en multi-assets).
    const openedCtx = registry.getAssetContext(deal.asset);
    if (openedCtx && openedCtx.autoTrade.lastTradeAction && (deal.action === 'call' || deal.action === 'put')) {
      // Only override if we have a recent trade on THIS asset (within last 60s)
      const timeSinceTrade = Date.now() - (openedCtx.autoTrade.lastTradeTs ?? 0);
      if (timeSinceTrade < 60000) {
        deal.action = openedCtx.autoTrade.lastTradeAction;
      }
    } else if (!openedCtx && session.lastTradeAction && (deal.action === 'call' || deal.action === 'put')) {
      // Fallback legacy (asset hors sélection — deal manuel d'un ancien asset)
      const timeSinceTrade = Date.now() - (session.lastTradeTs ?? 0);
      if (timeSinceTrade < 60000) {
        deal.action = session.lastTradeAction;
      }
    }
    // Enregistre le deal dans le contexte de SON asset (§17).
    if (openedCtx) noteDealOpened(openedCtx, deal);
    const brokerTracked = openedCtx?.trackedDeals.get(String(deal.id));
    const brokerExpiry = brokerTracked?.expirationSeconds;
    io.emit('trade-opened', { asset: deal.asset, deal, source: 'broker', expirationSeconds: brokerExpiry, label: 'Ordre broker (ouvert hors Auto Trade)' }); // §21 + libellé v22

    // ----------------------------------------------------------------
    // MANUAL-TRADE CAPTURE (race-condition guard)
    // ----------------------------------------------------------------
    // If a `place-order` call is currently in flight (its await on
    // `openOrder` hasn't resolved yet), the SDK emits `deal_opened`
    // BEFORE the manualDealIds.add() in the place-order handler gets
    // a chance to run. We read the `manualTradePending` flag here
    // and pre-register the deal id as manual so the `deal_closed`
    // handler will skip auto-switch for it. The flag is time-gated
    // (5s) so a stale pending state cannot accidentally mark an
    // unrelated strategy/auto-trade deal as manual.
    // ----------------------------------------------------------------
    if (session.manualTradePending && Date.now() - session.manualTradePendingTs < 5000) {
      session.manualDealIds.add(String(deal.id));
      if (session.manualDealIds.size > 500) {
        const arr = Array.from(session.manualDealIds);
        session.manualDealIds = new Set(arr.slice(-200));
      }
      log(io, 'info', `[MANUAL] deal_opened #${deal.id} captured during place-order await — marked manual (auto-switch DISABLED)`);
    }

    // Évite les doublons
    if (!session.openedDeals.find(d => d.id === deal.id)) {
      session.openedDeals.push(deal);
    } else {
      // Update existing deal with correct action
      const existing = session.openedDeals.find(d => d.id === deal.id);
      if (existing) existing.action = deal.action;
    }
    log(io, 'info', `deal opened: #${deal.id} ${deal.action.toUpperCase()} ${deal.asset} amount=${deal.amount} openPrice=${deal.openPrice}`);
  });

  // Deal clôturé
  client.on('deal_closed', async (deal: ClosedDeal) => {
    // Ignore old deals that were already processed (the server re-sends
    // updateClosedDeals with ALL recent deals on every reconnection/auth).
    // We track seen deal IDs to avoid duplicate processing.
    const dealKey = String(deal.id);

    // SKIP invalid deal IDs (0, NaN, empty) for dedup — but still process for pattern-perf
    const isValidDealId = dealKey !== '0' && dealKey !== 'NaN' && dealKey !== '' && dealKey !== 'null' && dealKey !== 'undefined';

    // WinWin: broker/local expiry placeholders can arrive as deal #0 with no
    // close/profit data. Do not let such placeholders mutate betting state or
    // performance counters. The post-expiry watchdog will refresh real closes.
    // (v17 — plus de verrou sur strategyId : les placeholders sont filtrés par
    // leurs données vides, pas par la stratégie courante, pour rester fiable
    // même si l'utilisateur change de stratégie pendant qu'un trade vole.)
    if (!isValidDealId &&
        Number(deal.profit ?? 0) === 0 && Number(deal.closeTime ?? 0) <= 0) {
      return;
    }

    if (isValidDealId) {
      // MULTI-ASSETS : la clé de dédoublonnage inclut L'ASSET du deal. Le
      // broker (et son cache updateClosedDeals) mélange les règlements de
      // TOUS les assets ; deux assets différents peuvent partager un même id
      // numérique — une clé par id seul rejetait SILENCIEUSEMENT le
      // règlement du second asset, sa Martingale ne doublait donc JAMAIS
      // (« les ordres continuent de s'enchaîner sur la mise de base »).
      const seenKey = `${String(deal.asset ?? '')}|${dealKey}`;
      if (seenClosedDeals.has(seenKey)) return;
      seenClosedDeals.add(seenKey);
      if (seenClosedDeals.size > 500) {
        const arr = Array.from(seenClosedDeals);
        seenClosedDeals.clear();
        arr.slice(-200).forEach(id => seenClosedDeals.add(id));
      }
    }

    // BUG FIX (MULTI-ASSETS §18) : surcharge de deal.action avec la dernière
    // action demandée SUR L'ASSET DE CE DEAL — jamais celle d'un autre asset
    // (l'ancien override global inversait les directions en multi-assets).
    const closedCtx = registry.getAssetContext(deal.asset);
    if (closedCtx && closedCtx.autoTrade.lastTradeAction) {
      const timeSinceTrade = Date.now() - (closedCtx.autoTrade.lastTradeTs ?? 0);
      if (timeSinceTrade < 120000) {  // within 2 minutes (expiry can be up to 60s)
        deal.action = closedCtx.autoTrade.lastTradeAction;
      }
    } else if (!closedCtx && session.lastTradeAction) {
      const timeSinceTrade = Date.now() - (session.lastTradeTs ?? 0);
      if (timeSinceTrade < 120000) {
        deal.action = session.lastTradeAction;
      }
    }

    // IMPORTANT : régler d'abord la mise, puis seulement retirer le miroir
    // de position. Le moteur Martingale doit voir le deal encore suivi.
    // v17 — classification TROIS états du règlement : WIN (P&L > 0) → reset
    // à la mise de base ; LOSS (P&L < 0) → incrément multiplicateur ;
    // PUSH (Tie/Refund, P&L = 0) → état NEUTRE, le niveau de mise courant
    // est conservé pour l'ordre suivant (l'index de la suite de mises ne
    // bouge PAS).
    const settledOutcome = classifySettledOutcome(deal);

    // Retire des openedDeals + du contexte de SON asset (§17/§18) après
    // le règlement Martingale/Fibonacci.
    session.openedDeals = session.openedDeals.filter(d => String(d.id) !== dealKey);
    session.closedDeals.unshift(deal);
    if (session.closedDeals.length > 100) session.closedDeals.pop();
    const win = settledOutcome === 'push' ? 'TIE (remboursé)' : settledOutcome === 'win' ? 'WIN' : 'LOSS';
    if (session.config.strategyId !== 'winwin') {
      log(io, 'info', assetLog(deal.asset ?? '?', `trade result = ${win} (deal #${deal.id}, profit=${deal.profit}, action=${deal.action.toUpperCase()})`));
    }
    io.emit('trade-closed', { asset: deal.asset, deal, isWin: !!deal.isWin, profit: deal.profit ?? 0, outcome: settledOutcome }); // §21

    // v20 — Résultat du DERNIER ordre réglé de la SESSION (tous assets) :
    // le re-login automatique attend un GAIN avant de s'exécuter (un Tie
    // n'est pas un gain → on attend encore).
    session.lastSettledWin = settledOutcome === 'win';
    // v20 — Un GAIN vient d'arriver : si un re-login automatique était
    // reporté en attente de gain, on l'exécute MAINTENANT.
    if (session.reloginDeferredSince > 0 && settledOutcome === 'win' && !session.reloginInProgress) {
      log(io, 'info', '[AUTO-RELOGIN] gain reçu — le re-login reporté peut maintenant s\'exécuter');
      session.reloginDeferredSince = 0;
      if (session.reloginTimer) { clearTimeout(session.reloginTimer); session.reloginTimer = null; }
      void performScheduledRelogin(io);
    }

    // ==========================================================
    // AUTO-TRADE : suivi win/loss + avancement de la stratégie de mise
    // (martingale / fibonacci) — SUR LE CONTEXTE DE L'ASSET DU DEAL
    // UNIQUEMENT (§14/§15/§18/§19 : une perte EURUSD ne touche JAMAIS
    // la Martingale/Fibonacci de XAUUSD ou BTCUSD).
    // ==========================================================
    if (closedCtx) {
      // Cas race : le broker peut fermer un ordre très court avant que le
      // `openOrder()` côté appelant ait reçu son dealId. On rattache alors le
      // résultat au plus ancien ordre auto en vol de CET asset.
      if (!closedCtx.trackedDeals.has(dealKey) && closedCtx.pendingBettingOrders.length > 0) {
        const now = Date.now();
        const idx = closedCtx.pendingBettingOrders.findIndex((p) => now - p.submittedAt <= Math.max(120_000, p.expirationSeconds * 4_000));
        if (idx >= 0) {
          const pending = closedCtx.pendingBettingOrders.splice(idx, 1)[0];
          closedCtx.trackedDeals.set(dealKey, {
            asset: deal.asset,
            amount: pending.amount,
            expirationSeconds: pending.expirationSeconds,
            // Empreinte du règlement lui-même (fill broker du deal fermé) :
            // le rattachement race ci-dessus concerne CE deal, ses prix/horodatages
            // sont donc les nôtres.
            openPrice: Number(deal.openPrice ?? 0) || undefined,
            openTime: Number(deal.openTime ?? 0) || undefined,
            action: (deal.action === 'put' ? 'put' : deal.action === 'call' ? 'call' : pending.action),
            placedAtMs: pending.submittedAt,
          });
          log(io, 'info', assetLog(deal.asset, `deal #${deal.id} rattaché au trade auto en attente (${pending.strategyId}) pour conserver le résultat Martingale/Fibonacci.`));
        }
      }

      let res = applyDealResult(closedCtx, dealKey, settledOutcome);
      /** Clé du tracked deal réellement réglé (dealKey, ou clé rattachée par
       * empreinte) — sert à nettoyer aussi le miroir des positions ouvertes. */
      let resTrackedKey: string | null = res ? dealKey : null;

      // ── RATTACHEMENT PAR EMPREINTE (§17bis — correctif Martingale BOS) ──
      // Le broker réel publie souvent le deal FERMÉ avec un id NUMÉRIQUE
      // différent de l'UUID d'ouverture, et paresseusement (updateClosedDeals).
      // Le deal suivi (UUID) reste alors orphelin et applyDealResult() ne voit
      // rien : le GAIN ne remet JAMAIS consecutiveLosses à zéro (bug « la
      // Martingale ne repart jamais à la mise initiale après un gain »).
      // On rattache donc le règlement à l'ordre suivi de CET asset par son
      // empreinte (fill exact + fenêtre d'ouverture + direction + échéance) —
      // un deal fermé étranger (fantôme du cache broker) ne peut jamais
      // régler notre ordre (mêmes garde-fous que le matcher WinWin v19).
      // Uniquement si le règlement porte de VRAIES données de clôture (les
      // placeholders vides du broker sont ignorés).
      const hasRealCloseData = Number(deal.profit ?? 0) !== 0 || deal.isWin != null || Number(deal.closeTime ?? 0) > 0;
      if (!res && hasRealCloseData) {
        const match = findTrackedDealByFingerprint(closedCtx, {
          id: deal.id,
          asset: String(deal.asset ?? ''),
          amount: Number(deal.amount ?? 0),
          openPrice: Number(deal.openPrice ?? 0),
          closePrice: Number(deal.closePrice ?? 0),
          openTime: Number(deal.openTime ?? 0),
          closeTime: Number(deal.closeTime ?? 0),
          profit: Number(deal.profit ?? 0),
          isWin: deal.isWin == null ? null : !!deal.isWin,
        });
        if (match) {
          res = applyDealResult(closedCtx, match.key, settledOutcome);
          if (res) {
            resTrackedKey = match.key;
            log(io, 'info', assetLog(closedCtx.asset,
              `deal #${deal.id} (id broker ≠ id d'ouverture) rattaché par empreinte à l'ordre suivi #${match.key} — ` +
              `résultat ${outcomeLabel(res.outcome)} appliqué à la Martingale/Fibonacci de ${closedCtx.asset}.`));
          }
        }
      }

      // Le miroir de position est retiré APRES applyDealResult().
      noteDealClosed(closedCtx, dealKey);
      // Le miroir doit aussi disparaître pour l'ordre suivi rattaché (clé
      // d'ouverture) : un deal rattaché par empreinte laisse sinon un doublon
      // de position ouverte qui bloque maxConcurrentPositions.
      if (res && resTrackedKey && resTrackedKey !== dealKey) noteDealClosed(closedCtx, resTrackedKey);
      if (res) {
        if (session.config.strategyId !== 'winwin') {
          log(io, 'info',
            assetLog(closedCtx.asset, `deal #${deal.id} ${outcomeLabel(res.outcome)} — stats ${res.wins}W/${res.losses}L${res.pushes > 0 ? `/${res.pushes}T` : ''} — ` +
            `martingale step = ${closedCtx.betting.consecutiveLosses}, fibIndex = ${closedCtx.betting.fibIndex} — ` +
            `prochaine mise: ${res.nextBetAmount} (${closedCtx.bettingStrategy})`));
        }
        io.emit('auto-trade-status', buildAutoTradeStatus());
      }

      // ── PERFORMANCE DES PATTERNS ───────────────────────────────────────────
      // Associe le résultat WIN/LOSS au trade enregistré à l'ouverture (sur
      // l'ASSET DU DEAL uniquement — jamais un autre asset, §17/§36). Les
      // stats par signature de setup alimentent la journalisation des
      // performances (pattern-performance-logger).
    }

    // ==========================================================
    // PATTERN PERFORMANCE: update only from a broker-confirmed CLOSED deal.
    // WinWin uses the exact broker dealId captured at order placement.
    // Synthetic deal #0/local expiry events are ignored here.
    // ==========================================================
    if (isValidDealId && session.pendingPatternTrades.size > 0) {
      let matchedTradeId: string | null = null;
      let matchedInfo: any = null;

      // 1) Exact broker dealId match (preferred, deterministic).
      for (const [tradeId, info] of session.pendingPatternTrades) {
        if (info.dealId && String(info.dealId) === dealKey) {
          matchedTradeId = tradeId;
          matchedInfo = info;
          break;
        }
      }

      // 2) Fallback temporel si l'id exact n'a pas été capturé.
      if (!matchedTradeId) {
        const dealTime = deal.openTime ? deal.openTime * 1000 : Date.now();
        let bestTimeDiff = Infinity;
        for (const [tradeId, info] of session.pendingPatternTrades) {
          if ((info as any).asset && (info as any).asset !== (deal.asset ?? '')) continue;
          const timeDiff = Math.abs(info.timestamp - dealTime);
          if (timeDiff < bestTimeDiff) {
            bestTimeDiff = timeDiff;
            matchedTradeId = tradeId;
            matchedInfo = info;
          }
        }
        if (matchedTradeId && bestTimeDiff >= 120000) {
          matchedTradeId = null;
          matchedInfo = null;
        }
      }

      if (matchedTradeId) {
        updatePatternTradeResult(
          matchedTradeId,
          matchedInfo?.patternId ?? null,
          dealKey,
          !!deal.isWin,
          Number(deal.profit ?? 0),
        );
        session.pendingPatternTrades.delete(matchedTradeId);
      }

      // Expiration honnête : un trade sans confirmation broker après 2 min
      // est marqué expiré (jamais converti en LOSS).
      {
        const nowMs = Date.now();
        for (const [tid, info] of session.pendingPatternTrades) {
          if (nowMs - info.timestamp > 120000) {
            updatePatternTradeResult(tid, info.patternId, 'expired', false, -1);
            session.pendingPatternTrades.delete(tid);
          }
        }
      }

      io.emit('pattern-performance', {
        stats: getAllPatternStats(),
        recentTrades: getRecentPatternTrades(20),
      });
    }

    // ==========================================================
    // v20 — AUTO-SWITCH après chaque trade : SUPPRIMÉ.
    // Nouvelles règles Auto Switch Assets (payout < 92% + dernier ordre =
    // GAIN → asset payout == 92%) : évaluées sur chaque poussée updateAssets
    // par runPayoutGuard, pas à la clôture d'un trade.
    // ==========================================================
    if (isValidDealId) {
      const tradedAsset = String(deal.asset ?? '').trim();
      if (tradedAsset && !registry.has(tradedAsset)) {
        log(io, 'info', `[ASSET-SWITCH] trade #${deal.id} asset=${tradedAsset} non sélectionné — ignoré`);
      }
    }

    // ==========================================================
    // RISK MANAGER: Record trade result (only if risk management is enabled)
    // ==========================================================
    if (riskManager && (session.config.riskManagementEnabled ?? false)) {
      riskManager.recordTrade(deal.isWin, deal.profit ?? 0);
      const rs = riskManager.getState();
      log(io, 'info', `[RISK] ${rs.winsToday}W/${rs.lossesToday}L today, streak ${rs.consecutiveWins}W/${rs.consecutiveLosses}L, balance=${rs.balance.toFixed(2)}`);
      if (rs.isPaused) {
        log(io, 'warning', `[RISK] PAUSED: ${rs.pauseReason}`);
        io.emit('auto-trade-stopped', { reason: rs.pauseReason, balance: rs.balance });
      }
    }

    io.emit('deal-closed', deal);
  });

  // Order result
  client.on('order_result', (result) => {
    io.emit('order-placed', {
      success: result.success,
      requestId: result.requestId,
      deal: result.deal,
      error: result.error,
    });
  });

  // Errors
  client.on('error', (err: Error) => {
    log(io, 'error', `client error: ${err.message}`);
  });

  client.on('auth_failed', (err: Error) => {
    log(io, 'error', `auth failed: ${err.message}`);
  });

  client.on('disconnected', (reason: string) => {
    log(io, 'warning', `websocket disconnected: ${reason} — auto-reconnect broker activé`);
    // v6.9 — expose explicitement l'état de reconnexion au frontend.
    io.emit('broker-connection', { state: 'reconnecting', reason, ts: Date.now() });
    // v6.4 — Stream DÉCONNECTÉ pour tous les pipelines (§10 → score 5,
    // statut DISCONNECTED, trading BLOQUÉ jusqu'à reconnexion + recovery).
    pipelineManager.setStreamState(false);
    log(io, 'warning', formatStructuredLog('MARKET-DATA', {
      event: 'STREAM_DISCONNECTED',
      pipelines: pipelineManager.size,
      reason,
    }));
  });
}

// ─────────────────────────────────────────────────────────────────────────────
//  SÉLECTION DES ASSETS — application de la source de vérité (§4)
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Applique une sélection d'assets VALIDÉE (validateAssetSelection) :
 *
 *   1. Désabonne + supprime les contextes des assets RETIRÉS (§30) :
 *      - arrêt de leur Auto Trade ;
 *      - suppression de leur contexte (moteurs libérés) ;
 *      - purge de leurs séries du synchroniseur + listeners spécifiques.
 *   2. CONSERVE les contextes des assets déjà sélectionnés (leurs états de
 *      mise Martingale/Fibonacci/stats/positions NE SONT PAS réinitialisés —
 *      ajouter/retirer un asset ne doit pas réinitialiser les autres).
 *   3. Crée les contextes des NOUVEAUX assets + subscribe broker.
 *   4. Focus = premier asset ; changeSymbol sur le focus (le broker ne
 *      pousse candles_update que pour un symbole — les autres assets sont
 *      alimentés par leurs ticks updateStream, §7).
 *   5. Historiques : fetch léger par asset (fetchAndBroadcastHistory) ;
 *      cache 90 j + recorder JSONL UNIQUEMENT pour l'asset primaire (§27).
 */
function applyAssetSelection(io: Server, mode: 'single' | 'multi', assets: string[]): void {
  if (!session.client) return;
  const prevAssets = [...tradingMode.assets];
  const nextAssets = [...new Set(assets)]; // re-dédupliqué côté serveur (§3)
  const nextSet = new Set(nextAssets);

  // 1. Assets retirés → arrêt propre (§30).
  for (const asset of prevAssets) {
    if (nextSet.has(asset)) continue;
    try { session.client.market.unsubscribe(asset); } catch { /* best-effort */ }
    registry.removeAssetContext(asset);     // auto-trade off + deals + instances libérés
    candleSync.purgeAsset(asset);           // séries + buffer de ticks libérés
    pipelineManager.remove(asset);          // v6.4 — pipeline + santé libérés
    assetTickStats.delete(asset);
    healthEmitTs.delete(asset);
    log(io, 'info', assetLog(asset, 'arrêté — contexte supprimé, abonnements arrêtés (§30)'));
  }

  // 2/3. Assets conservés + nouveaux.
  let firstNewAsset: string | null = null;
  for (const asset of nextAssets) {
    if (!registry.has(asset)) {
      const market = getMarket(asset);
      registry.ensureAssetContext(asset, {
        market,
        bettingStrategy: session.config.bettingStrategy ?? 'fixed',
        baseAmount: parseFloat(session.config.margin) || 1,
        maxMartingaleSteps: clampMaxMartingaleSteps(session.config.maxMartingaleSteps),
        autoTradeEnabled: session.config.autoTradeEnabled && session.config.autoOpen,
      });
      session.client.market.subscribe(asset);
      if (!firstNewAsset) firstNewAsset = asset;
      log(io, 'info', assetLog(asset, `contexte créé — pipeline dédié (mode ${mode})`));
    }
  }

  // 4. Source de vérité + focus.
  tradingMode.mode = mode;
  tradingMode.assets = nextAssets;
  const focus = tradingMode.focus && nextSet.has(tradingMode.focus)
    ? tradingMode.focus                    // focus conservé s'il reste sélectionné
    : nextAssets[0];
  tradingMode.focus = focus;
  session.market = registry.getAssetContext(focus)?.market ?? getMarket(focus);
  session.config.market = focus;
  candleSync.setActiveAssets(nextAssets, session.config.candleSize ?? 30, focus);

  // CRITIQUE : les pipelines doivent exister AVANT activateSymbolStreams().
  // changeSymbol() peut faire parvenir updateHistoryNewFast immédiatement ;
  // sans pipeline pré-créé, la graine fast est reçue puis perdue pour la
  // santé marché (candles=0/HISTORY_NOT_READY).
  ensurePipelinesForSelection();

  // v6.5.1 — flux live pour TOUS les assets sélectionnés (focus en dernier).
  activateSymbolStreams();
  log(io, 'info', formatStructuredLog('ASSET-PIPELINE', {
    event: 'SELECTION_APPLIED',
    assets: nextAssets.length,
    pipelines: pipelineManager.size,
    focus,
  }));

  // ── AUTO TRADE : jamais armé implicitement après sélection ─────────
  // La sélection initialise uniquement les flux/pipelines. L'utilisateur
  // doit actionner explicitement le master-switch Auto Trade ou une carte.
  if (nextAssets.length > 0 && prevAssets.length === 0) {
    // Uniquement au premier chargement de workspace : une sélection de
    // remplacement/switch ne doit jamais couper SMART (ou une autre
    // stratégie) déjà active.
    session.config.autoTradeEnabled = false;
    for (const asset of nextAssets) {
      const ctx = registry.getAssetContext(asset);
      if (ctx) ctx.autoTrade.enabled = false;
    }
    log(io, 'info', formatStructuredLog('AUTO-TRADE', {
      event: 'INITIAL_ACTIVATION_REQUIRES_USER_TOGGLE',
      reason: 'first-asset-selection-only',
      assets: nextAssets.length,
    }));
    io.emit('auto-trade-status', buildAutoTradeStatus());
  }

  // 5. Historiques — v6.5.1 : TOUS les nouveaux assets (PRIMAIRE INCLU)
  //    passent par le fetch léger du timeframe courant (§27), via FILE À
  //    CONCURRENCE LIMITÉE (4 fetchs parallèles max — rapide SANS tempête
  //    de requêtes broker).
  //    AVANT (bug v6.5) : l'asset primaire était EXCLU de la file avec le
  //    commentaire « géré ci-dessous »… mais le code ci-dessous ne
  //    déclenchait AUCUN fetch pour lui (seul le recorder JSONL était créé)
  //    → l'asset focus restait HISTORY_NOT_READY à vie (jamais tradable).
  //    Le cache lourd 90 j reste réservé au mode mono (select-market §27).
  const primary = nextAssets[0];
  const firstSelection = prevAssets.length === 0;
  const primaryIsNew = !prevAssets.includes(primary);
  const historyTasks: Array<() => Promise<void>> = [];
  for (const asset of nextAssets) {
    const isNew = !prevAssets.includes(asset);
    if (!isNew) continue;                          // déjà sélectionné : rien à refaire
    historyTasks.push(async () => {
      await fetchAndBroadcastHistory(
        io, asset, session.config.candleSize ?? 30, session.config.historyCount ?? 300, 'select-assets',
      );
    });
  }
  if (historyTasks.length > 0) {
    runWithConcurrency(historyTasks, HISTORY_FETCH_CONCURRENCY)
      .catch(() => { /* best-effort */ });
  }
  if (firstSelection || primaryIsNew || !primaryCacheAsset) {
    // Init cache lourd 90 j pour l'asset primaire UNIQUEMENT (§27).
    // Candle Tick Recorder (JSONL) — asset primaire uniquement (§27).
    if (candleTickRecorder) candleTickRecorder.stop();
    candleTickRecorder = new CandleTickRecorder(primary, session.config.candleSize ?? 30, {
      log: (m) => log(io, 'info', m),
      // Déclenche l'évaluation BOS EXACTEMENT à la clôture de chaque bougie de
      // l'asset enregistré (la ligne candle fermée vient d'être écrite avec
      // son close exact). Les autres assets sont évalués via le callback
      // onCandleClosed du CandleSyncManager (chemin uniforme multi-assets).
      onCandleClosed: () => { /* L_Lucien ProTrader est évalué par la boucle de polling */ },
    });
    recorderAsset = primary;
    log(io, 'info', `[TICK-RECORDER] Recording to .logs/candles.jsonl (asset primaire ${primary}, temps réel, ticks normalisés anti-duplication)`);
  }

  // 6. Reset complet UNIQUEMENT à la première sélection (contextes vierges) :
  //    les états Martingale/Fibonacci des assets conservés sont préservés.
  if (prevAssets.length === 0) {
    session.closeWindow = [];
  }

  log(io, 'info',
    `[MULTI] sélection active — mode=${mode}, ${nextAssets.length} asset(s): ${nextAssets.join(', ')} (focus: ${focus})`);
  io.emit('auto-trade-status', buildAutoTradeStatus());

}

/** Supprime TOUTE la sélection d'assets (logout / nouveau login). */

const AUTOMATIC_RELOGIN_MS = 60 * 60 * 1000; // v21 — re-login automatique toutes les 1 HEURES de programme
/** v20 — Intervalle de re-contrôle quand le re-login attend un gain. */
const RELOGIN_WAIT_RETRY_MS = 15 * 1000;

/**
 * v20/v21 — Verrou « dernier ordre = gain » du re-login automatique :
 *   - un ordre en vol → on attend TOUJOURS sa clôture ;
 *   - dernier ordre réglé de la session = perte ou Tie → on attend le gain ;
 *   - aucun ordre réglé → re-login autorisé immédiatement.
 * v21 — règle STRICTE : le re-login ne s'exécute JAMAIS tant que ces deux
 * conditions ne sont pas réunies (plus de garde-fou temporel qui exécutait
 * quand même après 10 min — le réveil immédiat au gain garantit la sortie
 * d'attente dès qu'un gain est réglé).
 * Retourne la raison du blocage ('' = autorisé).
 */
function reloginBlockReason(): string {
  if (session.openedDeals.length > 0) {
    return `${session.openedDeals.length} ordre(s) en cours (attente de clôture)`;
  }
  if (session.lastSettledWin === false) {
    return 'le dernier ordre réglé n\'est pas un gain (attente du prochain GAIN)';
  }
  return '';
}

async function performScheduledRelogin(io: Server): Promise<void> {
  if (session.reloginInProgress || !session.client || !session.credentials) return;

  // v21 — AVANT tout re-login automatique (toutes les 1 h de programme) : on
  // vérifie qu'AUCUN ordre n'est placé en cours ET que le dernier ordre réglé
  // est un GAIN. Sinon on ATTEND (retry 15 s ; réveil immédiat dès qu'un gain
  // est réglé). AUCUNE exception — règle utilisateur stricte.
  const blockReason = reloginBlockReason();
  if (blockReason !== '') {
    if (session.reloginDeferredSince === 0) session.reloginDeferredSince = Date.now();
    const waitedMs = Date.now() - session.reloginDeferredSince;
    log(io, 'warning',
      `[AUTO-RELOGIN] reporté (${blockReason})${waitedMs > 0 ? ` — en attente depuis ${Math.round(waitedMs / 1000)}s` : ''} — nouvelle vérification dans ${Math.round(RELOGIN_WAIT_RETRY_MS / 1000)}s`);
    if (session.reloginTimer) clearTimeout(session.reloginTimer);
    session.reloginTimer = setTimeout(() => {
      session.reloginTimer = null;
      void performScheduledRelogin(io);
    }, RELOGIN_WAIT_RETRY_MS);
    return;
  }
  session.reloginDeferredSince = 0;

  session.reloginInProgress = true;
  const savedBeforeReconnect = buildSessionSnapshot();
  await savePersistedSession(SESSION_SNAPSHOT_PATH, savedBeforeReconnect);
  const wasStrategyRunning = session.strategyRunning;
  const previousAssets = [...tradingMode.assets];
  const previousFocus = tradingMode.focus;
  log(io, 'warning', `[AUTO-RELOGIN] 1 h de programme atteinte — sauvegarde complète + reconnexion broker (assets=${previousAssets.join(',') || 'none'}, focus=${previousFocus || 'none'}, autoTrade=${session.config.autoTradeEnabled ? 'ON' : 'OFF'})`);
  io.emit('session-refresh', { phase: 'start', reason: 'scheduled-relogin', at: Date.now() });
  if (session.strategyRunning) stopStrategyLoop(io);
  try {
    if (session.client) { try { session.client.destroy(); } catch { /* best effort */ } }
    const creds = session.credentials;
    const client = new PocketOptionClient({
      credentials: { email: creds.email, password: creds.password },
      mode: creds.mode,
      region: 'eu', debug: false, authTimeout: 30000,
    });
    attachClientHandlers(client, io);
    session.client = client;
    session.mode = creds.mode;
    const sessionData: SessionData = await client.connect();
    session.credentials = creds;
    session.startedAt = Date.now();
    session.lastTradeTs = Date.now();
    session.liveTradeIds.clear();
    session.seenClosedDealFingerprints.clear();

    // Rebuild the exact prior selection with Auto Trade temporarily DISARMED.
    // restoreSessionSnapshot preserves the complete configuration and prepares
    // the exact asset set; only after fresh history has arrived do we resume.
    clearAssetSelection('scheduled-relogin');
    restoreSessionSnapshot(io, savedBeforeReconnect, true);
    tradingMode.focus = savedBeforeReconnect.focus && tradingMode.assets.includes(savedBeforeReconnect.focus)
      ? savedBeforeReconnect.focus : tradingMode.focus;
    session.market = registry.getAssetContext(tradingMode.focus ?? '')?.market ?? getMarket(tradingMode.focus ?? '');
    session.config.market = tradingMode.focus ?? session.config.market;
    const size = session.config.candleSize ?? 30;
    const selected = [...tradingMode.assets];
    // Mandatory fresh candle history for every selected asset. Bounded to 100.
    await runWithConcurrency(selected.map((asset) => async () => {
      await fetchAndBroadcastHistory(io, asset, size, Math.min(100, session.config.historyCount ?? 100), 'scheduled-relogin-refresh');
    }), 2);

    // Only now re-arm the saved Auto Trade state.
    session.config.autoTradeEnabled = savedBeforeReconnect.config.autoTradeEnabled !== false;
    for (const [, ctx] of registry.entries()) {
      ctx.autoTrade.enabled = session.config.autoTradeEnabled && session.config.autoOpen;
    }
    if (wasStrategyRunning || session.config.autoTradeEnabled) startStrategyLoop(io);
    // v20 — les nouvelles règles Auto Switch sont pilotées par les poussées
    // updateAssets (runPayoutGuard sur client.on('assets')) : plus de timer
    // idle à réarmer après le re-login.
    io.emit('login-result', { ok: true, user_id: sessionData.uid, mode: creds.mode, resumed: true, reason: 'scheduled-relogin' });
    io.emit('assets-selected', { ok: true, mode: tradingMode.mode, assets: [...tradingMode.assets], focus: tradingMode.focus, restored: true, reason: 'scheduled-relogin' });
    io.emit('auto-trade-status', buildAutoTradeStatus());
    io.emit('status', buildStatusPayload());
    io.emit('session-refresh', { phase: 'complete', reason: 'scheduled-relogin', at: Date.now() });
    // v21 — REFRESH OBLIGATOIRE DU FRONTEND à chaque Re-Login : la page est
    // rechargée intégralement (window.location.reload) pour reconstruire
    // graphique/historique sur la session reconnectée. Le backend ci-dessus
    // a déjà tout réinitialisé (client, contextes, historiques).
    io.emit('force-frontend-refresh', { reason: 'relogin', detail: 'scheduled-relogin', at: Date.now() });
    log(io, 'info', `[AUTO-RELOGIN] complete — session resumed (${selectedForLog(previousAssets)}, autoTrade=${session.config.autoTradeEnabled ? 'ON' : 'OFF'}) — refresh frontend demandé`);
  } catch (e: any) {
    log(io, 'error', `[AUTO-RELOGIN] failed: ${e?.message ?? e}`);
    io.emit('session-refresh', { phase: 'error', reason: 'scheduled-relogin', error: e?.message ?? String(e), at: Date.now() });
  } finally {
    session.reloginInProgress = false;
    session.reloginDeferredSince = 0; // v20 — le cycle de re-login est terminé
    scheduleAutomaticRelogin(io);
  }
}

function selectedForLog(assets: string[]): string { return assets.join(', ') || 'none'; }

// --------------------------------------------------------------------------
//  v21 — DÉMARRAGE DU PROGRAMME : sélection ALÉATOIRE d'un asset 92 %
// --------------------------------------------------------------------------
/**
 * Demande utilisateur (v21) :
 *   « Retire cette règle EURUSD_otc codée en dur par défaut. Dorénavant, au
 *     démarrage du programme, un asset avec profit 92 % est sélectionné au
 *     hasard. »
 *
 * Conditions d'exécution (login SANS session restaurée — backend neuf) :
 *   - aucun asset sélectionné (tradingMode.assets vide) à CHAQUE tentative ;
 *   - candidats = assets du broker avec payout == 92 % EXACTEMENT (même
 *     tolérance que l'Auto Switch) et marché OUVERT ;
 *   - sélection ALÉATOIRE uniforme parmi les candidats ;
 *   - dédouanée de toute préférence : le switch « Stay on Forex OTC Only » ne
 *     contraint QUE l'Auto Switch (règle utilisateur) — au démarrage, TOUS les
 *     assets 92 % sont éligibles.
 *
 * La carte des payouts arrive via updateAssets juste après l'authentification :
 * on réessaie pendant ~60 s (toutes les 2 s) si elle n'est pas encore là.
 * Désactivable pour les tests E2E via PO_STARTUP_RANDOM_ASSET=0.
 */
async function ensureStartupAssetSelection(io: Server): Promise<void> {
  if (process.env.PO_STARTUP_RANDOM_ASSET === '0') {
    log(io, 'info', '[STARTUP] sélection aléatoire 92 % DÉSACTIVÉE (PO_STARTUP_RANDOM_ASSET=0)');
    return;
  }
  const startedAt = Date.now();
  for (let attempt = 0; attempt < 30; attempt++) {
    // Une sélection est arrivée entre-temps (restauration, choix manuel…) :
    // la sélection aléatoire n'écrase JAMAIS un choix existant.
    if (tradingMode.assets.length > 0) return;
    if (!session.client || !session.credentials) return;
    let candidates: string[] = [];
    try {
      const assetsMap = (session.client as any).market?.getAssets?.() as
        Record<string, { name?: string; payout?: number | null; isOpen?: boolean }> | undefined;
      if (assetsMap && Object.keys(assetsMap).length > 0) {
        candidates = Object.values(assetsMap)
          .map((a) => ({
            name: String(a?.name ?? '').trim(),
            payout: typeof a?.payout === 'number' ? a.payout : null,
            isOpen: a?.isOpen,
          }))
          .filter((a) => a.name && a.payout != null && isPayoutTarget(a.payout) && a.isOpen !== false)
          .map((a) => a.name);
      }
    } catch { /* carte des payouts pas encore disponible */ }
    if (candidates.length > 0) {
      const pick = candidates[Math.floor(Math.random() * candidates.length)];
      applyAssetSelection(io, 'single', [pick]);
      saveSessionSnapshot();
      const payout = (() => {
        try {
          const map = (session.client as any).market?.getAssets?.() as Record<string, any> | undefined;
          const found = Object.values(map ?? {}).find((a) => String(a?.name ?? '') === pick);
          return typeof found?.payout === 'number' ? found.payout : 92;
        } catch { return 92; }
      })();
      log(io, 'info',
        `[STARTUP] asset sélectionné ALÉATOIREMENT parmi ${candidates.length} asset(s) à profit 92 % : ${pick} (${payout} %) — plus d'asset par défaut codé en dur`);
      io.emit('assets-selected', {
        ok: true,
        mode: tradingMode.mode,
        assets: [...tradingMode.assets],
        focus: tradingMode.focus,
        reason: 'startup-random-92',
      });
      return;
    }
    await new Promise((r) => setTimeout(r, 2000));
    if (Date.now() - startedAt > 60_000) break;
  }
  log(io, 'warning',
    '[STARTUP] aucun asset à profit 92 % disponible (ou carte des payouts absente) — aucune sélection automatique ; l\'utilisateur choisit manuellement');
}

function scheduleAutomaticRelogin(io: Server): void {
  if (session.reloginTimer) clearTimeout(session.reloginTimer);
  if (!session.credentials) return;
  session.startedAt = Date.now();
  session.reloginDeferredSince = 0;
  session.reloginTimer = setTimeout(() => {
    session.reloginTimer = null;
    void performScheduledRelogin(io);
  }, AUTOMATIC_RELOGIN_MS);
  log(io, 'info', `[AUTO-RELOGIN] programmé dans 1 h (${new Date(Date.now() + AUTOMATIC_RELOGIN_MS).toISOString()}) — exécution uniquement si aucun ordre en cours et dernier ordre = GAIN`);
}

function clearAssetSelection(reason: string): void {
  for (const asset of [...tradingMode.assets]) {
    registry.removeAssetContext(asset);   // §30 — arrêt propre de chaque asset
    candleSync.purgeAsset(asset);
  }
  tradingMode.mode = 'single';
  tradingMode.assets = [];
  tradingMode.focus = null;
  session.market = null;
  session.openedDeals = [];
  assetTickStats.clear();
  historyFetchStates.clear();
  gapRepairStates.clear();
  primaryCacheAsset = null;
  recorderAsset = null;
  if (candleTickRecorder) {
    try { candleTickRecorder.stop(); } catch { /* ignore */ }
    candleTickRecorder = null;
  }
  if (reason) console.log(`[MULTI] sélection réinitialisée (${reason})`);
}

// --------------------------------------------------------------------------
//  Socket.io server
// --------------------------------------------------------------------------

const httpServer = createServer();
// NOTE v4 : pas de handler HTTP ici — Socket.IO est attaché avec path:'/' et
// engine.io intercepte TOUTES les requêtes HTTP du port 3030 (réponse
// « Transport unknown »). Le diagnostic /social-debug vit donc sur son
// PROPRE mini-serveur (port 3031, cf. socialDebugServer en fin de fichier).
const io = new Server(httpServer, {
  path: '/',
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000,
});

// Branche le journal [SYNC] du synchroniseur sur les logs socket (§19) —
// tous les événements de synchronisation (fusion, trous, réponses obsolètes,
// réparations) deviennent visibles dans le panneau de logs du frontend.
syncLogSink = (level, message) => log(io, level, message);

io.on('connection', (socket) => {
  console.log(`[socket] connected: ${socket.id}`);

  // ----- login -----
  // NOUVEAU FLUX (§1) : LOGIN → AUTHENTIFICATION RÉUSSIE → le frontend
  // affiche AssetSelectionScreen → l'utilisateur envoie 'select-assets'
  // → applyAssetSelection crée les contextes et lance le trading.
  // Le login n'instancie PLUS aucun moteur lié au marché (plus de marché
  // par défaut implicite) — c'est la sélection de l'utilisateur qui décide.
  socket.on('login', async (data: { email: string; password: string; mode?: AccountMode }) => {
    try {
      const mode: AccountMode = data.mode ?? 'demo';

      // ── v6.3 — LOGIN IDEMPOTENT (REPRISE DE SESSION) ─────────────────────
      // Si le backend tourne DÉJÀ avec les MÊMES identifiants (frontend fermé
      // puis rouvert, onglet rechargé, Chrome redémarré…), on NE DÉTRUIT PAS
      // la session en cours : les contextes par asset, les positions ouvertes,
      // l'auto-trade et les Martingale/Fibonacci ISOLÉES continuent — on
      // renvoie simplement TOUT l'état au frontend fraîchement reconnecté.
      const clientState = session.client?.getState?.();
      if (
        session.client &&
        session.credentials &&
        session.credentials.email === data.email &&
        session.credentials.password === data.password &&
        session.credentials.mode === mode &&
        (clientState === 'authenticated' || clientState === 'connected') &&
        tradingMode.assets.length > 0
      ) {
        session.resumedOnce = true;
        log(io, 'info',
          `login idempotent — session REPRISE telle quelle (${registry.size} asset(s) actif(s), ` +
          `auto-trade=${session.config.autoTradeEnabled ? 'ON' : 'OFF'}, ${session.openedDeals.length} position(s) ouverte(s)) — ` +
          `rien n'a été réinitialisé`);
        socket.emit('login-result', {
          ok: true,
          user_id: session.client.getSession()?.uid ?? null,
          mode,
          resumed: true,
        });
        socket.emit('assets-selected', {
          ok: true,
          mode: tradingMode.mode,
          assets: [...tradingMode.assets],
          focus: tradingMode.focus,
          restored: true,
        });
        socket.emit('auto-trade-status', buildAutoTradeStatus());
        scheduleAutomaticRelogin(io);
        // v20 — Auto Switch : plus de timer idle — les règles payout < 92% +
        // dernier ordre GAIN s'exécutent sur les poussées updateAssets.
        socket.emit('payout-guard-status', payoutGuardSummary(payoutGuard.state, payoutGuard.config));
        socket.emit('status', buildStatusPayload());
        return;
      }

      // ── Nouvelle session (identifiants différents OU backend fraîchement
      //    démarré) : connexion broker + RESTAURATION de la session persistée.
      // v5 — le sidecar social de la session précédente est arrêté (il sera
      // redémarré ci-dessous si le nouveau mode est démo).
      if (session.client) {
        try { session.client.destroy(); } catch { /* ignore */ }
      }
      session.mode = mode;
      // v21 — PLUS de fallback 'EURUSD_otc' (règle codée en dur RETIRÉE sur
      // demande utilisateur) : la sélection d'asset vient soit de la session
      // restaurée, soit du choix manuel de l'utilisateur, soit de la sélection
      // ALÉATOIRE d'un asset payout 92 % au démarrage (ensureStartupAssetSelection).
      session.resumedOnce = false;

      const client = new PocketOptionClient({
        credentials: { email: data.email, password: data.password },
        mode,
        region: 'eu',
        debug: false,
        authTimeout: 30000,
      });
      attachClientHandlers(client, io);
      session.client = client;

      log(io, 'info', `logging in as ${data.email} (mode=${mode})`);
      const sessionData: SessionData = await client.connect();
      log(io, 'info', `authenticated: uid=${sessionData.uid} server=${client.getConnectedServer()} demoBalance=${sessionData.demoBalance} ${sessionData.currency}`);

      // v6.3 — Mémorise les identifiants (EN MÉMOIRE UNIQUEMENT) pour les
      // logins idempotents suivants. JAMAIS persistés sur disque.
      session.credentials = { email: data.email, password: data.password, mode };

      // Nettoie TOUT état de marché de la session précédente (nouveaux
      // credentials = nouvelle session de trading ; la sélection d'assets
      // précédente est invalidée).
      clearAssetSelection('login');

      socket.emit('login-result', { ok: true, user_id: sessionData.uid, mode });
      scheduleAutomaticRelogin(io);

      // ── v6.3 — RESTAURATION de la session persistée (data/backend-session.json).
      //    Après un redémarrage du BACKEND (pas seulement du frontend), la
      //    sélection d'assets + la config auto-trade sont réappliquées : le
      //    programme reprend là où il s'était arrêté.
      const saved = await loadPersistedSession(SESSION_SNAPSHOT_PATH);
      if (saved && saved.assets.length > 0) {
        restoreSessionSnapshot(io, saved);
        socket.emit('assets-selected', {
          ok: true,
          mode: tradingMode.mode,
          assets: [...tradingMode.assets],
          focus: tradingMode.focus,
          restored: true,
        });
      }
      // v21 — DÉMARRAGE DU PROGRAMME sans asset à restaurer (backend neuf,
      // snapshot absent/corrompu) : sélection ALÉATOIRE d'un asset avec
      // profit 92 %. L'ancien défaut codé en dur EURUSD_otc est RETIRÉ —
      // aucune règle d'asset par défaut n'existe désormais.
      if (tradingMode.assets.length === 0) {
        void ensureStartupAssetSelection(io);
      }
      // v20 — Auto Switch : plus de timer idle à armer (règles pilotées par
      // les poussées updateAssets via runPayoutGuard).

      // Broadcast léger du statut (1 Hz). Les calculs lourds restent événementiels
      // sur les clôtures de bougies; aucune reconstruction de pipeline n'est faite
      if (session.statusBroadcastTimer) clearInterval(session.statusBroadcastTimer);
      session.statusBroadcastTimer = setInterval(() => {
        io.emit('status', buildStatusPayload());
      }, 1000);

      // v6.3 — Heartbeat headless : preuve de vie toutes les 60 s, même sans
      // frontend connecté (le trading continue après fermeture de Chrome).
      startBackendHeartbeat(io);

      // Diffuse l'état auto-trade complet au frontend fraîchement connecté.
      io.emit('auto-trade-status', buildAutoTradeStatus());
      io.emit('payout-guard-status', payoutGuardSummary(payoutGuard.state, payoutGuard.config));
    } catch (e: any) {
      log(io, 'error', `login error: ${e.message}`);
      socket.emit('login-result', { ok: false, error: e.message });
    }
  });

  // ----- select-assets (§1/§2/§3 — NOUVEAU FLUX MULTI-ASSETS) -----
  // Reçoit { mode: 'single' | 'multi', assets: string[] } depuis
  // AssetSelectionScreen. VALIDATION BACKEND OBLIGATOIRE (§3) :
  //   1 <= assets.length <= 24 (v6.3) · doublons supprimés · mode cohérent.
  // Ne JAMAIS faire confiance au frontend seul.
  socket.on('select-assets', async (data: { mode?: unknown; assets?: unknown }) => {
    if (!session.client) {
      socket.emit('assets-selected', { ok: false, error: 'not logged in', mode: 'single', assets: [], focus: null });
      return;
    }
    const validation = validateAssetSelection(data);
    if (!validation.ok) {
      log(io, 'warning', `[MULTI] sélection rejetée : ${validation.error}`);
      socket.emit('assets-selected', {
        ok: false,
        error: validation.error,
        mode: tradingMode.mode,
        assets: [...tradingMode.assets],
        focus: tradingMode.focus,
      });
      return;
    }
    applyAssetSelection(io, validation.mode, validation.assets);
    log(io, 'info',
      `[MULTI] sélection VALIDÉE — mode=${validation.mode}, ${validation.assets.length} asset(s): ` +
      `${validation.assets.join(', ')}${validation.deduped ? ' (doublons supprimés)' : ''}`);
    saveSessionSnapshot(); // v6.3 — persistance (reprise après redémarrage)
    io.emit('assets-selected', {
      ok: true,
      mode: tradingMode.mode,
      assets: [...tradingMode.assets],
      focus: tradingMode.focus,
    });
  });

  // ----- switch-asset (§ multi : remplace UN asset par un autre) -----
  socket.on('switch-asset', async (data: { from: string; to: string }) => {
    if (!session.client) return;
    const from = String(data?.from ?? '');
    const to = String(data?.to ?? '').trim();
    if (!from || !to || !registry.has(from)) return;
    if (registry.has(to) && to !== from) {
      log(io, 'warning', `[MULTI] switch-asset : ${to} est déjà sélectionné`);
      socket.emit('assets-selected', { ok: false, error: `${to} déjà sélectionné`, mode: tradingMode.mode, assets: [...tradingMode.assets], focus: tradingMode.focus });
      return;
    }
    // Remplace en conservant la POSITION dans la liste.
    const nextAssets = tradingMode.assets.map(a => a === from ? to : a);
    applyAssetSelection(io, tradingMode.mode, nextAssets);
    log(io, 'info', `[MULTI] asset remplacé : ${from} → ${to}`);
    saveSessionSnapshot(); // v6.3 — persistance
    io.emit('assets-selected', { ok: true, mode: tradingMode.mode, assets: [...tradingMode.assets], focus: tradingMode.focus });
  });

  // ----- add-asset (ajoute un asset jusqu'à la limite de 24 — v6.3) -----
  socket.on('add-asset', async (data: { asset: string }) => {
    if (!session.client) return;
    const asset = String(data?.asset ?? '').trim();
    if (!asset) return;
    if (registry.has(asset)) return;
    if (tradingMode.assets.length >= MAX_SELECTED_ASSETS) {
      log(io, 'warning', `[MULTI] add-asset ${asset} rejeté : limite de ${MAX_SELECTED_ASSETS} assets atteinte`);
      socket.emit('assets-selected', { ok: false, error: `maximum ${MAX_SELECTED_ASSETS} assets`, mode: tradingMode.mode, assets: [...tradingMode.assets], focus: tradingMode.focus });
      return;
    }
    applyAssetSelection(io, tradingMode.mode, [...tradingMode.assets, asset]);
    log(io, 'info', `[MULTI] asset ajouté : ${asset} (${tradingMode.assets.length}/${MAX_SELECTED_ASSETS})`);
    saveSessionSnapshot(); // v6.3 — persistance
    io.emit('assets-selected', { ok: true, mode: tradingMode.mode, assets: [...tradingMode.assets], focus: tradingMode.focus });
  });

  // ----- remove-asset (§30 — arrêt propre d'un asset) -----
  socket.on('remove-asset', async (data: { asset: string }) => {
    if (!session.client) return;
    const asset = String(data?.asset ?? '').trim();
    if (!asset || !registry.has(asset)) return;
    if (tradingMode.assets.length <= 1) {
      log(io, 'warning', `[MULTI] remove-asset ${asset} rejeté : au moins 1 asset est requis`);
      socket.emit('assets-selected', { ok: false, error: 'au moins 1 asset requis', mode: tradingMode.mode, assets: [...tradingMode.assets], focus: tradingMode.focus });
      return;
    }
    applyAssetSelection(io, tradingMode.mode, tradingMode.assets.filter(a => a !== asset));
    log(io, 'info', `[MULTI] asset retiré : ${asset} (contexte supprimé, auto-trade arrêté — ${tradingMode.assets.length} restant(s))`);
    saveSessionSnapshot(); // v6.3 — persistance
    io.emit('assets-selected', { ok: true, mode: tradingMode.mode, assets: [...tradingMode.assets], focus: tradingMode.focus });
  });

  // ----- v6.3 : Payout Guard — toggle + statut -----
  // Active/désactive le remplacement automatique des assets (v20 : Auto
  // Switch Assets — déclencheur payout < 92%, cible payout == 92%). Tourne
  // côté backend, y compris SANS frontend connecté.
  socket.on('set-payout-guard', (data: { enabled?: boolean }) => {
    if (typeof data?.enabled === 'boolean') {
      payoutGuard.config.enabled = data.enabled;
      log(io, 'info', `[AUTO-SWITCH] ${data.enabled ? 'ACTIVÉ' : 'DÉSACTIVÉ'} — déclencheur payout < ${AUTO_SWITCH_TRIGGER_PCT}% · cible payout == ${AUTO_SWITCH_TARGET_PCT}% · verrou dernier ordre = GAIN`);
      saveSessionSnapshot(); // v6.3 — persistance
    }
    socket.emit('payout-guard-status', payoutGuardSummary(payoutGuard.state, payoutGuard.config));
  });

  socket.on('get-payout-guard', () => {
    socket.emit('payout-guard-status', payoutGuardSummary(payoutGuard.state, payoutGuard.config));
  });

  // ----- set-focus (§26 — l'asset affiché n'arrête JAMAIS les autres) -----
  socket.on('set-focus', (data: { asset: string }) => {
    const asset = String(data?.asset ?? '').trim();
    if (!asset || !registry.has(asset)) return;
    if (tradingMode.focus === asset) return;
    tradingMode.focus = asset;
    session.market = registry.getAssetContext(asset)?.market ?? session.market;
    // v6.5.1 — (ré)activation des flux de TOUS les assets (focus en dernier)
    // : un changeSymbol supplémentaire ne coupe PAS les flux déjà activés
    // (validé en live) — tous les contextes continuent d'être traités (§26).
    activateSymbolStreams();
    candleSync.setActiveAssets(tradingMode.assets, session.config.candleSize ?? 30, asset);
    log(io, 'info', assetLog(asset, `focus — affichage plein écran (les ${registry.size} assets continuent d'être traités)`));
    io.emit('assets-selected', { ok: true, mode: tradingMode.mode, assets: [...tradingMode.assets], focus: tradingMode.focus });
  });

  // ----- set-mode (changement de mode démo/réel) -----
  socket.on('set-mode', async (data: { mode: AccountMode }) => {
    if (!session.client) return;
    try {
      log(io, 'info', `switching to ${data.mode} mode (reconnect required)`);
      session.mode = data.mode;
      session.client.setMode(data.mode);
      // Note: en pratique il faut appeler connect() à nouveau. On détruit
      // et recrée le client pour simplifier.
      const creds = session.client.getSession();
      if (!creds) return;
      // On garde les credentials dans le session.client.options mais comme
      // c'est privé, on doit redemander à l'utilisateur de se reconnecter.
      // Pour cette UI, on demande simplement à l'utilisateur de re-login.
      socket.emit('mode-change-required', { mode: data.mode });
    } catch (e: any) {
      log(io, 'error', `set-mode error: ${e.message}`);
    }
  });

  socket.on('select-market', async (data: { market: string }) => {
    if (!session.client) {
      socket.emit('log', { ts: new Date().toISOString(), level: 'error', message: 'not logged in' });
      return;
    }
    try {
      const m = getMarket(data.market);
      if (!m) {
        log(io, 'error', `unknown market: ${data.market}`);
        return;
      }
      // ── MÊME ACTIF re-sélectionné (ex. après changement de timeframe) ──
      // Le handler set-config (applyTimeframeSwitch) a déjà synchronisé le
      // flux broker (changeSymbol), le CandleBuilder et l'historique à la
      // nouvelle période. On ne refait PAS les opérations lourdes (init du
      // cache 90 jours, reset des moteurs) : c'était la source de la
      // désynchronisation historique ↔ live (bougie M1 étiquetée M5 pendant
      // la fenêtre de fetch).
      if (registry.has(m.name)) {
        try { session.client.market.changeSymbol(m.name, (session.config.candleSize ?? 30) as any); } catch { /* ignore */ }
        log(io, 'info', `market re-selected (same asset ${m.name}, period=${session.config.candleSize ?? 30}s) — sync déjà faite par set-config`);
        io.emit('market-refresh', { phase: 'start', from: m.name, to: m.name, reason: 'manual-select-same-asset' });
        void fetchAndBroadcastHistory(io, m.name, session.config.candleSize ?? 30, Math.min(100, session.config.historyCount ?? 100), 'manual-select-refresh').finally(() => io.emit('market-refresh', { phase: 'complete', from: m.name, to: m.name, reason: 'manual-select-same-asset' }));
        return;
      }

      // ── MODE MULTI-ASSETS : select-market = remplacer l'asset FOCUS par ce
      // marché (switch-asset) — les AUTRES assets sélectionnés continuent
      // d'être abonnés et traités indépendamment (§20/§30).
      if (tradingMode.mode === 'multi' && tradingMode.focus) {
        const from = tradingMode.focus;
        io.emit('market-refresh', { phase: 'start', from, to: m.name, reason: 'manual-select' });
        applyAssetSelection(io, 'multi', tradingMode.assets.map(a => a === from ? m.name : a));
        log(io, 'info', `[MULTI] asset focus remplacé : ${from} → ${m.name} (${tradingMode.assets.length} assets actifs)`);
        io.emit('assets-selected', { ok: true, mode: tradingMode.mode, assets: [...tradingMode.assets], focus: tradingMode.focus });
        void fetchAndBroadcastHistory(io, m.name, session.config.candleSize ?? 30, Math.min(100, session.config.historyCount ?? 100), 'manual-select-refresh').finally(() => io.emit('market-refresh', { phase: 'complete', from, to: m.name, reason: 'manual-select' }));
        return;
      }

      // ── MODE MONO-ASSET : remplacement de l'unique asset (1 contexte).
      const prevAsset = session.market?.name;
      io.emit('market-refresh', { phase: 'start', from: prevAsset, to: m.name, reason: 'manual-select' });
      if (prevAsset && prevAsset !== m.name) {
        try { session.client.market.unsubscribe(prevAsset); } catch { /* ignore */ }
        registry.removeAssetContext(prevAsset); // §30
        candleSync.purgeAsset(prevAsset);
      }
      session.market = m;
      session.config.market = data.market;
      session.closeWindow = [];
      session.client.market.subscribe(m.name);
      session.client.market.changeSymbol(m.name, (session.config.candleSize ?? 30) as any);
      // Contexte de trading du NOUVEL asset (moteurs dédiés).
      registry.ensureAssetContext(m.name, {
        market: m,
        bettingStrategy: session.config.bettingStrategy ?? 'fixed',
        baseAmount: parseFloat(session.config.margin) || 1,
        maxMartingaleSteps: clampMaxMartingaleSteps(session.config.maxMartingaleSteps),
        autoTradeEnabled: session.config.autoTradeEnabled && session.config.autoOpen,
      });
      tradingMode.mode = 'single';
      tradingMode.assets = [m.name];
      tradingMode.focus = m.name;
      candleSync.setActiveAssets([m.name], session.config.candleSize ?? 30, m.name);
      // PURGE des séries du synchroniseur pour le nouvel actif (anti bougies
      // multi-actifs à la prochaine ré-agrégation de changement de timeframe).
      candleSync.switchAsset(m.name);
      log(io, 'info', `market switched to ${m.name} (period=${session.config.candleSize ?? 30}s)`);
      // Re-initialize the candle history cache for the new asset
      initializeCandleHistoryCache(io, m.name, session.config.candleSize ?? 30).catch(err => {
        log(io, 'error', `candle cache re-init error: ${err.message}`);
      });
      // Update the tick recorder for the new asset
      if (candleTickRecorder) candleTickRecorder.setAsset(m.name);
      recorderAsset = m.name;
      void fetchAndBroadcastHistory(io, m.name, session.config.candleSize ?? 30, Math.min(100, session.config.historyCount ?? 100), 'manual-select-refresh').finally(() => io.emit('market-refresh', { phase: 'complete', from: prevAsset, to: m.name, reason: 'manual-select' }));
    } catch (e: any) {
      log(io, 'error', `select-market error: ${e.message}`);
    }
  });

  socket.on('get-deals', () => {
    socket.emit('deals', { deals: session.closedDeals.slice(0, 50) });
  });

  // ----- get-pattern-performance (fetch pattern stats + recent trades) -----
  socket.on('get-pattern-performance', () => {
    socket.emit('pattern-performance', {
      stats: getAllPatternStats(),
      recentTrades: getRecentPatternTrades(50),
    });
  });

  // ----- get-cache-status (debug: check candle history cache state) -----
  socket.on('get-cache-status', () => {
    if (!candleHistoryCache) {
      socket.emit('cache-status', { initialized: false, message: 'Cache not initialized' });
      return;
    }
    const status = {
      initialized: true,
      asset: candleHistoryCache['asset'],
      period: candleHistoryCache['period'],
      cacheDir: candleHistoryCache['cacheDir'],
      filePath: candleHistoryCache['cacheDir'] + '/candles_' + (candleHistoryCache['asset'] as string).replace(/[^a-zA-Z0-9_-]/g, '_') + '_S' + candleHistoryCache['period'] + '.json',
      candleCount: candleHistoryCache.size(),
      firstCandleTime: candleHistoryCache.getFirstCandleTime() > 0
        ? new Date(candleHistoryCache.getFirstCandleTime() * 1000).toISOString()
        : null,
      lastCandleTime: candleHistoryCache.getLastCandleTime() > 0
        ? new Date(candleHistoryCache.getLastCandleTime() * 1000).toISOString()
        : null,
    };
    socket.emit('cache-status', status);
    log(io, 'info', `[CACHE] Status: ${status.candleCount} candles, last: ${status.lastCandleTime}, file: ${status.filePath}`);
  });

  // ----- get-sync-report (§19 : diagnostics de synchronisation par timeframe) -----
  // Rapport complet de l'état de synchronisation historique ↔ live :
  // machine d'état, génération, plages, recouvrement, trous, compteurs de
  // ticks (doublons/retards/hors-ordre) + les 100 derniers événements [SYNC].
  socket.on('get-sync-report', (data: { asset?: string; period?: number } = {}) => {
    const asset = data.asset ?? chartAsset();
    if (!asset) {
      socket.emit('sync-report', { error: 'no active market' });
      return;
    }
    const reports = data.period
      ? [candleSync.getSyncReport(asset, data.period)]
      : candleSync.getAllReports(asset);
    socket.emit('sync-report', {
      asset,
      activePeriod: chartPeriodSec(),
      latestMarketTimeSec: candleSync.getLatestMarketTimeSec(asset),
      reports,
      recentEvents: candleSync.getRecentSyncEvents(100),
      stats: candleSync.getStats(),
    });
  });

  // ----- capture-history -----
  socket.on('capture-history', async (data: { count?: number; size?: number; asset?: string }, ack?: (result: { ok: boolean; count?: number; error?: string; candles?: any[] }) => void) => {
    const targetAsset = (typeof data.asset === 'string' && data.asset.length > 0)
      ? data.asset
      : (tradingMode.focus ?? session.market?.name ?? '');
    if (!session.client || !registry.has(targetAsset)) {
      const error = 'not logged in or no asset selected';
      socket.emit('log', { ts: new Date().toISOString(), level: 'error', message: error });
      ack?.({ ok: false, error });
      return;
    }
    // Explicit Fetch History requests are expressed in DAYS by the UI and
    // may legitimately require more than the normal 300-candle warm-up.
    // Keep the hard ceiling at the equivalent of 10 days for the selected
    // timeframe; background/automatic callers can still pass their smaller
    // counts unchanged.
    const size = data.size ?? session.config.candleSize ?? 30;
    const maxDaysCandles = Math.max(1, Math.ceil((10 * 86400) / Math.max(1, size)));
    const count = Math.min(maxDaysCandles, Math.max(1, Math.floor(data.count ?? session.config.historyCount ?? 300)));
    // Timeframe de capture = timeframe du graphique (celui de la config,
    // ou celui explicitement demandé par le frontend) — JAMAIS un timeframe
    // figé : l'historique doit être capturé dans la MÊME période que les
    // bougies live (protocole .har : une seule période par flux).
    if (data.size && data.size !== session.config.candleSize) {
      // Le frontend demande une période différente de la config → aligne la
      // config (et le flux broker) AVANT la capture, ATTENDS le fetch
      // d'arrière-plan du switch, puis effectue la capture profonde.
      // L'ack n'est JAMAIS laissé pendant : la promesse frontend résout
      // toujours avec le résultat de la capture au nouveau timeframe.
      applyTimeframeSwitch(io, session.config.candleSize ?? 30, data.size);
      // ALIGNEMENT CONFIG (même ordre que set-config : config PUIS switch) —
      // sans cela fetchAndBroadcastHistory rejetterait le résultat profond
      // comme « superseded » (config.candleSize ≠ size demandé).
      session.config.candleSize = data.size;
      await waitForHistoryFetchIdle(targetAsset, data.size, 90_000);
      // ⤵ suite du flux commun ci-dessous avec `size` déjà aligné sur la demande.
    }
    log(io, 'info', `capturing ${count} historical candles (period=${size}s) for ${targetAsset}`);
    // SÉRIALISATION AVEC LES FETCHS D'ARRIERE-PLAN : sans cette attente, la
    // garde anti-doublon de fetchAndBroadcastHistory renvoyait [] quand un
    // warm-up/gap-resync était en vol → le frontend recevait ok:false et
    // repliait silencieusement sur son buffer visible de 300 bougies.
    await waitForHistoryFetchIdle(targetAsset, size, 90_000);
    // Chemin unique dédupliqué : fetch complet + seed builder + emit
    // candles-history + re-chauffe des moteurs — POUR CET ASSET.
    const fetchedCandles = await fetchAndBroadcastHistory(io, targetAsset, size, count, 'capture-history');
    const captured = fetchedCandles.length;
    if (captured === 0) {
      ack?.({ ok: false, count: 0, error: 'broker returned no historical candles' });
    } else {
      ack?.({ ok: true, count: captured, candles: fetchedCandles });
    }
    socket.emit('candles-snapshot', {
      asset: targetAsset,
      key: `${registry.getAssetContext(targetAsset)?.market.active_id ?? getMarket(targetAsset).active_id}:${size}`,
      count: session.candlesCaptured,
    });
  });

  // ----- place-order (binary CALL/PUT) -----
  // MULTI-ASSETS : `asset` optionnel dans le payload — par défaut l'asset
  // FOCUS. Chaque carte AssetTradingCard passe SON asset (§25).
  socket.on('place-order', async (data: {
    action: 'call' | 'put';
    amount: number;
    time?: number;          // expiration en secondes
    optionType?: number;
    asset?: string;         // asset cible (défaut : focus)
  }) => {
    const targetAsset = (typeof data.asset === 'string' && data.asset.length > 0)
      ? data.asset
      : (tradingMode.focus ?? session.market?.name ?? '');
    if (!session.client || !targetAsset || !registry.has(targetAsset)) {
      const msg = 'not logged in or no asset selected';
      log(io, 'error', `place-order: ${msg}`);
      socket.emit('order-error', { error: msg, asset: targetAsset });
      return;
    }
    const effectiveAsset = targetAsset;
    const orderCtx = registry.requireAssetContext(effectiveAsset); // §32
    const amount = data.amount ?? parseFloat(session.config.margin) ?? 1;
    const time = data.time ?? session.config.expirySeconds;
    log(io, 'info', assetLog(effectiveAsset, `placing ${data.action.toUpperCase()} order: amount=${amount} time=${time}s`));
    // Set the manual-trade pending flag BEFORE awaiting openOrder so the
    // SDK's `deal_opened` event (fired during the await) can mark the
    // deal as manual via the race-condition guard in the deal_opened
    // handler above. The flag is time-gated to 5s.
    session.manualTradePending = true;
    session.manualTradePendingTs = Date.now();
    try {
      const result = await session.client.trading.openOrder({
        asset: effectiveAsset,
        amount,
        action: data.action,
        time,
        isDemo: session.mode === 'demo' ? 1 : 0,
        optionType: (data.optionType as any) ?? 100,
      });
      // Clear the pending flag now that openOrder has resolved.
      session.manualTradePending = false;
      // L'action demandée est enregistrée SUR LE CONTEXTE DE CET ASSET (le
      // fallback d'action dans deal_opened/deal_closed ne peut pas se tromper
      // d'asset — §18).
      orderCtx.autoTrade.lastTradeAction = data.action;
      orderCtx.autoTrade.lastTradeTs = Date.now();

      if (result.success && result.deal) {
        noteDealOpened(orderCtx, result.deal);
        if (!session.openedDeals.find(d => d.id === result.deal!.id)) {
          session.openedDeals.push(result.deal);
        }
        // ----------------------------------------------------------------
        // Mark this deal as MANUAL so the auto-switch-asset logic in
        // `deal_closed` is skipped when it expires. The user pressed
        // CALL/PUT in the UI — they explicitly chose this asset and
        // expect the chart to stay on it after the trade resolves.
        //
        // NOTE: the race-condition guard in `deal_opened` may have
        // already added this id to the set if the SDK emitted
        // `deal_opened` during the await. Using `add()` on a Set is
        // idempotent so the duplicate insert is a no-op.
        // ----------------------------------------------------------------
        session.manualDealIds.add(String(result.deal.id));
        // Bound the set to avoid unbounded growth over long sessions.
        if (session.manualDealIds.size > 500) {
          const arr = Array.from(session.manualDealIds);
          session.manualDealIds = new Set(arr.slice(-200));
        }
        session.lastOrderPlacedTs = Date.now(); // v20 — diagnostic (plus de switch idle)
        session.lastTradeTs = session.lastOrderPlacedTs;
        log(io, 'info', assetLog(targetAsset, `trade opened — ${data.action.toUpperCase()} dealId=${result.deal.id} openPrice=${result.deal.openPrice} (manual)`));
        io.emit('trade-opened', { asset: effectiveAsset, deal: result.deal, source: 'manual', expirationSeconds: time, label: 'Manuel · Order panel' }); // §21 + libellé v22
      } else {
        log(io, 'warning', assetLog(targetAsset, `${data.action.toUpperCase()} order failed: ${result.error ?? 'unknown'}`));
      }
      socket.emit('order-placed', {
        success: result.success,
        requestId: result.requestId,
        deal: result.deal,
        error: result.error,
        side: data.action,
        asset: effectiveAsset,
      });
    } catch (e: any) {
      // Make sure we clear the pending flag even on error.
      session.manualTradePending = false;
      const errMsg = e?.message ?? String(e);
      log(io, 'error', assetLog(targetAsset, `place-order error: ${errMsg}`));
      socket.emit('order-error', { error: errMsg, side: data.action, asset: effectiveAsset });
    }
  });

  // ----- close-positions / close-all (non supporté en binaire, on log seulement) -----
  socket.on('close-positions', (_data: { position_ids: number[] }) => {
    log(io, 'warning', 'close-positions: non supporté en mode binaire (les ordres expirent automatiquement)');
  });
  socket.on('close-all', () => {
    log(io, 'warning', 'close-all: non supporté en mode binaire (les ordres expirent automatiquement)');
  });

  // ----- set-config -----
  socket.on('set-config', (data: Partial<StrategyConfig>) => {
    const prevSize = session.config.candleSize;
    session.config = { ...session.config, ...data };
    if (typeof data.autoSwitchAssets === 'boolean') {
      session.config.autoSwitchAssets = data.autoSwitchAssets;
      // v20 — Nouvelles règles Auto Switch Assets : payout < 92% + dernier
      // ordre = GAIN → switch vers un asset payout == 92%. Évaluation sur
      // chaque poussée updateAssets (runPayoutGuard) — plus de timer idle.
      log(io, 'info', `[AUTO-SWITCH] ${data.autoSwitchAssets ? 'ENABLED' : 'DISABLED'} from frontend (règle : payout < 92% + dernier ordre GAIN → asset == 92%)`);
      saveSessionSnapshot();
    }
    // v21 — « Stay on Forex OTC Only » : quand ON, tout Auto Switch Assets ne
    // choisit QUE des paires Forex OTC (CADJPY_otc, AUDUSD_OTC…).
    if (typeof data.stayOnForexOtcOnly === 'boolean') {
      session.config.stayOnForexOtcOnly = data.stayOnForexOtcOnly;
      log(io, 'info', `[AUTO-SWITCH] Stay on Forex OTC Only ${data.stayOnForexOtcOnly ? 'ON — cibles limitées aux paires Forex OTC' : 'OFF — cibles = tout asset payout == 92%'}`);
      saveSessionSnapshot();
    }
    log(io, 'info', `config updated: ${JSON.stringify(data)}`);
    // Update tick recorder if candleSize changed
    if (data.candleSize && candleTickRecorder) {
      candleTickRecorder.setPeriod(data.candleSize);
    }
    // ── CHANGEMENT DE TIMEFRAME — synchronisation historique ↔ live ──
    // Le protocole Pocket Option (.har) exige changeSymbol {asset, period}
    // pour re-tager le flux broker à la nouvelle période. On ré-agrège aussi
    // INSTANTANÉMENT le buffer de ticks (miroir updateHistoryNewFast) pour
    // que le graphique ne montre JAMAIS un mélange de périodes.
    if (data.candleSize && data.candleSize !== prevSize) {
      applyTimeframeSwitch(io, prevSize ?? 30, data.candleSize);
    }
    // Propage la config de mise aux contextes (stratégie/montant de base).
    if (data.bettingStrategy || data.margin) {
      for (const [, ctx] of registry.entries()) {
        if (data.bettingStrategy) ctx.bettingStrategy = data.bettingStrategy;
        if (data.margin) ctx.betting.baseAmount = parseFloat(data.margin) || 1;
      }
    }
    // v19 — Propage AUSSI le garde-fou Martingale aux contextes existants
    // (couvre le set-config direct des consommateurs génériques du frontend).
    if (typeof (data as any).maxMartingaleSteps === 'number') {
      const cap = clampMaxMartingaleSteps((data as any).maxMartingaleSteps);
      session.config.maxMartingaleSteps = cap;
      for (const [, ctx] of registry.entries()) ctx.betting.maxMartingaleSteps = cap;
    }
    io.emit('status', buildStatusPayload());
  });

  // ----- save-config (saves to JSON file) -----
  socket.on('save-config', () => {
    try {
      const configPath = require('path').join(process.cwd(), '..', '..', '.logs', 'saved-config.json');
      const fs = require('fs');
      const dir = require('path').dirname(configPath);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      // Include strategyId, dailyProfitStop config, and custom strategy config
      const saveData = {
        ...session.config,
        // Also save the custom strategy configuration (selectedAlgos, decisionType, threshold)
        // These are stored in the imported customStrategyConfig from strategies.ts
        customStrategyConfig: (require('./strategies.js') as any).customStrategyConfig,
      };
      fs.writeFileSync(configPath, JSON.stringify(saveData, null, 2));
      log(io, 'info', `config saved to file (incl. strategyId, dailyProfitStop, customStrategy)`);
      socket.emit('config-saved', { ok: true, path: configPath });
    } catch (e: any) {
      log(io, 'error', `save-config error: ${e.message}`);
      socket.emit('config-saved', { ok: false, error: e.message });
    }
  });

  // ----- load-config (loads from JSON file) -----
  socket.on('load-config', () => {
    try {
      const configPath = require('path').join(process.cwd(), '..', '..', '.logs', 'saved-config.json');
      const fs = require('fs');
      if (!fs.existsSync(configPath)) {
        socket.emit('config-loaded', { ok: false, error: 'No saved config found' });
        return;
      }
      const saved = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
      // Extract custom strategy config before merging
      const savedCustom = saved.customStrategyConfig;
      delete saved.customStrategyConfig;
      session.config = { ...session.config, ...saved };
      // Restore custom strategy config
      if (savedCustom) {
        const strategiesModule = require('./strategies.js') as any;
        if (strategiesModule.customStrategyConfig) {
          strategiesModule.customStrategyConfig.selectedAlgos = savedCustom.selectedAlgos ?? [];
          strategiesModule.customStrategyConfig.decisionType = savedCustom.decisionType ?? 'majority';
          strategiesModule.customStrategyConfig.threshold = savedCustom.threshold ?? 0.5;
        }
      }
      log(io, 'info', `config loaded from file`);
      socket.emit('config-loaded', { ok: true, config: session.config, customStrategyConfig: savedCustom });
    } catch (e: any) {
      log(io, 'error', `load-config error: ${e.message}`);
      socket.emit('config-loaded', { ok: false, error: e.message });
    }
  });

  // ----- set-auto-trade (§13 — Auto Trade PAR ASSET) -----
  // `asset` optionnel : si présent, ne bascule QUE le contexte de CET asset
  // (les autres continuent leur Auto Trade indépendamment). Sinon, bascule
  // TOUS les contextes + la config globale.
  socket.on('set-auto-trade', (data: { enabled: boolean; asset?: string }) => {
    const enabled = !!data.enabled;

    if (typeof data.asset === 'string' && data.asset.length > 0) {
      // ── Toggle PAR ASSET : seul LE contexte de cet asset change. ──
      const ctx = registry.getAssetContext(data.asset);
      if (!ctx) {
        socket.emit('auto-trade-status', buildAutoTradeStatus());
        return;
      }
      ctx.autoTrade.enabled = enabled;
      log(io, 'info',
        assetLog(data.asset, `Auto Trade ${enabled ? 'ACTIVÉ' : 'DÉSACTIVÉ'} (contexte isolé — ${registry.size} assets actifs, ` +
        `les autres contextes ne changent pas)`));
      // Active aussi la config globale au premier toggle ON d'un asset (le
      // master-switch du panneau Auto Trade reste cohérent avec l'UI).
      if (enabled && !session.config.autoTradeEnabled) {
        session.config.autoTradeEnabled = true;
        session.startBalance = session.client?.account?.getCurrentBalance?.() ?? 0;
      }
      if (enabled && !session.strategyRunning) startStrategyLoop(io);
      io.emit('auto-trade-status', buildAutoTradeStatus());
      return;
    }

    // ── Toggle GLOBAL : tous les contextes + config. ──
    session.config.autoTradeEnabled = enabled;
    for (const [, ctx] of registry.entries()) {
      ctx.autoTrade.enabled = enabled;
    }
    if (enabled) {
      // Record starting balance when auto-trade is enabled
      const bal = session.client?.account?.getCurrentBalance?.() ?? 0;
      session.startBalance = bal;
      log(io, 'info',
        `auto-trade enabled — ${registry.size} asset(s) (start balance: ${bal}, strategy: ${session.config.strategyId}, ` +
        `mise: ${session.config.bettingStrategy ?? 'fixed'}, ` +
        `expiration: chaque règle L_Lucien ProTrader porte la sienne`);
    } else {
      log(io, 'info', `auto-trade disabled — ${registry.size} asset(s)`);
    }
    if (enabled && !session.strategyRunning) {
      startStrategyLoop(io);
    } else if (!enabled && session.strategyRunning) {
      stopStrategyLoop(io);
    }
    saveSessionSnapshot(); // v6.3 — persistance
    io.emit('auto-trade-status', buildAutoTradeStatus());
  });

  // ----- set-auto-strategy (stratégie d'auto-trade) -----
  socket.on('set-auto-strategy', (data: { strategyId: string }) => {
    // Alias legacy : l'ancien identifiant « bos_choch_cisd » (v1-v17) reste
    // accepté et mappé vers L_Lucien ProTrader (sessions persistées).
    const requested = data?.strategyId === 'bos_choch_cisd' ? 'l_lucien_protrader' : data?.strategyId;
    const s = AUTO_TRADE_STRATEGIES.find(x => x.id === requested);
    if (!s) {
      log(io, 'error', `unknown auto-trade strategy: ${data?.strategyId}`);
      socket.emit('auto-trade-status', buildAutoTradeStatus());
      return;
    }
    session.config.strategyId = s.id;
    // La stratégie d'auto-trade et la stratégie de mise sont indépendantes,
    // mais le choix Martingale/Fixe/Fibonacci doit être effectif immédiatement
    // sur TOUS les contextes existants, même si aucun nouvel ordre n'est encore placé.
    const selectedBettingStrategy = session.config.bettingStrategy ?? 'fixed';
    const selectedBaseAmount = Math.max(1, parseFloat(session.config.margin) || 1);
    const selectedMaxMartingaleSteps = clampMaxMartingaleSteps(session.config.maxMartingaleSteps);
    for (const [, ctx] of registry.entries()) {
      ctx.bettingStrategy = selectedBettingStrategy;
      ctx.betting.baseAmount = selectedBaseAmount;
      ctx.betting.maxMartingaleSteps = selectedMaxMartingaleSteps; // v19 — garde-fou Martingale
      resetBosChochCisdState();
      resetNinjaProTraderState(); // v22 — Ninja ProTrader : garde un-ordre-par-bougie-en-formation
    }
    log(io, 'info', `auto-trade strategy set to: ${s.name}`);
    saveSessionSnapshot(); // v6.3 — persistance
    io.emit('auto-trade-status', buildAutoTradeStatus());
  });

  // ----- set-auto-config (mise + réglages L_Lucien ProTrader) -----
  socket.on('set-auto-config', (data: {
    bettingStrategy?: 'fixed' | 'martingale' | 'fibonacci';
    baseAmount?: number;
    bosChochCisdBosUp?: boolean;
    bosChochCisdBosDown?: boolean;
    bosChochCisdChochUp?: boolean;
    bosChochCisdChochDown?: boolean;
    bosChochCisdCisdUp?: boolean;
    bosChochCisdCisdDown?: boolean;
    bosChochCisdCallRules?: BosChochCisdOrderRule[];
    bosChochCisdPutRules?: BosChochCisdOrderRule[];
    /** v26 — règles PROPRES à Ninja ProTrader (repli partagé si absentes). */
    ninjaBosChochCisdCallRules?: BosChochCisdOrderRule[];
    ninjaBosChochCisdPutRules?: BosChochCisdOrderRule[];
    bosChochCisdReset?: boolean;
    /** v19 — switch « Confirmation bougie précédente » (L_Lucien ProTrader). */
    bosChochCisdConfirmCandle?: boolean;
    /** v19/v20 — garde-fou Martingale : nombre max de mises (0 = illimité). */
    maxMartingaleSteps?: number;
    /** v24 — étapes de vérification CISD optionnelles (cases à cocher). */
    cisdGuardUp?: boolean;
    cisdGuardDown?: boolean;
    cisdGuardSwingMode?: 'intact' | 'violated' | 'none';
    cisdGuardConfirmBosUp?: boolean;
    cisdGuardConfirmChochUp?: boolean;
    cisdGuardConfirmBosDown?: boolean;
    cisdGuardConfirmChochDown?: boolean;
  }) => {
    const changes: string[] = [];

    if (data.bettingStrategy && ['fixed', 'martingale', 'fibonacci'].includes(data.bettingStrategy)) {
      const previousBettingStrategy = session.config.bettingStrategy ?? 'fixed';
      const nextBettingStrategy = data.bettingStrategy as 'fixed' | 'martingale' | 'fibonacci';
      session.config.bettingStrategy = nextBettingStrategy;
      changes.push(`mise=${nextBettingStrategy}`);

      // Changer de moteur de mise démarre toujours sur la mise de base.
      // Cela évite qu'un ancien streak de pertes accumulé sous Fixed/Fibonacci
      // contamine le premier ordre Martingale de L_Lucien ProTrader.
      if (previousBettingStrategy !== nextBettingStrategy) {
        for (const [, ctx] of registry.entries()) {
          ctx.betting.consecutiveLosses = 0;
          ctx.betting.fibIndex = 0;
        }
      }
    }
    if (typeof data.baseAmount === 'number' && Number.isFinite(data.baseAmount) && data.baseAmount >= 1) {
      session.config.margin = String(data.baseAmount);
      changes.push(`montant base=${data.baseAmount}`);
    }
    // Champ « Expiration » générique (contrat v6.3 : respecté à la seconde
    // près, clamp [3 s, 86 400 s] — jamais snappé). NOTE : ce champ ne
    // contrôle JAMAIS les ordres de L_Lucien ProTrader — l'expiration d'un
    // ordre vient UNIQUEMENT de sa règle CALL/PUT (expirationSeconds de la
    // combinaison). Le champ reste un réglage générique de session (exposé
    // par le status, persisté, utilisé comme repli par les consommateurs
    // génériques du frontend).
    if (typeof (data as any).expirySeconds === 'number' && Number.isFinite((data as any).expirySeconds)) {
      const nextExpiry = snapExpiry((data as any).expirySeconds as number);
      if (nextExpiry !== session.config.expirySeconds) {
        session.config.expirySeconds = nextExpiry;
        changes.push(`expiration champ=${nextExpiry}s`);
      }
    }
    if (data.bosChochCisdCallRules !== undefined || data.bosChochCisdPutRules !== undefined) {
      const normalizedRules = normalizeBosChochCisdOrderRules(
        data.bosChochCisdCallRules ?? session.config.bosChochCisdCallRules,
        data.bosChochCisdPutRules ?? session.config.bosChochCisdPutRules,
      );
      session.config.bosChochCisdCallRules = normalizedRules.callRules
      session.config.bosChochCisdPutRules = normalizedRules.putRules
      changes.push(`règles CALL=${normalizedRules.callRules.length} PUT=${normalizedRules.putRules.length}`);
    }
    // v26 — règles PROPRES à Ninja ProTrader (§31 — séparées des règles
    // L_Lucien ; reçues UNIQUEMENT via les clés ninja*). Si l'utilisateur
    // n'en a jamais défini, elles restent absentes et Ninja retombe sur les
    // règles partagées (compatibilité §32).
    if ((data as any).ninjaBosChochCisdCallRules !== undefined || (data as any).ninjaBosChochCisdPutRules !== undefined) {
      const normalizedNinja = normalizeBosChochCisdOrderRules(
        (data as any).ninjaBosChochCisdCallRules ?? session.config.ninjaBosChochCisdCallRules,
        (data as any).ninjaBosChochCisdPutRules ?? session.config.ninjaBosChochCisdPutRules,
      );
      session.config.ninjaBosChochCisdCallRules = normalizedNinja.callRules
      session.config.ninjaBosChochCisdPutRules = normalizedNinja.putRules
      changes.push(`règles NINJA CALL=${normalizedNinja.callRules.length} PUT=${normalizedNinja.putRules.length}`);
    }
    const bccToggles: Array<[keyof StrategyConfig, string]> = [
      ['bosChochCisdBosUp', 'BOS Up'],
      ['bosChochCisdBosDown', 'BOS Down'],
      ['bosChochCisdChochUp', 'CHoCH Up'],
      ['bosChochCisdChochDown', 'CHoCH Down'],
      ['bosChochCisdCisdUp', 'CISD Up'],
      ['bosChochCisdCisdDown', 'CISD Down'],
    ];
    // v19 — switch « Confirmation bougie précédente » : ON → CALL ▲ exige
    // une bougie baissière avant la bougie signalée, PUT ▼ une haussière.
    if (data.bosChochCisdConfirmCandle === true || data.bosChochCisdConfirmCandle === false) {
      session.config.bosChochCisdConfirmCandle = data.bosChochCisdConfirmCandle;
      changes.push(`confirmation bougie précédente=${data.bosChochCisdConfirmCandle ? 'ON' : 'OFF'}`);
    }
    // v19/v20 — garde-fou Martingale : nombre MAXIMAL de mises (0 = illimité).
    // Après une perte au niveau max, RETOUR à la mise initiale.
    if (typeof data.maxMartingaleSteps === 'number' && Number.isFinite(data.maxMartingaleSteps)) {
      const cap = clampMaxMartingaleSteps(data.maxMartingaleSteps);
      if (cap !== clampMaxMartingaleSteps(session.config.maxMartingaleSteps)) {
        session.config.maxMartingaleSteps = cap;
        changes.push(`martingale max=${cap === 0 ? 'illimité' : `${cap} mise(s) dans la séquence`}`);
      }
    }
    // v24 — ÉTAPES DE VÉRIFICATION CISD OPTIONNELLES (cases à cocher).
    // Chaque changement réinitialise les séquences armées (les gardes
    // d'armement vivaient sous l'ancienne configuration).
    const cisdGuardChanged: string[] = [];
    const cisdGuardBooleans: Array<[keyof StrategyConfig, string]> = [
      ['cisdGuardUp', 'CISD Up'],
      ['cisdGuardDown', 'CISD Down'],
      ['cisdGuardConfirmBosUp', 'BOS Up + CISD Up'],
      ['cisdGuardConfirmChochUp', 'CHoCH Up + CISD Up'],
      ['cisdGuardConfirmBosDown', 'BOS Down + CISD Down'],
      ['cisdGuardConfirmChochDown', 'CHoCH Down + CISD Down'],
    ];
    for (const [k, label] of cisdGuardBooleans) {
      const v = (data as any)[k];
      if (v === true || v === false) {
        if ((session.config as any)[k] !== v) {
          (session.config as any)[k] = v;
          cisdGuardChanged.push(`${label}=${v ? '✓' : '✗'}`);
        }
      }
    }
    if (data.cisdGuardSwingMode === 'intact' || data.cisdGuardSwingMode === 'violated' || data.cisdGuardSwingMode === 'none') {
      if (session.config.cisdGuardSwingMode !== data.cisdGuardSwingMode) {
        session.config.cisdGuardSwingMode = data.cisdGuardSwingMode;
        cisdGuardChanged.push(`swing ${data.cisdGuardSwingMode === 'violated' ? 'VIOLÉ' : data.cisdGuardSwingMode === 'none' ? 'TOUT DÉCOCHÉ (étape ignorée)' : 'NON violé (intact)'}`);
      }
    }
    if (cisdGuardChanged.length > 0) {
      changes.push(`vérification CISD : ${cisdGuardChanged.join(' · ')}`);
      // Les séquences armées vivent sous l'ancienne configuration → reset.
      resetBosChochCisdState();
      resetNinjaProTraderState();
    }
    const bccOn: string[] = [];
    const bccOff: string[] = [];
    for (const [k, label] of bccToggles) {
      const v = (data as any)[k];
      if (v === true) { (session.config as any)[k] = true; bccOn.push(label); }
      else if (v === false) { (session.config as any)[k] = false; bccOff.push(label); }
    }
    if (bccOn.length || bccOff.length) {
      changes.push(`alertes ON=[${bccOn.join(',')}] OFF=[${bccOff.join(',')}]`);
    }
    if (data.bosChochCisdReset === true) {
      session.config.bosChochCisdBosUp = DEFAULT_BOS_CHOCH_CISD_TOGGLES.bosUp;
      session.config.bosChochCisdBosDown = DEFAULT_BOS_CHOCH_CISD_TOGGLES.bosDown;
      session.config.bosChochCisdChochUp = DEFAULT_BOS_CHOCH_CISD_TOGGLES.chochUp;
      session.config.bosChochCisdChochDown = DEFAULT_BOS_CHOCH_CISD_TOGGLES.chochDown;
      session.config.bosChochCisdCisdUp = DEFAULT_BOS_CHOCH_CISD_TOGGLES.cisdUp;
      session.config.bosChochCisdCisdDown = DEFAULT_BOS_CHOCH_CISD_TOGGLES.cisdDown;
      session.config.bosChochCisdCallRules = DEFAULT_BOS_CHOCH_CISD_ORDER_RULES.callRules;
      session.config.bosChochCisdPutRules = DEFAULT_BOS_CHOCH_CISD_ORDER_RULES.putRules;
      changes.push('réglages pack réinitialisés');
    }
    // L'expiration vient UNIQUEMENT des règles CALL/PUT — le champ global
    // expirySeconds n'est plus utilisé par L_Lucien ProTrader (conservé en
    // config pour le compatibility des sessions, jamais appliqué aux ordres).
    if (changes.length === 0) {
      socket.emit('auto-trade-status', buildAutoTradeStatus());
      return;
    }
    // Applique la mise de base + le garde-fou Martingale à tous les contextes existants.
    const baseAmt = Math.max(1, parseFloat(session.config.margin) || 1);
    const capSteps = clampMaxMartingaleSteps(session.config.maxMartingaleSteps);
    for (const [, ctx] of registry.entries()) {
      ctx.betting.baseAmount = baseAmt;
      ctx.betting.maxMartingaleSteps = capSteps; // v19 — garde-fou Martingale
    }
    if (data.bosChochCisdReset === true || bccToggles.some(([k]) => (data as any)[k] !== undefined)) {
      resetBosChochCisdState();
      resetNinjaProTraderState(); // v22 — Ninja ProTrader : garde un-ordre-par-bougie-en-formation
    }
    saveSessionSnapshot(); // v6.3 — persistance
    log(io, 'info', `auto-trade config updated: ${changes.join(' · ')}`);
    io.emit('auto-trade-status', buildAutoTradeStatus());
  });

  // ----- get-auto-status -----
  socket.on('get-auto-status', () => {
    candleJsonlReader.poll(); // rafraîchit le lecteur JSONL
    socket.emit('auto-trade-status', buildAutoTradeStatus());
  });

  socket.on('start-strategy', () => startStrategyLoop(io));
  socket.on('stop-strategy', () => stopStrategyLoop(io));

  socket.on('disconnect', () => {
    // v6.3 — La déconnexion du frontend N'ARRÊTE RIEN : la connexion broker,
    // les subscriptions, les contextes par asset, l'auto-trade, le Payout
    // Guard et le heartbeat headless continuent côté backend. Le prochain
    // frontend connecté récupère l'état complet via le flux status (1 Hz).
    console.log(`[socket] disconnected: ${socket.id} — le backend CONTINUE de trader (headless)`);
  });

  // Send initial status
  socket.emit('status', buildStatusPayload());
  // v6.3 — état du Payout Guard pour le frontend fraîchement connecté.
  socket.emit('payout-guard-status', payoutGuardSummary(payoutGuard.state, payoutGuard.config));
});

httpServer.listen(PORT, () => {
  console.log(`pocketoption-backend socket.io server running on port ${PORT}`);
});
