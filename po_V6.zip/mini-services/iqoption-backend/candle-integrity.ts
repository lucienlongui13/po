/**
 * candle-integrity.ts — Intégrité des séries de bougies (anti multi-actifs).
 * ============================================================
 *
 * Module PUR (aucun effet de bord) partagé par le serveur et les tests.
 *
 * Contexte (bug « graphiques endommagés » v5.3) : des bougies d'AUTRES
 * actifs (XAUUSD ~4400, BTC ~64000, EURJPY ~185…) entraient dans les
 * séries EURUSD ~1.16 via l'auto-switch post-trade, le buffer de ticks
 * non purgé et les caches 90 j contaminés — le graphique s'étalait alors
 * sur plusieurs ordres de grandeur de prix (bougies « éclatées » en
 * grappes illisibles séparées de vides).
 *
 * Principe : aucun instrument OTC de la plateforme ne varie de ×10 en
 * 90 jours. Toute bougie dont le close s'écarte de plus d'une DÉCADE
 * (×10) de la médiane des bougies RÉCENTES (l'actif réellement streamé)
 * appartient à un autre actif → REJET.
 */

export interface PriceSanitisableCandle {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume?: number
}

/**
 * Sanitise une série de bougies contre la contamination multi-actifs.
 *
 * Référence de prix = MÉDIANE des `refWindow` dernières closes (les plus
 * récentes = l'actif réellement streamé). Toute bougie dont le close
 * s'écarte de plus de `maxDecades` décades (×10 par défaut) de la
 * référence est REJETÉE : aucun instrument OTC de la plateforme ne bouge
 * de ×10 en 90 jours, alors qu'un actif étranger (XAUUSD ~4400 dans un
 * cache EURUSD ~1.16) s'écarte de ×3800.
 *
 * Retourne les bougies saines (ordre conservé) — défense en profondeur
 * appliquée à TOUT ce qui entre dans le CandleBuilder, les caches ou le
 * graphique (candles-history, ré-agrégation ticks, seed moteurs).
 */
export function sanitizeCandlesByPrice<T extends PriceSanitisableCandle>(
  candles: T[],
  opts: {
    refWindow?: number;
    maxDecades?: number;
    /** Prix d'ancrage externe (idéalement le dernier prix LIVE de l'actif). */
    referencePrice?: number;
    /** Distance relative maximale autour de l'ancre (ex. 0.05 = ±5%). */
    maxRelativeDistance?: number;
  } = {},
): { clean: T[]; dropped: number } {
  const n = candles.length
  if (n === 0) return { clean: [], dropped: 0 }
  const refWindow = opts.refWindow ?? 200
  const maxDecades = opts.maxDecades ?? 1 // ×10 par défaut

  // Médiane des closes des dernières bougies (référence = actif courant)
  const refCloses: number[] = []
  for (let i = n - 1; i >= 0 && refCloses.length < refWindow; i--) {
    const c = candles[i]
    if (Number.isFinite(c.close) && c.close > 0) refCloses.push(c.close)
  }
  if (refCloses.length === 0) return { clean: [], dropped: n }
  refCloses.sort((a, b) => a - b)
  const median = refCloses[Math.floor(refCloses.length / 2)]
  if (!Number.isFinite(median) || median <= 0) return { clean: [], dropped: n }

  const anchor = Number.isFinite(opts.referencePrice) && (opts.referencePrice ?? 0) > 0
    ? Number(opts.referencePrice)
    : median
  const logRef = Math.log10(anchor)
  const maxRelativeDistance = Number.isFinite(opts.maxRelativeDistance)
    ? Math.max(0, Number(opts.maxRelativeDistance))
    : null
  const clean: T[] = []
  let dropped = 0
  for (const c of candles) {
    const relativeOk = maxRelativeDistance == null
      || Math.abs(c.close / anchor - 1) <= maxRelativeDistance
    const ok = Number.isFinite(c.close) && c.close > 0
      && Number.isFinite(c.open) && Number.isFinite(c.high) && Number.isFinite(c.low)
      && Math.abs(Math.log10(c.close) - logRef) <= maxDecades
      && relativeOk
    if (ok) clean.push(c)
    else dropped++
  }
  return { clean, dropped }
}


/**
 * Garde-fou de continuité PRIX : conserve uniquement le dernier régime de prix
 * cohérent, en remontant depuis la bougie la plus récente.
 *
 * But : empêcher qu'une série contaminée ou recousue (ex. cache ancien + flux
 * live) introduise un saut artificiel de prix dans le graphique. Une rupture de
 * temps reste visible comme un trou : aucune bougie synthétique n'est créée.
 */
export function retainLatestPriceRegime<T extends PriceSanitisableCandle>(
  candles: T[],
  opts: { maxRelativeStep?: number; maxRelativeToAnchor?: number } = {},
): { clean: T[]; dropped: number; breakIndex: number | null } {
  if (candles.length <= 1) return { clean: candles.slice(), dropped: 0, breakIndex: null }
  const maxRelativeStep = Math.max(0, opts.maxRelativeStep ?? 0.05)
  const maxRelativeToAnchor = Math.max(0, opts.maxRelativeToAnchor ?? 0.05)

  const sorted = candles
    .filter((c) => Number.isFinite(c.time) && Number.isFinite(c.close) && c.close > 0)
    .slice()
    .sort((a, b) => a.time - b.time)

  if (sorted.length <= 1) return { clean: sorted, dropped: candles.length - sorted.length, breakIndex: null }

  const anchor = sorted[sorted.length - 1].close
  let start = sorted.length - 1
  for (let i = sorted.length - 2; i >= 0; i--) {
    const newer = sorted[i + 1]
    const older = sorted[i]
    const step = Math.abs(newer.close / older.close - 1)
    const anchorDrift = Math.abs(older.close / anchor - 1)
    if (step > maxRelativeStep || anchorDrift > maxRelativeToAnchor) {
      start = i + 1
      break
    }
    start = i
  }
  const clean = sorted.slice(start)
  return { clean, dropped: candles.length - clean.length, breakIndex: start > 0 ? start : null }
}
