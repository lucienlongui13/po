/**
 * candle-sync-manager.ts — SYNCHRONISATEUR HISTORIQUE ↔ LIVE PAR TIMEFRAME.
 * ============================================================================
 *
 * Implémente l'architecture cible du ToDo « Synchronisation historique ↔
 * stream des bougies par timeframe » (validée sur `History_Live_Fix.har`) :
 *
 *   Pocket Option market timestamps
 *           │
 *           ▼
 *   StreamTickNormalizer (updateStream / updateHistoryNewFast)
 *           │
 *           ▼
 *   Canonical Tick Buffer (CandleSyncManager)      ←§10 : UNE SEULE chronologie
 *           ├──► S5  CandleBuilder
 *           ├──► S30 CandleBuilder
 *           ├──► M1  CandleBuilder
 *           └──► M5  CandleBuilder
 *                    │
 *   History ──► normalize + align + merge ──► CandleSyncManager
 *                    │
 *          closed candles   /   forming candle
 *                    │
 *              Chart / Coach / Stratégies
 *
 * RÈGLE INVARIANTE : même actif + même timeframe + même bucket UTC
 *                    = une seule bougie canonique.
 *
 * Responsabilités (§15) :
 *   - recevoir l'historique (ingestHistory) ;
 *   - recevoir les ticks normalisés (ingestTick) ;
 *   - maintenir latestMarketTimeSec (temps MARCHÉ, jamais Date.now()) ;
 *   - conserver la zone de recouvrement historique ↔ live (§6) ;
 *   - fusionner par bucket avec priorité des sources (§14) ;
 *   - détecter les trous (§13) et piloter leur réparation (REPAIRING) ;
 *   - alimenter les builders de TOUS les timeframes (§10) ;
 *   - déclencher les événements de clôture UNE SEULE fois ;
 *   - machine d'état de synchronisation (§16) + syncGenerationId (§17) ;
 *   - logs de diagnostic [SYNC] (§19) + 100 derniers événements en mémoire.
 *
 * Machine d'état par (asset, period) :
 *
 *   DISCONNECTED → BUFFERING_LIVE → LOADING_HISTORY → MERGING → SYNCED
 *        │                                                     │
 *        └────────── (switchAsset) ──────────────────→ GAP_DETECTED
 *                                                    → REPAIRING → SYNCED
 */

import { CandleBuilder, type CandleLike, type SeedSource } from './candle-builder.js';
import {
  bucketStart,
  findGaps,
  isOhlcValid,
  normalizeCandleSeries,
  type CandleGap,
} from './timeframe.js';
import { sanitizeCandlesByPrice } from './candle-integrity.js';

// ─────────────────────────────────────────────────────────────────────────────
// Types publics
// ─────────────────────────────────────────────────────────────────────────────

export type SyncStateName =
  | 'DISCONNECTED'
  | 'BUFFERING_LIVE'
  | 'LOADING_HISTORY'
  | 'MERGING'
  | 'SYNCED'
  | 'GAP_DETECTED'
  | 'REPAIRING';

export interface TickInput {
  /** Temps MARCHÉ du tick (secondes, sous-seconde possible). */
  marketTimeSec: number;
  price: number;
  /** Temps local de réception (ms) — latence/logs uniquement. */
  receivedAtMs?: number;
}

export interface CandleSeries {
  closed: CandleLike[];
  forming: CandleLike | null;
}

export interface TickIngestResult {
  applied: boolean;
  reason?: 'duplicate' | 'late' | 'out-of-order';
}

export interface HistoryIngestResult {
  accepted: boolean;
  reason?: string;
  series: CandleSeries;
  report: SyncReport;
}

export interface SyncEvent {
  ts: number;
  asset: string;
  periodSec: number;
  type:
    | 'state-change'
    | 'history-loaded'
    | 'history-ticks-merged'
    | 'merge'
    | 'gap-detected'
    | 'repair-started'
    | 'repair-done'
    | 'stale-response'
    | 'switch-period'
    | 'switch-asset';
  message: string;
  data?: Record<string, unknown>;
}

export interface SyncReport {
  asset: string;
  periodSec: number;
  state: SyncStateName;
  generation: number;
  latestMarketTimeSec: number;
  closedCount: number;
  formingBucket: number | null;
  historyRange: [number, number] | null;
  liveRange: [number, number] | null;
  overlapBuckets: number;
  lastMerge: MergeStats | null;
  gaps: CandleGap[];
  tickBufferCount: number;
  repairAttempts: number;
  builderStats: ReturnType<CandleBuilder['getStats']>;
}

export interface MergeStats {
  merged: number;
  duplicates: number;
  realigned: number;
  invalid: number;
  priceDropped: number;
  gaps: number;
  overlapBuckets: number;
}

export interface CandleSyncOptions {
  /** Timeframes alimentés en permanence depuis le buffer de ticks (§10). */
  periods?: number[];
  /** Taille du ring buffer de ticks canoniques (~2 ticks/s → 4800 ≈ 40 min). */
  maxTickBuffer?: number;
  /** Nombre max de bougies par série (clôturées). */
  maxCandlesPerSeries?: number;
  /** Callback de clôture — invoqué UNE fois par (asset, period, bougie). */
  onCandleClosed?: (asset: string, periodSec: number, candle: CandleLike) => void;
  /** Callback d'événement de synchronisation (diagnostic §19). */
  onSyncEvent?: (event: SyncEvent) => void;
  /** Mode debug : journalise chaque événement via onSyncEvent. */
  debug?: boolean;
}

// ─────────────────────────────────────────────────────────────────────────────
// État interne
// ─────────────────────────────────────────────────────────────────────────────

interface SeriesState {
  asset: string;
  periodSec: number;
  builder: CandleBuilder;
  state: SyncStateName;
  /** Génération de synchronisation (§16/§17) — incrémentée à chaque switch. */
  generation: number;
  historyRange: [number, number] | null;
  liveRange: [number, number] | null;
  overlapBuckets: number;
  lastMerge: MergeStats | null;
  repairAttempts: number;
}

interface AssetState {
  /** Buffer de ticks canoniques {marketTimeSec, price} — UNE chronologie. */
  ticks: Array<{ time: number; price: number }>;
  /** Dernier temps MARCHÉ vu (ticks) — référence anti-dérive (§7). */
  latestMarketTimeSec: number;
  series: Map<number, SeriesState>;
}

const DEFAULT_PERIODS = [5, 10, 15, 30, 60, 120, 180, 300, 600, 900, 1800, 3600, 14400, 86400];

// ─────────────────────────────────────────────────────────────────────────────
// CandleSyncManager
// ─────────────────────────────────────────────────────────────────────────────

export class CandleSyncManager {
  private readonly periods: number[];
  private readonly maxTickBuffer: number;
  private readonly maxCandlesPerSeries: number;
  private readonly onCandleClosedCb?: CandleSyncOptions['onCandleClosed'];
  private readonly onSyncEventCb?: CandleSyncOptions['onSyncEvent'];
  private debug: boolean;

  private assets = new Map<string, AssetState>();
  /** Contexte actif (§17) : toute réponse historique hors contexte est rejetée. */
  private activeAsset: string | null = null;
  private activePeriod: number | null = null;
  /** Contexte actif MULTI-ASSETS (§17 étendu) : l'ensemble des assets
   *  sélectionnés est actif — chacun peut ingérer son historique. Le
   *  `activeAsset` reste l'asset FOCUS (affiché), `activeAssets` regroupe
   *  tous les assets abonnés et analysés (focus ≠ traitement, §9/§26). */
  private activeAssets: Set<string> | null = null;
  /** 100 derniers événements de sync en mémoire (§19). */
  private recentEvents: SyncEvent[] = [];
  private static readonly MAX_EVENTS = 100;

  constructor(opts: CandleSyncOptions = {}) {
    this.periods = [...new Set(opts.periods ?? DEFAULT_PERIODS)].sort((a, b) => a - b);
    this.maxTickBuffer = opts.maxTickBuffer ?? 4800;
    this.maxCandlesPerSeries = Math.min(300, opts.maxCandlesPerSeries ?? 300);
    this.onCandleClosedCb = opts.onCandleClosed;
    this.onSyncEventCb = opts.onSyncEvent;
    this.debug = opts.debug ?? false;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // TICKS — source de vérité temps marché (§3, §7, §10)
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * Ingest un tick normalisé : alimente le buffer canonique ET TOUS les
   * builders de timeframes (§10 — chaque timeframe calcule SON bucket depuis
   * la MÊME chronologie ; jamais de reconstruction S30 → M1 → M5 en cascade).
   */
  ingestTick(asset: string, tick: TickInput): TickIngestResult {
    const st = this.ensureAsset(asset);
    const t = tick.marketTimeSec;
    const prevLatest = st.latestMarketTimeSec;

    // Anti-rejeu (§8) : un tick rejoué / antérieur au dernier temps marché
    // connu est droppé AVANT toute agrégation.
    if (t <= prevLatest) {
      return { applied: false, reason: 'duplicate' };
    }

    // Buffer canonique (ring) — miroir d'updateHistoryNewFast.
    st.ticks.push({ time: t, price: tick.price });
    st.latestMarketTimeSec = t;
    if (st.ticks.length > this.maxTickBuffer) {
      st.ticks.splice(0, st.ticks.length - this.maxTickBuffer);
    }

    // Plage live (diagnostic §19).
    const s0 = st.ticks[0].time;
    for (const series of st.series.values()) {
      series.liveRange = series.liveRange ? [s0, t] : [t, t];
    }

    // Alimente CHAQUE timeframe avec le MÊME tick (clôtures événementielles
    // via le callback enregistré — UNE fois par (asset, period, bougie)).
    let anyApplied = false;
    let anyLate = false;
    for (const series of st.series.values()) {
      if (series.state === 'DISCONNECTED') series.state = 'BUFFERING_LIVE';
      const updated = series.builder.addTick(t, tick.price);
      if (updated) anyApplied = true;
      else anyLate = anyLate || t > prevLatest;
    }
    return {
      applied: anyApplied,
      reason: anyApplied ? undefined : (anyLate ? 'late' : 'duplicate'),
    };
  }

  // ─────────────────────────────────────────────────────────────────────────
  // HISTORIQUE — normalisation + fusion par bucket (§5, §6, §14, §17)
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * Déclare un chargement d'historique en cours → incrémente la génération si
   * nécessaire et retourne le jeton de génération à transmettre à
   * `ingestHistory` (protection §17 contre les réponses retardées).
   */
  beginHistoryLoad(asset: string, periodSec: number): number {
    const series = this.ensureSeries(asset, periodSec);
    if (series.state !== 'REPAIRING') series.state = 'LOADING_HISTORY';
    return series.generation;
  }

  /**
   * Ingest une réponse d'historique broker :
   *   1. garde de génération (§17) — une réponse obsolète est IGNORÉE ;
   *   2. normalisation : alignement grille + dédup + tri + validation OHLC ;
   *   3. sanitisation prix (défense multi-actifs, en profondeur) ;
   *   4. fusion par bucket avec le buffer de ticks :
   *        - bougies CLÔTURÉES : historique broker (rang 3) > réagrégation
   *          ticks live (rang 2) > cache (rang 1) (§14) ;
   *        - bougie EN FORMATION (bucket courant marché) : ticks LIVE gagnent,
   *          l'historique ne sert que de graine initiale ;
   *   5. seed du builder avec référence = latestMarketTimeSec ;
   *   6. validation finale → SYNCED ou GAP_DETECTED (§13).
   */
  ingestHistory(
    asset: string,
    periodSec: number,
    candles: CandleLike[],
    opts: { generation?: number; source?: SeedSource } = {},
  ): HistoryIngestResult {
    const st = this.ensureAsset(asset);
    const series = this.ensureSeries(asset, periodSec);
    const source: SeedSource = opts.source ?? 'history';

    // §17 — réponse obsolète (changement de timeframe/actif pendant le fetch)
    if (opts.generation !== undefined && opts.generation !== series.generation) {
      this.pushEvent(series, 'stale-response',
        `réponse historique IGNORÉE (génération ${opts.generation} ≠ ${series.generation})`,
        { generation: opts.generation, current: series.generation });
      const report = this.buildReport(series);
      return { accepted: false, reason: 'stale-generation', series: this.getSeries(asset, periodSec), report };
    }
    // §17 — la réponse doit correspondre au CONTEXTE ACTIF (asset + période).
    // MULTI-ASSETS : tous les assets SÉLECTIONNÉS sont actifs (chacun peut
    // ingérer SA réponse d'historique) — l'asset affiché en focus n'est qu'un
    // d'entre eux et ne doit JAMAIS bloquer les autres (§9/§26).
    if (this.activeAssets !== null) {
      if (!this.activeAssets.has(asset)) {
        this.pushEvent(series, 'stale-response',
          `réponse historique IGNORÉE (actif ${asset} hors des ${this.activeAssets.size} assets actifs)`);
        const report = this.buildReport(series);
        return { accepted: false, reason: 'inactive-asset', series: this.getSeries(asset, periodSec), report };
      }
    } else if (this.activeAsset && asset !== this.activeAsset) {
      this.pushEvent(series, 'stale-response',
        `réponse historique IGNORÉE (actif ${asset} ≠ actif actif ${this.activeAsset})`);
      const report = this.buildReport(series);
      return { accepted: false, reason: 'inactive-asset', series: this.getSeries(asset, periodSec), report };
    }
    if (this.activePeriod !== null && this.isAssetActive(asset) && periodSec !== this.activePeriod) {
      this.pushEvent(series, 'stale-response',
        `réponse historique IGNORÉE (période S${periodSec} ≠ timeframe actif S${this.activePeriod})`);
      const report = this.buildReport(series);
      return { accepted: false, reason: 'inactive-period', series: this.getSeries(asset, periodSec), report };
    }

    series.state = 'MERGING';
    this.pushEvent(series, 'state-change', `MERGING (${source}: ${candles.length} bougies reçues)`);

    // 2. Normalisation grille + OHLC.
    const norm = normalizeCandleSeries(candles, periodSec);
    // 3. Sanitisation prix (défense multi-actifs — aucune bougie d'un autre
    //    actif ne peut entrer dans la série canonique).
    const san = sanitizeCandlesByPrice(norm.candles);
    const incoming = san.clean;
    const priceDropped = norm.invalid + san.dropped;

    // 4. Fusion par bucket — CINQ sources hiérarchisées (§14) :
    //
    //      Bougies CLÔTURÉES :  historique broker (3) > état canonique
    //      existant (2.5) > ticks réagrégés (2) > cache (1).
    //      Bougie EN FORMATION : ticks live réagrégés (2) > formation
    //      existante (1.9, d'origine live) > historique (1.5, graine
    //      initiale) > cache (1).
    //
    //    L'état canonique EXISTANT participe à la fusion : une réponse
    //    d'historique PARTIELLE (réparation ciblée d'un trou, §13) complète
    //    la série au lieu de la REMPLACER — les bougies déjà fusionnées
    //    (historique complet, cache 90 j) ne sont jamais perdues.
    const currentBucket = st.latestMarketTimeSec > 0
      ? bucketStart(st.latestMarketTimeSec, periodSec)
      : null;
    const liveCandles = this.reaggregateTicks(st.ticks, periodSec);
    const existingClosed = series.builder.getClosedCandles(this.maxCandlesPerSeries);
    const existingForming = series.builder.getFormingCandle();

    type Entry = { c: CandleLike; rank: number };
    const byTime = new Map<number, Entry>();
    const put = (c: CandleLike, rank: number) => {
      const bucket = bucketStart(c.time, periodSec);
      const isFormingBucket = currentBucket !== null && bucket === currentBucket;
      // Sur le bucket en formation : le live (rank 2 réagrégé) EST la
      // référence — l'historique (rank 3) est rétrogradé (1.5, graine).
      const effRank = isFormingBucket && rank === 3 ? 1.5 : rank;
      const existing = byTime.get(bucket);
      if (!existing || effRank >= existing.rank) {
        byTime.set(bucket, { c: { ...c, time: bucket }, rank: effRank });
      }
    };
    // insertion du plus faible au plus fort (le plus fort écrase au même bucket)
    if (source === 'cache') for (const c of incoming) put(c, 1);
    if (existingForming) put(existingForming, 1.9);
    for (const c of existingClosed) put(c, 2.5);
    for (const c of liveCandles) put(c, 2);
    if (source !== 'cache') for (const c of incoming) put(c, 3);

    const merged = [...byTime.keys()].sort((a, b) => a - b).map(k => byTime.get(k)!.c);

    // Recouvrement historique ↔ live (§6/§19) : buckets communs.
    const liveBuckets = new Set(liveCandles.map(c => bucketStart(c.time, periodSec)));
    const overlapBuckets = incoming.filter(c => liveBuckets.has(c.time)).length;

    // 5. Seed du builder — la référence marché décide seule de la formation.
    const lastCandleTime = merged.length > 0 ? merged[merged.length - 1].time : 0;
    const reference = st.latestMarketTimeSec > 0
      ? st.latestMarketTimeSec
      : lastCandleTime + periodSec; // boot sans live : tout est clôturé
    series.builder.setPeriod(periodSec);
    series.builder.seed(merged, {
      referenceMarketTimeSec: reference,
      periodSec,
      source,
      latestLiveTickTimeSec: st.latestMarketTimeSec > 0 ? st.latestMarketTimeSec : undefined,
    });

    // 6. Validation finale : grille, OHLC, trous.
    //    NOTE : la bougie EN FORMATION participe à la détection de trous —
    //    l'écart entre la dernière clôturée et la formation (couture
    //    historique ↔ live, §5/§6) est un VRAI trou si > 1 période.
    const finalCandles = series.builder.getClosedCandles(this.maxCandlesPerSeries);
    const forming = series.builder.getFormingCandle();
    const fullSeries = forming ? [...finalCandles, forming] : finalCandles;
    const invalidFinal = fullSeries.filter(c => !isOhlcValid(c)).length;
    const gaps = findGaps(fullSeries, periodSec);

    series.historyRange = incoming.length > 0
      ? [incoming[0].time, incoming[incoming.length - 1].time]
      : series.historyRange;
    series.overlapBuckets = overlapBuckets;
    series.lastMerge = {
      merged: merged.length,
      duplicates: norm.duplicates,
      realigned: norm.realigned,
      invalid: priceDropped,
      priceDropped,
      gaps: gaps.length,
      overlapBuckets,
    };
    series.state = gaps.length > 0 ? 'GAP_DETECTED' : 'SYNCED';

    this.pushEvent(series, gaps.length > 0 ? 'gap-detected' : 'history-loaded',
      gaps.length > 0
        ? `SYNC=${series.state} — ${gaps.length} trou(s) détecté(s) (${gaps.reduce((a, g) => a + g.missingCandles, 0)} bougies manquantes)`
        : `SYNCED — ${merged.length} bougies canoniques, recouvrement=${overlapBuckets} buckets`,
      {
        historyRange: series.historyRange,
        liveRange: series.liveRange,
        overlapBuckets,
        merged: merged.length,
        duplicates: norm.duplicates,
        realigned: norm.realigned,
        invalid: priceDropped + invalidFinal,
        gaps: gaps.length,
        // v6.5 — DÉTAILS des trous (position exacte) pour le vieillissement
        // par position dans MarketDataHealth (recent vs aged) : chaque trou
        // porte startTime/endTime/missingCandles (findGaps, §13).
        gapDetails: gaps.map(g => ({
          startTime: g.startTime,
          endTime: g.endTime,
          missingCandles: g.missingCandles,
          periodSec: g.periodSec,
        })),
        formingBucket: forming?.time ?? null,
        latestMarketTime: st.latestMarketTimeSec,
        status: series.state,
      });

    return {
      accepted: true,
      series: { closed: finalCandles, forming },
      report: this.buildReport(series),
    };
  }

  // ─────────────────────────────────────────────────────────────────────────
  // CHANGEMENTS DE CONTEXTE (§11, §16, §17)
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * Changement d'actif : purge le buffer de ticks canonique (les ticks de
   * l'ancien actif ne doivent JAMAIS contaminer le nouveau) et remet toutes
   * les série à DISCONNECTED. Incrémente la génération → toute réponse
   * historique en vol pour l'ancien actif sera ignorée.
   */
  switchAsset(asset: string): void {
    const st = this.ensureAsset(asset);
    st.ticks = [];
    st.latestMarketTimeSec = 0;
    for (const series of st.series.values()) {
      series.generation++;
      series.state = 'DISCONNECTED';
      series.builder.reset();
      series.historyRange = null;
      series.liveRange = null;
      series.overlapBuckets = 0;
      series.lastMerge = null;
      series.repairAttempts = 0;
    }
    this.activeAsset = asset;
    this.activePeriod = null;
    this.pushEvent({ asset, periodSec: 0 }, 'switch-asset',
      `actif → ${asset} (buffer purgé, générations invalidées)`);
  }

  /**
   * Changement de timeframe (§11) — SANS saut temporel :
   *   1. gèle la référence : switchMarketTime = latestMarketTimeSec ;
   *   2. le builder du NOUVEAU timeframe est DÉJÀ chaud (alimenté en continu
   *      par le même buffer de ticks, §10) ; s'il est froid (période
   *      non configurée), il est réagrégé depuis le buffer ;
   *   3. incrémente la génération → les réponses historiques de l'ANCIEN
   *      timeframe sont ignorées (§17) ;
   *   4. retourne la série partielle (émission instantanée < 1 s).
   */
  switchPeriod(asset: string, periodSec: number): CandleSeries {
    const st = this.ensureAsset(asset);
    const series = this.ensureSeries(asset, periodSec);
    series.generation++;
    this.activeAsset = asset;
    this.activePeriod = periodSec;

    const switchMarketTime = st.latestMarketTimeSec;
    if (series.builder.getCandles().length === 0 && st.ticks.length > 0) {
      // Série froide : ré-agrégation depuis le buffer de ticks avec la
      // référence gelée au moment du switch (§11).
      const reagg = this.reaggregateTicks(st.ticks, periodSec);
      series.builder.setPeriod(periodSec);
      series.builder.seed(reagg, {
        referenceMarketTimeSec: switchMarketTime,
        periodSec,
        source: 'reaggregated-ticks',
        latestLiveTickTimeSec: switchMarketTime,
      });
      if (series.state === 'DISCONNECTED') series.state = 'BUFFERING_LIVE';
    }

    this.pushEvent(series, 'switch-period',
      `timeframe → S${periodSec} (réf. marché gelée @ ${switchMarketTime}, série: ` +
      `${series.builder.getClosedCandles().length} clôturées + forming=${series.builder.getFormingCandle()?.time ?? '∅'})`,
      { switchMarketTime });

    return {
      closed: series.builder.getClosedCandles(this.maxCandlesPerSeries),
      forming: series.builder.getFormingCandle(),
    };
  }

  /**
   * Demande de réparation d'un gap (§13/§16). Autorisée UNIQUEMENT depuis
   * GAP_DETECTED (jamais deux réparations concurrentes ; max 3 tentatives
   * par série). Retourne la génération à transmettre à ingestHistory.
   */
  requestRepair(asset: string, periodSec: number): { started: boolean; generation: number; gaps: CandleGap[] } {
    const series = this.ensureSeries(asset, periodSec);
    const closed = series.builder.getClosedCandles(this.maxCandlesPerSeries);
    const forming = series.builder.getFormingCandle();
    const gaps = findGaps(forming ? [...closed, forming] : closed, periodSec);
    if (series.state !== 'GAP_DETECTED' || gaps.length === 0) {
      return { started: false, generation: series.generation, gaps };
    }
    if (series.repairAttempts >= 3) {
      this.pushEvent(series, 'repair-done',
        `réparation ABANDONNÉE après ${series.repairAttempts} tentatives (${gaps.length} trou(s) restants)`);
      return { started: false, generation: series.generation, gaps };
    }
    series.repairAttempts++;
    series.state = 'REPAIRING';
    series.generation++;
    this.pushEvent(series, 'repair-started',
      `REPAIRING — tentative ${series.repairAttempts}/3 : ${gaps.length} trou(s), ` +
      `${gaps.reduce((a, g) => a + g.missingCandles, 0)} bougies à récupérer`,
      { gaps });
    return { started: true, generation: series.generation, gaps };
  }

  /** Abandonne une réparation en échec (fetch réseau raté) → retour à GAP_DETECTED. */
  abortRepair(asset: string, periodSec: number): void {
    const series = this.ensureSeries(asset, periodSec);
    if (series.state === 'REPAIRING') {
      series.state = 'GAP_DETECTED';
      this.pushEvent(series, 'repair-done', 'réparation interrompue (fetch échoué) → GAP_DETECTED');
    }
  }

  /**
   * v6.10 — Ingestion du snapshot `updateHistoryNewFast` (ticks du broker).
   *
   * LE protocole Pocket Option (HAR fix_gaps.har) : après chaque
   * `changeSymbol`, le broker pousse ~1300-1600 ticks couvrant ~12 minutes,
   * CONTIGUS avec le flux `updateStream` qui suit. C'est la graine
   * d'historique RAPIDE de chaque asset — elle rend un asset LIVE en < 1 s
   * sans attendre la pagination `loadHistoryPeriod` (lente, ~150
   * bougies/batch, file de concurrence 4 → minutes en multi-assets 24).
   *
   * Méthode :
   *   1. fusionne les ticks dans le buffer canonique (tri + dédoublonnage
   *      par timestamp EXACT — les ticks historiques peuvent précéder le
   *      dernier tick live, on NE les rejette PAS, on fusionne) ;
   *   2. met à jour latestMarketTimeSec + la plage live ;
   *   3. ré-agrège puis re-seed les builders de TOUS les timeframes de CET
   *      asset depuis le buffer enrichi (graine 'reaggregated-ticks',
   *      référence = dernier tick marché) — aucun callback de clôture n'est
   *   émis par le seed (pas de double-évaluation coach/BOS) ;
   *   4. l'état des séries repasse par BUFFERING_LIVE — la validation des
   *      trous (findGaps) se fait à la prochaine ingestHistory/validate,
   *      quand l'historique profond aura fusionné.
   *
   * La période annoncée par le broker est IGNORÉE : les ticks sont
   * période-agnostiques, chaque timeframe agrège depuis la même chronologie.
   */
  ingestHistoryTicks(
    asset: string,
    ticks: ReadonlyArray<{ time: number; price: number }>,
  ): { merged: number; duplicates: number; firstTickSec: number; lastTickSec: number } {
    const st = this.ensureAsset(asset);
    if (ticks.length === 0) {
      return { merged: st.ticks.length, duplicates: 0, firstTickSec: 0, lastTickSec: 0 };
    }

    // 1. Fusion tri + dédoublonnage (timestamp exact) dans le buffer.
    const byTime = new Map<number, number>();
    for (const t of st.ticks) byTime.set(t.time, t.price);
    let duplicates = 0;
    let invalid = 0;
    for (const t of ticks) {
      if (!Number.isFinite(t.time) || !Number.isFinite(t.price) || t.price <= 0) {
        invalid++;
        continue;
      }
      if (byTime.has(t.time)) {
        duplicates++;
        continue; // le tick live du même timestamp fait foi
      }
      byTime.set(t.time, t.price);
    }
    let mergedTicks = [...byTime.entries()]
      .sort((a, b) => a[0] - b[0])
      .map(([time, price]) => ({ time, price }));
    if (mergedTicks.length > this.maxTickBuffer) {
      mergedTicks = mergedTicks.slice(mergedTicks.length - this.maxTickBuffer);
    }
    st.ticks = mergedTicks;

    const firstTickSec = mergedTicks.length > 0 ? mergedTicks[0].time : 0;
    const lastTickSec = mergedTicks.length > 0 ? mergedTicks[mergedTicks.length - 1].time : 0;
    // Le snapshot peut contenir des ticks PLUS RÉCENTS que le dernier vu
    // (horloge/dérive) — latestMarketTimeSec = MAX de la chronologie fusionnée.
    st.latestMarketTimeSec = Math.max(st.latestMarketTimeSec, lastTickSec);

    // 2. Plage live (diagnostic §19).
    if (firstTickSec > 0) {
      for (const series of st.series.values()) {
        series.liveRange = [firstTickSec, lastTickSec];
      }
    }

    // 3. Re-seed des builders de TOUS les timeframes depuis le buffer.
    for (const series of st.series.values()) {
      const reagg = this.reaggregateTicks(mergedTicks, series.periodSec);
      series.builder.setPeriod(series.periodSec);
      series.builder.seed(reagg, {
        referenceMarketTimeSec: st.latestMarketTimeSec,
        periodSec: series.periodSec,
        source: 'reaggregated-ticks',
        latestLiveTickTimeSec: st.latestMarketTimeSec,
      });
      if (series.state === 'DISCONNECTED' || series.state === 'LOADING_HISTORY') {
        series.state = 'BUFFERING_LIVE';
      }
      // v6.10.1 — type d'événement DÉDIÉ 'history-ticks-merged' (plus 'history-loaded') :
      // le dispatch backend (applySyncGapsToHealth) branchait le fallback
      // « legacy » sur les événements history-loaded SANS gapDetails → 4 FAUX
      // trous bloquants par snapshot (un par timeframe) → pénalité de score
      // → CRITICAL_GAP après 2 reconnexions (4+4 faux trous > 5 = critical).
      // Une fusion de ticks n'est PAS une détection de trous : cet événement
      // ne déclenche plus la mise à jour des gaps de santé.
      this.pushEvent(series, 'history-ticks-merged',
        `snapshot updateHistoryNewFast fusionné : ${ticks.length} ticks reçus ` +
        `(${duplicates} doublons, ${invalid} invalides), buffer=${mergedTicks.length}, ` +
        `re-seed S${series.periodSec} (${reagg.length} bougies)`,
        {
          received: ticks.length,
          duplicates,
          invalid,
          tickBufferCount: mergedTicks.length,
          firstTickSec,
          lastTickSec,
        });
    }

    return { merged: mergedTicks.length, duplicates, firstTickSec, lastTickSec };
  }

  /**
   * Déclare le contexte actif (asset + timeframe graphique) SANS toucher aux
   * générations — utilisé au login / sélection de marché pour que la garde
   * §17 d'ingestHistory connaisse le contexte dès la première seconde.
   */
  setActiveContext(asset: string, periodSec: number | null): void {
    this.activeAsset = asset;
    this.activePeriod = periodSec;
    this.activeAssets = new Set([asset]);
  }

  /**
   * Déclare le contexte actif MULTI-ASSETS (§9/§26) : l'ensemble des assets
   * sélectionnés est ACTIF (historiques acceptés pour chacun), le premier
   * (ou `focusAsset`) étant l'asset affiché. Le focus ne bloque JAMAIS le
   * traitement des autres assets.
   */
  setActiveAssets(assets: string[], periodSec: number | null, focusAsset?: string): void {
    this.activeAssets = new Set(assets);
    this.activeAsset = focusAsset && assets.includes(focusAsset) ? focusAsset : assets[0] ?? null;
    this.activePeriod = periodSec;
  }

  /** L'asset fait-il partie du contexte actif (mono ou multi) ? */
  isAssetActive(asset: string): boolean {
    if (this.activeAssets !== null) return this.activeAssets.has(asset);
    return this.activeAsset === asset;
  }

  /**
   * Supprime TOUT l'état d'un asset désélectionné (§30 — arrêt d'un asset) :
   * buffer de ticks + toutes les séries libérés de la mémoire. N'affecte
   * JAMAIS les autres assets.
   */
  purgeAsset(asset: string): void {
    const existed = this.assets.delete(asset);
    if (this.activeAssets) this.activeAssets.delete(asset);
    if (this.activeAsset === asset) this.activeAsset = null;
    if (existed) {
      this.pushEvent({ asset, periodSec: 0 }, 'switch-asset',
        `actif ${asset} supprimé du synchroniseur (mémoire libérée)`);
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // LECTURES
  // ─────────────────────────────────────────────────────────────────────────

  /** Ensure that a timeframe series exists before the next live tick arrives.
   * This is important for event-driven strategies when the chart switches to
   * a timeframe that was not part of the original static period list.
   */
  ensurePeriod(asset: string, periodSec: number): void {
    this.ensureSeries(asset, periodSec)
  }

  getSeries(asset: string, periodSec: number): CandleSeries {
    const series = this.ensureSeries(asset, periodSec);
    return {
      closed: series.builder.getClosedCandles(this.maxCandlesPerSeries),
      forming: series.builder.getFormingCandle(),
    };
  }

  /** Série complète (clôturées + formation) — ordre du graphique. */
  getAllCandles(asset: string, periodSec: number): CandleLike[] {
    const series = this.ensureSeries(asset, periodSec);
    return series.builder.getCandles();
  }

  getClosed(asset: string, periodSec: number, n = 100): CandleLike[] {
    return this.ensureSeries(asset, periodSec).builder.getClosedCandles(n);
  }

  getForming(asset: string, periodSec: number): CandleLike | null {
    return this.ensureSeries(asset, periodSec).builder.getFormingCandle();
  }

  getLatestMarketTimeSec(asset: string): number {
    return this.assets.get(asset)?.latestMarketTimeSec ?? 0;
  }

  /**
   * v6.10 — Premier tick du segment live CONTIGU (début du buffer canonique).
   *
   * Le broker OTC ne génère des ticks que lorsqu'un asset est actif quelque
   * part : l'historique paginé peut donc s'arrêter AVANT le début du segment
   * live. Le trou [fin historique, premier tick] est une LIMITE DE SOURCE
   * (couture), PAS une perte de données — la classification de couture de
   * MarketDataHealth compare la FIN d'un trou à CE début de segment.
   */
  getFirstLiveTickSec(asset: string): number {
    const ticks = this.assets.get(asset)?.ticks;
    return ticks && ticks.length > 0 ? ticks[0].time : 0;
  }

  getTickBuffer(asset: string): ReadonlyArray<{ time: number; price: number }> {
    return this.assets.get(asset)?.ticks ?? [];
  }

  getGeneration(asset: string, periodSec: number): number {
    return this.ensureSeries(asset, periodSec).generation;
  }

  validate(asset: string, periodSec: number): SyncReport {
    const series = this.ensureSeries(asset, periodSec);
    const report = this.buildReport(series);
    if (report.gaps.length > 0 && series.state === 'SYNCED') {
      series.state = 'GAP_DETECTED';
      this.pushEvent(series, 'gap-detected', `${report.gaps.length} trou(s) détecté(s) à la validation`, {
        // v6.5 — détails des trous (position) pour MarketDataHealth.
        gapDetails: report.gaps.map(g => ({
          startTime: g.startTime,
          endTime: g.endTime,
          missingCandles: g.missingCandles,
          periodSec: g.periodSec,
        })),
      });
      return this.buildReport(series);
    }
    return report;
  }

  getSyncReport(asset: string, periodSec?: number): SyncReport {
    if (periodSec !== undefined) return this.buildReport(this.ensureSeries(asset, periodSec));
    const st = this.assets.get(asset);
    if (!st) return this.buildReport(this.ensureSeries(asset, this.periods[0]));
    const first = [...st.series.values()][0];
    return this.buildReport(first ?? this.ensureSeries(asset, this.periods[0]));
  }

  /** Tous les rapports d'un actif (diagnostic par timeframe). */
  getAllReports(asset: string): SyncReport[] {
    const st = this.assets.get(asset);
    if (!st) return [];
    return [...st.series.values()].map(s => this.buildReport(s));
  }

  getRecentSyncEvents(n = 100): SyncEvent[] {
    return this.recentEvents.slice(-n);
  }

  setDebug(debug: boolean): void {
    this.debug = debug;
  }

  getStats(): {
    periods: number[];
    assets: Array<{ asset: string; latestMarketTimeSec: number; tickBufferCount: number; series: Array<{ periodSec: number; state: SyncStateName }> }>;
  } {
    return {
      periods: [...this.periods],
      assets: [...this.assets.entries()].map(([asset, st]) => ({
        asset,
        latestMarketTimeSec: st.latestMarketTimeSec,
        tickBufferCount: st.ticks.length,
        series: [...st.series.values()].map(s => ({ periodSec: s.periodSec, state: s.state })),
      })),
    };
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Internes
  // ─────────────────────────────────────────────────────────────────────────

  private ensureAsset(asset: string): AssetState {
    let st = this.assets.get(asset);
    if (!st) {
      st = { ticks: [], latestMarketTimeSec: 0, series: new Map() };
      this.assets.set(asset, st);
      // Crée TOUTES les séries configurées → chaque tick alimente tous les
      // timeframes dès la première seconde (§10).
      for (const p of this.periods) this.ensureSeries(asset, p, st);
    }
    return st;
  }

  private ensureSeries(asset: string, periodSec: number, assetState?: AssetState): SeriesState {
    const st = assetState ?? this.ensureAsset(asset);
    let series = st.series.get(periodSec);
    if (!series) {
      const builder = new CandleBuilder(periodSec, { maxCandles: this.maxCandlesPerSeries });
      // Clôture événementielle : UNE invocation par bougie, propagée au
      // consommateur (coach/stratégies) avec son (asset, period).
      builder.setOnCandleClosed((candle) => this.fireClosed(asset, periodSec, candle));
      series = {
        asset,
        periodSec,
        builder,
        state: 'DISCONNECTED',
        generation: 0,
        historyRange: null,
        liveRange: null,
        overlapBuckets: 0,
        lastMerge: null,
        repairAttempts: 0,
      };
      st.series.set(periodSec, series);
    }
    return series;
  }

  /** Ré-agrège le buffer de ticks canonique à la période demandée. */
  private reaggregateTicks(ticks: ReadonlyArray<{ time: number; price: number }>, periodSec: number): CandleLike[] {
    const out: CandleLike[] = [];
    let cur: CandleLike | null = null;
    for (const t of ticks) {
      const bucket = bucketStart(t.time, periodSec);
      if (!cur || cur.time !== bucket) {
        if (cur) out.push(cur);
        cur = { time: bucket, open: t.price, high: t.price, low: t.price, close: t.price, volume: 1 };
      } else {
        cur.high = Math.max(cur.high, t.price);
        cur.low = Math.min(cur.low, t.price);
        cur.close = t.price;
        cur.volume = (cur.volume ?? 0) + 1;
      }
    }
    if (cur) out.push(cur);
    return out;
  }

  private fireClosed(asset: string, periodSec: number, candle: CandleLike): void {
    if (!this.onCandleClosedCb) return;
    try {
      this.onCandleClosedCb(asset, periodSec, { ...candle });
    } catch { /* best-effort — jamais casser le pipeline de ticks */ }
  }

  private buildReport(series: SeriesState): SyncReport {
    const st = this.assets.get(series.asset);
    const closed = series.builder.getClosedCandles(this.maxCandlesPerSeries);
    const forming = series.builder.getFormingCandle();
    return {
      asset: series.asset,
      periodSec: series.periodSec,
      state: series.state,
      generation: series.generation,
      latestMarketTimeSec: st?.latestMarketTimeSec ?? 0,
      closedCount: closed.length,
      formingBucket: forming?.time ?? null,
      historyRange: series.historyRange,
      liveRange: series.liveRange,
      overlapBuckets: series.overlapBuckets,
      lastMerge: series.lastMerge,
      // Trous calculés sur la série COMPLÈTE (clôturées + formation) : la
      // couture historique ↔ live est un vrai trou si > 1 période (§5/§6).
      gaps: findGaps(forming ? [...closed, forming] : closed, series.periodSec),
      tickBufferCount: st?.ticks.length ?? 0,
      repairAttempts: series.repairAttempts,
      builderStats: series.builder.getStats(),
    };
  }

  private pushEvent(series: { asset: string; periodSec: number }, type: SyncEvent['type'], message: string, data?: Record<string, unknown>): void {
    const event: SyncEvent = {
      ts: Date.now(),
      asset: series.asset,
      periodSec: series.periodSec,
      type,
      message,
      data,
    };
    this.recentEvents.push(event);
    if (this.recentEvents.length > CandleSyncManager.MAX_EVENTS) {
      this.recentEvents.splice(0, this.recentEvents.length - CandleSyncManager.MAX_EVENTS);
    }
    if (this.debug || type !== 'state-change') {
      this.onSyncEventCb?.(event);
    }
  }
}
