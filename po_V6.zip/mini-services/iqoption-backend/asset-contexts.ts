/**
 * asset-contexts.ts — CŒUR MULTI-ASSETS : contextes de trading indépendants.
 * =====================================================================
 *
 * RÈGLE ARCHITECTURALE ABSOLUE (§5/§6 du cahier des charges multi-assets) :
 *   Chaque asset sélectionné possède son PROPRE contexte de trading :
 *     - son propre état Martingale                 → ctx.betting.consecutiveLosses
 *     - son propre état Fibonacci                  → ctx.betting.fibIndex
 *     - ses propres stats W/L                      → ctx.stats
 *     - ses propres deals suivis                   → ctx.trackedDeals
 *     - ses propres positions ouvertes              → ctx.openPositions
 *     - son propre état Auto Trade                 → ctx.autoTrade
 *
 *   ISOLATION TOTALE : une perte sur EURUSD ne modifie JAMAIS l'état de mise
 *   de XAUUSD ou BTCUSD. Un signal d'un asset n'est JAMAIS appliqué à un
 *   autre asset. Cf. tests/test-multi-assets.ts (TEST 4/5/8 + test de
 *   non-contamination §36).
 *
 * Module PUR (aucune dépendance socket/io) — testable isolément :
 *   - index.ts (serveur socket.io) l'utilise via `registry` ;
 *   - tests/test-multi-assets.ts valide l'isolation sans serveur.
 */

import { getMarket, type MarketInfo } from './markets-catalog.js';
import type { OpenedDeal } from './pocket-option-sdk/src/index.js';

// ---------------------------------------------------------------------------
//  Constantes
// ---------------------------------------------------------------------------

/** Nombre maximum d'assets tradés simultanément.
 *  v6.3 : 24 (10 + 14 supplémentaires demandés par l'utilisateur). */
export const MAX_SELECTED_ASSETS = 24;

/** Paliers Fibonacci pour la stratégie de mise fibonacci (§15). */
export const FIBONACCI_STEPS = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55];

/** Facteur fixe de progression Martingale demandé par Auto Trade : perte → ×2. */
export const MARTINGALE_MULTIPLIER = 2;

/**
 * v19 — Borne haute du nombre de doublements Martingale (garde-fou risques).
 * 0 = ILLIMITÉ (comportement historique inchangé).
 * Stocké PAR ASSET dans ctx.betting.maxMartingaleSteps (comme les autres
 * états de mise) mais piloté par la config de session : tous les contextes
 * reçoivent la même valeur (règle de risque globale de la session).
 */
export const MAX_MARTINGALE_STEPS_LIMIT = 1000;

/** Stratégies de mise supportées. */
export type BettingStrategy = 'fixed' | 'martingale' | 'fibonacci';

/** Mode de trading de la session. */
export type TradingMode = 'single' | 'multi';

/** Configuration de sélection des assets (source de vérité de la session, §4). */
export interface TradingModeConfig {
  mode: TradingMode;
  /** Assets actifs — 1 (single) à 10 (multi), sans doublons. */
  assets: string[];
  /** Asset affiché/focus — n'ARRÊTE JAMAIS le traitement des autres (§26). */
  focus: string | null;
}

// ---------------------------------------------------------------------------
//  AssetTradingContext (§5)
// ---------------------------------------------------------------------------

/** État de mise par asset — Martingale + Fibonacci isolées (§14/§15/§16). */
export interface AssetBettingState {
  /** Mise de base ($). */
  baseAmount: number;
  /** Pertes consécutives de CET asset (martingale). */
  consecutiveLosses: number;
  /** Index Fibonacci courant de CET asset. */
  fibIndex: number;
  /**
   * v19/v20 — Garde-fou Martingale : nombre MAXIMAL de mises dans la
   * séquence de Martingale pour CET asset. 0 = illimité (comportement
   * historique). Ex. 4 avec base 10 : mises 10 → 20 → 40 → 80 (4 mises) ;
   * si l'ordre de 80 perd, RETOUR À LA MISE INITIALE (10) au lieu de 160.
   * Ne concerne QUE la Martingale — Fibonacci est pilotée par fibIndex.
   */
  maxMartingaleSteps: number;
}

/** État Auto Trade par asset (§13). */
export interface AssetAutoTradeState {
  /** Auto Trade actif pour CET asset (indépendant des autres). */
  enabled: boolean;
  /** Horodatage (ms) du dernier trade placé sur cet asset (patience/cooldown). */
  lastTradeTs: number;
  /** Dernière action demandée sur cet asset ('call' | 'put') — corrige
   *  l'absence du champ action dans les réponses broker SANS contaminer
   *  les autres assets. */
  lastTradeAction: 'call' | 'put' | null;
  /** v20 — Auto Switch Assets : résultat du DERNIER ordre réglé de CET
   *  asset. true = gain, false = perte/tie, null = aucun ordre réglé.
   *  Le switch automatique ne quitte un asset QUE si son dernier ordre
   *  est un GAIN (jamais au milieu d'une Martingale en récupération). */
  lastOrderWin: boolean | null;
}

/** Stats de trading par asset (§18/§19). */
export interface AssetStats {
  signals: number;
  trades: number;
  wins: number;
  losses: number;
  /**
   * v17 — règlements NEUTRES (Tie/Refund, P&L = 0 $) : ni gain ni perte.
   * Un trade neutre n'augmente JAMAIS l'index de la suite de mises
   * (consecutiveLosses/fibIndex inchangés — le niveau de mise courant est
   * conservé pour l'ordre suivant).
   */
  pushes: number;
}

/** Deal suivi par le moteur d'auto-trade (§17). */
export interface TrackedDeal {
  asset: string;
  amount: number;
  expirationSeconds: number;
  /** Empreinte du fill broker — rattachement des règlements quand le broker
   * publie le deal fermé avec un id DIFFÉRENT de celui de l'ouverture
   * (comportement réel observé : UUID à l'ouverture, id numérique à la
   * clôture, publication paresseuse via updateClosedDeals). */
  openPrice?: number;
  /** Heure d'ouverture du fill (unix secondes broker). */
  openTime?: number;
  /** Direction demandée ('call' | 'put'). */
  action?: 'call' | 'put';
  /** Horodatage LOCAL (ms) du placement — ancre GARANTIE du watchdog de
   *  règlement quand le broker ne renvoie ni openTime ni openPrice. */
  placedAtMs?: number;
}

/**
 * Contexte de trading INDÉPENDANT par asset (§5 du cahier des charges).
 *
 * AUCUN de ces champs n'est partagé entre assets : le registre
 * (`AssetContextRegistry`) garantit un contexte unique par asset et
 * `assertAssetContext` vérifie l'intégrité asset ↔ contexte dans les
 * traitements critiques (§32).
 */
export interface AssetTradingContext {
  asset: string;
  market: MarketInfo;

  /** Stratégie de mise de CET asset. */
  bettingStrategy: BettingStrategy;
  betting: AssetBettingState;

  autoTrade: AssetAutoTradeState;

  /** Dernière bougie traitée — évite le double traitement (§28). */
  candleState: { lastProcessedCandleTime: number };

  stats: AssetStats;

  /** Deals placés par l'auto-trade de CET asset → suivi win/loss (§17). */
  trackedDeals: Map<string, TrackedDeal>;

  /** Ordres auto-trade en vol avant réception du dealId broker. Sert à ne pas perdre
   * le résultat d'un trade très court si `deal_closed` arrive avant `openOrder()`
   * n'ait fini son await. */
  pendingBettingOrders: Array<{ submittedAt: number; amount: number; expirationSeconds: number; strategyId: string; action?: 'call' | 'put' }>;

  /** Positions ouvertes de CET asset (miroir filtré de session.openedDeals,
   *  maintenues via noteDealOpened/noteDealClosed). */
  openPositions: OpenedDeal[];

  /** Horodatage de création du contexte. */
  createdAt: number;
}

// ---------------------------------------------------------------------------
//  Vérification d'intégrité (§32)
// ---------------------------------------------------------------------------

/**
 * Vérifie que le contexte appartient bien à l'asset attendu.
 * À utiliser dans les traitements critiques : ouverture/fermeture de trade,
 * calcul de mise, signal, mise à jour marché, Martingale, Fibonacci.
 */
export function assertAssetContext(asset: string, ctx: AssetTradingContext | null | undefined): AssetTradingContext {
  if (!ctx) {
    throw new Error(`Asset context mismatch: no context for ${asset}`);
  }
  if (ctx.asset !== asset) {
    throw new Error(`Asset context mismatch: expected ${asset}, got ${ctx.asset}`);
  }
  if (ctx.market.name !== asset) {
    throw new Error(`Asset context mismatch: market ${ctx.market.name} ≠ asset ${asset}`);
  }
  return ctx;
}

// ---------------------------------------------------------------------------
//  Création de contexte
// ---------------------------------------------------------------------------

export interface CreateAssetContextOptions {
  bettingStrategy?: BettingStrategy;
  baseAmount?: number;
  /** v19/v20 — Garde-fou Martingale : nombre MAXIMAL de mises dans la
   * séquence (0 = illimité). Ex. 4, base 10 : 10→20→40→80 puis retour. */
  maxMartingaleSteps?: number;
  autoTradeEnabled?: boolean;
  /** Override MarketInfo (ex. enrichi par les données live du SDK). */
  market?: MarketInfo;
}

/** Clamp du garde-fou Martingale : entier [0, 1000] (0 = illimité, NaN → 0). */
export function clampMaxMartingaleSteps(v: unknown): number {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) return 0;
  return Math.min(MAX_MARTINGALE_STEPS_LIMIT, Math.floor(n));
}

/** Crée un contexte de trading COMPLET pour un asset (états de mise vierges). */
export function createAssetContext(
  asset: string,
  opts: CreateAssetContextOptions = {},
): AssetTradingContext {
  const market = opts.market ?? getMarket(asset);
  const baseAmount = opts.baseAmount ?? 1;

  return {
    asset,
    market,
    bettingStrategy: opts.bettingStrategy ?? 'fixed',
    betting: {
      baseAmount,
      consecutiveLosses: 0,
      fibIndex: 0,
      maxMartingaleSteps: clampMaxMartingaleSteps(opts.maxMartingaleSteps),
    },
    autoTrade: {
      enabled: opts.autoTradeEnabled ?? false,
      lastTradeTs: 0,
      lastTradeAction: null,
      lastOrderWin: null,
    },
    candleState: { lastProcessedCandleTime: 0 },
    stats: { signals: 0, trades: 0, wins: 0, losses: 0, pushes: 0 },
    trackedDeals: new Map<string, TrackedDeal>(),
    pendingBettingOrders: [],
    openPositions: [],
    createdAt: Date.now(),
  };
}

// ---------------------------------------------------------------------------
//  Registre de contextes (§5 : assetContexts = Map<string, AssetTradingContext>)
// ---------------------------------------------------------------------------

/**
 * Registre central des contextes par asset.
 * `getAssetContext(asset)` retourne TOUJOURS le contexte unique de l'asset.
 */
export class AssetContextRegistry {
  private contexts = new Map<string, AssetTradingContext>();
  /** Markets live (SDK updateAssets) pour enrichir les MarketInfo. */
  private liveMarkets = new Map<string, MarketInfo>();

  /** Contexte unique de l'asset (null si non sélectionné). */
  getAssetContext(asset: string): AssetTradingContext | null {
    return this.contexts.get(asset) ?? null;
  }

  /** Contexte unique de l'asset — THROW si absent (traitements critiques). */
  requireAssetContext(asset: string): AssetTradingContext {
    const ctx = this.contexts.get(asset);
    if (!ctx) throw new Error(`Asset context mismatch: no context for ${asset}`);
    return assertAssetContext(asset, ctx);
  }

  has(asset: string): boolean {
    return this.contexts.has(asset);
  }

  /** Crée (ou remplace) le contexte d'un asset. */
  ensureAssetContext(asset: string, opts: CreateAssetContextOptions = {}): AssetTradingContext {
    const market = opts.market ?? this.liveMarkets.get(asset) ?? getMarket(asset);
    const existing = this.contexts.get(asset);
    if (existing) {
      // Contexte déjà présent : met à jour la config légère sans détruire
      // les états de mise/stats en cours (l'asset reste le même).
      if (opts.bettingStrategy) existing.bettingStrategy = opts.bettingStrategy;
      if (opts.baseAmount != null) existing.betting.baseAmount = opts.baseAmount;
      if (opts.maxMartingaleSteps != null) existing.betting.maxMartingaleSteps = clampMaxMartingaleSteps(opts.maxMartingaleSteps);
      if (opts.autoTradeEnabled != null) existing.autoTrade.enabled = opts.autoTradeEnabled;
      return existing;
    }
    const ctx = createAssetContext(asset, { ...opts, market });
    this.contexts.set(asset, ctx);
    return ctx;
  }

  /**
   * Supprime le contexte d'un asset (§30 — arrêt d'un asset) :
   * - arrête son Auto Trade ;
   * - nettoie trackedDeals + openPositions ;
   * - SUPPRIME les moteurs de l'asset (libération mémoire) ;
   * - n'affecte JAMAIS les autres contextes.
   */
  removeAssetContext(asset: string): boolean {
    const ctx = this.contexts.get(asset);
    if (!ctx) return false;
    ctx.autoTrade.enabled = false;
    ctx.trackedDeals.clear();
    ctx.openPositions.length = 0;
    this.contexts.delete(asset);
    return true;
  }

  /** Supprime tous les contextes sauf ceux listés (déselection en masse). */
  retainOnly(assets: string[]): void {
    const keep = new Set(assets);
    for (const asset of [...this.contexts.keys()]) {
      if (!keep.has(asset)) this.removeAssetContext(asset);
    }
  }

  clear(): void {
    for (const asset of [...this.contexts.keys()]) {
      this.removeAssetContext(asset);
    }
  }

  /** Liste des assets actifs (ordre d'insertion). */
  assets(): string[] {
    return [...this.contexts.keys()];
  }

  get size(): number {
    return this.contexts.size;
  }

  /** Itère tous les contextes actifs. */
  entries(): Array<[string, AssetTradingContext]> {
    return [...this.contexts.entries()];
  }

  /** Enregistre un MarketInfo live (SDK updateAssets). */
  setLiveMarket(asset: string, market: MarketInfo): void {
    this.liveMarkets.set(asset, market);
    const ctx = this.contexts.get(asset);
    if (ctx && market.name === asset) ctx.market = market;
  }
}

// ---------------------------------------------------------------------------
//  Calcul de mise — déterministe à partir du contexte UNIQUEMENT (§16)
// ---------------------------------------------------------------------------

/**
 * Calcule le montant de la prochaine mise pour CET asset.
 * Déterministe à partir de : ctx.bettingStrategy, ctx.betting.baseAmount,
 * ctx.betting.consecutiveLosses, ctx.betting.fibIndex.
 * AUCUNE variable globale n'intervient — le clamping balance (optionnel)
 * est passé EXPLICITEMENT par l'appelant.
 */
export function computeBettingAmount(ctx: AssetTradingContext, balance = 0): number {
  const base = ctx.betting.baseAmount > 0 ? ctx.betting.baseAmount : 1;
  let amount = base;

  switch (ctx.bettingStrategy) {
    case 'martingale': {
      // v20 — Garde-fou : la séquence de Martingale compte AU PLUS
      // maxMartingaleSteps MISES (0 = illimité). La mise N°k vaut
      // base × 2^(k-1) : ex. cap 4, base 10 → 10 → 20 → 40 → 80, puis si le
      // 80 PERD → RETOUR à 10 (mise initiale) — JAMAIS 160.
      // Ceinture+bretelles : le reset est déjà garanti par
      // updateBettingAfterResult, ce clamp protège en plus contre tout état
      // hérité/corrompu.
      const cap = ctx.betting.maxMartingaleSteps > 0 ? ctx.betting.maxMartingaleSteps : Infinity;
      // N mises max → exposant max N-1 (Infinity - 1 = Infinity : illimité).
      const step = Math.max(0, Math.min(Math.floor(ctx.betting.consecutiveLosses), cap - 1));
      amount = base * Math.pow(MARTINGALE_MULTIPLIER, step);
      break;
    }
    case 'fibonacci': {
      const idx = Math.min(ctx.betting.fibIndex, FIBONACCI_STEPS.length - 1);
      amount = base * FIBONACCI_STEPS[idx];
      break;
    }
    default:
      amount = base;
  }

  // Jamais plus que la balance disponible (minimum broker $1) — balance
  // passée explicitement (0 = pas de clamp, ex. tests unitaires).
  if (balance > 0 && amount > balance) amount = Math.max(1, Math.floor(balance));
  return Math.max(1, amount);
}

// ---------------------------------------------------------------------------
//  Résultat d'un règlement — TROIS états (v17 : Tie/Refund = état neutre)
// ---------------------------------------------------------------------------

/**
 * v17 — Résultat d'un règlement broker en trois états (spéc. utilisateur) :
 *   - 'win'  : Gain (P&L > 0)  → la mise est RÉINITIALISÉE au montant initial ;
 *   - 'loss' : Perte (P&L < 0) → la mise est INCRÉMENTÉE selon le
 *              multiplicateur défini (Martingale) / l'index (Fibonacci) ;
 *   - 'push' : Remboursement/Égalité (Tie/Refund, P&L = 0 $) → ÉTAT NEUTRE :
 *              le niveau de mise COURANT est conservé pour l'ordre suivant,
 *              l'index de la suite de mises (consecutiveLosses/fibIndex)
 *              n'est JAMAIS modifié.
 *
 * Ex. (base 1, multiplicateur ×2 — cas de validation utilisateur) :
 *   1$ → LOSS → 2$ → LOSS → 4$ → TIE → 4$ (maintenue) → LOSS → 8$.
 */
export type BettingOutcome = 'win' | 'loss' | 'push';

/** Normalise l'ancien booléen (true/false) ou le trois-états en BettingOutcome. */
export function normalizeBettingOutcome(result: boolean | BettingOutcome): BettingOutcome {
  if (result === true || result === 'win') return 'win';
  if (result === false || result === 'loss') return 'loss';
  return 'push';
}

/** Deal réglé broker minimal nécessaire à la classification trois états. */
export interface SettledDealLike {
  id?: string | number | null;
  asset?: string | null;
  closeTime?: number | null;
  profit?: number | null;
  isWin?: boolean | null;
}

/**
 * v17 — Classe un règlement broker en 'win' | 'loss' | 'push' :
 *   - profit > 0 (ou isWin === true) → 'win'  (Gain) ;
 *   - profit < 0                      → 'loss' (Perte) ;
 *   - profit === 0 (Tie/Refund)       → 'push' (Remboursement/Égalité) —
 *     UNIQUEMENT si le règlement porte une signature de clôture RÉELLE
 *     (closeTime, asset ou id exploitable). Un placeholder dégradé
 *     (enveloppe fallback : id 0, asset vide, sans clôture) reste 'loss'
 *     comme avant — il est de toute façon inattribuable (deal non suivi,
 *     empreinte impossible) et n'atteint JAMAIS le moteur de mises : ce
 *     garde-fou ne fait que préserver le comportement antérieur des
 *     règlements dégradés pour les logs.
 *
 * Chemins réels couverts (broker PO, capture 2026-09-17) :
 *   - successcloseOrder → deals[0] porte l'UUID d'ouverture, l'asset et
 *     closeTimestamp : un Tie y arrive avec profit NET = 0 → 'push' ;
 *   - updateClosedDeals (cache lazy, ids numériques) : id réel + asset +
 *     closeTime → profit = 0 → 'push'.
 */
export function classifySettledOutcome(deal: SettledDealLike): BettingOutcome {
  const profit = Number(deal.profit ?? 0);
  if (deal.isWin === true) return 'win';
  if (Number.isFinite(profit) && profit > 0) return 'win';
  if (Number.isFinite(profit) && profit < 0) return 'loss';
  // profit === 0 → Tie/Refund POTENTIEL : signature de clôture réelle ?
  const hasRealClose =
    Number(deal.closeTime ?? 0) > 0 ||
    (typeof deal.asset === 'string' && deal.asset.trim() !== '');
  const idStr = deal.id == null ? '' : String(deal.id);
  const usableId = idStr !== '' && idStr !== '0' && idStr !== 'NaN' &&
    idStr !== 'null' && idStr !== 'undefined';
  if (hasRealClose || usableId) return 'push';
  return 'loss'; // placeholder dégradé — comportement antérieur conservé
}

/**
 * Avance la stratégie de mise de CET asset après un résultat (§14/§15/§19).
 * EURUSD LOSS → EURUSD.consecutiveLosses++ — XAUUSD/BTCUSD INTACTS.
 *
 * v17 — TROIS états : 'push' (Tie/Refund, P&L = 0) est un état NEUTRE qui ne
 * modifie JAMAIS l'index de la suite de mises — le niveau courant est
 * conservé pour l'ordre suivant (ni reset, ni incrément).
 */
export function updateBettingAfterResult(ctx: AssetTradingContext, result: boolean | BettingOutcome): void {
  const outcome = normalizeBettingOutcome(result);
  if (outcome === 'push') {
    // Tie/Refund (P&L = 0) : mise conservée au niveau courant.
    // Ex. base 1, ×2 : 1 → L → 2 → L → 4 → TIE → 4 → L → 8.
    return;
  }
  if (outcome === 'win') {
    ctx.betting.consecutiveLosses = 0;
    ctx.betting.fibIndex = Math.max(0, ctx.betting.fibIndex - 2); // recule de 2 pas
  } else {
    ctx.betting.consecutiveLosses++;
    // v20 — GARDE-FOU MARTINGALE : maxMartingaleSteps = nombre MAXIMAL de
    // mises dans la séquence de Martingale (0 = illimité). Si la mise au
    // niveau max (la N-ième mise) a PERDU, RETOUR À LA MISE INITIALE.
    // Ex. max 4, base 10 : 10 → 20 → 40 → 80 ; si le 80 perd (la 4e mise)
    // → prochaine mise 10 — la 5e mise n'EXISTE PAS.
    // (v19 : le cap comptait les doublements → 4 donnait 5 mises, corrigé.)
    if (ctx.betting.maxMartingaleSteps > 0 && ctx.betting.consecutiveLosses >= ctx.betting.maxMartingaleSteps) {
      ctx.betting.consecutiveLosses = 0;
    }
    ctx.betting.fibIndex = Math.min(ctx.betting.fibIndex + 1, FIBONACCI_STEPS.length - 1);
  }
}

/**
 * Applique le résultat d'un deal fermé au contexte de SON asset (§18/§19) :
 *   - stats (wins/losses/pushes) ;
 *   - progression Martingale/Fibonacci ('push' = index INCHANGÉ, v17) ;
 *   - retrait des trackedDeals + des openPositions ;
 *   - nettoyage de l'action mémorisée (plus de trade en cours).
 * Retourne un résumé (pour les logs de debug §37) ou null si le deal
 * n'était pas suivi par ce contexte.
 */
export function applyDealResult(
  ctx: AssetTradingContext,
  dealId: string,
  result: boolean | BettingOutcome,
): {
  outcome: BettingOutcome;
  isWin: boolean;
  wins: number;
  losses: number;
  pushes: number;
  nextBetAmount: number;
} | null {
  const tracked = ctx.trackedDeals.get(String(dealId));
  if (!tracked) return null;
  ctx.trackedDeals.delete(String(dealId));
  noteDealClosed(ctx, String(dealId)); // retire aussi des positions ouvertes
  const outcome = normalizeBettingOutcome(result);
  if (outcome === 'win') ctx.stats.wins++;
  else if (outcome === 'loss') ctx.stats.losses++;
  else ctx.stats.pushes++; // v17 — Tie/Refund : état neutre, ni win ni loss
  updateBettingAfterResult(ctx, outcome);
  // v20 — Auto Switch Assets : mémorise le résultat du DERNIER ordre réglé
  // de CET asset (le switch automatique attend un GAIN avant de le quitter).
  ctx.autoTrade.lastOrderWin = outcome === 'win';
  return {
    outcome,
    isWin: outcome === 'win',
    wins: ctx.stats.wins,
    losses: ctx.stats.losses,
    pushes: ctx.stats.pushes,
    nextBetAmount: computeBettingAmount(ctx),
  };
}

// ---------------------------------------------------------------------------
//  Bookkeeping des positions (§17)
// ---------------------------------------------------------------------------

/** Enregistre un deal ouvert dans le contexte de SON asset. */
export function noteDealOpened(ctx: AssetTradingContext, deal: OpenedDeal): void {
  if (!ctx.openPositions.find((d) => String(d.id) === String(deal.id))) {
    ctx.openPositions.push(deal);
  }
}

/** Retire un deal fermé du contexte de SON asset. */
export function noteDealClosed(ctx: AssetTradingContext, dealId: string): void {
  ctx.openPositions = ctx.openPositions.filter((d) => String(d.id) !== String(dealId));
}

// ---------------------------------------------------------------------------
// Rattachement d'un règlement broker à un deal suivi (§17bis — martingale)
// ---------------------------------------------------------------------------

/** Deal fermé broker minimal nécessaire au rattachement par empreinte. */
export interface ClosedDealFingerprintInput {
  id: string | number;
  asset: string;
  amount: number;
  openPrice: number;
  closePrice: number;
  openTime: number;
  closeTime: number;
  profit: number;
  isWin: boolean | null;
}

/**
 * Retrouve, PARMI LES DEALS SUIVIS DE CET ASSET, celui que ce règlement broker
 * ferme réellement — quand le broker publie le deal fermé avec un id DIFFÉRENT
 * de l'UUID d'ouverture (comportement réel observé : règlements paresseux via
 * updateClosedDeals, ids numériques ≠ UUID).
 *
 * Critères (validés sur le JSONL réel du 2026-09-08 — un deal fermé
 * étranger ne peut JAMAIS régler notre ordre) :
 *   (a) même asset (celui du CONTEXTE, jamais un autre asset) ;
 *   (b) même montant (± 0,01) ;
 *   (c) prix d'entrée : le règlement porte EXACTEMENT le fill de notre ordre
 *       (le broker renvoie le même openPrice à l'ouverture et à la clôture
 *       d'un même deal — égalité stricte observée sur les règlements réels) ;
 *   (d) fenêtre d'ouverture : ouvert au moment de notre ordre (± 5 s) ;
 *   (e) direction cohérente : CALL gagne ⇔ close > open, PUT gagne ⇔ close <
 *       open — une contradiction exclut le rattachement ;
 *   (f) fenêtre d'échéance : le règlement tombe à l'expiration attendue
 *       (expiry + 15 s de tolérance, étendue aux règlements paresseux).
 *
 * Retourne la clé du tracked deal (dans ctx.trackedDeals) ou null si aucun
 * deal suivi ne correspond — auquel cas le résultat reste honnêtement ignoré.
 */
export function findTrackedDealByFingerprint(
  ctx: AssetTradingContext,
  deal: ClosedDealFingerprintInput,
): { key: string; tracked: TrackedDeal } | null {
  const dealAsset = String(deal.asset ?? '').trim();
  if (dealAsset && dealAsset !== ctx.asset) return null;

  // NORMALISATION DES HORODATAGES BROKER : certains payloads réels portent
  // openTime/closeTime en MILLISECONDES (unix ms ~1,79e12), d'autres en
  // SECONDES (~1,79e9). Une valeur > 1e12 est forcément en ms ; sinon on
  // la traite comme des secondes. Sans cette normalisation, un règlement en
  // ms échouait TOUJOURS les fenêtres (d)/(f) (ms × 1000 = écart absurde)
  // et la Martingale ne voyait JAMAIS le résultat.
  const toMs = (v: number): number => {
    if (!Number.isFinite(v) || v <= 0) return 0;
    return v > 1e12 ? v : v * 1000;
  };

  const dealAmount = Number(deal.amount ?? 0);
  const dealOpen = Number(deal.openPrice ?? 0);
  const dealClose = Number(deal.closePrice ?? 0);
  const dealOpenTimeMs = toMs(Number(deal.openTime ?? 0));
  const closeTimeMs = toMs(Number(deal.closeTime ?? 0));
  const reference = closeTimeMs || dealOpenTimeMs || Date.now();
  const settledWin = deal.isWin === true || (deal.isWin == null && Number(deal.profit ?? 0) > 0);

  let best: { key: string; tracked: TrackedDeal; score: number } | null = null;
  for (const [key, tracked] of ctx.trackedDeals) {
    // (a)+(b) même asset, même montant
    if (dealAsset && tracked.asset !== dealAsset) continue;
    if (dealAmount > 0 && Math.abs(dealAmount - tracked.amount) > 0.01) continue;
    // (c) même fill d'entrée, TOLÉRANT AU SPREAD du broker réel : l'ouverture
    //     et le règlement peuvent porter bid vs ask (1-2 pips d'écart sur
    //     FX, davantage sur métaux/indices). Tolérance = max(arrondi float,
    //     0,05 % du prix) : au-dessus d'un spread réel, STRICTEMENT sous le
    //     fantôme du cache broker (8 pips ≈ 0,068 %) qui reste REJETÉ — et
    //     le montant (b) + la fenêtre (d) + la direction (e) + l'échéance
    //     (f) discriminent le reste.
    if (dealOpen > 0 && tracked.openPrice != null &&
        Math.abs(dealOpen - tracked.openPrice) > Math.max(1e-6, tracked.openPrice * 5e-4)) continue;
    // (d) ouvert au moment de notre ordre
    if (dealOpenTimeMs > 0 && tracked.openTime != null &&
        Math.abs(dealOpenTimeMs - tracked.openTime * 1000) > 5000) continue;
    // (e) direction cohérente avec l'action de l'ordre
    if (dealOpen > 0 && dealClose > 0 && tracked.action) {
      const implied: 'call' | 'put' = dealClose === dealOpen
        ? tracked.action
        : settledWin
          ? (dealClose > dealOpen ? 'call' : 'put')
          : (dealClose > dealOpen ? 'put' : 'call');
      if (implied !== tracked.action) continue;
    }
    // (f) règlement tombé à l'échéance attendue de CET ordre suivi
    const openRefMs = tracked.openTime != null && tracked.openTime > 0
      ? tracked.openTime * 1000
      : null;
    const expectedClose = (openRefMs ?? (reference - tracked.expirationSeconds * 1000)) + tracked.expirationSeconds * 1000;
    const score = Math.abs(reference - expectedClose);
    if (score > Math.max(15_000, tracked.expirationSeconds * 1000 + 15_000)) continue;
    if (!best || score < best.score) best = { key, tracked, score };
  }
  return best ? { key: best.key, tracked: best.tracked } : null;
}

// ---------------------------------------------------------------------------
//  Validation de la sélection d'assets (§3 — backend, jamais que le frontend)
// ---------------------------------------------------------------------------

export interface AssetSelectionResult {
  ok: boolean;
  mode: TradingMode;
  assets: string[];
  error?: string;
  deduped?: boolean;
}

/**
 * Valide une sélection d'assets côté backend :
 *   1 <= assets.length <= 10 (§3) · doublons supprimés · mode cohérent.
 * Ne FAIT JAMAIS confiance au frontend — tout est revalidé ici.
 */
export function validateAssetSelection(input: { mode?: unknown; assets?: unknown }): AssetSelectionResult {
  const rawMode = input.mode === 'multi' ? 'multi' : input.mode === 'single' ? 'single' : null;
  if (!rawMode) {
    return { ok: false, mode: 'single', assets: [], error: 'mode invalide (attendu: single | multi)' };
  }

  if (!Array.isArray(input.assets)) {
    return { ok: false, mode: rawMode, assets: [], error: 'assets doit être un tableau' };
  }

  // Nettoyage : strings non vides + suppression des doublons (Set).
  const cleaned: string[] = [];
  const seen = new Set<string>();
  for (const a of input.assets) {
    if (typeof a !== 'string') continue;
    const name = a.trim();
    if (!name || seen.has(name)) continue;
    seen.add(name);
    cleaned.push(name);
  }
  const deduped = cleaned.length !== input.assets.length;

  if (cleaned.length < 1) {
    return { ok: false, mode: rawMode, assets: [], error: 'sélectionnez au moins 1 asset', deduped };
  }
  if (cleaned.length > MAX_SELECTED_ASSETS) {
    return {
      ok: false,
      mode: rawMode,
      assets: cleaned,
      error: `maximum ${MAX_SELECTED_ASSETS} assets simultanés (reçu: ${cleaned.length})`,
      deduped,
    };
  }
  if (rawMode === 'single' && cleaned.length > 1) {
    return {
      ok: false,
      mode: rawMode,
      assets: [cleaned[0]],
      error: 'mode single = 1 seul asset',
      deduped,
    };
  }

  // mode multi avec 1 asset → autorisé (comportement identique au single,
  // l'utilisateur peut ajouter des assets ensuite) ; on normalise tout de
  // même le mode pour cohérence interne.
  const mode: TradingMode = rawMode === 'single' ? 'single' : 'multi';
  return { ok: true, mode, assets: cleaned, deduped };
}

// ---------------------------------------------------------------------------
//  Reconnexion (§31) — resubscription des assets sélectionnés
// ---------------------------------------------------------------------------

export interface ResubscriptionPlan {
  toSubscribe: string[];
  toUnsubscribe: string[];
}

/**
 * Après une reconnexion broker, calcule les subscriptions à rétablir à
 * partir de `selectedAssets` (source de vérité) et des subscriptions
 * courantes. Exemple : selected=[EURUSD,XAUUSD], subscribed=[] (reset
 * connexion) → toSubscribe=[EURUSD,XAUUSD].
 */
export function planResubscription(selected: string[], subscribed: string[]): ResubscriptionPlan {
  const sel = new Set(selected);
  const sub = new Set(subscribed);
  const toSubscribe = selected.filter((a) => !sub.has(a));
  const toUnsubscribe = subscribed.filter((a) => !sel.has(a));
  return { toSubscribe, toUnsubscribe };
}

/**
 * Un tick doit-il être traité pour cet asset ? (§26 — le focus n'arrête
 * JAMAIS les autres assets ; §9 — l'affichage ≠ le traitement).
 * Règle : l'asset est traité s'il fait partie des assets SÉLECTIONNÉS,
 * quel que soit le focus.
 */
export function shouldProcessAssetTick(selectedAssets: string[], asset: string): boolean {
  return selectedAssets.includes(asset);
}

// ---------------------------------------------------------------------------
//  Logs de debug (§37) — format [ASSET:xxx] pour détecter la contamination
// ---------------------------------------------------------------------------

export function assetLog(asset: string, message: string): string {
  return `[ASSET:${asset}] ${message}`;
}
