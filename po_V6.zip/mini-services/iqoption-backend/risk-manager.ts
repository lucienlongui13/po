/**
 * risk-manager.ts
 * ================
 * The #1 reason traders lose in binary options is NOT bad predictions —
 * it's poor risk management. This module enforces strict rules that
 * keep you profitable even with a 55% win rate.
 *
 * Core principles:
 *   1. Never risk more than 1% of balance per trade
 *   2. Stop trading after 3 consecutive losses (tilt protection)
 *   3. Stop trading after hitting daily profit target OR daily loss limit
 *   4. Reduce position size after losses, increase after wins (anti-martingale)
 *   5. Maximum 4 trades per 10-minute window (overtrading protection)
 */

export interface RiskState {
  balance: number;
  startOfDayBalance: number;
  consecutiveLosses: number;
  consecutiveWins: number;
  totalTradesToday: number;
  winsToday: number;
  lossesToday: number;
  tradesInWindow: number[];   // timestamps of recent trades
  lastLossTime: number;       // for cooldown after loss streak
  isPaused: boolean;
  pauseReason: string;
  pauseUntil: number;         // timestamp when pause ends
  lastRiskAmount: number;
}

export interface RiskDecision {
  allowed: boolean;
  reason: string;
  amount: number;             // amount to bet
  riskPercent: number;        // % of balance
}

export class RiskManager {
  private state: RiskState;
  private readonly maxRiskPercent = 0.02;       // max 2% per trade
  private readonly baseRiskPercent = 0.01;      // base 1% per trade
  private readonly maxConsecutiveLosses = 3;    // pause after 3 losses
  private readonly lossStreakCooldownMs = 30 * 60 * 1000;  // 30 min cooldown
  private readonly dailyProfitTargetPct = 0.05; // +5% → stop for day
  private readonly dailyLossLimitPct = -0.05;    // -5% → stop for day
  private readonly tradeWindowMs = 10 * 60 * 1000;  // 10 minutes
  private readonly maxTradesPerWindow = 4;       // max 4 trades per 10 min

  constructor(startBalance: number) {
    const now = Date.now();
    this.state = {
      balance: startBalance,
      startOfDayBalance: startBalance,
      consecutiveLosses: 0,
      consecutiveWins: 0,
      totalTradesToday: 0,
      winsToday: 0,
      lossesToday: 0,
      tradesInWindow: [],
      lastLossTime: 0,
      isPaused: false,
      pauseReason: '',
      pauseUntil: 0,
      lastRiskAmount: 0,
    };
  }

  /** Update balance after a trade closes */
  updateBalance(newBalance: number): void {
    this.state.balance = newBalance;
  }

  /** Record a trade result */
  recordTrade(won: boolean, profit: number): void {
    this.state.totalTradesToday++;
    const now = Date.now();
    this.state.tradesInWindow.push(now);
    // Clean old trades from window
    this.state.tradesInWindow = this.state.tradesInWindow.filter(
      ts => now - ts < this.tradeWindowMs
    );

    if (won) {
      this.state.winsToday++;
      this.state.consecutiveWins++;
      this.state.consecutiveLosses = 0;
    } else {
      this.state.lossesToday++;
      this.state.consecutiveLosses++;
      this.state.consecutiveWins = 0;
      this.state.lastLossTime = now;

      // Pause after 3 consecutive losses
      if (this.state.consecutiveLosses >= this.maxConsecutiveLosses) {
        this.state.isPaused = true;
        this.state.pauseReason = `${this.state.consecutiveLosses} consecutive losses — cooldown ${this.lossStreakCooldownMsMs / 60000}min`;
        this.state.pauseUntil = now + this.lossStreakCooldownMs;
      }
    }

    // Check daily limits
    const pnlPct = (this.state.balance - this.state.startOfDayBalance) / this.state.startOfDayBalance;
    if (pnlPct >= this.dailyProfitTargetPct) {
      this.state.isPaused = true;
      this.state.pauseReason = `Daily profit target reached: +${(pnlPct * 100).toFixed(1)}%`;
      this.state.pauseUntil = this.getNextDayTimestamp();
    } else if (pnlPct <= this.dailyLossLimitPct) {
      this.state.isPaused = true;
      this.state.pauseReason = `Daily loss limit hit: ${(pnlPct * 100).toFixed(1)}%`;
      this.state.pauseUntil = this.getNextDayTimestamp();
    }
  }

  private get lossStreakCooldownMsMs(): number {
    return this.lossStreakCooldownMs;
  }

  private getNextDayTimestamp(): number {
    const tomorrow = new Date();
    tomorrow.setHours(0, 0, 0, 0);
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.getTime();
  }

  /** Check if a new trade is allowed and return the amount to bet */
  evaluate(): RiskDecision {
    const now = Date.now();

    // Check if paused
    if (this.state.isPaused) {
      if (now < this.state.pauseUntil) {
        const remaining = Math.ceil((this.state.pauseUntil - now) / 60000);
        return {
          allowed: false,
          reason: `PAUSED: ${this.state.pauseReason} (${remaining}min remaining)`,
          amount: 0,
          riskPercent: 0,
        };
      } else {
        // Pause is over — reset
        this.state.isPaused = false;
        this.state.pauseReason = '';
        this.state.consecutiveLosses = 0;
      }
    }

    // Check trade frequency (max 4 per 10 min)
    this.state.tradesInWindow = this.state.tradesInWindow.filter(
      ts => now - ts < this.tradeWindowMs
    );
    if (this.state.tradesInWindow.length >= this.maxTradesPerWindow) {
      const oldestTrade = Math.min(...this.state.tradesInWindow);
      const waitMs = this.tradeWindowMs - (now - oldestTrade);
      const waitMin = Math.ceil(waitMs / 60000);
      return {
        allowed: false,
        reason: `Overtrading protection: ${this.state.tradesInWindow.length}/${this.maxTradesPerWindow} trades in 10min (wait ${waitMin}min)`,
        amount: 0,
        riskPercent: 0,
      };
    }

    // Calculate position size using anti-martingale (reduce after loss, increase after win)
    let riskPercent = this.baseRiskPercent;
    if (this.state.consecutiveLosses > 0) {
      // Reduce by 50% per consecutive loss (0.5% → 0.25% → 0.125%)
      riskPercent = this.baseRiskPercent * Math.pow(0.5, this.state.consecutiveLosses);
    } else if (this.state.consecutiveWins >= 2) {
      // Increase to 1.5% after 2 consecutive wins
      riskPercent = this.baseRiskPercent * 1.5;
    } else if (this.state.consecutiveWins >= 4) {
      // Cap at 2% after 4 consecutive wins
      riskPercent = this.maxRiskPercent;
    }

    // Clamp to [0.1%, 2%]
    riskPercent = Math.max(0.001, Math.min(this.maxRiskPercent, riskPercent));

    const amount = Math.max(1, Math.floor(this.state.balance * riskPercent));

    return {
      allowed: true,
      reason: `OK: ${this.state.winsToday}W/${this.state.lossesToday}L today, streak ${this.state.consecutiveWins}W/${this.state.consecutiveLosses}L, risk ${(riskPercent * 100).toFixed(2)}%`,
      amount,
      riskPercent,
    };
  }

  /** Get current state for logging/frontend */
  getState(): RiskState {
    return { ...this.state };
  }

  /** Reset daily counters (call at start of new day) */
  resetDaily(): void {
    const now = Date.now();
    if (now >= this.getNextDayTimestamp() - 86400000) {
      // It's a new day
      this.state.startOfDayBalance = this.state.balance;
      this.state.totalTradesToday = 0;
      this.state.winsToday = 0;
      this.state.lossesToday = 0;
      this.state.isPaused = false;
      this.state.pauseReason = '';
    }
  }
}
