#!/bin/bash
#
# start-dev.sh — PiracyChecker Trade (npm only)
#   1. Backend socket.io  (port 3030)
#   2. Next.js frontend   (port 3000)
#
set -e

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
BACKEND_DIR="$ROOT_DIR/mini-services/iqoption-backend"
BACKEND_LOG="$ROOT_DIR/backend.log"
BACKEND_SUPERVISOR="$ROOT_DIR/scripts/backend-supervisor.sh"
MAX_BACKEND_LOG_BYTES=$((10 * 1024 * 1024))

if [ ! -d "$ROOT_DIR/node_modules" ]; then
  echo "Installing frontend dependencies (one-time)…"
  (cd "$ROOT_DIR" && npm install --no-audit --no-fund)
fi
if [ ! -d "$BACKEND_DIR/node_modules" ]; then
  echo "Installing backend dependencies…"
  (cd "$BACKEND_DIR" && npm install --no-audit --no-fund)
fi

echo "Starting backend supervisor (port 3030)…"
if [ -f "$BACKEND_LOG" ] && [ "$(wc -c < "$BACKEND_LOG")" -gt "$MAX_BACKEND_LOG_BYTES" ]; then
  mv -f "$BACKEND_LOG" "$BACKEND_LOG.1"
fi
nohup "$BACKEND_SUPERVISOR" >> "$BACKEND_LOG" 2>&1 &
sleep 4

echo "Starting frontend (port 3000)…"
cd "$ROOT_DIR"
npm run dev
