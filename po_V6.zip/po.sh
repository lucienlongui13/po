#!/usr/bin/env bash
# ============================================================================
# po.sh — Pocket Option Predictor UI (native Termux, no bun, no proot)
# ============================================================================
# Works on: Termux (android/aarch64), Ubuntu, Debian, x86_64
# Requirements: node >= 18, npm
#
# Usage:
#   ./po.sh              # start both services
#   ./po.sh stop         # stop
#   ./po.sh restart      # restart
#   ./po.sh status       # status
#   ./po.sh logs         # tail logs
# ============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$SCRIPT_DIR"
BACKEND_DIR="$PROJECT_ROOT/mini-services/iqoption-backend"
FRONTEND_DIR="$PROJECT_ROOT"
SDK_DIR="$BACKEND_DIR/pocket-option-sdk"

BACKEND_PORT=3030
FRONTEND_PORT=3000

LOG_DIR="$PROJECT_ROOT/.logs"
mkdir -p "$LOG_DIR"
BACKEND_LOG="$LOG_DIR/backend.log"
FRONTEND_LOG="$LOG_DIR/frontend.log"
PO_PID_FILE="$LOG_DIR/po.pids"

if [ -t 1 ]; then
  RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[0;33m'; BLUE='\033[0;34m'; NC='\033[0m'
else
  RED=''; GREEN=''; YELLOW=''; BLUE=''; NC=''
fi

log()   { echo -e "${GREEN}[po.sh]${NC} $*"; }
warn()  { echo -e "${YELLOW}[po.sh]${NC} $*"; }
error() { echo -e "${RED}[po.sh]${NC} $*" >&2; }
info()  { echo -e "${BLUE}[po.sh]${NC} $*"; }

# --- Check if port is open (uses Node.js net module — works EVERYWHERE) ---
is_port_open() {
  local port="$1"
  node -e "
    var s = require('net').connect({port: $port, host: '127.0.0.1'}, function() {
      s.end();
      process.exit(0);
    });
    s.on('error', function() { process.exit(1); });
    setTimeout(function() { process.exit(1); }, 1000);
  " 2>/dev/null
}

# --- Kill stale processes ---
kill_stale() {
  log "Cleaning up stale processes..."
  pkill -f "tsx.*index" 2>/dev/null
  pkill -f "next dev" 2>/dev/null
  pkill -f "next-server" 2>/dev/null
  # Kill by PID file
  if [ -f "$PO_PID_FILE" ]; then
    while read -r pid; do
      [ -n "$pid" ] && kill "$pid" 2>/dev/null
    done < "$PO_PID_FILE"
    rm -f "$PO_PID_FILE"
  fi
  sleep 2
  # Force kill survivors
  pkill -9 -f "tsx.*index" 2>/dev/null
  pkill -9 -f "next dev" 2>/dev/null
  pkill -9 -f "next-server" 2>/dev/null
  sleep 1
}

# --- Wait for port ---
wait_for_port() {
  local port="$1"
  local name="$2"
  local timeout="${3:-60}"
  local elapsed=0
  while ! is_port_open "$port"; do
    sleep 2
    elapsed=$((elapsed + 2))
    if [ "$elapsed" -ge "$timeout" ]; then
      return 1
    fi
  done
  log "$name is up (port $port, ${elapsed}s)"
  return 0
}

# --- Check deps ---
check_deps() {
  log "Checking dependencies..."

  if ! command -v node >/dev/null 2>&1; then
    error "Node.js required. Install: pkg install nodejs"
    exit 1
  fi
  log "Node.js: $(node -v)"

  if ! command -v npm >/dev/null 2>&1; then
    error "npm required."
    exit 1
  fi
  log "npm: $(npm -v)"

  # Pine is a runtime dependency of the frontend. Install it explicitly when
  # it is absent before the broader npm install; this also repairs a stale
  # package-lock from an older project archive.
  if [ ! -d "$FRONTEND_DIR/node_modules/@heyphat/piner" ]; then
    warn "Pine Script engine missing; installing @heyphat/piner@0.13.0..."
    if ! (cd "$FRONTEND_DIR" && npm install @heyphat/piner@0.13.0 --save --no-audit --no-fund); then
      error "Pine Script engine installation failed."
      error "Try manually: npm install @heyphat/piner@0.13.0 --save"
      return 1
    fi
  fi

  if [ ! -x "$FRONTEND_DIR/node_modules/.bin/next" ]; then
    warn "Installing/repairing frontend deps..."
    if ! (cd "$FRONTEND_DIR" && npm install --include=dev --no-audit --no-fund); then
      error "Frontend dependency installation failed."
      return 1
    fi
  fi

  if ! (cd "$FRONTEND_DIR" && node -e "const p=require.resolve('@heyphat/piner'); console.log('Pine engine:', p)" >/dev/null 2>&1); then
    error "Pine Script engine @heyphat/piner@0.13.0 is not loadable."
    error "Run: npm install @heyphat/piner@0.13.0 --save"
    return 1
  fi

  if [ ! -x "$BACKEND_DIR/node_modules/.bin/tsx" ] || [ ! -d "$BACKEND_DIR/node_modules/socket.io" ] || ! (cd "$BACKEND_DIR" && npm ls --depth=0 >/dev/null 2>&1); then
    warn "Repairing/installing backend deps..."
    (cd "$BACKEND_DIR" && npm install --include=dev --no-audit --no-fund) || {
      error "Backend dependency installation failed."
      return 1
    }
  fi

  local sdk_build=0
  [ ! -f "$SDK_DIR/dist/index.js" ] && sdk_build=1
  [ ! -x "$SDK_DIR/node_modules/.bin/tsc" ] && sdk_build=1
  [ -f "$SDK_DIR/dist/index.js" ] && find "$SDK_DIR/src" -type f -newer "$SDK_DIR/dist/index.js" -print -quit | grep -q . && sdk_build=1
  if [ "$sdk_build" -eq 1 ]; then
    warn "Building SDK..."
    if [ ! -x "$SDK_DIR/node_modules/.bin/tsc" ]; then
      (cd "$SDK_DIR" && npm install --include=dev --no-audit --no-fund) || {
        error "SDK dependency installation failed."
        return 1
      }
    fi
    if ! (cd "$SDK_DIR" && ./node_modules/.bin/tsc -p tsconfig.json); then
      error "SDK build failed. See TypeScript errors above."
      return 1
    fi
    [ ! -f "$SDK_DIR/dist/index.js" ] && error "SDK build failed: dist/index.js missing" && return 1
    log "SDK built."
  fi

  # Fast backend syntax preflight. TypeScript is a declared backend dev
  # dependency, so this parser check is independent of esbuild's install
  # scripts and catches syntax errors before launching the background process.
  if ! (cd "$BACKEND_DIR" && node - <<'NODE'
const fs = require('fs');
const ts = require('typescript');
const file = 'index.ts';
const source = fs.readFileSync(file, 'utf8');
const sf = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS);
const diagnostics = sf.parseDiagnostics || [];
if (diagnostics.length) {
  for (const d of diagnostics) {
    const pos = d.start ?? 0;
    const lc = sf.getLineAndCharacterOfPosition(pos);
    console.error(`Syntax error ${file}:${lc.line + 1}:${lc.character + 1} — ${ts.flattenDiagnosticMessageText(d.messageText, ' ')}`);
  }
  process.exit(1);
}
NODE
  ); then
    error "Backend TypeScript syntax check failed. Fix the reported source error before starting."
    return 1
  fi

  log "Dependencies OK."
}

# --- Start backend ---
start_backend() {
  log "Starting backend (port $BACKEND_PORT)..."
  cd "$BACKEND_DIR"
  if [ ! -x "$BACKEND_DIR/node_modules/.bin/tsx" ]; then
    error "tsx is missing. Run ./po.sh restart to repair dependencies."
    return 1
  fi
  nohup "$BACKEND_DIR/node_modules/.bin/tsx" index.ts > "$BACKEND_LOG" 2>&1 &
  local pid=$!
  echo "$pid" >> "$PO_PID_FILE"
  log "Backend PID: $pid"

  if ! wait_for_port "$BACKEND_PORT" "Backend" 30; then
    error "Backend failed. Full diagnostic:"
    tail -30 "$BACKEND_LOG" 2>/dev/null
    return 1
  fi
  return 0
}

# --- Start frontend ---
start_frontend() {
  log "Starting frontend (port $FRONTEND_PORT)..."
  cd "$FRONTEND_DIR"
  # --webpack required on Termux (Turbopack needs native bindings)
  nohup node node_modules/next/dist/bin/next dev -p "$FRONTEND_PORT" --webpack > "$FRONTEND_LOG" 2>&1 &
  local pid=$!
  echo "$pid" >> "$PO_PID_FILE"
  log "Frontend PID: $pid"

  if ! wait_for_port "$FRONTEND_PORT" "Frontend" 120; then
    error "Frontend failed. Log:"
    tail -10 "$FRONTEND_LOG" 2>/dev/null
    return 1
  fi
  return 0
}

# --- Stop ---
stop_services() {
  log "Stopping..."
  pkill -f "tsx.*index" 2>/dev/null
  pkill -f "next dev" 2>/dev/null
  pkill -f "next-server" 2>/dev/null
  if [ -f "$PO_PID_FILE" ]; then
    while read -r pid; do
      [ -n "$pid" ] && kill "$pid" 2>/dev/null
    done < "$PO_PID_FILE"
    rm -f "$PO_PID_FILE"
  fi
  sleep 2
  pkill -9 -f "tsx.*index" 2>/dev/null
  pkill -9 -f "next dev" 2>/dev/null
  pkill -9 -f "next-server" 2>/dev/null
  sleep 1
  log "Stopped."
}

# --- Status ---
show_status() {
  echo ""
  info "=== Pocket Option Predictor UI ==="
  echo ""
  if is_port_open "$BACKEND_PORT"; then
    echo -e "  Backend  (:$BACKEND_PORT): ${GREEN}RUNNING${NC}"
  else
    echo -e "  Backend  (:$BACKEND_PORT): ${RED}STOPPED${NC}"
  fi
  if is_port_open "$FRONTEND_PORT"; then
    echo -e "  Frontend (:$FRONTEND_PORT): ${GREEN}RUNNING${NC}"
  else
    echo -e "  Frontend (:$FRONTEND_PORT): ${RED}STOPPED${NC}"
  fi
  echo ""
  is_port_open "$FRONTEND_PORT" && echo "  Open: http://localhost:$FRONTEND_PORT"
  is_port_open 3031 && echo "  Social Order Flow debug: http://localhost:3031/social-debug"
  echo ""
}

# --- Main ---
main() {
  local cmd="${1:-start}"
  case "$cmd" in
    start)
      check_deps || exit 1
      kill_stale
      start_backend || exit 1
      start_frontend || exit 1
      show_status
      ;;
    stop)
      stop_services
      ;;
    restart)
      stop_services
      sleep 2
      check_deps || exit 1
      kill_stale
      start_backend || exit 1
      start_frontend || exit 1
      show_status
      ;;
    status)
      show_status
      ;;
    logs)
      log "Tailing logs (Ctrl+C to stop)..."
      tail -f "$BACKEND_LOG" "$FRONTEND_LOG" 2>/dev/null || warn "No logs."
      ;;
    *)
      echo "Usage: $0 {start|stop|restart|status|logs}"
      exit 1
      ;;
  esac
}

main "$@"
