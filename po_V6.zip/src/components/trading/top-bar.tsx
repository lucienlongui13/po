'use client'

/**
 * top-bar.tsx — TradingView-style top toolbar.
 *
 * Logo · symbol button (search dialog) · live price · timeframes ·
 * chart type dropdown · Indicators · Replay · Alerts · log scale ·
 * theme · balance · mode · LIVE status · logout.
 */

import { useEffect, useRef, useState } from 'react'
import {
  Sun, Moon, LogOut, Wifi, WifiOff, ChevronDown, CandlestickChart,
  BarChart3, LineChart as LineChartIcon, Activity, Minus, FlaskConical,
  BellRing, History, Sigma, Clock3,
} from 'lucide-react'

import { TIMEFRAMES } from '@/hooks/use-pocket-option'
import { useTVStore, type ChartStyle } from '@/lib/tv-store'

export interface TopBarProps {
  dark: boolean
  setDark: (v: boolean) => void
  marketName: string
  price: number
  changePct: number
  timeframe: number
  setTimeframe: (s: number) => void
  onLogout: () => void
  balanceLabel: string
  mode: 'demo' | 'real'
  liveActive: boolean
  brokerConnected?: boolean
  brokerReconnecting?: boolean
  replayActive: boolean
  onStartReplay: (barsBack: number) => void
  /** Ceiling for the bars-back input — 10-day candle equivalent of the current timeframe. */
  maxBarsBack?: number
  alertCount: number
  onAddAlert: (price: number, direction: 'above' | 'below') => void
  onRemoveAlert: (id: string) => void
  alerts: Array<{ id: string; symbol: string; price: number; direction: 'above' | 'below'; triggered: boolean }>
}

const CHART_TYPES: Array<{ key: ChartStyle; label: string; icon: React.ReactNode }> = [
  { key: 'candles', label: 'Candles', icon: <CandlestickChart className="h-4 w-4" /> },
  { key: 'hollow', label: 'Hollow Candles', icon: <CandlestickChart className="h-4 w-4 opacity-50" /> },
  { key: 'bars', label: 'Bars', icon: <BarChart3 className="h-4 w-4" /> },
  { key: 'line', label: 'Line', icon: <LineChartIcon className="h-4 w-4" /> },
  { key: 'area', label: 'Area', icon: <Activity className="h-4 w-4" /> },
  { key: 'baseline', label: 'Baseline', icon: <Minus className="h-4 w-4" /> },
  { key: 'heikin-ashi', label: 'Heikin Ashi', icon: <CandlestickChart className="h-4 w-4" style={{ color: '#F23645' }} /> },
]

export function TopBar(props: TopBarProps) {
  const {
    dark, setDark, marketName, price, changePct, timeframe, setTimeframe,
    onLogout, balanceLabel, mode, liveActive, brokerConnected = false, brokerReconnecting = false, replayActive, onStartReplay,
    maxBarsBack = 3000, alertCount, onAddAlert, onRemoveAlert, alerts,
  } = props

  const chartStyle = useTVStore((s) => s.chartStyle)
  const setChartStyle = useTVStore((s) => s.setChartStyle)
  const setIndicatorsMenuOpen = useTVStore((s) => s.setIndicatorsMenuOpen)
  const setSymbolSearchOpen = useTVStore((s) => s.setSymbolSearchOpen)
  const toggleRightPanel = useTVStore((s) => s.toggleRightPanel)
  const logScale = useTVStore((s) => s.logScale)
  const toggleLogScale = useTVStore((s) => s.toggleLogScale)
  const indicators = useTVStore((s) => s.indicators)

  const [styleOpen, setStyleOpen] = useState(false)
  const [replayOpen, setReplayOpen] = useState(false)
  const [alertOpen, setAlertOpen] = useState(false)
  const [barsBack, setBarsBack] = useState(300)
  const [alertPriceInput, setAlertPriceInput] = useState<string | null>(null)
  const [alertDir, setAlertDir] = useState<'above' | 'below'>('above')
  const alertPrice = alertPriceInput ?? (price > 0 ? price.toFixed(price > 1000 ? 1 : 5) : '')

  // Candle countdown: the selected timeframe is the candle period itself.
  // Uses the same UTC epoch grid as the backend timeframe module:
  // S5=5s, S10=10s, S15=15s, S30=30s, M1=60s, ... D1=86400s.
  //
  // The state stores the REMAINING SECONDS (not Date.now()) and the updater
  // returns the previous value while the displayed second has not flipped:
  // React bails out on Object.is-equal state → the bar re-renders at most
  // once per second instead of 4×/s. TopBar sits inside the page tree that
  // replay re-renders at high frequency — a free-running 250ms timer used
  // to pile updates onto that cascade and trip React's "Maximum update
  // depth exceeded" guard.
  const [candleRemainingSec, setCandleRemainingSec] = useState(() => {
    const periodSec = Math.max(1, timeframe)
    return periodSec - (Math.floor(Date.now() / 1000) % periodSec)
  })
  useEffect(() => {
    const periodSec = Math.max(1, timeframe)
    const compute = () => periodSec - (Math.floor(Date.now() / 1000) % periodSec)
    const sync = () => {
      setCandleRemainingSec((prev) => {
        const next = compute()
        return next === prev ? prev : next
      })
    }
    // recompute right after a timeframe switch (async tick — lint-safe), then
    // tick at 250ms with a same-value bailout (one re-render per second max)
    const t0 = window.setTimeout(sync, 0)
    const id = window.setInterval(sync, 250)
    return () => { window.clearTimeout(t0); window.clearInterval(id) }
  }, [timeframe])

  const formatCandleRemaining = (seconds: number): string => {
    const total = Math.max(0, Math.ceil(seconds))
    const h = Math.floor(total / 3600)
    const m = Math.floor((total % 3600) / 60)
    const s = total % 60
    if (h > 0) return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`
  }

  const candleTimerLabel = formatCandleRemaining(candleRemainingSec)

  const styleRef = useRef<HTMLDivElement>(null)
  const replayRef = useRef<HTMLDivElement>(null)
  const alertRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const onDoc = (e: MouseEvent) => {
      if (styleRef.current && !styleRef.current.contains(e.target as Node)) setStyleOpen(false)
      if (replayRef.current && !replayRef.current.contains(e.target as Node)) setReplayOpen(false)
      if (alertRef.current && !alertRef.current.contains(e.target as Node)) setAlertOpen(false)
    }
    document.addEventListener('mousedown', onDoc)
    return () => document.removeEventListener('mousedown', onDoc)
  }, [])



  const border = dark ? '#2A2E39' : '#E0E3EB'
  const bg = dark ? '#131722' : '#FFFFFF'
  const text = dark ? '#D1D4DC' : '#131722'
  const sub = '#787B86'
  const up = changePct >= 0

  const btn = 'px-2 h-7 flex items-center gap-1 rounded-md text-[11px] font-medium transition-colors hover:bg-black/10 dark:hover:bg-white/10'

  return (
    <div
      className="flex items-center gap-1 px-2 h-11 border-b shrink-0 relative z-30"
      style={{ background: bg, borderColor: border, color: text }}
    >
      {/* logo */}
      <div className="flex items-center gap-1.5 pr-2">
        <img src="/pc-trade-logo.jpg" alt="PiracyChecker Trade" className="h-6 w-6 rounded object-cover" />
        <span className="font-bold text-[13px] hidden sm:inline">PiracyChecker&nbsp;Trade</span>
      </div>

      <div className="w-px h-6 mx-1" style={{ background: border }} />

      {/* symbol button */}
      <button
        onClick={() => setSymbolSearchOpen(true)}
        className="px-2 h-8 flex items-center gap-2 rounded-md hover:bg-black/10 dark:hover:bg-white/10"
        title="Search symbol (Pocket Option assets)"
      >
        <span className="font-bold text-[13px]">{marketName || '—'}</span>
        <ChevronDown className="h-3 w-3 opacity-60" />
        {price > 0 && (
          <span className="text-[12px] font-mono tabular-nums" style={{ color: up ? '#089981' : '#F23645' }}>
            {price > 1000 ? price.toFixed(1) : price.toFixed(5)}
            <span className="ml-1 text-[10px]">{up ? '+' : ''}{changePct.toFixed(2)}%</span>
          </span>
        )}
      </button>

      <div className="w-px h-6 mx-1" style={{ background: border }} />

      {/* timeframes */}
      <div className="flex items-center gap-0.5 overflow-x-auto max-w-[240px] sm:max-w-none">
        {TIMEFRAMES.map((tf) => (
          <button
            key={tf.label}
            onClick={() => setTimeframe(tf.seconds)}
            title={`Candle period ${tf.seconds}s`}
            className="px-1.5 h-7 rounded-md text-[11px] font-semibold transition-colors whitespace-nowrap"
            style={{
              background: timeframe === tf.seconds ? '#2962FF' : 'transparent',
              color: timeframe === tf.seconds ? '#fff' : sub,
            }}
          >
            {tf.label}
          </button>
        ))}
      </div>

      {/* candle countdown */}
      <div
        className="flex items-center gap-1 px-2 h-7 rounded-md text-[11px] font-mono tabular-nums"
        title={`Candle time remaining ${TIMEFRAMES.find((tf) => tf.seconds === timeframe)?.label ?? `${timeframe}s`} — period ${timeframe}s`}
        style={{ background: dark ? '#1E222D' : '#F0F3FA', color: text }}
      >
        <Clock3 className="h-3.5 w-3.5 opacity-70" />
        <span className="font-semibold">{candleTimerLabel}</span>
      </div>

      {/* chart type dropdown */}
      <div className="relative" ref={styleRef}>
        <button className={btn} onClick={() => setStyleOpen((v) => !v)} title="Chart type">
          {CHART_TYPES.find((t) => t.key === chartStyle)?.icon ?? <CandlestickChart className="h-4 w-4" />}
          <ChevronDown className="h-3 w-3 opacity-60" />
        </button>
        {styleOpen && (
          <div className="absolute top-9 left-0 rounded-md border shadow-xl py-1 w-44 z-40"
            style={{ background: dark ? '#1E222D' : '#FFFFFF', borderColor: border }}>
            {CHART_TYPES.map((t) => (
              <button
                key={t.key}
                onClick={() => { setChartStyle(t.key); setStyleOpen(false) }}
                className="w-full flex items-center gap-2 px-3 py-1.5 text-[12px] text-left hover:bg-black/10"
                style={{ color: chartStyle === t.key ? '#2962FF' : text, fontWeight: chartStyle === t.key ? 600 : 400 }}
              >
                {t.icon} {t.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* indicators */}
      <button className={btn} onClick={() => setIndicatorsMenuOpen(true)} title="Indicators (55 available)">
        <Sigma className="h-4 w-4" />
        <span className="hidden md:inline">Indicators</span>
        {indicators.length > 0 && (
          <span className="text-[9px] px-1 rounded-full text-white" style={{ background: '#2962FF' }}>{indicators.length}</span>
        )}
      </button>

      {/* replay */}
      <div className="relative" ref={replayRef}>
        <button
          className={btn}
          onClick={() => setReplayOpen((v) => !v)}
          title="Bar Replay & Backtesting"
          style={replayActive ? { background: '#FF6D00', color: '#fff' } : undefined}
        >
          <History className="h-4 w-4" />
          <span className="hidden md:inline">{replayActive ? 'Replaying' : 'Replay'}</span>
        </button>
        {replayOpen && (
          <div className="absolute top-9 left-0 rounded-md border shadow-xl p-3 w-60 z-40"
            style={{ background: dark ? '#1E222D' : '#FFFFFF', borderColor: border }}>
            <div className="text-[12px] font-semibold mb-2 flex items-center gap-1.5">
              <FlaskConical className="h-3.5 w-3.5" style={{ color: '#FF6D00' }} />
              Bar Replay — Backtesting
            </div>
            <div className="text-[10px] mb-2" style={{ color: sub }}>
              Rewind live Pocket Option history and replay it candle by candle. Place simulated CALL/PUT orders while it plays.
            </div>
            {replayActive ? (
              <div className="text-[11px]" style={{ color: '#FF6D00' }}>
                Replay running — use the transport bar under the chart. Exit from there.
              </div>
            ) : (
              <>
                <label className="flex items-center justify-between gap-2 text-[11px] mb-2">
                  <span style={{ color: sub }}>Bars back</span>
                  <input
                    type="number"
                    min={20}
                    max={maxBarsBack}
                    value={barsBack}
                    onChange={(e) => {
                      const n = Number(e.target.value)
                      setBarsBack(Number.isFinite(n) ? Math.max(1, Math.min(maxBarsBack, Math.floor(n))) : 300)
                    }}
                    className="w-24 px-2 py-1 rounded border bg-transparent text-right"
                    style={{ borderColor: border, color: text }}
                  />
                </label>
                {/* quick presets — Max covers the whole 10-day fetchable history */}
                <div className="flex gap-1 mb-2">
                  {[300, 1000, 5000].filter((v) => v < maxBarsBack).map((v) => (
                    <button
                      key={v}
                      onClick={() => setBarsBack(v)}
                      className="flex-1 py-1 rounded text-[10px] border"
                      style={{
                        borderColor: barsBack === v ? '#FF6D00' : border,
                        color: barsBack === v ? '#FF6D00' : sub,
                      }}
                    >
                      {v >= 1000 ? `${v / 1000}k` : v}
                    </button>
                  ))}
                  <button
                    onClick={() => setBarsBack(maxBarsBack)}
                    title={`Replay the entire fetchable history (${maxBarsBack.toLocaleString()} bars on this timeframe)`}
                    className="flex-1 py-1 rounded text-[10px] font-bold border"
                    style={{
                      borderColor: barsBack === maxBarsBack ? '#FF6D00' : border,
                      color: barsBack === maxBarsBack ? '#FF6D00' : sub,
                    }}
                  >
                    MAX
                  </button>
                </div>
                <div className="text-[9px] mb-2" style={{ color: sub }}>
                  Up to {maxBarsBack.toLocaleString()} bars (10 days) on this timeframe. Use the Strategy Tester's Fetch History to load it, then rewind to the start.
                </div>
                <button
                  onClick={() => { onStartReplay(barsBack); setReplayOpen(false) }}
                  className="w-full py-1.5 rounded text-[11px] font-semibold text-white"
                  style={{ background: '#FF6D00' }}
                >
                  Start Replay
                </button>
              </>
            )}
          </div>
        )}
      </div>

      {/* alerts */}
      <div className="relative" ref={alertRef}>
        <button
          className={btn}
          onClick={() => { setAlertOpen((v) => !v); setAlertPriceInput(null) }}
          title="Price alerts"
          style={alertCount > 0 ? { color: '#FF6D00' } : undefined}
        >
          <BellRing className="h-4 w-4" />
          {alertCount > 0 && <span className="text-[9px] px-1 rounded-full text-white" style={{ background: '#FF6D00' }}>{alertCount}</span>}
        </button>
        {alertOpen && (
          <div className="absolute top-9 left-0 rounded-md border shadow-xl p-3 w-64 z-40"
            style={{ background: dark ? '#1E222D' : '#FFFFFF', borderColor: border }}>
            <div className="text-[12px] font-semibold mb-2">Price alerts</div>
            <div className="flex gap-1.5 mb-2">
              <input
                type="number"
                value={alertPrice}
                onChange={(e) => setAlertPriceInput(e.target.value)}
                placeholder="Price"
                className="flex-1 px-2 py-1 rounded border bg-transparent text-[11px]"
                style={{ borderColor: border, color: text }}
              />
              <select
                value={alertDir}
                onChange={(e) => setAlertDir(e.target.value as 'above' | 'below')}
                className="px-1 py-1 rounded border bg-transparent text-[11px]"
                style={{ borderColor: border, color: text }}
              >
                <option value="above">Crossing up</option>
                <option value="below">Crossing down</option>
              </select>
            </div>
            <button
              onClick={() => {
                const p = parseFloat(alertPrice)
                if (Number.isFinite(p) && p > 0 && marketName) {
                  onAddAlert(p, alertDir)
                  setAlertOpen(false)
                }
              }}
              className="w-full py-1.5 rounded text-[11px] font-semibold text-white mb-2"
              style={{ background: '#2962FF' }}
            >
              Add alert on {marketName || '—'}
            </button>
            <div className="max-h-40 overflow-y-auto flex flex-col gap-1">
              {alerts.length === 0 && (
                <div className="text-[10px] text-center py-2" style={{ color: sub }}>No alerts yet</div>
              )}
              {alerts.map((a) => (
                <div key={a.id} className="flex items-center justify-between text-[10px] px-2 py-1 rounded"
                  style={{ background: dark ? '#131722' : '#F0F3FA', opacity: a.triggered ? 0.5 : 1 }}>
                  <span className="font-mono">
                    {a.symbol} {a.direction === 'above' ? '≥' : '≤'} {a.price}
                    {a.triggered ? ' ✓' : ''}
                  </span>
                  <button onClick={() => onRemoveAlert(a.id)} className="opacity-60 hover:opacity-100">✕</button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* log scale */}
      <button
        className={btn}
        onClick={toggleLogScale}
        title="Logarithmic price scale"
        style={logScale ? { color: '#2962FF' } : undefined}
      >
        <span className="text-[12px] font-bold">log</span>
      </button>

      {/* right cluster */}
      <div className="ml-auto flex items-center gap-1.5">
        <button className={btn} onClick={toggleRightPanel} title="Toggle right panel">
          <span className="text-[14px] leading-none">▤</span>
        </button>

        <button className={btn} onClick={() => setDark(!dark)} title="Theme">
          {dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </button>

        <div className="hidden sm:flex items-center gap-1 text-[11px] px-2 py-1 rounded-md"
          style={{ background: dark ? '#1E222D' : '#F0F3FA' }}>
          {brokerReconnecting
            ? <><WifiOff className="h-3 w-3 animate-pulse" style={{ color: '#F5A623' }} /><span style={{ color: '#F5A623' }}>RECONNECTING</span></>
            : brokerConnected
              ? liveActive
                ? <><Wifi className="h-3 w-3" style={{ color: '#089981' }} /><span style={{ color: '#089981' }}>LIVE</span></>
                : <><Wifi className="h-3 w-3" style={{ color: '#F5A623' }} /><span style={{ color: '#F5A623' }}>DATA STALE</span></>
              : <><WifiOff className="h-3 w-3" style={{ color: '#F23645' }} /><span style={{ color: '#F23645' }}>OFFLINE</span></>}
        </div>

        <div className="hidden md:flex items-center gap-1.5 text-[11px]">
          <span className="font-semibold tabular-nums">{balanceLabel}</span>
          <span
            className="px-1.5 py-0.5 rounded text-[9px] font-bold text-white"
            style={{ background: mode === 'demo' ? '#787B86' : '#089981' }}
          >
            {mode.toUpperCase()}
          </span>
        </div>

        <button className={btn} onClick={onLogout} title="Log out">
          <LogOut className="h-4 w-4" />
        </button>
      </div>
    </div>
  )
}
