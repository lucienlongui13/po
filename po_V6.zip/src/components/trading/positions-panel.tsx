'use client'

import { ArrowUpRight, ArrowDownRight, Timer, Eraser } from 'lucide-react'
import type { OpenPosition } from '@/hooks/use-pocket-option'

interface PositionsPanelProps {
  positions: OpenPosition[]
  currentPrice: number
  /** active_id → asset name mapping (Pocket Option positions carry no asset string). */
  assetNames?: Map<number, string>
}

function fmtRemaining(openTime: number, expirySeconds: number): string {
  // openTime is in seconds; estimate remaining from a passed-in expiry hint
  const elapsed = Math.floor(Date.now() / 1000) - openTime
  const remaining = expirySeconds - elapsed
  if (remaining <= 0) return 'expiring…'
  return remaining > 90 ? `${Math.round(remaining / 60)}m` : `${remaining}s`
}

export function PositionsPanel({ positions, currentPrice, assetNames }: PositionsPanelProps) {
  return (
    <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden">
      <div className="px-3 py-2 text-xs font-medium text-zinc-500 dark:text-zinc-400 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
        <span>Open Positions</span>
        <span className="text-[10px] bg-zinc-100 dark:bg-zinc-800 px-2 py-0.5 rounded-full">
          {positions.length}
        </span>
      </div>
      {positions.length === 0 ? (
        <div className="p-4 text-center text-sm text-zinc-500">No open positions</div>
      ) : (
        <div className="max-h-64 overflow-y-auto text-xs">
          <div className="grid grid-cols-6 px-3 py-2 text-zinc-500 dark:text-zinc-400">
            <div>Asset</div><div>Side</div><div>Strike</div><div>Now</div><div>Stake</div><div>P&amp;L</div>
          </div>
          <div className="divide-y divide-zinc-200 dark:divide-zinc-800">
            {positions.map((p) => {
              const price = p.current_price > 0 ? p.current_price : currentPrice
              const inFavor = p.side === 'call'
                ? price > p.open_quote
                : price < p.open_quote
              const pnl = inFavor ? p.invest * 0.87 : -p.invest
              return (
                <div key={p.id} className="grid grid-cols-6 px-3 py-2 items-center font-mono">
                  <div className="font-sans font-medium truncate">{assetNames?.get(p.active_id) ?? p.asset ?? p.active_id}</div>
                  <div className={p.side === 'call' ? 'text-emerald-500 flex items-center gap-0.5' : 'text-rose-500 flex items-center gap-0.5'}>
                    {p.side === 'call' ? <ArrowUpRight className="h-3 w-3" /> : <ArrowDownRight className="h-3 w-3" />}
                    {p.side.toUpperCase()}
                  </div>
                  <div>{p.open_quote > 1000 ? p.open_quote.toFixed(1) : p.open_quote.toFixed(5)}</div>
                  <div>{price > 1000 ? price.toFixed(1) : price.toFixed(5)}</div>
                  <div>${p.invest.toFixed(2)}</div>
                  <div className={inFavor ? 'text-emerald-500' : 'text-rose-500'}>
                    {inFavor ? '+' : ''}${pnl.toFixed(2)}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}

interface DealsPanelProps {
  deals: Array<{
    id: number | string
    asset: string
    action: 'call' | 'put'
    amount: number
    openPrice: number
    closePrice: number
    closeTime: number
    profit: number
    isWin: boolean
  }>
  /** v1.6 — mode replay : les deals affichés sont les trades SIMULÉS du
   * backtest (onglet « Trade History » pendant le replay). */
  sim?: boolean
  /** v1.6 — efface l'historique affiché (deals réels du backend). */
  onClear?: () => void
}

export function DealsPanel({ deals, sim = false, onClear }: DealsPanelProps) {
  const wins = deals.filter((d) => d.isWin).length
  const winRate = deals.length > 0 ? (wins / deals.length) * 100 : 0

  return (
    <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden">
      <div className="px-3 py-2 text-xs font-medium text-zinc-500 dark:text-zinc-400 border-b border-zinc-200 dark:border-zinc-800 flex items-center justify-between">
        <span className="flex items-center gap-1.5">
          {sim && (
            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded text-white" style={{ background: '#FF6D00' }}>
              REPLAY
            </span>
          )}
          {sim ? 'Simulated Trades · backtest' : 'Recent Trades'}
        </span>
        <span className="flex items-center gap-2">
          {deals.length > 0 && (
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-zinc-100 dark:bg-zinc-800">
              {wins}/{deals.length} won ({winRate.toFixed(0)}%)
            </span>
          )}
          {onClear && deals.length > 0 && (
            <button
              type="button"
              onClick={onClear}
              className="inline-flex items-center gap-1 rounded px-1.5 py-0.5 text-[10px] font-semibold border border-zinc-300 dark:border-zinc-700 hover:bg-black/5 dark:hover:bg-white/5"
              title={sim
                ? 'Efface les trades simulés du backtest — identique à RESET TRADES (orders, equity, stats)'
                : "Effacer l'historique affiché (les nouveaux deals réapparaîtront à leur survenue)"}
            >
              <Eraser className="h-3 w-3" /> {sim ? 'RESET' : 'EFFACER'}
            </button>
          )}
        </span>
      </div>
      {deals.length === 0 ? (
        <div className="p-4 text-center text-sm text-zinc-500">
          {sim
            ? 'No simulated trades yet — run the replay and place CALL/PUT orders (RESET TRADES clears this history).'
            : 'No closed trades yet — place a CALL or PUT order'}
        </div>
      ) : (
        <div className="max-h-64 overflow-y-auto divide-y divide-zinc-200 dark:divide-zinc-800 text-xs">
          {deals.map((d) => (
            <div key={String(d.id)} className="px-3 py-1.5 grid grid-cols-5 items-center font-mono">
              <span className={d.action === 'call' ? 'text-emerald-500' : 'text-rose-500'}>
                {d.action.toUpperCase()}
              </span>
              <span className="font-sans truncate">{d.asset}</span>
              <span className="text-zinc-500">{d.openPrice > 1000 ? d.openPrice.toFixed(1) : d.openPrice.toFixed(5)}</span>
              <span className={d.isWin ? 'text-emerald-500' : 'text-rose-500'}>
                {d.isWin ? '+' : ''}${d.profit.toFixed(2)}
              </span>
              <span className="text-zinc-500 flex items-center gap-1 justify-end">
                <Timer className="h-3 w-3" />
                {d.closeTime > 0 ? new Date(d.closeTime * 1000).toLocaleTimeString() : '—'}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

export { fmtRemaining }
