'use client'

import { TrendingUp, TrendingDown } from 'lucide-react'

export interface WatchItem {
  ticker: string
  name: string
  payout?: number
  isOtc?: boolean
  ltp: number
  chg: number
  live: boolean
}

interface SidebarProps {
  list: WatchItem[]
  onSelect: (ticker: string) => void
  active: string
}

export function Sidebar({ list, onSelect, active }: SidebarProps) {
  return (
    <div className="flex flex-col gap-1.5 px-2 pb-2 overflow-y-auto">
      <div className="text-xs font-medium text-zinc-500 dark:text-zinc-400 px-2 flex items-center justify-between">
        <span>Watchlist</span>
        <span className="text-[10px] bg-zinc-100 dark:bg-zinc-800 px-2 py-0.5 rounded-full">
          {list.length} assets
        </span>
      </div>
      {list.map((it) => {
        const isPositive = it.chg >= 0
        const hasPrice = it.ltp && it.ltp > 0

        return (
          <button
            key={it.ticker}
            onClick={() => onSelect(it.ticker)}
            className={
              'group text-left px-3 py-2.5 rounded-xl border hover:shadow-sm transition-all ' +
              (active === it.ticker
                ? 'border-indigo-500/40 bg-indigo-50 dark:bg-indigo-950/30'
                : 'border-zinc-200 dark:border-zinc-800 hover:bg-zinc-50 dark:hover:bg-zinc-800')
            }
          >
            <div className="flex items-center justify-between mb-1">
              <div className="font-semibold tracking-tight text-sm">{it.ticker}</div>
              {hasPrice ? (
                <div className="text-sm font-semibold font-mono">{it.ltp.toFixed(it.ltp > 1000 ? 1 : 5)}</div>
              ) : it.payout != null ? (
                <div className="text-xs text-emerald-500 font-medium">{it.payout}%</div>
              ) : (
                <div className="text-xs text-zinc-400 flex items-center gap-1">
                  <div className="w-1 h-1 rounded-full bg-amber-500 animate-pulse"></div>
                  {it.isOtc ? 'OTC' : '—'}
                </div>
              )}
            </div>
            <div className="flex items-center justify-between">
              <div className="text-xs text-zinc-500 dark:text-zinc-400 truncate max-w-[130px]">{it.name}</div>
              {it.live && hasPrice ? (
                <div className={'text-xs font-medium flex items-center gap-0.5 ' + (isPositive ? 'text-emerald-500' : 'text-rose-500')}>
                  {isPositive ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                  {isPositive ? '+' : ''}{it.chg.toFixed(2)}%
                </div>
              ) : null}
            </div>
          </button>
        )
      })}
      <div className="mt-1 px-2 py-2 text-[10px] text-zinc-500 dark:text-zinc-400">
        Live price streams for the selected asset. Payout shown for others.
      </div>
    </div>
  )
}
