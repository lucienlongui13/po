'use client'

import { useState } from 'react'
import { LogIn, Loader2, AlertCircle } from 'lucide-react'
import type { AccountMode, LoginResult } from '@/hooks/use-pocket-option'

interface LoginScreenProps {
  onLogin: (email: string, password: string, mode: AccountMode) => void
  loginResult: LoginResult | null
  defaultEmail: string
  defaultPassword: string
}

const FEATURES: Array<{ title: string; desc: string }> = [
  {
    title: 'Real-time Market Data',
    desc: 'Stream live OTC candles 24/7 from Pocket Option',
  },
  {
    title: 'Advanced Charting',
    desc: 'Interactive candlestick charts with live updates',
  },
  {
    title: 'Binary CALL/PUT Trading',
    desc: 'Place orders, track balance and open positions',
  },
]

export function LoginScreen({ onLogin, loginResult, defaultEmail, defaultPassword }: LoginScreenProps) {
  const [email, setEmail] = useState(defaultEmail)
  const [password, setPassword] = useState(defaultPassword)
  const [mode, setMode] = useState<AccountMode>('demo')
  const [submitting, setSubmitting] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !password || submitting) return
    setSubmitting(true)
    onLogin(email, password, mode)
    // safety: re-enable after 30s (backend auth timeout)
    setTimeout(() => setSubmitting(false), 30000)
  }

  return (
    <div className="min-h-screen w-full bg-gradient-to-br from-zinc-950 via-zinc-900 to-zinc-950 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center h-16 w-16 rounded-2xl overflow-hidden mb-4">
            { }
            <img src="/pc-trade-logo.jpg" alt="PiracyChecker Trade Logo" className="h-full w-full object-cover" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">PiracyChecker Trade</h1>
          <p className="text-zinc-400">Professional Trading Platform</p>
        </div>

        <div className="bg-zinc-900/50 backdrop-blur border border-zinc-800 rounded-2xl p-8">
          <h2 className="text-xl font-semibold text-white mb-6">Connect to Pocket Option</h2>

          <div className="space-y-4 mb-6">
            {FEATURES.map((f) => (
              <div key={f.title} className="flex items-start gap-3">
                <div className="h-6 w-6 rounded-full bg-indigo-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                  <div className="h-2 w-2 rounded-full bg-indigo-500"></div>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-white">{f.title}</h3>
                  <p className="text-xs text-zinc-400 mt-1">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="po-email" className="block text-xs font-medium text-zinc-400 mb-1.5">
                Pocket Option email
              </label>
              <input
                id="po-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full px-3 py-2.5 rounded-xl border border-zinc-800 bg-zinc-950 text-sm text-white outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>
            <div>
              <label htmlFor="po-password" className="block text-xs font-medium text-zinc-400 mb-1.5">
                Password
              </label>
              <input
                id="po-password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••••••"
                className="w-full px-3 py-2.5 rounded-xl border border-zinc-800 bg-zinc-950 text-sm text-white outline-none focus:ring-2 focus:ring-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-zinc-400 mb-1.5">Account mode</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setMode('demo')}
                  className={
                    'px-3 py-2.5 rounded-xl border text-sm font-medium transition-all ' +
                    (mode === 'demo'
                      ? 'border-emerald-500/50 bg-emerald-500/10 text-emerald-400'
                      : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:bg-zinc-900')
                  }
                >
                  Demo
                  <div className="text-[10px] font-normal opacity-70 mt-0.5">Virtual money</div>
                </button>
                <button
                  type="button"
                  onClick={() => setMode('real')}
                  className={
                    'px-3 py-2.5 rounded-xl border text-sm font-medium transition-all ' +
                    (mode === 'real'
                      ? 'border-rose-500/50 bg-rose-500/10 text-rose-400'
                      : 'border-zinc-800 bg-zinc-950 text-zinc-400 hover:bg-zinc-900')
                  }
                >
                  Real
                  <div className="text-[10px] font-normal opacity-70 mt-0.5">Real money</div>
                </button>
              </div>
              {mode === 'real' && (
                <p className="text-xs text-rose-400/90 mt-2">
                  Real mode places actual trades with your money.
                </p>
              )}
            </div>

            {loginResult && !loginResult.ok && loginResult.error && (
              <div className="flex items-start gap-2 p-3 rounded-xl bg-rose-500/10 border border-rose-500/20">
                <AlertCircle className="h-4 w-4 text-rose-400 flex-shrink-0 mt-0.5" />
                <p className="text-xs text-rose-300 break-all">{loginResult.error}</p>
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full bg-gradient-to-r from-indigo-500 to-fuchsia-500 hover:from-indigo-600 hover:to-fuchsia-600 disabled:opacity-60 text-white font-semibold py-3 px-4 rounded-xl transition-all flex items-center justify-center gap-2"
            >
              {submitting ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Connecting…
                </>
              ) : (
                <>
                  <LogIn className="h-5 w-5" />
                  Login with Pocket Option
                </>
              )}
            </button>
          </form>

          <p className="text-xs text-zinc-500 text-center mt-6">
            By continuing, you agree to Pocket Option&apos;s Terms of Service
          </p>
        </div>

        <div className="mt-6 p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl">
          <p className="text-xs text-amber-200/80">
            <strong className="text-amber-200">Note:</strong> Credentials are sent directly to your
            own Pocket Option account through the local API backend. Demo mode trades with virtual money.
          </p>
        </div>
      </div>
    </div>
  )
}
