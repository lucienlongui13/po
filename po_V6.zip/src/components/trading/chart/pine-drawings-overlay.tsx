'use client'

/**
 * Pine drawings overlay — renders the drawing-object half of Pine's Visual IR
 * (line.new / label.new / box.new / polyline.new / linefill.new, plot fills,
 * bgcolor bands) onto a canvas aligned with lightweight-charts, plus Pine
 * tables as positioned HTML.
 *
 * Implements the repo's canvas overlay pattern: rAF redraw loop, devicePixelRatio
 * canvas, timeToCoordinate/priceToCoordinate conversion with linear
 * extrapolation for coordinates outside the chart's data window (negative or
 * beyond-history bar indexes, extended lines).
 */

import { useEffect, useRef } from 'react'
import type { IChartApi, ISeriesApi, Time } from 'lightweight-charts'
import type { CandleLike } from '@/lib/indicators'
import type { PineDrawing, PineLabelDrawing, PineLineDrawing, PineBoxDrawing } from '@/lib/pine-engine'
import { usePineStore } from '@/lib/pine-store'
import { pineTimeToChartTime, toPineTime } from '@/lib/pine-time-axis'

const FONT_STACK = `-apple-system, BlinkMacSystemFont, 'Trebuchet MS', Roboto, Ubuntu, sans-serif`

function fontSizeFor(size: string | undefined): number {
  switch ((size ?? 'small').toLowerCase()) {
    case 'auto': return 10
    case 'tiny': return 9
    case 'normal': return 13
    case 'large': return 15
    case 'huge': return 19
    case 'small':
    default: return 11
  }
}

function alphaAware(hex: string | undefined, fallbackAlpha: number, fallback: string): string {
  if (!hex) return withAlpha(fallback, fallbackAlpha)
  return withAlpha(hex, fallbackAlpha)
}

/** Normalize a #RRGGBB[AA] string to an rgba() with the given alpha override. */
function withAlpha(hex: string, alpha: number): string {
  const m = hex.match(/^#?([0-9a-f]{6})([0-9a-f]{2})?$/i)
  if (!m) return hex
  const r = parseInt(m[1].slice(0, 2), 16)
  const g = parseInt(m[1].slice(2, 4), 16)
  const b = parseInt(m[1].slice(4, 6), 16)
  const a = Math.round(Math.min(1, Math.max(0, alpha)) * 255)
  return `rgba(${r},${g},${b},${a})`
}

function setLineDash(ctx: CanvasRenderingContext2D, style: string | undefined, width: number): void {
  switch ((style ?? 'solid').toLowerCase()) {
    case 'dotted': ctx.setLineDash([1.5, Math.max(2, width * 1.8)]); break
    case 'dashed': ctx.setLineDash([Math.max(4, width * 3), Math.max(3, width * 2)]); break
    default: ctx.setLineDash([])
  }
}

interface Props {
  getChart: () => IChartApi | null
  getSeries: () => ISeriesApi<any> | null
  getCandles: () => CandleLike[]
  dark: boolean
}

export function PineDrawingsOverlay({ getChart, getSeries, getCandles, dark }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const scripts = usePineStore((s) => s.scripts)
  const scriptsRef = useRef(scripts)
  const darkRef = useRef(dark)
  useEffect(() => { scriptsRef.current = scripts }, [scripts])
  useEffect(() => { darkRef.current = dark }, [dark])

  // Read-only introspection hook for e2e regression tests (alignment guards)
  // and live diagnostics. Exposes nothing mutable; never throws.
  useEffect(() => {
    if (typeof window === 'undefined') return
    ;(window as unknown as Record<string, unknown>).__pineChartDebug = {
      getChart, getSeries, getCandles,
      getScripts: () => scriptsRef.current,
    }
    return () => {
      delete (window as unknown as Record<string, unknown>).__pineChartDebug
    }
  }, [getChart, getSeries, getCandles])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    let raf = 0
    let lastW = 0
    let lastH = 0

    const draw = () => {
      raf = requestAnimationFrame(draw)
      const chart = getChart()
      const series = getSeries()
      if (!chart || !series) { ctx.clearRect(0, 0, canvas.width, canvas.height); return }

      /* ── resize (devicePixelRatio aware) ── */
      const parent = canvas.parentElement
      const w = parent ? parent.clientWidth : 0
      const h = parent ? parent.clientHeight : 0
      if (w === 0 || h === 0) return
      if (w !== lastW || h !== lastH) {
        lastW = w
        lastH = h
        const dpr = window.devicePixelRatio || 1
        canvas.width = Math.max(1, Math.floor(w * dpr))
        canvas.height = Math.max(1, Math.floor(h * dpr))
        canvas.style.width = `${w}px`
        canvas.style.height = `${h}px`
      }
      const dpr = window.devicePixelRatio || 1
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.clearRect(0, 0, w, h)

      const ts = chart.timeScale()
      const candles = getCandles()
      const all = scriptsRef.current.filter((s) => s.enabled && s.result)
      if (!candles.length || !all.length) return

      let priceScaleWidth = 0
      try { priceScaleWidth = chart.priceScale('right').width() } catch { priceScaleWidth = 0 }
      const plotRight = Math.max(10, w - priceScaleWidth)

      /* ── coordinate conversion with extrapolation ──
         LWC's logical→pixel mapping is linear: x = (logical - from) * barSpacing
         where barSpacing = plotWidth / (to - from). Pine times outside the
         chart data window get a fractional logical index via binary search. */
      const times = candles.map((c) => toPineTime(Number(c.time)))
      const logicalOfTime = (t: number): number | null => {
        let lo = 0, hi = times.length - 1
        if (t <= times[0]) {
          const interval = times.length > 1 ? times[1] - times[0] : 60_000
          return (t - times[0]) / interval
        }
        if (t >= times[hi]) {
          const interval = times.length > 1 ? times[hi] - times[hi - 1] : 60_000
          return hi + (t - times[hi]) / interval
        }
        while (lo < hi) {
          const mid = (lo + hi) >> 1
          if (times[mid] <= t) lo = mid + 1
          else hi = mid
        }
        const t1 = times[lo - 1], t2 = times[lo]
        return lo - 1 + (t - t1) / Math.max(1, t2 - t1)
      }

      const timeToX = (t: number): number | null => {
        try {
          const x = ts.timeToCoordinate(t as Time)
          if (x != null) return x as number
        } catch { /* outside visible range */ }
        const range = ts.getVisibleLogicalRange()
        if (!range) return null
        const logical = logicalOfTime(t)
        if (logical == null) return null
        const barSpacing = plotRight / Math.max(1e-6, range.to - range.from)
        return (logical - range.from) * barSpacing
      }

      const priceToY = (p: number): number | null => {
        try {
          const y = series.priceToCoordinate(p)
          return y == null ? null : (y as number)
        } catch { return null }
      }

      const isDark = darkRef.current
      const defaultText = isDark ? '#D1D4DC' : '#131722'

      /* ═══ bgcolor bands (overlay scripts only) ═══ */
      for (const script of all) {
        if (!script.result!.overlay) continue
        const layerList = script.result!.bgColors || []
        const pineTimes = script.result!._times
        if (!layerList.length || !pineTimes?.length) continue
        const range = ts.getVisibleLogicalRange()
        if (!range) continue
        const barSpacing = plotRight / Math.max(1e-6, range.to - range.from)
        for (const layer of layerList) {
          if (!Array.isArray(layer)) continue
          for (let i = 0; i < Math.min(layer.length, pineTimes.length); i++) {
            const color = layer[i]
            if (!color) continue
            const logical = logicalOfTime(pineTimes[i])
            if (logical == null) continue
            const x = (logical - range.from) * barSpacing
            if (x < -barSpacing || x > plotRight + barSpacing) continue
            ctx.fillStyle = color
            ctx.fillRect(x - barSpacing / 2, 0, barSpacing + 0.5, h)
          }
        }
      }

      /* ═══ fills between plots/hlines (overlay scripts only) ═══ */
      const fillPolygon = (
        dataA: Array<number | null>, dataB: Array<number | null>,
        timesArr: number[], color: string | null, colors: Array<string | null>,
      ) => {
        const pts: Array<{ x: number; ya: number; yb: number; color: string }> = []
        const n = Math.min(dataA.length, dataB.length, timesArr.length)
        for (let i = 0; i < n; i++) {
          const va = dataA[i], vb = dataB[i]
          if (va == null || vb == null) continue
          const x = timeToX(timesArr[i])
          const ya = priceToY(va), yb = priceToY(vb)
          if (x == null || ya == null || yb == null) continue
          pts.push({ x, ya, yb, color: colors[i] || color || '#2962FF33' })
        }
        if (pts.length < 2) return
        // Segment-wise fill so per-bar colors stay visible.
        for (let i = 1; i < pts.length; i++) {
          const p0 = pts[i - 1], p1 = pts[i]
          ctx.beginPath()
          ctx.moveTo(p0.x, p0.ya); ctx.lineTo(p1.x, p1.ya)
          ctx.lineTo(p1.x, p1.yb); ctx.lineTo(p0.x, p0.yb)
          ctx.closePath()
          ctx.fillStyle = p1.color
          ctx.fill()
        }
      }

      for (const script of all) {
        const result = script.result!
        if (!result.overlay) continue
        const pineTimes = result._times ?? []
        for (const fill of result.fills || []) {
          const plotA = result.plots.find((p) => p.id === fill.plot1)
          const plotB = result.plots.find((p) => p.id === fill.plot2)
          const hlineA = result.hlines.find((l) => l.id === fill.plot1)
          const hlineB = result.hlines.find((l) => l.id === fill.plot2)
          const dataA = plotA ? plotA.data : hlineA ? pineTimes.map(() => hlineA.price) : null
          const dataB = plotB ? plotB.data : hlineB ? pineTimes.map(() => hlineB.price) : null
          if (!dataA || !dataB) continue
          fillPolygon(dataA, dataB, pineTimes, fill.color, fill.colors)
        }
      }

      /* ═══ drawing objects ═══
         OVERLAY scripts only — a non-overlay script's drawings live in the
         coordinate space of its own pane (oscillator values, not prices), so
         rendering them on the price chart would place them at absurd price
         levels. PineSubPane renders those. */
      const drawLine = (d: PineLineDrawing) => {
        const x1 = timeToX(d.x1), x2 = timeToX(d.x2)
        const y1 = priceToY(d.y1), y2 = priceToY(d.y2)
        if (x1 == null || x2 == null || y1 == null || y2 == null) return
        let px1 = x1, px2 = x2, py1 = y1, py2 = y2
        // Extension is performed in pixel space (both scales are linear):
        // extrapolate y along the (x1,y1)→(x2,y2) pixel direction.
        const extend = (d.extend ?? 'none').toLowerCase()
        if ((extend === 'right' || extend === 'both') && px2 !== px1) {
          const t = (plotRight - px1) / (px2 - px1)
          py2 = py1 + (py2 - py1) * t
          px2 = plotRight
        }
        if ((extend === 'left' || extend === 'both') && px2 !== px1) {
          const t = (0 - px1) / (px2 - px1)
          py1 = py1 + (py2 - py1) * t
          px1 = 0
        }
        if (Math.max(px1, px2) < -20 || Math.min(px1, px2) > w + 20) return
        const color = d.color || (isDark ? '#D1D4DC' : '#131722')
        const width = Math.max(1, Math.min(6, d.width ?? 1))
        ctx.save()
        ctx.strokeStyle = color
        ctx.lineWidth = width
        ctx.lineCap = 'round'
        setLineDash(ctx, d.style, width)
        ctx.beginPath(); ctx.moveTo(px1, py1); ctx.lineTo(px2, py2); ctx.stroke()
        ctx.restore()
      }

      const drawLabel = (d: PineLabelDrawing) => {
        const x = timeToX(d.x)
        if (x == null) return
        const y = d.y != null ? priceToY(d.y) : null
        if (y == null) return
        if (x < -160 || x > w + 160 || y < -60 || y > h + 60) return
        const text = d.text ?? ''
        const fontSize = fontSizeFor(d.size)
        ctx.save()
        ctx.font = `bold ${fontSize}px ${FONT_STACK}`
        const style = (d.style ?? 'label_up').toLowerCase()
        const textColor = d.textcolor ?? (style.startsWith('label') && d.color ? '#FFFFFF' : defaultText)

        const isCallout = style.startsWith('label_')
        if (isCallout && text) {
          const padX = 6, padY = 4
          const wText = ctx.measureText(text).width
          const bw = wText + padX * 2
          const bh = fontSize + padY * 2
          const arrow = Math.max(4, fontSize * 0.32)
          const bg = d.color ?? (isDark ? '#2962FF' : '#2962FF')
          let bx = x - bw / 2, by = y + arrow // label_up: body below anchor
          let tri: Array<[number, number]> | null = [[x, y], [x - arrow * 0.7, y + arrow], [x + arrow * 0.7, y + arrow]]
          if (style === 'label_down') {
            by = y - arrow - bh
            tri = [[x, y], [x - arrow * 0.7, y - arrow], [x + arrow * 0.7, y - arrow]]
          } else if (style === 'label_left') {
            // arrow points left → body to the right of the anchor
            bx = x + arrow; by = y - bh / 2
            tri = [[x, y], [x + arrow, y - arrow * 0.7], [x + arrow, y + arrow * 0.7]]
          } else if (style === 'label_right') {
            // arrow points right → body to the left of the anchor
            bx = x - arrow - bw; by = y - bh / 2
            tri = [[x, y], [x - arrow, y - arrow * 0.7], [x - arrow, y + arrow * 0.7]]
          } else if (style.includes('upper_left')) {
            bx = x + arrow; by = y + arrow
          } else if (style.includes('upper_right')) {
            bx = x - arrow - bw; by = y + arrow
          } else if (style.includes('lower_left')) {
            bx = x + arrow; by = y - arrow - bh
          } else if (style.includes('lower_right')) {
            bx = x - arrow - bw; by = y - arrow - bh
          }
          // body + arrow
          ctx.fillStyle = bg
          ctx.beginPath()
          const r = 3
          ctx.moveTo(bx + r, by)
          ctx.lineTo(bx + bw - r, by); ctx.quadraticCurveTo(bx + bw, by, bx + bw, by + r)
          ctx.lineTo(bx + bw, by + bh - r); ctx.quadraticCurveTo(bx + bw, by + bh, bx + bw - r, by + bh)
          ctx.lineTo(bx + r, by + bh); ctx.quadraticCurveTo(bx, by + bh, bx, by + bh - r)
          ctx.lineTo(bx, by + r); ctx.quadraticCurveTo(bx, by, bx + r, by)
          ctx.closePath(); ctx.fill()
          if (tri) { ctx.beginPath(); ctx.moveTo(tri[0][0], tri[0][1]); ctx.lineTo(tri[1][0], tri[1][1]); ctx.lineTo(tri[2][0], tri[2][1]); ctx.closePath(); ctx.fill() }
          ctx.fillStyle = textColor
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
          ctx.fillText(text, bx + bw / 2, by + bh / 2 + 0.5)
        } else {
          // plain text styles: text_outline / none / shapes fall back to text
          ctx.fillStyle = textColor
          ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
          if (style === 'text_outline') {
            ctx.shadowColor = isDark ? 'rgba(0,0,0,.65)' : 'rgba(255,255,255,.9)'
            ctx.shadowBlur = 3
          }
          const dy = d.yloc === 'abovebar' ? -fontSize : d.yloc === 'belowbar' ? fontSize : 0
          ctx.fillText(text, x, y + dy)
          ctx.shadowBlur = 0
        }
        ctx.restore()
      }

      const drawBox = (d: PineBoxDrawing) => {
        const xl = timeToX(d.left), xr = timeToX(d.right)
        const yt = priceToY(d.top), yb = priceToY(d.bottom)
        if (xl == null || xr == null || yt == null || yb == null) return
        if (Math.max(xl, xr) < -20 || Math.min(xl, xr) > w + 20) return
        const x = Math.min(xl, xr), bw = Math.max(2, Math.abs(xr - xl))
        const y = Math.min(yt, yb), bh = Math.max(1, Math.abs(yb - yt))
        ctx.save()
        if (d.bgcolor) { ctx.fillStyle = d.bgcolor; ctx.fillRect(x, y, bw, bh) }
        const borderColor = d.borderColor ?? d.bgcolor
        if (borderColor) {
          ctx.strokeStyle = borderColor
          ctx.lineWidth = Math.max(1, Math.min(6, d.borderWidth ?? 1))
          setLineDash(ctx, d.borderStyle, ctx.lineWidth)
          ctx.strokeRect(x + 0.5, y + 0.5, bw - 1, bh - 1)
        }
        if (d.text) {
          const fontSize = fontSizeFor(d.textSize)
          ctx.font = `bold ${fontSize}px ${FONT_STACK}`
          const align = (d.textHalign ?? 'center').toLowerCase()
          ctx.textAlign = align === 'left' ? 'left' : align === 'right' ? 'right' : 'center'
          const valign = (d.textValign ?? 'center').toLowerCase()
          ctx.textBaseline = valign === 'top' ? 'top' : valign === 'bottom' ? 'bottom' : 'middle'
          ctx.fillStyle = d.textColor ?? defaultText
          const tx = align === 'left' ? x + 5 : align === 'right' ? x + bw - 5 : x + bw / 2
          const ty = valign === 'top' ? y + 4 : valign === 'bottom' ? y + bh - 4 : y + bh / 2
          ctx.fillText(d.text, tx, ty)
        }
        ctx.restore()
      }

      for (const script of all) {
        const result = script.result!
        if (!result.overlay) continue
        const drawings = result.drawings || []
        if (!drawings.length) continue
        const linesById = new Map<number, PineLineDrawing>()
        for (const d of drawings) if (d.kind === 'line' && d.id != null) linesById.set(d.id, d)

        for (const d of drawings) {
          switch (d.kind) {
            case 'line': drawLine(d); break
            case 'label': drawLabel(d); break
            case 'box': drawBox(d); break
            case 'polyline': {
              const pts = d.points
                .map((pt) => ({ x: timeToX(pt.time), y: priceToY(pt.price) }))
                .filter((p): p is { x: number; y: number } => p.x != null && p.y != null)
              if (pts.length < 2) break
              const color = d.lineColor ?? (isDark ? '#D1D4DC' : '#131722')
              const width = Math.max(1, Math.min(6, d.lineWidth ?? 1))
              ctx.save()
              ctx.strokeStyle = color
              ctx.lineWidth = width
              ctx.lineJoin = 'round'
              setLineDash(ctx, d.lineStyle, width)
              ctx.beginPath()
              ctx.moveTo(pts[0].x, pts[0].y)
              for (let i = 1; i < pts.length; i++) ctx.lineTo(pts[i].x, pts[i].y)
              ctx.stroke()
              ctx.restore()
              break
            }
            case 'linefill': {
              const l1 = linesById.get(d.line1)
              const l2 = linesById.get(d.line2)
              if (!l1 || !l2) break
              const a1 = timeToX(l1.x1), a2 = timeToX(l1.x2)
              const b1 = timeToX(l2.x1), b2 = timeToX(l2.x2)
              const ya1 = priceToY(l1.y1), ya2 = priceToY(l1.y2)
              const yb1 = priceToY(l2.y1), yb2 = priceToY(l2.y2)
              if (a1 == null || a2 == null || b1 == null || b2 == null || ya1 == null || ya2 == null || yb1 == null || yb2 == null) break
              ctx.save()
              ctx.fillStyle = d.color ?? '#2962FF33'
              ctx.beginPath()
              ctx.moveTo(a1, ya1); ctx.lineTo(a2, ya2); ctx.lineTo(b2, yb2); ctx.lineTo(b1, yb1)
              ctx.closePath(); ctx.fill()
              ctx.restore()
              break
            }
            default: break // tables are rendered by PineTablesOverlay
          }
        }
      }
      /* ═══ alert markers (overlay scripts) ═══
         Piner records every alert()/alertcondition() event with its bar.
         TradingView-style visibility: an amber bell badge anchored on the
         event bar's close, with the message for recent/sparse events. */
      const timeToCandle = new Map<number, CandleLike>()
      for (const c of candles) timeToCandle.set(Number(c.time), c)
      const drawBell = (x: number, y: number) => {
        ctx.save()
        ctx.fillStyle = '#FF9800'
        ctx.beginPath(); ctx.arc(x, y, 6, 0, Math.PI * 2); ctx.fill()
        ctx.fillStyle = '#FFFFFF'
        // tiny bell: dome + skirt + clapper
        ctx.beginPath()
        ctx.arc(x, y - 1.4, 3.1, Math.PI, 0)
        ctx.lineTo(x + 3.1, y + 2.1)
        ctx.lineTo(x - 3.1, y + 2.1)
        ctx.closePath(); ctx.fill()
        ctx.beginPath(); ctx.arc(x, y + 3.4, 1.05, 0, Math.PI * 2); ctx.fill()
        ctx.restore()
      }
      for (const script of all) {
        const result = script.result!
        if (!result.overlay) continue
        const alerts = (result.alerts || []).filter((a) => a.time != null)
        if (!alerts.length) continue
        const recent = alerts.slice(-120)
        const drawText = recent.length <= 8
        for (let i = 0; i < recent.length; i++) {
          const a = recent[i]
          const x = timeToX(a.time!)
          if (x == null || x < 6 || x > plotRight - 6) continue
          const candle = timeToCandle.get(pineTimeToChartTime(a.time!))
          const y = candle ? priceToY(candle.close) : null
          if (y == null || y < -8 || y > h + 8) continue
          drawBell(x, y)
          if (drawText || i === recent.length - 1) {
            ctx.save()
            ctx.font = `bold 9px ${FONT_STACK}`
            ctx.textAlign = 'left'; ctx.textBaseline = 'middle'
            ctx.fillStyle = 'rgba(255,152,0,.95)'
            ctx.fillText(a.message.slice(0, 42), x + 10, y)
            ctx.restore()
          }
        }
      }
    }

    raf = requestAnimationFrame(draw)
    return () => cancelAnimationFrame(raf)
  }, [getChart, getSeries, getCandles])

  return <canvas ref={canvasRef} className="absolute inset-0 z-[4] pointer-events-none" />
}

/* ══════════════════════════════════════════════════════════════════════════
   Pine tables — HTML overlay anchored to screen edges (never to prices).
   ══════════════════════════════════════════════════════════════════════════ */

const TABLE_POSITIONS: Record<string, string> = {
  top_left: 'top-2 left-2',
  top_center: 'top-2 left-1/2 -translate-x-1/2',
  top_right: 'top-2 right-2',
  middle_left: 'top-1/2 -translate-y-1/2 left-2',
  middle_center: 'top-1/2 -translate-y-1/2 left-1/2 -translate-x-1/2',
  middle_right: 'top-1/2 -translate-y-1/2 right-2',
  bottom_left: 'bottom-2 left-2',
  bottom_center: 'bottom-2 left-1/2 -translate-x-1/2',
  bottom_right: 'bottom-2 right-2',
}

export function PineTablesOverlay({ dark }: { dark: boolean }) {
  // Screen-anchored HTML overlays; re-renders naturally when the store's
  // scripts array changes (results included).
  const scripts = usePineStore((s) => s.scripts)

  const tables = scripts
    .filter((s) => s.enabled && s.result?.drawings)
    .flatMap((s) => s.result!.drawings.filter((d): d is Extract<PineDrawing, { kind: 'table' }> => d.kind === 'table'))

  if (!tables.length) return null

  const border = dark ? '#2A2E39' : '#E0E3EB'
  const fallbackBg = dark ? 'rgba(32,34,41,.92)' : 'rgba(247,248,250,.94)'

  return (
    <div className="absolute inset-0 z-[5] pointer-events-none">
      {tables.map((table, ti) => {
        const posClass = TABLE_POSITIONS[table.position] ?? TABLE_POSITIONS.top_right
        const cols = Math.max(1, Math.min(50, table.columns))
        const rows = Math.max(1, Math.min(120, table.rows))
        const occupied = new Set<string>()
        // Place merged ranges first, then fill remaining slots.
        const spans: Array<{ slot: string; cell: NonNullable<unknown> & { text?: string; textColor?: string; bgcolor?: string; textSize?: string; textHalign?: string; merged?: { startRow: number; startCol: number; endRow: number; endCol: number } }; style: React.CSSProperties }> = []
        for (const [slot, cell] of Object.entries(table.cells)) {
          if (!cell) continue
          if (cell.merged) {
            const { startRow, startCol, endRow, endCol } = cell.merged
            const rowSpan = Math.max(1, endRow - startRow + 1)
            const colSpan = Math.max(1, endCol - startCol + 1)
            for (let r = startRow; r <= endRow; r++) for (let c = startCol; c <= endCol; c++) occupied.add(`${r},${c}`)
            spans.push({
              slot: `${startRow},${startCol}`,
              cell: cell as any,
              style: { gridColumn: `${startCol + 1} / span ${colSpan}`, gridRow: `${startRow + 1} / span ${rowSpan}` },
            })
          } else {
            spans.push({ slot, cell: cell as any, style: {} })
            occupied.add(slot)
          }
        }
        return (
          <div
            key={`${ti}-${table.position}`}
            className={`absolute ${posClass} pointer-events-none select-none`}
            style={{
              display: 'grid',
              gridTemplateColumns: `repeat(${cols}, minmax(24px, auto))`,
              gap: 0,
              border: `1px solid ${border}`,
              borderRadius: 4,
              overflow: 'hidden',
              boxShadow: dark ? '0 2px 10px rgba(0,0,0,.5)' : '0 2px 10px rgba(0,0,0,.12)',
              fontFamily: FONT_STACK,
              maxWidth: 'min(480px, 60%)',
              maxHeight: '55%',
              overflowY: 'hidden',
            }}
          >
            {Array.from({ length: rows * cols }, (_, i) => {
              const r = Math.floor(i / cols), c = i % cols
              const slot = `${r},${c}`
              const span = spans.find((s) => s.slot === slot)
              if (!span) {
                // Render merged-covered slots as nothing (grid spans handle them).
                if (occupied.has(slot)) return <div key={slot} />
                return <div key={slot} style={{ background: fallbackBg, minHeight: 4, minWidth: 4 }} />
              }
              const cell = span.cell
              const size = fontSizeFor(cell.textSize)
              return (
                <div
                  key={slot}
                  style={{
                    ...span.style,
                    background: cell.bgcolor ?? fallbackBg,
                    color: cell.textColor ?? (dark ? '#D1D4DC' : '#131722'),
                    fontSize: size,
                    lineHeight: `${Math.round(size * 1.35)}px`,
                    padding: size <= 9 ? '1px 5px' : '2px 7px',
                    textAlign: cell.textHalign === 'left' ? 'left' : cell.textHalign === 'right' ? 'right' : (cell.textHalign as any) === undefined ? 'left' : 'center',
                    whiteSpace: 'pre',
                    fontWeight: 500,
                  }}
                >
                  {cell.text ?? ''}
                </div>
              )
            })}
          </div>
        )
      })}
    </div>
  )
}
