'use client'

/**
 * backtest-panel.tsx — Strategy Tester panel (replay backtesting report).
 *
 * Live stats for simulated binary orders placed during bar replay:
 * balance, net P&L, win rate, profit factor, drawdown, equity curve
 * sparkline and the list of simulated trades.
 *
 * LOG TRADES (v1.5) : switch qui journalise CHAQUE trade simulé dans
 * `.logs/trade.jsonl` (via l'API /api/trade-log) — avec toutes les
 * conditions détectées sur les bougies apparues AVANT et PENDANT le
 * trade (voir src/lib/trade-logger.ts). OFF (défaut) → rien n'est loggé.
 */

import { useEffect, useState } from 'react'
import { TrendingUp, TrendingDown, Minus, Download, Wallet, RotateCcw, FileJson, AlertTriangle, Bot } from 'lucide-react'

import type { ReplayEngine, BacktestStats, SimOrder } from '@/lib/replay-engine'
import type { TradeLogger } from '@/lib/trade-logger'
import { BACKTEST_STRATEGIES, type LucienProTraderBacktester } from '@/lib/lucien-backtest'

interface BacktestPanelProps {
  replay: ReplayEngine
  dark: boolean
  compact?: boolean
  candleSize?: number
  onFetchHistory?: (days: number) => void | Promise<void>
  /** Solde de départ courant du backtest (persisté par page.tsx). */
  startBalance: number
  /** Nouveau solde de départ → réinitialise les trades du backtest. */
  onSetStartBalance: (balance: number) => void
  /** Remise à zéro de l'historique des trades (orders + equity + stats). */
  onResetTrades: () => void
  /** Journalisation des trades (switch « Log trades » → .logs/trade.jsonl). */
  tradeLogger?: TradeLogger | null
  /** v22 — Strategy Tester : backtesting AUTOMATIQUE L_Lucien ProTrader
   * (combinaisons + Candles Validation du panneau Auto Trade, expiration
   * convertie en nombre de bougies). */
  lucienBacktester?: LucienProTraderBacktester | null
}

/** v26 — §20 : GRANDE carte de statistique LISIBLE (jamais quasi invisible). */
function StatCard({ label, value, color, text, sub }: {
  label: string; value: string; color?: string; text: string; sub: string
}) {
  return (
    <div className="flex flex-col justify-center gap-1 rounded-lg border px-3 py-2.5 min-w-[128px] flex-1" style={{ borderColor: sub + '33' }}>
      <span className="text-[10px] uppercase tracking-wide font-semibold" style={{ color: sub }}>{label}</span>
      <span className="text-xl font-bold tabular-nums leading-none" style={{ color: color ?? text }}>{value}</span>
    </div>
  )
}

function Stat({ label, value, color, text, sub }: {
  label: string; value: string; color?: string; text: string; sub: string
}) {
  return (
    <div className="flex flex-col gap-0.5 min-w-[86px]">
      <span className="text-[10px] uppercase tracking-wide" style={{ color: sub }}>{label}</span>
      <span className="text-sm font-semibold tabular-nums" style={{ color: color ?? text }}>{value}</span>
    </div>
  )
}

function EquitySpark({ points, dark }: { points: Array<{ time: number; value: number }>; dark: boolean }) {
  if (points.length < 2) {
    return <div className="h-16 flex items-center justify-center text-[10px] opacity-50">Equity curve appears after the first settled trade</div>
  }
  const w = 260
  const h = 56
  const values = points.map((p) => p.value)
  const min = Math.min(...values)
  const max = Math.max(...values)
  const range = max - min || 1
  const up = values[values.length - 1] >= values[0]
  const color = up ? '#089981' : '#F23645'
  const d = points
    .map((p, i) => {
      const x = (i / (points.length - 1)) * w
      const y = h - ((p.value - min) / range) * (h - 6) - 3
      return `${i === 0 ? 'M' : 'L'}${x.toFixed(1)},${y.toFixed(1)}`
    })
    .join(' ')
  const area = `${d} L${w},${h} L0,${h} Z`
  return (
    <svg width="100%" height={h + 8} viewBox={`0 0 ${w} ${h + 8}`} preserveAspectRatio="none">
      <path d={area} fill={color} opacity={dark ? 0.15 : 0.12} />
      <path d={d} fill="none" stroke={color} strokeWidth={1.5} />
    </svg>
  )
}

export function BacktestPanel({ replay, dark, compact, candleSize = 60, onFetchHistory, startBalance, onSetStartBalance, onResetTrades, tradeLogger, lucienBacktester }: BacktestPanelProps) {
  const [historyDays, setHistoryDays] = useState('')
  const [fetching, setFetching] = useState(false)
  const [balanceDraft, setBalanceDraft] = useState(String(startBalance))
  const [stats, setStats] = useState<BacktestStats>(() => replay.getStats())
  const [orders, setOrders] = useState<SimOrder[]>([])
  // État du journal « Log trades » (re-render à chaque changement notifié).
  const [, setLogRev] = useState(0)
  // v22 — backtesting automatique L_Lucien ProTrader (re-render à chaque
  // signal/ordre notifié par le backtester).
  const [, setBtRev] = useState(0)
  const [btStakeDraft, setBtStakeDraft] = useState('')
  const [btPayoutDraft, setBtPayoutDraft] = useState('')

  useEffect(() => {
    if (!tradeLogger) return
    return tradeLogger.subscribe(() => setLogRev((r) => r + 1))
  }, [tradeLogger])

  // v22 — abonnement au backtester (signaux, ordres, réglages).
  useEffect(() => {
    if (!lucienBacktester) return
    return lucienBacktester.subscribe(() => setBtRev((r) => r + 1))
  }, [lucienBacktester])

  // Le brouillon suit le solde persisté (reset externe, changement d'onglet…)
  useEffect(() => { setBalanceDraft(String(startBalance)) }, [startBalance])

  useEffect(() => {
    // UPDATE-PRESSURE GUARD: onState fires on every replay advance (up to
    // 20×/s). The stats/orders objects are always fresh references, so the
    // previous unconditional setState re-rendered this panel — including the
    // 100-row trades table — on every single candle and contributed to
    // React's "Maximum update depth exceeded" during fast replay. The panel
    // now re-renders only when the displayed content actually changed (an
    // order was placed, settled, refunded, or the balance was reset).
    let lastSig = ''
    const sigOf = (st: BacktestStats, os: SimOrder[]) =>
      [st.startBalance, st.balance, st.availableBalance, st.netProfit,
        st.totalTrades, st.openTrades, st.wins, st.losses, st.refunds,
        st.maxDrawdown, st.equityCurve.length, os.length].join('|')
    const unsub = replay.onState((_s, st, os) => {
      const sig = sigOf(st, os)
      if (sig === lastSig) return
      lastSig = sig
      setStats({ ...st })
      setOrders(os.slice())
    })
    // initial sync deferred (avoids synchronous setState in effect body)
    const t = setTimeout(() => {
      const st = replay.getStats()
      const os = replay.allOrders.slice(0, 100)
      lastSig = sigOf(st, os)
      setStats({ ...st })
      setOrders(os)
    }, 0)
    return () => { clearTimeout(t); unsub() }
  }, [replay])

  const border = dark ? '#2A2E39' : '#E0E3EB'
  const bg = dark ? '#131722' : '#FFFFFF'
  const text = dark ? '#D1D4DC' : '#131722'
  const sub = '#787B86'

  const pnlColor = stats.netProfit > 0 ? '#089981' : stats.netProfit < 0 ? '#F23645' : sub

  // v26 — état courant du backtester (stratégie auto — L_Lucien | Ninja).
  const bt = lucienBacktester?.getState() ?? { enabled: false, strategyId: 'l_lucien_protrader' as const, stake: 1, payout: 92, lastSignal: null, placedCount: 0 }
  const btSummary = lucienBacktester?.getRulesSummary() ?? { callRules: 0, putRules: 0, validatedRules: 0 }

  const fetchHistory = async () => {
    const parsed = Number(historyDays)
    if (!Number.isFinite(parsed) || parsed < 1 || parsed > 10) return
    const days = Math.floor(parsed)
    setFetching(true)
    try {
      await onFetchHistory?.(days)
    } finally {
      setFetching(false)
    }
  }

  const applyBalance = () => {
    const parsed = Number(balanceDraft)
    if (!Number.isFinite(parsed) || parsed < 1) {
      setBalanceDraft(String(startBalance))
      return
    }
    onSetStartBalance(Math.round(parsed * 100) / 100)
  }

  const requestedCandles = historyDays === '' ? 0 : Math.ceil(Number(historyDays) * 86400 / Math.max(1, candleSize))

  /* ── switch « Log trades » + état du journal ── */
  const logEnabled = tradeLogger?.enabled ?? false
  const renderLogToggle = (size: 'sm' | 'md') => (
    <div className="inline-flex items-center gap-1.5" title={logEnabled
      ? 'Chaque trade simulé est journalisé dans .logs/trade.jsonl avec toutes les conditions détectées sur les bougies apparues avant et pendant le trade'
      : 'Activer pour journaliser chaque trade simulé (conditions avant/pendant) dans .logs/trade.jsonl'}>
      <FileJson className={size === 'sm' ? 'h-3 w-3' : 'h-3.5 w-3.5'} style={{ color: logEnabled ? '#089981' : sub }} />
      <span className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: logEnabled ? '#089981' : sub }}>
        Log trades
      </span>
      <button
        type="button"
        aria-label="Toggle log trades"
        aria-pressed={logEnabled}
        onClick={() => tradeLogger?.setEnabled(!logEnabled)}
        className="relative rounded-full transition-colors shrink-0"
        style={{
          width: size === 'sm' ? 30 : 34,
          height: size === 'sm' ? 16 : 18,
          background: logEnabled ? '#089981' : '#71717a',
        }}
      >
        <span
          className="absolute top-0.5 rounded-full bg-white shadow transition-all"
          style={{
            width: size === 'sm' ? 12 : 14,
            height: size === 'sm' ? 12 : 14,
            left: logEnabled ? (size === 'sm' ? 16 : 18) : 2,
          }}
        />
      </button>
      {tradeLogger && logEnabled && (
        <span className="text-[9px] tabular-nums" style={{ color: sub }}>
          {tradeLogger.lastError
            ? (
              <span className="inline-flex items-center gap-0.5" style={{ color: '#F23645' }} title={tradeLogger.lastError}>
                <AlertTriangle className="h-3 w-3" />erreur
              </span>
            )
            : `${tradeLogger.loggedCount} loggé${tradeLogger.loggedCount > 1 ? 's' : ''}`}
        </span>
      )}
    </div>
  )

  if (compact) {
    return (
      <div className="flex items-center gap-4 flex-wrap px-3 py-2" style={{ background: bg, color: text }}>
        <Stat text={text} sub={sub} label="Balance" value={`$${stats.balance.toFixed(2)}`} />
        <Stat text={text} sub={sub} label="Net P&L" value={`${stats.netProfit >= 0 ? '+' : ''}$${stats.netProfit.toFixed(2)}`} color={pnlColor} />
        <Stat text={text} sub={sub} label="Win rate" value={`${stats.winRate.toFixed(0)}%`} />
        <Stat text={text} sub={sub} label="Trades" value={`${stats.totalTrades}`} />
        <button
          type="button"
          onClick={onResetTrades}
          className="inline-flex items-center gap-1 rounded px-2 py-1 text-[10px] font-bold border hover:bg-black/5"
          style={{ borderColor: border, color: sub }}
          title="Reset trades — remise à zéro de l'historique du backtest"
        >
          <RotateCcw className="h-3 w-3" /> RESET TRADES
        </button>
        {tradeLogger && renderLogToggle('sm')}
        <span className="text-[10px]" style={{ color: sub }}>
          Place simulated CALL/PUT orders from the order panel while replay runs
        </span>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-full overflow-hidden" style={{ background: bg, color: text }}>
      {/* Backtest controls — start balance + reset trades + log trades */}
      <div className="px-4 py-2 border-b flex items-center gap-2 flex-wrap" style={{ borderColor: border }}>
        <Wallet className="h-3.5 w-3.5" style={{ color: sub }} />
        <span className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: sub }}>Start balance</span>
        <input
          aria-label="Backtest start balance"
          type="number"
          min={1}
          step={1}
          value={balanceDraft}
          onChange={(e) => setBalanceDraft(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') applyBalance() }}
          className="w-24 rounded border px-1.5 py-1 text-[11px] text-right bg-transparent outline-none tabular-nums"
          style={{ borderColor: border, color: text }}
        />
        <button
          type="button"
          onClick={applyBalance}
          className="inline-flex items-center gap-1 rounded px-2 py-1 text-[10px] font-bold border hover:bg-black/5"
          style={{ borderColor: '#089981', color: '#089981' }}
          title="Applique le solde de départ (réinitialise les trades du backtest)"
        >
          APPLY
        </button>
        <span className="text-[9px]" style={{ color: sub }}>setting a balance resets the trades</span>
        <button
          type="button"
          onClick={onResetTrades}
          className="ml-auto inline-flex items-center gap-1.5 rounded px-2.5 py-1.5 text-[10px] font-bold border hover:bg-black/5"
          style={{ borderColor: '#F23645', color: '#F23645' }}
          title="Reset trades — remise à zéro de l'historique des trades simulés (orders, equity, drawdown)"
        >
          <RotateCcw className="h-3 w-3" />
          RESET TRADES
        </button>
        {tradeLogger && (
          <div className="inline-flex items-center gap-2">
            {renderLogToggle('md')}
            <span className="text-[9px]" style={{ color: sub }}>.logs/trade.jsonl</span>
          </div>
        )}
      </div>

      {/* Strategy Tester history fetch — 1 to 10 days, empty by default */}
      {onFetchHistory && (
        <div className="px-4 py-2 border-b flex items-center gap-2 flex-wrap" style={{ borderColor: border }}>
          <Download className="h-3.5 w-3.5" style={{ color: sub }} />
          <span className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: sub }}>History</span>
          <input
            aria-label="Number of candle days"
            type="number"
            min={1}
            max={10}
            step={1}
            value={historyDays}
            onChange={(e) => {
              const value = e.target.value
              if (value === '') { setHistoryDays(''); return }
              const digits = value.replace(/\D/g, '')
              if (digits === '') { setHistoryDays(''); return }
              const n = Number(digits)
              if (Number.isFinite(n) && n >= 1 && n <= 10) setHistoryDays(String(n))
            }}
            className="w-16 rounded border px-1.5 py-1 text-[11px] text-center bg-transparent outline-none"
            style={{ borderColor: border, color: text }}
          />
          <span className="text-[10px]" style={{ color: sub }}>{historyDays === '' ? 'enter 1 to 10 days' : `day(s) · ${requestedCandles.toLocaleString()} candles requested`}</span>
          <button
            type="button"
            onClick={fetchHistory}
            disabled={fetching}
            className="inline-flex items-center gap-1.5 rounded px-2.5 py-1.5 text-[10px] font-bold border disabled:opacity-50"
            style={{ borderColor: '#2962FF', color: '#2962FF' }}
          >
            <Download className="h-3 w-3" />
            {fetching ? 'FETCHING…' : 'FETCH HISTORY'}
          </button>
          <span className="text-[9px] ml-auto" style={{ color: sub }}>TF {candleSize}s · up to 10 days</span>
        </div>
      )}

      {/* v26 — §18 : STRATÉGIE SÉLECTIONNABLE (L_Lucien ProTrader |
          Ninja ProTrader) — les DEUX fonctionnelles avec le MÊME Rule
          Engine que l'Auto Trade (§19) et leurs règles propres (§31). */}
      {lucienBacktester && (
        <div className="px-4 py-2 border-b" style={{ borderColor: border }}>
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <Bot className="h-3.5 w-3.5" style={{ color: bt.enabled ? '#2962FF' : sub }} />
                <select
                  aria-label="Stratégie testée"
                  value={bt.strategyId}
                  onChange={(e) => lucienBacktester.setStrategy(e.target.value as 'l_lucien_protrader' | 'ninja_protrader')}
                  className="rounded border px-1.5 py-0.5 text-[11px] font-semibold bg-transparent outline-none"
                  style={{ borderColor: border, color: text }}
                  title="Stratégie testée — L_Lucien : signal confirmé à la clôture ; Ninja : signal sur la bougie en formation (Candles Validation ancrée sur la bougie clôturée précédente)"
                >
                  {BACKTEST_STRATEGIES.map((s) => (
                    <option key={s.id} value={s.id} style={{ color: text }}>{s.name} — {s.description}</option>
                  ))}
                </select>
                <span className="text-[9px] uppercase tracking-wide" style={{ color: sub }}>stratégie auto</span>
                {bt.enabled && (
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded text-white" style={{ background: '#2962FF' }}>AUTO</span>
                )}
              </div>
              <div className="text-[9px] leading-snug mt-0.5" style={{ color: sub }}>
                {bt.strategyId === 'ninja_protrader'
                  ? 'Ninja : chaque bougie est évaluée avec la sémantique « en formation » — la Candles Validation s’ancre sur la bougie clôturée PRÉCÉDENTE (jamais la bougie signalée).'
                  : 'L_Lucien : signal confirmé à la CLÔTURE de chaque bougie du replay — la Candles Validation s’ancre sur la bougie signalée.'}
                {' '}Règles + expiration (secondes / bougies / remaining Time) du panneau Auto Trade.
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={bt.enabled}
              aria-label="Activer la stratégie L_Lucien ProTrader dans le Strategy Tester"
              onClick={() => lucienBacktester.setEnabled(!bt.enabled)}
              className="relative shrink-0 rounded-full transition-colors"
              style={{ width: 34, height: 18, background: bt.enabled ? '#2962FF' : '#71717a' }}
              title={bt.enabled ? 'Stratégie auto ACTIVE — cliquer pour désactiver' : 'Stratégie auto inactive — cliquer pour activer'}
            >
              <span
                className="absolute top-0.5 rounded-full bg-white shadow transition-all"
                style={{ width: 14, height: 14, left: bt.enabled ? 18 : 2 }}
              />
            </button>
          </div>
          {bt.enabled && (
            <div className="flex items-center gap-3 mt-1.5 flex-wrap">
              <label className="flex items-center gap-1 text-[10px]" style={{ color: sub }}>
                Mise $
                <input
                  aria-label="Mise de la stratégie auto"
                  type="number" min={0.01} step={0.01}
                  value={btStakeDraft === '' ? String(bt.stake) : btStakeDraft}
                  onChange={(e) => setBtStakeDraft(e.target.value)}
                  onBlur={() => {
                    const v = Number(btStakeDraft)
                    if (Number.isFinite(v) && v >= 0.01) lucienBacktester.configure({ stake: v })
                    setBtStakeDraft('')
                  }}
                  onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur() }}
                  className="w-16 rounded border px-1.5 py-1 text-[11px] text-right bg-transparent outline-none tabular-nums"
                  style={{ borderColor: border, color: text }}
                />
              </label>
              <label className="flex items-center gap-1 text-[10px]" style={{ color: sub }}>
                Payout %
                <input
                  aria-label="Payout de la stratégie auto"
                  type="number" min={1} max={100} step={1}
                  value={btPayoutDraft === '' ? String(bt.payout) : btPayoutDraft}
                  onChange={(e) => setBtPayoutDraft(e.target.value)}
                  onBlur={() => {
                    const v = Number(btPayoutDraft)
                    if (Number.isFinite(v) && v > 0 && v <= 100) lucienBacktester.configure({ payout: v })
                    setBtPayoutDraft('')
                  }}
                  onKeyDown={(e) => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur() }}
                  className="w-16 rounded border px-1.5 py-1 text-[11px] text-right bg-transparent outline-none tabular-nums"
                  style={{ borderColor: border, color: text }}
                />
              </label>
              <span className="text-[9px]" style={{ color: sub }}>
                {btSummary.callRules} combinaison(s) CALL ▲ · {btSummary.putRules} PUT ▼ · {btSummary.validatedRules} avec Candles Validation · {bt.placedCount} ordre(s) placé(s)
              </span>
            </div>
          )}
          {bt.lastSignal && (
            <div className="text-[9px] mt-1 truncate" style={{ color: sub }} title={bt.lastSignal}>
              Dernier signal : {bt.lastSignal}
            </div>
          )}
        </div>
      )}

      {/* v26 — §20 : LES 8 STATISTIQUES EN GRANDES CARTES LISIBLES
          (Start balance · Balance · Available · Net P&L · Win rate ·
          Profit factor · Max DD · Trades) — jamais quasi invisibles. */}
      <div className="px-4 py-3 border-b" style={{ borderColor: border }}>
        <div className="grid grid-cols-4 gap-2">
          <StatCard text={text} sub={sub} label="START BALANCE" value={`$${stats.startBalance.toFixed(2)}`} />
          <StatCard text={text} sub={sub} label="BALANCE" value={`$${stats.balance.toFixed(2)}`} />
          <StatCard text={text} sub={sub} label="AVAILABLE" value={`$${stats.availableBalance.toFixed(2)}`} color={stats.availableBalance < 1 ? '#F23645' : text} />
          <StatCard text={text} sub={sub} label="NET P&L" value={`${stats.netProfit >= 0 ? '+' : ''}$${stats.netProfit.toFixed(2)}`} color={pnlColor} />
          <StatCard text={text} sub={sub} label="WIN RATE" value={`${stats.winRate.toFixed(1)}%`} color={stats.winRate >= 50 ? '#089981' : text} />
          <StatCard text={text} sub={sub} label="PROFIT FACTOR" value={Number.isFinite(stats.profitFactor) ? stats.profitFactor.toFixed(2) : '∞'} />
          <StatCard text={text} sub={sub} label="MAX DD" value={`$${stats.maxDrawdown.toFixed(2)}`} color={stats.maxDrawdown > 0 ? '#F23645' : sub} />
          <StatCard text={text} sub={sub} label="TRADES" value={`${stats.totalTrades} (${stats.wins}W / ${stats.losses}L${stats.refunds ? ` / ${stats.refunds}R` : ''})`} />
        </div>
        <div className="mt-2 flex items-end gap-2">
          <div className="flex-1 min-w-[200px]">
            <EquitySpark points={stats.equityCurve} dark={dark} />
          </div>
        </div>
      </div>

      {/* open trades */}
      {orders.some((o) => o.status === 'open') && (
        <div className="px-4 py-2 border-b" style={{ borderColor: border }}>
          <div className="text-[10px] uppercase tracking-wide mb-1.5" style={{ color: sub }}>Open simulated trades</div>
          <div className="flex gap-2 flex-wrap">
            {orders.filter((o) => o.status === 'open').map((o) => (
              <span
                key={o.id}
                className="inline-flex items-center gap-1.5 px-2 py-1 rounded text-[11px] border"
                style={{ borderColor: o.side === 'call' ? '#089981' : '#F23645' }}
                title={o.label ?? undefined}
              >
                <span style={{ color: o.side === 'call' ? '#089981' : '#F23645', fontWeight: 600 }}>
                  {o.side === 'call' ? 'CALL' : 'PUT'}
                </span>
                <span className="tabular-nums">${o.amount.toFixed(2)}</span>
                <span className="tabular-nums opacity-70">@ {o.entryPrice.toFixed(5)}</span>
                <span className="opacity-60">exp {o.expiryCandles} bars</span>
                {/* v22 — libellé de l'ordre (combinaison + validation). */}
                {o.label && <span className="opacity-70 max-w-[220px] truncate">{o.label}</span>}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* trades table */}
      <div className="flex-1 overflow-y-auto min-h-0">
        <table className="w-full text-[11px]">
          <thead className="sticky top-0" style={{ background: bg }}>
            <tr className="text-left" style={{ color: sub }}>
              <th className="px-4 py-2 font-medium">Side</th>
              <th className="px-2 py-2 font-medium">Label</th>
              <th className="px-2 py-2 font-medium">Amount</th>
              <th className="px-2 py-2 font-medium">Entry</th>
              <th className="px-2 py-2 font-medium">Exit</th>
              <th className="px-2 py-2 font-medium">Payout</th>
              <th className="px-2 py-2 font-medium">Expiration</th>
              <th className="px-2 py-2 font-medium">Result</th>
              <th className="px-2 py-2 font-medium">P&L</th>
              <th className="px-4 py-2 font-medium">Time</th>
            </tr>
          </thead>
          <tbody>
            {orders.length === 0 && (
              <tr>
                <td colSpan={10} className="px-4 py-8 text-center" style={{ color: sub }}>
                  No simulated trades yet — play the replay and place CALL/PUT orders to build a backtest.
                </td>
              </tr>
            )}
            {orders.map((o) => {
              const res = o.status
              const resColor = res === 'won' ? '#089981' : res === 'lost' ? '#F23645' : sub
              return (
                <tr key={o.id} className="border-t tabular-nums" style={{ borderColor: border }}>
                  <td className="px-4 py-1.5 font-semibold" style={{ color: o.side === 'call' ? '#089981' : '#F23645' }}>
                    {o.side === 'call' ? <TrendingUp className="inline h-3 w-3 mr-1" /> : <TrendingDown className="inline h-3 w-3 mr-1" />}
                    {o.side.toUpperCase()}
                  </td>
                  {/* v22 — LIBELLÉ D'ORDRE : combinaison + règle de validation
                      (texte complet au survol). */}
                  <td className="px-2 py-1.5 max-w-[260px]" title={o.label ?? undefined}>
                    <span className="block truncate text-[10px]" style={{ color: o.label ? sub : '#787B8680' }}>
                      {o.label ?? '—'}
                    </span>
                  </td>
                  <td className="px-2 py-1.5">${o.amount.toFixed(2)}</td>
                  <td className="px-2 py-1.5">{o.entryPrice.toFixed(5)}</td>
                  <td className="px-2 py-1.5">{o.exitPrice != null ? o.exitPrice.toFixed(5) : '—'}</td>
                  <td className="px-2 py-1.5">{o.payout.toFixed(0)}%</td>
                  <td className="px-2 py-1.5" style={{ color: sub }} title="Expiration en bougies — expiryIndex = entryIndex + expiryCandles">{o.expiryCandles} bougie(s)</td>
                  <td className="px-2 py-1.5 font-semibold" style={{ color: resColor }}>
                    {res === 'open' ? 'Open' : res === 'won' ? 'Won' : res === 'lost' ? 'Lost' : <><Minus className="inline h-3 w-3 mr-1" />Refund</>}
                  </td>
                  <td className="px-2 py-1.5 font-semibold" style={{ color: (o.profit ?? 0) > 0 ? '#089981' : (o.profit ?? 0) < 0 ? '#F23645' : sub }}>
                    {o.status === 'open' ? '—' : `${(o.profit ?? 0) >= 0 ? '+' : ''}$${(o.profit ?? 0).toFixed(2)}`}
                  </td>
                  <td className="px-4 py-1.5" style={{ color: sub }}>
                    {o.exitTime ? new Date(o.exitTime * 1000).toLocaleTimeString() : new Date(o.entryTime * 1000).toLocaleTimeString()}
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
