'use client'

/**
 * bos-choch-cisd-overlay.tsx — Couche visuelle UNIFIÉE des signaux sur le
 * graphique (v26) : ICT (BOS/CHoCH/CISD) + les 73 CANDLESTICK PATTERNS.
 * ====================================================================
 * Rend ce que dessinent les packs Pine sources, calculé par les MÊMES
 * moteurs partagés que les stratégies :
 *
 *   - lignes de TENDANCE pleines (swing→swing) du pack BOS/CHoCH/CISD ;
 *   - lignes d'ÉVÉNEMENT pointillées (du swing cassé vers la bougie) ;
 *   - LABELS/BADGES via le SignalLabelManager (§25-§29) : déduplication,
 *     badges compacts multi-patterns (« ENGULFING · HAMMER »), voies
 *     d'empilement sans collision, priorité BOS/CHoCH/CISD > candles,
 *     préfixe « LIVE · » sur la bougie en formation, tailles
 *     Small/Normal/Large (défaut)/Huge.
 *
 * SWITCH MASTER « Tags & labels » (§22) : DÉFAUT DÉSACTIVÉ — aucun tag
 * visuel tant que le switch du panneau Auto Trade n'est pas activé.
 * Les FILTRES DE VISIBILITÉ (§23 : groupes + 73 patterns individuels +
 * masters bullish/bearish/neutral) s'appliquent UNIQUEMENT au rendu :
 * la détection et le Rule Engine ne sont JAMAIS filtrés (§33).
 *
 * PERFORMANCE (§26/§42) : cache des visuels par stamp (longueur +
 * dernière bougie + réglages), badges réutilisés du manager (clés
 * stables — le LIVE est MIS À JOUR, pas recréé), rafraîchissement du
 * canvas par requestAnimationFrame sans recompute des événements.
 */

import { useEffect, useRef } from 'react'
import type { IChartApi, ISeriesApi, Time } from 'lightweight-charts'

import type { CandleLike } from '@/lib/indicators'
import { computeBosChochCisdVisuals, type BosChochCisdSettings } from '../../../../shared/bos-choch-cisd'
import { computeCandlePatternEvents } from '../../../../shared/candle-patterns'
import { isSignalVisible, SIGNAL_REGISTRY_BY_ID, type SignalDisplayFilters } from '../../../../shared/signal-registry'
import { SignalLabelManager } from '../../../../shared/signal-label-manager'
import {
  loadBosChochCisdSettings,
  subscribeBosChochCisdSettings,
} from '@/lib/bos-choch-cisd-settings'
import {
  loadSignalDisplayFilters,
  subscribeSignalDisplayFilters,
} from '@/lib/signal-display-settings'

const FONT_STACK = `-apple-system, BlinkMacSystemFont, 'Trebuchet MS', Roboto, Ubuntu, sans-serif`

/** Tailles de police des badges par taille de label (§29 — défaut Large). */
function fontSizeFor(size: string | undefined): number {
  switch ((size ?? 'Large').toLowerCase()) {
    case 'small': return 9
    case 'normal': return 11
    case 'huge': return 18
    case 'large':
    default: return 14
  }
}

interface BosChochCisdOverlayProps {
  /** Afficher la couche (stratégie sélectionnée / testée). */
  visible: boolean
  getChart: () => IChartApi | null
  getSeries: () => ISeriesApi<any> | null
  getCandles: () => CandleLike[]
}

/** Résumé diagnostic (lecture seule — tests E2E). */
interface BosChochCisdDebugSummary {
  candles: number
  labels: number
  eventLines: number
  trendLines: number
  families: Record<string, number>
  /** couleurs effectives par type d'événement (réglages du pack). */
  colours: Record<string, string>
  settings: BosChochCisdSettings
  /** état du switch « Tags & labels » (défaut : masqué). */
  showLabels: boolean
  /** v26 — détections candle (TOUJOURS calculées, même masquées §33). */
  candleDetections: number
  /** v26 — badges visibles (après filtres d'affichage). */
  visibleBadges: number
}

export function BosChochCisdOverlay({
  visible, getChart, getSeries, getCandles,
}: BosChochCisdOverlayProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const visibleRef = useRef(visible)
  const settingsRef = useRef<BosChochCisdSettings>(loadBosChochCisdSettings())
  /* Filtres d'affichage v26 (master + groupes + 73 patterns + taille). */
  const displayRef = useRef<SignalDisplayFilters>(loadSignalDisplayFilters())
  /* SignalLabelManager PERSISTANT — badges réutilisés entre frames (§26). */
  const labelManagerRef = useRef<SignalLabelManager>(new SignalLabelManager())

  useEffect(() => { visibleRef.current = visible }, [visible])

  /* réglages du pack partagés (panneau Auto Trade ↔ overlay) */
  useEffect(() => subscribeBosChochCisdSettings((s) => { settingsRef.current = s }), [])

  /* filtres d'affichage des signaux (persistés, master par défaut OFF) */
  useEffect(() => subscribeSignalDisplayFilters((d) => { displayRef.current = d }), [])

  /* mintick dérivé des bougies (même heuristique que le moteur Pine) */
  const deriveMintick = (candles: CandleLike[]): number => {
    const sample = candles.slice(-400)
    if (sample.length < 3) return 0
    const deltas: number[] = []
    for (let i = 1; i < sample.length; i++) {
      const d = Math.abs(Number(sample[i].close) - Number(sample[i - 1].close))
      if (d > 1e-12 && Number.isFinite(d)) deltas.push(d)
    }
    if (deltas.length >= 8) {
      deltas.sort((a, b) => a - b)
      const probe = deltas.slice(0, Math.min(5, deltas.length))
      const tick = probe[Math.floor(probe.length / 2)]
      const lastPrice = Math.abs(sample[sample.length - 1].close) || 1
      if (tick > 0 && Number.isFinite(tick) && tick <= lastPrice * 0.005) return tick
    }
    let decimals = 0
    for (const c of sample.slice(-80)) {
      const s = String(c.close)
      const dot = s.indexOf('.')
      if (dot >= 0) decimals = Math.max(decimals, s.length - dot - 1)
    }
    return Number(`1e-${decimals}`)
  }

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    let raf = 0
    let lastW = 0
    let lastH = 0
    let cachedVisuals: ReturnType<typeof computeBosChochCisdVisuals> | null = null
    let cachedCandleEvents: ReturnType<typeof computeCandlePatternEvents> = []
    let settingsStamp = ''

    /* hook diagnostic lecture seule (tests E2E) */
    const debugRef: { summary: BosChochCisdDebugSummary | null } = { summary: null }
    ;(window as any).__bosChochCisdDebug = {
      getSummary: () => debugRef.summary,
    }

    const render = () => {
      raf = requestAnimationFrame(render)
      if (!visibleRef.current) {
        if (canvas.width !== 0 || canvas.height !== 0) { ctx.clearRect(0, 0, canvas.width, canvas.height); canvas.width = 0; canvas.height = 0; lastW = 0; lastH = 0 }
        return
      }
      const chart = getChart()
      const series = getSeries()
      if (!chart || !series) return

      const parent = canvas.parentElement
      const w = parent ? parent.clientWidth : 0
      const h = parent ? parent.clientHeight : 0
      if (w === 0 || h === 0) return
      if (w !== lastW || h !== lastH) {
        lastW = w
        lastH = h
        const dpr = window.devicePixelRatio || 1
        canvas.width = Math.max(1, Math.floor(w * dpr))
        canvas.height = Math.max(1, Math.floor(h * dpr))
        canvas.style.width = `${w}px`
        canvas.style.height = `${h}px`
      }
      const dpr = window.devicePixelRatio || 1
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.clearRect(0, 0, w, h)

      const candles = getCandles()
      if (!candles.length) return
      const settings = settingsRef.current
      const display = displayRef.current
      const mintick = deriveMintick(candles)
      const stamp = `${candles.length}:${candles[candles.length - 1].time}:${JSON.stringify(settings)}:${JSON.stringify(display)}`
      if (stamp !== settingsStamp || !cachedVisuals) {
        /* les bougies vivent en SECONDES dans l'app — le moteur est
         * agnostique (pass-through), seul le rendu convertit. */
        cachedVisuals = computeBosChochCisdVisuals(candles, settings, { mintick })
        /* v26 — DÉTECTION CANDLE sur TOUTE la série : TOUJOURS calculée
         * (§33 : les filtres d'affichage ne touchent PAS la détection). */
        cachedCandleEvents = computeCandlePatternEvents(candles, { mintick })
        settingsStamp = stamp
      }

      const ts = chart.timeScale()

      /* largeur de la zone de tracé (sans l'échelle de prix de droite) */
      let priceScaleWidth = 0
      try { priceScaleWidth = chart.priceScale('right').width() } catch { priceScaleWidth = 0 }
      const plotWidth = Math.max(10, w - priceScaleWidth)

      /* ── conversion x : temps (s) → pixels, avec repli logique ── */
      const timeOfBar = (barIndex: number): number => Number(candles[Math.max(0, Math.min(candles.length - 1, barIndex))].time)
      const timeToX = (t: number): number | null => {
        try {
          const x = ts.timeToCoordinate(t as Time)
          if (x != null) return x as number
        } catch { /* hors fenêtre visible */ }
        const range = ts.getVisibleLogicalRange()
        if (!range) return null
        const barSpacing = plotWidth / Math.max(1e-6, range.to - range.from)
        const times = candles.map((c) => Number(c.time))
        let lo = 0, hi = times.length - 1
        if (t <= times[0]) {
          const interval = times.length > 1 ? times[1] - times[0] : 60
          return ((t - times[0]) / interval - range.from) * barSpacing
        }
        if (t >= times[hi]) {
          const interval = times.length > 1 ? times[hi] - times[hi - 1] : 60
          return (hi + (t - times[hi]) / interval - range.from) * barSpacing
        }
        while (lo < hi) { const mid = (lo + hi) >> 1; if (times[mid] <= t) lo = mid + 1; else hi = mid }
        const frac = lo - 1 + (t - times[lo - 1]) / Math.max(1, times[lo] - times[lo - 1])
        return (frac - range.from) * barSpacing
      }
      const priceToY = (p: number): number | null => {
        try {
          const y = series.priceToCoordinate(p)
          return y == null ? null : (y as number)
        } catch { return null }
      }

      /* ── 1. lignes de tendance (pleines, vertes/rouges, largeur 2) ── */
      for (const tl of cachedVisuals.trendLines) {
        const x1 = timeToX(timeOfBar(tl.fromBarIndex))
        const x2 = timeToX(timeOfBar(tl.toBarIndex))
        const y1 = priceToY(tl.fromPrice)
        const y2 = priceToY(tl.toPrice)
        if (x1 == null || x2 == null || y1 == null || y2 == null) continue
        if (Math.max(x1, x2) < -20 || Math.min(x1, x2) > w + 20) continue
        ctx.save()
        ctx.strokeStyle = tl.kind === 'uptrend' ? '#4CAF50' : '#F23645'
        ctx.lineWidth = 2
        ctx.setLineDash([])
        ctx.lineCap = 'round'
        ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke()
        ctx.restore()
      }

      /* ── 2. lignes d'événement (pointillées, vertes/rouges, largeur 2) ── */
      for (const { event: e, colour } of cachedVisuals.eventLines) {
        const x1 = timeToX(timeOfBar(e.lineFromBarIndex))
        const x2 = timeToX(timeOfBar(e.barIndex))
        const y1 = priceToY(e.linePrice)
        if (x1 == null || x2 == null || y1 == null) continue
        const y2 = y1
        if (Math.max(x1, x2) < -20 || Math.min(x1, x2) > w + 20) continue
        ctx.save()
        ctx.strokeStyle = colour
        ctx.lineWidth = 2
        ctx.setLineDash([6, 4])
        ctx.lineCap = 'round'
        ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke()
        ctx.restore()
      }

      /* ── 3. BADGES DE SIGNAUX via le SignalLabelManager (§25-§29) ──
       * Master OFF → AUCUN tag visuel. Les filtres (groupes + 73
       * patterns + masters candle) s'appliquent à la SORTIE uniquement. */
      const liveBarIndex = candles.length > 0 ? candles.length - 1 : null
      const isSignalVisibleFn = (id: string, category: string, direction: string) =>
        isSignalVisible(display, { id, category: category as never, direction: direction as never })
      const bosInputs: Array<{ id: string; label: string; category: 'STRUCTURE'; direction: 'bullish' | 'bearish'; barIndex: number; time: number; side: 'below' | 'above'; referenceLevel: number }> = cachedVisuals.labels.map((e) => ({
        id: e.label,
        label: e.label.toUpperCase().replace('CHOCH', 'CHoCH'),
        category: 'STRUCTURE' as const,
        direction: (e.dir === 'up' ? 'bullish' : 'bearish') as 'bullish' | 'bearish',
        barIndex: e.barIndex,
        time: e.time,
        side: (e.dir === 'up' ? 'below' : 'above') as 'below' | 'above',
        referenceLevel: e.linePrice,
      }))
      const candleInputs: Array<{ id: string; label: string; category: 'CANDLE'; direction: 'bullish' | 'bearish' | 'neutral'; barIndex: number; time: number; side: 'below' | 'above' }> = cachedCandleEvents.map((e) => ({
        id: e.patternId,
        label: e.label
          .replace(/^Bullish /, '').replace(/^Bearish /, '')
          .replace('White Lines', '').replace(/ {2,}/g, ' ').trim().toUpperCase(),
        category: 'CANDLE' as const,
        direction: e.direction as 'bullish' | 'bearish' | 'neutral',
        barIndex: e.barIndex,
        time: e.candleTime,
        side: (e.position === 'below' ? 'below' : 'above') as 'below' | 'above',
      }))
      const badges = labelManagerRef.current.layout([...bosInputs, ...candleInputs], {
        liveBarIndex,
        isSignalVisible: isSignalVisibleFn,
      })

      /* résumé diagnostic (détections TOUJOURS complètes, badges filtrés). */
      const families: Record<string, number> = {}
      const colours: Record<string, string> = {}
      for (const l of cachedVisuals.labels) {
        families[l.kind] = (families[l.kind] ?? 0) + 1
        colours[`${l.kind}:${l.dir}`] = l.familyColour
      }
      debugRef.summary = {
        candles: candles.length,
        labels: badges.length,
        eventLines: cachedVisuals.eventLines.length,
        trendLines: cachedVisuals.trendLines.length,
        families,
        colours,
        settings: { ...settings },
        showLabels: display.showLabels,
        candleDetections: cachedCandleEvents.length,
        visibleBadges: badges.length,
      }

      if (display.showLabels) {
        const fontSize = fontSizeFor(display.labelSize)
        ctx.save()
        ctx.font = `bold ${fontSize}px ${FONT_STACK}`
        ctx.textAlign = 'center'
        ctx.textBaseline = 'middle'
        /* suivi d'occupation horizontale par voie (anti-collision §27). */
        const laneExtents = new Map<number, number[]>()
        for (const badge of badges) {
          const bar = candles[Math.max(0, Math.min(candles.length - 1, badge.barIndex))]
          const x = timeToX(Number(bar.time))
          if (x == null) continue
          /* position Y : voie (lane) au-dessus/en-dessous de la bougie. */
          const baseY = badge.side === 'below' ? bar.low : bar.high
          const yBase = priceToY(baseY)
          if (yBase == null) continue
          const offset = 14 + badge.lane * (fontSize + 8)
          const y = badge.side === 'below' ? yBase + offset : yBase - offset
          if (x < -200 || x > w + 200 || y < -60 || y > h + 60) continue
          const text = badge.live ? `LIVE · ${badge.text}` : badge.text
          const padX = 7, padY = 4
          const wText = ctx.measureText(text).width
          const bw = wText + padX * 2
          const bh = fontSize + padY * 2
          const bx = x - bw / 2
          const by = y - bh / 2
          /* anti-collision horizontale par voie : décale d'une voie si
           * le badge chevauche le précédent de la MÊME voie. */
          let lane = badge.lane
          for (let guard = 0; guard < 6; guard++) {
            const extents = laneExtents.get(lane) ?? []
            const overlaps = extents.some((ex) => Math.abs(ex - x) < (bw + 90) / 2)
            if (!overlaps) break
            lane++
          }
          if (lane !== badge.lane) {
            const offset2 = 14 + lane * (fontSize + 8)
            const y2 = badge.side === 'below' ? yBase + offset2 : yBase - offset2
            if (!(y2 < -60 || y2 > h + 60)) {
              // eslint-disable-next-line @typescript-eslint/no-unused-expressions
              (badge as { _laneY?: number })._laneY = y2
            }
          }
          const drawY = (badge as { _laneY?: number })._laneY ?? y
          const ext = laneExtents.get(lane) ?? []
          ext.push(x)
          laneExtents.set(lane, ext)

          /* badge arrondi (palette professionnelle §30). */
          ctx.fillStyle = badge.color
          const r = Math.min(6, bh / 2)
          const bx2 = bx
          const by2 = drawY - bh / 2
          ctx.beginPath()
          ctx.moveTo(bx2 + r, by2)
          ctx.lineTo(bx2 + bw - r, by2); ctx.quadraticCurveTo(bx2 + bw, by2, bx2 + bw, by2 + r)
          ctx.lineTo(bx2 + bw, by2 + bh - r); ctx.quadraticCurveTo(bx2 + bw, by2 + bh, bx2 + bw - r, by2 + bh)
          ctx.lineTo(bx2 + r, by2 + bh); ctx.quadraticCurveTo(bx2, by2 + bh, bx2, by2 + bh - r)
          ctx.lineTo(bx2, by2 + r); ctx.quadraticCurveTo(bx2, by2, bx2 + r, by2)
          ctx.closePath(); ctx.fill()
          /* halo LIVE discret. */
          if (badge.live) {
            ctx.strokeStyle = 'rgba(41, 98, 255, 0.55)'
            ctx.lineWidth = 1.5
            ctx.stroke()
          }
          ctx.fillStyle = '#FFFFFF'
          ctx.fillText(text, bx2 + bw / 2, drawY + 0.5)
        }
        ctx.restore()
      }
    }
    raf = requestAnimationFrame(render)
    return () => cancelAnimationFrame(raf)
  }, [getChart, getSeries, getCandles])

  if (!visible) return null
  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 z-[3] pointer-events-none"
      aria-label="Signal visuals (BOS, CHoCH, CISD + 73 candlestick patterns)"
    />
  )
}
