'use client'

/**
 * chart-theme.ts — TradingView exact palette for lightweight-charts v4.
 */

import { ColorType, CrosshairMode, LineStyle } from 'lightweight-charts'

export const TV_COLORS = {
  dark: {
    background: '#131722',
    text: '#B2B5BE',
    grid: '#1E222D',
    border: '#2A2E39',
    crosshair: '#758696',
    up: '#089981',
    down: '#F23645',
    upWick: '#089981',
    downWick: '#F23645',
    lineSeries: '#2962FF',
    areaTop: 'rgba(41, 98, 255, 0.28)',
    areaBottom: 'rgba(41, 98, 255, 0.05)',
    volumeUp: 'rgba(8, 153, 129, 0.45)',
    volumeDown: 'rgba(242, 54, 69, 0.45)',
  },
  light: {
    background: '#FFFFFF',
    text: '#131722',
    grid: '#F0F3FA',
    border: '#E0E3EB',
    crosshair: '#9598A1',
    up: '#089981',
    down: '#F23645',
    upWick: '#089981',
    downWick: '#F23645',
    lineSeries: '#2962FF',
    areaTop: 'rgba(41, 98, 255, 0.20)',
    areaBottom: 'rgba(41, 98, 255, 0.03)',
    volumeUp: 'rgba(8, 153, 129, 0.40)',
    volumeDown: 'rgba(242, 54, 69, 0.40)',
  },
} as const

export type ChartTheme = (typeof TV_COLORS)[keyof typeof TV_COLORS]

export function themeFor(dark: boolean): ChartTheme {
  return (dark ? TV_COLORS.dark : TV_COLORS.light) as ChartTheme
}

export function baseChartOptions(theme: ChartTheme) {
  return {
    layout: {
      background: { type: ColorType.Solid, color: theme.background },
      textColor: theme.text,
      fontFamily: "'Trebuchet MS', -apple-system, Roboto, sans-serif",
      fontSize: 11,
    },
    grid: {
      vertLines: { color: theme.grid },
      horzLines: { color: theme.grid },
    },
    crosshair: {
      mode: CrosshairMode.Normal,
      vertLine: { color: theme.crosshair, width: 1 as const, style: LineStyle.Dashed, labelBackgroundColor: theme.background },
      horzLine: { color: theme.crosshair, width: 1 as const, style: LineStyle.Dashed, labelBackgroundColor: theme.background },
    },
    rightPriceScale: {
      borderColor: theme.border,
      autoScale: true,
      scaleMargins: { top: 0.08, bottom: 0.08 },
    },
    timeScale: {
      borderColor: theme.border,
      timeVisible: true,
      secondsVisible: true,
    },
    handleScroll: true,
    handleScale: true,
  }
}
