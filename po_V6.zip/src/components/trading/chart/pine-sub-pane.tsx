'use client'

/**
 * pine-sub-pane.tsx — synchronized Pine oscillator pane (TradingView-style).
 *
 * One pane per enabled NON-overlay Pine script (`indicator(..., overlay=false)`).
 *
 * WHY THIS EXISTS (v1.8): non-overlay scripts previously had NO pane system.
 * Their plots were attached to an independent overlay price scale drawn ON TOP
 * of the price chart — with its own autoscale, so the line could never fit the
 * candles — and their hlines (RSI 30/70) were added to the MAIN candle series,
 * stretching the price scale from ~1.16 to 70 and exploding the whole chart
 * ("indicators never fit with the chart"). TradingView renders these scripts
 * in a separate pane below the chart; this component does exactly that:
 *
 *   - plots (line / histogram), plotcandle, plotshape markers, hlines, fills
 *     between plots, bgcolor bands, drawing objects and alert bells all render
 *     INSIDE this pane, in the script's own value space
 *   - the pane's price scale autoscales to the script's values only
 *   - time scale + crosshair stay in sync with the main chart (the anchor
 *     series mirrors every chart candle so logical indexes match 1:1)
 *
 * It implements the same SubPaneHandle interface as the built-in oscillators,
 * so the chart-workspace sync machinery (range push, crosshair, theme, data
 * pushes) drives it unchanged.
 */

import {
  forwardRef, useEffect, useImperativeHandle, useRef,
} from 'react'
import {
  createChart, LineStyle,
  type IChartApi, type ISeriesApi, type LogicalRange, type Time,
  type LineData, type HistogramData, type IPriceLine,
} from 'lightweight-charts'
import { X, Eye, EyeOff } from 'lucide-react'

import type { CandleLike } from '@/lib/indicators'
import type { PineDrawing, PineLineDrawing, PineLabelDrawing, PineBoxDrawing } from '@/lib/pine-engine'
import { usePineStore, type PineScriptInstance } from '@/lib/pine-store'
import { alignPineSeries, pineTimeToChartTime, type AlignDiagnostic } from '@/lib/pine-time-axis'
import type { SubPaneHandle } from './sub-pane'
import { baseChartOptions, themeFor } from './chart-theme'

const FONT_STACK = `-apple-system, BlinkMacSystemFont, 'Trebuchet MS', Roboto, Ubuntu, sans-serif`
const PANE_HEIGHT = 128

/** sec → ms for the pane's canvas extrapolation math (central conversion). */
const toPineTimeLocal = (c: CandleLike): number => Number(c.time) * 1000

function fontSizeForPane(size: string | undefined): number {
  switch ((size ?? 'small').toLowerCase()) {
    case 'tiny': return 8
    case 'normal': return 11
    case 'large': return 13
    case 'huge': return 16
    case 'small':
    default: return 9
  }
}

interface PineSubPaneProps {
  scriptId: string
  /** Chart candles (live or replay window) — hydrates the pane on mount
   *  and on every new execution result, since the workspace only pushes
   *  setData()/updateTail() when the data itself advances. */
  getCandles: () => CandleLike[]
  dark: boolean
  showTimeAxis: boolean
  onRemove: (id: string) => void
  onToggle: (id: string) => void
  registerHandle: (uid: string, handle: SubPaneHandle | null) => void
}

export const PineSubPane = forwardRef<SubPaneHandle, PineSubPaneProps>(function PineSubPane({
  scriptId, getCandles, dark, showTimeAxis, onRemove, onToggle, registerHandle,
}, _ref) {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const anchorRef = useRef<ISeriesApi<'Line'> | null>(null)
  const seriesByPlot = useRef<Map<string, ISeriesApi<any>>>(new Map())
  const panePriceLinesRef = useRef<IPriceLine[]>([])
  const valueSpansRef = useRef<Map<string, HTMLSpanElement | null>>(new Map())
  const applyingRangeRef = useRef(false)
  const lastCandlesRef = useRef<CandleLike[]>([])

  const script = usePineStore((s) => s.scripts.find((x) => x.id === scriptId)) as PineScriptInstance | undefined
  const scriptRef = useRef(script)
  useEffect(() => { scriptRef.current = script }, [script])
  const result = script?.result ?? null
  const resultRef = useRef(result)
  useEffect(() => { resultRef.current = result }, [result])

  // ── chart creation (once) ─────────────────────────────────────
  useEffect(() => {
    if (!containerRef.current) return
    const theme = themeFor(dark)
    const options: any = {
      ...baseChartOptions(theme),
      width: containerRef.current.clientWidth,
      height: containerRef.current.clientHeight,
      timeScale: {
        ...baseChartOptions(theme).timeScale,
        visible: showTimeAxis,
        rightOffset: 4,
        minBarSpacing: 4,
        barSpacing: 12,
        shiftVisibleRangeOnNewBar: false,
        fixLeftEdge: false,
      },
      rightPriceScale: {
        ...baseChartOptions(theme).rightPriceScale,
        scaleMargins: { top: 0.15, bottom: 0.1 },
      },
      crosshair: {
        ...baseChartOptions(theme).crosshair,
        mode: 0, // Normal
      },
    }
    const chart = createChart(containerRef.current, options)
    chartRef.current = chart

    // ANCHOR series: one data point per chart candle so the pane's logical
    // index space matches the main chart 1:1 (range sync correctness even
    // when the script's own plots start late or have holes). Excluded from
    // the price autoscale so it never stretches the pane.
    anchorRef.current = chart.addLineSeries({
      color: 'rgba(0,0,0,0)',
      lineWidth: 1,
      priceLineVisible: false,
      lastValueVisible: false,
      crosshairMarkerVisible: false,
      autoscaleInfoProvider: () => null,
    })

    const ro = new ResizeObserver(() => {
      if (containerRef.current && chartRef.current) {
        chartRef.current.applyOptions({
          width: containerRef.current.clientWidth,
          height: containerRef.current.clientHeight,
        })
      }
    })
    ro.observe(containerRef.current)

    return () => {
      ro.disconnect()
      chart.remove()
      chartRef.current = null
      anchorRef.current = null
      seriesByPlot.current.clear()
    }
  }, [])

  useEffect(() => {
    chartRef.current?.applyOptions({ timeScale: { visible: showTimeAxis } } as any)
  }, [showTimeAxis])

  useEffect(() => {
    chartRef.current?.applyOptions({
      layout: { ...baseChartOptions(themeFor(dark)).layout },
      grid: { ...baseChartOptions(themeFor(dark)).grid },
      rightPriceScale: { borderColor: themeFor(dark).border },
      timeScale: { borderColor: themeFor(dark).border },
    } as any)
  }, [dark])

  // ── data binding: Pine result arrays → pane series, by TIME ──
  const rebind = (candles: CandleLike[]) => {
    const chart = chartRef.current
    const res = resultRef.current
    if (!chart || !res) return
    lastCandlesRef.current = candles
    if (!candles.length) return

    const isProd = typeof process !== 'undefined' && process.env?.NODE_ENV === 'production'
    const reportIssues = (what: string, issues: AlignDiagnostic[]) => {
      if (isProd || !issues.length) return
      for (const issue of issues) {
        console.warn(`[PINE ALIGNMENT] ${issue.code} · pane ${script?.id ?? '?'} · ${what} — ${issue.detail}`)
      }
    }

    const pineTimes = res._times

    // anchor: every chart candle (value irrelevant — excluded from autoscale)
    try {
      anchorRef.current?.setData(candles.map((c) => ({ time: c.time as Time, value: 0 })))
    } catch { /* noop */ }

    // v1.9 — TIMESTAMP-ONLY alignment (spec §7): the positional tail fallback
    // that used to live here (`values[values.length - n + j]` on
    // `candles[offset + j]`) is REMOVED. A missing/incoherent Pine timeline
    // produces an explicit diagnostic and NO data — never a shifted layer.
    const timeAligned = (values: Array<number | null>, what = 'plot'): Array<{ time: Time; value: number }> => {
      const { points, issues } = alignPineSeries(values, pineTimes, candles)
      reportIssues(what, issues)
      const data: Array<{ time: Time; value: number }> = []
      for (const p of points) {
        if (p.value == null || !Number.isFinite(p.value)) continue
        data.push({ time: p.candle.time as Time, value: p.value })
      }
      return data
    }

    // (re)create plot series when the script's plot set changes identity
    const wanted = new Set<string>()
    for (let i = 0; i < res.plots.length; i++) wanted.add(`plot:${res.plots[i].id ?? i}`)
    for (let ci = 0; ci < (res.candles || []).length; ci++) wanted.add(`candle:${res.candles[ci].id ?? ci}`)
    for (const key of [...seriesByPlot.current.keys()]) {
      if (!wanted.has(key)) {
        try { chart.removeSeries(seriesByPlot.current.get(key)!) } catch { /* noop */ }
        seriesByPlot.current.delete(key)
      }
    }

    for (let i = 0; i < res.plots.length; i++) {
      const plot = res.plots[i]
      const key = `plot:${plot.id ?? i}`
      let series = seriesByPlot.current.get(key)
      const isHistogram = plot.style === 'histogram' || plot.style === 'columns'
      if (!series) {
        series = isHistogram
          ? chart.addHistogramSeries({
              color: plot.color || '#2962FF', base: 0,
              priceLineVisible: false, lastValueVisible: false,
            })
          : chart.addLineSeries({
              color: plot.color || '#2962FF',
              lineWidth: Math.max(1, Math.min(4, Math.round(plot.linewidth || 1))) as 1 | 2 | 3 | 4,
              priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false,
            })
        seriesByPlot.current.set(key, series)
      }
      try { series.setData(timeAligned(plot.data || []) as any) } catch { /* noop */ }
    }

    for (let ci = 0; ci < (res.candles || []).length; ci++) {
      const candleOut = res.candles[ci]
      const key = `candle:${candleOut.id ?? ci}`
      let series = seriesByPlot.current.get(key)
      if (!series) {
        series = chart.addCandlestickSeries({
          upColor: '#26a69a', downColor: '#ef5350', borderVisible: true,
          wickUpColor: '#26a69a', wickDownColor: '#ef5350',
          priceLineVisible: false, lastValueVisible: false,
        })
        seriesByPlot.current.set(key, series)
      }
      // Timestamp-keyed (spec §7) — no positional fallback.
      const { points, issues } = alignPineSeries(candleOut.data || [], pineTimes, candles)
      reportIssues(`plotcandle "${candleOut.title}"`, issues)
      const data: Array<any> = []
      for (const p of points) {
        const bar = p.value
        if (!bar) continue
        data.push({
          time: p.candle.time as Time,
          open: bar.open, high: bar.high, low: bar.low, close: bar.close,
        })
      }
      try { series.setData(data) } catch { /* noop */ }
    }

    // plotshape markers ride the anchor series (it covers every bar).
    // TIMESTAMP-ANCHORED (spec §9) — a marker stays on the candle that
    // triggered the signal, never on a positional tail.
    const markerSeries = anchorRef.current
    if (markerSeries) {
      const md: Array<any> = []
      for (const marker of res.markers || []) {
        const arr = marker.data || []
        const { points, issues } = alignPineSeries(arr, pineTimes, candles)
        reportIssues(`marker "${marker.title}"`, issues)
        for (const p of points) {
          const item = p.value
          if (!item) continue
          md.push({
            time: p.candle.time as Time,
            position: marker.location === 'belowbar' || marker.location === 'bottom' ? 'belowBar' : 'aboveBar',
            shape: markerShapeForPane(marker),
            color: item.color || '#2962FF',
            text: item.text || undefined,
          })
        }
      }
      try { markerSeries.setMarkers(md) } catch { /* noop */ }
    }

    // hlines: reference levels on the FIRST plot series (pane value space).
    // Tracked explicitly — LWC has no getter, and re-creating on every rebind
    // would stack duplicates.
    const hlineHost = seriesByPlot.current.get(`plot:${res.plots[0]?.id ?? 0}`) ?? markerSeries
    for (const pl of panePriceLinesRef.current) {
      try { (hlineHost as any)?.removePriceLine?.(pl) } catch { /* noop */ }
    }
    panePriceLinesRef.current = []
    for (const line of res.hlines || []) {
      try {
        const pl = (hlineHost as any)?.createPriceLine?.({
          price: line.price,
          color: '#787B86',
          lineStyle: LineStyle.Dashed,
          lineWidth: 1,
          axisLabelVisible: true,
          lineVisible: true,
          title: line.title,
        })
        if (pl) panePriceLinesRef.current.push(pl)
      } catch { /* noop */ }
    }

    updateLegend()
  }

  function markerShapeForPane(marker: { kind: string; glyph: string }): 'circle' | 'square' | 'arrowUp' | 'arrowDown' {
    const g = (marker.glyph || '').toLowerCase()
    if (marker.kind === 'arrow' || g.includes('up')) return 'arrowUp'
    if (g.includes('down')) return 'arrowDown'
    if (g.includes('square') || g.includes('diamond')) return 'square'
    return 'circle'
  }

  // ── legend values (last bar / crosshair bar) ───────────────────
  const updateLegend = (logical: number | null = null) => {
    const res = resultRef.current
    const candles = lastCandlesRef.current
    if (!res) return
    const idx = logical == null ? candles.length - 1 : Math.round(logical)
    const candle = candles[idx]
    if (!candle) return
    const pineTimes = res._times ?? []
    const j = pineTimes.findIndex((t) => pineTimeToChartTime(t) === Number(candle.time))
    for (let i = 0; i < res.plots.length; i++) {
      const plot = res.plots[i]
      const span = valueSpansRef.current.get(`plot:${plot.id ?? i}`)
      if (!span) continue
      const v = j >= 0 ? plot.data?.[j] : undefined
      span.textContent = v == null || !Number.isFinite(v) ? '' : String(Math.round(v * 10000) / 10000)
    }
  }

  // rebind whenever the script's execution result changes — hydrating from
  // the chart candles when the workspace has not pushed any yet
  useEffect(() => {
    if (!result) return
    rebind(lastCandlesRef.current.length ? lastCandlesRef.current : getCandles())
  }, [result])

  // hydrate once on mount (workspace pushes only fire on data advances)
  useEffect(() => {
    rebind(getCandles())
  }, [])

  // ── canvas overlay: fills, bgcolor bands, drawings, alert bells ──
  useEffect(() => {
    let raf = 0
    const draw = () => {
      raf = requestAnimationFrame(draw)
      const canvas = canvasRef.current
      const chart = chartRef.current
      const res = resultRef.current
      if (!canvas || !chart || !res) return
      const parent = canvas.parentElement
      const w = parent ? parent.clientWidth : 0
      const h = parent ? parent.clientHeight : 0
      if (!w || !h) return

      const dpr = window.devicePixelRatio || 1
      if (canvas.width !== Math.floor(w * dpr) || canvas.height !== Math.floor(h * dpr)) {
        canvas.width = Math.max(1, Math.floor(w * dpr))
        canvas.height = Math.max(1, Math.floor(h * dpr))
        canvas.style.width = `${w}px`
        canvas.style.height = `${h}px`
      }
      const ctx = canvas.getContext('2d')
      if (!ctx) return
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
      ctx.clearRect(0, 0, w, h)

      const candles = lastCandlesRef.current
      if (!candles.length) return
      const ts = chart.timeScale()
      const priceSeries: ISeriesApi<any> | null = seriesByPlot.current.get(`plot:${res.plots[0]?.id ?? 0}`) ?? null
      let priceScaleWidth = 0
      try { priceScaleWidth = chart.priceScale('right').width() } catch { priceScaleWidth = 0 }
      const plotRight = Math.max(10, w - priceScaleWidth)

      const times = candles.map((c) => toPineTimeLocal(c))
      const logicalOfTime = (t: number): number | null => {
        let lo = 0, hi = times.length - 1
        if (t <= times[0]) {
          const interval = times.length > 1 ? times[1] - times[0] : 60_000
          return (t - times[0]) / interval
        }
        if (t >= times[hi]) {
          const interval = times.length > 1 ? times[hi] - times[hi - 1] : 60_000
          return hi + (t - times[hi]) / interval
        }
        while (lo < hi) {
          const mid = (lo + hi) >> 1
          if (times[mid] <= t) lo = mid + 1
          else hi = mid
        }
        const t1 = times[lo - 1], t2 = times[lo]
        return lo - 1 + (t - t1) / Math.max(1, t2 - t1)
      }
      const timeToX = (t: number): number | null => {
        try {
          const x = ts.timeToCoordinate(t as Time)
          if (x != null) return x as number
        } catch { /* outside visible range */ }
        const range = ts.getVisibleLogicalRange()
        if (!range) return null
        const logical = logicalOfTime(t)
        if (logical == null) return null
        const barSpacing = plotRight / Math.max(1e-6, range.to - range.from)
        return (logical - range.from) * barSpacing
      }
      const priceToY = (p: number): number | null => {
        const host = priceSeries ?? anchorRef.current
        if (!host) return null
        try {
          const y = host.priceToCoordinate(p)
          return y == null ? null : (y as number)
        } catch { return null }
      }

      /* bgcolor bands */
      const range = ts.getVisibleLogicalRange()
      const pineTimes = res._times ?? []
      if (range) {
        const barSpacing = plotRight / Math.max(1e-6, range.to - range.from)
        for (const layer of res.bgColors || []) {
          if (!Array.isArray(layer)) continue
          for (let i = 0; i < Math.min(layer.length, pineTimes.length); i++) {
            const color = layer[i]
            if (!color) continue
            const logical = logicalOfTime(pineTimes[i])
            if (logical == null) continue
            const x = (logical - range.from) * barSpacing
            if (x < -barSpacing || x > plotRight + barSpacing) continue
            ctx.fillStyle = color
            ctx.fillRect(x - barSpacing / 2, 0, barSpacing + 0.5, h)
          }
        }
      }

      /* fills between plots / hlines */
      const hlineById = new Map(res.hlines.map((l) => [l.id, l]))
      for (const fill of res.fills || []) {
        const plotA = res.plots.find((p) => p.id === fill.plot1)
        const plotB = res.plots.find((p) => p.id === fill.plot2)
        const hlA = hlineById.get(fill.plot1)
        const hlB = hlineById.get(fill.plot2)
        const dataA = plotA ? plotA.data : hlA ? pineTimes.map(() => hlA.price) : null
        const dataB = plotB ? plotB.data : hlB ? pineTimes.map(() => hlB.price) : null
        if (!dataA || !dataB) continue
        const pts: Array<{ x: number; ya: number; yb: number; color: string }> = []
        const n = Math.min(dataA.length, dataB.length, pineTimes.length)
        for (let i = 0; i < n; i++) {
          const va = dataA[i], vb = dataB[i]
          if (va == null || vb == null) continue
          const x = timeToX(pineTimes[i])
          const ya = priceToY(va), yb = priceToY(vb)
          if (x == null || ya == null || yb == null) continue
          pts.push({ x, ya, yb, color: (fill.colors?.[i] || fill.color || '#2962FF33') as string })
        }
        for (let i = 1; i < pts.length; i++) {
          const p0 = pts[i - 1], p1 = pts[i]
          ctx.beginPath()
          ctx.moveTo(p0.x, p0.ya); ctx.lineTo(p1.x, p1.ya)
          ctx.lineTo(p1.x, p1.yb); ctx.lineTo(p0.x, p0.yb)
          ctx.closePath()
          ctx.fillStyle = p1.color
          ctx.fill()
        }
      }

      /* drawing objects (labels / lines / boxes / polylines in pane space) */
      const setLineDashPane = (style: string | undefined, width: number) => {
        switch ((style ?? 'solid').toLowerCase()) {
          case 'dotted': ctx.setLineDash([1.5, Math.max(2, width * 1.8)]); break
          case 'dashed': ctx.setLineDash([Math.max(4, width * 3), Math.max(3, width * 2)]); break
          default: ctx.setLineDash([])
        }
      }
      const defaultText = '#D1D4DC'
      for (const d of (res.drawings || []).slice(-200) as PineDrawing[]) {
        if (d.kind === 'line') {
          const dd = d as PineLineDrawing
          const x1 = timeToX(dd.x1), x2 = timeToX(dd.x2)
          const y1 = priceToY(dd.y1), y2 = priceToY(dd.y2)
          if (x1 == null || x2 == null || y1 == null || y2 == null) continue
          if (Math.max(x1, x2) < -20 || Math.min(x1, x2) > w + 20) continue
          const width = Math.max(1, Math.min(6, dd.width ?? 1))
          ctx.save()
          ctx.strokeStyle = dd.color || defaultText
          ctx.lineWidth = width
          setLineDashPane(dd.style, width)
          ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke()
          ctx.restore()
        } else if (d.kind === 'label') {
          const dd = d as PineLabelDrawing
          const x = timeToX(dd.x)
          if (x == null) continue
          const y = dd.y != null ? priceToY(dd.y) : h / 2
          if (y == null || x < -160 || x > w + 160 || y < -60 || y > h + 60) continue
          const fontSize = fontSizeForPane(dd.size)
          ctx.save()
          ctx.font = `bold ${fontSize}px ${FONT_STACK}`
          const style = (dd.style ?? 'label_up').toLowerCase()
          if (style.startsWith('label_') && dd.text) {
            const wText = ctx.measureText(dd.text).width
            const bw = wText + 12, bh = fontSize + 8
            const bx = x - bw / 2, by = style === 'label_down' ? y - bh - 4 : y + 4
            ctx.fillStyle = dd.color ?? '#2962FF'
            ctx.beginPath()
            const r = 3
            ctx.moveTo(bx + r, by)
            ctx.lineTo(bx + bw - r, by); ctx.quadraticCurveTo(bx + bw, by, bx + bw, by + r)
            ctx.lineTo(bx + bw, by + bh - r); ctx.quadraticCurveTo(bx + bw, by + bh, bx + bw - r, by + bh)
            ctx.lineTo(bx + r, by + bh); ctx.quadraticCurveTo(bx, by + bh, bx, by + bh - r)
            ctx.lineTo(bx, by + r); ctx.quadraticCurveTo(bx, by, bx + r, by)
            ctx.closePath(); ctx.fill()
            ctx.fillStyle = dd.textcolor ?? '#FFFFFF'
            ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
            ctx.fillText(dd.text, bx + bw / 2, by + bh / 2 + 0.5)
          } else if (dd.text) {
            ctx.fillStyle = dd.textcolor ?? defaultText
            ctx.textAlign = 'center'; ctx.textBaseline = 'middle'
            ctx.fillText(dd.text, x, y)
          }
          ctx.restore()
        } else if (d.kind === 'box') {
          const dd = d as PineBoxDrawing
          const xl = timeToX(dd.left), xr = timeToX(dd.right)
          const yt = priceToY(dd.top), yb = priceToY(dd.bottom)
          if (xl == null || xr == null || yt == null || yb == null) continue
          const x = Math.min(xl, xr), bw = Math.max(2, Math.abs(xr - xl))
          const y = Math.min(yt, yb), bh = Math.max(1, Math.abs(yb - yt))
          if (dd.bgcolor) { ctx.fillStyle = dd.bgcolor; ctx.fillRect(x, y, bw, bh) }
          if (dd.borderColor) {
            ctx.strokeStyle = dd.borderColor
            ctx.lineWidth = Math.max(1, Math.min(6, dd.borderWidth ?? 1))
            setLineDashPane(dd.borderStyle, ctx.lineWidth)
            ctx.strokeRect(x + 0.5, y + 0.5, bw - 1, bh - 1)
          }
        }
      }

      /* alert bells at the first plot's value */
      const alerts = (res.alerts || []).filter((a) => a.time != null).slice(-60)
      if (alerts.length) {
        const plot = res.plots[0]
        const pineTimesArr = pineTimes
        for (const a of alerts) {
          const x = timeToX(a.time!)
          if (x == null || x < 6 || x > plotRight - 6) continue
          let y: number | null = null
          if (plot && pineTimesArr.length === plot.data.length) {
            const j = pineTimesArr.findIndex((t) => t === a.time)
            const v = j >= 0 ? plot.data[j] : undefined
            if (v != null && Number.isFinite(v)) y = priceToY(v)
          }
          if (y == null) y = h / 2
          ctx.save()
          ctx.fillStyle = '#FF9800'
          ctx.beginPath(); ctx.arc(x, y, 6, 0, Math.PI * 2); ctx.fill()
          ctx.fillStyle = '#FFFFFF'
          ctx.beginPath()
          ctx.arc(x, y - 1.4, 3.1, Math.PI, 0)
          ctx.lineTo(x + 3.1, y + 2.1)
          ctx.lineTo(x - 3.1, y + 2.1)
          ctx.closePath(); ctx.fill()
          ctx.beginPath(); ctx.arc(x, y + 3.4, 1.05, 0, Math.PI * 2); ctx.fill()
          ctx.restore()
        }
      }
    }
    raf = requestAnimationFrame(draw)
    return () => cancelAnimationFrame(raf)
  }, [])

  // ── imperative handle (same interface as the built-in panes) ──
  const handleRef = useRef<SubPaneHandle | null>(null)
  useImperativeHandle(_ref, () => {
    const handle: SubPaneHandle = {
      uid: `pine:${scriptId}`,
      setData: (candles: CandleLike[]) => rebind(candles),
      updateTail: (candles: CandleLike[]) => rebind(candles),
      applyRange: (from: number, to: number) => {
        const chart = chartRef.current
        if (!chart) return
        applyingRangeRef.current = true
        try {
          chart.timeScale().setVisibleLogicalRange({ from, to })
        } catch { /* noop */ }
        setTimeout(() => { applyingRangeRef.current = false }, 0)
      },
      getRange: () => chartRef.current?.timeScale().getVisibleLogicalRange() ?? null,
      crosshairAt: (logical: number | null, time: number | null) => {
        const chart = chartRef.current
        if (!chart) return
        updateLegend(logical)
        const host = seriesByPlot.current.get(`plot:${resultRef.current?.plots[0]?.id ?? 0}`) ?? anchorRef.current
        if (!host || logical == null || time == null) {
          try { chart.clearCrosshairPosition() } catch { /* noop */ }
          return
        }
        const res = resultRef.current
        const candles = lastCandlesRef.current
        const candle = candles[Math.round(logical)]
        if (!res || !candle) return
        const pineTimes = res._times ?? []
        const j = pineTimes.findIndex((t) => pineTimeToChartTime(t) === Number(candle.time))
        const v = j >= 0 ? res.plots[0]?.data?.[j] : undefined
        if (v == null || !Number.isFinite(v)) {
          try { chart.clearCrosshairPosition() } catch { /* noop */ }
          return
        }
        try { chart.setCrosshairPosition(v, time as Time, host as any) } catch { /* noop */ }
      },
      applyTheme: (isDark: boolean) => {
        chartRef.current?.applyOptions({
          layout: { ...baseChartOptions(themeFor(isDark)).layout },
          grid: { ...baseChartOptions(themeFor(isDark)).grid },
          rightPriceScale: { borderColor: themeFor(isDark).border },
          timeScale: { borderColor: themeFor(isDark).border },
        } as any)
      },
      refreshSeries: () => rebind(lastCandlesRef.current),
    }
    handleRef.current = handle
    return handle
  }, [scriptId])

  useEffect(() => {
    const timer = setTimeout(() => {
      if (handleRef.current) registerHandle(`pine:${scriptId}`, handleRef.current)
    }, 0)
    return () => {
      clearTimeout(timer)
      registerHandle(`pine:${scriptId}`, null)
    }
  }, [scriptId, registerHandle])

  if (!script) return null

  const plots = result?.plots ?? []

  return (
    <div
      data-testid="pine-sub-pane"
      className="relative border-t"
      style={{ height: PANE_HEIGHT, borderColor: dark ? '#2A2E39' : '#E0E3EB' }}
    >
      <div ref={containerRef} className="absolute inset-0" />
      <canvas ref={canvasRef} className="absolute inset-0 z-[3] pointer-events-none" />

      {/* Legend */}
      <div className="absolute top-1 left-2 z-10 flex items-center gap-2 text-[11px] select-none">
        <span className="font-semibold" style={{ color: dark ? '#D1D4DC' : '#131722' }}>
          {script.name}
        </span>
        {plots.map((plot, i) => (
          <span key={i} className="flex items-center gap-1">
            <span className="inline-block w-2 h-0.5 rounded" style={{ background: plot.color || '#2962FF' }} />
            <span
              ref={(el) => { valueSpansRef.current.set(`plot:${plot.id ?? i}`, el) }}
              className="tabular-nums"
              style={{ color: plot.color || '#2962FF' }}
            />
          </span>
        ))}
        <span className="flex items-center gap-0.5 ml-1">
          <button
            onClick={() => onToggle(script.id)}
            title={script.enabled ? 'Hide' : 'Show'}
            className="p-1 rounded hover:bg-black/10"
          >
            {script.enabled ? <Eye className="h-3 w-3 opacity-60" /> : <EyeOff className="h-3 w-3 opacity-40" />}
          </button>
          <button
            onClick={() => onRemove(script.id)}
            title="Remove script"
            className="p-1 rounded hover:bg-black/10"
          >
            <X className="h-3 w-3 opacity-60" />
          </button>
        </span>
      </div>
    </div>
  )
})
