'use client'

import { useEffect, useMemo, useRef, useState, type ChangeEvent, type DragEvent } from 'react'
import { Code2, Play, Plus, Trash2, Upload, X, Eye, EyeOff, RotateCcw, BookOpen, SlidersHorizontal, FileArchive, Files, CheckCircle2, AlertTriangle } from 'lucide-react'
import { inspectPineSource, invalidatePineCaches, getPineInputSchema, type PineExecutionResult, type PineInputDecl } from '@/lib/pine-engine'
import { usePineStore } from '@/lib/pine-store'
import { pineCoordinator } from '@/lib/pine-executor'
import { addLibrary, listLibraries, removeLibrary, computeMissingLibraries, importLibraryBundle, inspectSourceKind, type ImportBundleReport, type MissingLibrary } from '@/lib/pine-libraries'
import { readZipEntries } from '@/lib/zip-reader'
import type { LiveEngine } from '@/lib/live-engine'
import type { ReplayEngine } from '@/lib/replay-engine'

const STARTER = `//@version=6
indicator("EMA Cross", overlay=true)
fast = ta.ema(close, 9)
slow = ta.ema(close, 21)
buy = ta.crossover(fast, slow)
sell = ta.crossunder(fast, slow)
plot(fast, "Fast EMA", color=color.blue, linewidth=2)
plot(slow, "Slow EMA", color=color.orange, linewidth=2)
plotshape(buy, title="BUY", style=shape.triangleup, location=location.belowbar, color=color.lime, size=size.tiny)
plotshape(sell, title="SELL", style=shape.triangledown, location=location.abovebar, color=color.red, size=size.tiny)
`

interface Props {
  dark: boolean
  engine: LiveEngine
  replay: ReplayEngine
  replayActive: boolean
  marketName: string
  candleSize: number
}

function fmtTime(ms?: number): string {
  if (!ms) return ''
  try { return new Date(ms).toLocaleTimeString() } catch { return '' }
}

/** "#00E676FF" (Pine #RRGGBBAA) → "#00E676" for <input type="color">. */
function colorToHex6(value: unknown): string {
  const s = typeof value === 'string' ? value : ''
  return /^#[0-9a-fA-F]{6}/.test(s) ? s.slice(0, 7) : '#000000'
}

function countDrawings(result: PineExecutionResult) {
  const counts = { line: 0, label: 0, box: 0, table: 0, polyline: 0, linefill: 0 }
  for (const d of result.drawings || []) counts[d.kind]++
  return counts
}

export function PineScriptEditor({ dark, engine, replay, replayActive, marketName, candleSize }: Props) {
  const [open, setOpen] = useState(false)
  const [draft, setDraft] = useState(STARTER)
  const [running, setRunning] = useState(false)
  // UI-ONLY bar counter ("N Pine bars"). Execution no longer depends on this
  // state — v1.9 routes every dataset change through pineCoordinator, which
  // fixed the starvation bug: the old 350 ms debounce was cancelled by each
  // new candles-array reference (one per tick) and NEVER fired, freezing
  // results while candles advanced (the cumulative left-drift bug).
  const [barCount, setBarCount] = useState(() => (replayActive ? replay.getVisible() : engine.getPineCandles()).length)
  const barCountRef = useRef(barCount)
  const setBarCountUi = (n: number) => {
    if (n !== barCountRef.current) {
      barCountRef.current = n
      setBarCount(n)
    }
  }
  const [libOpen, setLibOpen] = useState(false)
  const [libKey, setLibKey] = useState('')
  const [libSource, setLibSource] = useState('')
  const [libError, setLibError] = useState<string | null>(null)
  const [libVersion, setLibVersion] = useState(0)
  // ── v1.7 multi-library bulk import ──
  const zipRef = useRef<HTMLInputElement>(null)
  const bulkRef = useRef<HTMLInputElement>(null)
  const [importing, setImporting] = useState(false)
  const [importError, setImportError] = useState<string | null>(null)
  const [importReport, setImportReport] = useState<ImportBundleReport | null>(null)
  const [dragOver, setDragOver] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const addScript = usePineStore((s) => s.addScript)
  const activeId = usePineStore((s) => s.activeId)
  const scripts = usePineStore((s) => s.scripts)
  const setActive = usePineStore((s) => s.setActive)
  const updateScript = usePineStore((s) => s.updateScript)
  const setExecution = usePineStore((s) => s.setExecution)
  const removeScript = usePineStore((s) => s.removeScript)
  const toggle = usePineStore((s) => s.toggle)
  const setInputValue = usePineStore((s) => s.setInputValue)
  const resetInputValues = usePineStore((s) => s.resetInputValues)
  const settingsRev = usePineStore((s) => s.settingsRev)

  // ── Réglages panel state (input.* schema of the ACTIVE script) ──
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [schema, setSchema] = useState<PineInputDecl[] | null>(null)
  const [schemaError, setSchemaError] = useState<string | null>(null)

  const active = useMemo(() => scripts.find((s) => s.id === activeId) ?? scripts[0] ?? null, [scripts, activeId])

  useEffect(() => {
    if (!active) return
    setDraft(active.source)
  }, [active?.id])

  // ── v1.9 — CANONICAL EXECUTION PIPELINE (spec §13) ─────────────────────
  // engine event → coordinator snapshot (revision) → scheduler (single
  // flight, latest-wins) → execution → freshness check → atomic commit.
  //
  // Context: asset/timeframe changes invalidate every previous snapshot and
  // every stored result (spec §23/§24).
  useEffect(() => {
    pineCoordinator.setContext({ asset: marketName, timeframe: candleSize })
    const dataset = replayActive ? replay.getVisible() : engine.getPineCandles()
    setBarCountUi(dataset.length)
    if (dataset.length >= 2) pineCoordinator.notifyDataset(dataset, 'init')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [marketName, candleSize, replayActive, engine, replay])

  // LIVE stream: new candles have MAX priority (immediate revision bump and
  // scheduling); forming-bar ticks are throttled INSIDE the coordinator
  // (same barTime, trailing recalc). During replay the live engine is muted.
  useEffect(() => {
    const feed = (reason: 'new-bar' | 'forming' | 'replace') => {
      const dataset = engine.getPineCandles()
      pineCoordinator.notifyDataset(dataset, reason)
      setBarCountUi(dataset.length)
    }
    const unsubCandle = engine.onCandle((flush) => {
      if (replayActive) return
      feed(flush.isNewCandle ? 'new-bar' : 'forming')
    })
    const unsubHistory = engine.onHistory(() => {
      if (replayActive) return
      // resetHistory() has already refreshed the pine window before emitting.
      feed('replace')
    })
    return () => { unsubCandle(); unsubHistory() }
  }, [engine, replayActive])

  // REPLAY stream: every advance is a complete new bar of the replay prefix;
  // a seek replaces the dataset. The coordinator's single-flight scheduler
  // absorbs X40/X80 cadence (12–25 ms) with a trailing latest-snapshot — no
  // coalescing needed for correctness, only the UI counter is throttled.
  useEffect(() => {
    if (!replayActive) return
    const unsub = replay.onAdvance((candles) => {
      pineCoordinator.notifyDataset(candles, 'new-bar')
      setBarCountUi(candles.length)
    })
    return unsub
  }, [replay, replayActive])

  // Settings changes (Réglages panel) re-run every enabled script on the
  // CURRENT snapshot through the same single-flight pipeline.
  useEffect(() => {
    if (settingsRev === 0) return
    void pineCoordinator.requestImmediateAndWait('manual')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settingsRev])

  function newScript() {
    const id = addScript(STARTER, 'EMA Cross')
    setActive(id)
    setOpen(true)
  }

  /** Manual Run: routes through the coordinator's single-flight pipeline on
   *  the CURRENT snapshot (freshness + atomic commit guaranteed — no more
   *  concurrent ad-hoc executions that could overwrite newer results). */
  async function execute(id: string, source: string) {
    setRunning(true)
    const meta = inspectPineSource(source)
    updateScript(id, source, meta)
    try {
      if (pineCoordinator.snapshotCandles().length < 2) {
        setExecution(id, null, 'loader: Waiting for chart history (at least 2 candles).')
        return
      }
      await pineCoordinator.requestImmediateAndWait('manual')
    } finally {
      setRunning(false)
    }
  }

  function openFile() { fileRef.current?.click() }
  async function onFile(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    const text = await file.text()
    const meta = inspectPineSource(text)
    const id = addScript(text, meta.title || file.name.replace(/\.pine$/i, ''))
    setActive(id)
    setDraft(text)
    setOpen(true)
    e.target.value = ''
    void execute(id, text)
  }

  function reexecuteAll() {
    // Library changes can alter compilation of already-loaded scripts — run
    // every enabled script again (failures may now resolve) through the
    // coordinator (single-flight, same snapshot, atomic commit).
    void pineCoordinator.requestImmediateAndWait('manual')
  }

  function submitLibrary() {
    setLibError(null)
    const res = addLibrary(libKey, libSource)
    if (!res.ok) { setLibError(res.error ?? 'Invalid library'); return }
    setLibKey(''); setLibSource('')
    setLibVersion((v) => v + 1)
    // Library changes can alter compilation of already-loaded scripts.
    invalidatePineCaches()
    reexecuteAll()
  }

  function deleteLibrary(key: string) {
    removeLibrary(key)
    setLibVersion((v) => v + 1)
    invalidatePineCaches()
    reexecuteAll()
  }

  /** Register a whole pack (ZIP entries or picked files) in one operation. */
  async function importBundleFiles(files: Array<{ name: string; source: string }>) {
    if (!files.length) return
    setImporting(true)
    setImportError(null)
    try {
      const report = importLibraryBundle(files)
      setImportReport(report)
      setLibVersion((v) => v + 1)
      invalidatePineCaches()
      // Auto-add the pack's main script(s) to the editor (dedup by identical
      // source — a re-import of the same pack must not duplicate entries).
      const existing = new Set(usePineStore.getState().scripts.map((s) => s.source))
      let added = false
      for (const main of report.mainScripts) {
        if (existing.has(main.file.source)) continue
        const id = addScript(main.file.source, main.title || 'Pine Script')
        setActive(id)
        setDraft(main.file.source)
        added = true
      }
      // Uniform re-execution of EVERY enabled script: the newly added mains
      // AND previously-errored scripts whose imports may now resolve (deduped
      // mains included — a lib registration can unblock them).
      if (added || report.registered.length > 0 || report.aliased.length > 0) reexecuteAll()
    } catch (err) {
      setImportError(err instanceof Error ? err.message : String(err))
    } finally {
      setImporting(false)
    }
  }

  async function onZip(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    e.target.value = ''
    if (!file) return
    try {
      const entries = await readZipEntries(await file.arrayBuffer())
      const files = entries
        .filter((en) => !en.binary && /\.(pine|txt)$/i.test(en.name))
        .map((en) => ({ name: en.name, source: en.text }))
      if (!files.length) {
        setImportError(`Aucun fichier .pine / .txt trouvé dans « ${file.name} ».`)
        return
      }
      await importBundleFiles(files)
    } catch (err) {
      setImportError(err instanceof Error ? err.message : String(err))
    }
  }

  async function onBulkFiles(e: ChangeEvent<HTMLInputElement>) {
    const picked = Array.from(e.target.files ?? [])
    e.target.value = ''
    if (!picked.length) return
    try {
      const files: Array<{ name: string; source: string }> = []
      for (const f of picked) {
        const text = await f.text()
        if (/\.(pine|txt)$/i.test(f.name) || inspectSourceKind(text).declaration !== 'unknown') {
          files.push({ name: f.name, source: text })
        }
      }
      if (!files.length) {
        setImportError('Aucune source Pine valide sélectionnée.')
        return
      }
      await importBundleFiles(files)
    } catch (err) {
      setImportError(err instanceof Error ? err.message : String(err))
    }
  }

  /** Drag & drop d'un pack (ZIP) ou de fichiers .pine sur l'éditeur entier. */
  async function onDropFiles(e: DragEvent) {
    e.preventDefault()
    setDragOver(false)
    const dropped = Array.from(e.dataTransfer.files ?? [])
    if (!dropped.length) return
    setImportError(null)
    try {
      const zip = dropped.find((f) => /\.zip$/i.test(f.name))
      if (zip) {
        const entries = await readZipEntries(await zip.arrayBuffer())
        const files = entries
          .filter((en) => !en.binary && /\.(pine|txt)$/i.test(en.name))
          .map((en) => ({ name: en.name, source: en.text }))
        if (!files.length) {
          setImportError(`Aucun fichier .pine / .txt trouvé dans « ${zip.name} ».`)
          return
        }
        await importBundleFiles(files)
        return
      }
      const files: Array<{ name: string; source: string }> = []
      for (const f of dropped) {
        const text = await f.text()
        if (/\.(pine|txt)$/i.test(f.name) || inspectSourceKind(text).declaration !== 'unknown') {
          files.push({ name: f.name, source: text })
        }
      }
      if (!files.length) {
        setImportError('Aucune source Pine valide déposée (fichiers .pine / .txt ou archive ZIP).')
        return
      }
      await importBundleFiles(files)
    } catch (err) {
      setImportError(err instanceof Error ? err.message : String(err))
    }
  }

  const missingImports = useMemo<MissingLibrary[]>(() => {
    if (!active) return []
    // v1.7 — transitive closure: walks the active script's imports AND every
    // registered library's own imports, so a dependency needed only by a
    // library (e.g. PubLibCandleTrend behind PubLibSwing) is listed too.
    return computeMissingLibraries(active.source)
  }, [active?.source, libVersion])

  /** Nombre de dépendances non résolues PAR script (badge ambre du panneau latéral). */
  const missingByScript = useMemo(() => {
    const map = new Map<string, number>()
    for (const s of scripts) map.set(s.id, computeMissingLibraries(s.source).length)
    return map
  }, [scripts, libVersion])

  const libsCount = useMemo(() => listLibraries().length, [libVersion])
  const anyMissingImport = useMemo(() => [...missingByScript.values()].some((n) => n > 0), [missingByScript])

  // Compile-once (cached) schema of the active script's input declarations.
  useEffect(() => {
    if (!settingsOpen || !active) return
    let cancelled = false
    setSchema(null)
    setSchemaError(null)
    getPineInputSchema(active.source).then((res) => {
      if (cancelled) return
      setSchema(res.inputs)
      setSchemaError(res.error)
    })
    return () => { cancelled = true }
  }, [settingsOpen, active?.id, active?.source])

  const groupedInputs = useMemo(() => {
    if (!schema) return [] as Array<{ name: string; items: PineInputDecl[] }>
    const out: Array<{ name: string; items: PineInputDecl[] }> = []
    const index = new Map<string, { name: string; items: PineInputDecl[] }>()
    for (const decl of schema) {
      const name = decl.group?.trim() || 'Réglages'
      let bucket = index.get(name)
      if (!bucket) {
        bucket = { name, items: [] }
        index.set(name, bucket)
        out.push(bucket)
      }
      bucket.items.push(decl)
    }
    return out
  }, [schema])

  const bg = dark ? '#131722' : '#fff'
  const surface = dark ? '#1E222D' : '#F7F8FA'
  const border = dark ? '#2A2E39' : '#E0E3EB'
  const text = dark ? '#D1D4DC' : '#131722'
  const muted = '#787B86'

  const result = active?.result ?? null
  const drawCounts = result ? countDrawings(result) : null

  return (
    <>
      <div className="fixed top-[58px] right-3 z-[65] flex items-center gap-1">
        <button
          onClick={() => setOpen(true)}
          className="relative flex items-center gap-1.5 px-3 py-1.5 rounded-md border shadow-lg text-[11px] font-bold tracking-wide transition-transform hover:scale-[1.02]"
          style={{ background: bg, borderColor: '#2962FF', color: text }}
          title="Open Pine Script editor"
        >
          <Code2 className="h-3.5 w-3.5" style={{ color: '#2962FF' }} />
          PINE SCRIPT
          {anyMissingImport && (
            <span
              className="absolute -top-1 -right-1 h-2.5 w-2.5 rounded-full"
              style={{ background: '#FF9800', boxShadow: `0 0 0 2px ${bg}` }}
              title="Des scripts importent des librairies non enregistrées — cliquez pour les importer"
            />
          )}
        </button>
      </div>

      {open && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-3" style={{ background: 'rgba(0,0,0,.58)' }}>
          <div
            className="w-[1100px] max-w-[97vw] h-[76vh] max-h-[820px] rounded-xl border shadow-2xl flex flex-col overflow-hidden relative"
            style={{ background: bg, borderColor: border }}
            onDragOver={(e) => { e.preventDefault(); if (!dragOver) setDragOver(true) }}
            onDragLeave={(e) => { if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setDragOver(false) }}
            onDrop={onDropFiles}
          >
            {dragOver && (
              <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-2 rounded-xl" style={{ background: 'rgba(255,152,0,.16)', border: '2px dashed #FF9800' }}>
                <FileArchive className="h-9 w-9" style={{ color: '#FF9800' }} />
                <div className="text-sm font-bold" style={{ color: '#FF9800' }}>Déposez le pack — archive ZIP ou fichiers .pine</div>
                <div className="text-[10px]" style={{ color: muted }}>Librairies et script principal importés en une seule opération · clés déduites automatiquement</div>
              </div>
            )}
            <div className="h-11 shrink-0 flex items-center gap-2 px-3 border-b" style={{ borderColor: border }}>
              <Code2 className="h-4 w-4" style={{ color: '#2962FF' }} />
              <span className="text-sm font-semibold" style={{ color: text }}>Pine Script</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: surface, color: muted }}>v5 / v6</span>
              <span className="text-[10px] ml-auto" style={{ color: muted }}>{marketName} · {candleSize}s · {barCount} Pine bars</span>
              <button
                onClick={() => setLibOpen(true)}
                className="relative flex items-center gap-1 px-2 py-1 rounded text-[10px] font-medium hover:bg-black/10"
                style={{ color: missingImports.length > 0 ? '#FF9800' : muted }}
                title="Librairies Pine — importer un pack ZIP / fichiers, gérer les librairies enregistrées"
              >
                <BookOpen className="h-3.5 w-3.5" /> Librairies
                {libsCount > 0 && <span className="px-1 rounded" style={{ background: surface, color: muted }}>{libsCount}</span>}
                {missingImports.length > 0 && <span className="h-1.5 w-1.5 rounded-full" style={{ background: '#FF9800' }} />}
              </button>
              <button onClick={() => setOpen(false)} data-testid="pine-editor-close" className="p-1 rounded hover:bg-black/10"><X className="h-4 w-4" style={{ color: muted }} /></button>
            </div>

            <div className="flex flex-1 min-h-0">
              <aside className="w-[230px] border-r flex flex-col" style={{ borderColor: border, background: surface }}>
                <div className="p-2 flex gap-1">
                  <button onClick={newScript} className="flex-1 flex items-center justify-center gap-1 px-2 py-1.5 rounded border text-[10px]" style={{ borderColor: border, color: text }}><Plus className="h-3 w-3" /> New</button>
                  <button onClick={openFile} className="p-1.5 rounded border" style={{ borderColor: border }} title="Load .pine"><Upload className="h-3 w-3" style={{ color: text }} /></button>
                  <input ref={fileRef} type="file" accept=".pine,.txt,text/plain" className="hidden" onChange={onFile} />
                  <input ref={zipRef} type="file" accept=".zip,application/zip,application/x-zip-compressed" className="hidden" onChange={onZip} />
                  <input ref={bulkRef} type="file" accept=".pine,.txt,text/plain" multiple className="hidden" onChange={onBulkFiles} />
                </div>
                <div className="flex-1 overflow-y-auto">
                  {scripts.length === 0 && <div className="p-3 text-[10px]" style={{ color: muted }}>Create or load a Pine script.</div>}
                  {scripts.map((s) => (
                    <div key={s.id} className="px-2 py-2 border-t cursor-pointer" style={{ borderColor: border, background: s.id === activeId ? (dark ? '#2A2E39' : '#E8EEF9') : 'transparent' }} onClick={() => { setActive(s.id); setDraft(s.source) }}>
                      <div className="flex items-center gap-1.5">
                        <span className="flex-1 truncate text-[11px] font-medium" style={{ color: text }}>{s.name}</span>
                        {(missingByScript.get(s.id) ?? 0) > 0 && (
                          <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: '#FF9800' }} title="Ce script importe des librairies non encore enregistrées" />
                        )}
                        <button onClick={(e) => { e.stopPropagation(); toggle(s.id) }} className="p-0.5">{s.enabled ? <Eye className="h-3 w-3" style={{ color: muted }} /> : <EyeOff className="h-3 w-3" style={{ color: '#F23645' }} />}</button>
                        <button onClick={(e) => { e.stopPropagation(); removeScript(s.id) }} className="p-0.5"><Trash2 className="h-3 w-3" style={{ color: muted }} /></button>
                      </div>
                      <div className="text-[9px] mt-1" style={{ color: muted }}>{s.meta.declaration} · Pine {s.meta.version}</div>
                      {s.error && <div className="text-[9px] mt-1 line-clamp-2" style={{ color: '#F23645' }}>{s.error}</div>}
                    </div>
                  ))}
                </div>
              </aside>

              <section className="flex-1 min-w-0 flex flex-col">
                <div className="h-9 shrink-0 flex items-center gap-2 px-3 border-b" style={{ borderColor: border }}>
                  <span className="text-[10px] uppercase tracking-wide" style={{ color: muted }}>Editor</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded" style={{ background: surface, color: muted }}>
                    {active ? `Editing: ${active.name}` : 'New script'}
                  </span>
                  <button onClick={() => setDraft(STARTER)} className="ml-auto flex items-center gap-1 text-[10px] px-1.5 py-1 rounded hover:bg-black/10" style={{ color: muted }}><RotateCcw className="h-3 w-3" /> Template</button>
                  <button
                    onClick={() => setSettingsOpen(true)}
                    disabled={!active}
                    className="flex items-center gap-1 text-[10px] px-1.5 py-1 rounded hover:bg-black/10"
                    style={{ color: active ? '#2962FF' : muted, opacity: active ? 1 : .45 }}
                    title="Réglages du script — tous les paramètres input() : cases à cocher, couleurs, épaisseurs…"
                  >
                    <SlidersHorizontal className="h-3 w-3" /> Réglages
                  </button>
                  <button
                    disabled={!draft.trim() || running}
                    onClick={() => {
                      if (!draft.trim() || running) return
                      const meta = inspectPineSource(draft)
                      if (active) {
                        execute(active.id, draft)
                      } else {
                        const id = addScript(draft, meta.title || 'Pine Script')
                        setActive(id)
                        void execute(id, draft)
                      }
                    }}
                    className="flex items-center gap-1 px-2.5 py-1 rounded text-[10px] font-semibold"
                    style={{ background: running ? '#5A6B8C' : '#2962FF', color: '#fff', opacity: !draft.trim() ? .5 : 1 }}
                    title={active ? 'Compile and run this script' : 'Add this pasted script and run it'}
                  >
                    <Play className="h-3 w-3" /> {running ? 'Compiling…' : active ? 'Run' : 'Add / Run'}
                  </button>
                </div>
                <textarea value={draft} onChange={(e) => setDraft(e.target.value)} spellCheck={false} className="flex-1 resize-none bg-transparent outline-none p-3 font-mono text-[12px] leading-5" style={{ color: text }} placeholder={STARTER} />

                {/* ── execution console: full visual/alert/strategy inventory ── */}
                <div className="h-40 shrink-0 border-t overflow-y-auto p-2 space-y-2" style={{ borderColor: border, background: surface }}>
                  {/* v1.7 — bannière LIBRAIRIES REQUISES : affichée dès qu'une dépendance
                      (directe OU transitive) du script actif n'est pas enregistrée, même
                      avant toute exécution — c'est l'invite d'import demandée. */}
                  {active && missingImports.length > 0 && (
                    <div className="rounded border px-2.5 py-2 space-y-1.5" style={{ borderColor: 'rgba(255,183,77,.45)', background: dark ? 'rgba(255,152,0,.09)' : 'rgba(255,152,0,.1)' }}>
                      <div className="flex items-center gap-1.5 text-[10px] font-bold" style={{ color: '#FF9800' }}>
                        <AlertTriangle className="h-3.5 w-3.5 shrink-0" />
                        LIBRAIRIES REQUISES ({missingImports.length}) — importez le pack pour exécuter ce script
                      </div>
                      {missingImports.map((m) => (
                        <div key={m.path} className="text-[9px] leading-4 font-mono break-all" style={{ color: text }} title={`${m.path} — requise par ${m.importers.join(', ')}`}>
                          {m.path}
                          <span className="font-sans" style={{ color: muted }}> · requise par {m.importers.join(' ← ')}</span>
                        </div>
                      ))}
                      <div className="flex flex-wrap items-center gap-2 pt-0.5">
                        <button
                          onClick={() => zipRef.current?.click()}
                          disabled={importing}
                          className="flex items-center gap-1.5 px-2.5 py-1 rounded text-[10px] font-semibold hover:opacity-90"
                          style={{ background: '#FF9800', color: '#fff', opacity: importing ? .6 : 1 }}
                        >
                          <FileArchive className="h-3 w-3" /> Importer le pack (ZIP)
                        </button>
                        <button
                          onClick={() => bulkRef.current?.click()}
                          disabled={importing}
                          className="flex items-center gap-1.5 px-2.5 py-1 rounded border text-[10px] font-semibold hover:bg-black/5"
                          style={{ borderColor: '#FF9800', color: '#FF9800', opacity: importing ? .6 : 1 }}
                        >
                          <Files className="h-3 w-3" /> Fichiers séparés
                        </button>
                        <button onClick={() => setLibOpen(true)} className="text-[10px] underline underline-offset-2" style={{ color: muted }}>
                          Gestion des librairies
                        </button>
                      </div>
                      <div className="text-[9px] leading-3.5" style={{ color: muted }}>
                        Glissez-déposez aussi l'archive ZIP directement dans l'éditeur. Clés <span className="font-mono">auteur/nom/version</span> déduites automatiquement des imports — aucun réglage.
                      </div>
                    </div>
                  )}
                  {!active ? <div className="text-[10px]" style={{ color: muted }}>No active script.</div> : active.error ? (
                    <div className="space-y-1">
                      <div className="text-[10px] leading-4" style={{ color: '#F23645' }}>{active.error}</div>
                    </div>
                  ) : result ? (
                    <div className="space-y-1.5">
                      <div className="text-[10px] font-semibold" style={{ color: text }}>
                        {result.title} · {result.plots.length} plot(s) · {result.markers.length} marker series · {result.hlines.length} hline(s) · {result.fills.length} fill(s) · {result.drawings.length} drawing object(s)
                      </div>
                      {drawCounts && (drawCounts.line + drawCounts.label + drawCounts.box + drawCounts.table + drawCounts.polyline + drawCounts.linefill) > 0 && (
                        <div className="text-[9px]" style={{ color: muted }}>
                          drawings: {drawCounts.line} lines · {drawCounts.label} labels · {drawCounts.box} boxes · {drawCounts.polyline} polylines · {drawCounts.table} tables · {drawCounts.linefill} linefills
                        </div>
                      )}
                      {result.plots.map((p) => (
                        <div key={p.id} className="flex items-center gap-2 text-[9px]" style={{ color: muted }}>
                          <span className="inline-block w-2 h-2 rounded-full" style={{ background: p.color || '#2962FF' }} />
                          {p.title}<span className="ml-auto">{p.data.filter((v) => v != null).length} values</span>
                        </div>
                      ))}
                      {result.strategy && (result.strategy.closedTrades.length > 0 || result.strategy.netProfit !== 0) && (
                        <div className="text-[9px] px-2 py-1.5 rounded leading-4" style={{ background: dark ? 'rgba(41,98,255,.1)' : 'rgba(41,98,255,.08)', color: text }}>
                          <span className="font-semibold">Strategy</span> · Net PnL {result.strategy.netProfit.toFixed(2)} · {result.strategy.closedTrades.length} trades ·
                          win rate {result.strategy.winRate.toFixed(1)}% · max DD {result.strategy.maxDrawdownPercent.toFixed(2)}% ·
                          commission {result.strategy.totalCommission.toFixed(2)}
                        </div>
                      )}
                      {result.alerts.length > 0 && (
                        <div className="space-y-0.5">
                          <div className="text-[9px] font-semibold" style={{ color: muted }}>{result.alerts.length} alert event(s) — latest:</div>
                          {result.alerts.slice(-4).reverse().map((a, i) => (
                            <div key={i} className="text-[9px] truncate" style={{ color: muted }} title={a.message}>
                              <span style={{ color: '#FFB74D' }}>▸ {fmtTime(a.time)}</span> {a.message.slice(0, 110)}
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ) : <div className="text-[10px]" style={{ color: muted }}>Press Add / Run to compile and execute on the current dataset.</div>}
                </div>
              </section>
            </div>
          </div>
        </div>
      )}

      {/* ── script settings: the input.* Réglages panel ── */}
      {settingsOpen && active && (
        <div className="fixed inset-0 z-[75] flex items-center justify-center p-3" style={{ background: 'rgba(0,0,0,.58)' }}>
          <div className="w-[620px] max-w-[95vw] h-[74vh] max-h-[780px] rounded-xl border shadow-2xl flex flex-col overflow-hidden" style={{ background: bg, borderColor: border }}>
            <div className="h-11 shrink-0 flex items-center gap-2 px-3 border-b" style={{ borderColor: border }}>
              <SlidersHorizontal className="h-4 w-4 shrink-0" style={{ color: '#2962FF' }} />
              <span className="text-sm font-semibold truncate" style={{ color: text }}>Réglages — {active.name}</span>
              {schema && schema.length > 0 && (
                <span className="text-[10px] px-1.5 py-0.5 rounded shrink-0" style={{ background: surface, color: muted }}>{schema.length} paramètres</span>
              )}
              <button
                onClick={() => resetInputValues(active.id)}
                className="ml-auto flex items-center gap-1 text-[10px] px-2 py-1 rounded hover:bg-black/10 shrink-0"
                style={{ color: muted }}
                title="Restaurer tous les paramètres aux valeurs par défaut du script"
              >
                <RotateCcw className="h-3 w-3" /> Défauts
              </button>
              <button onClick={() => setSettingsOpen(false)} data-testid="pine-settings-close" className="p-1 rounded hover:bg-black/10 shrink-0"><X className="h-4 w-4" style={{ color: muted }} /></button>
            </div>
            <div className="flex-1 overflow-y-auto p-3 space-y-3">
              {schemaError && (
                <div className="text-[10px] leading-4 px-2 py-1.5 rounded" style={{ background: 'rgba(242,54,69,.08)', color: '#F23645' }}>
                  Impossible d&apos;analyser les paramètres : {schemaError}
                </div>
              )}
              {!schema && !schemaError && <div className="text-[10px]" style={{ color: muted }}>Analyse des paramètres du script…</div>}
              {schema && schema.length === 0 && !schemaError && (
                <div className="text-[10px]" style={{ color: muted }}>Ce script ne déclare aucun input() — il n&apos;a donc aucun réglage modifiable.</div>
              )}
              {groupedInputs.map((g) => (
                <div key={g.name} className="rounded-lg border overflow-hidden" style={{ borderColor: border }}>
                  <div className="px-2.5 py-1.5 text-[10px] font-bold uppercase tracking-wide flex items-center justify-between" style={{ background: surface, color: muted }}>
                    <span className="truncate">{g.name}</span>
                    <span className="shrink-0 ml-2">{g.items.length}</span>
                  </div>
                  {g.items.map((decl, i) => {
                    const raw = active.inputValues?.[decl.key] ?? decl.default
                    const label = decl.title?.trim()
                      || (decl.tooltip ? decl.tooltip.split(/[:.]/)[0].trim() : decl.kind === 'color' ? 'Couleur' : 'Valeur')
                    const isNum = decl.kind === 'int' || decl.kind === 'float' || decl.kind === 'price'
                    return (
                      <div key={decl.key} className="flex items-center gap-2 px-2.5 py-1.5" style={{ background: i % 2 ? surface : 'transparent' }} title={decl.tooltip ?? undefined}>
                        {decl.kind === 'bool' ? (
                          <>
                            <input
                              type="checkbox"
                              checked={Boolean(raw)}
                              onChange={(e) => setInputValue(active.id, decl.key, e.target.checked)}
                              className="h-3.5 w-3.5 shrink-0 accent-[#2962FF] cursor-pointer"
                            />
                            <span className="flex-1 text-[11px] leading-4" style={{ color: text }}>{label}</span>
                          </>
                        ) : (
                          <>
                            <span className="flex-1 truncate text-[11px] leading-4" style={{ color: text }}>{label}</span>
                            {decl.kind === 'color' ? (
                              <input
                                type="color"
                                value={colorToHex6(raw)}
                                onChange={(e) => setInputValue(active.id, decl.key, e.target.value)}
                                className="h-6 w-10 shrink-0 rounded border cursor-pointer bg-transparent"
                                style={{ borderColor: border }}
                              />
                            ) : isNum ? (
                              <input
                                type="number"
                                value={Number(raw)}
                                min={decl.minval}
                                max={decl.maxval}
                                step={decl.step ?? (decl.kind === 'int' ? 1 : undefined)}
                                onChange={(e) => {
                                  const n = Number(e.target.value)
                                  if (Number.isFinite(n)) setInputValue(active.id, decl.key, n)
                                }}
                                className="w-24 shrink-0 px-1.5 py-1 rounded border text-[11px] text-right"
                                style={{ background: bg, borderColor: border, color: text }}
                              />
                            ) : decl.options && decl.options.length > 0 ? (
                              <select
                                value={String(raw)}
                                onChange={(e) => setInputValue(active.id, decl.key, e.target.value)}
                                className="max-w-[230px] shrink-0 px-1.5 py-1 rounded border text-[11px]"
                                style={{ background: bg, borderColor: border, color: text }}
                              >
                                {decl.options.map((o) => <option key={String(o)} value={String(o)}>{String(o)}</option>)}
                              </select>
                            ) : (
                              <input
                                type="text"
                                value={String(raw ?? '')}
                                onChange={(e) => setInputValue(active.id, decl.key, e.target.value)}
                                className="w-36 shrink-0 px-1.5 py-1 rounded border text-[11px]"
                                style={{ background: bg, borderColor: border, color: text }}
                              />
                            )}
                          </>
                        )}
                      </div>
                    )
                  })}
                </div>
              ))}
            </div>
            <div className="shrink-0 px-3 py-2 border-t text-[9px] leading-4" style={{ borderColor: border, color: muted }}>
              Les modifications sont appliquées immédiatement au graphique (re-exécution du script) et sauvegardées avec le script. « Défauts » restaure les valeurs du code source.
            </div>
          </div>
        </div>
      )}

      {/* ── v1.7 — gestionnaire de librairies Pine : import de pack + registre + ajout manuel ── */}
      {libOpen && (
        <div className="fixed inset-0 z-[80] flex items-center justify-center p-3" style={{ background: 'rgba(0,0,0,.58)' }}>
          <div className="w-[760px] max-w-[95vw] max-h-[82vh] rounded-xl border shadow-2xl flex flex-col overflow-hidden" style={{ background: bg, borderColor: border }}>
            <div className="h-11 shrink-0 flex items-center gap-2 px-3 border-b" style={{ borderColor: border }}>
              <BookOpen className="h-4 w-4" style={{ color: '#2962FF' }} />
              <span className="text-sm font-semibold" style={{ color: text }}>Librairies Pine</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: surface, color: muted }}>{libsCount} enregistrée(s)</span>
              <button onClick={() => setLibOpen(false)} data-testid="pine-libraries-close" className="ml-auto p-1 rounded hover:bg-black/10"><X className="h-4 w-4" style={{ color: muted }} /></button>
            </div>
            <div className="p-3 space-y-3 overflow-y-auto">

              {/* ── import d'un pack complet (ZIP / fichiers multiples) ── */}
              <div className="rounded-lg border p-2.5 space-y-2" style={{ borderColor: 'rgba(255,152,0,.4)', background: dark ? 'rgba(255,152,0,.05)' : 'rgba(255,152,0,.04)' }}>
                <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wide" style={{ color: '#FF9800' }}>
                  <FileArchive className="h-3.5 w-3.5" /> Importer un pack complet
                </div>
                <div className="text-[10px] leading-4" style={{ color: muted }}>
                  Archive ZIP du script principal + dossier <span className="font-mono">libs/</span> (packs TradingView), ou sélection de plusieurs fichiers <span className="font-mono">.pine</span>.
                  Les clés <span className="font-mono">auteur/nom/version</span> sont déduites automatiquement des instructions import — dépendances transitives et alias d&apos;auteurs compris.
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => zipRef.current?.click()}
                    disabled={importing}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded text-[11px] font-semibold hover:opacity-90"
                    style={{ background: '#FF9800', color: '#fff', opacity: importing ? .6 : 1 }}
                  >
                    <FileArchive className="h-3.5 w-3.5" /> {importing ? 'Import en cours…' : 'Importer un ZIP'}
                  </button>
                  <button
                    onClick={() => bulkRef.current?.click()}
                    disabled={importing}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded border text-[11px] font-semibold hover:bg-black/5"
                    style={{ borderColor: '#FF9800', color: '#FF9800', opacity: importing ? .6 : 1 }}
                  >
                    <Files className="h-3.5 w-3.5" /> Fichiers multiples
                  </button>
                </div>
                {importError && (
                  <div className="text-[10px] leading-4 px-2 py-1.5 rounded" style={{ background: 'rgba(242,54,69,.08)', color: '#F23645' }}>{importError}</div>
                )}

                {/* rapport du dernier import */}
                {importReport && (
                  <div className="space-y-1.5 pt-1">
                    {importReport.registered.length > 0 && (
                      <div className="space-y-1">
                        <div className="text-[10px] font-semibold flex items-center gap-1" style={{ color: '#26A69A' }}>
                          <CheckCircle2 className="h-3 w-3" /> {importReport.registered.length} librairie(s) enregistrée(s) — les scripts ré-importés s&apos;exécutent automatiquement :
                        </div>
                        {importReport.registered.map((r) => (
                          <div key={r.key} className="text-[9px] leading-4 font-mono px-2 py-1 rounded space-y-0.5" style={{ background: surface, color: text }}>
                            {r.keys.map((k, i) => (
                              <div key={k} className="flex items-center gap-1.5 min-w-0">
                                <span className="truncate">{k}</span>
                                {i > 0 && <span className="font-sans text-[8px] px-1 rounded shrink-0" style={{ background: 'rgba(41,98,255,.15)', color: '#2962FF' }}>alias</span>}
                                {i === 0 && r.matched === 'fallback' && <span className="font-sans text-[8px] px-1 rounded shrink-0" style={{ background: 'rgba(255,183,77,.2)', color: '#FF9800' }}>clé devinée — aucun import ne la référence</span>}
                                {i === 0 && r.replacedBuiltin && <span className="font-sans text-[8px] px-1 rounded shrink-0" style={{ background: 'rgba(38,166,154,.15)', color: '#26A69A' }}>shim intégré remplacé</span>}
                                {i === 0 && r.replacedUser && <span className="font-sans text-[8px] px-1 rounded shrink-0" style={{ background: 'rgba(41,98,255,.12)', color: '#2962FF' }}>mise à jour</span>}
                              </div>
                            ))}
                            <div className="font-sans text-[8px]" style={{ color: muted }}>← {r.fileName}</div>
                          </div>
                        ))}
                      </div>
                    )}
                    {importReport.mainScripts.length > 0 && (
                      <div className="text-[10px] leading-4 flex items-start gap-1" style={{ color: '#26A69A' }}>
                        <CheckCircle2 className="h-3 w-3 mt-0.5 shrink-0" />
                        <span>{importReport.mainScripts.length} script(s) principal(aux) ajouté(s) à l&apos;éditeur et exécuté(s) : {importReport.mainScripts.map((m) => m.title || m.file.name).join(' · ')}</span>
                      </div>
                    )}
                    {importReport.skipped.length > 0 && (
                      <div className="text-[10px] leading-4" style={{ color: '#FF9800' }}>
                        Ignoré(s) : {importReport.skipped.map((s) => `${s.file.name} (${s.reason})`).join(' · ')}
                      </div>
                    )}
                    {importReport.missing.length > 0 && (
                      <div className="text-[10px] leading-4 px-2 py-1.5 rounded space-y-1" style={{ background: 'rgba(255,183,77,.1)' }}>
                        <div className="font-semibold flex items-center gap-1" style={{ color: '#FF9800' }}>
                          <AlertTriangle className="h-3 w-3" /> {importReport.missing.length} dépendance(s) encore manquante(s) :
                        </div>
                        {importReport.missing.map((m) => (
                          <div key={m.path} className="font-mono text-[9px]" style={{ color: text }}>
                            {m.path} <span className="font-sans" style={{ color: muted }}>— requise par {m.importers.join(' ← ')}</span>
                          </div>
                        ))}
                        <div className="font-sans text-[9px]" style={{ color: muted }}>Importez un pack contenant ces librairies (ou collez leur source ci-dessous) pour compléter le graphe.</div>
                      </div>
                    )}
                    {importReport.registered.length === 0 && importReport.mainScripts.length === 0 && importReport.missing.length === 0 && (
                      <div className="text-[10px]" style={{ color: muted }}>Rien à importer : aucune librairie ni script principal détecté dans la sélection.</div>
                    )}
                  </div>
                )}
              </div>

              {/* ── registre ── */}
              <div className="space-y-1">
                <div className="text-[10px] font-bold uppercase tracking-wide" style={{ color: muted }}>Librairies enregistrées ({libsCount})</div>
                {listLibraries().map((lib) => (
                  <div key={lib.key} className="flex items-center gap-2 px-2 py-1.5 rounded border text-[10px]" style={{ borderColor: border, background: surface }} title={lib.note ?? lib.key}>
                    <span className="flex-1 truncate font-mono" style={{ color: text }}>{lib.key}</span>
                    {lib.builtin && <span className="text-[8px] px-1 rounded shrink-0" style={{ background: 'rgba(41,98,255,.12)', color: '#2962FF' }}>SHIM</span>}
                    <span className="shrink-0" style={{ color: muted }}>{(lib.source.length / 1024).toFixed(1)} KB</span>
                    <button
                      onClick={() => deleteLibrary(lib.key)}
                      disabled={lib.builtin}
                      className="p-1 rounded hover:bg-black/10 disabled:opacity-30 disabled:cursor-not-allowed shrink-0"
                      title={lib.builtin ? 'Shim intégré — remplacé automatiquement en important la source officielle sous la même clé' : 'Supprimer cette librairie'}
                    >
                      <Trash2 className="h-3 w-3" style={{ color: lib.builtin ? muted : '#F23645' }} />
                    </button>
                  </div>
                ))}
                {libsCount === 0 && <div className="text-[10px] px-2 py-2 rounded border border-dashed" style={{ borderColor: border, color: muted }}>Aucune librairie enregistrée pour l&apos;instant — importez un pack ci-dessus.</div>}
              </div>

              {/* ── ajout manuel d'une seule librairie ── */}
              <div className="space-y-2 pt-2 border-t" style={{ borderColor: border }}>
                <div className="text-[10px] font-bold uppercase tracking-wide" style={{ color: muted }}>Ajout manuel — une librairie</div>
                <div className="text-[9px] leading-4" style={{ color: muted }}>
                  Pour une librairie isolée : copiez sa source depuis sa page TradingView (onglet « Source code »), puis enregistrez-la avec son chemin d&apos;import exact comme clé.
                </div>
                <input
                  value={libKey}
                  onChange={(e) => setLibKey(e.target.value)}
                  placeholder="auteur/nom/version  (ex. PiracyChecker/PubLibSwing/3)"
                  className="w-full px-2 py-1.5 rounded border text-[11px] font-mono outline-none"
                  style={{ background: surface, borderColor: border, color: text }}
                />
                <textarea
                  value={libSource}
                  onChange={(e) => setLibSource(e.target.value)}
                  placeholder={'// Source Pine de la librairie (doit contenir la déclaration library("nom"))\n//@version=6\nlibrary("ZigZag", overlay=true)\n…'}
                  spellCheck={false}
                  className="w-full h-40 resize-none px-2 py-1.5 rounded border text-[11px] font-mono outline-none"
                  style={{ background: surface, borderColor: border, color: text }}
                />
                {libError && <div className="text-[10px]" style={{ color: '#F23645' }}>{libError}</div>}
                <button onClick={submitLibrary} disabled={!libKey.trim() || !libSource.trim()} className="px-3 py-1.5 rounded text-[11px] font-semibold" style={{ background: '#2962FF', color: '#fff', opacity: !libKey.trim() || !libSource.trim() ? .5 : 1 }}>
                  Enregistrer la librairie
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
