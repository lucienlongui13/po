'use client'

/**
 * replay-bar.tsx — TradingView-style bar replay transport controls.
 *
 * Play / pause / step / scrub / speed / exit, with a progress slider
 * positioned above the chart's bottom edge.
 */

import { useEffect, useState } from 'react'
import { Play, Pause, SkipBack, SkipForward, X, Rewind } from 'lucide-react'

import { REPLAY_SPEEDS, type ReplayEngine, type ReplayState } from '@/lib/replay-engine'

interface ReplayBarProps {
  replay: ReplayEngine
  dark: boolean
  onExit: () => void
}

export function ReplayBar({ replay, dark, onExit }: ReplayBarProps) {
  const [state, setState] = useState<ReplayState>(() => replay.getState())

  useEffect(() => {
    const unsub = replay.onState((s) => setState({ ...s }))
    const t = setTimeout(() => setState({ ...replay.getState() }), 0)
    return () => { clearTimeout(t); unsub() }
  }, [replay])

  const border = dark ? '#2A2E39' : '#E0E3EB'
  const bg = dark ? '#1E222D' : '#FFFFFF'
  const text = dark ? '#D1D4DC' : '#131722'
  const sub = '#787B86'

  const span = Math.max(1, state.total - 1 - state.startIdx)
  const progress = ((state.cursor - state.startIdx) / span) * 100

  const timeStr = state.currentTime > 0
    ? new Date(state.currentTime * 1000).toLocaleString([], {
        month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit',
      })
    : '—'

  return (
    <div
      className="flex items-center gap-2 px-3 py-1.5 border-t text-[11px] shrink-0"
      style={{ background: bg, borderColor: border, color: text }}
    >
      <span className="font-semibold px-1.5 py-0.5 rounded text-[10px]" style={{ background: '#2962FF', color: '#fff' }}>
        REPLAY
      </span>

      <button
        title="Back to start"
        onClick={() => replay.seek(state.startIdx)}
        className="p-1.5 rounded hover:bg-black/10"
      >
        <Rewind className="h-3.5 w-3.5" />
      </button>
      <button
        title="Step back"
        onClick={() => replay.stepBack()}
        className="p-1.5 rounded hover:bg-black/10"
      >
        <SkipBack className="h-3.5 w-3.5" />
      </button>
      <button
        title={state.playing ? 'Pause' : 'Play'}
        onClick={() => replay.toggle()}
        className="p-1.5 rounded hover:bg-black/10"
        style={{ color: '#2962FF' }}
      >
        {state.playing
          ? <Pause className="h-4 w-4" />
          : <Play className="h-4 w-4" />}
      </button>
      <button
        title="Step forward"
        onClick={() => replay.stepForward()}
        className="p-1.5 rounded hover:bg-black/10"
      >
        <SkipForward className="h-3.5 w-3.5" />
      </button>

      {/* speed selector */}
      <select
        value={state.speedMs}
        onChange={(e) => replay.setSpeed(Number(e.target.value))}
        className="px-1.5 py-1 rounded border bg-transparent text-[11px] outline-none"
        style={{ borderColor: border, color: text }}
      >
        {REPLAY_SPEEDS.map((s) => (
          <option key={s.label} value={s.ms} style={{ color: text, background: bg }}>
            {s.label}
          </option>
        ))}
      </select>

      {/* progress slider */}
      <div className="flex-1 flex items-center gap-2 min-w-[120px]">
        <input
          type="range"
          min={state.startIdx}
          max={state.total - 1}
          value={state.cursor}
          onChange={(e) => replay.seek(Number(e.target.value))}
          className="flex-1 h-1 accent-[#2962FF] cursor-pointer"
          style={{ accentColor: '#2962FF' }}
        />
        <span className="tabular-nums whitespace-nowrap" style={{ color: sub }}>
          {progress.toFixed(0)}%
        </span>
      </div>

      <span className="tabular-nums whitespace-nowrap hidden md:inline" style={{ color: sub }}>
        {timeStr}
      </span>
      <span className="tabular-nums whitespace-nowrap" style={{ color: sub }}>
        {state.cursor - state.startIdx + 1}/{span + 1} bars
      </span>

      <button
        title="Exit replay"
        onClick={onExit}
        className="flex items-center gap-1 px-2 py-1 rounded hover:bg-black/10"
        style={{ color: '#F23645' }}
      >
        <X className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">Exit</span>
      </button>
    </div>
  )
}
