'use client'

/**
 * signal-display-fields.tsx — Section « Tags & labels » du panneau Auto
 * Trade : SWITCH MASTER + filtres de visibilité + presets + tailles
 * (§22/§23/§24/§29).
 * ====================================================================
 * GROUPES REPLIABLES (§23) : STRUCTURE (BOS/CHoCH/CISD), IMBALANCE,
 * BLOCKS, SWINGS, LIQUIDITY, DRT, PO3, SMT, AMD, CANDLE PATTERNS (les
 * 73 patterns individuellement masquables + masters bullish/bearish/
 * neutral). Les signaux non détectés par le moteur actuel apparaissent
 * GRISÉS (classification complète §5/§6 — ils s'activeront avec leur
 * moteur).
 *
 * PRESETS (§24) : Show All / Hide All / Minimal / Balanced / Full /
 * Structure Only / ICT Only / Candle Only / Swings Only / Liquidity Only
 * — ils ne modifient QUE l'affichage.
 *
 * TAILLES (§29) : Small / Normal / Large (défaut) / Huge.
 *
 * EXIGENCE ABSOLUE (§33) : un signal masqué reste détecté et utilisable
 * par Auto Trade / Strategy Tester — ces filtres sont PUREMENT visuels.
 */

import { useEffect, useState } from 'react'
import { TrendingUp, TrendingDown } from 'lucide-react'
import {
  SIGNAL_REGISTRY,
  SIGNAL_CATEGORY_ORDER,
  SIGNAL_CATEGORY_LABELS,
  SIGNAL_DISPLAY_PRESETS,
  type SignalCategory,
  type SignalDisplayFilters,
  type SignalDisplayPreset,
} from '../../../../shared/signal-registry'
import {
  loadSignalDisplayFilters,
  saveSignalDisplayFilters,
  saveSignalDisplayPreset,
  subscribeSignalDisplayFilters,
} from '@/lib/signal-display-settings'

const PRESET_LABELS: Record<SignalDisplayPreset, string> = {
  show_all: 'Show All',
  hide_all: 'Hide All',
  minimal: 'Minimal',
  balanced: 'Balanced',
  full: 'Full',
  structure_only: 'Structure Only',
  ict_only: 'ICT Only',
  candle_only: 'Candle Only',
  swings_only: 'Swings Only',
  liquidity_only: 'Liquidity Only',
}

const SIZE_OPTIONS: Array<{ key: SignalDisplayFilters['labelSize']; px: number }> = [
  { key: 'Small', px: 9 },
  { key: 'Normal', px: 11 },
  { key: 'Large', px: 14 },
  { key: 'Huge', px: 18 },
]

export function SignalDisplayFields({ disabled }: { disabled?: boolean }) {
  const [filters, setFilters] = useState<SignalDisplayFilters>(() => loadSignalDisplayFilters())
  const [openGroups, setOpenGroups] = useState<Set<SignalCategory>>(new Set(['STRUCTURE', 'CANDLE']))
  const [showFilters, setShowFilters] = useState(false)

  useEffect(() => subscribeSignalDisplayFilters(setFilters), [])

  const toggleGroupOpen = (cat: SignalCategory) => {
    setOpenGroups((prev) => {
      const next = new Set(prev)
      if (next.has(cat)) next.delete(cat)
      else next.add(cat)
      return next
    })
  }
  const setMaster = (on: boolean) => saveSignalDisplayFilters({ showLabels: on })
  const setGroupVisible = (cat: SignalCategory, on: boolean) => {
    saveSignalDisplayFilters({ groups: { ...filters.groups, [cat]: on } })
  }
  const setSignalVisible = (id: string, on: boolean) => {
    saveSignalDisplayFilters({ signals: { ...filters.signals, [id]: on } })
  }
  const setCandleMaster = (dir: 'bullish' | 'bearish' | 'neutral', on: boolean) => {
    saveSignalDisplayFilters({ candleMasters: { ...filters.candleMasters, [dir]: on } })
  }
  const applyPreset = (p: SignalDisplayPreset) => saveSignalDisplayPreset(p)

  return (
    <div className="rounded-lg border border-zinc-200 dark:border-zinc-800 p-2 space-y-2">
      {/* SWITCH MASTER (§22) — OFF : AUCUN tag visuel. */}
      <div className="flex items-center justify-between">
        <div className="pr-2">
          <div className="text-[9px] font-semibold text-zinc-700 dark:text-zinc-200">Tags &amp; labels sur le graphique</div>
          <div className="text-[8px] text-zinc-500 leading-snug">
            Switch MASTER : OFF = aucun tag visuel (BOS/CHoCH/CISD + les 73 patterns candle). ON = sélectionnez ce qui est visible ci-dessous. <b>Masquer un signal ne l’empêche pas d’être détecté ni utilisé par Auto Trade / Strategy Tester.</b>
          </div>
        </div>
        <button
          type="button"
          role="switch"
          aria-checked={filters.showLabels}
          aria-label="Afficher les tags et libellés des signaux sur le graphique"
          disabled={disabled}
          onClick={() => setMaster(!filters.showLabels)}
          title={filters.showLabels ? 'Tags et libellés affichés — cliquer pour tout masquer' : 'Tags et libellés masqués — cliquer pour afficher'}
          className="relative shrink-0 w-12 h-6 rounded-full transition-colors disabled:opacity-50"
          style={{ background: filters.showLabels ? '#089981' : '#71717a' }}
        >
          <span
            className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all flex items-center justify-center"
            style={{ left: filters.showLabels ? '26px' : '2px' }}
          >
            {filters.showLabels
              ? <TrendingUp className="h-2.5 w-2.5" style={{ color: '#089981' }} />
              : <TrendingDown className="h-2.5 w-2.5 text-zinc-400" />}
          </span>
        </button>
      </div>

      {/* TAILLE DES LABELS (§29) — défaut Large. */}
      <div className="flex items-center gap-1.5">
        <label className="text-[8px] text-zinc-500 shrink-0 font-semibold">Label Size</label>
        <div className="flex gap-0.5">
          {SIZE_OPTIONS.map((s) => (
            <button key={s.key} type="button" disabled={disabled} onClick={() => saveSignalDisplayFilters({ labelSize: s.key })}
              className={'px-1.5 py-0.5 rounded border text-[8px] font-semibold ' + (filters.labelSize === s.key
                ? 'border-emerald-500 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                : 'border-zinc-200 dark:border-zinc-800 text-zinc-500')}
              style={{ fontSize: `${Math.min(9, s.px * 0.55)}px` }}
              title={`Taille des labels = ${s.key} (défaut : Large)`}
            >{s.key}</button>
          ))}
        </div>
      </div>

      {/* PRESETS (§24) — affichage seul. */}
      <div className="flex flex-wrap gap-0.5">
        {SIGNAL_DISPLAY_PRESETS.map((p) => (
          <button key={p} type="button" disabled={disabled} onClick={() => applyPreset(p)}
            className="px-1.5 py-0.5 rounded-full border border-zinc-200 dark:border-zinc-800 text-[8px] text-zinc-500 hover:border-blue-400 hover:text-blue-500"
            title={`Preset d'affichage : ${PRESET_LABELS[p]} — ne modifie QUE l'affichage, jamais la détection ni les règles`}
          >{PRESET_LABELS[p]}</button>
        ))}
      </div>

      {/* Ouverture des filtres détaillés. */}
      <button
        type="button"
        disabled={disabled}
        onClick={() => setShowFilters(!showFilters)}
        className="w-full rounded-md border border-zinc-200 dark:border-zinc-800 px-2 py-1 text-[8px] font-semibold text-zinc-500 hover:border-blue-400"
      >
        {showFilters ? '▼ Masquer les filtres de visibilité' : '▶ Filtres de visibilité (groupes + 73 patterns)'}
      </button>

      {showFilters && (
        <div className="space-y-1.5 max-h-[420px] overflow-y-auto pr-0.5">
          {SIGNAL_CATEGORY_ORDER.map((cat) => {
            const entries = SIGNAL_REGISTRY.filter((s) => s.category === cat)
            const groupOn = filters.groups[cat] !== false
            const isCandleCat = cat === 'CANDLE'
            const open = openGroups.has(cat)
            return (
              <div key={cat} className="rounded-md border border-zinc-200 dark:border-zinc-800 overflow-hidden">
                <div className="flex items-center gap-1 px-1.5 py-1 bg-zinc-50 dark:bg-zinc-900/60">
                  <button type="button" disabled={disabled} onClick={() => setGroupVisible(cat, !groupOn)}
                    aria-pressed={groupOn}
                    title={groupOn ? `Groupe ${SIGNAL_CATEGORY_LABELS[cat]} VISIBLE — cliquer pour masquer tout le groupe` : `Groupe ${SIGNAL_CATEGORY_LABELS[cat]} MASQUÉ — cliquer pour afficher le groupe`}
                    className={'shrink-0 w-4 h-4 rounded border flex items-center justify-center text-[9px] ' + (groupOn
                      ? 'border-emerald-500 bg-emerald-500/10 text-emerald-600'
                      : 'border-zinc-300 dark:border-zinc-700 text-zinc-400')}
                  >{groupOn ? '✓' : ''}</button>
                  <button type="button" onClick={() => toggleGroupOpen(cat)} className="flex-1 text-left text-[8px] font-semibold text-zinc-600 dark:text-zinc-300 truncate">
                    {SIGNAL_CATEGORY_LABELS[cat]}
                    <span className="text-zinc-400 font-normal"> ({entries.filter((e) => e.available).length}/{entries.length})</span>
                  </button>
                  <button type="button" onClick={() => toggleGroupOpen(cat)} className="text-[8px] text-zinc-400 px-1">{open ? '▼' : '▶'}</button>
                </div>
                {open && (
                  <div className="p-1.5 space-y-1 border-t border-zinc-200 dark:border-zinc-800">
                    {isCandleCat && (
                      /* Masters bullish/bearish/neutral (§23). */
                      <div className="flex items-center gap-1 pb-1 border-b border-zinc-200 dark:border-zinc-800">
                        <span className="text-[8px] text-zinc-500 font-semibold mr-0.5">MASTER :</span>
                        {(['bullish', 'bearish', 'neutral'] as const).map((dir) => {
                          const on = filters.candleMasters[dir]
                          return (
                            <button key={dir} type="button" disabled={disabled} onClick={() => setCandleMaster(dir, !on)}
                              aria-pressed={on}
                              title={`Tous les patterns ${dir} ${on ? 'visibles' : 'masqués'} — cliquer pour ${on ? 'masquer' : 'afficher'}`}
                              className={'px-1.5 py-0.5 rounded-full border text-[8px] font-semibold ' + (on
                                ? dir === 'bullish' ? 'border-emerald-500 bg-emerald-500/10 text-emerald-600' : dir === 'bearish' ? 'border-red-500 bg-red-500/10 text-red-600' : 'border-slate-500 bg-slate-500/10 text-slate-600'
                                : 'border-zinc-200 dark:border-zinc-800 text-zinc-400')}
                            >{dir === 'bullish' ? 'Bullish' : dir === 'bearish' ? 'Bearish' : 'Neutral'}</button>
                          )
                        })}
                      </div>
                    )}
                    <div className={cat === 'CANDLE' ? 'grid grid-cols-2 gap-0.5' : 'flex flex-wrap gap-0.5'}>
                      {entries.map((e) => {
                        const own = filters.signals[e.id]
                        const visible = typeof own === 'boolean' ? own : e.displayDefault
                        return (
                          <button key={e.id} type="button" disabled={disabled || !e.available}
                            onClick={() => setSignalVisible(e.id, !visible)}
                            aria-pressed={visible}
                            title={e.available
                              ? `${e.label} — ${visible ? 'visible' : 'masqué'} — masquer n'affecte QUE l'affichage (le signal reste détecté et utilisable dans les règles)`
                              : `${e.label} — signal classé mais NON détecté par le moteur actuel (s'activera avec son moteur)`}
                            className={'px-1.5 py-0.5 rounded border text-[8px] text-left truncate ' + (!e.available
                              ? 'border-zinc-200 dark:border-zinc-800 text-zinc-300 dark:text-zinc-700 cursor-not-allowed'
                              : visible
                                ? 'border-blue-500/50 bg-blue-500/10 text-blue-600 dark:text-blue-400'
                                : 'border-zinc-200 dark:border-zinc-800 text-zinc-400')}
                          >{visible ? '✓ ' : '○ '}{e.label}</button>
                        )
                      })}
                    </div>
                    {isCandleCat && (
                      <div className="text-[8px] text-zinc-400 leading-snug pt-1 border-t border-zinc-200 dark:border-zinc-800">
                        Masquer un pattern = uniquement masquer le VISUEL. La détection continue — un pattern masqué reste utilisable dans Auto Trade / Strategy Tester.
                      </div>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
