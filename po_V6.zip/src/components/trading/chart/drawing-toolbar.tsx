'use client'

import { useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import {
  ArrowUpRight,
  Brush,
  Crosshair,
  EyeOff,
  Grid2X2,
  Lock,
  LockOpen,
  Magnet,
  Minus,
  Slash,
  Square,
  Trash2,
} from 'lucide-react'
import {
  DrawingManager,
  type DrawingTool,
  DEFAULT_DRAWING_WIDTH,
  MAX_DRAWING_WIDTH,
  MIN_DRAWING_WIDTH,
} from '@/lib/drawings'

interface DrawingToolbarProps {
  manager: DrawingManager
  dark: boolean
}

interface ToolButton {
  tool: DrawingTool
  label: string
  icon: ReactNode
}

// Deliberately compact: keep only the practical chart tools requested by the user.
const TOOLS: ToolButton[] = [
  { tool: 'cursor', label: 'Cursor / Select', icon: <Crosshair className="h-[18px] w-[18px]" /> },
  { tool: 'trend-line', label: 'Trend Line', icon: <Slash className="h-[18px] w-[18px]" /> },
  { tool: 'horizontal-line', label: 'Horizontal Line (finite)', icon: <Minus className="h-[18px] w-[18px]" /> },
  { tool: 'vertical-line', label: 'Vertical Line (finite)', icon: <Minus className="h-[18px] w-[18px] rotate-90" /> },
  { tool: 'fib-retracement', label: 'Fibonacci Retracement', icon: <Grid2X2 className="h-[18px] w-[18px]" /> },
  { tool: 'rectangle', label: 'Rectangle', icon: <Square className="h-[18px] w-[18px]" /> },
  { tool: 'brush', label: 'Freehand / Brush', icon: <Brush className="h-[18px] w-[18px]" /> },
  { tool: 'arrow', label: 'Arrow', icon: <ArrowUpRight className="h-[18px] w-[18px]" /> },
]

export function DrawingToolbar({ manager, dark }: DrawingToolbarProps) {
  const [, setVersion] = useState(0)

  useEffect(() => manager.subscribe(() => setVersion((v) => v + 1)), [manager])

  const border = dark ? '#2A2E39' : '#E0E3EB'
  const hover = dark ? '#2A2E39' : '#F0F3FA'
  const muted = dark ? '#9CA3AF' : '#6B7280'
  const foreground = dark ? '#B2B5BE' : '#131722'
  const style = manager.activeStyle

  const button = (b: ToolButton) => (
    <button
      key={b.tool}
      type="button"
      title={b.label}
      aria-label={b.label}
      onClick={() =>
        manager.setTool(
          manager.activeTool === b.tool && b.tool !== 'cursor' ? 'cursor' : b.tool,
        )
      }
      className="w-10 h-10 flex items-center justify-center rounded-md"
      style={{
        color: manager.activeTool === b.tool ? '#fff' : foreground,
        background: manager.activeTool === b.tool ? '#2962FF' : 'transparent',
      }}
      onMouseEnter={(e) => {
        if (manager.activeTool !== b.tool) e.currentTarget.style.background = hover
      }}
      onMouseLeave={(e) => {
        if (manager.activeTool !== b.tool) e.currentTarget.style.background = 'transparent'
      }}
    >
      {b.icon}
    </button>
  )

  const toggle = (
    key: string,
    label: string,
    active: boolean,
    icon: ReactNode,
    fn: () => void,
  ) => (
    <button
      key={key}
      type="button"
      title={label}
      aria-label={label}
      onClick={fn}
      className="w-10 h-10 flex items-center justify-center rounded-md"
      style={{ color: active ? '#2962FF' : foreground }}
    >
      {icon}
    </button>
  )

  return (
    <div
      className="flex flex-col items-center gap-0.5 py-1.5 shrink-0 border-r overflow-y-auto"
      style={{ width: 66, background: dark ? '#131722' : '#FFF', borderColor: border }}
    >
      <div
        className="flex flex-col items-center gap-0.5 pb-1.5 mb-1 border-b w-full"
        style={{ borderColor: border }}
      >
        {TOOLS.map(button)}
      </div>

      <div className="w-full px-1.5 py-2 border-b" style={{ borderColor: border }}>
        <div
          className="text-[8px] font-bold uppercase tracking-wide mb-1 text-center"
          style={{ color: muted }}
        >
          Style
        </div>

        <label
          className="flex flex-col items-center gap-1 text-[8px]"
          style={{ color: muted }}
        >
          <span>Thickness</span>
          <input
            aria-label="Drawing thickness"
            type="range"
            min={MIN_DRAWING_WIDTH}
            max={MAX_DRAWING_WIDTH}
            step="1"
            value={style.width || DEFAULT_DRAWING_WIDTH}
            onChange={(e) => manager.updateSelectedStyle({ width: Number(e.target.value) })}
            className="w-full"
          />
          <span className="font-mono">{style.width}px</span>
        </label>

        <label
          className="mt-1.5 flex items-center justify-between gap-1 text-[8px]"
          style={{ color: muted }}
        >
          <span>Couleur</span>
          <input
            aria-label="Drawing color"
            type="color"
            value={style.color}
            onChange={(e) => manager.updateSelectedStyle({ color: e.target.value })}
            className="h-6 w-8 p-0 border-0 bg-transparent"
          />
        </label>
      </div>

      <div className="flex flex-col items-center gap-0.5 w-full">
        {toggle(
          'magnet',
          'Magnet',
          manager.magnet,
          <Magnet className="h-[18px] w-[18px]" />,
          () => manager.toggleMagnet(),
        )}
        {toggle(
          'lock',
          'Lock all',
          manager.lockAll,
          manager.lockAll ? (
            <Lock className="h-[18px] w-[18px]" />
          ) : (
            <LockOpen className="h-[18px] w-[18px]" />
          ),
          () => manager.toggleLockAll(),
        )}
        {toggle(
          'hide',
          'Hide all',
          manager.hideAll,
          <EyeOff className="h-[18px] w-[18px]" />,
          () => manager.toggleHideAll(),
        )}
        {toggle(
          'trash',
          'Remove selected/all',
          false,
          <Trash2 className="h-[18px] w-[18px]" />,
          () => (manager.selectedId ? manager.deleteSelected() : manager.deleteAll()),
        )}
      </div>
    </div>
  )
}
