'use client'

/**
 * sub-pane.tsx — synchronized oscillator pane (TradingView-style).
 *
 * One lightweight-charts instance per separate-pane indicator (RSI, MACD,
 * Stoch…). The parent chart-workspace orchestrates:
 *   - time-scale sync (logical range pushed main↔subs)
 *   - crosshair sync (setCrosshairPosition across panes)
 *   - data pushes (full setData on history/reset, tail update on ticks)
 *
 * Legend shows the indicator title, live values at the crosshair and
 * controls (visibility, settings, remove) — exactly like TradingView.
 */

import {
  forwardRef, useEffect, useImperativeHandle, useRef, useState,
} from 'react'
import {
  createChart, LineStyle,
  type IChartApi, type ISeriesApi, type LogicalRange, type Time,
  type LineData, type HistogramData, type IPriceLine,
} from 'lightweight-charts'
import { X, Settings2, Eye, EyeOff } from 'lucide-react'

import type { CandleLike } from '@/lib/indicators'
import {
  INDICATOR_MAP, indicatorTitle, formatIndicatorValue,
  type IndicatorPlot,
} from '@/lib/indicators-library'
import type { IndicatorInstance, IndicatorPlotSettings } from '@/lib/tv-store'
import { baseChartOptions, themeFor } from './chart-theme'

export interface SubPaneHandle {
  uid: string
  setData(candles: CandleLike[]): void
  updateTail(candles: CandleLike[]): void
  applyRange(from: number, to: number): void
  getRange(): LogicalRange | null
  crosshairAt(logical: number | null, time: number | null): void
  applyTheme(dark: boolean): void
  refreshSeries(): void
}

interface SubPaneProps {
  instance: IndicatorInstance
  dark: boolean
  showTimeAxis: boolean
  onRemove: (uid: string) => void
  onToggleVisible: (uid: string) => void
  onParams: (uid: string, params: Record<string, number>) => void
  onPlotSettings: (uid: string, settings: Record<string, IndicatorPlotSettings>) => void
  onRangeChange: (uid: string, range: LogicalRange) => void
  onCrosshair: (uid: string, logical: number | null, time: number | null) => void
  registerHandle: (uid: string, handle: SubPaneHandle | null) => void
}

const PANE_HEIGHT = 128

function timeForTarget(candles: CandleLike[], targetIdx: number): number | null {
  const n = candles.length
  if (n === 0) return null
  const last = candles[n - 1]
  if (targetIdx < 0) return null
  if (targetIdx < n) return candles[targetIdx].time
  const tf = n > 1 ? candles[1].time - candles[0].time : 60
  return last.time + (targetIdx - (n - 1)) * Math.max(1, tf)
}

export const SubPane = forwardRef<SubPaneHandle, SubPaneProps>(function SubPane({
  instance, dark, showTimeAxis,
  onRemove, onToggleVisible, onParams, onPlotSettings, onRangeChange, onCrosshair, registerHandle,
}, _ref) {
  const containerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const seriesMapRef = useRef<Map<string, ISeriesApi<'Line'> | ISeriesApi<'Histogram'>>>(new Map())
  const priceLinesRef = useRef<IPriceLine[]>([])
  const valueSpansRef = useRef<Map<string, HTMLSpanElement | null>>(new Map())
  const applyingRangeRef = useRef(false)
  const lastCandlesRef = useRef<CandleLike[]>([])
  const crosshairSeriesRef = useRef<ISeriesApi<'Line'> | ISeriesApi<'Histogram'> | null>(null)

  const def = INDICATOR_MAP.get(instance.defId)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [draftParams, setDraftParams] = useState<Record<string, number>>(instance.params)
  const [draftPlotSettings, setDraftPlotSettings] = useState<Record<string, IndicatorPlotSettings>>(instance.plotSettings ?? {})

  // keep draft params in sync when the instance params change (deferred)
  useEffect(() => {
    const t = setTimeout(() => { setDraftParams(instance.params); setDraftPlotSettings(instance.plotSettings ?? {}) }, 0)
    return () => clearTimeout(t)
  }, [instance.params])

  // ── chart creation (once) ─────────────────────────────────────
  useEffect(() => {
    if (!containerRef.current) return
    const theme = themeFor(dark)
    const options: any = {
      ...baseChartOptions(theme),
      width: containerRef.current.clientWidth,
      height: containerRef.current.clientHeight,
      timeScale: {
        ...baseChartOptions(theme).timeScale,
        visible: showTimeAxis,
        rightOffset: 4,
        minBarSpacing: 4,
        barSpacing: 12,
        shiftVisibleRangeOnNewBar: false,
        fixLeftEdge: false,
      },
      rightPriceScale: {
        ...baseChartOptions(theme).rightPriceScale,
        scaleMargins: { top: 0.15, bottom: 0.1 },
      },
      crosshair: {
        ...baseChartOptions(theme).crosshair,
        mode: 0, // Normal
      },
    }
    const chart = createChart(containerRef.current, options)
    chartRef.current = chart

    const ro = new ResizeObserver(() => {
      if (containerRef.current && chartRef.current) {
        chartRef.current.applyOptions({
          width: containerRef.current.clientWidth,
          height: containerRef.current.clientHeight,
        })
      }
    })
    ro.observe(containerRef.current)

    const rangeHandler = (range: LogicalRange | null) => {
      if (applyingRangeRef.current || !range) return
      onRangeChange(instance.uid, range)
    }
    chart.timeScale().subscribeVisibleLogicalRangeChange(rangeHandler)

    const crossHandler = (param: any) => {
      if (param.time != null && param.logical != null) {
        onCrosshair(instance.uid, param.logical as number, param.time as number)
      } else {
        onCrosshair(instance.uid, null, null)
      }
    }
    chart.subscribeCrosshairMove(crossHandler)

    return () => {
      ro.disconnect()
      chart.remove()
      chartRef.current = null
      seriesMapRef.current.clear()
      priceLinesRef.current = []
    }
  }, [])

  // time axis visibility depends on position (bottom pane only)
  useEffect(() => {
    chartRef.current?.applyOptions({ timeScale: { visible: showTimeAxis } } as any)
  }, [showTimeAxis])

  // ── series (re)creation on instance change ────────────────────
  const rebuildSeries = () => {
    const chart = chartRef.current
    if (!chart || !def) return
    for (const s of seriesMapRef.current.values()) {
      try { chart.removeSeries(s) } catch { /* noop */ }
    }
    seriesMapRef.current.clear()
    for (const pl of priceLinesRef.current) {
      try { (crosshairSeriesRef.current as any)?.removePriceLine(pl) } catch { /* noop */ }
    }
    priceLinesRef.current = []

    let first = true
    for (const plot of def.plots) {
      const cfg = instance.plotSettings?.[plot.key] ?? { visible: true, color: plot.color }
      if (!cfg.visible) continue
      if (plot.type === 'histogram') {
        const s = chart.addHistogramSeries({
          color: cfg.color,
          base: 0,
          priceLineVisible: false,
          lastValueVisible: false,
        })
        seriesMapRef.current.set(plot.key, s)
      } else {
        const s = chart.addLineSeries({
          color: cfg.color,
          lineWidth: (plot.lineWidth ?? 1) as 1 | 2 | 3 | 4,
          lineStyle: plot.dashed ? LineStyle.Dashed : LineStyle.Solid,
          priceLineVisible: false,
          lastValueVisible: false,
          crosshairMarkerVisible: false,
        })
        seriesMapRef.current.set(plot.key, s)
        if (first) crosshairSeriesRef.current = s
      }
      first = false
    }
    // reference levels (RSI 30/70 …) on the first line series
    const anchor = crosshairSeriesRef.current
    if (anchor && def.levels) {
      for (const lvl of def.levels) {
        priceLinesRef.current.push(anchor.createPriceLine({
          price: lvl.value,
          color: lvl.color,
          lineStyle: lvl.dashed ? LineStyle.Dashed : LineStyle.Solid,
          lineVisible: true,
          axisLabelVisible: false,
          title: '',
        }))
      }
    }
  }

  // ── data rendering ─────────────────────────────────────────────
  const renderData = (candles: CandleLike[], mode: 'full' | 'tail') => {
    const chart = chartRef.current
    if (!chart || !def) return
    lastCandlesRef.current = candles
    if (seriesMapRef.current.size === 0) rebuildSeries()
    if (seriesMapRef.current.size === 0) return

    if (!instance.visible) {
      if (mode === 'full') {
        for (const s of seriesMapRef.current.values()) s.setData([])
      }
      return
    }

    let computed: Record<string, (number | null)[]>
    try {
      computed = def.compute(candles, instance.params)
    } catch { return }

    const n = candles.length
    const tf = n > 1 ? candles[1].time - candles[0].time : 60

    for (const plot of def.plots) {
      const series = seriesMapRef.current.get(plot.key)
      const arr = computed[plot.key]
      if (!series || !arr) continue

      if (mode === 'full') {
        const data: (LineData | HistogramData)[] = []
        for (let i = 0; i < n; i++) {
          const v = arr[i]
          if (v == null || !Number.isFinite(v)) continue
          const t = plot.displacement
            ? timeForTarget(candles, i + plot.displacement)
            : candles[i].time
          if (t == null) continue
          if (plot.type === 'histogram') {
            data.push({ time: t as Time, value: v, color: histColor(plot, v, arr, i) })
          } else {
            data.push({ time: t as Time, value: v })
          }
        }
        try { series.setData(data as any) } catch { /* noop */ }
      } else {
        // tail: update the last two points (previous final + current)
        for (let k = Math.max(0, n - 2); k < n; k++) {
          const v = arr[k]
          if (v == null || !Number.isFinite(v)) continue
          const t = plot.displacement
            ? timeForTarget(candles, k + plot.displacement)
            : candles[k].time
          if (t == null) continue
          try {
            if (plot.type === 'histogram') {
              (series as ISeriesApi<'Histogram'>).update({ time: t as Time, value: v, color: histColor(plot, v, arr, k) })
            } else {
              (series as ISeriesApi<'Line'>).update({ time: t as Time, value: v })
            }
          } catch { /* noop */ }
        }
      }
    }
    void tf
    updateLegendFromIndex(null)
  }

  const histColor = (plot: IndicatorPlot, v: number, arr: (number | null)[], i: number): string => {
    if (plot.histMode === 'sign') return v >= 0 ? plot.color : (plot.color2 ?? plot.color)
    if (plot.histMode === 'direction') {
      const prev = arr[i - 1]
      if (prev == null) return v >= 0 ? plot.color : (plot.color2 ?? plot.color)
      return v >= prev ? plot.color : (plot.color2 ?? plot.color)
    }
    return plot.color
  }

  // ── legend value updates (imperative — no React re-render) ────
  const updateLegendFromIndex = (logical: number | null) => {
    const candles = lastCandlesRef.current
    const idx = logical == null ? candles.length - 1 : Math.round(logical)
    if (!def || idx < 0 || idx >= candles.length) {
      for (const plot of def?.plots ?? []) {
        const span = valueSpansRef.current.get(plot.key)
        if (span) span.textContent = ''
      }
      return
    }
    let computed: Record<string, (number | null)[]>
    try {
      computed = def.compute(candles, instance.params)
    } catch { return }
    for (const plot of def.plots) {
      const span = valueSpansRef.current.get(plot.key)
      if (!span) continue
      const v = computed[plot.key]?.[idx]
      span.textContent = v == null ? '' : formatIndicatorValue(v)
    }
  }

  // ── imperative handle ──────────────────────────────────────────
  const handleRef = useRef<SubPaneHandle | null>(null)
  useImperativeHandle(_ref, () => {
    const handle: SubPaneHandle = {
    uid: instance.uid,
    setData: (candles: CandleLike[]) => renderData(candles, 'full'),
    updateTail: (candles: CandleLike[]) => renderData(candles, 'tail'),
    applyRange: (from: number, to: number) => {
      const chart = chartRef.current
      if (!chart) return
      applyingRangeRef.current = true
      try {
        chart.timeScale().setVisibleLogicalRange({ from, to })
      } catch { /* noop */ }
      // release on next tick (LWC emits the change synchronously)
      setTimeout(() => { applyingRangeRef.current = false }, 0)
    },
    getRange: () => chartRef.current?.timeScale().getVisibleLogicalRange() ?? null,
    crosshairAt: (logical: number | null, time: number | null) => {
      const chart = chartRef.current
      const candles = lastCandlesRef.current
      if (!chart || !def) return
      updateLegendFromIndex(logical)
      const series = crosshairSeriesRef.current
      if (!series) return
      if (logical == null || time == null) {
        try { chart.clearCrosshairPosition() } catch { /* noop */ }
        return
      }
      // value of the FIRST plot at that logical index
      let computed: Record<string, (number | null)[]> | null = null
      try { computed = def.compute(candles, instance.params) } catch { /* noop */ }
      const firstPlot = def.plots.find((p) => p.type === 'line') ?? def.plots[0]
      const v = computed?.[firstPlot.key]?.[Math.round(logical)]
      if (v == null) {
        try { chart.clearCrosshairPosition() } catch { /* noop */ }
        return
      }
      try { chart.setCrosshairPosition(v, time as Time, series) } catch { /* noop */ }
    },
    applyTheme: (isDark: boolean) => {
      chartRef.current?.applyOptions({
        layout: { ...baseChartOptions(themeFor(isDark)).layout },
        grid: { ...baseChartOptions(themeFor(isDark)).grid },
        rightPriceScale: { borderColor: themeFor(isDark).border },
        timeScale: { borderColor: themeFor(isDark).border },
      } as any)
    },
    refreshSeries: () => {
      rebuildSeries()
      renderData(lastCandlesRef.current, 'full')
    },
    }
    handleRef.current = handle
    return handle
  }, [instance, def])

  // register with parent (keep latest handle identity)
  useEffect(() => {
    const timer = setTimeout(() => {
      if (handleRef.current) registerHandle(instance.uid, handleRef.current)
    }, 0)
    return () => {
      clearTimeout(timer)
      registerHandle(instance.uid, null)
    }
  }, [instance, def, registerHandle])

  // rebuild + full render whenever instance identity / params / visibility change
  useEffect(() => {
    rebuildSeries()
    if (lastCandlesRef.current.length > 0) {
      renderData(lastCandlesRef.current, 'full')
    }
     
  }, [instance.uid, instance.defId, instance.params, instance.visible])

  if (!def) return null

  const title = indicatorTitle(def, instance.params)

  return (
    <div
      className="relative border-t"
      style={{ height: PANE_HEIGHT, borderColor: dark ? '#2A2E39' : '#E0E3EB' }}
    >
      <div ref={containerRef} className="absolute inset-0" />

      {/* Legend */}
      <div className="absolute top-1 left-2 z-10 flex items-center gap-2 text-[11px] select-none">
        <span className="font-semibold" style={{ color: dark ? '#D1D4DC' : '#131722' }}>
          {title}
        </span>
        {def.plots.map((plot) => (
          <span key={plot.key} className="flex items-center gap-1">
            <span className="inline-block w-2 h-2 rounded-full" style={{ background: instance.plotSettings?.[plot.key]?.color ?? plot.color }} />
            <span
              ref={(el) => { valueSpansRef.current.set(plot.key, el) }}
              style={{ color: instance.plotSettings?.[plot.key]?.color ?? plot.color }}
              className="tabular-nums"
            />
          </span>
        ))}
        <span className="flex items-center gap-0.5 ml-1">
          <button
            onClick={() => onToggleVisible(instance.uid)}
            title={instance.visible ? 'Hide' : 'Show'}
            className="p-1 rounded hover:bg-black/10 dark:hover:bg-white/10"
          >
            {instance.visible
              ? <Eye className="h-3 w-3 opacity-60" />
              : <EyeOff className="h-3 w-3 opacity-40" />}
          </button>
          <button
            onClick={() => setSettingsOpen((v) => !v)}
            title="Settings"
            className="p-1 rounded hover:bg-black/10 dark:hover:bg-white/10"
          >
            <Settings2 className="h-3 w-3 opacity-60" />
          </button>
          <button
            onClick={() => onRemove(instance.uid)}
            title="Remove indicator"
            className="p-1 rounded hover:bg-black/10 dark:hover:bg-white/10"
          >
            <X className="h-3 w-3 opacity-60" />
          </button>
        </span>
      </div>

      {/* Settings popover */}
      {settingsOpen && (
        <div
          className="absolute top-7 left-2 z-20 rounded-md border p-3 w-56 shadow-lg"
          style={{
            background: dark ? '#1E222D' : '#FFFFFF',
            borderColor: dark ? '#2A2E39' : '#E0E3EB',
          }}
        >
          <div className="text-[11px] font-semibold mb-2" style={{ color: dark ? '#D1D4DC' : '#131722' }}>
            {def.name}
          </div>
          {def.params.length === 0 && (
            <div className="text-[11px] opacity-60 mb-2">No parameters</div>
          )}
          {def.params.map((p) => (
            <label key={p.key} className="flex items-center justify-between gap-2 mb-2 text-[11px]">
              <span className="opacity-80">{p.label}</span>
              <input
                type="number"
                value={Number.isFinite(draftParams[p.key] ?? p.default) ? (draftParams[p.key] ?? p.default) : ''}
                min={p.min}
                max={p.max}
                step={p.step}
                onChange={(e) => setDraftParams((prev) => ({
                  ...prev,
                  [p.key]: e.target.value.trim() === '' ? Number.NaN : Number(e.target.value),
                }))}
                className="w-20 px-2 py-1 rounded border text-[11px] bg-transparent"
                style={{ borderColor: dark ? '#2A2E39' : '#E0E3EB', color: dark ? '#D1D4DC' : '#131722' }}
              />
            </label>
          ))}
          <div className="border-t pt-2 mt-1 flex flex-col gap-1.5">
            <span className="text-[11px] font-semibold opacity-70">Plots / couleurs</span>
            {def.plots.map((plot) => {
              const cfg = draftPlotSettings[plot.key] ?? { visible: true, color: plot.color }
              return (
                <label key={plot.key} className="flex items-center justify-between gap-2 text-[11px]">
                  <span className="flex items-center gap-1.5"><input type="checkbox" checked={cfg.visible} onChange={(e) => setDraftPlotSettings((prev) => ({ ...prev, [plot.key]: { ...cfg, visible: e.target.checked } }))} />{plot.label}</span>
                  <input type="color" value={cfg.color} onChange={(e) => setDraftPlotSettings((prev) => ({ ...prev, [plot.key]: { ...cfg, color: e.target.value } }))} className="w-7 h-5 border-0 bg-transparent" />
                </label>
              )
            })}
          </div>
          <div className="flex gap-2 mt-3">
            <button
              onClick={() => {
                onParams(instance.uid, draftParams); onPlotSettings(instance.uid, draftPlotSettings)
                setSettingsOpen(false)
              }}
              className="flex-1 px-2 py-1 rounded text-[11px] font-medium text-white"
              style={{ background: '#2962FF' }}
            >
              Apply
            </button>
            <button
              onClick={() => setSettingsOpen(false)}
              className="px-2 py-1 rounded text-[11px] border"
              style={{ borderColor: dark ? '#2A2E39' : '#E0E3EB' }}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  )
})
