'use client'

/**
 * drawing-layer.tsx — TradingView drawing tools over lightweight-charts.
 *
 * Canvas overlay anchored in chart space ({logical, price}). The canvas
 * itself is pointer-events:none (the chart keeps receiving pan/zoom);
 * interactions are captured on the container in CAPTURE phase so a
 * drawing gesture can stopPropagation before lightweight-charts sees it.
 *
 * Tools: trend line, ray, extended line, horizontal line/ray, vertical
 * line, arrow, parallel channel, rectangle, triangle, ellipse, fib
 * retracement, fib extension, brush, text, measure — with magnet snap,
 * selection, point dragging, shape translation and deletion.
 */

import { useEffect, useRef, useState, useCallback } from 'react'
import type { IChartApi, ISeriesApi } from 'lightweight-charts'

import type { CandleLike } from '@/lib/indicators'
import { smartTraderProjection } from '@/lib/smart-trader-projection'
import {
  DrawingManager, TOOL_META, FIB_LEVELS, FIB_EXT_LEVELS, FIB_COLORS,
  type DrawingPoint, type DrawingShape,
} from '@/lib/drawings'

export interface SmartTraderForecast {
  direction: 'up' | 'down' | 'neutral'
  confidence: number
  onsetSeconds: number | null
  horizonSeconds: number
  target: number
  generatedAt: number
}

interface DrawingLayerProps {
  manager: DrawingManager
  getChart: () => IChartApi | null
  getSeries: () => ISeriesApi<any> | null
  getCandles: () => CandleLike[]
  dark: boolean
  /** Host element that OWNS the lightweight-charts canvas (listeners attach here). */
  hostRef: React.RefObject<HTMLDivElement | null>
  onForecast?: (forecast: SmartTraderForecast | null) => void
}

interface Px { x: number; y: number }

function fmtPrice(p: number): string {
  const abs = Math.abs(p)
  if (abs >= 10000) return p.toFixed(1)
  if (abs >= 100) return p.toFixed(2)
  if (abs >= 1) return p.toFixed(4)
  return p.toFixed(5)
}

function fmtDuration(sec: number): string {
  if (sec < 60) return `${sec}s`
  if (sec < 3600) return `${Math.floor(sec / 60)}m ${sec % 60}s`
  if (sec < 86400) return `${Math.floor(sec / 3600)}h ${Math.floor((sec % 3600) / 60)}m`
  return `${Math.floor(sec / 86400)}d ${Math.floor((sec % 86400) / 3600)}h`
}

type FibCorner = 0 | 1 | 2 | 3 // TL, TR, BL, BR

function fibCornerPoints(points: DrawingPoint[]) {
  if (points.length < 2) return null
  const p0 = points[0], p1 = points[1]
  const minL = Math.min(p0.logical, p1.logical), maxL = Math.max(p0.logical, p1.logical)
  const minP = Math.min(p0.price, p1.price), maxP = Math.max(p0.price, p1.price)
  return [
    { logical: minL, price: maxP },
    { logical: maxL, price: maxP },
    { logical: minL, price: minP },
    { logical: maxL, price: minP },
  ] as DrawingPoint[]
}


function autoPatternHits(candles: CandleLike[]) {
  const out:{name:string,index:number,dir:'up'|'down'|'neutral'}[]=[]; const n=candles.length; if(n<5)return out;
  const c=candles[n-1], p=candles[n-2], b=candles[n-3], a=candles[n-4];
  const body=Math.abs(c.close-c.open), range=Math.max(1e-12,c.high-c.low), upper=c.high-Math.max(c.open,c.close), lower=Math.min(c.open,c.close)-c.low;
  if(body/range<.25 && lower>body*2 && upper<body*1.2) out.push({name:'Hammer',index:n-1,dir:'up'});
  if(body/range<.25 && upper>body*2 && lower<body*1.2) out.push({name:'Shooting Star',index:n-1,dir:'down'});
  if(c.close>c.open&&p.close<p.open&&c.open<=p.close&&c.close>=p.open) out.push({name:'Bullish Engulfing',index:n-1,dir:'up'});
  if(c.close<c.open&&p.close>p.open&&c.open>=p.close&&c.close<=p.open) out.push({name:'Bearish Engulfing',index:n-1,dir:'down'});
  if(c.close>c.open&&p.close<p.open&&c.close>(p.open+p.close)/2) out.push({name:'Piercing Line',index:n-1,dir:'up'});
  if(c.close<c.open&&p.close>p.open&&c.close<(p.open+p.close)/2) out.push({name:'Dark Cloud',index:n-1,dir:'down'});
  if(Math.abs(c.close-c.open)<range*.1) out.push({name:'Doji',index:n-1,dir:'neutral'});
  const hs=[a.high,b.high,p.high,c.high], ls=[a.low,b.low,p.low,c.low];
  if(b.high>a.high&&b.high>p.high&&p.high<c.high) out.push({name:'Possible Head & Shoulders',index:n-2,dir:'down'});
  if(b.low<a.low&&b.low<p.low&&p.low>c.low) out.push({name:'Possible Inverse H&S',index:n-2,dir:'up'});
  const hi=Math.max(...candles.slice(-8).map(x=>x.high)),lo=Math.min(...candles.slice(-8).map(x=>x.low));
  if((hi-lo)>0 && range<(hi-lo)*.25) out.push({name:'Rectangle / Consolidation',index:n-1,dir:'neutral'});
  return out.slice(-6);
}

export function DrawingLayer({ manager, getChart, getSeries, getCandles, dark, hostRef, onForecast }: DrawingLayerProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const dirtyRef = useRef(true)
  const cursorRef = useRef<Px | null>(null)
  const anchorsRef = useRef<Array<{ id: string; pts: Px[] }>>([])
  const sizeRef = useRef({ w: 0, h: 0 })
  const [textInput, setTextInput] = useState<{ id: string; x: number; y: number; value: string } | null>(null)
  const [fibLookbackDraft, setFibLookbackDraft] = useState('30')
  const fibLookbackOwnerRef = useRef<string | null>(null)
  const [, forceManagerRefresh] = useState(0)
  const forecastFingerprintRef = useRef('')
  const forecastSeenRef = useRef(false)

  // drag state (ref — no re-render)
  const dragRef = useRef<{
    kind: 'shape' | 'point' | 'fib-corner' | 'brush' | 'measure'
    id?: string
    pointIdx?: number
    fibCorner?: FibCorner
    lastLogical: number
    lastPrice: number
  } | null>(null)

  // ephemeral measure state
  const measureRef = useRef<{ start: Px; end: Px; done: boolean } | null>(null)

  // ─────────────────────────────────────────────── coordinate conversion
  const xToLogical = useCallback((x: number): number | null => {
    const chart = getChart()
    if (!chart) return null
    try {
      const l = chart.timeScale().coordinateToLogical(x as any)
      return l == null ? null : (l as number)
    } catch { return null }
  }, [getChart])

  const logicalToX = useCallback((l: number): number | null => {
    const chart = getChart()
    if (!chart) return null
    try {
      const x = chart.timeScale().logicalToCoordinate(l as any)
      return x == null ? null : (x as number)
    } catch { return null }
  }, [getChart])

  const yToPrice = useCallback((y: number): number | null => {
    const series = getSeries()
    if (!series) return null
    try {
      const p = series.coordinateToPrice(y as any)
      return p == null ? null : (p as number)
    } catch { return null }
  }, [getSeries])

  const priceToY = useCallback((p: number): number | null => {
    const series = getSeries()
    if (!series) return null
    try {
      const y = series.priceToCoordinate(p)
      return y == null ? null : (y as number)
    } catch { return null }
  }, [getSeries])

  const magnetSnap = useCallback((logical: number, price: number): number => {
    if (!manager.magnet) return price
    const candles = getCandles()
    const idx = Math.round(logical)
    const c = candles[idx]
    if (!c) return price
    const y = priceToY(price)
    if (y == null) return price
    let best = price
    let bestD = Infinity
    for (const v of [c.open, c.high, c.low, c.close]) {
      const vy = priceToY(v)
      if (vy == null) continue
      const d = Math.abs(vy - y)
      if (d < bestD) { bestD = d; best = v }
    }
    return bestD <= 18 ? best : price
  }, [manager, getCandles, priceToY])

  const pointFromXY = useCallback((x: number, y: number): DrawingPoint | null => {
    const logical = xToLogical(x)
    const price = yToPrice(y)
    if (logical == null || price == null) return null
    return { logical, price: magnetSnap(logical, price) }
  }, [xToLogical, yToPrice, magnetSnap])

  const pxOf = useCallback((p: DrawingPoint): Px | null => {
    const x = logicalToX(p.logical)
    const y = priceToY(p.price)
    if (x == null || y == null) return null
    return { x, y }
  }, [logicalToX, priceToY])

  // ─────────────────────────────────────────────── canvas sizing
  useEffect(() => {
    const container = containerRef.current
    const canvas = canvasRef.current
    if (!container || !canvas) return
    const resize = () => {
      const w = container.clientWidth
      const h = container.clientHeight
      const dpr = window.devicePixelRatio || 1
      canvas.width = Math.max(1, Math.floor(w * dpr))
      canvas.height = Math.max(1, Math.floor(h * dpr))
      canvas.style.width = `${w}px`
      canvas.style.height = `${h}px`
      sizeRef.current = { w, h }
      dirtyRef.current = true
    }
    resize()
    const ro = new ResizeObserver(resize)
    ro.observe(container)
    return () => ro.disconnect()
  }, [])

  // Keep a local draft for Fibonacci lookback so users can type multi-digit
  // values (e.g. 45) without the controlled input being clamped after the
  // first keypress. The value is committed atomically on blur / Enter.
  useEffect(() => {
    const selected = manager.selectedId ? manager.byId(manager.selectedId) : null
    if (selected?.tool === 'fib-retracement') {
      const raw = Number(selected.forecastLookback ?? 30)
      const value = Number.isFinite(raw) ? Math.max(1, Math.round(raw)) : 30
      if (fibLookbackOwnerRef.current !== selected.id) {
        fibLookbackOwnerRef.current = selected.id
        setFibLookbackDraft(String(value))
      }
    } else {
      fibLookbackOwnerRef.current = null
    }
  }, [manager, forceManagerRefresh])

  // ─────────────────────────────────────────────── manager changes
  useEffect(() => {
    const unsub = manager.subscribe(() => { dirtyRef.current = true; forceManagerRefresh(v => v + 1) })
    return unsub
  }, [manager])

  // ─────────────────────────────────────────────── rendering
  const render = useCallback(() => {
    const canvas = canvasRef.current
    const chart = getChart()
    const series = getSeries()
    if (!canvas || !chart || !series) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    const dpr = window.devicePixelRatio || 1
    const { w, h } = sizeRef.current
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    ctx.clearRect(0, 0, w, h)

    const textColor = dark ? '#D1D4DC' : '#131722'
    const crossColor = dark ? '#758696' : '#9598A1'

    if (manager.hideAll) {
      anchorsRef.current = []
      return
    }

    const shapes = manager.shapes
    const anchors: Array<{ id: string; pts: Px[] }> = []
    forecastSeenRef.current = false

    const strokeLine = (a: Px, b: Px, color: string, width = 4) => {
      ctx.beginPath()
      ctx.moveTo(a.x, a.y)
      ctx.lineTo(b.x, b.y)
      ctx.strokeStyle = color
      ctx.lineWidth = width
      ctx.stroke()
    }

    const drawHandles = (pts: Px[], width: number) => {
      for (const p of pts) {
        ctx.beginPath()
        ctx.arc(p.x, p.y, 16, 0, Math.PI * 2)
        ctx.fillStyle = '#FFFFFF'
        ctx.fill()
        ctx.strokeStyle = '#2962FF'
        ctx.lineWidth = Math.max(2, width)
        ctx.stroke()
      }
    }

    const drawLabel = (x: number, y: number, text: string, bg: string, fg: string) => {
      ctx.font = '10px -apple-system, Roboto, sans-serif'
      const pad = 3
      const tw = ctx.measureText(text).width
      ctx.fillStyle = bg
      ctx.fillRect(x - pad, y - 8, tw + pad * 2, 14)
      ctx.fillStyle = fg
      ctx.fillText(text, x, y + 2)
    }

    for (const shape of shapes) {
      const pts = shape.points.map(pxOf)
      if (pts.some((p) => p == null) || pts.length === 0) continue
      const P = pts as Px[]
      const selected = manager.selectedId === shape.id
      const color = shape.color
      const sw = Math.max(1, Math.min(16, shape.strokeWidth ?? 4))
      ctx.lineWidth = sw
      ctx.strokeStyle = color

      // collect hit anchors
      const anchorPts: Px[] = []
      for (const p of shape.points) {
        const px = pxOf(p)
        if (px) anchorPts.push(px)
      }
      anchors.push({ id: shape.id, pts: anchorPts })

      switch (shape.tool) {
        case 'info-line': {
          strokeLine(P[0],P[1],color,sw); const dx=shape.points[1].logical-shape.points[0].logical; const dp=shape.points[1].price-shape.points[0].price; drawLabel((P[0].x+P[1].x)/2,(P[0].y+P[1].y)/2,`${fmtPrice(dp)} · ${Math.abs(Math.round(dx))} bars`,color,'#fff'); break
        }
        case 'trend-angle': {
          strokeLine(P[0],P[1],color,sw); const a=Math.atan2(P[1].y-P[0].y,P[1].x-P[0].x)*180/Math.PI; drawLabel(P[1].x+5,P[1].y-5,`${a.toFixed(1)}°`,color,'#fff'); break
        }
        case 'trend-line': {
          strokeLine(P[0], P[1], color, sw)
          break
        }
        case 'ray': {
          // extend from P[0] through P[1] to the right edge
          const dx = P[1].x - P[0].x
          const dy = P[1].y - P[0].y
          if (dx !== 0) {
            const t = dx > 0 ? (w + 50 - P[0].x) / dx : (-50 - P[0].x) / dx
            strokeLine(P[0], { x: P[0].x + dx * t, y: P[0].y + dy * t }, color, sw)
          } else strokeLine(P[0], P[1], color, sw)
          break
        }
        case 'extended-line': {
          const dx = P[1].x - P[0].x
          const dy = P[1].y - P[0].y
          if (dx !== 0) {
            const tR = (w + 50 - P[0].x) / dx
            const tL = (-50 - P[0].x) / dx
            strokeLine(
              { x: P[0].x + dx * Math.min(tR, tL), y: P[0].y + dy * Math.min(tR, tL) },
              { x: P[0].x + dx * Math.max(tR, tL), y: P[0].y + dy * Math.max(tR, tL) },
              color, 1.5,
            )
          } else strokeLine({ x: P[0].x, y: -50 }, { x: P[0].x, y: h + 50 }, color, sw)
          break
        }
        case 'horizontal-line': {
          if (P.length < 2) break
          const y = P[0].y
          const x1 = Math.min(P[0].x, P[1].x), x2 = Math.max(P[0].x, P[1].x)
          strokeLine({ x: x1, y }, { x: x2, y }, color, sw)
          drawLabel(x2 + 4, y, fmtPrice(shape.points[0].price), color, '#FFFFFF')
          break
        }
        case 'horizontal-ray': {
          const y = P[0].y
          strokeLine({ x: P[0].x, y }, { x: w + 50, y }, color, sw)
          drawLabel(w - 70, y, fmtPrice(shape.points[0].price), color, '#FFFFFF')
          break
        }
        case 'vertical-line': {
          if (P.length < 2) break
          const x = P[0].x
          const y1 = Math.min(P[0].y, P[1].y), y2 = Math.max(P[0].y, P[1].y)
          strokeLine({ x, y: y1 }, { x, y: y2 }, color, sw)
          break
        }
        case 'arrow': {
          strokeLine(P[0], P[1], color, sw)
          // arrowhead at P[1]
          const angle = Math.atan2(P[1].y - P[0].y, P[1].x - P[0].x)
          const headLen = 12
          ctx.beginPath()
          ctx.moveTo(P[1].x, P[1].y)
          ctx.lineTo(P[1].x - headLen * Math.cos(angle - Math.PI / 7), P[1].y - headLen * Math.sin(angle - Math.PI / 7))
          ctx.lineTo(P[1].x - headLen * Math.cos(angle + Math.PI / 7), P[1].y - headLen * Math.sin(angle + Math.PI / 7))
          ctx.closePath()
          ctx.fillStyle = color
          ctx.fill()
          break
        }
        case 'rotated-rectangle': case 'rectangle': {
          const x = Math.min(P[0].x, P[1].x)
          const y = Math.min(P[0].y, P[1].y)
          const rw = Math.abs(P[1].x - P[0].x)
          const rh = Math.abs(P[1].y - P[0].y)
          ctx.beginPath()
          ctx.rect(x, y, rw, rh)
          ctx.strokeStyle = color
          ctx.lineWidth = sw
          ctx.stroke()
          ctx.fillStyle = `${color}22`
          ctx.fill()
          break
        }
        case 'path': case 'curve': case 'double-curve': case 'triangle': {
          if (P.length < 3) break
          ctx.beginPath()
          ctx.moveTo(P[0].x, P[0].y)
          ctx.lineTo(P[1].x, P[1].y)
          ctx.lineTo(P[2].x, P[2].y)
          ctx.closePath()
          ctx.strokeStyle = color
          ctx.lineWidth = sw
          ctx.stroke()
          ctx.fillStyle = `${color}22`
          ctx.fill()
          break
        }
        case 'ellipse': {
          const cx = (P[0].x + P[1].x) / 2
          const cy = (P[0].y + P[1].y) / 2
          const rx = Math.abs(P[1].x - P[0].x) / 2
          const ry = Math.abs(P[1].y - P[0].y) / 2
          ctx.beginPath()
          ctx.ellipse(cx, cy, Math.max(2, rx), Math.max(2, ry), 0, 0, Math.PI * 2)
          ctx.strokeStyle = color
          ctx.lineWidth = sw
          ctx.stroke()
          ctx.fillStyle = `${color}22`
          ctx.fill()
          break
        }
        case 'parallel-channel': {
          if (P.length < 3) break
          const p1 = shape.points[0]
          const p2 = shape.points[1]
          const p3 = shape.points[2]
          const dL = p3.logical - p1.logical
          const dP = p3.price - p1.price
          const q1 = pxOf({ logical: p1.logical + dL, price: p1.price + dP })
          const q2 = pxOf({ logical: p2.logical + dL, price: p2.price + dP })
          if (!q1 || !q2) break
          strokeLine(P[0], P[1], color, sw)
          strokeLine(q1, q2, color, sw)
          // translucent fill between the two lines
          ctx.beginPath()
          ctx.moveTo(P[0].x, P[0].y)
          ctx.lineTo(P[1].x, P[1].y)
          ctx.lineTo(q2.x, q2.y)
          ctx.lineTo(q1.x, q1.y)
          ctx.closePath()
          ctx.fillStyle = `${color}18`
          ctx.fill()
          break
        }
        case 'fib-retracement': {
          if (P.length < 2 || shape.points.length < 2) break
          const x1 = Math.min(P[0].x, P[1].x)
          const x2 = Math.max(P[0].x, P[1].x)
          const a = shape.points[0].price
          const b = shape.points[1].price
          const fibTop = Math.max(a, b)
          const fibBottom = Math.min(a, b)
          const fibFlipped = shape.fibFlipped === true
          const visibleLevels = (shape.fibLevels !== undefined ? shape.fibLevels : [...FIB_LEVELS]).filter(Number.isFinite)
          const ys: Array<{ y: number; lvl: number }> = []
          for (const lvl of visibleLevels) {
            const price = fibFlipped ? b + (a - b) * lvl : a + (b - a) * lvl
            const y = priceToY(price)
            if (y == null) continue
            const colorIndex = Math.max(0, FIB_LEVELS.findIndex(v => Math.abs(v - lvl) < 1e-9))
            const lineColor = FIB_COLORS[colorIndex % FIB_COLORS.length]
            ys.push({ y, lvl })
            strokeLine({ x: x1, y }, { x: x2, y }, lineColor, sw)
            const labelX = fibFlipped ? Math.max(x1 + 2, x2 - 78) : x1
            drawLabel(labelX, y - 6, `${lvl} (${fmtPrice(price)})`, 'transparent', lineColor)
          }

          const candles = getCandles()
          if (candles.length >= 28) {
            const last = candles[candles.length - 1]
            const prev = candles[candles.length - 2]
            const tfSec = Math.max(1, Math.abs(last.time - prev.time) || 60)

            // SMART TRADER RULE (retracement principle):
            // The Fibonacci 0→1 segment anchors the impulse leg and its
            // price levels — it does NOT define the forecast time window.
            // The projection ALWAYS starts at the CURRENT candle and only
            // ever extends into the FUTURE (never over history). Placing 0
            // on the swing low and 1 on the swing high therefore works with
            // no need to drag an anchor past the last candle.
            const rawLastX = logicalToX(candles.length - 1)
            const prevX = logicalToX(candles.length - 2)
            if (rawLastX == null) break
            const candlePx = prevX != null ? Math.max(3, Math.abs(rawLastX - prevX)) : 8

            // Impulse direction from the TIME-ORDERED anchors: the leg runs
            // from the earlier anchor to the later one.
            const pA = shape.points[0]
            const pB = shape.points[1]
            const earlier = pA.logical <= pB.logical ? pA : pB
            const laterPt = pA.logical <= pB.logical ? pB : pA
            const impulseDir: 1 | -1 = laterPt.price >= earlier.price ? 1 : -1

            // Forecast horizon is measured in REAL future candles, never
            // arbitrary clock timestamps or a stretched Fibonacci width.
            // The model decides direction from the last lookback bars; the
            // drawing simply displays the next 3–8 candles chronologically.
            const swingBars = Math.abs(Math.round(pB.logical - pA.logical))
            const horizonBars = Math.min(8, Math.max(3, Math.round(3 + Math.min(5, swingBars / 12))))
            const rawLookback = Number(shape.forecastLookback ?? 30)
            const forecastLookback = Number.isFinite(rawLookback) ? Math.max(1, Math.round(rawLookback)) : 30
            const model = smartTraderProjection(candles, horizonBars, a, b, impulseDir, forecastLookback)
            if (model) {
              forecastSeenRef.current = true
              const forecastSeconds = model.onsetBar > 0 ? Math.max(tfSec, Math.round(model.onsetBar * tfSec)) : null
              const forecast: SmartTraderForecast = {
                direction: model.direction > 0 ? 'up' : model.direction < 0 ? 'down' : 'neutral',
                confidence: model.confidence,
                onsetSeconds: forecastSeconds,
                horizonSeconds: Math.max(tfSec, horizonBars * tfSec),
                target: model.target,
                generatedAt: Date.now(),
              }
              const fp = `${forecast.direction}|${forecast.confidence}|${forecast.onsetSeconds ?? 0}|${forecast.target.toFixed(8)}|${forecast.horizonSeconds}|${last.time}|${horizonBars}`
              if (fp !== forecastFingerprintRef.current) {
                forecastFingerprintRef.current = fp
                onForecast?.(forecast)
              }

              // Forecast geometry — strictly the FUTURE zone to the right of
              // the current candle (never over history). The price clip is the
              // retracement corridor: the 0/1 box plus the 1.272 continuation
              // extension, so the projected trend may legitimately exceed the
              // swing-end level instead of being pinned flat at level 1.
              const forecastStartX = rawLastX
              const xEnd = Math.max(forecastStartX + candlePx, Math.min(w - 12, forecastStartX + candlePx * horizonBars))
              const curvePts: Px[] = []
              for (const q of model.out) {
                const x = forecastStartX + (xEnd - forecastStartX) * q.t
                const y = priceToY(q.p)
                if (y != null && x >= forecastStartX - 1 && x <= xEnd + 1) curvePts.push({ x, y })
              }
              if (curvePts.length > 1) {
                const trendColor = model.direction > 0 ? '#089981' : model.direction < 0 ? '#F23645' : '#787B86'

                // Future-only time clip + retracement corridor price clip.
                ctx.save()
                const topY = priceToY(model.corridorTop)
                const bottomY = priceToY(model.corridorBottom)
                const clipTop = Math.max(0, Math.min(h, Math.min(topY ?? 0, bottomY ?? h)))
                const clipBottom = Math.max(0, Math.min(h, Math.max(topY ?? 0, bottomY ?? h)))
                const clipLeft = Math.max(0, forecastStartX - 2)
                const clipRight = Math.max(1, Math.min(w, xEnd))
                ctx.beginPath()
                ctx.rect(clipLeft, clipTop, Math.max(1, clipRight - clipLeft), Math.max(1, clipBottom - clipTop))
                ctx.clip()
                // Compact onset heatmap inside the Fibonacci frame: green row
                // = historical bullish onset frequency, red row = bearish.
                const heatH = Math.min(8, Math.max(3, (clipBottom - clipTop) * 0.018))
                const heatY = clipBottom - heatH * 2 - 4
                const bins = Math.min(horizonBars, 40)
                for (let b = 0; b < bins; b++) {
                  const start = Math.floor((b / bins) * horizonBars)
                  const end = Math.min(horizonBars, Math.floor(((b + 1) / bins) * horizonBars))
                  let up = 0, down = 0
                  for (let j = start; j < Math.max(start + 1, end); j++) {
                    up = Math.max(up, model.heatUp[j] ?? 0)
                    down = Math.max(down, model.heatDown[j] ?? 0)
                  }
                  const bx = forecastStartX + (xEnd - forecastStartX) * (b / bins)
                  const bw = Math.max(1, (xEnd - forecastStartX) / bins + 0.5)
                  if (up > 0) {
                    ctx.fillStyle = `rgba(8,153,129,${0.06 + up * 0.42})`
                    ctx.fillRect(bx, heatY, bw, heatH)
                  }
                  if (down > 0) {
                    ctx.fillStyle = `rgba(242,54,69,${0.06 + down * 0.42})`
                    ctx.fillRect(bx, heatY + heatH, bw, heatH)
                  }
                }
                const strongestUp = model.heatUp.reduce((best, value, i, arr) => value > arr[best] ? i : best, 0)
                const strongestDown = model.heatDown.reduce((best, value, i, arr) => value > arr[best] ? i : best, 0)
                if ((model.heatUp[strongestUp] ?? 0) > 0) {
                  const ux = forecastStartX + (xEnd - forecastStartX) * (strongestUp / Math.max(1, horizonBars))
                  ctx.fillStyle = 'rgba(8,153,129,0.18)'
                  ctx.fillRect(ux - 2, clipTop, 4, heatY - clipTop)
                }
                if ((model.heatDown[strongestDown] ?? 0) > 0) {
                  const dx = forecastStartX + (xEnd - forecastStartX) * (strongestDown / Math.max(1, horizonBars))
                  ctx.fillStyle = 'rgba(242,54,69,0.18)'
                  ctx.fillRect(dx - 2, clipTop, 4, heatY - clipTop)
                }

                const ribbon: Px[] = []
                for (let i = 0; i < curvePts.length; i++) ribbon.push({ x: curvePts[i].x, y: curvePts[i].y - 4 - i * 0.05 })
                for (let i = curvePts.length - 1; i >= 0; i--) ribbon.push({ x: curvePts[i].x, y: curvePts[i].y + 4 + i * 0.05 })
                ctx.beginPath()
                ctx.moveTo(ribbon[0].x, ribbon[0].y)
                for (let i = 1; i < ribbon.length; i++) ctx.lineTo(ribbon[i].x, ribbon[i].y)
                ctx.closePath()
                ctx.fillStyle = `${trendColor}12`
                ctx.fill()

                // Main non-linear forecast path.
                ctx.beginPath()
                ctx.moveTo(curvePts[0].x, curvePts[0].y)
                for (let i = 1; i < curvePts.length; i++) ctx.lineTo(curvePts[i].x, curvePts[i].y)
                ctx.strokeStyle = trendColor
                ctx.lineWidth = Math.max(3, sw + 1)
                ctx.shadowBlur = 8
                ctx.shadowColor = trendColor
                ctx.stroke()
                ctx.restore()

                // Draw predicted candles from the analogue forecast. These are
                // placed AFTER the latest real candle — never over history.
                ctx.save()
                ctx.beginPath()
                ctx.rect(clipLeft, clipTop, Math.max(1, clipRight - clipLeft), Math.max(1, clipBottom - clipTop))
                ctx.clip()
                const candleSpan = Math.min(candlePx, Math.max(2, (xEnd - forecastStartX) / Math.max(2, horizonBars) * 0.92))
                for (let i = 1; i < curvePts.length; i++) {
                  const px = curvePts[i].x
                  const py = curvePts[i].y
                  const prevPy = curvePts[i - 1].y
                  const predicted = model.predictedBodies[i - 1]
                  if (!predicted) continue
                  const highY = priceToY(Math.min(model.corridorTop, predicted.high)) ?? Math.min(py, prevPy)
                  const lowY = priceToY(Math.max(model.corridorBottom, predicted.low)) ?? Math.max(py, prevPy)
                  const bodyOpenY = priceToY(Math.max(model.corridorBottom, Math.min(model.corridorTop, predicted.open))) ?? prevPy
                  const bodyCloseY = priceToY(Math.max(model.corridorBottom, Math.min(model.corridorTop, predicted.close))) ?? py
                  const bodyTop = Math.min(bodyOpenY, bodyCloseY)
                  const bodyBottom = Math.max(bodyOpenY, bodyCloseY)
                  const half = Math.max(2, candleSpan * 0.28)
                  const wickTop = Math.min(h, Math.max(0, highY))
                  const wickBottom = Math.max(0, Math.min(h, lowY))
                  const candleColor = predicted.close >= predicted.open ? '#089981' : '#F23645'
                  ctx.strokeStyle = `${candleColor}99`
                  ctx.lineWidth = 1
                  ctx.beginPath()
                  ctx.moveTo(px, wickTop)
                  ctx.lineTo(px, wickBottom)
                  ctx.stroke()
                  ctx.fillStyle = `${candleColor}66`
                  ctx.fillRect(px - half, bodyTop, half * 2, Math.max(2, bodyBottom - bodyTop))
                  ctx.strokeStyle = candleColor
                  ctx.strokeRect(px - half, bodyTop, half * 2, Math.max(2, bodyBottom - bodyTop))
                }
                ctx.restore()

                const onsetSec = Math.max(tfSec, Math.round(model.onsetBar * tfSec))
                const onsetTime = new Date(last.time * 1000 + onsetSec * 1000)
                const onsetClock = onsetTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })
                const targetTime = new Date(last.time * 1000 + Math.max(tfSec, horizonBars * tfSec) * 1000)
                const targetClock = targetTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })
                const trend = model.direction > 0 ? 'BULLISH' : model.direction < 0 ? 'BEARISH' : 'WAIT'
                const onsetText = model.direction === 0 ? 'no clear trigger' : `start ${trend === 'BULLISH' ? 'BULLISH' : 'BEARISH'} ≈ ${fmtDuration(onsetSec)} · ${onsetClock}`
                const tagX = Math.max(6, Math.min(w - 260, forecastStartX + 6))
                const tagY = Math.min(h - 38, Math.max(24, curvePts[0].y - 34))
                drawLabel(tagX, tagY, `AI SMART TRADER · ${trend}`, 'rgba(15,17,23,0.94)', trendColor)
                drawLabel(tagX, tagY + 16, `${onsetText} · confidence ${model.confidence}%`, 'rgba(15,17,23,0.88)', '#FFFFFF')
                drawLabel(Math.max(forecastStartX + 4, Math.min(w - 160, xEnd - 150)), Math.max(14, (priceToY(model.target) ?? curvePts[curvePts.length - 1].y) - 10), `target ${fmtPrice(model.target)} · ${targetClock}`, 'rgba(15,17,23,0.82)', '#FFFFFF')

                // Forecast origin marker — where the trend starts: exactly at
                // the CURRENT candle's close (never in the past).
                const startY = priceToY(last.close) ?? curvePts[0].y
                ctx.beginPath()
                ctx.arc(forecastStartX, startY, 4.5, 0, Math.PI * 2)
                ctx.fillStyle = '#FFFFFF'
                ctx.fill()
                ctx.strokeStyle = trendColor
                ctx.lineWidth = 2
                ctx.stroke()

                // Direction arrowhead at the end of the projected path —
                // where the trend is heading.
                const tip = curvePts[curvePts.length - 1]
                const before = curvePts[Math.max(0, curvePts.length - 2)]
                const ang = Math.atan2(tip.y - before.y, tip.x - before.x)
                ctx.beginPath()
                ctx.moveTo(tip.x, tip.y)
                ctx.lineTo(tip.x - 12 * Math.cos(ang - 0.45), tip.y - 12 * Math.sin(ang - 0.45))
                ctx.lineTo(tip.x - 12 * Math.cos(ang + 0.45), tip.y - 12 * Math.sin(ang + 0.45))
                ctx.closePath()
                ctx.fillStyle = trendColor
                ctx.fill()

                // Exact time-to-onset marker in the forecast corridor, aligned to the real current candle.
                if (model.direction !== 0 && model.onsetBar > 0) {
                  const onsetX = forecastStartX + (xEnd - forecastStartX) * (model.onsetBar / horizonBars)
                  ctx.save()
                  ctx.setLineDash([3, 4])
                  strokeLine({ x: onsetX, y: clipTop }, { x: onsetX, y: clipBottom }, `${trendColor}99`, 1)
                  ctx.restore()
                  drawLabel(Math.max(forecastStartX + 4, Math.min(w - 112, onsetX + 4)), Math.max(12, (priceToY(model.target) ?? curvePts[0].y) - 26), `START ${fmtDuration(onsetSec)}`, 'transparent', trendColor)
                }
              }
            }
          }

          for (let i = 0; i < ys.length - 1; i++) {
            ctx.fillStyle = `${FIB_COLORS[(i + 1) % FIB_COLORS.length]}12`
            ctx.fillRect(x1, Math.min(ys[i].y, ys[i + 1].y), Math.max(1, x2 - x1), Math.abs(ys[i + 1].y - ys[i].y))
          }
          break
        }
        case 'fib-extension': {
          if (P.length < 3) break
          const a = shape.points[0].price
          const b = shape.points[1].price
          const c = shape.points[2]
          const range = b - a
          const xStart = P[2].x
          for (let i = 0; i < FIB_EXT_LEVELS.length; i++) {
            const lvl = FIB_EXT_LEVELS[i]
            const price = c.price + range * lvl
            const y = priceToY(price)
            if (y == null) continue
            strokeLine({ x: xStart, y }, { x: w - 60, y }, FIB_COLORS[i % FIB_COLORS.length], sw)
            drawLabel(w - 56, y - 6, `${lvl} (${fmtPrice(price)})`,
              'transparent', FIB_COLORS[i % FIB_COLORS.length])
          }
          break
        }
        case 'highlighter': case 'brush': {
          ctx.beginPath()
          ctx.moveTo(P[0].x, P[0].y)
          for (let i = 1; i < P.length; i++) ctx.lineTo(P[i].x, P[i].y)
          ctx.strokeStyle = color
          ctx.lineWidth = sw
          ctx.lineJoin = 'round'
          ctx.stroke()
          break
        }
        case 'polyline': {
          ctx.beginPath(); ctx.moveTo(P[0].x,P[0].y); for(let i=1;i<P.length;i++) ctx.lineTo(P[i].x,P[i].y)
          ctx.strokeStyle=color; ctx.lineWidth=sw; ctx.lineJoin='round'; ctx.stroke(); break
        }
        case 'cross-line': {
          strokeLine({x:P[0].x,y:-50},{x:P[0].x,y:h+50},color,sw); strokeLine({x:-50,y:P[0].y},{x:w+50,y:P[0].y},color,sw); break
        }
        case 'arrow-mark': {
          const a=P[0],b=P[1]; strokeLine(a,b,color,sw); const ang=Math.atan2(b.y-a.y,b.x-a.x),q=10; ctx.beginPath();ctx.moveTo(b.x,b.y);ctx.lineTo(b.x-q*Math.cos(ang-.55),b.y-q*Math.sin(ang-.55));ctx.lineTo(b.x-q*Math.cos(ang+.55),b.y-q*Math.sin(ang+.55));ctx.closePath();ctx.fillStyle=color;ctx.fill(); break
        }
        case 'circle': {
          const cx=(P[0].x+P[1].x)/2,cy=(P[0].y+P[1].y)/2,r=Math.max(2,Math.hypot(P[1].x-P[0].x,P[1].y-P[0].y)/2);ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.strokeStyle=color;ctx.stroke();break
        }
        case 'arc': {
          const cx=P[0].x,cy=P[0].y,r=Math.max(2,Math.hypot(P[1].x-P[0].x,P[1].y-P[0].y)),a1=Math.atan2(P[1].y-P[0].y,P[1].x-P[0].x);ctx.beginPath();ctx.arc(cx,cy,r,a1-.9,a1+.9);ctx.strokeStyle=color;ctx.stroke();break
        }
        case 'sector': {
          const cx=P[0].x,cy=P[0].y,r=Math.max(2,Math.hypot(P[1].x-P[0].x,P[1].y-P[0].y)),a=Math.atan2(P[1].y-P[0].y,P[1].x-P[0].x);ctx.beginPath();ctx.moveTo(cx,cy);ctx.arc(cx,cy,r,a-.65,a+.65);ctx.closePath();ctx.strokeStyle=color;ctx.fillStyle=`${color}18`;ctx.fill();ctx.stroke();break
        }
        case 'regression-trend': {
          const x1=P[0].x,x2=P[1].x,y1=P[0].y,y2=P[1].y; strokeLine(P[0],P[1],color,sw); strokeLine({x:x1,y:y1+18},{x:x2,y:y2+18},color,sw); strokeLine({x:x1,y:y1-18},{x:x2,y:y2-18},color,sw); break
        }
        case 'fib-channel': { if(P.length<3) break; for(let k=-2;k<=2;k++){const off=(P[2].y-P[0].y)*k; strokeLine({x:P[0].x,y:P[0].y+off},{x:w,y:P[1].y+off},color,sw)} break }
        case 'fib-spiral': { const r=Math.max(4,Math.hypot(P[1].x-P[0].x,P[1].y-P[0].y)); ctx.beginPath(); for(let t=0;t<Math.PI*5;t+=.12){const rr=r*t/(Math.PI*5);const x=P[0].x+rr*Math.cos(t),y=P[0].y+rr*Math.sin(t); if(t===0)ctx.moveTo(x,y);else ctx.lineTo(x,y)} ctx.strokeStyle=color;ctx.stroke(); break }
        case 'fib-time-zone': {
          const a=Math.min(P[0].x,P[1].x),step=Math.abs(P[1].x-P[0].x)||20; for(let k=0;k<8;k++){const x=a+step*((Math.sqrt(5)-1)/2)*k*k; if(x>w+30)break; strokeLine({x,y:-50},{x,y:h+50},color,k<2?1.4:0.8)} break
        }
        case 'fib-speed-resistance-arc': {
          const r=Math.max(2,Math.abs(P[1].x-P[0].x));ctx.beginPath();ctx.arc(P[0].x,P[0].y,r,0,Math.PI/2);ctx.strokeStyle=color;ctx.stroke(); break
        }
        case 'fib-speed-resistance-fan': {
          for(let k=1;k<=4;k++){const q={x:P[0].x+(P[1].x-P[0].x)*k/4,y:P[0].y+(P[1].y-P[0].y)*k/4};strokeLine(P[0],{x:w,y:P[0].y+(q.y-P[0].y)*(w-P[0].x)/(q.x-P[0].x||1)},color,sw)} break
        }
        case 'fib-circles': {
          const r=Math.max(2,Math.hypot(P[1].x-P[0].x,P[1].y-P[0].y)); for(let k=1;k<=4;k++){ctx.beginPath();ctx.arc(P[0].x,P[0].y,r*k/4,0,Math.PI*2);ctx.strokeStyle=color;ctx.stroke()} break
        }
        case 'fib-wedge': case 'triangle-pattern': {
          if(P.length>=3){ctx.beginPath();ctx.moveTo(P[0].x,P[0].y);ctx.lineTo(P[1].x,P[1].y);ctx.lineTo(P[2].x,P[2].y);ctx.closePath();ctx.strokeStyle=color;ctx.fillStyle=`${color}18`;ctx.fill();ctx.stroke()} break
        }
        case 'gann-box': case 'gann-square': {
          const x=Math.min(P[0].x,P[1].x),y=Math.min(P[0].y,P[1].y),rw=Math.abs(P[1].x-P[0].x),rh=Math.abs(P[1].y-P[0].y);ctx.strokeStyle=color;ctx.strokeRect(x,y,rw,rh);for(let k=1;k<4;k++){strokeLine({x:x+rw*k/4,y},{x:x+rw*k/4,y:y+rh},color,.7);strokeLine({x,y:y+rh*k/4},{x:x+rw,y:y+rh*k/4},color,.7)}ctx.strokeStyle=color;strokeLine({x,y},{x:x+rw,y:y+rh},color,sw);strokeLine({x:x+rw,y},{x,y:y+rh},color,sw);break
        }
        case 'gann-fan': {
          for(let k=-2;k<=2;k++){const yy=P[0].y+k*(P[1].y-P[0].y)/2;strokeLine(P[0],{x:w,y:yy+(w-P[0].x)*((P[1].y-P[0].y)/(Math.abs(P[1].x-P[0].x)||1))},color,sw)} break
        }
        case 'pitchfork': case 'schiff-pitchfork': case 'modified-schiff-pitchfork': case 'inside-pitchfork': case 'pitchfan': {
          if(P.length>=3){const mx=(P[1].x+P[2].x)/2,my=(P[1].y+P[2].y)/2;strokeLine(P[0],{x:mx,y:my},color,sw);strokeLine(P[1],{x:w,y:P[1].y+(w-P[1].x)*(my-P[0].y)/(mx-P[0].x||1)},color,sw);strokeLine(P[2],{x:w,y:P[2].y+(w-P[2].x)*(my-P[0].y)/(mx-P[0].x||1)},color,sw)} break
        }
        case 'abcd': case 'xabcd': case 'three-drives': case 'head-shoulders': case 'elliott-wave': case 'forecast': case 'projection': case 'bar-pattern': {
          ctx.beginPath();ctx.moveTo(P[0].x,P[0].y);for(let i=1;i<P.length;i++)ctx.lineTo(P[i].x,P[i].y);ctx.strokeStyle=color;ctx.lineWidth=sw;ctx.stroke(); break
        }
        case 'time-cycles': case 'cyclic-lines': {
          const x1=P[0].x,x2=P[1].x,step=Math.abs(x2-x1)||20;for(let k=0;k<10;k++){const x=x1+step*k;strokeLine({x,y:-50},{x,y:h+50},color,sw)}break
        }
        case 'sine-line': { if(P.length<3) break; const x0=P[0].x,x1=P[1].x,amp=Math.abs(P[2].y-P[0].y),step=Math.max(8,Math.abs(x1-x0)); ctx.beginPath(); for(let x=Math.max(0,x0-20);x<=w+20;x+=3){const y=P[0].y+amp*Math.sin((x-x0)*Math.PI/step); if(x===Math.max(0,x0-20))ctx.moveTo(x,y);else ctx.lineTo(x,y)} ctx.strokeStyle=color;ctx.stroke(); break }
        case 'flat-top-bottom': case 'disjoint-channel': { if(P.length>=3){strokeLine(P[0],P[1],color,sw);strokeLine(P[2],{x:P[2].x+(P[1].x-P[0].x),y:P[2].y+(P[1].y-P[0].y)},color,sw)} break }
        case 'date-range': { const x1=Math.min(P[0].x,P[1].x),x2=Math.max(P[0].x,P[1].x);ctx.fillStyle=`${color}12`;ctx.fillRect(x1,0,x2-x1,h);strokeLine({x:x1,y:0},{x:x1,y:h},color,sw);strokeLine({x:x2,y:0},{x:x2,y:h},color,sw);break }
        case 'price-range': { const y1=Math.min(P[0].y,P[1].y),y2=Math.max(P[0].y,P[1].y);ctx.fillStyle=`${color}12`;ctx.fillRect(0,y1,w,y2-y1);strokeLine({x:0,y:y1},{x:w,y:y1},color,sw);strokeLine({x:0,y:y2},{x:w,y:y2},color,sw);break }
        case 'long-position': case 'short-position': { const x=Math.min(P[0].x,P[1].x),y=Math.min(P[0].y,P[1].y),rw=Math.abs(P[1].x-P[0].x),rh=Math.abs(P[1].y-P[0].y);ctx.strokeStyle=color;ctx.strokeRect(x,y,rw,rh);ctx.fillStyle=`${color}12`;ctx.fillRect(x,y,rw,rh/2);drawLabel(x+4,y+12,shape.tool==='long-position'?'LONG':'SHORT',color,'#fff');break }
        case 'fixed-range-volume-profile': case 'anchored-volume-profile': { const x1=Math.min(P[0].x,P[P.length-1].x),x2=Math.max(P[0].x,P[P.length-1].x); for(let k=0;k<12;k++){const yy=(k+.5)*h/12;const bw=(x2-x1)*(0.15+0.8*Math.sin((k+1)*1.7)**2);ctx.fillStyle=`${color}35`;ctx.fillRect(x2-bw,yy-3,bw,6)} strokeLine({x:x1,y:0},{x:x1,y:h},color,sw);break }
        case 'anchored-vwap': { const y=P[0].y;strokeLine({x:P[0].x,y},{x:w,y},color,sw);drawLabel(P[0].x+4,y-6,'VWAP',color,'#fff');break }
        case 'flag-mark': case 'price-note': case 'pin': case 'signpost': case 'image': case 'x-posts-ideas': case 'price-label': case 'ghost-feed': case 'callout': case 'comment': case 'note': case 'table': case 'emoji': { const labels:any={'flag-mark':'⚑','price-note':fmtPrice(shape.points[0].price),'pin':'📌','signpost':'⚑','image':'🖼','x-posts-ideas':'𝕏','price-label':fmtPrice(shape.points[0].price),'ghost-feed':'Ghost Feed','callout':'Callout','comment':'Comment','note':'Note','table':'Table','emoji':'⭐'};drawLabel(P[0].x+5,P[0].y-5,shape.text||labels[shape.tool],color,'#fff'); if(shape.tool==='ghost-feed'&&P.length>1) strokeLine(P[0],P[1],color,sw); break }
        case 'text': {
          const text = shape.text || ''
          ctx.font = '12px -apple-system, Roboto, sans-serif'
          ctx.fillStyle = color
          ctx.fillText(text, P[0].x + 6, P[0].y - 6)
          if (selected) {
            const tw = ctx.measureText(text).width
            ctx.strokeStyle = `${color}88`
            ctx.setLineDash([3, 3])
            ctx.strokeRect(P[0].x + 2, P[0].y - 18, tw + 10, 20)
            ctx.setLineDash([])
          }
          break
        }
        default: break
      }

      if (selected) {
        drawHandles(anchorPts, sw)
        if (shape.tool === 'fib-retracement' && shape.points.length >= 2) {
          for (const cp of fibCornerPoints(shape.points) ?? []) {
            const q = pxOf(cp)
            if (!q) continue
            const r = 9
            ctx.fillStyle = '#FFFFFF'
            ctx.fillRect(q.x - r, q.y - r, r * 2, r * 2)
            ctx.strokeStyle = '#2962FF'
            ctx.lineWidth = Math.max(2, sw)
            ctx.strokeRect(q.x - r, q.y - r, r * 2, r * 2)
          }
        }
      }
    }

    if (manager.autoPatterns && shapes.length >= 0) {
      const candles = getCandles(); const hits=autoPatternHits(candles);
      for(const hit of hits){ const x=logicalToX(hit.index); const y=priceToY(candles[hit.index]?.close ?? 0); if(x==null||y==null)continue; const col=hit.dir==='up'?'#089981':hit.dir==='down'?'#F23645':'#787B86'; drawLabel(Math.min(w-170,Math.max(4,x+5)),Math.max(12,y-18),hit.name,col,'#fff'); }
    }

    anchorsRef.current = anchors
    if (!forecastSeenRef.current && forecastFingerprintRef.current) {
      forecastFingerprintRef.current = ''
      onForecast?.(null)
    }

    // ── draft preview ──
    const draft = manager.draft
    if (draft && draft.points.length > 0) {
      const draftPts = draft.points.map(pxOf).filter(Boolean) as Px[]
      const cursor = cursorRef.current
      ctx.setLineDash([4, 4])
      ctx.strokeStyle = color6()
      ctx.lineWidth = 4
      if (draftPts.length > 0 && cursor) {
        const meta = TOOL_META[draft.tool]
        if (draft.tool === 'brush') {
          ctx.beginPath()
          ctx.moveTo(draftPts[0].x, draftPts[0].y)
          for (const p of draftPts) ctx.lineTo(p.x, p.y)
          ctx.lineTo(cursor.x, cursor.y)
          ctx.stroke()
        } else if (meta.points === 2) {
          ctx.beginPath()
          ctx.moveTo(draftPts[0].x, draftPts[0].y)
          ctx.lineTo(cursor.x, cursor.y)
          ctx.stroke()
        } else if (meta.points === 3 && draftPts.length >= 2) {
          ctx.beginPath()
          ctx.moveTo(draftPts[draftPts.length - 1].x, draftPts[draftPts.length - 1].y)
          ctx.lineTo(cursor.x, cursor.y)
          ctx.stroke()
        }
      }
      for (const p of draftPts) {
        ctx.beginPath()
        ctx.arc(p.x, p.y, 16, 0, Math.PI * 2)
        ctx.fillStyle = color6()
        ctx.fill()
      }
      ctx.setLineDash([])
    }

    // ── measure overlay ──
    const ms = measureRef.current
    if (ms) {
      const x = Math.min(ms.start.x, ms.end.x)
      const y = Math.min(ms.start.y, ms.end.y)
      const mw = Math.abs(ms.end.x - ms.start.x)
      const mh = Math.abs(ms.end.y - ms.start.y)
      ctx.fillStyle = ms.start.y > ms.end.y ? 'rgba(8, 153, 129, 0.12)' : 'rgba(242, 54, 69, 0.12)'
      ctx.fillRect(x, y, mw, mh)
      ctx.strokeStyle = crossColor
      ctx.lineWidth = 1
      ctx.setLineDash([4, 3])
      ctx.strokeRect(x, y, mw, mh)
      ctx.setLineDash([])

      // stats
      const l1 = xToLogical(ms.start.x)
      const l2 = xToLogical(ms.end.x)
      const p1 = yToPrice(ms.start.y)
      const p2 = yToPrice(ms.end.y)
      if (l1 != null && l2 != null && p1 != null && p2 != null) {
        const dP = p2 - p1
        const pct = p1 !== 0 ? (dP / p1) * 100 : 0
        const bars = Math.abs(Math.round(l2 - l1))
        const candles = getCandles()
        const i1 = candles[Math.round(l1)]
        const i2 = candles[Math.round(l2)]
        const dur = i1 && i2 ? Math.abs(i2.time - i1.time) : null
        const lines = [
          `${dP >= 0 ? '+' : ''}${fmtPrice(dP)} (${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%)`,
          `${bars} bars${dur != null ? ` · ${fmtDuration(dur)}` : ''}`,
        ]
        ctx.font = '11px -apple-system, Roboto, sans-serif'
        const bw = Math.max(...lines.map((t) => ctx.measureText(t).width)) + 16
        const bx = x + mw / 2 - bw / 2
        const by = y - 40
        ctx.fillStyle = dark ? '#1E222D' : '#FFFFFF'
        ctx.strokeStyle = dark ? '#2A2E39' : '#E0E3EB'
        ctx.beginPath()
        ctx.roundRect?.(bx, by, bw, 38, 6)
        if (!ctx.roundRect) ctx.rect(bx, by, bw, 38)
        ctx.fill()
        ctx.stroke()
        ctx.fillStyle = dP >= 0 ? '#089981' : '#F23645'
        ctx.fillText(lines[0], bx + 8, by + 15)
        ctx.fillStyle = textColor
        ctx.fillText(lines[1], bx + 8, by + 29)
      }
    }

    function color6() { return '#2962FF' }
  }, [manager, getChart, getSeries, getCandles, dark, xToLogical, yToPrice, priceToY, pxOf, onForecast])

  // ─────────────────────────────────────────────── rAF probe loop
  useEffect(() => {
    let raf = 0
    let lastKey = ''
    const tick = () => {
      const chart = getChart()
      const series = getSeries()
      const candles = getCandles()
      if (chart && series) {
        try {
          const range = chart.timeScale().getVisibleLogicalRange()
          const lastClose = candles.length > 0 ? candles[candles.length - 1].close : 1
          const probeY = series.priceToCoordinate(lastClose)
          const key = `${range ? range.from.toFixed(2) + ':' + range.to.toFixed(2) : '-'}|${probeY ?? '-'}|${sizeRef.current.w}x${sizeRef.current.h}`
          if (key !== lastKey) { lastKey = key; dirtyRef.current = true }
        } catch { /* noop */ }
      }
      if (dirtyRef.current) {
        dirtyRef.current = false
        render()
      }
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [render, getChart, getSeries, getCandles])

  // ─────────────────────────────────────────────── interactions
  useEffect(() => {
    // Listeners live on the HOST container: the lightweight-charts canvas is a
    // CHILD of the host, so capture-phase interception works while the drawing
    // overlay itself stays pointer-events:none.
    const container = hostRef.current ?? containerRef.current
    if (!container) return

    const onPointerDown = (e: PointerEvent) => {
      if (e.button !== 0) return
      try { container.setPointerCapture(e.pointerId) } catch { /* noop */ }
      const rect = container.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top

      // measure tool: first click clears a done measurement
      if (measureRef.current?.done && manager.activeTool !== 'measure') {
        measureRef.current = null
        dirtyRef.current = true
      }

      if (manager.activeTool !== 'cursor') {
        e.stopPropagation() // the chart must not pan while drawing
        e.preventDefault()

        if (manager.activeTool === 'measure') {
          if (measureRef.current?.done) {
            measureRef.current = null
          }
          measureRef.current = { start: { x, y }, end: { x, y }, done: false }
          dragRef.current = { kind: 'measure', lastLogical: 0, lastPrice: 0 }
          dirtyRef.current = true
          return
        }

        if (manager.activeTool === 'text') {
          const pt = pointFromXY(x, y)
          if (!pt) return
          manager.addDraftPoint(pt, getCandles())
          const draft = manager.draft
          if (draft) {
            setTextInput({ id: draft.id, x, y, value: '' })
          }
          return
        }

        if (manager.activeTool === 'brush') {
          const pt = pointFromXY(x, y)
          if (!pt) return
          manager.addDraftPoint(pt, getCandles())
          dragRef.current = { kind: 'brush', lastLogical: pt.logical, lastPrice: pt.price }
          return
        }

        const pt = pointFromXY(x, y)
        if (!pt) return
        const finished = manager.addDraftPoint(pt, getCandles())
        if (finished) {
          manager.finishDraft(getCandles())
          // keep the tool active for consecutive drawings (TV behaviour)
        }
        dirtyRef.current = true
        return
      }

      // cursor mode: selection / dragging
      const selectedFib = manager.selectedId ? manager.byId(manager.selectedId) : null
      if (selectedFib?.tool === 'fib-retracement' && selectedFib.points.length >= 2) {
        const corners = (fibCornerPoints(selectedFib.points) ?? []).map(pxOf).filter(Boolean) as Px[]
        const idx = corners.findIndex(q => Math.hypot(q.x - x, q.y - y) <= 18)
        if (idx >= 0) {
          e.stopPropagation()
          dragRef.current = { kind: 'fib-corner', id: selectedFib.id, fibCorner: idx as FibCorner, lastLogical: 0, lastPrice: 0 }
          dirtyRef.current = true
          return
        }
      }
      // Fibonacci level bars are draggable as a whole. Clicking anywhere in
      // the 0/1 (or any visible level) bar now moves the complete grid.
      let fibBarHit: DrawingShape | null = null
      for (const candidate of manager.shapes) {
        if (candidate.tool !== 'fib-retracement' || candidate.points.length < 2) continue
        const cp = candidate.points.map(pxOf)
        if (cp.some(v => !v)) continue
        const left = Math.min((cp[0] as Px).x, (cp[1] as Px).x)
        const right = Math.max((cp[0] as Px).x, (cp[1] as Px).x)
        if (x < left - 10 || x > right + 10) continue
        const aa = candidate.points[0].price, bb = candidate.points[1].price
        const levels = (candidate.fibLevels !== undefined ? candidate.fibLevels : [...FIB_LEVELS]).filter(Number.isFinite)
        for (const lvl of levels) {
          const price = candidate.fibFlipped ? bb + (aa - bb) * lvl : aa + (bb - aa) * lvl
          const ly = priceToY(price)
          if (ly != null && Math.abs(ly - y) <= 10) { fibBarHit = candidate; break }
        }
        if (fibBarHit) break
      }
      if (fibBarHit) {
        e.stopPropagation()
        manager.select(fibBarHit.id)
        const pt = pointFromXY(x, y)
        if (pt) dragRef.current = { kind: 'shape', id: fibBarHit.id, lastLogical: pt.logical, lastPrice: pt.price }
        dirtyRef.current = true
        return
      }

      const hitId = manager.hitTest(x, y, anchorsRef.current)
      if (hitId) {
        e.stopPropagation()
        manager.select(hitId)
        const shape = manager.byId(hitId)
        if (shape) {
          const px = shape.points.map(pxOf).filter(Boolean) as Px[]
          const handleIdx = manager.hitPointHandle(x, y, px)
          if (handleIdx >= 0) {
            dragRef.current = { kind: 'point', id: hitId, pointIdx: handleIdx, lastLogical: 0, lastPrice: 0 }
          } else {
            const pt = pointFromXY(x, y)
            if (pt) dragRef.current = { kind: 'shape', id: hitId, lastLogical: pt.logical, lastPrice: pt.price }
          }
        }
        dirtyRef.current = true
      } else {
        manager.select(null)
        dirtyRef.current = true
      }
    }

    const onPointerMove = (e: PointerEvent) => {
      if (manager.activeTool !== 'cursor' || dragRef.current) {
        e.preventDefault()
        e.stopPropagation()
      }
      const rect = container.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top
      cursorRef.current = { x, y }

      const drag = dragRef.current
      if (drag?.kind === 'measure' && measureRef.current && !measureRef.current.done) {
        measureRef.current.end = { x, y }
        dirtyRef.current = true
        return
      }

      if (drag?.kind === 'brush') {
        const pt = pointFromXY(x, y)
        if (pt) manager.addDraftPoint(pt, getCandles())
        dirtyRef.current = true
        return
      }

      if (drag?.kind === 'fib-corner' && drag.id != null && drag.fibCorner != null) {
        const pt = pointFromXY(x, y)
        const shape = manager.byId(drag.id)
        if (pt && shape?.tool === 'fib-retracement' && shape.points.length >= 2 && !shape.locked && !manager.lockAll) {
          const p0 = shape.points[0], p1 = shape.points[1]
          let minL = Math.min(p0.logical, p1.logical), maxL = Math.max(p0.logical, p1.logical)
          let minP = Math.min(p0.price, p1.price), maxP = Math.max(p0.price, p1.price)
          const left0 = p0.logical <= p1.logical, high0 = p0.price >= p1.price
          if (drag.fibCorner === 0 || drag.fibCorner === 2) minL = pt.logical; else maxL = pt.logical
          if (drag.fibCorner === 0 || drag.fibCorner === 1) maxP = pt.price; else minP = pt.price
          const make = (zero: boolean): DrawingPoint => ({ logical: (zero ? left0 : !left0) ? minL : maxL, price: (zero ? high0 : !high0) ? maxP : minP })
          manager.movePoint(shape.id, 0, make(true))
          manager.movePoint(shape.id, 1, make(false))
        }
        dirtyRef.current = true
        return
      }

      if (drag?.kind === 'point' && drag.id != null) {
        const pt = pointFromXY(x, y)
        if (pt) manager.movePoint(drag.id, drag.pointIdx ?? 0, pt)
        dirtyRef.current = true
        return
      }

      if (drag?.kind === 'shape' && drag.id != null) {
        const pt = pointFromXY(x, y)
        if (pt) {
          const dL = pt.logical - drag.lastLogical
          const dP = pt.price - drag.lastPrice
          drag.lastLogical = pt.logical
          drag.lastPrice = pt.price
          if (dL !== 0 || dP !== 0) manager.translate(drag.id, dL, dP)
        }
        dirtyRef.current = true
        return
      }

      if (!dragRef.current && manager.activeTool === 'cursor') {
        const selected = manager.selectedId ? manager.byId(manager.selectedId) : null
        let cursor = 'default'
        if (selected?.tool === 'fib-retracement' && selected.points.length >= 2) {
          const corners = (fibCornerPoints(selected.points) ?? []).map(pxOf).filter(Boolean) as Px[]
          const ci = corners.findIndex(q => Math.hypot(q.x - x, q.y - y) <= 18)
          if (ci === 0 || ci === 3) cursor = 'nwse-resize'
          else if (ci === 1 || ci === 2) cursor = 'nesw-resize'
        }
        container.style.cursor = cursor
      }
      // hover feedback for draft previews
      if (manager.draft) dirtyRef.current = true
    }

    const onPointerUp = () => {
      const drag = dragRef.current
      if (drag?.kind === 'brush' || drag?.kind === 'shape') {
        const d = manager.draft
        if (d && ['brush','polyline','path','curve','double-curve','highlighter'].includes(d.tool)) manager.finishDraft(getCandles())
      }
      if (drag?.kind === 'measure' && measureRef.current) {
        measureRef.current.done = true
      }
      dragRef.current = null
      dirtyRef.current = true
    }

    const onDblClick = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect()
      const x = e.clientX - rect.left
      const y = e.clientY - rect.top
      const hitId = manager.hitTest(x, y, anchorsRef.current)
      if (hitId) {
        const shape = manager.byId(hitId)
        if (shape?.tool === 'text') {
          e.stopPropagation()
          const px = pxOf(shape.points[0])
          if (px) setTextInput({ id: shape.id, x: px.x, y: px.y, value: shape.text || '' })
        }
      }
    }

    container.addEventListener('pointerdown', onPointerDown, true)
    container.addEventListener('pointermove', onPointerMove, true)
    container.addEventListener('dblclick', onDblClick, true)
    window.addEventListener('pointerup', onPointerUp, true)
    window.addEventListener('pointercancel', onPointerUp, true)
    return () => {
      container.removeEventListener('pointerdown', onPointerDown, true)
      container.removeEventListener('pointermove', onPointerMove, true)
      container.removeEventListener('dblclick', onDblClick, true)
      window.removeEventListener('pointerup', onPointerUp, true)
      window.removeEventListener('pointercancel', onPointerUp, true)
    }
  }, [manager, pointFromXY, pxOf, getCandles])

  // ─────────────────────────────────────────────── keyboard
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        manager.cancelDraft()
        if (manager.activeTool !== 'cursor') manager.setTool('cursor')
        if (measureRef.current) { measureRef.current = null; dirtyRef.current = true }
      }
      if ((e.key === 'Delete' || e.key === 'Backspace') && manager.selectedId) {
        const target = e.target as HTMLElement
        if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA') return
        manager.deleteSelected()
        dirtyRef.current = true
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [manager])

  const commitText = () => {
    if (textInput) {
      const shape = manager.byId(textInput.id)
      if (shape) {
        if (textInput.value.trim() === '') manager.deleteShape(textInput.id)
        else manager.updateText(textInput.id, textInput.value)
      } else {
        // shape still a draft → finish then update
        const draft = manager.draft
        if (draft && draft.id === textInput.id) {
          if (textInput.value.trim() === '') manager.cancelDraft()
          else {
            manager.finishDraft(getCandles())
            manager.updateText(textInput.id, textInput.value)
          }
        }
      }
    }
    setTextInput(null)
    dirtyRef.current = true
  }

  const crosshairActive = manager.activeTool !== 'cursor'

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 z-[5]"
      style={{ pointerEvents: 'none', cursor: crosshairActive ? 'crosshair' : 'default', touchAction: crosshairActive ? 'none' : 'auto' }}
    >
      <canvas ref={canvasRef} className="absolute inset-0" />
      {(() => {
        const selected = manager.selectedId ? manager.byId(manager.selectedId) : null
        const fib = selected?.tool === 'fib-retracement' && selected.points.length >= 2 ? selected : null
        if (!fib) return null
        const activeLevels = fib.fibLevels !== undefined ? fib.fibLevels : [...FIB_LEVELS]
        return (
          <div
            className="absolute top-2 right-2 z-30 w-[226px] rounded-lg border shadow-xl text-[9px]"
            style={{ pointerEvents: 'auto', background: dark ? 'rgba(15,17,23,0.97)' : 'rgba(255,255,255,0.97)', borderColor: dark ? '#2A2E39' : '#D8DCE4', color: dark ? '#D1D4DC' : '#131722' }}
            onPointerDown={(e) => e.stopPropagation()}
          >
            <div className="px-2 py-1.5 flex items-center justify-between border-b" style={{ borderColor: dark ? '#2A2E39' : '#E5E7EB' }}>
              <span className="font-bold uppercase tracking-wide">Fibonacci · Smart Forecast</span>
              <button type="button" className="rounded px-1.5 py-0.5 border" style={{ borderColor: dark ? '#3B4250' : '#D8DCE4' }} onClick={() => manager.updateSelectedFibSettings({ fibFlipped: !(fib.fibFlipped === true) })}>↔ Flip</button>
            </div>
            <div className="p-2 space-y-2">
              <fieldset>
                <legend className="mb-1 font-semibold">Fibonacci Retracement levels</legend>
                <div className="space-y-1">
                  {FIB_LEVELS.map((lvl) => {
                    const checked = activeLevels.some(v => Math.abs(v - lvl) < 1e-9)
                    return (
                      <label key={lvl} className="flex items-center justify-between rounded px-1.5 py-1 cursor-pointer" style={{ background: checked ? 'rgba(41,98,255,0.10)' : 'transparent' }}>
                        <span className="flex items-center gap-1.5">
                          <input
                            type="checkbox"
                            checked={checked}
                            onChange={() => {
                              const next = checked
                                ? activeLevels.filter(v => Math.abs(v - lvl) >= 1e-9)
                                : [...activeLevels, lvl].sort((a,b) => a-b)
                              manager.updateSelectedFibSettings({ fibLevels: next })
                            }}
                            className="h-3.5 w-3.5 accent-[#2962FF]"
                          />
                          <span>{lvl}</span>
                        </span>
                        <span className="text-[8px] text-zinc-500">{checked ? 'ON' : 'OFF'}</span>
                      </label>
                    )
                  })}
                </div>
              </fieldset>
              <label className="flex items-center justify-between gap-2">
                <span className="font-semibold">Lookback</span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    step={1}
                    value={fibLookbackDraft}
                    onChange={(e) => setFibLookbackDraft(e.target.value)}
                    onBlur={() => {
                      const parsed = Number(fibLookbackDraft)
                      const value = Number.isFinite(parsed) ? Math.max(1, Math.round(parsed)) : 30
                      setFibLookbackDraft(String(value))
                      manager.updateSelectedFibSettings({ forecastLookback: value })
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') (e.currentTarget as HTMLInputElement).blur()
                    }}
                    className="w-16 rounded border px-1 py-0.5 bg-transparent text-right"
                  />
                  <span className="text-zinc-500">bars</span>
                </div>
              </label>
              <div className="text-[8px] text-zinc-500">Direction is calculated from the last bars. Future candles are chronological and limited to the next 3–8 bars.</div>
            </div>
          </div>
        )
      })()}
      {textInput && (
        <input
          autoFocus
          value={textInput.value}
          onChange={(e) => setTextInput({ ...textInput, value: e.target.value })}
          onBlur={commitText}
          onKeyDown={(e) => {
            if (e.key === 'Enter') commitText()
            if (e.key === 'Escape') {
              manager.cancelDraft()
              setTextInput(null)
            }
          }}
          className="absolute z-20 px-2 py-1 text-xs rounded border shadow-lg outline-none"
          style={{
            left: textInput.x,
            top: textInput.y - 14,
            width: 160,
            background: dark ? '#1E222D' : '#FFFFFF',
            borderColor: '#2962FF',
            color: dark ? '#D1D4DC' : '#131722',
          }}
          placeholder="Text…"
        />
      )}
    </div>
  )
}

export type { DrawingShape }
