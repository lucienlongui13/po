'use client'

/**
 * indicators-menu.tsx — TradingView-style "Indicators" dialog.
 *
 * Search across all 55 indicators, browse by category, manage the
 * active instances (visibility / remove) in the "Active" tab.
 */

import { useEffect, useMemo, useRef, useState } from 'react'
import { Search, X, Plus, Eye, EyeOff, Trash2 } from 'lucide-react'

import {
  INDICATORS, CATEGORY_LABELS, searchIndicators, indicatorTitle,
  type IndicatorCategory,
} from '@/lib/indicators-library'
import { useTVStore } from '@/lib/tv-store'

const CATEGORY_ORDER: IndicatorCategory[] = [
  'moving-averages', 'trend', 'momentum', 'oscillators',
  'volatility', 'volume', 'bill-williams',
]

type Tab = 'all' | IndicatorCategory | 'active'

function TabBtn({ id, label, tab, setTab, subtext }: {
  id: Tab; label: string; tab: Tab; setTab: (t: Tab) => void; subtext: string
}) {
  return (
    <button
      onClick={() => setTab(id)}
      className="px-3 py-1.5 text-[11px] rounded-md whitespace-nowrap transition-colors"
      style={{
        background: tab === id ? '#2962FF' : 'transparent',
        color: tab === id ? '#fff' : subtext,
        fontWeight: tab === id ? 600 : 400,
      }}
    >
      {label}
    </button>
  )
}

export function IndicatorsMenu({ dark }: { dark: boolean }) {
  const open = useTVStore((s) => s.indicatorsMenuOpen)
  const setOpen = useTVStore((s) => s.setIndicatorsMenuOpen)
  const indicators = useTVStore((s) => s.indicators)
  const addIndicator = useTVStore((s) => s.addIndicator)
  const removeIndicator = useTVStore((s) => s.removeIndicator)
  const toggleVisible = useTVStore((s) => s.toggleIndicatorVisible)

  const [query, setQuery] = useState('')
  const [tab, setTab] = useState<Tab>('all')
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (open) {
      const t = setTimeout(() => {
        setQuery('')
        setTab('all')
        inputRef.current?.focus()
      }, 50)
      return () => clearTimeout(t)
    }
  }, [open])

  const results = useMemo(() => {
    const found = searchIndicators(query)
    if (tab === 'all') return found
    return found.filter((d) => d.category === tab)
  }, [query, tab])

  if (!open) return null

  const bg = dark ? '#131722' : '#FFFFFF'
  const surface = dark ? '#1E222D' : '#FFFFFF'
  const border = dark ? '#2A2E39' : '#E0E3EB'
  const text = dark ? '#D1D4DC' : '#131722'
  const subtext = dark ? '#787B86' : '#787B86'

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-[8vh]"
      style={{ background: 'rgba(0,0,0,0.5)' }}
      onClick={() => setOpen(false)}
    >
      <div
        className="w-[640px] max-w-[92vw] rounded-lg border shadow-2xl flex flex-col"
        style={{ background: bg, borderColor: border, maxHeight: '76vh' }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* search header */}
        <div className="flex items-center gap-2 px-4 py-3 border-b" style={{ borderColor: border }}>
          <Search className="h-4 w-4 shrink-0" style={{ color: subtext }} />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && results.length > 0) {
                addIndicator(results[0].id)
                setOpen(false)
              }
              if (e.key === 'Escape') setOpen(false)
            }}
            placeholder="Search indicators…"
            className="flex-1 bg-transparent outline-none text-sm"
            style={{ color: text }}
          />
          <button onClick={() => setOpen(false)} className="p-1 rounded hover:bg-black/10">
            <X className="h-4 w-4" style={{ color: subtext }} />
          </button>
        </div>

        {/* category tabs */}
        <div className="flex gap-1 px-3 py-2 border-b overflow-x-auto" style={{ borderColor: border }}>
          <TabBtn id="all" label="All" tab={tab} setTab={setTab} subtext={subtext} />
          {CATEGORY_ORDER.map((c) => (
            <TabBtn key={c} id={c} label={CATEGORY_LABELS[c]} tab={tab} setTab={setTab} subtext={subtext} />
          ))}
          <TabBtn id="active" label={`Active (${indicators.length})`} tab={tab} setTab={setTab} subtext={subtext} />
        </div>

        {/* list */}
        <div className="flex-1 overflow-y-auto min-h-[240px]">
          {tab === 'active' ? (
            indicators.length === 0 ? (
              <div className="p-6 text-center text-xs" style={{ color: subtext }}>
                No indicators applied. Pick one from the other tabs.
              </div>
            ) : (
              indicators.map((inst) => {
                const def = INDICATORS.find((d) => d.id === inst.defId)
                if (!def) return null
                return (
                  <div
                    key={inst.uid}
                    className="flex items-center justify-between px-4 py-2.5 hover:bg-black/20"
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className="inline-block w-2.5 h-2.5 rounded-full"
                        style={{ background: def.plots[0]?.color ?? '#2962FF' }}
                      />
                      <span className="text-sm" style={{ color: text }}>{def.name}</span>
                      <span className="text-[11px]" style={{ color: subtext }}>
                        {indicatorTitle(def, inst.params)}
                      </span>
                      <span
                        className="text-[10px] px-1.5 py-0.5 rounded"
                        style={{ background: surface, color: subtext }}
                      >
                        {def.pane === 'main' ? 'overlay' : 'pane'}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <button
                        title={inst.visible ? 'Hide' : 'Show'}
                        onClick={() => toggleVisible(inst.uid)}
                        className="p-1.5 rounded hover:bg-black/10"
                      >
                        {inst.visible
                          ? <Eye className="h-3.5 w-3.5" style={{ color: subtext }} />
                          : <EyeOff className="h-3.5 w-3.5" style={{ color: '#F23645' }} />}
                      </button>
                      <button
                        title="Remove"
                        onClick={() => removeIndicator(inst.uid)}
                        className="p-1.5 rounded hover:bg-black/10"
                      >
                        <Trash2 className="h-3.5 w-3.5" style={{ color: subtext }} />
                      </button>
                    </div>
                  </div>
                )
              })
            )
          ) : (
            results.map((def) => (
              <button
                key={def.id}
                onClick={() => { addIndicator(def.id); setOpen(false) }}
                className="w-full flex items-center justify-between px-4 py-2.5 text-left hover:bg-black/20 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <span className="text-sm" style={{ color: text }}>{def.name}</span>
                  <span className="text-[11px]" style={{ color: subtext }}>
                    {CATEGORY_LABELS[def.category]}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className="text-[10px] px-1.5 py-0.5 rounded"
                    style={{ background: surface, color: subtext }}
                  >
                    {def.pane === 'main' ? 'overlay' : 'pane'}
                  </span>
                  <Plus className="h-4 w-4" style={{ color: '#2962FF' }} />
                </div>
              </button>
            ))
          )}
          {tab !== 'active' && results.length === 0 && (
            <div className="p-6 text-center text-xs" style={{ color: subtext }}>
              No indicator matches “{query}”.
            </div>
          )}
        </div>

        <div className="px-4 py-2 border-t text-[10px]" style={{ borderColor: border, color: subtext }}>
          {INDICATORS.length} indicators · Pine-compatible formulas · Click to apply
        </div>
      </div>
    </div>
  )
}
