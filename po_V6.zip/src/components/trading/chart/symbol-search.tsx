'use client'

/**
 * symbol-search.tsx — TradingView-style symbol search dialog.
 */

import { useEffect, useMemo, useRef, useState } from 'react'
import { Search, X } from 'lucide-react'

export interface SymbolItem {
  ticker: string
  name: string
  payout?: number
  isOtc?: boolean
}

interface SymbolSearchProps {
  open: boolean
  onClose: () => void
  onSelect: (ticker: string) => void
  items: SymbolItem[]
  active: string
  dark: boolean
}

export function SymbolSearch({ open, onClose, onSelect, items, active, dark }: SymbolSearchProps) {
  const [query, setQuery] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (open) {
      const t = setTimeout(() => {
        setQuery('')
        inputRef.current?.focus()
      }, 50)
      return () => clearTimeout(t)
    }
  }, [open])

  const results = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return items.slice(0, 80)
    return items
      .filter((i) => i.ticker.toLowerCase().includes(q) || i.name.toLowerCase().includes(q))
      .slice(0, 80)
  }, [query, items])

  if (!open) return null

  const bg = dark ? '#131722' : '#FFFFFF'
  const border = dark ? '#2A2E39' : '#E0E3EB'
  const text = dark ? '#D1D4DC' : '#131722'
  const sub = '#787B86'

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-[10vh]"
      style={{ background: 'rgba(0,0,0,0.5)' }}
      onClick={onClose}
    >
      <div
        className="w-[520px] max-w-[92vw] rounded-lg border shadow-2xl flex flex-col"
        style={{ background: bg, borderColor: border, maxHeight: '70vh' }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-2 px-4 py-3 border-b" style={{ borderColor: border }}>
          <Search className="h-4 w-4" style={{ color: sub }} />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && results.length > 0) {
                onSelect(results[0].ticker)
                onClose()
              }
              if (e.key === 'Escape') onClose()
            }}
            placeholder="Search symbol…"
            className="flex-1 bg-transparent outline-none text-sm"
            style={{ color: text }}
          />
          <button onClick={onClose} className="p-1 rounded hover:bg-black/10">
            <X className="h-4 w-4" style={{ color: sub }} />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto">
          {results.map((it) => (
            <button
              key={it.ticker}
              onClick={() => { onSelect(it.ticker); onClose() }}
              className="w-full flex items-center justify-between px-4 py-2.5 text-left hover:bg-black/20"
              style={{
                background: it.ticker === active ? (dark ? '#1E222D' : '#F0F3FA') : 'transparent',
              }}
            >
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold" style={{ color: text }}>{it.ticker}</span>
                <span className="text-[11px] truncate max-w-[240px]" style={{ color: sub }}>{it.name}</span>
              </div>
              <div className="flex items-center gap-2">
                {it.isOtc && (
                  <span className="text-[10px] px-1.5 py-0.5 rounded" style={{ background: dark ? '#2A2E39' : '#F0F3FA', color: sub }}>
                    OTC 24/7
                  </span>
                )}
                {it.payout != null && (
                  <span className="text-[11px] font-semibold" style={{ color: '#089981' }}>{it.payout}%</span>
                )}
              </div>
            </button>
          ))}
          {results.length === 0 && (
            <div className="p-6 text-center text-xs" style={{ color: sub }}>
              No symbol matches “{query}”.
            </div>
          )}
        </div>

        <div className="px-4 py-2 border-t text-[10px]" style={{ borderColor: border, color: sub }}>
          {items.length} Pocket Option assets · OTC markets trade 24/7
        </div>
      </div>
    </div>
  )
}
