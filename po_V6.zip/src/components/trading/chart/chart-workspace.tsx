'use client'

/**
 * chart-workspace.tsx — the BIG TradingView-style chart area.
 *
 * Orchestrates:
 *  - main chart (7 chart styles: candles, hollow, bars, line, area,
 *    baseline, Heikin Ashi) with the anti-jitter anchor series
 *  - overlay indicators (incl. Volume) on the main pane
 *  - synchronized oscillator sub-panes (range + crosshair + legends)
 *  - the drawing layer (canvas) + drawings keyed per market:timeframe
 *  - live streaming via LiveEngine  ·  replay streaming via ReplayEngine
 *  - price alerts as price lines
 *  - TradingView legend (symbol · O H L C · change · indicator values)
 */

import {
  useCallback, useEffect, useMemo, useRef, useState,
} from 'react'
import {
  createChart, LineStyle, PriceScaleMode,
  type IChartApi, type ISeriesApi, type Time, type LogicalRange,
  type IPriceLine,
} from 'lightweight-charts'
import { Eye, EyeOff, Settings2, X } from 'lucide-react'

import type { LiveEngine, CandleFlush } from '@/lib/live-engine'
import type { CandleLike } from '@/lib/indicators'
import { INDICATOR_MAP, indicatorTitle, formatIndicatorValue, TV } from '@/lib/indicators-library'
import { TIMEFRAMES } from '@/hooks/use-pocket-option'
import type { ReplayEngine } from '@/lib/replay-engine'
import { DrawingManager } from '@/lib/drawings'
import { useTVStore, type IndicatorInstance, type ChartStyle, type IndicatorPlotSettings } from '@/lib/tv-store'

import { baseChartOptions, themeFor } from './chart-theme'
import { DrawingLayer, type SmartTraderForecast } from './drawing-layer'
import { SubPane, type SubPaneHandle } from './sub-pane'
import { ReplayBar } from './replay-bar'
import { TradeMarkersOverlay, type TradeMarkerRecord } from './trade-markers-overlay'
import { usePineStore } from '@/lib/pine-store'
import {
  alignPineSeries, diagnosePineAlignment, logPineAlignmentDiagnostics,
  pineTimeToChartTime, toPineTime, type AlignDiagnostic,
} from '@/lib/pine-time-axis'
import { PineDrawingsOverlay, PineTablesOverlay } from './pine-drawings-overlay'
import { PineSubPane } from './pine-sub-pane'
import { toast } from 'sonner'
import { BosChochCisdOverlay } from './bos-choch-cisd-overlay'

interface ChartWorkspaceProps {
  engine: LiveEngine
  replay: ReplayEngine
  drawings: DrawingManager
  dark: boolean
  marketName: string
  activeId: number
  candleSize: number
  tradeVisuals?: TradeMarkerRecord[]
  onForecast?: (forecast: SmartTraderForecast | null) => void
  /**
   * Couche visuelle L_Lucien ProTrader (pack Pine) : montée quand la
   * stratégie Auto Trade « l_lucien_protrader » est sélectionnée ou
   * testée — rend les labels/lignes EXACTS du pack, pilotés par ses
   * réglages (tags et libellés masqués par défaut via le switch du
   * panneau Auto Trade).
   */
  bosChochCisdActive?: boolean
}

interface OverlayEntry {
  series: Map<string, ISeriesApi<'Line'> | ISeriesApi<'Histogram'>>
  computed: Record<string, (number | null)[]> | null
  paramsKey: string
}

/** Map a Pine plotshape glyph to a lightweight-charts marker shape. */
function markerShapeFor(marker: { kind: string; glyph: string }): 'circle' | 'square' | 'arrowUp' | 'arrowDown' {
  const glyph = String(marker.glyph || '').toLowerCase()
  if (marker.kind === 'arrow' || glyph.includes('triangleup') || glyph.includes('arrowup')) return 'arrowUp'
  if (marker.kind === 'arrow' || glyph.includes('triangledown') || glyph.includes('arrowdown')) return 'arrowDown'
  if (glyph.includes('square')) return 'square'
  return 'circle'
}

const UP = '#089981'
const DOWN = '#F23645'

function heikinAshi(candles: CandleLike[]): CandleLike[] {
  const out: CandleLike[] = []
  let prevOpen = 0
  let prevClose = 0
  for (let i = 0; i < candles.length; i++) {
    const c = candles[i]
    const close = (c.open + c.high + c.low + c.close) / 4
    const open = i === 0 ? (c.open + c.close) / 2 : (prevOpen + prevClose) / 2
    const high = Math.max(c.high, open, close)
    const low = Math.min(c.low, open, close)
    out.push({ time: c.time, open, high, low, close, volume: c.volume })
    prevOpen = open
    prevClose = close
  }
  return out
}

// ══════════════════════════════════════════════ overlay indicator rendering (module scope)
function renderOverlayIndicatorsImpl(
  chartRefHolder: IChartApi | null,
  dark: boolean,
  overlayInstances: IndicatorInstance[],
  volumeInstance: IndicatorInstance | null,
  volumeSeries: ISeriesApi<'Histogram'> | null,
  overlayRef: Map<string, OverlayEntry>,
  candles: CandleLike[],
  mode: 'full' | 'tail',
) {
      const chart = chartRefHolder
    if (!chart || candles.length === 0) return
    const n = candles.length
    const tf = n > 1 ? candles[1].time - candles[0].time : 60
    const hasLiveFractal = overlayInstances.some((i) => i.defId === 'fractal-custom')
    const hasNinjaFractal = overlayInstances.some((i) => i.defId === 'live-fractal-ninja')
    const hasFtFp = overlayInstances.some((i) => i.defId === 'fractal-trigonometric-forecast')
    const hasWtr = overlayInstances.some((i) => i.defId === 'wave-trend-resonance')
    const compareFractals = hasLiveFractal && hasNinjaFractal
    const separateFtFpFromLive = hasLiveFractal && hasFtFp

    // Marker placement is a rendering concern only. Lightweight Charts marker
    // positions are discrete (aboveBar/belowBar/inBar), so we deliberately
    // give the FTFP and Fractal Custom — Live markers different slots instead
    // of moving the indicator values or changing their calculations.
    const visualAtr = (idx: number): number => {
      const start = Math.max(0, idx - 13)
      let sum = 0
      let count = 0
      for (let j = start; j <= idx; j++) {
        const c = candles[j]
        const prevClose = j > 0 ? candles[j - 1].close : c.close
        const range = Math.max(
          c.high - c.low,
          Math.abs(c.high - prevClose),
          Math.abs(c.low - prevClose),
        )
        if (Number.isFinite(range) && range > 0) { sum += range; count++ }
      }
      return count ? sum / count : 1e-8
    }

    const visualMarkerValue = (
      instId: string,
      plotKey: string,
      value: number,
      idx: number,
    ): number => {
      const c = candles[idx]
      const atr = visualAtr(idx)
      const direction = (plotKey === 'up' || plotKey === 'buy') ? -1 : 1

      // When WTR is visible, use the in-bar slot with deterministic vertical
      // clearances. Lightweight Charts only has three marker slots; using the
      // marker's price value for inBar lets three independent predictors remain
      // visibly separated without changing any indicator calculations.
      if (hasWtr) {
        const factor = instId === 'wave-trend-resonance'
          ? 0.30
          : instId === 'fractal-trigonometric-forecast'
            ? 0.60
            : instId === 'fractal-custom'
              ? 0.90
              : 1.10
        const clearance = Math.max(atr * factor, (c.high - c.low) * 0.20, 1e-8)
        return value + direction * clearance
      }

      if (!compareFractals || (instId !== 'fractal-custom' && instId !== 'live-fractal-ninja')) return value
      // Legacy spacing when WTR is not enabled.
      const factor = instId === 'fractal-custom' ? 0.45 : 0.95
      const clearance = Math.max(atr * factor, (c.high - c.low) * 0.25, 1e-8)
      return value + direction * clearance
    }


    for (const inst of overlayInstances) {
      const def = INDICATOR_MAP.get(inst.defId)
      if (!def) continue

      // Volume is rendered by its dedicated histogram series
      if (inst.defId === 'volume') {
        const vol = volumeSeries
        if (!vol) continue
        if (!inst.visible) { if (mode === 'full') vol.setData([]); continue }
        const theme = themeFor(dark)
        if (vol) {
          if (mode === 'full') {
            vol.setData(candles.map((c) => ({
              time: c.time as Time,
              value: c.volume,
              color: c.close >= c.open ? theme.volumeUp : theme.volumeDown,
            })))
          } else {
            const c = candles[n - 1]
            try {
              vol.update({ time: c.time as Time, value: c.volume, color: c.close >= c.open ? theme.volumeUp : theme.volumeDown })
            } catch { /* noop */ }
          }
        }
        // Volume MA line
        const entry = overlayRef.get(inst.uid)
        if (entry) {
          const maSeries = entry.series.get('ma') as ISeriesApi<'Line'> | undefined
          if (maSeries) {
            let computed: Record<string, (number | null)[]>
            try { computed = def.compute(candles, inst.params) } catch { continue }
            const arr = computed['ma']
            if (arr) {
              if (mode === 'full') {
                const data: Array<{ time: Time; value: number }> = []
                for (let i = 0; i < n; i++) {
                  const v = arr[i]
                  if (v == null || !Number.isFinite(v)) continue
                  data.push({ time: candles[i].time as Time, value: v })
                }
                maSeries.setData(data)
              } else {
                for (let k = Math.max(0, n - 2); k < n; k++) {
                  const v = arr[k]
                  if (v == null || !Number.isFinite(v)) continue
                  try { maSeries.update({ time: candles[k].time as Time, value: v }) } catch { /* noop */ }
                }
              }
            }
            entry.computed = computed
          }
        }
        continue
      }

      // generic overlay indicator
      const entry = overlayRef.get(inst.uid)
      if (!entry) continue
      if (!inst.visible) {
        if (mode === 'full') {
          for (const s of entry.series.values()) s.setData([])
        }
        entry.computed = null
        continue
      }
      let computed: Record<string, (number | null)[]>
      try { computed = def.compute(candles, inst.params) } catch { continue }
      entry.computed = computed

      if (def.candleColoring) continue

      for (const plot of def.plots) {
        if (plot.marker) {
          const cfg = inst.plotSettings?.[plot.key] ?? { visible: true, color: plot.color }
          const ms = entry.series.get(plot.key) as any
          if (cfg.visible && ms?.setMarkers) {
            const arr = computed[plot.key] ?? []
            const isNinja = inst.defId === 'live-fractal-ninja'
            const isWtr = inst.defId === 'wave-trend-resonance'
            const isCustomLive = inst.defId === 'fractal-custom' && (plot.key === 'up' || plot.key === 'down')
            const isFtFp = inst.defId === 'fractal-trigonometric-forecast' && (plot.key === 'call' || plot.key === 'put')
            const useSeparatedPosition = compareFractals && (isCustomLive || isNinja)
            const markers = arr.map((v, i) => v == null || !Number.isFinite(v) ? null : ({
              time: candles[i].time as Time,
              // With WTR visible, all prediction arrows use the inBar slot and
              // are vertically spaced by visualMarkerValue() (WTR/FTFP/Fractal).
              position: hasWtr && (isWtr || isFtFp || isCustomLive || isNinja)
                ? 'inBar'
                : separateFtFpFromLive && isCustomLive
                  ? 'inBar'
                  : useSeparatedPosition
                    ? 'inBar'
                    : (plot.marker === 'arrowUp' ? 'belowBar' : 'aboveBar'),
              color: cfg.color, shape: plot.marker === 'arrowUp' ? 'arrowUp' : 'arrowDown',
              text: isNinja && i === n - 1 ? (plot.marker === 'arrowUp' ? 'NINJA CALL • LIVE' : 'NINJA PUT • LIVE') : '',
            })).filter(Boolean)
            try { ms.setMarkers(markers as any) } catch {}
          } else if (ms?.setMarkers) { try { ms.setMarkers([]) } catch {} }
        }
      }

      for (const plot of def.plots) {
        const plotCfg = inst.plotSettings?.[plot.key] ?? { visible: true, color: plot.color }
        const series = entry.series.get(plot.key)
        if (!plotCfg.visible) { if (mode === 'full') { try { series?.setData([]) } catch {} } continue }
        const arr = computed[plot.key]
        if (!series || !arr) continue
        const targetIdx = (i: number) => i + (plot.displacement ?? 0)
        const timeAt = (idx: number): number | null => {
          if (idx < 0) return null
          if (idx < n) return candles[idx].time
          return candles[n - 1].time + (idx - (n - 1)) * Math.max(1, tf)
        }
        if (mode === 'full') {
          const data: Array<{ time: Time; value: number; color?: string }> = []
          for (let i = 0; i < n; i++) {
            const rawValue = arr[i]
            if (rawValue == null || !Number.isFinite(rawValue)) continue
            const v = plot.marker ? visualMarkerValue(inst.defId, plot.key, rawValue, i) : rawValue
            const t = timeAt(targetIdx(i))
            if (t == null) continue
            data.push({ time: t as Time, value: v })
          }
          try { series.setData(data as any) } catch { /* noop */ }
        } else {
          for (let k = Math.max(0, n - 2); k < n; k++) {
            const rawValue = arr[k]
            if (rawValue == null || !Number.isFinite(rawValue)) continue
            const v = plot.marker ? visualMarkerValue(inst.defId, plot.key, rawValue, k) : rawValue
            const t = timeAt(targetIdx(k))
            if (t == null) continue
            try { series.update({ time: t as Time, value: v } as any) } catch { /* noop */ }
          }
        }
      }
    }
}

export function ChartWorkspace({
  engine, replay, drawings, dark, marketName, activeId, candleSize,
  tradeVisuals = [],
  onForecast,
  bosChochCisdActive = false,
}: ChartWorkspaceProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const mainSeriesRef = useRef<ISeriesApi<any> | null>(null)
  const anchorSeriesRef = useRef<ISeriesApi<'Line'> | null>(null)
  const volumeSeriesRef = useRef<ISeriesApi<'Histogram'> | null>(null)
  const cloudCanvasRef = useRef<HTMLCanvasElement | null>(null)
  const hadCandleColoringRef = useRef(false)
  // Colors already committed to the live LWC series, keyed by candle time.
  // LWC update() only accepts the newest timestamp, so historical color
  // changes must be applied through a full setData() refresh.
  const renderedCandleColorsRef = useRef<Map<number, string>>(new Map())

  const overlayRef = useRef<Map<string, OverlayEntry>>(new Map())
  const paneHandlesRef = useRef<Map<string, SubPaneHandle>>(new Map())
  const alertLinesRef = useRef<IPriceLine[]>([])
  const haStateRef = useRef<{ open: number; close: number } | null>(null)
  const lastCandlesRef = useRef<CandleLike[]>([])
  const lastIndTsRef = useRef(0)
  const positionOnHydrateRef = useRef(true)
  // Last logical index as seen by lightweight-charts. The engine's dataset is
  // windowed (≤300 candles, head evicted) so its length diverges from LWC's
  // index space while streaming — track the LWC truth for edge detection.
  const lwcLastBarRef = useRef(-1)
  const programmaticRangeUntilRef = useRef(0)
  const syncingRef = useRef(false)
  const hoverIdxRef = useRef<number | null>(null)
  const replayActiveRef = useRef(false)
  /** REPLAY FOLLOW : la vue suit la dernière bougie révélée tant que
   *  l'utilisateur n'a pas pané manuellement (pan → suivi coupé jusqu'au
   *  prochain start/seek — comme le bar replay TradingView). */
  const replayFollowRef = useRef(true)
  const lastReplayScrollRef = useRef(0)
  /** Vrai UNIQUEMENT pendant un drag utilisateur (souris/tactile) — permet
   *  de distinguer un vrai pan des événements de plage émis par LWC quand
   *  les données s'ajoutent ou qu'un scroll programmatique s'anime. */
  const userDraggingRef = useRef(false)
  const pineSeriesRef = useRef<Map<string, ISeriesApi<any>>>(new Map())
  const pineHlineRef = useRef<Map<string, any>>(new Map())
  // Pine barcolor() overrides keyed by candle time — consulted by applyMainTo.
  const pineBarColorsRef = useRef<Map<number, string>>(new Map())

  // ── store ──
  const chartStyle = useTVStore((s) => s.chartStyle)
  const indicators = useTVStore((s) => s.indicators)
  const replayActive = useTVStore((s) => s.replayActive)
  const logScale = useTVStore((s) => s.logScale)
  const alerts = useTVStore((s) => s.alerts)
  const removeIndicator = useTVStore((s) => s.removeIndicator)
  const toggleIndicatorVisible = useTVStore((s) => s.toggleIndicatorVisible)
  const updateIndicatorParams = useTVStore((s) => s.updateIndicatorParams)
  const setReplayActive = useTVStore((s) => s.setReplayActive)
  const updateIndicatorPlotSettings = useTVStore((s) => s.updateIndicatorPlotSettings)
  const setIndicatorCloudVisible = useTVStore((s) => s.setIndicatorCloudVisible)
  const pineScripts = usePineStore((s) => s.scripts)
  const pineDataset = usePineStore((s) => s.dataset)
  const removePineScript = usePineStore((s) => s.removeScript)
  const togglePineScript = usePineStore((s) => s.toggle)

  /** Enabled NON-overlay Pine scripts → one synchronized oscillator pane each
   *  (TradingView semantics: overlay=false renders BELOW the chart, never on
   *  the price scale — v1.8 fix for "indicators never fit with the chart"). */
  const pineSeparateScripts = useMemo(
    () => pineScripts.filter((s) =>
      s.enabled && s.result && !s.result.overlay &&
      (s.result.plots.length > 0 || s.result.hlines.length > 0 || s.result.markers.length > 0 ||
        s.result.candles.length > 0 || s.result.fills.length > 0 || s.result.drawings.length > 0)),
    [pineScripts],
  )

  const [atLiveEdge, setAtLiveEdge] = useState(true)
  // Bumps once the chart/series refs become available; refs themselves do not
  // trigger React renders, so the trade overlay needs an explicit ready signal.
  const [chartReadyVersion, setChartReadyVersion] = useState(0)
  const [activeTool, setActiveTool] = useState(drawings.activeTool)
  const [legendSettingsUid, setLegendSettingsUid] = useState<string | null>(null)
  const [draftParams, setDraftParams] = useState<Record<string, number>>({})
  const [draftPlotSettings, setDraftPlotSettings] = useState<Record<string, IndicatorPlotSettings>>({})

  // ── latest-ref bridge: once-mounted effects must call FRESH closures ──
  const latestRef = useRef<{
    updateLegendValues: (idx: number | null) => void
    renderOverlayIndicators: (c: CandleLike[], mode: 'full' | 'tail') => void
    applyMainTo: (s: ISeriesApi<any>, c: CandleLike[], only: CandleLike | null) => void
    fullHydrate: (explicit?: CandleLike[]) => void
    overlayInstances: IndicatorInstance[]
  }>(null as any)


  useEffect(() => { replayActiveRef.current = replayActive }, [replayActive])

  // ── stable chart/series accessors for the canvas overlays ──
  // BosChochCisdOverlay / DrawingLayer key their mount
  // effects (rAF draw loops, event listeners) on these function props.
  // Inline arrows change identity on every render, tearing down and
  // restarting those loops each time the workspace re-renders during fast
  // replay — useCallback keeps the identity stable for the whole mount.
  const getChartApi = useCallback(() => chartRef.current, [])
  const getMainSeries = useCallback(() => mainSeriesRef.current, [])

  useEffect(() => {
    const unsub = drawings.subscribe(() => setActiveTool(drawings.activeTool))
    return unsub
  }, [drawings])

  // ── derived indicator lists ──
  const overlayInstances = useMemo(
    () => indicators.filter((i) => INDICATOR_MAP.get(i.defId)?.pane === 'main'),
    [indicators],
  )
  const separateInstances = useMemo(
    () => indicators.filter((i) => INDICATOR_MAP.get(i.defId)?.pane === 'separate'),
    [indicators],
  )
  const volumeInstance = useMemo(
    () => overlayInstances.find((i) => i.defId === 'volume') ?? null,
    [overlayInstances],
  )

  const tfLabel = useMemo(
    () => TIMEFRAMES.find((t) => t.seconds === candleSize)?.label ?? `${candleSize}s`,
    [candleSize],
  )

  const getCandles = useCallback((): CandleLike[] => {
    if (replayActiveRef.current) return replay.getVisible()
    return engine.getCandles()
  }, [engine, replay])

  // ══════════════════════════════════════════════ main chart creation
  useEffect(() => {
    if (!containerRef.current) return
    const theme = themeFor(dark)
    const options: any = {
      ...baseChartOptions(theme),
      width: containerRef.current.clientWidth,
      height: containerRef.current.clientHeight,
      rightPriceScale: {
        ...baseChartOptions(theme).rightPriceScale,
        scaleMargins: { top: 0.08, bottom: 0.25 },
      },
      timeScale: {
        ...baseChartOptions(theme).timeScale,
        // Reserve a real one-hour blank future window after the latest candle.
        // The axis can therefore show upcoming times for the Fibonacci forecast
        // without fabricating candles.
        rightOffset: Math.max(6, Math.ceil(3600 / Math.max(1, candleSize))),
        minBarSpacing: 3,
        barSpacing: 9,
        // FIXED SCREEN: never shift the visible range when a new candle
        // arrives — candles do NOT slide left on their own. Only a user pan
        // (swipe/drag) or the Go-to-Live button moves the view.
        shiftVisibleRangeOnNewBar: false,
      },
    }
    const chart = createChart(containerRef.current, options)
    chartRef.current = chart

    // invisible ANCHOR series (anti Y-jitter during ticks, v4-safe)
    anchorSeriesRef.current = chart.addLineSeries({
      color: 'rgba(0,0,0,0)',
      lineWidth: 1,
      priceLineVisible: false,
      lastValueVisible: false,
      crosshairMarkerVisible: false,
      priceScaleId: 'right',
    })

    setChartReadyVersion((v) => v + 1)

    // Détection du drag/zoom UTILISATEUR (source fiable d'un pan réel — les
    // événements de plage LWC se déclenchent aussi hors interaction).
    const killReplayFollow = () => {
      if (replayActiveRef.current) replayFollowRef.current = false
    }
    const onDown = () => { userDraggingRef.current = true }
    const onUp = () => {
      // petit délai : le dernier événement de plage du drag doit passer
      // pendant la fenêtre « dragging » pour être qualifié de pan.
      window.setTimeout(() => { userDraggingRef.current = false }, 60)
    }
    const hostEl = containerRef.current
    if (hostEl) {
      hostEl.addEventListener('mousedown', onDown)
      hostEl.addEventListener('touchstart', onDown, { passive: true })
      hostEl.addEventListener('wheel', killReplayFollow, { passive: true })
      window.addEventListener('mouseup', onUp)
      window.addEventListener('touchend', onUp, { passive: true })
    }

    // FIXED SCREEN — the view never moves on its own (no auto-follow, no
    // shift-on-new-bar). This subscription only (a) tracks whether the live
    // edge is visible (to show/hide the Go-to-Live button) and (b) mirrors
    // the user's pan to the oscillator sub-panes.
    chart.timeScale().subscribeVisibleLogicalRangeChange((range) => {
      if (!range) return
      if (lwcLastBarRef.current >= 0) {
        // "at live edge" = the last bar sits inside the live zone: at or
        // before the view's right edge, and no deeper than the reserved
        // future offset. Wandering into blank future OR into history hides
        // the live edge → show the Go-to-Live button.
        const last = lwcLastBarRef.current
        const rightOffset = (chart.timeScale().options() as any).rightOffset ?? 12
        const near = range.to >= last - 0.5 && range.to <= last + rightOffset + 8
        setAtLiveEdge((prev) => (prev !== near ? near : prev))
      }
      if (Date.now() < programmaticRangeUntilRef.current || syncingRef.current) return
      // Pan UTILISATEUR pendant le replay (drag actif) → coupe le suivi
      // automatique (il reprendra au prochain start / seek / Back to start).
      // Les changements de plage émis par l'ajout de données ou l'animation
      // d'un scroll programmatique ne comptent PAS comme pan.
      if (replayActiveRef.current && userDraggingRef.current) replayFollowRef.current = false
      // push range to sub-panes
      if (paneHandlesRef.current.size > 0) {
        syncingRef.current = true
        for (const h of paneHandlesRef.current.values()) h.applyRange(range.from, range.to)
        setTimeout(() => { syncingRef.current = false }, 0)
      }
    })

    // crosshair → legends + sub-pane sync
    chart.subscribeCrosshairMove((param: any) => {
      const candles = lastCandlesRef.current
      if (param.time != null && param.logical != null) {
        const idx = Math.round(param.logical as number)
        hoverIdxRef.current = idx
        latestRef.current?.updateLegendValues(idx)
        for (const h of paneHandlesRef.current.values()) {
          h.crosshairAt(idx, param.time as number)
        }
      } else {
        hoverIdxRef.current = null
        latestRef.current?.updateLegendValues(candles.length - 1)
        for (const h of paneHandlesRef.current.values()) {
          h.crosshairAt(null, null)
        }
      }
    })

    const ro = new ResizeObserver(() => {
      if (containerRef.current && chartRef.current) {
        chartRef.current.applyOptions({
          width: containerRef.current.clientWidth,
          height: containerRef.current.clientHeight,
        })
      }
    })
    ro.observe(containerRef.current)

    return () => {
      ro.disconnect()
      if (hostEl) {
        hostEl.removeEventListener('mousedown', onDown)
        hostEl.removeEventListener('touchstart', onDown)
        hostEl.removeEventListener('wheel', killReplayFollow)
        window.removeEventListener('mouseup', onUp)
        window.removeEventListener('touchend', onUp)
      }
      chart.remove()
      chartRef.current = null
      mainSeriesRef.current = null
      anchorSeriesRef.current = null
      volumeSeriesRef.current = null
      overlayRef.current.clear()
      alertLinesRef.current = []
    }
     
  }, [])

  // theme change
  useEffect(() => {
    const chart = chartRef.current
    if (!chart) return
    const theme = themeFor(dark)
    chart.applyOptions({
      layout: { ...baseChartOptions(theme).layout },
      grid: { ...baseChartOptions(theme).grid },
      crosshair: {
        ...baseChartOptions(theme).crosshair,
      },
      rightPriceScale: { borderColor: theme.border },
      timeScale: { borderColor: theme.border },
    } as any)
    for (const h of paneHandlesRef.current.values()) h.applyTheme(dark)
     
  }, [dark])

  // log scale
  useEffect(() => {
    const chart = chartRef.current
    if (!chart) return
    try {
      chart.priceScale('right').applyOptions({
        mode: logScale ? PriceScaleMode.Logarithmic : PriceScaleMode.Normal,
      })
    } catch { /* noop */ }
  }, [logScale])

  // ══════════════════════════════════════════════ main series per style
  useEffect(() => {
    const chart = chartRef.current
    if (!chart) return
    if (mainSeriesRef.current) {
      try { chart.removeSeries(mainSeriesRef.current) } catch { /* noop */ }
      mainSeriesRef.current = null
    }
    const theme = themeFor(dark)
    switch (chartStyle) {
      case 'candles':
        mainSeriesRef.current = chart.addCandlestickSeries({
          upColor: theme.up, downColor: theme.down,
          borderUpColor: theme.up, borderDownColor: theme.down,
          wickUpColor: theme.upWick, wickDownColor: theme.downWick,
        })
        break
      case 'hollow':
        mainSeriesRef.current = chart.addCandlestickSeries({
          upColor: 'rgba(0,0,0,0)', downColor: theme.down,
          borderUpColor: theme.up, borderDownColor: theme.down,
          wickUpColor: theme.upWick, wickDownColor: theme.downWick,
        })
        break
      case 'bars':
        mainSeriesRef.current = chart.addBarSeries({
          upColor: theme.up, downColor: theme.down,
          thinBars: false,
        })
        break
      case 'line':
        mainSeriesRef.current = chart.addLineSeries({ color: theme.lineSeries, lineWidth: 2 })
        break
      case 'area':
        mainSeriesRef.current = chart.addAreaSeries({
          lineColor: theme.lineSeries, lineWidth: 2,
          topColor: theme.areaTop, bottomColor: theme.areaBottom,
        })
        break
      case 'baseline': {
        const base = lastCandlesRef.current[0]?.close ?? 0
        mainSeriesRef.current = chart.addBaselineSeries({
          baseValue: { type: 'price', price: base },
          topLineColor: theme.up, topFillColor1: `${theme.up}33`, topFillColor2: `${theme.up}05`,
          bottomLineColor: theme.down, bottomFillColor1: `${theme.down}05`, bottomFillColor2: `${theme.down}33`,
          lineWidth: 2,
        })
        break
      }
      case 'heikin-ashi':
        mainSeriesRef.current = chart.addCandlestickSeries({
          upColor: theme.up, downColor: theme.down,
          borderUpColor: theme.up, borderDownColor: theme.down,
          wickUpColor: theme.upWick, wickDownColor: theme.downWick,
        })
        break
    }
    haStateRef.current = null
    latestRef.current?.fullHydrate(lastCandlesRef.current)
  }, [chartStyle])

  // ══════════════════════════════════════════════ overlay indicator series
  useEffect(() => {
    const chart = chartRef.current
    if (!chart) return

    const wanted = new Set(overlayInstances.map((i) => i.uid))
    // remove stale series
    for (const [uid, entry] of overlayRef.current) {
      if (!wanted.has(uid)) {
        for (const s of entry.series.values()) {
          try { chart.removeSeries(s) } catch { /* noop */ }
        }
        overlayRef.current.delete(uid)
      }
    }
    // volume series lifecycle (special scale)
    const needVolume = volumeInstance != null
    if (needVolume && !volumeSeriesRef.current) {
      volumeSeriesRef.current = chart.addHistogramSeries({
        priceFormat: { type: 'volume' },
        priceScaleId: '',
        priceLineVisible: false,
        lastValueVisible: false,
      })
      try {
        chart.priceScale('').applyOptions({ scaleMargins: { top: 0.82, bottom: 0 } })
      } catch { /* scale not yet registered */ }
    } else if (!needVolume && volumeSeriesRef.current) {
      try { chart.removeSeries(volumeSeriesRef.current) } catch { /* noop */ }
      volumeSeriesRef.current = null
    }

    // create missing entries
    for (const inst of overlayInstances) {
      const def = INDICATOR_MAP.get(inst.defId)
      if (!def) continue
      if (inst.defId === 'volume') {
        // Volume histogram is dedicated; only its MA line lives in the entry
        const existing = overlayRef.current.get(inst.uid)
        const paramsKey = JSON.stringify({ params: inst.params, plots: inst.plotSettings })
        if (existing && existing.paramsKey === paramsKey) continue
        if (existing) {
          for (const s of existing.series.values()) {
            try { chart.removeSeries(s) } catch { /* noop */ }
          }
        }
        const series = new Map<string, ISeriesApi<'Line'> | ISeriesApi<'Histogram'>>()
        series.set('ma', chart.addLineSeries({
          color: '#F57F17',
          lineWidth: 1,
          priceLineVisible: false,
          lastValueVisible: false,
          crosshairMarkerVisible: false,
          priceScaleId: '',
        }))
        overlayRef.current.set(inst.uid, { series, computed: null, paramsKey })
        continue
      }

      const existing = overlayRef.current.get(inst.uid)
      const paramsKey2 = JSON.stringify({ params: inst.params, plots: inst.plotSettings })
      if (existing && existing.paramsKey === paramsKey2) continue
      if (existing) {
        for (const s of existing.series.values()) {
          try { chart.removeSeries(s) } catch { /* noop */ }
        }
      }
      // Candle-coloring definitions do not need plot series. Their plot colors
      // are consumed by getEngulfingCandleColors() and the settings UI.
      const series = new Map<string, ISeriesApi<'Line'> | ISeriesApi<'Histogram'>>()
      if (def.candleColoring) {
        overlayRef.current.set(inst.uid, { series, computed: null, paramsKey: paramsKey2 })
        continue
      }
      for (const plot of def.plots) {
        const plotCfg = inst.plotSettings?.[plot.key] ?? { visible: true, color: plot.color }
        if (plot.type === 'histogram') {
          series.set(plot.key, chart.addHistogramSeries({
            color: plotCfg.color,
            base: 0,
            priceLineVisible: false,
            lastValueVisible: false,
            priceScaleId: 'right',
          }))
        } else {
          series.set(plot.key, chart.addLineSeries({
            color: plot.marker ? 'rgba(0,0,0,0)' : plotCfg.color,
            lineWidth: (plot.lineWidth ?? 1) as 1 | 2 | 3 | 4,
            lineStyle: plot.dashed ? LineStyle.Dashed : LineStyle.Solid,
            priceLineVisible: false,
            lastValueVisible: false,
            crosshairMarkerVisible: false,
            priceScaleId: 'right',
          }))
        }
      }
      overlayRef.current.set(inst.uid, {
        series, computed: null, paramsKey: paramsKey2,
      })
      // Marker-only plots use an invisible line series as their anchor.
      for (const plot of def.plots) {
        if (!plot.marker) continue
        const ms = series.get(plot.key) as any
        try { ms?.setMarkers?.([]) } catch {}
      }
    }

    latestRef.current?.renderOverlayIndicators(lastCandlesRef.current, 'full')
    latestRef.current?.updateLegendValues(hoverIdxRef.current)
  }, [overlayInstances, volumeInstance])

  // ══════════════════════════════════════════════ Pine Script plots
  // v1.9 — TIMESTAMP-ONLY ALIGNMENT (spec §7/§9): every Pine output is
  // positioned by its bar TIMESTAMP through pine-time-axis. The v1.8
  // positional tail fallbacks (`values[values.length - n + i]` on
  // `visible[offset + i]`) are GONE: when the Pine timeline is missing or
  // incoherent we refuse to draw and emit an explicit [PINE ALIGNMENT]
  // diagnostic instead of silently rendering a shifted layer.
  useEffect(() => {
    const chart = chartRef.current
    if (!chart) return

    const isProd = typeof process !== 'undefined' && process.env?.NODE_ENV === 'production'
    const reportIssues = (scriptId: string, what: string, issues: AlignDiagnostic[]) => {
      if (isProd || !issues.length) return
      for (const issue of issues) {
        console.warn(`[PINE ALIGNMENT] ${issue.code} · ${scriptId} · ${what} — ${issue.detail}`)
      }
    }

    const activeIds = new Set<string>()
    for (const script of pineScripts) {
      if (!script.enabled || !script.result) continue
      // v1.8 — non-overlay scripts render in their own PineSubPane, NOT on the
      // price chart: their values live in a different coordinate space and
      // used to float over the candles with an independent scale.
      if (!script.result.overlay) continue
      activeIds.add(script.id)
      const prefix = `${script.id}:`

      for (let i = 0; i < script.result.plots.length; i++) {
        const plot = script.result.plots[i]
        const key = `${prefix}${plot.id ?? i}`
        let series = pineSeriesRef.current.get(key)
        const isHistogram = plot.style === 'histogram' || plot.style === 'columns'
        if (!series) {
          series = isHistogram
            ? chart.addHistogramSeries({
                color: plot.color || '#2962FF',
                base: 0,
                priceLineVisible: false,
                lastValueVisible: false,
                priceScaleId: plot.overlay ? 'right' : `pine-${script.id}`,
              })
            : chart.addLineSeries({
                color: plot.color || '#2962FF',
                lineWidth: Math.max(1, Math.min(4, Math.round(plot.linewidth || 1))) as 1 | 2 | 3 | 4,
                priceLineVisible: false,
                lastValueVisible: false,
                crosshairMarkerVisible: false,
                priceScaleId: plot.overlay ? 'right' : `pine-${script.id}`,
              })
          pineSeriesRef.current.set(key, series)
        }

        // Timestamp-keyed alignment — the ONLY placement mechanism.
        const visible = lastCandlesRef.current
        const values = plot.data || []
        const { points, issues } = alignPineSeries(values, script.result._times, visible)
        reportIssues(script.id, `plot "${plot.title}"`, issues)
        const data: Array<{ time: Time; value: number }> = []
        for (const p of points) {
          if (p.value == null || !Number.isFinite(p.value)) continue
          data.push({ time: p.candle.time as Time, value: p.value })
        }
        try { series.setData(data as any) } catch (err) { console.warn('[Pine] setData failed', err) }
        // Pine supports per-bar plot colors. lightweight-charts line series do
        // not, so retain the declared/static color here and expose the full
        // color array in the script output for diagnostics/future renderers.
      }

      // plotcandle / plotbar outputs render as native candlestick series.
      for (let ci = 0; ci < (script.result.candles || []).length; ci++) {
        const candleOut = script.result.candles[ci]
        const key = `${prefix}candle:${candleOut.id ?? ci}`
        let series = pineSeriesRef.current.get(key)
        if (!series) {
          series = chart.addCandlestickSeries({
            upColor: '#26a69a', downColor: '#ef5350',
            borderVisible: true, wickUpColor: '#26a69a', wickDownColor: '#ef5350',
            priceLineVisible: false,
            lastValueVisible: false,
            priceScaleId: candleOut.overlay ? 'right' : `pine-${script.id}`,
          })
          pineSeriesRef.current.set(key, series)
        }
        const visible = lastCandlesRef.current
        const { points, issues } = alignPineSeries(candleOut.data, script.result._times, visible)
        reportIssues(script.id, `plotcandle "${candleOut.title}"`, issues)
        const data: Array<any> = []
        let pi = 0
        for (const p of points) {
          const bar = p.value
          if (!bar) { pi++; continue }
          data.push({
            time: p.candle.time as Time,
            open: bar.open, high: bar.high, low: bar.low, close: bar.close,
            ...(candleOut.colors?.[pi] ? { color: candleOut.colors[pi] } : {}),
            ...(candleOut.borderColors?.[pi] ? { borderColor: candleOut.borderColors[pi] } : {}),
            ...(candleOut.wickColors?.[pi] ? { wickColor: candleOut.wickColors[pi] } : {}),
          })
          pi++
        }
        try { series.setData(data) } catch (err) { console.warn('[Pine] plotcandle setData failed', err) }
      }

      // plotshape/plotchar/plotarrow → lightweight-charts native markers.
      // MARKERS ARE TIMESTAMP-ANCHORED (spec §9): each marker stays on the
      // exact candle that triggered the signal — never positional.
      for (let mi = 0; mi < (script.result.markers || []).length; mi++) {
        const marker = script.result.markers[mi]
        const key = `${script.id}:marker:${marker.id ?? mi}`
        let anchor = pineSeriesRef.current.get(key)
        if (!anchor) {
          anchor = chart.addLineSeries({
            color: 'rgba(0,0,0,0)',
            lineWidth: 1,
            priceLineVisible: false,
            lastValueVisible: false,
            crosshairMarkerVisible: false,
            priceScaleId: 'right',
          })
          pineSeriesRef.current.set(key, anchor)
        }
        const visible = lastCandlesRef.current
        const md = marker.data || []
        const { points, issues } = alignPineSeries(md, script.result._times, visible)
        reportIssues(script.id, `marker "${marker.title}"`, issues)
        // PINE_MARKER_DESYNC (spec §17): markers that cannot be placed on
        // their candle are COUNTED and diagnosed, never tail-aligned.
        const unplaced = md.filter((m) => m != null).length - points.filter((p) => p.value != null).length
        if (unplaced > 0 && !isProd) {
          console.warn(`[PINE ALIGNMENT] PINE_MARKER_DESYNC · ${script.id} · "${marker.title}" — ${unplaced} marker(s) outside the chart window or timeline`)
        }
        const markerData: Array<any> = []
        for (const p of points) {
          const item = p.value
          if (!item) continue
          markerData.push({
            time: p.candle.time,
            position: marker.location === 'belowbar' || marker.location === 'bottom' ? 'belowBar' : 'aboveBar',
            shape: markerShapeFor(marker),
            color: item.color || '#2962FF',
            text: item.text || undefined,
          })
        }
        try {
          anchor.setData(lastCandlesRef.current.map((c) => ({ time: c.time as Time, value: c.close })))
          anchor.setMarkers(markerData)
        } catch (err) { console.warn('[Pine] marker render failed', err) }
      }
    }

    // Hlines are native price lines on the MAIN series — OVERLAY scripts only.
    // A non-overlay script's hlines (RSI 30/70…) live in its own pane; adding
    // them to the price series stretched the whole chart (v1.8 fix).
    const mainSeries = mainSeriesRef.current
    if (mainSeries) {
      const activeHlines = new Set<string>()
      for (const script of pineScripts) {
        if (!script.enabled || !script.result) continue
        if (!script.result.overlay) continue
        for (const line of script.result.hlines || []) {
          const key = `${script.id}:hline:${line.id}`
          activeHlines.add(key)
          let priceLine = pineHlineRef.current.get(key)
          if (!priceLine) {
            try {
              priceLine = mainSeries.createPriceLine({
                price: line.price,
                color: '#2962FF',
                lineStyle: LineStyle.Dashed,
                lineWidth: 1,
                axisLabelVisible: true,
                lineVisible: true,
                title: line.title,
              })
              pineHlineRef.current.set(key, priceLine)
            } catch (err) { console.warn('[Pine] hline render failed', err) }
          }
        }
      }
      for (const [key, priceLine] of pineHlineRef.current) {
        if (!activeHlines.has(key)) {
          try { mainSeries.removePriceLine(priceLine) } catch { /* noop */ }
          pineHlineRef.current.delete(key)
        }
      }
    }

    for (const [key, series] of pineSeriesRef.current) {
      const id = key.split(':', 1)[0]
      if (!activeIds.has(id)) {
        try { chart.removeSeries(series) } catch { /* noop */ }
        pineSeriesRef.current.delete(key)
      }
    }

    // Pine barcolor() overrides → consulted by applyMainTo when painting the
    // main candle series. Rebuilding the map and forcing a full re-apply keeps
    // historical colors correct (LWC can only update() the newest bar).
    const pineBarColors = new Map<number, string>()
    for (const script of pineScripts) {
      if (!script.enabled || !script.result?.overlay) continue
      const layers = script.result.barColors || []
      const times = script.result._times
      if (!times) continue
      for (const layer of layers) {
        if (!Array.isArray(layer)) continue
        for (let i = 0; i < Math.min(layer.length, times.length); i++) {
          const color = layer[i]
          if (!color) continue
          pineBarColors.set(pineTimeToChartTime(times[i]), color)
        }
      }
    }
    const prevSignature = (pineBarColorsRef.current as any).__sig as string | undefined
    const signature = [...pineBarColors.entries()].map(([t, c]) => `${t}:${c}`).join('|')
    ;(pineBarColorsRef.current as any).__sig = signature
    pineBarColorsRef.current.clear()
    for (const [t, c] of pineBarColors) pineBarColorsRef.current.set(t, c)
    if (signature !== prevSignature && mainSeriesRef.current && lastCandlesRef.current.length) {
      latestRef.current?.applyMainTo(mainSeriesRef.current, lastCandlesRef.current, null)
    }

    // ── [PINE ALIGNMENT] dev-only probe (spec §17) ──
    // Verifies that every displayed result still matches the live dataset:
    // a result whose last bar lags the chart's last bar by ≥ 1 timeframe is
    // reported as PINE_RESULT_STALE instead of silently rendering shifted.
    if (!isProd) {
      const reports = pineScripts
        .filter((s) => s.enabled && s.result)
        .map((s) => diagnosePineAlignment({
          scriptId: s.id,
          scriptName: s.name,
          resultTimes: s.result!._times,
          candles: lastCandlesRef.current,
          datasetRevision: pineDataset.revision,
          resultRevision: s.envelope?.revision,
        }))
      logPineAlignmentDiagnostics(reports)
    }

    return () => {
      // Series lifetime is owned by the chart and explicitly reconciled above.
    }
  }, [pineScripts, marketName, candleSize, chartReadyVersion, pineDataset])

  // (v1.9) The v1.8 "re-bind on dataset advance" effect was REMOVED: it was
  // fully redundant with the render effect above (both keyed on pineScripts)
  // and its positional tail fallback was a forbidden alignment mechanism.
  // Series data is timestamp-anchored, so nothing needs re-binding when
  // candles advance alone; a fresh result always triggers the effect above.

  // ══════════════════════════════════════════════ alerts → price lines
  useEffect(() => {
    const series = mainSeriesRef.current
    if (!series) return
    for (const line of alertLinesRef.current) {
      try { series.removePriceLine(line) } catch { /* noop */ }
    }
    alertLinesRef.current = []
    for (const a of alerts) {
      if (a.symbol !== marketName || a.triggered) continue
      alertLinesRef.current.push(series.createPriceLine({
        price: a.price,
        color: '#FF6D00',
        lineStyle: LineStyle.Dashed,
        lineVisible: true,
        axisLabelVisible: true,
        title: a.direction === 'above' ? 'Alert ▲' : 'Alert ▼',
      }))
    }
  }, [alerts, marketName, chartStyle])

  // ══════════════════════════════════════════════ overlay indicator rendering
  const renderOverlayIndicators = useCallback(
    (candles: CandleLike[], mode: 'full' | 'tail') => {
      renderOverlayIndicatorsImpl(
        chartRef.current, dark, overlayInstances, volumeInstance,
        volumeSeriesRef.current, overlayRef.current, candles, mode,
      )
    },
    [dark, overlayInstances, volumeInstance],
  )

  // ──────────────────────────────────────────── legends (imperative DOM)
  const ohlcRefs = useRef<Record<string, HTMLSpanElement | null>>({})
  const chgRef = useRef<HTMLSpanElement | null>(null)
  const overlayValueRefs = useRef<Map<string, Map<string, HTMLSpanElement | null>>>(new Map())

  const updateLegendValues = (idx: number | null) => {
    const candles = lastCandlesRef.current
    const i = idx == null ? candles.length - 1 : idx
    const c = candles[i]
    const fmt = (v: number) => formatIndicatorValue(v)
    if (c) {
      const color = c.close >= c.open ? UP : DOWN
      const set = (k: string, v: number) => {
        const el = ohlcRefs.current[k]
        if (el) { el.textContent = fmt(v); el.style.color = color }
      }
      set('o', c.open); set('h', c.high); set('l', c.low); set('cl', c.close)
      const prev = candles[i - 1]
      const chgEl = chgRef.current
      if (chgEl) {
        if (prev) {
          const chg = c.close - prev.close
          const pct = prev.close !== 0 ? (chg / prev.close) * 100 : 0
          chgEl.textContent = `${chg >= 0 ? '+' : ''}${fmt(chg)} (${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%)`
          chgEl.style.color = chg >= 0 ? UP : DOWN
        } else {
          chgEl.textContent = ''
        }
      }
    }
    // overlay indicator values
    for (const inst of overlayInstances) {
      const entry = overlayRef.current.get(inst.uid)
      const spans = overlayValueRefs.current.get(inst.uid)
      if (!entry || !spans) continue
      const def = INDICATOR_MAP.get(inst.defId)
      if (!def) continue
      let computed = entry.computed
      if (!computed || !inst.visible) {
        for (const plot of def.plots) {
          const el = spans.get(plot.key)
          if (el) el.textContent = inst.visible ? '' : '—'
        }
        continue
      }
      const valid = i >= 0 && i < candles.length
      for (const plot of def.plots) {
        const el = spans.get(plot.key)
        if (!el) continue
        const v = valid ? computed[plot.key]?.[i] : undefined
        el.textContent = v == null ? '' : formatIndicatorValue(v)
      }
    }
  }

  // ══════════════════════════════════════════════ main series data helpers
  const getEngulfingCandleColors = (candles: CandleLike[]) => {
    const out = new Map<number, { color: string; borderColor: string; wickColor: string }>()
    // Latest active Engulfing instance wins. This also makes multiple active
    // pattern indicators deterministic instead of stacking colors.
    for (const inst of [...overlayInstances].reverse()) {
      const def = INDICATOR_MAP.get(inst.defId)
      if (!def?.candleColoring || !inst.visible) continue
      const computed = def.compute(candles, inst.params)
      const shortCfg = inst.plotSettings?.shortCandle
      const longCfg = inst.plotSettings?.longCandle
      const shortColor = shortCfg?.color ?? '#FDD835'
      const longColor = longCfg?.color ?? '#000000'
      const shortVisible = shortCfg?.visible !== false
      const longVisible = longCfg?.visible !== false
      const shortSeries = computed.shortCandle ?? []
      const longSeries = computed.longCandle ?? []
      for (let i = 0; i < candles.length; i++) {
        if (longVisible && longSeries[i] != null) {
          out.set(i, { color: longColor, borderColor: longColor, wickColor: longColor })
        } else if (shortVisible && shortSeries[i] != null && !out.has(i)) {
          out.set(i, { color: shortColor, borderColor: shortColor, wickColor: shortColor })
        }
      }
      // We only use one candle-coloring indicator by precedence.
      break
    }
    return out
  }

  const applyMainTo = (series: ISeriesApi<any>, candles: CandleLike[], only: CandleLike | null) => {
    const style = chartStyle
    const isCandleLike = style === 'candles' || style === 'hollow' || style === 'heikin-ashi' || style === 'bars'
    if (isCandleLike) {
      const colors = getEngulfingCandleColors(candles)
      // Pine barcolor() wins over the built-in engulfing coloring — mirroring
      // TradingView, where barcolor repaints the whole bar.
      const colorFor = (idx: number) => {
        const pineColor = pineBarColorsRef.current.get(Number(candles[idx]?.time))
        if (pineColor) return { color: pineColor, borderColor: pineColor, wickColor: pineColor }
        return colors.get(idx)
      }
      const colorKey = (cc?: { color: string; borderColor: string; wickColor: string }) =>
        cc ? `${cc.color}|${cc.borderColor}|${cc.wickColor}` : ''

      const setAllData = (data: any[], colorStateSource: CandleLike[]) => {
        // Historical candle colors cannot be changed with update(): LWC requires
        // update() timestamps to be >= the last update timestamp. Rebuild only
        // when a previous candle actually changed color, and preserve viewport.
        const visible = chartRef.current?.timeScale().getVisibleLogicalRange()
        ;(series as ISeriesApi<'Candlestick'>).setData(data)
        renderedCandleColorsRef.current.clear()
        for (let i = 0; i < colorStateSource.length; i++) {
          renderedCandleColorsRef.current.set(colorStateSource[i].time, colorKey(colorFor(i)))
        }
        if (visible) {
          try { chartRef.current?.timeScale().setVisibleLogicalRange(visible) } catch { /* noop */ }
        }
      }

      if (style === 'heikin-ashi') {
        const ha = heikinAshi(candles)
        if (only) {
          const idx = candles.length - 1
          const prev = idx > 0 ? candles[idx - 1] : null
          const prevColorKey = prev ? colorKey(colorFor(idx - 1)) : ''
          const renderedPrevKey = prev ? (renderedCandleColorsRef.current.get(prev.time) ?? '') : ''
          if (prev && prevColorKey !== renderedPrevKey) {
            setAllData(ha.map((c, i) => ({
              time: c.time as Time,
              open: c.open, high: c.high, low: c.low, close: c.close,
              ...(colorFor(i) ?? {}),
            } as any)), candles)
            return
          }
          const haOnly = ha[idx]
          if (haOnly) {
            const cc = colorFor(idx)
            ;(series as ISeriesApi<'Candlestick'>).update({
              time: haOnly.time as Time,
              open: haOnly.open, high: haOnly.high, low: haOnly.low, close: haOnly.close,
              ...(cc ?? {}),
            } as any)
            renderedCandleColorsRef.current.set(haOnly.time, colorKey(cc))
          }
        } else {
          setAllData(ha.map((c, i) => ({
            time: c.time as Time,
            open: c.open, high: c.high, low: c.low, close: c.close,
            ...(colorFor(i) ?? {}),
          } as any)), candles)
        }
      } else if (only) {
        const idx = candles.length - 1
        const prev = idx > 0 ? candles[idx - 1] : null
        const prevColorKey = prev ? colorKey(colorFor(idx - 1)) : ''
        const renderedPrevKey = prev ? (renderedCandleColorsRef.current.get(prev.time) ?? '') : ''

        // Never update candles[idx-1] after candles[idx]. If its color changed,
        // setData() restores all bars in chronological order without LWC errors.
        if (prev && prevColorKey !== renderedPrevKey) {
          setAllData(candles.map((c, i) => ({
            time: c.time as Time,
            open: c.open, high: c.high, low: c.low, close: c.close,
            ...(colorFor(i) ?? {}),
          } as any)), candles)
          return
        }

        const cc = colorFor(idx)
        ;(series as ISeriesApi<'Candlestick'>).update({
          time: only.time as Time,
          open: only.open, high: only.high, low: only.low, close: only.close,
          ...(cc ?? {}),
        } as any)
        renderedCandleColorsRef.current.set(only.time, colorKey(cc))
      } else {
        setAllData(candles.map((c, i) => ({
          time: c.time as Time,
          open: c.open, high: c.high, low: c.low, close: c.close,
          ...(colorFor(i) ?? {}),
        } as any)), candles)
      }
    } else {
      const toLine = (c: CandleLike) => ({ time: c.time as Time, value: c.close })
      if (only) {
        ;(series as ISeriesApi<'Line'>).update(toLine(only))
      } else {
        ;(series as ISeriesApi<'Line'>).setData(candles.map(toLine))
      }
    }
  }

  // Re-apply candle overrides immediately when Engulfing parameters/colors
  // change or when the indicator is removed. This path is event-driven (not a
  // per-tick effect), so the fixed chart viewport remains stable during live
  // streaming.
  useEffect(() => {
    const hasCandleColoring = overlayInstances.some((inst) => INDICATOR_MAP.get(inst.defId)?.candleColoring)
    if (hasCandleColoring || hadCandleColoringRef.current) {
      const id = window.requestAnimationFrame(() => {
        const series = mainSeriesRef.current
        const candles = lastCandlesRef.current
        if (series && candles.length > 0) latestRef.current?.applyMainTo(series, candles, null)
      })
      hadCandleColoringRef.current = hasCandleColoring
      return () => window.cancelAnimationFrame(id)
    }
    hadCandleColoringRef.current = false
  }, [overlayInstances])

  // ══════════════════════════════════════════════ full hydrate
  const fullHydrate = (explicit?: CandleLike[]) => {
    const chart = chartRef.current
    const series = mainSeriesRef.current
    if (!chart || !series) return
    const candles = (explicit && explicit.length > 0 ? explicit : getCandles()) ?? []
    lastCandlesRef.current = candles
    if (candles.length === 0) {
      try {
        series.setData([])
        volumeSeriesRef.current?.setData([])
        anchorSeriesRef.current?.setData([])
        for (const entry of overlayRef.current.values()) {
          for (const s of entry.series.values()) s.setData([])
        }
        for (const h of paneHandlesRef.current.values()) h.setData([])
      } catch { /* noop */ }
      updateLegendValues(null)
      return
    }

    try {
      applyMainTo(series, candles, null)
      renderOverlayIndicators(candles, 'full')
      for (const h of paneHandlesRef.current.values()) h.setData(candles)

      const n = candles.length
      const anchor = anchorSeriesRef.current
      if (anchor && n >= 2) {
        const a = candles[n - 2]
        const b = candles[n - 1]
        anchor.setData([
          { time: a.time as Time, value: Math.max(a.high, b.high) },
          { time: b.time as Time, value: Math.min(a.low, b.low) },
        ])
      }
      updateLegendValues(hoverIdxRef.current)
      // LWC index space re-bases here (setData) → resync the tracked last bar
      lwcLastBarRef.current = candles.length - 1
      // FIXED SCREEN: re-anchor to the live edge ONLY right after the dataset
      // has been (re)loaded — mount, symbol/timeframe switch (onHistory) or
      // replay exit. While streaming, the view never moves; only the user
      // pans (or presses Go to Live).
      if (positionOnHydrateRef.current) {
        positionOnHydrateRef.current = false
        programmaticRangeUntilRef.current = Date.now() + 400
        try { chart.timeScale().scrollToRealTime() } catch { /* noop */ }
        if (paneHandlesRef.current.size > 0) {
          syncingRef.current = true
          const r = chart.timeScale().getVisibleLogicalRange()
          if (r) for (const h of paneHandlesRef.current.values()) h.applyRange(r.from, r.to)
          setTimeout(() => { syncingRef.current = false }, 0)
        }
      }
    } catch { /* noop */ }
  }

  // ══════════════════════════════════════════════ LIVE engine subscription
  useEffect(() => {
    const handleFlush = (flush: CandleFlush) => {
      if (replayActiveRef.current) return
      const chart = chartRef.current
      const series = mainSeriesRef.current
      if (!chart || !series) return

      const candles = engine.getCandles()
      lastCandlesRef.current = candles
      const n = candles.length
      if (n === 0) return
      const latest = flush.latest

      latestRef.current?.applyMainTo(series, candles, latest)
      // one series.update() per new-candle flush = exactly +1 bar in LWC's
      // logical index space (engine head-eviction does not renumber LWC)
      if (flush.isNewCandle) {
        lwcLastBarRef.current = (lwcLastBarRef.current < 0 ? n - 1 : lwcLastBarRef.current) + 1
      }

      // anchor follows the last two candles
      const anchor = anchorSeriesRef.current
      if (anchor && n >= 2) {
        const a = candles[n - 2]
        const b = candles[n - 1]
        try {
          anchor.update({ time: a.time as Time, value: Math.max(a.high, b.high) })
          anchor.update({ time: b.time as Time, value: Math.min(a.low, b.low) })
        } catch { /* noop */ }
      }

      // indicators: throttled tail updates (~4 Hz)
      const now = Date.now()
      if (now - lastIndTsRef.current > 250 || flush.isNewCandle) {
        lastIndTsRef.current = now
        latestRef.current?.renderOverlayIndicators(candles, 'tail')
        for (const h of paneHandlesRef.current.values()) h.updateTail(candles)
      }

      if (hoverIdxRef.current == null) latestRef.current?.updateLegendValues(n - 1)

      // FIXED SCREEN: on a new candle the view does NOT move. The new bar
      // simply appears inside the reserved future offset (rightOffset); once
      // that space is used up the "Go to Live →" button appears — the user
      // alone decides to swipe or jump back.
    }

    const unsubCandle = engine.onCandle(handleFlush)
    const unsubHistory = engine.onHistory((candles) => {
      if (replayActiveRef.current) return
      // dataset replaced (symbol/timeframe switch) → reposition ONCE at the
      // live edge, then the screen is fixed again
      positionOnHydrateRef.current = true
      latestRef.current?.fullHydrate(candles)
      drawings.renormalize(candles.length ? candles : lastCandlesRef.current)
    })

    // initial hydration
    latestRef.current?.fullHydrate()
    return () => {
      unsubCandle()
      unsubHistory()
    }
     
  }, [engine, drawings])

  // drawings key per market:timeframe
  useEffect(() => {
    drawings.setKey(`${marketName}:${candleSize}`, lastCandlesRef.current)
  }, [drawings, marketName, candleSize])

  // ══════════════════════════════════════════════ REPLAY subscription
  useEffect(() => {
    if (!replayActive) return

    // `ReplayEngine.start()` emits its initial seek synchronously. React can
    // therefore mount this subscription just after that event; hydrate the
    // current replay prefix immediately so replay never starts from stale live
    // candles.
    // entering replay = switching dataset → reposition once at the replay
    // live edge, then fixed again (also covers the empty-prefix case: the
    // first seek's hydrate will consume the flag)
    positionOnHydrateRef.current = true
    const initialVisible = replay.getVisible()
    if (initialVisible.length > 0) {
      lastCandlesRef.current = initialVisible
      latestRef.current?.fullHydrate(initialVisible)
    }

    const unsubAdvance = replay.onAdvance((candles, info) => {
      const chart = chartRef.current
      const series = mainSeriesRef.current
      if (!chart || !series) return
      lastCandlesRef.current = candles
      if (candles.length === 0) return

      if (info.seeked) {
        // seek (Back to start / slider / step-back) → recentre la vue sur le
        // bord du préfixe révélé et REACTIVE le suivi automatique.
        replayFollowRef.current = true
        positionOnHydrateRef.current = true
        latestRef.current?.fullHydrate(candles)
        return
      }

      const n = candles.length
      const appended = info.appended
      if (appended) {
        latestRef.current?.applyMainTo(series, candles, appended)
        lwcLastBarRef.current = (lwcLastBarRef.current < 0 ? n - 1 : lwcLastBarRef.current) + 1
        const anchor = anchorSeriesRef.current
        if (anchor && n >= 2) {
          const a = candles[n - 2]
          const b = candles[n - 1]
          try {
            anchor.update({ time: a.time as Time, value: Math.max(a.high, b.high) })
            anchor.update({ time: b.time as Time, value: Math.min(a.low, b.low) })
          } catch { /* noop */ }
        }
        latestRef.current?.renderOverlayIndicators(candles, 'tail')
        for (const h of paneHandlesRef.current.values()) h.updateTail(candles)
        if (hoverIdxRef.current == null) latestRef.current?.updateLegendValues(n - 1)

        // FIXED SCREEN pour le LIVE : les bougies s'ajoutent sans bouger la
        // vue. MAIS en REPLAY, sans suivi la lecture passe rapidement
        // hors écran (20 bougies/s) → bougies ET libellés de signal
        // invisibles. Tant que l'utilisateur n'a pas pané, la vue suit la
        // dernière bougie révélée (throttle 180 ms pour rester fluide en
        // lecture rapide).
        if (replayFollowRef.current) {
          const now = Date.now()
          if (now - lastReplayScrollRef.current > 180) {
            lastReplayScrollRef.current = now
            programmaticRangeUntilRef.current = now + 400
            try { chart.timeScale().scrollToRealTime() } catch { /* noop */ }
            if (paneHandlesRef.current.size > 0) {
              syncingRef.current = true
              const r = chart.timeScale().getVisibleLogicalRange()
              if (r) for (const h of paneHandlesRef.current.values()) h.applyRange(r.from, r.to)
              setTimeout(() => { syncingRef.current = false }, 0)
            }
          }
        }
      }
    })

    return () => {
      unsubAdvance()
      // back to live data → reposition once at the live edge, then fixed
      positionOnHydrateRef.current = true
      latestRef.current?.fullHydrate(engine.getCandles())
    }
     
  }, [replayActive, replay, engine])

  // hide main chart time axis when sub-panes are present (bottom pane owns it)
  useEffect(() => {
    chartRef.current?.applyOptions({
      timeScale: { visible: separateInstances.length === 0 && pineSeparateScripts.length === 0 },
    } as any)
  }, [separateInstances.length, pineSeparateScripts.length])

  // ══════════════════════════════════════════════ Pine alerts → toasts
  // Piner records every alert()/alertcondition() event; the chart shows bell
  // markers. This effect surfaces NEW events (on the latest bars) as toast
  // notifications so alerts are impossible to miss — historical backfill from
  // the first full run stays silent, and fast replay is throttled.
  const pineAlertSeenRef = useRef<Map<string, number>>(new Map())
  const pineAlertLastToastRef = useRef(0)
  useEffect(() => {
    const candles = lastCandlesRef.current
    if (!candles.length) return
    const lastTime = toPineTime(Number(candles[candles.length - 1].time))
    const tfMs = candles.length > 1
      ? toPineTime(Number(candles[candles.length - 1].time) - Number(candles[0].time)) / (candles.length - 1)
      : 60_000
    const seen = pineAlertSeenRef.current
    for (const script of pineScripts) {
      if (!script.enabled || !script.result?.alerts?.length) continue
      for (const a of script.result.alerts) {
        if (a.time == null) continue
        const key = `${script.id}|${a.time}|${a.message}`
        if (seen.has(key)) continue
        seen.set(key, Date.now())
        // only events on the ~3 most recent bars toast — the first execution
        // over history must not fire hundreds of notifications
        if (a.time >= lastTime - tfMs * 3) {
          if (Date.now() - pineAlertLastToastRef.current > 1500) {
            pineAlertLastToastRef.current = Date.now()
            toast(`🔔 ${a.message}`, {
              description: `${script.name} · ${marketName}`,
              duration: 6000,
            })
          }
        }
      }
    }
    // prune the seen-map (insertion order) so it cannot grow unbounded
    if (seen.size > 2000) {
      const keep = [...seen.entries()].slice(-1000)
      seen.clear()
      for (const [k, v] of keep) seen.set(k, v)
    }
  }, [pineScripts, marketName])

  // ══════════════════════════════════════════════ sub-pane plumbing
  const registerHandle = useCallback((uid: string, handle: SubPaneHandle | null) => {
    if (handle) {
      paneHandlesRef.current.set(uid, handle)
      if (lastCandlesRef.current.length > 0) {
        handle.setData(lastCandlesRef.current)
        // align with main chart range
        const r = chartRef.current?.timeScale().getVisibleLogicalRange()
        if (r) handle.applyRange(r.from, r.to)
      }
    } else {
      paneHandlesRef.current.delete(uid)
    }
  }, [])

  const onPaneRangeChange = useCallback((uid: string, range: LogicalRange) => {
    if (syncingRef.current) return
    const chart = chartRef.current
    if (!chart) return
    syncingRef.current = true
    try { chart.timeScale().setVisibleLogicalRange(range) } catch { /* noop */ }
    for (const [id, h] of paneHandlesRef.current) {
      if (id !== uid) h.applyRange(range.from, range.to)
    }
    setTimeout(() => { syncingRef.current = false }, 0)
  }, [])

  const onPaneCrosshair = useCallback((uid: string, logical: number | null, time: number | null) => {
    const chart = chartRef.current
    const series = mainSeriesRef.current
    const candles = lastCandlesRef.current
    if (!chart || !series) return
    if (logical == null || time == null) {
      try { chart.clearCrosshairPosition() } catch { /* noop */ }
      hoverIdxRef.current = null
      latestRef.current?.updateLegendValues(candles.length - 1)
      for (const [id, h] of paneHandlesRef.current) {
        if (id !== uid) h.crosshairAt(null, null)
      }
      return
    }
    const idx = Math.round(logical)
    hoverIdxRef.current = idx
    latestRef.current?.updateLegendValues(idx)
    const c = candles[idx]
    if (c) {
      try { chart.setCrosshairPosition(c.close, time as Time, series) } catch { /* noop */ }
    }
    for (const [id, h] of paneHandlesRef.current) {
      if (id !== uid) h.crosshairAt(idx, time)
    }
  }, [])

  // params/visibility changes on sub-panes trigger full re-render via props
  const onPaneParams = useCallback((uid: string, params: Record<string, number>) => {
    updateIndicatorParams(uid, params)
  }, [updateIndicatorParams])

  // Ichimoku cloud is rendered between Span A/B because lightweight-charts
  // has no native two-series fill-between primitive. The canvas follows the
  // chart coordinates and is redrawn whenever the overlay renderer runs.
  const renderIchimokuCloud = useCallback((candles: CandleLike[]) => {
    const canvas = cloudCanvasRef.current
    const chart = chartRef.current
    const series = mainSeriesRef.current
    if (!canvas || !chart || !series || candles.length < 2) return
    const inst = overlayInstances.find((i) => i.defId === 'ichimoku')
    const entry = inst ? overlayRef.current.get(inst.uid) : null
    const def = inst ? INDICATOR_MAP.get(inst.defId) : null
    if (!inst || !entry || !def) { const ctx = canvas.getContext('2d'); ctx?.clearRect(0,0,canvas.width,canvas.height); return }
    const aCfg = inst.plotSettings?.senkouA ?? { visible: true, color: TV.green }
    const bCfg = inst.plotSettings?.senkouB ?? { visible: true, color: TV.orange }
    const showCloud = inst.cloudVisible !== false && aCfg.visible && bCfg.visible
    const rect = containerRef.current?.getBoundingClientRect()
    if (!rect) return
    const dpr = window.devicePixelRatio || 1
    const w = rect.width, h = rect.height
    canvas.width = Math.max(1, Math.round(w*dpr)); canvas.height = Math.max(1, Math.round(h*dpr))
    canvas.style.width = `${w}px`; canvas.style.height = `${h}px`
    const ctx = canvas.getContext('2d'); if (!ctx) return
    ctx.setTransform(dpr,0,0,dpr,0,0); ctx.clearRect(0,0,w,h)
    if (!showCloud) return
    const comp = entry.computed
    if (!comp) return
    const A = comp.senkouA ?? [], B = comp.senkouB ?? []
    const toX = (i:number) => chart.timeScale().logicalToCoordinate((i + (def.plots.find(x=>x.key==='senkouA')?.displacement ?? 0)) as any)
    const toY = (v:number) => series.priceToCoordinate(v)
    const pts: Array<{x:number,yA:number,yB:number}> = []
    for (let i=0;i<candles.length;i++) { const av=A[i],bv=B[i]; if(av==null||bv==null) continue; const x=toX(i); const ya=toY(av),yb=toY(bv); if(x!=null&&ya!=null&&yb!=null) pts.push({x,yA:ya,yB:yb}) }
    if (pts.length<2) return
    ctx.beginPath(); ctx.moveTo(pts[0].x,pts[0].yA); for(const q of pts) ctx.lineTo(q.x,q.yA); for(let i=pts.length-1;i>=0;i--) ctx.lineTo(pts[i].x,pts[i].yB); ctx.closePath()
    ctx.fillStyle = `${aCfg.color}33`; ctx.fill()
    ctx.strokeStyle = `${aCfg.color}22`; ctx.stroke()
  }, [overlayInstances])

  useEffect(() => {
    let raf = 0
    const tick = () => {
      renderIchimokuCloud(lastCandlesRef.current)
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [renderIchimokuCloud])

  // ══════════════════════════════════════════════ render
  const showTimeAxisOnMain = separateInstances.length === 0 && pineSeparateScripts.length === 0

  // keep the latest closures (fresh state) available to stable handlers
  latestRef.current = {
    updateLegendValues: (idx: number | null) => updateLegendValues(idx),
    renderOverlayIndicators,
    applyMainTo,
    fullHydrate,
    overlayInstances,
  }

  return (
    <div className="flex flex-col h-full min-h-0 relative" style={{ background: themeFor(dark).background }}>
      {/* main pane */}
      <div
        ref={containerRef}
        className="relative flex-1 min-h-[220px]"
        style={{ cursor: activeTool !== 'cursor' ? 'crosshair' : 'default', touchAction: activeTool !== 'cursor' ? 'none' : 'auto' }}
      >
        <canvas ref={cloudCanvasRef} className="absolute inset-0 z-[2] pointer-events-none" />
        {/* Pine drawing objects (line/label/box/polyline/linefill, fills,
            bgcolor bands) drawn on a canvas synced to the chart axes. */}
        <PineDrawingsOverlay
          getChart={() => chartRef.current}
          getSeries={() => mainSeriesRef.current}
          getCandles={getCandles}
          dark={dark}
        />
        {/* Pine tables are screen-anchored HTML overlays. */}
        <PineTablesOverlay dark={dark} />
        <DrawingLayer
          manager={drawings}
          getChart={getChartApi}
          getSeries={getMainSeries}
          getCandles={getCandles}
          dark={dark}
          hostRef={containerRef}
          onForecast={onForecast}
        />

        {/* L_Lucien ProTrader — visuels du pack Pine (labels + lignes
            d'événements + lignes de tendance), montage conditionnel à la
            sélection de la stratégie Auto Trade correspondante. Tags et
            libellés MASQUÉS par défaut (switch du panneau Auto Trade). */}
        <BosChochCisdOverlay
          visible={bosChochCisdActive}
          getChart={getChartApi}
          getSeries={getMainSeries}
          getCandles={getCandles}
        />

        {/* Auto Trade / manual trade lifecycle markers: exact entry point +
            high-visibility CALL/PUT triangle + expiry/candle countdown +
            WIN/LOSS result. Display-only: no order logic lives in the chart. */}
        {!replayActive && <TradeMarkersOverlay
          chart={chartRef.current}
          series={mainSeriesRef.current}
          asset={marketName}
          candleSize={candleSize}
          dark={dark}
          trades={tradeVisuals}
          defaultExpirationSeconds={60}
          getCandles={getCandles}
        />}

        {/* TradingView legend */}
        <div className="absolute top-1.5 left-2 z-[6] pointer-events-none text-[11px] leading-[16px] font-medium select-none">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="font-bold" style={{ color: dark ? '#D1D4DC' : '#131722' }}>{marketName || '—'}</span>
            <span style={{ color: '#787B86' }}>· {tfLabel} · PocketOption</span>
            <span className="ml-2 flex items-center gap-1" style={{ color: '#787B86' }}>
              O<span ref={(el) => { ohlcRefs.current['o'] = el }} className="tabular-nums" />
            </span>
            <span className="flex items-center gap-1" style={{ color: '#787B86' }}>
              H<span ref={(el) => { ohlcRefs.current['h'] = el }} className="tabular-nums" />
            </span>
            <span className="flex items-center gap-1" style={{ color: '#787B86' }}>
              L<span ref={(el) => { ohlcRefs.current['l'] = el }} className="tabular-nums" />
            </span>
            <span className="flex items-center gap-1" style={{ color: '#787B86' }}>
              C<span ref={(el) => { ohlcRefs.current['cl'] = el }} className="tabular-nums" />
            </span>
            <span ref={(el) => { chgRef.current = el }} className="tabular-nums" />
          </div>

          {/* overlay indicator legends */}
          {overlayInstances.map((inst) => {
            const def = INDICATOR_MAP.get(inst.defId)
            if (!def) return null
            const title = indicatorTitle(def, inst.params)
            if (!overlayValueRefs.current.has(inst.uid)) {
              overlayValueRefs.current.set(inst.uid, new Map())
            }
            const spans = overlayValueRefs.current.get(inst.uid)!
            const isLegendOpen = legendSettingsUid === inst.uid
            return (
              <div
                key={inst.uid}
                className="flex items-center gap-2 mt-0.5 pointer-events-auto cursor-pointer group w-fit"
                onClick={() => {
                  setLegendSettingsUid(isLegendOpen ? null : inst.uid)
                  setDraftParams(inst.params)
                  setDraftPlotSettings(inst.plotSettings ?? Object.fromEntries(def.plots.map((p) => [p.key, { visible: true, color: p.color }])))
                }}
                style={{ opacity: inst.visible ? 1 : 0.4 }}
              >
                <span className="font-semibold" style={{ color: dark ? '#D1D4DC' : '#131722' }}>{title}</span>
                {def.plots.map((plot) => (
                  <span key={plot.key} className="flex items-center gap-1">
                    <span className="inline-block w-2 h-0.5 rounded" style={{ background: inst.plotSettings?.[plot.key]?.color ?? plot.color }} />
                    <span
                      ref={(el) => { spans.set(plot.key, el) }}
                      className="tabular-nums"
                      style={{ color: inst.plotSettings?.[plot.key]?.color ?? plot.color }}
                    />
                  </span>
                ))}
                {isLegendOpen && (
                  <span
                    className="flex items-center gap-1 p-3 rounded-md border shadow-lg text-[11px] mt-1 absolute top-full left-0"
                    style={{
                      background: dark ? '#1E222D' : '#FFFFFF',
                      borderColor: dark ? '#2A2E39' : '#E0E3EB',
                      color: dark ? '#D1D4DC' : '#131722',
                    }}
                    onClick={(e) => e.stopPropagation()}
                  >
                    <span className="flex flex-col gap-1.5">
                      {def.params.map((p) => (
                        <label key={p.key} className="flex items-center justify-between gap-2 w-40">
                          <span className="opacity-70">{p.label}</span>
                          <input
                            type="number"
                            value={Number.isFinite(draftParams[p.key] ?? p.default) ? (draftParams[p.key] ?? p.default) : ''}
                            min={p.min} max={p.max} step={p.step}
                            onChange={(e) => setDraftParams((prev) => ({ ...prev, [p.key]: e.target.value.trim() === '' ? Number.NaN : Number(e.target.value) }))}
                            className="w-16 px-1.5 py-0.5 rounded border bg-transparent"
                            style={{ borderColor: dark ? '#2A2E39' : '#E0E3EB', color: dark ? '#D1D4DC' : '#131722' }}
                          />
                        </label>
                      ))}
                      {inst.defId === 'ichimoku' && (
                        <label className="flex items-center gap-1.5 text-[11px] pb-1">
                          <input type="checkbox" checked={inst.cloudVisible !== false} onChange={(e) => setIndicatorCloudVisible(inst.uid, e.target.checked)} />
                          <span>Show cloud</span>
                        </label>
                      )}
                      <div className="border-t pt-2 mt-1 flex flex-col gap-1.5">
                        <span className="font-semibold opacity-70">Plots / couleurs</span>
                        {def.plots.map((plot) => {
                          const cfg = draftPlotSettings[plot.key] ?? { visible: true, color: plot.color }
                          return <label key={plot.key} className="flex items-center justify-between gap-2 w-48">
                            <span className="flex items-center gap-1.5">
                              <input type="checkbox" checked={cfg.visible} onChange={(e) => setDraftPlotSettings((prev) => ({ ...prev, [plot.key]: { ...cfg, visible: e.target.checked } }))} />
                              <span>{plot.label}</span>
                            </span>
                            <input type="color" value={cfg.color} onChange={(e) => setDraftPlotSettings((prev) => ({ ...prev, [plot.key]: { ...cfg, color: e.target.value } }))} className="w-7 h-5 p-0 border-0 bg-transparent" title={`Couleur ${plot.label}`} />
                          </label>
                        })}
                      </div>
                      <span className="flex gap-1.5 justify-end">
                        <button
                          title="Toggle visibility"
                          onClick={() => toggleIndicatorVisible(inst.uid)}
                          className="p-1 rounded hover:bg-black/10"
                        >
                          {inst.visible ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
                        </button>
                        <button
                          title="Remove"
                          onClick={() => { removeIndicator(inst.uid); setLegendSettingsUid(null) }}
                          className="p-1 rounded hover:bg-black/10"
                        >
                          <X className="h-3 w-3" />
                        </button>
                        <button
                          className="px-2 py-0.5 rounded text-white text-[10px]"
                          style={{ background: '#2962FF' }}
                          onClick={() => { updateIndicatorParams(inst.uid, draftParams); updateIndicatorPlotSettings(inst.uid, draftPlotSettings); setLegendSettingsUid(null) }}
                        >
                          Apply
                        </button>
                      </span>
                    </span>
                  </span>
                )}
              </div>
            )
          })}
        </div>

        {!atLiveEdge && !replayActive && (
          <button
            onClick={() => {
              // user-triggered ONE-SHOT jump back to the live edge — the
              // screen stays fixed afterwards
              const chart = chartRef.current
              if (!chart) return
              programmaticRangeUntilRef.current = Date.now() + 400
              try { chart.timeScale().scrollToRealTime() } catch { /* noop */ }
              if (paneHandlesRef.current.size > 0) {
                syncingRef.current = true
                const r = chart.timeScale().getVisibleLogicalRange()
                if (r) for (const h of paneHandlesRef.current.values()) h.applyRange(r.from, r.to)
                setTimeout(() => { syncingRef.current = false }, 0)
              }
              setAtLiveEdge(true)
            }}
            className="absolute bottom-16 right-4 z-10 px-3 py-1.5 rounded-md text-[11px] font-semibold text-white shadow-lg"
            style={{ background: '#2962FF' }}
          >
            Go to Live →
          </button>
        )}

        {replayActive && (
          <div className="absolute top-1.5 right-20 z-[7] px-2 py-0.5 rounded text-[10px] font-bold"
            style={{ background: '#FF6D00', color: '#fff' }}>
            REPLAY MODE
          </div>
        )}
      </div>

      {/* synchronized oscillator panes */}
      {separateInstances.map((inst, i) => (
        <SubPane
          key={inst.uid}
          ref={(h: SubPaneHandle | null) => {
            // React 19 runs useImperativeHandle only when a ref is attached —
            // register the handle here (guarded against duplicate pushes).
            if (h) {
              if (paneHandlesRef.current.get(inst.uid) !== h) registerHandle(inst.uid, h)
            } else {
              registerHandle(inst.uid, null)
            }
          }}
          instance={inst}
          dark={dark}
          showTimeAxis={i === separateInstances.length - 1 && pineSeparateScripts.length === 0 && !showTimeAxisOnMain}
          onRemove={removeIndicator}
          onToggleVisible={toggleIndicatorVisible}
          onParams={onPaneParams}
          onPlotSettings={updateIndicatorPlotSettings}
          onRangeChange={onPaneRangeChange}
          onCrosshair={onPaneCrosshair}
          registerHandle={registerHandle}
        />
      ))}

      {/* synchronized Pine oscillator panes — one per non-overlay script */}
      {pineSeparateScripts.map((s, i) => (
        <PineSubPane
          key={s.id}
          ref={(h: SubPaneHandle | null) => {
            if (h) {
              if (paneHandlesRef.current.get(`pine:${s.id}`) !== h) registerHandle(`pine:${s.id}`, h)
            } else {
              registerHandle(`pine:${s.id}`, null)
            }
          }}
          scriptId={s.id}
          getCandles={getCandles}
          dark={dark}
          showTimeAxis={i === pineSeparateScripts.length - 1 && !showTimeAxisOnMain}
          onRemove={removePineScript}
          onToggle={togglePineScript}
          registerHandle={registerHandle}
        />
      ))}

      {replayActive && <ReplayBar replay={replay} dark={dark} onExit={() => {
        replay.stop()
        setReplayActive(false)
      }} />}
    </div>
  )
}
