'use client'

import { useEffect, useMemo, useRef, useState } from 'react'
import type { IChartApi, ISeriesApi } from 'lightweight-charts'

export interface TradeMarkerRecord {
  id: string | number
  asset: string
  action: 'call' | 'put'
  amount: number
  openPrice: number
  openTime: number
  closeTime?: number
  closePrice?: number
  profit?: number
  isWin?: boolean
  expirationSeconds?: number
  source?: string
  /** v22 — libellé d'ordre : stratégie + combinaison + règle de validation. */
  label?: string
}

export interface TradeMarkerPosition {
  id: string
  action: 'call' | 'put'
  openPrice: number
  openTime: number
  amount: number
  profit?: number
  isClosed: boolean
  isWin?: boolean
  closeTime?: number
  expirationSeconds: number
  /** v22 — libellé d'ordre (combinaison + validation) rendu sur la carte. */
  label?: string
  x: number
  y: number
}

interface TradeMarkersOverlayProps {
  chart: IChartApi | null
  series: ISeriesApi<any> | null
  asset: string
  candleSize: number
  dark: boolean
  trades: TradeMarkerRecord[]
  defaultExpirationSeconds: number
  getCandles?: () => Array<{ time: number }>
}

function formatCountdown(totalSeconds: number): string {
  const s = Math.max(0, Math.ceil(totalSeconds))
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const sec = s % 60
  if (h > 0) return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
  return `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`
}

function decomposeExpiry(totalSeconds: number, candleSize: number): string {
  const exp = Math.max(0, Math.floor(totalSeconds))
  const tf = Math.max(1, Math.round(candleSize))
  const candles = Math.floor(exp / tf)
  const rest = exp % tf
  if (candles > 0 && rest > 0) return `${candles} bougies + ${rest}s`
  if (candles > 0) return `${candles} bougie${candles > 1 ? 's' : ''}`
  return `${rest}s`
}

function candleCountdown(nowSec: number, candleSize: number, latestCandleTime?: number): number {
  const tf = Math.max(1, Math.round(candleSize))
  if (Number.isFinite(latestCandleTime) && (latestCandleTime as number) > 0) {
    const start = latestCandleTime as number
    const end = start + tf
    const remaining = end - nowSec
    // The live candle can be slightly behind the client clock. Keep the value
    // within a single candle rather than displaying a negative or giant timer.
    if (remaining > 0 && remaining <= tf + 2) return remaining
  }
  const elapsed = ((nowSec % tf) + tf) % tf
  return tf - elapsed
}

function mergeTradeRecords(
  tradeVisuals: TradeMarkerRecord[],
  asset: string,
): TradeMarkerRecord[] {
  const byId = new Map<string, TradeMarkerRecord>()
  for (const t of tradeVisuals) {
    if (!t || t.asset !== asset) continue
    const id = String(t.id)
    byId.set(id, t)
  }
  return [...byId.values()].sort((a, b) => a.openTime - b.openTime).slice(-120)
}

export function TradeMarkersOverlay({
  chart,
  series,
  asset,
  candleSize,
  dark,
  trades,
  defaultExpirationSeconds,
  getCandles,
}: TradeMarkersOverlayProps) {
  const [nowMs, setNowMs] = useState(() => Date.now())
  const latestCandleTimeRef = useRef<number | undefined>(undefined)
  const [positions, setPositions] = useState<TradeMarkerPosition[]>([])

  const assetTrades = useMemo(() => mergeTradeRecords(trades, asset), [trades, asset])

  useEffect(() => {
    if (assetTrades.length === 0) return
    const id = window.setInterval(() => setNowMs(Date.now()), 250)
    return () => window.clearInterval(id)
  }, [assetTrades.length])

  useEffect(() => {
    if (!chart || !series) return

    const recalc = () => {
      try {
        const liveCandles = getCandles?.() ?? []
        const latestCandleTime = liveCandles.length > 0 ? Number(liveCandles[liveCandles.length - 1].time) : undefined
        if (Number.isFinite(latestCandleTime)) latestCandleTimeRef.current = latestCandleTime

        const next: TradeMarkerPosition[] = []
        const timeScale = chart.timeScale()

        for (const t of assetTrades) {
          if (!Number.isFinite(t.openPrice) || t.openTime <= 0) continue
          const x = timeScale.timeToCoordinate(t.openTime as any)
          const y = series.priceToCoordinate(t.openPrice)
          if (x == null || y == null || !Number.isFinite(x) || !Number.isFinite(y)) continue

          const expirationSeconds = Math.max(1, Number(t.expirationSeconds ?? defaultExpirationSeconds ?? candleSize ?? 60))
          const isClosed = Number.isFinite(t.closeTime) && Number(t.closeTime) > 0
          next.push({
            id: String(t.id),
            action: t.action,
            openPrice: t.openPrice,
            openTime: t.openTime,
            amount: t.amount,
            profit: t.profit,
            isClosed,
            isWin: t.isWin,
            closeTime: t.closeTime,
            expirationSeconds,
            label: t.label,
            x,
            y,
          })
        }
        setPositions(next)
      } catch {
        // Chart may be between resize/rebuild operations.
      }
    }

    recalc()
    const timeScale = chart.timeScale()
    timeScale.subscribeVisibleLogicalRangeChange(recalc)
    const onResize = () => recalc()
    window.addEventListener('resize', onResize)
    const timer = window.setInterval(recalc, 1000)
    return () => {
      // lightweight-charts 4.x : subscribe retourne void → désabonnement
      // explicite via unsubscribeVisibleLogicalRangeChange(handler).
      try { timeScale.unsubscribeVisibleLogicalRangeChange(recalc) } catch {}
      window.removeEventListener('resize', onResize)
      window.clearInterval(timer)
    }
  }, [chart, series, assetTrades, candleSize, defaultExpirationSeconds, getCandles])

  if (positions.length === 0) return null

  const nowSec = nowMs / 1000
  // Use the most recent candle represented by the chart's visible/live data.
  // We do not have to mutate the chart; this is display-only timing.
  const candleRemaining = candleCountdown(nowSec, candleSize, latestCandleTimeRef.current)

  return (
    <div className="absolute inset-0 z-[8] pointer-events-none overflow-hidden select-none">
      {positions.map((p) => {
        const remaining = p.isClosed
          ? 0
          : Math.max(0, p.openTime + p.expirationSeconds - nowSec)
        const color = p.action === 'call' ? '#00F57A' : '#FF3654'
        const isWin = p.isClosed && p.isWin === true
        const isLoss = p.isClosed && p.isWin === false
        const title = p.action === 'call' ? 'CALL' : 'PUT'
        const triangle = p.action === 'call' ? '▲' : '▼'
        const triangleTop = p.action === 'call' ? p.y - 38 : p.y + 16
        const cardTop = p.action === 'call' ? p.y - 102 : p.y + 46
        const maxCardTop = Math.max(3, Math.min(Math.max(3, (typeof window !== 'undefined' ? window.innerHeight : 720) - 180), cardTop))
        const candleLife = candleRemaining
        const resultText = isWin
          ? `✓ GAIN${Number.isFinite(p.profit) ? ` +$${Number(p.profit).toFixed(2)}` : ''}`
          : isLoss
            ? `✕ PERTE${Number.isFinite(p.profit) ? ` $${Number(p.profit).toFixed(2)}` : ''}`
            : null

        return (
          <div key={p.id} className="absolute" style={{ left: p.x, top: 0 }}>
            {/* exact entry point */}
            <div
              className="absolute rounded-full"
              style={{
                left: -4,
                top: p.y - 4,
                width: 8,
                height: 8,
                background: '#FFFFFF',
                boxShadow: `0 0 0 2px ${color}, 0 0 12px 3px ${color}88`,
              }}
            />

            {/* high-visibility direction triangle */}
            <div
              className="absolute font-black leading-none"
              style={{
                left: -13,
                top: triangleTop,
                color,
                fontSize: 27,
                lineHeight: '27px',
                WebkitTextStroke: `1.25px ${dark ? '#0B1018' : '#FFFFFF'}`,
                textShadow: `0 0 5px ${color}, 0 0 12px ${color}`,
                filter: `drop-shadow(0 2px 3px ${dark ? '#000000' : '#1b1b1b'}99)`,
              }}
              aria-label={title}
            >
              {triangle}
            </div>

            {/* trade lifecycle card */}
            <div
              className="absolute rounded-md border px-2 py-1.5 font-mono whitespace-nowrap"
              style={{
                left: 10,
                top: Math.max(3, maxCardTop),
                borderColor: `${color}99`,
                background: dark ? 'rgba(11,16,24,.94)' : 'rgba(255,255,255,.94)',
                color: dark ? '#F4F7FB' : '#101317',
                boxShadow: `0 2px 14px ${color}28`,
                fontSize: 10,
                minWidth: 132,
              }}
            >
              <div className="font-bold" style={{ color }}>
                {triangle} {title} · ${Number.isFinite(p.amount) ? p.amount.toFixed(0) : '—'}
              </div>
              {/* v22 — LIBELLÉ D'ORDRE : combinaison qui a placé l'ordre +
                  règle de validation (texte complet au survol). */}
              {p.label && (
                <div
                  className="opacity-80 max-w-[190px] whitespace-nowrap overflow-hidden text-ellipsis"
                  style={{ color: dark ? '#B7BDC6' : '#4A5568' }}
                  title={p.label}
                >
                  {p.label}
                </div>
              )}
              {!p.isClosed ? (
                <>
                  <div className="opacity-90">EXP {formatCountdown(remaining)}</div>
                  <div className="opacity-70">≈ {decomposeExpiry(remaining, candleSize)}</div>
                  <div className="opacity-90">BOUGIE {formatCountdown(candleLife)}</div>
                </>
              ) : (
                <>
                  <div className={isWin ? 'font-bold' : 'font-bold'} style={{ color: isWin ? '#00D96B' : '#FF3654' }}>
                    {resultText}
                  </div>
                  <div className="opacity-65">EXP {formatCountdown(0)}</div>
                  <div className="opacity-65">BOUGIE {formatCountdown(candleLife)}</div>
                </>
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}
