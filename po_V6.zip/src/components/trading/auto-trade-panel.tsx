'use client'

import { useEffect, useState } from 'react'
import {
  Bot, Play, Square, Activity, Target, ShieldCheck, TrendingUp, TrendingDown,
} from 'lucide-react'
import { englishizeText } from '@/lib/english-ui'
import type { AutoTradeStatus } from '@/hooks/use-pocket-option'
import {
  loadBosChochCisdSettings,
  saveBosChochCisdSettings,
  resetBosChochCisdSettings,
  subscribeBosChochCisdSettings,
} from '@/lib/bos-choch-cisd-settings'
import type { BosChochCisdOrderCondition, BosChochCisdOrderRule, BosChochCisdSettings, CisdGuardConfig } from '../../../shared/bos-choch-cisd'
import { normalizeCandlesValidation, normalizeCisdGuardConfig } from '../../../shared/bos-choch-cisd'
import {
  CANDLE_PATTERN_DEFS,
  CANDLE_PATTERN_BY_ID,
  type CandlePatternId,
} from '../../../shared/candle-patterns'
import { signalLabel } from '../../../shared/signal-registry'
import { SignalDisplayFields } from '@/components/trading/chart/signal-display-fields'

/* ═══════════ L_Lucien ProTrader — réglages du pack Pine ═══════════ */

/** Lignes du groupe « Labels » du pack (couleur + libellé exact TradingView). */
const BCC_LABEL_COLOURS: Array<{ key: keyof BosChochCisdSettings; label: string }> = [
  { key: 'bosUpLabelColour', label: 'BOS Up Label Colour' },
  { key: 'bosDownLabelColour', label: 'BOS Down Label Colour' },
  { key: 'chochUpLabelColour', label: 'CHoCH Up Label Colour' },
  { key: 'chochDownLabelColour', label: 'CHoCH Down Label Colour' },
  { key: 'cisdUpLabelColour', label: 'CISD Up Label Colour' },
  { key: 'cisdDownLabelColour', label: 'CISD Down Label Colour' },
  { key: 'textColour', label: 'Label Text Colour' },
]

const BCC_SIZES: BosChochCisdSettings['labelSize'][] = ['Tiny', 'Small', 'Normal', 'Large', 'Huge', 'Auto']

/* v26 — Conditions du Rule Builder : les 6 alertes du pack + les 73
 * patterns candle du pack source, groupés par direction (§11). */
const BCC_ORDER_OPTIONS: Array<{ key: BosChochCisdOrderCondition; label: string; side: 'up' | 'down'; kind: 'structure' | 'candle' }> = [
  { key: 'BOS Up', label: 'BOS Up', side: 'up', kind: 'structure' },
  { key: 'BOS Down', label: 'BOS Down', side: 'down', kind: 'structure' },
  { key: 'CHoCH Up', label: 'CHoCH Up', side: 'up', kind: 'structure' },
  { key: 'CHoCH Down', label: 'CHoCH Down', side: 'down', kind: 'structure' },
  { key: 'CISD Up', label: 'CISD Up', side: 'up', kind: 'structure' },
  { key: 'CISD Down', label: 'CISD Down', side: 'down', kind: 'structure' },
]

/** Options du sélecteur « + condition » (§11) — 6 alertes + 73 candles. */
const CONDITION_ADD_OPTIONS: Array<{ value: string; label: string; group: string }> = [
  ...BCC_ORDER_OPTIONS.map((o) => ({ value: o.key, label: o.label, group: 'STRUCTURE' })),
  ...CANDLE_PATTERN_DEFS.filter((d) => d.direction === 'bullish').map((d) => ({ value: d.id, label: d.label, group: 'CANDLE PATTERNS · Bullish' })),
  ...CANDLE_PATTERN_DEFS.filter((d) => d.direction === 'bearish').map((d) => ({ value: d.id, label: d.label, group: 'CANDLE PATTERNS · Bearish' })),
  ...CANDLE_PATTERN_DEFS.filter((d) => d.direction === 'neutral').map((d) => ({ value: d.id, label: d.label, group: 'CANDLE PATTERNS · Neutral (contexte)' })),
]

/** Valeurs du mode « Candles » de l'expiration (§15). */
const EXPIRY_CANDLE_OPTIONS = [1, 2, 3, 5, 10]

function isCandleConditionKey(key: string): boolean {
  return Boolean(CANDLE_PATTERN_BY_ID[key as CandlePatternId])
}

function conditionDisplayLabel(key: string): string {
  return signalLabel(key)
}

function BccRuleEditor({
  side, rules, disabled, onChange,
}: {
  side: 'CALL' | 'PUT'
  rules: BosChochCisdOrderRule[]
  disabled?: boolean
  onChange: (rules: BosChochCisdOrderRule[]) => void
}) {
  const addRule = () => {
    const id = `${side.toLowerCase()}-${Date.now()}`
    onChange([...rules, { id, alerts: side === 'CALL' ? ['BOS Up'] : ['BOS Down'], expirationMode: 'seconds', expirationSeconds: 60 }])
  }
  const updateRule = (index: number, patch: Partial<BosChochCisdOrderRule>) => {
    onChange(rules.map((r, i) => i === index ? { ...r, ...patch } : r))
  }
  /* v26 — conditions MIXTES : ajouter/retirer une condition (alerte pack
   * OU pattern candle) — logique AND entre toutes (§12). */
  const addCondition = (index: number, cond: string) => {
    const rule = rules[index]
    if (!cond || rule.alerts.includes(cond as BosChochCisdOrderCondition)) return
    updateRule(index, { alerts: [...rule.alerts, cond as BosChochCisdOrderCondition] })
  }
  const removeCondition = (index: number, cond: string) => {
    const rule = rules[index]
    const alerts = rule.alerts.filter((a) => a !== cond)
    if (!alerts.length) return
    updateRule(index, { alerts })
  }
  const toggleAlert = (index: number, alert: BosChochCisdOrderCondition) => {
    const rule = rules[index]
    const has = rule.alerts.includes(alert)
    const alerts = has ? rule.alerts.filter((a) => a !== alert) : [...rule.alerts, alert]
    if (!alerts.length) return
    updateRule(index, { alerts })
  }
  // v22 — « Candles Validation » : saisie R/G (max 5), majuscules forcées.
  // Vide = aucune validation (l'ordre suit la combinaison seule).
  const setValidation = (index: number, raw: string) => {
    const clean = normalizeCandlesValidation(raw)
    updateRule(index, { candlesValidation: clean || undefined })
  }
  /* v25/v26 — MODES D'EXPIRATION par règle :
   *   Seconds   : champ numérique 3..86400 (historique) ;
   *   Candles   : expirationCandles ∈ {1,2,3,5,10} + champ libre (§15) ;
   *   remaining : switch « remaining Time Before Candle Closure » (v25) —
   *               une fois ON il REMPLACE le champ Expiration : l'ordre
   *               expire au temps restant avant clôture de la bougie du
   *               signal (compteur 00:18 → 18 s). */
  const ruleMode = (rule: BosChochCisdOrderRule): 'seconds' | 'candles' | 'remaining' =>
    rule.remainingTimeBeforeClosure ? 'remaining' : rule.expirationMode === 'candles' ? 'candles' : 'seconds'
  const setMode = (index: number, mode: 'seconds' | 'candles' | 'remaining') => {
    const rule = rules[index]
    if (mode === 'seconds') {
      updateRule(index, { remainingTimeBeforeClosure: false, expirationMode: 'seconds', expirationCandles: undefined, expirationSeconds: rule.expirationSeconds ?? 60 })
    } else if (mode === 'candles') {
      updateRule(index, { remainingTimeBeforeClosure: false, expirationMode: 'candles', expirationCandles: rule.expirationCandles ?? 3, expirationSeconds: undefined })
    } else {
      updateRule(index, { remainingTimeBeforeClosure: true, expirationMode: 'remaining', expirationCandles: undefined, expirationSeconds: undefined })
    }
  }
  return (
    <div className="space-y-1.5">
      {rules.map((rule, index) => {
        const mode = ruleMode(rule)
        const candleConds = rule.alerts.filter((a) => isCandleConditionKey(a))
        return (
        <div key={rule.id} className="rounded-lg border border-zinc-200 dark:border-zinc-800 p-1.5 space-y-1.5">
          <div className="flex items-center gap-1.5">
            <span className={'px-1.5 py-0.5 rounded font-bold text-[8px] ' + (side === 'CALL' ? 'bg-emerald-500/10 text-emerald-600' : 'bg-red-500/10 text-red-600')}>
              {side === 'CALL' ? 'CALL ▲' : 'PUT ▼'}
            </span>
            <span className="text-[8px] text-zinc-500">règle {index + 1}</span>
            <div className="ml-auto flex items-center gap-1">
              <button type="button" disabled={disabled} onClick={() => onChange(rules.filter((_, i) => i !== index))} className="px-1 text-[10px] text-red-500" title="Supprimer la règle">×</button>
            </div>
          </div>

          {/* ── Conditions AND (§9/§10/§12) : alertes pack + patterns candle ── */}
          <div className="grid grid-cols-2 gap-1">
            {BCC_ORDER_OPTIONS.map((opt) => {
              const selected = rule.alerts.includes(opt.key)
              return (
                <button key={opt.key} type="button" disabled={disabled} onClick={() => toggleAlert(index, opt.key)}
                  className={'px-1.5 py-1 rounded border text-[8px] text-left ' + (selected ? (opt.side === 'up' ? 'border-emerald-500 bg-emerald-500/10 text-emerald-600' : 'border-red-500 bg-red-500/10 text-red-600') : 'border-zinc-200 dark:border-zinc-800 text-zinc-500')}
                >{selected ? '✓ ' : '○ '}{opt.label}</button>
              )
            })}
          </div>

          {/* Sélecteur « + condition » — les 73 patterns (§11) + chips des conditions candle */}
          <div className="space-y-1">
            <select
              value=""
              disabled={disabled}
              onChange={(e) => { addCondition(index, e.target.value); e.currentTarget.value = '' }}
              className="w-full px-1.5 py-1 rounded border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-[8px] text-zinc-600 dark:text-zinc-300 disabled:opacity-50"
              title="Ajouter une condition candlestick (logique AND — les 73 patterns du pack source) — ex. Bullish Engulfing"
            >
              <option value="">+ Condition candlestick (73 patterns)…</option>
              {CONDITION_ADD_OPTIONS.map((o) => (
                <option key={o.value} value={o.value} disabled={rule.alerts.includes(o.value as BosChochCisdOrderCondition)}>{o.label} — {o.group}</option>
              ))}
            </select>
            {candleConds.length > 0 && (
              <div className="flex flex-wrap gap-1">
                {candleConds.map((c) => (
                  <button key={c} type="button" disabled={disabled} onClick={() => removeCondition(index, c)}
                    className="px-1.5 py-0.5 rounded-full border border-blue-500/40 bg-blue-500/10 text-[8px] font-semibold text-blue-600 dark:text-blue-400"
                    title={`${conditionDisplayLabel(c)} — cliquer pour retirer la condition`}
                  >{conditionDisplayLabel(c)} ×</button>
                ))}
              </div>
            )}
          </div>

          {/* ── Expiration par MODE (§15/§25 v25) ── */}
          <div className="rounded-md border border-zinc-200 dark:border-zinc-800 p-1.5 space-y-1">
            <div className="flex items-center gap-1">
              <label className="text-[8px] text-zinc-500 shrink-0 font-semibold">Expiration</label>
              <div className="flex gap-0.5">
                {(['seconds', 'candles', 'remaining'] as const).map((m) => (
                  <button key={m} type="button" disabled={disabled} onClick={() => setMode(index, m)}
                    className={'px-1.5 py-0.5 rounded text-[8px] font-semibold border ' + (mode === m ? 'border-blue-500 bg-blue-500/10 text-blue-600 dark:text-blue-400' : 'border-zinc-200 dark:border-zinc-800 text-zinc-500')}
                    title={m === 'seconds' ? 'Expiration en secondes (3 à 86400)' : m === 'candles' ? 'Expiration en nombre de bougies (le Strategy Tester l\u2019utilise directement ; le broker reçoit candles × durée de bougie)' : 'remaining Time Before Candle Closure — le temps restant avant clôture de la bougie qui reçoit le signal (compteur 00:18 → 18 s) remplace le champ Expiration'}
                  >{m === 'seconds' ? 'Secondes' : m === 'candles' ? 'Bougies' : 'remaining Time'}</button>
                ))}
              </div>
            </div>
            {mode === 'seconds' && (
              <div className="flex items-center gap-1.5">
                <input
                  type="number" min={3} max={86400} step={1}
                  value={rule.expirationSeconds ?? ''}
                  disabled={disabled}
                  onChange={(e) => { const raw = e.target.value.trim(); if (raw === '') { updateRule(index, { expirationSeconds: undefined }); return }; const n = Number(raw); if (Number.isFinite(n)) updateRule(index, { expirationSeconds: Math.max(3, Math.min(86400, Math.round(n))) }) }}
                  className="w-16 px-1.5 py-1 rounded border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-[9px] font-mono"
                  title="Expiration obligatoire en secondes (3 à 86400) — aucune valeur automatique"
                />
                <span className="text-[8px] text-zinc-500">s</span>
              </div>
            )}
            {mode === 'candles' && (
              <div className="flex items-center gap-1.5">
                <div className="flex gap-0.5">
                  {EXPIRY_CANDLE_OPTIONS.map((n) => (
                    <button key={n} type="button" disabled={disabled} onClick={() => updateRule(index, { expirationCandles: n })}
                      className={'px-1.5 py-0.5 rounded border text-[8px] font-mono ' + (rule.expirationCandles === n ? 'border-blue-500 bg-blue-500/10 text-blue-600 dark:text-blue-400' : 'border-zinc-200 dark:border-zinc-800 text-zinc-500')}
                      title={`Expiration = ${n} bougie(s)`}
                    >{n}</button>
                  ))}
                </div>
                <input
                  type="number" min={1} max={50} step={1}
                  value={rule.expirationCandles ?? ''}
                  disabled={disabled}
                  onChange={(e) => { const raw = e.target.value.trim(); if (raw === '') { updateRule(index, { expirationCandles: undefined }); return }; const n = Number(raw); if (Number.isFinite(n)) updateRule(index, { expirationCandles: Math.max(1, Math.min(50, Math.round(n))) }) }}
                  className="w-12 px-1.5 py-1 rounded border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-[9px] font-mono"
                  title="Expiration en bougies (1 à 50)"
                />
                <span className="text-[8px] text-zinc-500">bougie(s)</span>
              </div>
            )}
            {mode === 'remaining' && (
              <div className="text-[8px] leading-snug text-zinc-500 bg-amber-500/5 border border-amber-500/20 rounded px-1.5 py-1">
                <b>remaining Time Before Candle Closure</b> : l’ordre expire au temps restant avant la clôture de la bougie qui reçoit le signal (compteur 00:18 → 18 s). Ce switch remplace le champ Expiration.
              </div>
            )}
          </div>

          {/* v22 — « Candles Validation » : règle de validation des bougies
              (R = Rouge, G = Vert ; max 5, lue de la bougie clôturée la plus
              récente à la plus ancienne — jamais la bougie en formation). */}
          <div className="flex items-center gap-1.5">
            <label className="text-[8px] text-zinc-500 shrink-0 font-semibold" title="Règle de validation des bougies avant l'ordre — R = Rouge, G = Vert, lue de la bougie clôturée la plus récente à la plus ancienne (max 5, jamais la bougie en formation). Vide = aucune validation.">
              Candles Validation
            </label>
            <input
              type="text"
              value={rule.candlesValidation ?? ''}
              placeholder="ex. RGRR"
              maxLength={12}
              disabled={disabled}
              onChange={(e) => setValidation(index, e.target.value)}
              className="w-[72px] px-1.5 py-1 rounded border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-[9px] font-mono uppercase tracking-wide"
              title="R = Rouge, G = Vert — max 5 bougies, lues de la plus récente à la plus ancienne bougie CLÔTURÉE (jamais la bougie en formation). Vide = aucune validation."
            />
            <span className="text-[8px] text-zinc-500">R/G · max 5</span>
          </div>
          <div className="text-[8px] text-zinc-500">Déclenchement AND : toutes les conditions (alertes + patterns) doivent être présentes sur la même bougie + la règle de bougies (si définie) validée. Une expiration doit être définie pour autoriser l’ordre. Combinaisons CISD : étapes « Vérification CISD » ci-dessous.</div>
        </div>
        )
      })}
      <button type="button" disabled={disabled} onClick={addRule} className="w-full rounded-lg border border-dashed border-zinc-300 dark:border-zinc-700 px-2 py-1.5 text-[9px] font-semibold text-zinc-600 dark:text-zinc-300 hover:border-blue-400">+ Ajouter une règle {side === 'CALL' ? 'CALL ▲' : 'PUT ▼'}</button>
    </div>
  )
}

function LucienProTraderFields({
  disabled, onConfigChange, confirmCandle, onConfirmCandleChange, strategyId,
}: {
  disabled?: boolean
  onConfigChange: AutoTradePanelProps['onConfigChange']
  /** v19 — état du switch « Confirmation bougie précédente » (backend). */
  confirmCandle: boolean
  /** v19 — bascule le switch « Confirmation bougie précédente ». */
  onConfirmCandleChange: (enabled: boolean) => void
  /** v22 — stratégie active (l_lucien_protrader | ninja_protrader) : les
   * réglages sont partagés (copie conforme), seuls le titre et la note
   * d'exécution changent. */
  strategyId: string
}) {
  const [settings, setSettings] = useState<BosChochCisdSettings>(() => loadBosChochCisdSettings())
  const isNinja = strategyId === 'ninja_protrader'
  const strategyTitle = isNinja ? 'Ninja ProTrader' : 'L_Lucien ProTrader'

  useEffect(() => subscribeBosChochCisdSettings(setSettings), [])

  /* v26 — RÈGLES PAR STRATÉGIE (§31) : Ninja édite SES règles propres
   * (ninjaCallRules/ninjaPutRules), L_Lucien les règles partagées —
   * elles ne se mélangent PAS. Les deux sont poussées au backend. */
  const activeCallRules = isNinja ? (settings.ninjaCallRules ?? []) : settings.callRules
  const activePutRules = isNinja ? (settings.ninjaPutRules ?? []) : settings.putRules
  const setActiveRules = (callRules: BosChochCisdOrderRule[], putRules: BosChochCisdOrderRule[]) => {
    if (isNinja) {
      saveBosChochCisdSettings({ ninjaCallRules: callRules, ninjaPutRules: putRules })
      onConfigChange({ ninjaBosChochCisdCallRules: callRules, ninjaBosChochCisdPutRules: putRules } as never)
    } else {
      saveBosChochCisdSettings({ callRules, putRules })
      onConfigChange({ bosChochCisdCallRules: callRules, bosChochCisdPutRules: putRules })
    }
  }
  /* Pousse les DEUX jeux au backend au premier montage et à chaque
   * changement (le backend choisit selon la stratégie active). */
  useEffect(() => {
    onConfigChange({
      bosChochCisdCallRules: settings.callRules,
      bosChochCisdPutRules: settings.putRules,
      ninjaBosChochCisdCallRules: settings.ninjaCallRules ?? settings.callRules,
      ninjaBosChochCisdPutRules: settings.ninjaPutRules ?? settings.putRules,
    } as never)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings.callRules, settings.putRules, settings.ninjaCallRules, settings.ninjaPutRules])

  const setColour = (key: keyof BosChochCisdSettings, value: string) => {
    saveBosChochCisdSettings({ [key]: value } as Partial<BosChochCisdSettings>)
  }

  // v24 — cases « Vérification CISD » (étapes optionnelles) : configuration
  // normalisée depuis les réglages persistés, poussée au backend à chaque
  // changement (clés plates cisdGuard* du set-auto-config).
  const guard = normalizeCisdGuardConfig(settings.cisdGuard)
  const applyGuard = (patch: Partial<CisdGuardConfig>) => {
    const next = { ...guard, ...patch }
    saveBosChochCisdSettings({ cisdGuard: next })
    onConfigChange({
      cisdGuardUp: next.up,
      cisdGuardDown: next.down,
      cisdGuardSwingMode: next.swingMode,
      cisdGuardConfirmBosUp: next.confirmBosUp,
      cisdGuardConfirmChochUp: next.confirmChochUp,
      cisdGuardConfirmBosDown: next.confirmBosDown,
      cisdGuardConfirmChochDown: next.confirmChochDown,
    })
  }

  return (
    <div className="rounded-lg border border-zinc-200 dark:border-zinc-800 p-2 space-y-2">
      <div className="flex items-center justify-between">
        <div className="text-[10px] font-semibold text-zinc-700 dark:text-zinc-200">{strategyTitle}</div>
        {isNinja ? (
          <span className="text-[8px] font-mono text-orange-500 dark:text-orange-400">DÉTECTION AVANT CLÔTURE · TEMPS RÉEL</span>
        ) : (
          <span className="text-[8px] font-mono text-emerald-600 dark:text-emerald-400">STRUCTURE · 2 SWINGS</span>
        )}
      </div>
      {isNinja && (
        <div className="rounded-md bg-orange-500/5 border border-orange-500/20 p-1.5 text-[8px] leading-snug text-zinc-500">
          Ninja ProTrader : les signaux BOS/CHoCH/CISD sont détectés <b>AVANT la clôture</b> de la bougie en formation (prix temps réel, polling 500 ms) — l’ordre part immédiatement au franchissement du niveau de swing. La Candles Validation s’ancre sur la dernière bougie <b>CLÔTURÉE</b> (la bougie en formation n’est jamais validée).
        </div>
      )}

      {/* v24 — Vérification CISD : étapes OPTIONNELLES (cases à cocher).
          L'utilisateur choisit : activation par direction (CISD UP /
          CISD DOWN), état exigé du swing (NON violé = v23, ou VIOLÉ =
          sweep de liquidité), et les combinaisons de confirmation
          acceptées (BOS + CISD et/ou CHoCH + CISD) pour le CALL ▲ et le
          PUT ▼. Partagé L_Lucien ProTrader / Ninja ProTrader / Strategy
          Tester. Défaut = v23 intégral (tout coché, swing non violé). */}
      <div className="rounded-lg border border-blue-500/30 bg-blue-500/5 p-2 space-y-1.5">
        <div className="text-[9px] font-semibold text-zinc-700 dark:text-zinc-200">Vérification CISD — étapes optionnelles</div>

        {/* Étape 0 — activation par direction */}
        <div className="grid grid-cols-2 gap-1.5">
          {([['up', 'Vérifier CISD UP', 'swing high', 'CALL ▲'], ['down', 'Vérifier CISD DOWN', 'swing low', 'PUT ▼']] as const).map(([dir, label, swingTxt, orderTxt]) => {
            const checked = dir === 'up' ? guard.up : guard.down
            return (
              <button
                key={dir}
                type="button"
                disabled={disabled}
                aria-pressed={checked}
                onClick={() => applyGuard(dir === 'up' ? { up: !checked } : { down: !checked })}
                title={checked
                  ? `Vérification CISD ${dir === 'up' ? 'Up' : 'Down'} ACTIVE — CISD seul vérifie le ${swingTxt} le plus proche puis attend le signal combiné avant l'ordre ${orderTxt}. Cliquer pour désactiver (ordre direct).`
                  : `Vérification CISD ${dir === 'up' ? 'Up' : 'Down'} DÉSACTIVÉE — les combinaisons CISD ${dir === 'up' ? 'Up' : 'Down'} placent leurs ordres directement. Cliquer pour activer la protection.`}
                className={'px-1.5 py-1 rounded border text-[8px] text-left font-semibold ' + (checked
                  ? 'border-blue-500 bg-blue-500/10 text-blue-600 dark:text-blue-400'
                  : 'border-zinc-200 dark:border-zinc-800 text-zinc-500')}
              >{checked ? '✓ ' : '○ '}{label}</button>
            )
          })}
        </div>

        {/* Étape 1 — état exigé du swing au CISD seul — v25 : TOUT
            DÉCOCHER EST PERMIS (les deux cases → étape swing IGNORÉE). */}
        <div>
          <div className="text-[8px] text-zinc-500 mb-0.5">Étape 1 — état du swing au CISD seul <span className="text-amber-600 dark:text-amber-400">(tout décocher = ignorer l’étape)</span> :</div>
          <div className="grid grid-cols-2 gap-1">
            {([['intact', 'Swing NON violé', 'la séquence s\u2019arme si le swing le plus proche n\u2019a PAS été violé (aucune mèche/clôture au-delà depuis sa formation). Cliquer à nouveau pour DÉCOCHER (ignorer l’étape swing).'], ['violated', 'Swing VIOLÉ', 'la séquence s\u2019arme si le swing le plus proche a ÉTÉ violé (sweep de liquidité) avant le signal. Cliquer à nouveau pour DÉCOCHER (ignorer l’étape swing).']] as const).map(([mode, label, hint]) => (
              <button
                key={mode}
                type="button"
                disabled={disabled}
                aria-pressed={guard.swingMode === mode}
                onClick={() => applyGuard({ swingMode: guard.swingMode === mode ? 'none' : mode })}
                title={hint}
                className={'px-1.5 py-1 rounded border text-[8px] text-left ' + (guard.swingMode === mode
                  ? 'border-amber-500 bg-amber-500/10 text-amber-600 dark:text-amber-400'
                  : 'border-zinc-200 dark:border-zinc-800 text-zinc-500')}
              >{guard.swingMode === mode ? '✓ ' : '○ '}{label}</button>
            ))}
          </div>
          {guard.swingMode === 'none' && (
            <div className="rounded-md bg-amber-500/10 border border-amber-500/30 px-1.5 py-1 text-[8px] leading-snug text-amber-700 dark:text-amber-300">
              Swing <b>NON VÉRIFIÉ</b> : les deux cases sont décochées — l’étape de vérification du swing est <b>ignorée</b> : un CISD seul arme la séquence sans aucune exigence sur le swing (liberté totale v25).
            </div>
          )}
        </div>

        {/* Étape 3 — combinaisons de confirmation acceptées */}
        <div>
          <div className="text-[8px] text-zinc-500 mb-0.5">Étape 3 — signal suivant accepté (confirmations) :</div>
          <div className="grid grid-cols-2 gap-1">
            <button
              type="button"
              disabled={disabled}
              aria-pressed={guard.confirmBosUp}
              onClick={() => applyGuard({ confirmBosUp: !guard.confirmBosUp })}
              title="Coché : le signal suivant BOS Up + CISD Up confirme la séquence et place le CALL ▲. Décoché : ce combiné consomme la séquence sans ordre."
              className={'px-1.5 py-1 rounded border text-[8px] text-left ' + (guard.confirmBosUp
                ? 'border-emerald-500 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                : 'border-zinc-200 dark:border-zinc-800 text-zinc-500')}
            >{guard.confirmBosUp ? '✓ ' : '○ '}CALL ▲ · BOS Up + CISD Up</button>
            <button
              type="button"
              disabled={disabled}
              aria-pressed={guard.confirmChochUp}
              onClick={() => applyGuard({ confirmChochUp: !guard.confirmChochUp })}
              title="Coché : le signal suivant CHoCH Up + CISD Up confirme la séquence et place le CALL ▲. Décoché : ce combiné consomme la séquence sans ordre."
              className={'px-1.5 py-1 rounded border text-[8px] text-left ' + (guard.confirmChochUp
                ? 'border-emerald-500 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                : 'border-zinc-200 dark:border-zinc-800 text-zinc-500')}
            >{guard.confirmChochUp ? '✓ ' : '○ '}CALL ▲ · CHoCH Up + CISD Up</button>
            <button
              type="button"
              disabled={disabled}
              aria-pressed={guard.confirmBosDown}
              onClick={() => applyGuard({ confirmBosDown: !guard.confirmBosDown })}
              title="Coché : le signal suivant BOS Down + CISD Down confirme la séquence et place le PUT ▼. Décoché : ce combiné consomme la séquence sans ordre."
              className={'px-1.5 py-1 rounded border text-[8px] text-left ' + (guard.confirmBosDown
                ? 'border-red-500 bg-red-500/10 text-red-600 dark:text-red-400'
                : 'border-zinc-200 dark:border-zinc-800 text-zinc-500')}
            >{guard.confirmBosDown ? '✓ ' : '○ '}PUT ▼ · BOS Down + CISD Down</button>
            <button
              type="button"
              disabled={disabled}
              aria-pressed={guard.confirmChochDown}
              onClick={() => applyGuard({ confirmChochDown: !guard.confirmChochDown })}
              title="Coché : le signal suivant CHoCH Down + CISD Down confirme la séquence et place le PUT ▼. Décoché : ce combiné consomme la séquence sans ordre."
              className={'px-1.5 py-1 rounded border text-[8px] text-left ' + (guard.confirmChochDown
                ? 'border-red-500 bg-red-500/10 text-red-600 dark:text-red-400'
                : 'border-zinc-200 dark:border-zinc-800 text-zinc-500')}
            >{guard.confirmChochDown ? '✓ ' : '○ '}PUT ▼ · CHoCH Down + CISD Down</button>
          </div>
        </div>

        {/* Récapitulatif des 3 étapes (miroir de la configuration courante) */}
        <div className="rounded-md border border-zinc-200 dark:border-zinc-800 overflow-hidden">
          <div className="grid grid-cols-[64px_1fr_1fr] text-[8px] font-semibold bg-zinc-100 dark:bg-zinc-900/60 text-zinc-600 dark:text-zinc-300">
            <div className="px-1.5 py-0.5">Étape</div>
            <div className="px-1.5 py-0.5 text-emerald-600 dark:text-emerald-400">CISD UP</div>
            <div className="px-1.5 py-0.5 text-red-600 dark:text-red-400">CISD DOWN</div>
          </div>
          <div className="grid grid-cols-[64px_1fr_1fr] text-[8px] text-zinc-500 border-t border-zinc-200 dark:border-zinc-800">
            <div className="px-1.5 py-0.5 font-semibold text-zinc-600 dark:text-zinc-300">1. CISD seul</div>
            <div className="px-1.5 py-0.5">{guard.up ? (guard.swingMode === 'none' ? 'swing NON VÉRIFIÉ (étape ignorée)' : `swing high ${guard.swingMode === 'violated' ? 'VIOLÉ exigé' : 'non violé'}`) : 'désactivé — ordre direct'}</div>
            <div className="px-1.5 py-0.5">{guard.down ? (guard.swingMode === 'none' ? 'swing NON VÉRIFIÉ (étape ignorée)' : `swing low ${guard.swingMode === 'violated' ? 'VIOLÉ exigé' : 'non violé'}`) : 'désactivé — ordre direct'}</div>
          </div>
          <div className="grid grid-cols-[64px_1fr_1fr] text-[8px] text-zinc-500 border-t border-zinc-200 dark:border-zinc-800">
            <div className="px-1.5 py-0.5 font-semibold text-zinc-600 dark:text-zinc-300">2. Swing conforme</div>
            <div className="px-1.5 py-0.5">{guard.up ? 'séquence ARMÉE — aucun ordre, attente' : '—'}</div>
            <div className="px-1.5 py-0.5">{guard.down ? 'séquence ARMÉE — aucun ordre, attente' : '—'}</div>
          </div>
          <div className="grid grid-cols-[64px_1fr_1fr] text-[8px] text-zinc-500 border-t border-zinc-200 dark:border-zinc-800">
            <div className="px-1.5 py-0.5 font-semibold text-zinc-600 dark:text-zinc-300">3. Signal suivant</div>
            <div className="px-1.5 py-0.5">{guard.up ? `${[guard.confirmBosUp ? 'BOS Up + CISD Up' : null, guard.confirmChochUp ? 'CHoCH Up + CISD Up' : null].filter(Boolean).join(' ou ') || 'AUCUN combiné coché'} → CALL ▲` : '—'}</div>
            <div className="px-1.5 py-0.5">{guard.down ? `${[guard.confirmBosDown ? 'BOS Down + CISD Down' : null, guard.confirmChochDown ? 'CHoCH Down + CISD Down' : null].filter(Boolean).join(' ou ') || 'AUCUN combiné coché'} → PUT ▼` : '—'}</div>
          </div>
        </div>

        {/* Avertissements de configuration */}
        {!guard.up && (
          <div className="rounded-md bg-amber-500/10 border border-amber-500/30 px-1.5 py-1 text-[8px] leading-snug text-amber-700 dark:text-amber-300">
            CISD UP : vérification désactivée — les combinaisons CISD Up placent leurs ordres <b>directement</b> (retour au comportement v22, sans protection du swing).
          </div>
        )}
        {!guard.down && (
          <div className="rounded-md bg-amber-500/10 border border-amber-500/30 px-1.5 py-1 text-[8px] leading-snug text-amber-700 dark:text-amber-300">
            CISD DOWN : vérification désactivée — les combinaisons CISD Down placent leurs ordres <b>directement</b> (retour au comportement v22, sans protection du swing).
          </div>
        )}
        {guard.up && !guard.confirmBosUp && !guard.confirmChochUp && (
          <div className="rounded-md bg-amber-500/10 border border-amber-500/30 px-1.5 py-1 text-[8px] leading-snug text-amber-700 dark:text-amber-300">
            CALL ▲ : aucune combinaison de confirmation cochée — aucune séquence CISD Up ne pourra être confirmée (aucun ordre).
          </div>
        )}
        {guard.down && !guard.confirmBosDown && !guard.confirmChochDown && (
          <div className="rounded-md bg-amber-500/10 border border-amber-500/30 px-1.5 py-1 text-[8px] leading-snug text-amber-700 dark:text-amber-300">
            PUT ▼ : aucune combinaison de confirmation cochée — aucune séquence CISD Down ne pourra être confirmée (aucun ordre).
          </div>
        )}
        <div className="text-[8px] leading-snug text-zinc-500">
          Ces cases s'appliquent à <b>{strategyTitle}</b>, à l'autre stratégie ProTrader et au Strategy Tester (configuration partagée). Une direction cochée ne place <b>jamais</b> d'ordre sur un CISD seul.
        </div>
      </div>

      {/* ── v26 — « Tags & labels sur le graphique » : SWITCH MASTER (§22)
          + filtres de visibilité (groupes repliables, 73 patterns
          individuellement masquables, masters bullish/bearish/neutral,
          presets, taille des labels). DÉFAUT : OFF — aucun tag visuel.
          EXIGENCE §33 : masquer un signal n'affecte QUE le rendu — la
          détection et le Rule Engine continuent de l'utiliser. ── */}
      <SignalDisplayFields disabled={disabled} />

      {/* ── v19 — switch « Confirmation bougie précédente » : filtre les
          signaux avant lancement d'ordre. ON → un CALL ▲ n'est émis que si
          la bougie PRÉCÉDANT la bougie signalée est BAISSIÈRE (close <
          open) ; un PUT ▼ que si elle est HAUSSIÈRE (close > open). Une
          doji ne confirme rien. DÉFAUT : OFF (comportement inchangé). ── */}
      <div className="flex items-center justify-between rounded-lg border border-zinc-200 dark:border-zinc-800 px-2 py-1.5">
        <div className="pr-2">
          <div className="text-[9px] font-semibold text-zinc-700 dark:text-zinc-200">Confirmation bougie précédente</div>
          <div className="text-[8px] text-zinc-500 leading-snug">CALL ▲ uniquement si la bougie avant le signal est baissière · PUT ▼ uniquement si elle est haussière. Désactivé par défaut.</div>
        </div>
        <button
          type="button"
          role="switch"
          aria-checked={confirmCandle}
          aria-label="Exiger une bougie de confirmation avant le signal (baissière pour CALL, haussière pour PUT)"
          disabled={disabled}
          onClick={() => onConfirmCandleChange(!confirmCandle)}
          title={confirmCandle ? 'Confirmation ACTIVE — cliquer pour désactiver' : 'Confirmation inactive — cliquer pour activer'}
          className="relative shrink-0 w-12 h-6 rounded-full transition-colors disabled:opacity-50"
          style={{ background: confirmCandle ? '#089981' : '#71717a' }}
        >
          <span
            className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all flex items-center justify-center"
            style={{ left: confirmCandle ? '26px' : '2px' }}
          >
            {confirmCandle
              ? <ShieldCheck className="h-2.5 w-2.5" style={{ color: '#089981' }} />
              : <ShieldCheck className="h-2.5 w-2.5 text-zinc-400" />}
          </span>
        </button>
      </div>

      {/* ── groupe « Labels » (visuels du graphique) ── */}
      <div className="text-[9px] font-semibold text-zinc-500 dark:text-zinc-400">Labels</div>
      <div className="grid grid-cols-2 gap-1.5">
        {BCC_LABEL_COLOURS.map((row) => (
          <div key={row.key} className="flex items-center gap-1.5">
            <input
              type="color"
              value={String(settings[row.key])}
              disabled={disabled}
              onChange={(e) => setColour(row.key, e.target.value)}
              className="h-5 w-6 shrink-0 cursor-pointer rounded border border-zinc-300 bg-transparent p-0 dark:border-zinc-700"
              title={row.label}
            />
            <label className="text-[8px] leading-tight text-zinc-600 dark:text-zinc-300 truncate" title={row.label}>{row.label}</label>
          </div>
        ))}
      </div>
      <div>
        <label className="block text-[9px] text-zinc-500 mb-1">Label Size</label>
        <div className="grid grid-cols-6 gap-1">
          {BCC_SIZES.map((s) => (
            <button key={s} type="button" disabled={disabled} onClick={() => saveBosChochCisdSettings({ labelSize: s })}
              className={'px-1 py-1 rounded-lg text-[8px] font-medium border ' + (settings.labelSize === s
                ? 'border-emerald-500 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
                : 'border-zinc-200 dark:border-zinc-800')}
              title={`Label Size = ${s}`}
            >{s}</button>
          ))}
        </div>
      </div>

      {/* ── placement d'ordres : règles libres CALL / PUT (§9/§10) —
          conditions MIXTES : alertes pack + 73 patterns candle, en
          logique AND. v26 : RÈGLES PROPRES À LA STRATÉGIE ACTIVE (§31). ── */}
      <div className="text-[9px] font-semibold text-zinc-500 dark:text-zinc-400">Placement des ordres — règles {strategyTitle}</div>
      <div className="rounded-md bg-blue-500/5 border border-blue-500/20 p-1.5 text-[8px] leading-snug text-zinc-500">
        Cochez <b>une ou plusieurs alertes</b> et/ou ajoutez des <b>conditions candlestick</b> (73 patterns) par règle — logique <b>AND</b> : toutes les conditions doivent être présentes sur la même bougie. Chaque règle a sa <b>propre expiration</b> (secondes, bougies ou remaining Time Before Candle Closure). Les règles plus spécifiques (plus de conditions) passent avant. {isNinja ? 'Ces règles sont PROPRES à Ninja ProTrader.' : 'Ces règles sont propres à L_Lucien ProTrader.'}
      </div>
      <div className="space-y-2">
        <div>
          <div className="flex items-center justify-between mb-1"><div className="text-[9px] font-semibold text-emerald-600">CALL ▲</div><div className="text-[8px] text-zinc-500">{activeCallRules.length} règle(s)</div></div>
          <BccRuleEditor side="CALL" rules={activeCallRules} disabled={disabled} onChange={(callRules) => setActiveRules(callRules, activePutRules)} />
        </div>
        <div>
          <div className="flex items-center justify-between mb-1"><div className="text-[9px] font-semibold text-red-600">PUT ▼</div><div className="text-[8px] text-zinc-500">{activePutRules.length} règle(s)</div></div>
          <BccRuleEditor side="PUT" rules={activePutRules} disabled={disabled} onChange={(putRules) => setActiveRules(activeCallRules, putRules)} />
        </div>
      </div>

      <div className="flex items-center justify-between">
        <div className="rounded-md bg-zinc-50 dark:bg-zinc-900/60 p-1.5 text-[8px] leading-snug text-zinc-500">
          {isNinja
            ? 'Copie conforme de L_Lucien ProTrader : mêmes combinaisons, mêmes validations — détection AVANT la clôture (ordre immédiat sur la bougie en formation).'
            : 'Indicateur du pack converti en stratégie : Up → CALL · Down → PUT sur bougies clôturées. Visuels + réglages identiques au pack.'}
        </div>
        <button
          type="button" disabled={disabled}
          onClick={() => { resetBosChochCisdSettings(); onConfigChange({ bosChochCisdReset: true }) }}
          className="shrink-0 ml-2 rounded-lg border border-zinc-200 dark:border-zinc-800 px-2 py-1 text-[8px] font-medium text-zinc-500 hover:border-emerald-400 hover:text-emerald-600"
          title="Restaurer les réglages du pack"
        >Reset pack</button>
      </div>
    </div>
  )
}

interface AutoTradePanelProps {
  asset: string
  status: AutoTradeStatus | null
  disabled?: boolean
  onToggle: (enabled: boolean) => void
  onStrategyChange: (strategyId: string) => void
  onConfigChange: (cfg: {
    bettingStrategy?: 'fixed' | 'martingale' | 'fibonacci'
    baseAmount?: number
    bosChochCisdBosUp?: boolean
    bosChochCisdBosDown?: boolean
    bosChochCisdChochUp?: boolean
    bosChochCisdChochDown?: boolean
    bosChochCisdCisdUp?: boolean
    bosChochCisdCisdDown?: boolean
    bosChochCisdCallRules?: BosChochCisdOrderRule[]
    bosChochCisdPutRules?: BosChochCisdOrderRule[]
    bosChochCisdReset?: boolean
    /** v19 — switch « Confirmation bougie précédente » (L_Lucien ProTrader). */
    bosChochCisdConfirmCandle?: boolean
    /** v19 — garde-fou Martingale : nombre max de doublements (0 = illimité). */
    maxMartingaleSteps?: number
    /** v26 — règles PROPRES à Ninja ProTrader (clés ninja* du backend). */
    ninjaBosChochCisdCallRules?: BosChochCisdOrderRule[]
    ninjaBosChochCisdPutRules?: BosChochCisdOrderRule[]
    /** v24/v25 — étapes de vérification CISD optionnelles (cases à cocher). */
    cisdGuardUp?: boolean
    cisdGuardDown?: boolean
    cisdGuardSwingMode?: 'intact' | 'violated' | 'none'
    cisdGuardConfirmBosUp?: boolean
    cisdGuardConfirmChochUp?: boolean
    cisdGuardConfirmBosDown?: boolean
    cisdGuardConfirmChochDown?: boolean
  }) => void
}

const BETTING_MODES: Array<{ id: 'fixed' | 'martingale' | 'fibonacci'; label: string; hint: string }> = [
  { id: 'fixed', label: 'Fixed', hint: 'Mise constante' },
  { id: 'martingale', label: 'Martingale', hint: 'Perte → ×2 · Victoire → mise initiale' },
  { id: 'fibonacci', label: 'Fibonacci', hint: '1,1,2,3,5,8…' },
]

/** Id de la stratégie unique conservée : L_Lucien ProTrader. */
export const LUCIEN_PROTRADER_STRATEGY_ID = 'l_lucien_protrader'

/** v22 — Ninja ProTrader : copie conforme de L_Lucien ProTrader, détection AVANT clôture. */
export const NINJA_PROTRADER_STRATEGY_ID = 'ninja_protrader'

export function AutoTradePanel({
  asset, status, disabled, onToggle, onStrategyChange, onConfigChange,
}: AutoTradePanelProps) {
  const [baseAmount, setBaseAmount] = useState('1')
  const [maxMartingaleSteps, setMaxMartingaleSteps] = useState('0')

  const enabled = status?.enabled ?? false
  const strategies = status?.strategies ?? []
  const strategyId = status?.strategyId ?? LUCIEN_PROTRADER_STRATEGY_ID
  const betting = status?.bettingStrategy ?? 'fixed'
  const stats = status?.stats
  const norm = status?.tickNormalizer
  const sig = status?.lastStrategyState ?? null
  const winRate = stats?.winRate != null ? Math.round(stats.winRate * 100) : null
  // v19 — switch « Confirmation bougie précédente » (backend, défaut OFF).
  const confirmCandle = status?.bosChochCisdConfirmCandle ?? false
  // v19 — garde-fou Martingale (0 = illimité) synchronisé depuis le backend.
  const capSteps = status?.maxMartingaleSteps ?? 0

  // Synchronise les inputs locaux avec l'état backend.
  // Pattern React « adjust state during render » (pas d'effet) :
  // on ne réinitialise l'input QUE si la valeur backend change.
  const [seenBase, setSeenBase] = useState<number | null>(null)
  if (status?.baseAmount != null && status.baseAmount !== seenBase) {
    setSeenBase(status.baseAmount)
    setBaseAmount(String(status.baseAmount))
  }
  const [seenCap, setSeenCap] = useState<number | null>(null)
  if (status?.maxMartingaleSteps != null && status.maxMartingaleSteps !== seenCap) {
    setSeenCap(status.maxMartingaleSteps)
    setMaxMartingaleSteps(String(status.maxMartingaleSteps))
  }

  const commitBaseAmount = () => {
    const v = parseFloat(baseAmount)
    if (Number.isFinite(v) && v >= 1) onConfigChange({ baseAmount: v })
  }

  const commitMaxMartingaleSteps = () => {
    const raw = maxMartingaleSteps.trim()
    if (raw === '') { onConfigChange({ maxMartingaleSteps: 0 }); return }
    const v = parseInt(raw, 10)
    if (Number.isFinite(v) && v >= 0) onConfigChange({ maxMartingaleSteps: Math.min(1000, v) })
  }

  return (
    <div className="flex flex-col gap-2.5 p-3">
      {/* ── Header + toggle ─────────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5">
          <Bot className="h-4 w-4" style={{ color: enabled ? '#2962FF' : undefined }} />
          <div className="text-sm font-semibold">Auto Trade</div>
          {enabled && (
            <span className="inline-flex items-center gap-1 text-[9px] font-bold px-1.5 py-0.5 rounded-full text-white animate-pulse" style={{ background: '#2962FF' }}>
              <Activity className="h-2.5 w-2.5" /> LIVE
            </span>
          )}
        </div>
        {/* Toggle ON/OFF */}
        <button
          onClick={() => !disabled && onToggle(!enabled)}
          disabled={disabled}
          className="relative w-12 h-6 rounded-full transition-colors disabled:opacity-50"
          style={{ background: enabled ? '#089981' : '#71717a' }}
          aria-label={enabled ? 'Disable auto-trade' : 'Enable auto-trade'}
        >
          <span
            className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all flex items-center justify-center"
            style={{ left: enabled ? '26px' : '2px' }}
          >
            {enabled
              ? <Play className="h-2.5 w-2.5" style={{ color: '#089981' }} />
              : <Square className="h-2.5 w-2.5 text-zinc-500" />}
          </span>
        </button>
      </div>
      {!enabled && (
        <div className="rounded-lg border border-amber-300/60 bg-amber-50 dark:bg-amber-500/5 px-2 py-1.5 text-[9px] text-amber-800 dark:text-amber-300">
          Auto Trade is <b>disabled</b> by default. No automatic order will be placed until you enable this switch.
        </div>
      )}

      {/* ── Strategy ───────────────────────────────────────────── */}
      <div>
        <label className="block text-[10px] text-zinc-500 dark:text-zinc-400 mb-1">Strategy</label>
        <select
          value={strategyId}
          onChange={(e) => onStrategyChange(e.target.value)}
          disabled={disabled}
          className="w-full px-2.5 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 outline-none focus:ring-2 focus:ring-blue-500 text-sm disabled:opacity-50 [&>option]:text-zinc-900 dark:[&>option]:bg-zinc-900 dark:[&>option]:text-zinc-100"
        >
          {strategies.length === 0 && (
            <option value={LUCIEN_PROTRADER_STRATEGY_ID}>L_Lucien ProTrader</option>
          )}
          {strategies.map((s) => (
            <option key={s.id} value={s.id}>{s.name}</option>
          ))}
        </select>
        {strategies.find((s) => s.id === strategyId)?.description && (
          <div className="text-[9px] text-zinc-500 dark:text-zinc-400 mt-1 leading-snug">
            {strategies.find((s) => s.id === strategyId)!.description}
          </div>
        )}
      </div>

      {/* ── Réglages L_Lucien ProTrader / Ninja ProTrader ─────── */}
      <LucienProTraderFields
        disabled={disabled}
        onConfigChange={onConfigChange}
        confirmCandle={confirmCandle}
        onConfirmCandleChange={(v) => onConfigChange({ bosChochCisdConfirmCandle: v })}
        strategyId={strategyId}
      />

      {/* ── Stake strategy ───────────────────────────────────── */}
      <div>
        <label className="block text-[10px] text-zinc-500 dark:text-zinc-400 mb-1">Stake strategy</label>
        <div className="grid grid-cols-3 gap-1.5">
          {BETTING_MODES.map((m) => (
            <button
              key={m.id}
              onClick={() => onConfigChange({ bettingStrategy: m.id })}
              disabled={disabled}
              title={m.hint}
              className={'px-2 py-1.5 rounded-lg text-[11px] font-medium border transition-all disabled:opacity-50 ' +
                (betting === m.id
                  ? 'border-blue-500 bg-blue-500/10 text-blue-600 dark:text-blue-400'
                  : 'border-zinc-200 dark:border-zinc-800 hover:border-zinc-400 dark:hover:border-zinc-600')}
            >
              {m.label}
            </button>
          ))}
        </div>
      </div>

      {/* ── Base amount ──────────────────────────────────────── */}
      {/* L_Lucien ProTrader : le champ « Expiration » global d'Auto Trade
          est CACHÉ — chaque règle CALL/PUT porte sa propre expiration
          (définie explicitement par l'utilisateur) et le champ global ne
          doit JAMAIS contrôler un ordre de la stratégie. */}
      <div className="grid grid-cols-1 gap-2">
        <div>
          <label className="block text-[10px] text-zinc-500 dark:text-zinc-400 mb-1">base stake ($)</label>
          <input
            type="number"
            min="1"
            step="1"
            value={baseAmount}
            disabled={disabled}
            onChange={(e) => setBaseAmount(e.target.value)}
            onBlur={commitBaseAmount}
            onKeyDown={(e) => e.key === 'Enter' && commitBaseAmount()}
            title="Mise de base — point de départ de la suite de mises (Fixed / Martingale / Fibonacci)"
            className="w-full px-2.5 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 placeholder:text-zinc-400 dark:placeholder:text-zinc-500 outline-none focus:ring-2 focus:ring-blue-500 text-sm font-mono disabled:opacity-50"
          />
        </div>
        {/* ── v20 — Garde-fou Martingale : nombre MAXIMAL de mises dans la
            séquence. Visible uniquement en mode Martingale (la règle ne
            concerne que cette mise). 0 = illimité. Ex. 4 avec base 10 :
            10→20→40→80 (4 mises), puis si le 80 perd → RETOUR à 10 (au
            lieu de 160). La « 5e mise » n'existe plus. ── */}
        {betting === 'martingale' && (
          <div>
            <label className="block text-[10px] text-zinc-500 dark:text-zinc-400 mb-1">
              Martingale max — doublements
            </label>
            <input
              type="number"
              min="0"
              max="1000"
              step="1"
              value={maxMartingaleSteps}
              disabled={disabled}
              onChange={(e) => setMaxMartingaleSteps(e.target.value)}
              onBlur={commitMaxMartingaleSteps}
              onKeyDown={(e) => e.key === 'Enter' && commitMaxMartingaleSteps()}
              title="Nombre maximal de mises dans la séquence Martingale (0 = illimité). Après l'échec de la N-ième mise, retour à la mise initiale."
              className="w-full px-2.5 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 placeholder:text-zinc-400 dark:placeholder:text-zinc-500 outline-none focus:ring-2 focus:ring-blue-500 text-sm font-mono disabled:opacity-50"
            />
            <div className="text-[8px] text-zinc-500 dark:text-zinc-400 leading-snug mt-1">
              {capSteps > 0
                ? `Séquence de ${capSteps} mise(s) max : ` +
                  `${Array.from({ length: Math.min(capSteps, 6) }, (_, i) =>
                    Number(status?.baseAmount ?? 1) * Math.pow(2, i)).join(' → ')}` +
                  `${capSteps > 6 ? ' → …' : ''} — puis retour à ${status?.baseAmount ?? '—'} $ si la ${capSteps}e mise perd.`
                : '0 = illimité — la mise double à chaque perte jusqu’à un gain.'}
            </div>
          </div>
        )}
      </div>

      {/* ── Next stake + stats ──────────────────────────────── */}
      <div className="grid grid-cols-4 gap-1.5 text-center">
        <div className="rounded-lg bg-zinc-100 dark:bg-zinc-800/60 px-1.5 py-1.5">
          <div className="text-[9px] text-zinc-500 dark:text-zinc-400">Prochaine stake</div>
          <div className="text-xs font-bold font-mono" style={{ color: '#2962FF' }}>
            ${status?.nextBetAmount ?? '—'}
          </div>
        </div>
        <div className="rounded-lg bg-zinc-100 dark:bg-zinc-800/60 px-1.5 py-1.5">
          <div className="text-[9px] text-zinc-500 dark:text-zinc-400">signals</div>
          <div className="text-xs font-bold font-mono">{stats?.signals ?? 0}</div>
        </div>
        <div className="rounded-lg bg-zinc-100 dark:bg-zinc-800/60 px-1.5 py-1.5">
          <div className="text-[9px] text-zinc-500 dark:text-zinc-400">Trades</div>
          <div className="text-xs font-bold font-mono">{stats?.trades ?? 0}</div>
        </div>
        <div className="rounded-lg bg-zinc-100 dark:bg-zinc-800/60 px-1.5 py-1.5">
          <div className="text-[9px] text-zinc-500 dark:text-zinc-400">W / L</div>
          <div className="text-xs font-bold font-mono">
            <span style={{ color: '#089981' }}>{stats?.wins ?? 0}</span>
            <span className="text-zinc-400"> / </span>
            <span style={{ color: '#F23645' }}>{stats?.losses ?? 0}</span>
          </div>
        </div>
      </div>

      {/* Win rate + statut mise */}
      <div className="flex items-center justify-between text-[10px] text-zinc-500 dark:text-zinc-400 px-0.5">
        <span>
          Win rate&nbsp;
          <span className="font-mono font-semibold" style={{ color: winRate == null ? undefined : winRate >= 50 ? '#089981' : '#F23645' }}>
            {winRate == null ? '—' : `${winRate}%`}
          </span>
        </span>
        {betting !== 'fixed' && (
          <span className="inline-flex items-center gap-1">
            <Target className="h-3 w-3" />
            {betting === 'martingale'
              ? `${stats?.consecutiveLosses ?? 0} consecutive loss(es)${capSteps > 0 ? ` · max ${capSteps}` : ''}`
              : `fib étape ${stats?.fibIndex ?? 0}`}
          </span>
        )}
      </div>

      {/* ── Dernier signal L_Lucien ProTrader ───────────────────── */}
      {sig && (
        <div className="rounded-lg border border-zinc-200 dark:border-zinc-800 p-2 flex flex-col gap-1">
          <div className="flex items-center justify-between">
            <div className="text-[10px] font-semibold text-zinc-600 dark:text-zinc-300 flex items-center gap-1">
              <ShieldCheck className="h-3 w-3" style={{ color: '#2962FF' }} />
              Latest signal
            </div>
            <div className="flex items-center gap-1 text-[10px] font-bold"
              style={{ color: sig.action === 'buy' ? '#089981' : sig.action === 'sell' ? '#F23645' : '#71717a' }}>
              {sig.action === 'buy'
                ? <TrendingUp className="h-3 w-3" />
                : sig.action === 'sell'
                  ? <TrendingDown className="h-3 w-3" />
                  : null}
              {sig.action === 'buy' ? 'CALL ▲' : sig.action === 'sell' ? 'PUT ▼' : 'HOLD —'}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-x-2 gap-y-0.5 text-[9px] text-zinc-500 dark:text-zinc-400 font-mono">
            <span>conf: <span className="text-zinc-700 dark:text-zinc-200">{Math.round((sig.confidence ?? 0) * 100)}%</span></span>
            <span>asset: <span className="text-zinc-700 dark:text-zinc-200 truncate">{sig.asset ?? asset}</span></span>
            {sig.matchedRuleId && (
              <span className="col-span-2 truncate">règle: <span className="text-zinc-700 dark:text-zinc-200">{sig.matchedRuleId}</span></span>
            )}
            {sig.events?.length ? (
              <span className="col-span-2 truncate">événements: <span className="text-zinc-700 dark:text-zinc-200">{sig.events.join(' + ')}</span></span>
            ) : null}
          </div>
          {sig.reason && (
            <div className="text-[9px] text-zinc-500 dark:text-zinc-400 leading-snug line-clamp-2" title={englishizeText(sig.reason, 'Strategy evaluation.')}>
              {englishizeText(sig.reason, 'Strategy evaluation.')}
            </div>
          )}
        </div>
      )}

      {/* ── Santé anti-duplication ───────────────────────────────── */}
      {norm && norm.received > 0 && (
        <div className="flex items-center justify-between text-[9px] text-zinc-500 dark:text-zinc-400 px-0.5">
          <span className="inline-flex items-center gap-1">
            <ShieldCheck className="h-3 w-3 text-emerald-500" />
            Anti-duplication: {norm.received} flux → {norm.emitted} ticks
          </span>
          {norm.droppedStale > 0 && <span>{norm.droppedStale} replayed items dropped</span>}
        </div>
      )}

      <div className="text-[9px] text-zinc-400 dark:text-zinc-500 leading-snug px-0.5">
        {englishizeText(enabled
          ? strategyId === 'ninja_protrader'
            ? `Ninja ProTrader : exécution automatique sur ${asset} AVANT la clôture de chaque bougie (BOS/CHoCH/CISD détectés sur la bougie en formation, prix temps réel). Chaque règle CALL/PUT porte sa propre expiration et sa Candles Validation (bougies clôturées, de la plus récente à la plus ancienne). Mise ${betting} (${status?.nextBetAmount ?? '—'} $).`
            : `L_Lucien ProTrader : exécution automatique sur ${asset} à chaque clôture de bougie (BOS/CHoCH/CISD, bougies confirmées uniquement). Chaque règle CALL/PUT porte sa propre expiration et sa Candles Validation (bougies clôturées, de la plus récente à la plus ancienne). Mise ${betting} (${status?.nextBetAmount ?? '—'} $).`
          : 'Enable automatic execution for signals. L_Lucien ProTrader analyzes each closed candle ; Ninja ProTrader detects signals before the candle closes. Each CALL/PUT rule carries its own expiration and Candles Validation.', 'Automatic trading is enabled.')}
      </div>
    </div>
  )
}
