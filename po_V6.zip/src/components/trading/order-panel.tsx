'use client'

import { useState } from 'react'
import { TrendingUp, TrendingDown, Loader2, AlertCircle, CheckCircle2, FlaskConical } from 'lucide-react'
import type { OrderResult } from '@/hooks/use-pocket-option'
import type { SmartTraderForecast } from '@/components/trading/chart/drawing-layer'

interface OrderPanelProps {
  asset: string
  currentPrice: number
  payout: number | null
  disabled?: boolean
  onPlaceOrder: (opts: { action: 'call' | 'put'; amount: number; time: number }) => void
  smartForecast?: SmartTraderForecast | null
  orderResult: OrderResult | null
  /** Replay backtest mode: orders are simulated, not sent to Pocket Option. */
  simMode?: boolean
  /** Candle period in seconds — converts expiry to bar count in sim mode. */
  candleSize?: number
}

export function OrderPanel({
  asset, currentPrice, payout, disabled, onPlaceOrder, orderResult,
  simMode = false, candleSize = 30, smartForecast = null,
}: OrderPanelProps) {
  const [amount, setAmount] = useState('1')
  const [expiryInput, setExpiryInput] = useState('60s')
  const [pending, setPending] = useState<'call' | 'put' | null>(null)

  const recent = orderResult && Date.now() - orderResult.ts < 8000 ? orderResult : null
  const numericAmount = parseFloat(amount) || 0
  const potentialProfit = numericAmount > 0 && payout != null
    ? numericAmount * (payout / 100)
    : null

  const parseExpiry = (raw: string): number | null => {
    const text = raw.trim().toLowerCase().replace(/\s+/g, '')
    if (!text) return null

    // Supported examples: 3s, 38s, 4m, 4m12, 4m12s, 1h2m3s.
    const compact = text.match(/^(?:(\d+(?:\.\d+)?)h)?(?:(\d+(?:\.\d+)?)m)?(?:(\d+(?:\.\d+)?)(?:s)?)?$/)
    if (compact && (compact[1] || compact[2] || compact[3])) {
      const h = compact[1] ? Number(compact[1]) : 0
      const min = compact[2] ? Number(compact[2]) : 0
      const sec = compact[3] ? Number(compact[3]) : 0
      const total = h * 3600 + min * 60 + sec
      return Number.isFinite(total) && total > 0 ? Math.round(total) : null
    }

    // Explicitly support the requested shorthand "4m12" (minutes + seconds).
    const minSec = text.match(/^(\d+(?:\.\d+)?)m(\d+(?:\.\d+)?)$/)
    if (minSec) {
      const total = Number(minSec[1]) * 60 + Number(minSec[2])
      return Number.isFinite(total) && total > 0 ? Math.round(total) : null
    }

    const plain = Number(text)
    return Number.isFinite(plain) && plain > 0 ? Math.round(plain) : null
  }

  const fmtExpiryInput = (seconds: number): string => {
    const s = Math.max(1, Math.round(seconds))
    const h = Math.floor(s / 3600)
    const m = Math.floor((s % 3600) / 60)
    const sec = s % 60
    if (h > 0) return sec ? `${h}h${m}m${sec}s` : (m ? `${h}h${m}m` : `${h}h`)
    if (m > 0) return sec ? `${m}m${sec}s` : `${m}m`
    return `${sec}s`
  }

  const parsedExpiry = parseExpiry(expiryInput)
  const effectiveExpiry = parsedExpiry != null ? Math.max(3, Math.min(86400, parsedExpiry)) : 0
  const expiryBars = Math.max(1, Math.round(effectiveExpiry / candleSize))

  const submit = (action: 'call' | 'put', forcedExpiry?: number) => {
    if (disabled || numericAmount <= 0) return
    const time = Math.max(3, Math.min(86400, Math.round(forcedExpiry ?? effectiveExpiry)))
    if (!Number.isFinite(time) || time <= 0) return
    if (forcedExpiry != null) setExpiryInput(fmtExpiryInput(time))
    if (simMode) {
      onPlaceOrder({ action, amount: numericAmount, time })
      return
    }
    if (pending) return
    setPending(action)
    onPlaceOrder({ action, amount: numericAmount, time })
    setTimeout(() => setPending(null), 15000)
  }

  const forecastAction = smartForecast?.direction === 'up' ? 'call' : smartForecast?.direction === 'down' ? 'put' : null
  const forecastExpiry = smartForecast?.onsetSeconds != null ? Math.max(3, Math.round(smartForecast.onsetSeconds)) : null
  const forecastReady = !!forecastAction && !!forecastExpiry && numericAmount > 0 && !disabled && (!pending || simMode)

  return (
    <div className="flex flex-col gap-2.5 p-3">
      <div className="flex items-center justify-between">
        <div className="text-sm font-semibold">Binary Trade</div>
        {simMode ? (
          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-1.5 py-0.5 rounded text-white" style={{ background: '#FF6D00' }}>
            <FlaskConical className="h-3 w-3" /> SIM {expiryBars} bars
          </span>
        ) : (
          <div className="text-[11px] text-zinc-500 dark:text-zinc-400">{asset}</div>
        )}
      </div>

      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="block text-[10px] text-zinc-500 dark:text-zinc-400 mb-1">Amount ($)</label>
          <input
            type="number"
            min="1"
            step="1"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="w-full px-2.5 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 outline-none focus:ring-2 focus:ring-blue-500 text-sm font-mono"
          />
        </div>
        <div>
          <label className="block text-[10px] text-zinc-500 dark:text-zinc-400 mb-1">Expiration</label>
          <input
            type="text"
            inputMode="text"
            value={expiryInput}
            onChange={(e) => setExpiryInput(e.target.value)}
            placeholder="ex. 38s · 4m · 4m12"
            aria-invalid={expiryInput.trim() !== '' && parsedExpiry == null}
            className="w-full px-2.5 py-1.5 rounded-lg border border-zinc-200 dark:border-zinc-800 bg-white dark:bg-zinc-900 text-zinc-900 dark:text-zinc-100 outline-none focus:ring-2 focus:ring-blue-500 text-sm font-mono"
          />
        </div>
      </div>

      {potentialProfit != null && (
        <div className="text-[11px] text-zinc-500 dark:text-zinc-400 flex justify-between px-0.5">
          <span>Payout {payout ?? 92}%</span>
          <span style={{ color: '#089981' }} className="font-medium">Win: +${potentialProfit.toFixed(2)}</span>
        </div>
      )}

      <button
        type="button"
        onClick={() => forecastExpiry != null && forecastAction && submit(forecastAction, forecastExpiry)}
        disabled={!forecastReady}
        className="w-full rounded-xl py-2 px-2.5 border text-[11px] font-semibold flex items-center justify-between gap-2 transition-all disabled:opacity-40"
        style={{ borderColor: smartForecast?.direction === 'up' ? '#08998166' : smartForecast?.direction === 'down' ? '#F2364566' : 'rgba(120,123,134,.35)', background: smartForecast?.direction === 'up' ? 'rgba(8,153,129,.08)' : smartForecast?.direction === 'down' ? 'rgba(242,54,69,.08)' : 'transparent' }}
        title="Capture the Fibonacci forecast and place the corresponding CALL/PUT with its estimated time"
      >
        <span>CAPTURE FORECAST</span>
        <span className="font-mono">{forecastAction ? forecastAction.toUpperCase() : '—'}{forecastExpiry ? ` · ${fmtExpiryInput(forecastExpiry)}` : ''}</span>
      </button>

      <div className="grid grid-cols-2 gap-2">
        <button
          onClick={() => submit('call')}
          disabled={disabled || (!simMode && pending != null) || numericAmount <= 0}
          className="rounded-xl py-2.5 hover:brightness-110 disabled:opacity-50 text-white font-semibold text-sm flex items-center justify-center gap-1.5 transition-all"
          style={{ background: '#089981' }}
        >
          {pending === 'call' && !simMode ? <Loader2 className="h-4 w-4 animate-spin" /> : <TrendingUp className="h-4 w-4" />}
          CALL
          <span className="text-[10px] font-normal opacity-80">up</span>
        </button>
        <button
          onClick={() => submit('put')}
          disabled={disabled || (!simMode && pending != null) || numericAmount <= 0}
          className="rounded-xl py-2.5 hover:brightness-110 disabled:opacity-50 text-white font-semibold text-sm flex items-center justify-center gap-1.5 transition-all"
          style={{ background: '#F23645' }}
        >
          {pending === 'put' && !simMode ? <Loader2 className="h-4 w-4 animate-spin" /> : <TrendingDown className="h-4 w-4" />}
          PUT
          <span className="text-[10px] font-normal opacity-80">down</span>
        </button>
      </div>

      <div className="text-[11px] text-zinc-500 dark:text-zinc-400 flex justify-between">
        <span>{simMode ? 'Entry (replay close)' : 'Strike price'}</span>
        <span className="font-mono">{currentPrice > 0 ? currentPrice.toFixed(currentPrice > 1000 ? 1 : 5) : '—'}</span>
      </div>

      {expiryInput.trim() !== '' && parsedExpiry == null && (
        <div className="text-[10px] text-rose-500">Format invalide. Utilisez par exemple 3s, 38s, 4m ou 4m12.</div>
      )}

      {simMode && (
        <div className="text-[10px] px-2 py-1.5 rounded-lg" style={{ background: 'rgba(255,109,0,0.1)', color: '#FF6D00' }}>
          Simulated order — settles when the replay reaches expiry. Results in the Strategy Tester panel.
        </div>
      )}

      {!simMode && recent && (
        <div className={
          'flex items-start gap-2 p-2 rounded-lg text-xs ' +
          (recent.success
            ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400'
            : 'bg-rose-500/10 text-rose-600 dark:text-rose-400')
        }>
          {recent.success ? <CheckCircle2 className="h-3.5 w-3.5 flex-shrink-0 mt-px" /> : <AlertCircle className="h-3.5 w-3.5 flex-shrink-0 mt-px" />}
          <span className="break-all">
            {recent.success
              ? `Order placed — deal #${recent.deal?.id ?? '?'} @ ${recent.deal?.openPrice ?? '—'}`
              : recent.error ?? 'Order failed'}
          </span>
        </div>
      )}
    </div>
  )
}
