'use client'

import { Wallet, Server, User, Activity } from 'lucide-react'
import type { StatusPayload } from '@/hooks/use-pocket-option'

interface AccountPanelProps {
  status: StatusPayload | null
  balanceLabel: string
}

export function AccountPanel({ status, balanceLabel }: AccountPanelProps) {
  const market = status?.market
  const ticks = status?.liveTicksForMarket ?? 0

  return (
    <div className="rounded-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden">
      <div className="px-3 py-2 text-xs font-medium text-zinc-500 dark:text-zinc-400 border-b border-zinc-200 dark:border-zinc-800">
        Account
      </div>
      <div className="p-3 space-y-2.5 text-sm">
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-zinc-500 dark:text-zinc-400">
            <Wallet className="h-4 w-4" /> Balance
          </span>
          <span className="font-semibold font-mono">{balanceLabel}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-zinc-500 dark:text-zinc-400">
            <User className="h-4 w-4" /> User
          </span>
          <span className="font-mono text-xs">
            #{status?.userId ?? '—'} · {status?.mode === 'real' ? 'REAL' : 'DEMO'}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-zinc-500 dark:text-zinc-400">
            <Server className="h-4 w-4" /> Server
          </span>
          <span className="font-mono text-xs">{status?.server ?? '—'}</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="flex items-center gap-2 text-zinc-500 dark:text-zinc-400">
            <Activity className="h-4 w-4" /> Live ticks
          </span>
          <span className={'font-mono text-xs ' + (status?.liveActive ? 'text-emerald-500' : 'text-zinc-500')}>
            {ticks.toLocaleString()}
          </span>
        </div>
        {market && (
          <div className="pt-2 border-t border-zinc-200 dark:border-zinc-800 text-xs">
            <div className="text-zinc-500 dark:text-zinc-400 mb-1">Active market</div>
            <div className="font-medium">{market.long_name}</div>
            <div className="text-zinc-500 dark:text-zinc-400 font-mono">
              {market.name} · {market.trading_hours}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
