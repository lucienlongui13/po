/**
 * usePocketOption — React hook that owns the socket.io connection to the
 * pocketoption-backend mini-service (port 3030) and exposes live state.
 *
 * MULTI-ASSETS (v6 — contextes indépendants par asset, max 10) :
 *  - login / logout (Pocket Option credentials, demo | real)
 *  - sélection d'un actif unique depuis la watchlist
 *    (validation backend : 1 ≤ assets ≤ 10, doublons supprimés — §3)
 *  - switch-asset / add-asset / remove-asset / set-focus (gestion live §26/§30)
 *  - UN LiveEngine PAR ASSET (Map<string, LiveEngine> — §22) :
 *    un tick EURUSD n'oblige jamais BTCUSD/XAUUSD/GBPUSD à se re-render (§38)
 *  - candle / candles-history / trade-* / auto-trade-status :
 *    chaque payload est routé par son champ `asset` (§21)
 *  - AssetStore (src/lib/asset-store.ts) : snapshots par asset, abonnements
 *    isolés (useSyncExternalStore)
 *  - balance / open positions (1 Hz `status` broadcast — champ `assets[]`)
 *  - CALL/PUT binary orders → order-placed / order-error (asset optionnel)
 *  - closed deals → deal-closed / trade-closed
 */

'use client'

import { useEffect, useRef, useState, useCallback, useMemo } from 'react'
import { io, Socket } from 'socket.io-client'
import { LiveEngine } from '@/lib/live-engine'
import type { RawCandleEvent } from '@/lib/live-engine'
import type { CandleLike } from '@/lib/indicators'
import { AssetStore, type AssetData } from '@/lib/asset-store'
import type { BosChochCisdOrderRule } from '../../shared/bos-choch-cisd'

const BACKEND_PORT = 3030

export type AccountMode = 'demo' | 'real'

export interface MarketInfo {
  name: string
  active_id: number
  long_name: string
  tv_symbol: string
  tv_exchange: string
  trading_hours: string
  always_on: boolean
  /** Payout en pourcentage (snapshot statique — remplacé par la valeur live). */
  payout?: number
}

export interface BalanceInfo {
  id: number
  user_id: number
  type: number            // 4 = demo, 1 = real
  amount: number
  currency: string
  is_cent: boolean
}

export interface OpenPosition {
  id: string
  external_id: number
  active_id: number
  side: 'call' | 'put'
  status: string
  open_quote: number
  invest: number
  pnl: number
  pnl_net: number
  current_price: number
  leverage: string
  open_time: number
  asset?: string
}

export interface TradeVisualRecord {
  id: string | number
  asset: string
  action: 'call' | 'put'
  amount: number
  openPrice: number
  openTime: number
  closeTime?: number
  closePrice?: number
  profit?: number
  isWin?: boolean
  expirationSeconds?: number
  source?: string
  /**
   * v22 — LIBELLÉ D'ORDRE : stratégie + combinaison qui a placé l'ordre +
   * règle de validation. Ex. « Ninja ProTrader · CALL ▲ · call-1
   * [BOS Up + CISD Up] · validation RGRR ». Affiché sur la carte de l'ordre
   * dans le graphique (trade-markers-overlay).
   */
  label?: string
}

export interface AssetInfo {
  id: string
  name: string
  type: string
  payout?: number
  isOtc?: boolean
  /** Nom complet fourni par Pocket Option (ex: "EUR/USD OTC"). */
  longName?: string
  /** Marché actuellement ouvert (OTC toujours true). */
  isOpen?: boolean
}

/** v6 — TUNNELS DE FLUX INDÉPENDANTS (market/social). Santé, latence,
 * séquence et fraîcheur SÉPARÉES par tunnel (§15/§26) : un ralentissement
 * ou une déconnexion d'un flux n'affecte jamais l'état de l'autre. */
export type StreamState =
  | 'DISCONNECTED'
  | 'CONNECTING'
  | 'CONNECTED'
  | 'DEGRADED'
  | 'RECONNECTING'
  | 'ERROR'

export interface ClosedDeal {
  id: number | string
  asset: string
  action: 'call' | 'put'
  amount: number
  openPrice: number
  closePrice: number
  openTime: number
  closeTime: number
  profit: number
  isWin: boolean
}

export interface SessionConfig {
  market: string
  candleSize: number
  historyCount: number
  margin: string
  expirySeconds: number
  autoSwitchAssets?: boolean
  /** v21 — « Stay on Forex OTC Only » : Auto Switch cible uniquement le Forex OTC. */
  stayOnForexOtcOnly?: boolean
  [k: string]: unknown
}

/** Configuration de trading de la session (§4 — source de vérité). */
export interface TradingModePayload {
  mode: 'single' | 'multi'
  assets: string[]
  focus: string | null
  maxAssets: number
}

/** Entrée du tableau `assets[]` du payload de statut (une par asset, §21/§25). */
/** v6.4 — Santé des données de marché d'UN asset (§27 : badge UI). */
export interface MarketDataHealthEntry {
  status: string
  healthScore: number
  badge: 'LIVE' | 'DEGRADED' | 'BLOCKED' | null
  lastTickAt: number | null
  lastCandleAt: number | null
  tickAgeMs: number | null
  candleAgeMs: number | null
  /** Total des trous détectés (jamais masqués — v6.5). */
  gapCount: number
  /** v6.5 — Trous RÉCENTS (fenêtre d'analyse) : ceux qui dégradent. */
  recentGapCount?: number
  /** v6.5 — Trous vieillis hors fenêtre d'analyse : informatifs. */
  agedGapCount?: number
  /** v6.5.1 — Trous de COUTURE historique↔live (limite de la source) :
   * signalés, non bloquants — le trading attend minCandles bougies fraîches. */
  seamGapCount?: number
  /** v6.5.1 — Couture active (lectures d'analyse coupées à la couture). */
  seamFirstLiveSec?: number | null
  candleCount: number
  timeframeSec: number
  historyReady: boolean
  streamConnected: boolean
  reasons: string[]
  trading: { enabled: boolean; reason: string | null } | null
}

export interface AssetStatusEntry {
  asset: string
  active_id: number
  long_name: string
  payout: number | null
  price: number
  lastTickTs: number
  live: boolean
  ticks: number
  isFocus: boolean
  autoTradeEnabled: boolean
  openPositions: OpenPosition[]
  openPositionsCount: number
  totalPnl: number
  /** v6.4 — santé des données + trading bloqué/autorisé PAR ASSET (§27). */
  marketDataHealth?: MarketDataHealthEntry | null
  betting: {
    strategy: 'fixed' | 'martingale' | 'fibonacci'
    baseAmount: number
    consecutiveLosses: number
    fibIndex: number
    nextBetAmount: number
  }
  stats: { signals: number; trades: number; wins: number; losses: number }
  createdAt: number
}

/** Entrée `assets[asset]` du payload auto-trade-status (§13/§21). */
export interface AssetAutoTradeEntry {
  asset: string
  enabled: boolean
  /** Stratégie d'auto-trade active (globale, v6.1) — affichée sur chaque carte. */
  strategyId?: string
  strategyName?: string
  /** Expiration EFFECTIVE des ordres = champ Auto Trade (v6.1). */
  expirySeconds?: number
  bettingStrategy: 'fixed' | 'martingale' | 'fibonacci'
  baseAmount: number
  nextBetAmount: number
  stats: {
    signals: number
    trades: number
    wins: number
    losses: number
    winRate: number | null
    consecutiveLosses: number
    fibIndex: number
  }
  openPositions: number
}

export interface StatusPayload {
  connected: boolean
  authenticated: boolean
  market: MarketInfo | null
  /** Configuration multi-assets de la session (§4). */
  tradingMode: TradingModePayload
  /** Statut PAR ASSET (une entrée autoportante par asset sélectionné — §21/§25). */
  assets: AssetStatusEntry[]
  userId: number | null
  balance: BalanceInfo | null
  openPositions: OpenPosition[]
  openPositionsCount: number
  totalPnl: number
  candlesCaptured: number
  strategyRunning: boolean
  autoTradeEnabled: boolean
  config: SessionConfig
  closeWindowLen: number
  lastSignal: string
  front: string | null
  liveTicksTotal: number
  liveTicksForMarket: number
  lastTickTs: number
  lastTickPrice: number
  lastTickActiveId: number
  lastTickSize: number
  liveActive: boolean
  mode: AccountMode
  server: string | null
  assetsCount: number
  /** Statut auto-trade complet (inclus dans le status 1 Hz). */
  autoTrade?: AutoTradeStatus
}

export interface OrderResult {
  success: boolean
  requestId?: number
  deal?: {
    id: number | string
    openPrice: number
    amount: number
    action?: string
  }
  error?: string
  side?: 'call' | 'put'
  ts: number
}

export interface LoginResult {
  ok: boolean
  error?: string
  user_id?: number
  mode?: AccountMode
  /** v6.3 — true si le backend a REPRI la session existante (login idempotent :
   *  mêmes identifiants, contextes/positions/auto-trade NON réinitialisés). */
  resumed?: boolean
}

/** v20 — Remplacement automatique d'un asset (Auto Switch Assets). */
export interface PayoutSwapEvent {
  from: string
  fromPayout: number
  to: string
  toPayout: number
}

/** v20 — État de l'Auto Switch Assets (backend). */
export interface PayoutGuardStatus {
  enabled: boolean
  /** Déclencheur : payout de l'asset en cours < triggerPct. */
  triggerPct: number
  /** Cible : switch uniquement vers un asset payout == targetPct. */
  targetPct: number
  lastSwaps: Array<{ ts: number; from: string; to: string; fromPayout: number; toPayout: number }>
  swapsLastHour: number
  maxSwapsPerHour: number
}

/** Statut auto-trade complet diffusé par le backend. */
export interface AutoTradeStatus {
  enabled: boolean
  strategyId: string
  strategies: Array<{ id: string; name: string; description: string }>
  bettingStrategy: 'fixed' | 'martingale' | 'fibonacci'
  fixedExpirySeconds: number
  /** v19 — switch « Confirmation bougie précédente » (L_Lucien ProTrader). */
  bosChochCisdConfirmCandle?: boolean
  /** v19/v20 — garde-fou Martingale : nombre max de mises dans la séquence
   *  (0 = illimité). Ex. 4, base 10 : 10→20→40→80 puis retour à 10. */
  maxMartingaleSteps?: number
  /** v24 — état des cases « Vérification CISD » (étapes optionnelles). */
  cisdGuard?: {
    up: boolean
    down: boolean
    swingMode: 'intact' | 'violated'
    confirmBosUp: boolean
    confirmChochUp: boolean
    confirmBosDown: boolean
    confirmChochDown: boolean
  }
  /** Dernier état de la stratégie L_Lucien ProTrader évalué par le backend. */
  lastStrategyState?: {
    asset: string
    action: 'buy' | 'sell' | 'hold'
    confidence: number
    reason: string
    matchedRuleId?: string | null
    events?: string[]
  } | null
  minExpirySeconds: number
  maxExpirySeconds: number
  nextBetAmount: number
  baseAmount: number
  stats: {
    signals: number
    trades: number
    wins: number
    losses: number
    winRate: number | null
    consecutiveLosses: number
    fibIndex: number
  }
  lastProcessedSignalTime: number
  /** Santé anti-duplication : updates brutes reçues / ticks normalisés émis. */
  tickNormalizer: { received: number; emitted: number; droppedStale: number } | null
  /** MULTI-ASSETS (§21) : statut auto-trade complet PAR ASSET. */
  assets?: Record<string, AssetAutoTradeEntry>
}

/** Pocket Option supported candle periods (seconds) — S5 → D1. */
export const TIMEFRAMES: Array<{ label: string; seconds: number }> = [
  { label: 'S5', seconds: 5 },
  { label: 'S10', seconds: 10 },
  { label: 'S15', seconds: 15 },
  { label: 'S30', seconds: 30 },
  { label: 'M1', seconds: 60 },
  { label: 'M2', seconds: 120 },
  { label: 'M3', seconds: 180 },
  { label: 'M5', seconds: 300 },
  { label: 'M10', seconds: 600 },
  { label: 'M15', seconds: 900 },
  { label: 'M30', seconds: 1800 },
  { label: 'H1', seconds: 3600 },
  { label: 'H4', seconds: 14400 },
  { label: 'D1', seconds: 86400 },
]

/** Résultat de la sélection d'assets (event assets-selected). */
export interface AssetsSelectedResult {
  ok: boolean
  error?: string
  mode: 'single' | 'multi'
  assets: string[]
  focus: string | null
  /** v6.3 — true si la sélection vient d'une RESTAURATION de session
   *  (reprise après fermeture du frontend ou redémarrage du backend). */
  restored?: boolean
  ts: number
}

/** Binary order expiration presets (seconds) — minimum broker : 3 s. */
export const EXPIRY_OPTIONS = [3, 5, 10, 15, 30, 60, 120, 300, 600]

const DEFAULT_CONFIG: SessionConfig = {
  // v21 — PLUS d'asset codé en dur (l'ancien 'EURUSD_otc' est RETIRÉ) : la
  // source de vérité est le backend — session restaurée, choix manuel, ou
  // sélection aléatoire d'un asset 92 % au démarrage du programme.
  market: '',
  candleSize: 30,
  historyCount: 300,
  margin: '1.0',
  expirySeconds: 60,
  autoSwitchAssets: false,
  stayOnForexOtcOnly: false,
}

export function usePocketOption() {
  const socketRef = useRef<Socket | null>(null)
  const statusRef = useRef<StatusPayload | null>(null)
  const [status, setStatus] = useState<StatusPayload | null>(null)
  const [configMessage, setConfigMessage] = useState<string | null>(null)
  const [loginResult, setLoginResult] = useState<LoginResult | null>(null)
  const [orderPlaced, setOrderPlaced] = useState<OrderResult | null>(null)
  const [assetsList, setAssetsList] = useState<AssetInfo[]>([])
  const [closedDeals, setClosedDeals] = useState<ClosedDeal[]>([])
  /** v1.6 — efface l'historique des deals affiché dans l'onglet « Trade
   * History » (vue locale uniquement : le backend conserve sa session et
   * renverra les nouveaux deals à leur survenue / reconnexion). */
  const clearClosedDeals = useCallback(() => setClosedDeals([]), [])
  const [tradeVisuals, setTradeVisuals] = useState<TradeVisualRecord[]>([])
  const [autoTradeStatus, setAutoTradeStatus] = useState<AutoTradeStatus | null>(null)
  /** Dernier état de la stratégie L_Lucien ProTrader (évaluation backend en cours). */
  const [lastStrategyState, setLastStrategyState] = useState<AutoTradeStatus['lastStrategyState']>(null)
  const [loggedOut, setLoggedOut] = useState(false)
  const [brokerConnection, setBrokerConnection] = useState<{ state: 'connected' | 'reconnecting'; reason?: string; ts: number; server?: string | null }>({ state: 'reconnecting', ts: Date.now() })
  const [defaultConfig] = useState<SessionConfig>(DEFAULT_CONFIG)
  /** Dernier changement d'actif INITIÉ PAR LE BACKEND (auto-switch) — info UI. */
  const [marketSwitch, setMarketSwitch] = useState<{ from: string; to: string; reason: string; ts: number } | null>(null)
  const [marketRefresh, setMarketRefresh] = useState<{ phase: string; from?: string; to?: string; reason?: string; ts: number } | null>(null)
  /** Monotonic signal: remount/hydrate the lightweight chart after broker asset/session refreshes. */
  const [chartRefreshSignal, setChartRefreshSignal] = useState(0)

  // ──────────────────────────────────────────────────────────────────
  // MULTI-ASSETS (§22) : UN LiveEngine PAR ASSET — jamais un moteur unique.
  //   WebSocket 'candle' {asset} → getEngine(candle.asset).pushRaw(candle)
  // Chaque moteur filtre sur l'active_id de SON asset : un tick EURUSD
  // n'entraîne AUCUN render des cartes BTCUSD/XAUUSD/GBPUSD (§38).
  // ──────────────────────────────────────────────────────────────────
  // FIX (audit v6.5) — les singletons paresseux tenus par useRef étaient lus/
  // écrits PENDANT le rendu (règle react-hooks/refs). Pattern recommandé :
  // instance stable via useState — identité garantie, zéro accès de ref au
  // rendu, comportement strictement identique (Map/Store créés une fois).
  const [engines] = useState<Map<string, LiveEngine>>(() => new Map())

  /** Store observable par asset (re-renders isolés par carte — §38). */
  const [store] = useState<AssetStore>(() => new AssetStore())

  /** Crée (ou retourne) le LiveEngine dédié à un asset (§22). */
  const getEngine = useCallback((asset: string): LiveEngine => {
    let engine = engines.get(asset)
    if (!engine) {
      engine = new LiveEngine()
      engines.set(asset, engine)
    }
    return engine
  }, [engines])

  /** Configuration multi-assets de la session (mode, assets, focus — §4). */
  const [tradingMode, setTradingMode] = useState<TradingModePayload>({
    mode: 'single',
    assets: [],
    focus: null,
    maxAssets: 24,
  })
  /** Dernier résultat de sélection d'assets (event assets-selected). */
  const [selectionResult, setSelectionResult] = useState<AssetsSelectedResult | null>(null)
  /** v6.3 — État du Payout Guard (remplacement auto des assets < 80 %). */
  const [payoutGuardStatus, setPayoutGuardStatus] = useState<PayoutGuardStatus | null>(null)
  /** v6.3 — Dernier remplacement auto (pour toast/notification UI). */
  const [lastPayoutSwap, setLastPayoutSwap] = useState<PayoutSwapEvent | null>(null)

  // ── Compat mono-asset (§34) : moteur/données du FOCUS. En mode single,
  //    le focus est l'unique asset → comportement identique à l'existant.
  const focusAsset = tradingMode.focus ?? status?.market?.name ?? ''
  const engine = useMemo(
    () => (focusAsset ? getEngine(focusAsset) : getEngine('__none__')),
    [focusAsset, getEngine],
  )

  /** Low-frequency snapshot (~1 Hz) for React consumers (stats, panels) — FOCUS. */
  const [chartCandles, setChartCandles] = useState<CandleLike[]>([])

  /** Référence vive du focus pour les closures socket (pas de stale closure). */
  const focusAssetRef = useRef('')
  useEffect(() => {
    focusAssetRef.current = focusAsset
  }, [focusAsset])

  useEffect(() => {
    const isDev = process.env.NODE_ENV === 'development'
    const hostname = typeof window !== 'undefined' ? window.location.hostname : 'localhost'
    const isPreview = hostname.includes('space-z.ai')

    let url: string
    let opts: any
    if (isDev && !isPreview) {
      url = `http://${hostname}:${BACKEND_PORT}`
      opts = { transports: ['websocket'] }
    } else {
      url = '/'
      opts = {
        transports: ['websocket'],
        query: { XTransformPort: String(BACKEND_PORT) },
      }
    }
    const socket = io(url, opts)
    socketRef.current = socket

    socket.on('connect', () => {
      console.log('[pocketoption-backend] connected')
      setBrokerConnection((p) => ({ ...p, state: 'connected', ts: Date.now() }))
      // v6.3 — réclame l'état du Payout Guard (remplacement auto < 80 %).
      socket.emit('get-payout-guard')
    })

    socket.on('broker-connection', (p: { state: 'connected' | 'reconnecting'; reason?: string; ts?: number; server?: string | null }) => {
      setBrokerConnection({ state: p.state, reason: p.reason, ts: p.ts ?? Date.now(), server: p.server ?? null })
    })

    socket.on('status', (s: StatusPayload) => {
      statusRef.current = s
      setStatus(s)
      // L'état auto-trade est aussi inclus dans le status (1 Hz).
      if (s.autoTrade) setAutoTradeStatus(s.autoTrade)
      // Configuration multi-assets (§4) — source de vérité des assets actifs.
      if (s.tradingMode) {
        setTradingMode(s.tradingMode)
        // Alimente le store par asset + lie les moteurs (§22/§38).
        for (const entry of s.assets ?? []) {
          store.update(entry.asset, { status: entry, engine: getEngine(entry.asset) })
        }
        store.setAssets(s.tradingMode.assets, engines)
      }
    })

    // ── v6.4 — SANTÉ DES DONNÉES PAR ASSET (§20/§27) ──
    // Événement dédié (throttle ~2 s PAR asset, indépendant du status 1 Hz) :
    // badge ● LIVE/DEGRADED/BLOCKED + score + raisons de blocage trading.
    // Mise à jour du store PAR ASSET (§38) — un asset bloqué ne re-render
    // QUE sa propre carte.
    socket.on('market-data-health', (p: {
      asset: string
      health: Omit<MarketDataHealthEntry, 'badge' | 'trading'> & { reasons: string[] }
      trading: { allowed: boolean; score: number; status: string; reason?: string; reasons: string[] }
      badge: 'LIVE' | 'DEGRADED' | 'BLOCKED' | null
    }) => {
      if (!p?.asset || !p.health) return
      const cur = store.getSnapshot(p.asset)
      const entry: MarketDataHealthEntry = {
        status: p.health.status,
        healthScore: p.health.healthScore,
        badge: p.badge,
        lastTickAt: p.health.lastTickAt,
        lastCandleAt: p.health.lastCandleAt,
        tickAgeMs: p.health.tickAgeMs,
        candleAgeMs: p.health.candleAgeMs,
        gapCount: p.health.gapCount,
        recentGapCount: p.health.recentGapCount,
        agedGapCount: p.health.agedGapCount,
        seamGapCount: p.health.seamGapCount,
        seamFirstLiveSec: p.health.seamFirstLiveSec,
        candleCount: p.health.candleCount,
        timeframeSec: p.health.timeframeSec,
        historyReady: p.health.historyReady,
        streamConnected: p.health.streamConnected,
        reasons: p.health.reasons ?? [],
        trading: p.trading ? { enabled: p.trading.allowed, reason: p.trading.reason ?? null } : null,
      }
      // Fusion dans le statut existant de CET asset (le status 1 Hz reste
      // source de vérité pour le reste ; la santé est rafraîchie ~2 s).
      if (cur.status) {
        store.update(p.asset, { status: { ...cur.status, marketDataHealth: entry } })
      }
    })

    // ── Sélection d'assets validée côté backend (§3) ──
    socket.on('assets-selected', (r: { ok: boolean; error?: string; mode: 'single' | 'multi'; assets: string[]; focus: string | null; restored?: boolean }) => {
      setSelectionResult({ ...r, ts: Date.now() })
    })

    // ── v6.3 — PAYOUT GUARD : remplacement auto des assets < 80 % ──
    // État (activation, surveillance en cours, derniers remplacements).
    socket.on('payout-guard-status', (s: PayoutGuardStatus) => {
      setPayoutGuardStatus(s)
    })
    // Un remplacement vient d'avoir lieu (même sans frontend ouvert avant).
    socket.on('payout-guard-swap', (swap: PayoutSwapEvent) => {
      if (swap?.from && swap?.to) {
        setLastPayoutSwap({ ...swap, ts: Date.now() } as PayoutSwapEvent & { ts: number })
      }
    })

    // Statut auto-trade détaillé (émis à chaque changement de config/signal).
    // MULTI-ASSETS : le payload contient `assets` — stats PAR ASSET (§21).
    socket.on('auto-trade-status', (s: AutoTradeStatus) => {
      setAutoTradeStatus(s)
      if (s.assets) {
        for (const [asset, entry] of Object.entries(s.assets)) {
          store.update(asset, { autoStatus: entry })
        }
      }
    })

    // ── L_Lucien ProTrader : dernier état de la stratégie évaluée par le
    // backend (action CALL/PUT/HOLD + confiance + raison + règle touchée).
    // Routé PAR ASSET (§21) — le panneau Auto Trade du FOCUS suit SON asset.
    socket.on('strategy-state', (st: NonNullable<AutoTradeStatus['lastStrategyState']>) => {
      if (!st?.asset) return
      if (st.asset !== focusAssetRef.current) return
      setLastStrategyState(st)
    })

    // ── Trades PAR ASSET (§21) : trade-opened / trade-closed ──
    socket.on('trade-opened', (payload: { asset: string; deal: unknown; source?: string; expirationSeconds?: number; label?: string }) => {
      const d = (payload?.deal ?? {}) as any
      const asset = payload?.asset ?? d.asset
      const id = d?.id
      if (!asset || id == null || !d?.action || !Number.isFinite(Number(d?.openTime)) || !Number.isFinite(Number(d?.openPrice))) return
      const action = d.action === 'put' ? 'put' : 'call'
      const expiry = Number(payload?.expirationSeconds ?? statusRef.current?.config?.expirySeconds ?? 60)
      const record: TradeVisualRecord = {
        id, asset, action, amount: Number(d.amount ?? 0), openPrice: Number(d.openPrice),
        openTime: Number(d.openTime), expirationSeconds: Number.isFinite(expiry) && expiry > 0 ? expiry : 60,
        source: payload?.source,
        // v22 — libellé de l'ordre : stratégie + combinaison + règle de validation.
        label: typeof payload?.label === 'string' && payload.label.trim() ? payload.label.trim() : undefined,
      }
      setTradeVisuals(prev => {
        const key = String(id)
        const next = prev.filter(x => String(x.id) !== key)
        next.push(record)
        return next.slice(-200)
      })
    })
    socket.on('trade-closed', (payload: { asset: string; deal: ClosedDeal; isWin: boolean; profit: number }) => {
      if (payload?.asset && payload.deal) {
        store.pushTrade(payload.asset, payload.deal)
        setTradeVisuals(prev => {
          const key = String(payload.deal.id)
          let found = false
          const next = prev.map(t => {
            if (String(t.id) !== key) return t
            found = true
            return { ...t, closeTime: payload.deal.closeTime, closePrice: payload.deal.closePrice, profit: payload.profit, isWin: payload.isWin }
          })
          if (!found) {
            next.push({
              id: payload.deal.id, asset: payload.deal.asset, action: payload.deal.action, amount: payload.deal.amount,
              openPrice: payload.deal.openPrice, openTime: payload.deal.openTime, closeTime: payload.deal.closeTime,
              closePrice: payload.deal.closePrice, profit: payload.deal.profit, isWin: payload.deal.isWin,
              expirationSeconds: Number(statusRef.current?.config?.expirySeconds ?? 60), source: 'closed-deal',
            })
          }
          return next.slice(-200)
        })
      }
    })

    // Le backend peut changer d'actif de lui-même (auto-switch post-trade —
    // mode mono uniquement, §20 : désactivé en multi).
    socket.on('market-switched', (ev: { from: string; to: string; reason?: string }) => {
      setMarketSwitch({ from: ev?.from ?? '?', to: ev?.to ?? '?', reason: ev?.reason ?? '', ts: Date.now() })
    })
    socket.on('market-refresh', (ev: { phase?: string; from?: string; to?: string; reason?: string }) => {
      setMarketRefresh({ phase: ev?.phase ?? 'start', from: ev?.from, to: ev?.to, reason: ev?.reason, ts: Date.now() })
      if ((ev?.phase ?? 'start') === 'start') setChartRefreshSignal((v) => v + 1)
      if (ev?.phase === 'start' && ev?.to) {
        try { getEngine(ev.to).clear() } catch {}
      }
    })
    socket.on('session-refresh', (ev: { phase?: string; reason?: string }) => {
      setMarketRefresh({ phase: `session:${ev?.phase ?? 'unknown'}`, reason: ev?.reason, ts: Date.now() })
      if ((ev?.phase ?? 'unknown') === 'start') setChartRefreshSignal((v) => v + 1)
    })

    // ── v21 — REFRESH OBLIGATOIRE DU FRONTEND (auto-switch assets / Re-Login):
    // le backend a terminé SA reconstruction (abonnements, contextes par
    // asset, historiques, reconnexion broker) et ordonne un rechargement
    // COMPLET de la page. Après le reload, le socket se reconnecte, le status
    // 1 Hz ré-authentifie l'UI et l'asset en cours (focus backend) s'affiche
    // à nouveau — avec un état de graphique strictement reconstruit.
    socket.on('force-frontend-refresh', (ev: { reason?: string; from?: string; to?: string; at?: number }) => {
      console.log('[pocketoption-backend] force-frontend-refresh:', ev?.reason ?? 'unknown',
        ev?.from ? `${ev.from} → ${ev.to ?? '?'}` : '')
      try { window.location.reload() } catch { /* environnement sans navigation */ }
    })

    // ── LIVE STREAM (§7/§22) : chaque bougie est routée vers le LiveEngine
    //    de SON asset. NO setState here — the chart subscribes to the engine
    //    and React only receives throttled batch snapshots (§38).
    socket.on('candle', (c: RawCandleEvent) => {
      const asset = (c as { asset?: string }).asset ?? focusAssetRef.current
      if (!asset) return
      getEngine(asset).pushRaw(c)
    })

    // Historique PAR ASSET (§8/§21) : payload { asset, key, candles }.
    socket.on('candles-history', (data: {
      asset?: string
      key: string
      candles: CandleLike[]
    }) => {
      const asset = data.asset ?? focusAssetRef.current
      if (!asset) return
      // The backend can emit history asynchronously after a market switch.
      // The LiveEngine ignores stale histories (key ≠ current filter) and
      // notifies the chart (single full setData) via onHistory.
      getEngine(asset).resetHistory(data.candles, data.key)
    })

    socket.on('assets', (data: { count: number; list?: AssetInfo[] }) => {
      if (data.list && Array.isArray(data.list)) {
        setAssetsList(data.list)
      }
    })

    socket.on('config-saved', (r: { ok: boolean; error?: string }) => {
      setConfigMessage(r.ok ? 'Configuration sauvegardée' : (r.error ?? 'Échec sauvegarde configuration'))
    })
    socket.on('config-loaded', (r: { ok: boolean; error?: string; config?: SessionConfig }) => {
      if (r.ok && r.config) {
        setStatus(prev => prev ? { ...prev, config: { ...prev.config, ...r.config } } : prev)
        setConfigMessage('Configuration chargée')
      } else {
        setConfigMessage(r.error ?? 'Échec chargement configuration')
      }
    })

    socket.on('login-result', (r: LoginResult) => {
      setLoginResult(r)
      if (r.ok) setLoggedOut(false)
    })

    socket.on('order-placed', (r: any) => {
      setOrderPlaced({
        success: r.success,
        requestId: r.requestId,
        deal: r.deal,
        error: r.error,
        side: r.side,
        ts: Date.now(),
      })
    })

    socket.on('order-error', (r: { error: string; side?: 'call' | 'put' }) => {
      setOrderPlaced({
        success: false,
        error: r.error,
        side: r.side,
        ts: Date.now(),
      })
    })

    socket.on('deal-closed', (deal: ClosedDeal) => {
      // The Pocket Option server can replay the same close twice (same id) —
      // dedupe to keep the trades panel keys unique.
      setClosedDeals((prev) => {
        if (prev.some((d) => String(d.id) === String(deal.id))) return prev
        return [deal, ...prev].slice(0, 50)
      })
      setTradeVisuals(prev => {
        const key = String(deal.id)
        let found = false
        const next = prev.map(t => {
          if (String(t.id) !== key) return t
          found = true
          return { ...t, closeTime: deal.closeTime, closePrice: deal.closePrice, profit: deal.profit, isWin: deal.isWin }
        })
        if (!found) next.push({ id: deal.id, asset: deal.asset, action: deal.action, amount: deal.amount, openPrice: deal.openPrice, openTime: deal.openTime, closeTime: deal.closeTime, closePrice: deal.closePrice, profit: deal.profit, isWin: deal.isWin, expirationSeconds: Number(statusRef.current?.config?.expirySeconds ?? 60), source: 'deal-closed' })
        return next.slice(-200)
      })
    })

    // Recent closed-deal history (backend keeps the last 100 in session).
    // Fetched on (re)connect so the trades panel survives page reloads.
    socket.on('deals', (data: { deals: ClosedDeal[] }) => {
      if (Array.isArray(data.deals)) {
        setClosedDeals((prev) => {
          const seen = new Set(prev.map((d) => String(d.id)))
          const merged = [...prev]
          for (const d of data.deals) {
            const key = String(d.id)
            if (seen.has(key)) continue
            seen.add(key)
            merged.push(d)
          }
          return merged.slice(0, 50)
        })
        setTradeVisuals(prev => {
          const map = new Map(prev.map(t => [String(t.id), t]))
          for (const d of data.deals ?? []) {
            const key = String(d.id)
            const existing = map.get(key)
            map.set(key, {
              ...(existing ?? {}),
              id: d.id, asset: d.asset, action: d.action, amount: d.amount, openPrice: d.openPrice, openTime: d.openTime,
              closeTime: d.closeTime, closePrice: d.closePrice, profit: d.profit, isWin: d.isWin,
              expirationSeconds: Number(existing?.expirationSeconds ?? statusRef.current?.config?.expirySeconds ?? 60),
              source: existing?.source ?? 'deals-history',
            })
          }
          return [...map.values()].sort((a,b) => a.openTime - b.openTime).slice(-200)
        })
      }
    })

    socket.on('disconnect', (reason) => {
      console.log('[pocketoption-backend] UI socket disconnected:', reason)
      setBrokerConnection((p) => ({ ...p, state: 'reconnecting', reason: `UI socket: ${reason}`, ts: Date.now() }))
    })

    return () => {
      socket.disconnect()
    }
     
  }, [store, getEngine, engines])

  // Throttled batch snapshot for React panels (~1 Hz + new candle) — FOCUS.
  // FIX (audit v6.5) — plus de setState synchrone dans le corps de l'effet :
  // resynchronisation pendant le rendu (pattern officiel) quand l'engine
  // change, l'effet ne gère que l'abonnement au flux de batchs.
  const [prevEngine, setPrevEngine] = useState<LiveEngine | null>(engine)
  if (engine !== prevEngine) {
    setPrevEngine(engine)
    setChartCandles(engine.getCandles())
  }
  useEffect(() => {
    const unsub = engine.onBatch((candles) => setChartCandles(candles))
    return unsub
  }, [engine])

  // ──────────────────────────────────────────────────────────────────
  // Actions
  // ──────────────────────────────────────────────────────────────────

  const login = useCallback((email: string, password: string, mode: AccountMode = 'demo') => {
    setLoggedOut(false)
    setLoginResult(null)
    socketRef.current?.emit('login', { email, password, mode })
  }, [])

  /** Client-side logout: the backend session stays alive, but the UI
   *  returns to the login screen until a fresh login is performed. */
  const logout = useCallback(() => {
    setLoggedOut(true)
  }, [])

  const selectMarket = useCallback((market: string) => {
    socketRef.current?.emit('select-market', { market })
  }, [])

  // ── MULTI-ASSETS (§1/§2/§3/§26/§30) ──────────────────────────────

  /**
   * Valide la sélection de marché après le login.
   * Le BACKEND revalide tout : 1 ≤ assets ≤ 10, doublons supprimés (§3).
   */
  const selectAssets = useCallback((mode: 'single' | 'multi', assets: string[]) => {
    socketRef.current?.emit('select-assets', { mode, assets })
  }, [])

  /** Multi : remplace l'asset `from` par l'asset `to` (une carte à la fois). */
  const switchAsset = useCallback((from: string, to: string) => {
    socketRef.current?.emit('switch-asset', { from, to })
  }, [])

  /** Multi : ajoute un asset (le backend rejette au-delà de 10). */
  const addAsset = useCallback((asset: string) => {
    socketRef.current?.emit('add-asset', { asset })
  }, [])

  /** Multi : arrête un asset (contexte supprimé — les autres continuent, §30). */
  const removeAsset = useCallback((asset: string) => {
    socketRef.current?.emit('remove-asset', { asset })
  }, [])

  /**
   * Change l'asset AFFICHÉ en plein écran (§26). Le focus n'arrête JAMAIS le
   * traitement live des autres assets — c'est purement un choix d'affichage.
   */
  const setFocus = useCallback((asset: string) => {
    socketRef.current?.emit('set-focus', { asset })
  }, [])

  /** Auto Trade PAR ASSET (§13) — asset absent = toggle global. */
  const setAutoTradeForAsset = useCallback((asset: string, enabled: boolean) => {
    socketRef.current?.emit('set-auto-trade', { enabled, asset })
  }, [])

  /** Ordre manuel CALL/PUT SUR UN ASSET DONNÉ (§25 — chaque carte trade son asset). */
  const placeOrderForAsset = useCallback((asset: string, opts: {
    action: 'call' | 'put'
    amount?: number
    time?: number
  }) => {
    socketRef.current?.emit('place-order', { ...opts, asset })
  }, [])

  /** Capture l'historique d'un asset donné (défaut : focus). */
  const captureHistoryForAsset = useCallback((asset: string, count?: number, size?: number) => {
    socketRef.current?.emit('capture-history', { asset, count, size })
  }, [])

  /**
   * Switch candle timeframe — SYNCHRONISÉ CÔTÉ BACKEND (protocole .har).
   *
   * Le handler `set-config { candleSize }` applique désormais TOUT le
   * protocole Pocket Option côté backend :
   *   1. changeSymbol {asset, period} → le flux broker est re-tagué à la
   *      nouvelle période (historique ET live restent synchrones)
   *   2. ré-agrégation instantanée du buffer de ticks → candles-history
   *      partiel immédiat (< 1 s)
   *   3. fetch complet paginé en arrière-plan → candles-history complet
   *   4. reset + re-seed des moteurs d'analyse (coach lit le nouveau TF)
   *
   * Inutile de re-sélectionner le marché : select-market ignore désormais
   * les re-sélections du même actif (anti tempête de requêtes).
   */
  const setTimeframe = useCallback((seconds: number, _market?: string) => {
    socketRef.current?.emit('set-config', { candleSize: seconds })
  }, [])

  /** Ask the backend to capture full candle history for the current market.
   * Returns an acknowledgement so Strategy Tester can refresh its replay
   * dataset only after the broker history has actually arrived. */
  const captureHistory = useCallback((count?: number, size?: number): Promise<{ ok: boolean; candles: CandleLike[] }> => {
    return new Promise((resolve) => {
      const socket = socketRef.current
      if (!socket) { resolve({ ok: false, candles: [] }); return }
      socket.emit('capture-history', { count, size }, (result?: { ok?: boolean; candles?: CandleLike[] }) => {
        resolve({ ok: result?.ok === true, candles: Array.isArray(result?.candles) ? result.candles : [] })
      })
    })
  }, [])

  /** Fetch the recent closed-deal history (trades panel). */
  const fetchDeals = useCallback(() => {
    socketRef.current?.emit('get-deals', {})
  }, [])

  /**
   * Place a binary CALL/PUT order.
   * @param opts.action 'call' (up) or 'put' (down)
   * @param opts.amount stake in $ (default: config.margin)
   * @param opts.time   expiration in seconds (default: config.expirySeconds)
   */
  const placeOrder = useCallback((opts: {
    action: 'call' | 'put'
    amount?: number
    time?: number
  }) => {
    socketRef.current?.emit('place-order', opts)
  }, [])

  const setConfig = useCallback((patch: Partial<SessionConfig>) => {
    socketRef.current?.emit('set-config', patch)
  }, [])
  const saveConfig = useCallback(() => { socketRef.current?.emit('save-config') }, [])
  const loadConfig = useCallback(() => { socketRef.current?.emit('load-config') }, [])


  // ── AUTO-TRADE ────────────────────────────────────────────────

  /** Active/désactive l'auto-trade backend. */
  const setAutoTrade = useCallback((enabled: boolean) => {
    socketRef.current?.emit('set-auto-trade', { enabled })
  }, [])

  /** Choisit la stratégie d'auto-trade (L_Lucien ProTrader). */
  const setAutoStrategy = useCallback((strategyId: string) => {
    socketRef.current?.emit('set-auto-strategy', { strategyId })
  }, [])

  /**
   * Configure la mise et l'expiration de l'auto-trade.
   * L'expiration minimale acceptée est de 3 secondes.
   */
  const setAutoConfig = useCallback((cfg: {
    bettingStrategy?: 'fixed' | 'martingale' | 'fibonacci'
    baseAmount?: number
    bosChochCisdBosUp?: boolean
    bosChochCisdBosDown?: boolean
    bosChochCisdChochUp?: boolean
    bosChochCisdChochDown?: boolean
    bosChochCisdCisdUp?: boolean
    bosChochCisdCisdDown?: boolean
    bosChochCisdCallRules?: BosChochCisdOrderRule[]
    bosChochCisdPutRules?: BosChochCisdOrderRule[]
    bosChochCisdReset?: boolean
    /** v19 — switch « Confirmation bougie précédente » (L_Lucien ProTrader). */
    bosChochCisdConfirmCandle?: boolean
    /** v19 — garde-fou Martingale : nombre max de doublements (0 = illimité). */
    maxMartingaleSteps?: number
    /** v24/v25 — étapes de vérification CISD optionnelles ('none' = les deux cases swing décochées). */
    cisdGuardUp?: boolean
    cisdGuardDown?: boolean
    cisdGuardSwingMode?: 'intact' | 'violated' | 'none'
    cisdGuardConfirmBosUp?: boolean
    cisdGuardConfirmChochUp?: boolean
    cisdGuardConfirmBosDown?: boolean
    cisdGuardConfirmChochDown?: boolean
    /** v26 — règles PROPRES à Ninja ProTrader (clés ninja* du backend). */
    ninjaBosChochCisdCallRules?: BosChochCisdOrderRule[]
    ninjaBosChochCisdPutRules?: BosChochCisdOrderRule[]
  }) => {
    socketRef.current?.emit('set-auto-config', cfg)
  }, [])

  /** Demande le statut auto-trade complet au backend. */
  const getAutoStatus = useCallback(() => {
    socketRef.current?.emit('get-auto-status', {})
  }, [])

  /** v6.3 — Active/désactive le Payout Guard (remplacement auto des assets
   *  dont le payout chute sous 80 % par un asset 80-92 %). */
  const setPayoutGuard = useCallback((enabled: boolean) => {
    socketRef.current?.emit('set-payout-guard', { enabled })
  }, [])

  const engineSetFilter = useCallback((activeId: number, size: number) => {
    engine.setFilter(activeId, size)
  }, [engine])

  /** Applique le filtre (active_id, timeframe) au moteur d'UN asset donné. */
  const engineSetFilterForAsset = useCallback((asset: string, activeId: number, size: number) => {
    const assetEngine = engines.get(asset)
    if (assetEngine) assetEngine.setFilter(activeId, size)
  }, [engines])

  const isAuthenticated = !loggedOut && (!!loginResult?.ok || !!status?.authenticated)

  /** Getter par asset (§39) : état complet d'UN asset depuis le store. */
  const getAssetState = useCallback((asset: string): AssetData => store.getSnapshot(asset), [store])
  /** Getter par asset : LiveEngine dédié. */
  const getAssetEngine = useCallback((asset: string): LiveEngine => getEngine(asset), [getEngine])
  /** Getter par asset : bougies courantes (snapshot basse fréquence). */
  const getAssetCandles = useCallback((asset: string): CandleLike[] => {
    return engines.get(asset)?.getCandles() ?? []
  }, [engines])
  /** Getter par asset : statut 1 Hz (prix/positions/mise). */
  const getAssetStatus = useCallback((asset: string) => store.getSnapshot(asset).status, [store])
  /** Getter par asset : statut auto-trade isolé (martingale/fibonacci, §13). */
  const getAssetAutoStatus = useCallback((asset: string) => store.getSnapshot(asset).autoStatus, [store])

  return {
    brokerConnection,
    // state
    status,
    loginResult,
    orderPlaced,
    assetsList,
    closedDeals,
    clearClosedDeals,
    tradeVisuals,
    autoTradeStatus,
    lastStrategyState,
    marketSwitch,
    loggedOut,
    isAuthenticated,
    defaultConfig,
    engine,
    engineSetFilter,
    chartCandles,
    // ── MULTI-ASSETS (§4/§39) ──
    tradingMode,
    selectionResult,
    // ── v6.3 — PAYOUT GUARD (remplacement auto < 80 %) ──
    payoutGuardStatus,
    lastPayoutSwap,
    focusAsset,
    /** Store observable par asset — consommé par les cartes via useAssetData. */
    assetStore: store,
    /** Map<string, LiveEngine> — UN moteur par asset (§22). */
    getEngine,
    getAssetState,
    getAssetEngine,
    getAssetCandles,
    getAssetStatus,
    getAssetAutoStatus,
    // actions
    login,
    logout,
    selectMarket,
    setTimeframe,
    captureHistory,
    fetchDeals,
    placeOrder,
    setConfig,
    setAutoTrade,
    setAutoStrategy,
    setAutoConfig,
    getAutoStatus,
    // v6.3 — Payout Guard
    setPayoutGuard,
    // ── actions MULTI-ASSETS ──
    selectAssets,
    switchAsset,
    addAsset,
    removeAsset,
    setFocus,
    setAutoTradeForAsset,
    placeOrderForAsset,
    captureHistoryForAsset,
    engineSetFilterForAsset,
    saveConfig, loadConfig, configMessage, marketRefresh,
    /** Incrémente à chaque début de market-refresh → force le remontage du ChartWorkspace (clé React). */
    chartRefreshSignal,

  }
}
