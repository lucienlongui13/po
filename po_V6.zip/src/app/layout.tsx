import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PiracyChecker Trade — Pocket Option Trading Platform",
  description:
    "Professional trading platform powered by the Pocket Option API: live OTC candle streaming, candle history, timeframes and binary CALL/PUT orders with real-time balance.",
  keywords: ["PiracyChecker Trade", "Pocket Option", "Binary Options", "Trading", "Candlestick Charts", "OTC"],
  authors: [{ name: "PiracyChecker Trade" }],
  icons: {
    icon: "/pc-trade-logo.jpg",
  },
  openGraph: {
    title: "PiracyChecker Trade",
    description:
      "Professional trading platform with live Pocket Option market data and binary CALL/PUT trading",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        {/* Tailwind CSS Play CDN — JIT compilation in the browser (avoids server-side OOM) */}
        <script src="https://cdn.tailwindcss.com"></script>
        <script
          dangerouslySetInnerHTML={{
            __html: `
              tailwind.config = {
                theme: {
                  extend: {
                    colors: {
                      border: 'hsl(240 5% 84%)',
                      input: 'hsl(240 5% 84%)',
                      ring: 'hsl(240 5% 64.9%)',
                      background: 'hsl(0 0% 100%)',
                      foreground: 'hsl(240 10% 3.9%)',
                      primary: { DEFAULT: 'hsl(240 5.9% 10%)', foreground: 'hsl(0 0% 98%)' },
                      secondary: { DEFAULT: 'hsl(240 4.8% 95.9%)', foreground: 'hsl(240 5.9% 10%)' },
                      destructive: { DEFAULT: 'hsl(0 84.2% 60.2%)', foreground: 'hsl(0 0% 98%)' },
                      muted: { DEFAULT: 'hsl(240 4.8% 95.9%)', foreground: 'hsl(240 3.8% 46.1%)' },
                      accent: { DEFAULT: 'hsl(240 4.8% 95.9%)', foreground: 'hsl(240 5.9% 10%)' },
                      card: { DEFAULT: 'hsl(0 0% 100%)', foreground: 'hsl(240 10% 3.9%)' },
                    },
                  },
                },
                darkMode: 'class',
              }
            `,
          }}
        />
      </head>
      <body className="antialiased">
        {children}
      </body>
    </html>
  );
}
