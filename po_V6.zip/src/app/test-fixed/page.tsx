'use client'

/**
 * test-fixed/page.tsx — DEV-ONLY visual harness for the FIXED SCREEN fix
 * (chart-workspace.tsx: no auto-follow, no shift-on-new-bar).
 *
 * Mounts the REAL ChartWorkspace with a LiveEngine seeded with 250 candles,
 * then STREAMS ticks + new candles (one new candle every ~3.6 s) exactly like
 * the production socket does.
 *
 * Verification protocol:
 *   t0 → screenshot           (initial, positioned at live edge)
 *   +12 s → screenshot        (≈3 new candles) — OLD candles must stay at the
 *                              same x under the fixed red ruler → screen FIXED
 *   pan left → screenshot     (user swipe moves the view)
 *   +8 s → screenshot         (more candles stream — view must NOT snap back)
 *   "Go to Live →" click      (one-shot jump back to the live edge)
 *
 * This route is a DEV-ONLY verification harness (same status as /test-fib):
 * it lets the user confirm the fixed-screen behavior without Pocket Option
 * credentials. NOT part of the production UI.
 */

import { useEffect, useRef, useState } from 'react'
import { ChartWorkspace } from '@/components/trading/chart/chart-workspace'
import { DrawingManager } from '@/lib/drawings'
import { LiveEngine } from '@/lib/live-engine'
import { ReplayEngine } from '@/lib/replay-engine'
import type { CandleLike } from '@/lib/indicators'

function mulberry32(seed: number) {
  let a = seed >>> 0
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

function buildCandles(): CandleLike[] {
  const rnd = mulberry32(4242)
  const gauss = () => (rnd() + rnd() + rnd() + rnd()) / 2 - 1
  const candles: CandleLike[] = []
  const N = 250
  const TF = 60
  const base = Math.floor(Date.now() / 1000 / TF) * TF - N * TF
  let close = 1.1842
  const sigma = 0.00042
  for (let i = 0; i < N; i++) {
    const open = close
    close = open + gauss() * sigma
    const spread = sigma * (0.6 + rnd() * 0.9)
    candles.push({
      time: base + i * TF,
      open,
      high: Math.max(open, close) + spread * rnd(),
      low: Math.min(open, close) - spread * rnd(),
      close,
      volume: Math.round(80 + rnd() * 320),
    })
  }
  return candles
}

export default function TestFixedPage() {
  const [state, setState] = useState<{
    engine: LiveEngine
    replay: ReplayEngine
    drawings: DrawingManager
  } | null>(null)
  const [hud, setHud] = useState({ seconds: 0, candles: 0, newCandles: 0 })
  const seededRef = useRef(false)

  useEffect(() => {
    if (seededRef.current) return
    seededRef.current = true

    const engine = new LiveEngine()
    const candles = buildCandles()
    for (const c of candles) engine.pushCandle(c)

    const replay = new ReplayEngine()
    const drawings = new DrawingManager()
    drawings.setKey('FIXED-TEST:60', candles)
    drawings.setTool('cursor')

    setState({ engine, replay, drawings })
  }, [])

  // ── stream: tick every 900 ms, new candle every 4th tick (~3.6 s) ──
  useEffect(() => {
    if (!state) return
    let i = 0
    let newCandles = 0
    const tick = () => {
      const engine = state.engine
      const candles = engine.getCandles()
      const last = candles[candles.length - 1]
      if (!last) return
      i++
      if (i % 4 === 0) {
        newCandles++
        const open = last.close
        const close = open + (Math.random() - 0.5) * 0.0008
        engine.pushCandle({
          time: last.time + 60,
          open,
          close,
          high: Math.max(open, close) + Math.random() * 0.0002,
          low: Math.min(open, close) - Math.random() * 0.0002,
          volume: 100 + Math.random() * 200,
        })
      } else {
        const close = last.close + (Math.random() - 0.5) * 0.0003
        engine.pushCandle({
          ...last,
          close,
          high: Math.max(last.high, close),
          low: Math.min(last.low, close),
        })
      }
      setHud({ seconds: Math.round((i * 900) / 1000), candles: engine.getCandles().length, newCandles })
    }
    const timer = setInterval(tick, 900)
    return () => clearInterval(timer)
  }, [state])

  if (!state) {
    return <div className="h-screen w-full bg-[#131722] text-[#787B86] flex items-center justify-center">seeding…</div>
  }

  return (
    <div className="h-screen w-full bg-[#131722] flex flex-col">
      <div className="h-8 px-3 flex items-center text-[11px] text-[#787B86] gap-4 border-b border-[#2A2E39]">
        <span className="text-[#D1D4DC] font-medium">FIXED SCREEN TEST</span>
        <span>t+{hud.seconds}s</span>
        <span>candles: {hud.candles}</span>
        <span className="text-[#089981]">new since load: {hud.newCandles}</span>
        <span className="ml-auto">rule: old candles never move; only user swipe moves the view</span>
      </div>
      <div className="relative flex-1 min-h-0">
        <ChartWorkspace
          engine={state.engine}
          replay={state.replay}
          drawings={state.drawings}
          dark={true}
          marketName="FIXED-TEST"
          activeId={1}
          candleSize={60}
        />
        {/* fixed ruler: if the screen slides, candles cross this line */}
        <div className="absolute top-8 bottom-8 w-0.5 bg-red-500/80 z-[6] pointer-events-none"
             style={{ left: '25%', boxShadow: '0 0 0 0.5px rgba(255,0,0,0.4)' }} />
        <div className="absolute top-8 z-[6] pointer-events-none text-[10px] text-red-400 font-bold"
             style={{ left: '25%', marginLeft: 6 }}>
          RULER
        </div>
      </div>
    </div>
  )
}
