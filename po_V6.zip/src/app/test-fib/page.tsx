'use client'

/**
 * test-fib/page.tsx — DEV-ONLY visual harness for the Fibonacci Retracement
 * Smart Trader forecast (smartTraderProjection + drawing-layer rendering).
 *
 * Mounts the REAL ChartWorkspace with a synthetic candle series and a
 * pre-seeded fib-retracement whose anchors are BOTH IN THE PAST:
 *   - anchor 0 on the swing LOW (earlier in time)
 *   - anchor 1 on the swing HIGH (later in time)
 * This reproduces the reported defect scenario: the forecast must appear,
 * start exactly at the current candle and extend only into the future.
 *
 * This route is used for the v15 visual regression test and is NOT part of
 * the production UI (removed before delivery).
 */

import { useEffect, useRef, useState } from 'react'
import { ChartWorkspace } from '@/components/trading/chart/chart-workspace'
import { DrawingManager } from '@/lib/drawings'
import { LiveEngine } from '@/lib/live-engine'
import { ReplayEngine } from '@/lib/replay-engine'
import type { CandleLike } from '@/lib/indicators'
import type { SmartTraderForecast } from '@/components/trading/chart/drawing-layer'

// Deterministic PRNG (mulberry32)
function mulberry32(seed: number) {
  let a = seed >>> 0
  return () => {
    a |= 0
    a = (a + 0x6d2b79f5) | 0
    let t = Math.imul(a ^ (a >>> 15), 1 | a)
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296
  }
}

/** 300 candles: range → pullback → strong impulse → retracement.
 * scenario 'up': up-impulse then pullback (0=LOW earlier, 1=HIGH later)
 * scenario 'down': down-impulse then pullback (0=HIGH earlier, 1=LOW later)
 */
function buildCandles(scenario: 'up' | 'down' | 'future'): CandleLike[] {
  const down = scenario !== 'up'
  const rnd = mulberry32(20260907)
  const gauss = () => {
    // sum of uniforms ≈ normal, scaled
    return ((rnd() + rnd() + rnd() + rnd()) / 2 - 1)
  }
  const candles: CandleLike[] = []
  const N = 300
  const TF = 60
  const base = Math.floor(Date.now() / 1000 / TF) * TF - N * TF
  let close = 1.1842
  const sigma = 0.00042

  const driftAt = (i: number) => {
    const s = down ? -1 : 1
    if (i < 100) return 0.000008 * s          // slow drift (context)
    if (i < 200) return 0.000010 * s          // continued mild
    if (i < 215) return -0.000012 * s         // small counter-move → swing origin
    if (i < 272) return 0.000030 * s          // strong impulse
    return -0.000022 * s                      // retracement pullback
  }

  for (let i = 0; i < N; i++) {
    const open = close
    const noise = gauss() * sigma
    close = open + driftAt(i) + noise
    const spread = sigma * (0.6 + rnd() * 0.9)
    const high = Math.max(open, close) + spread * rnd()
    const low = Math.min(open, close) - spread * rnd()
    candles.push({
      time: base + i * TF,
      open,
      high,
      low,
      close,
      volume: Math.round(80 + rnd() * 320),
    })
  }
  return candles
}

export default function TestFibPage() {
  const [state, setState] = useState<{
    engine: LiveEngine
    replay: ReplayEngine
    drawings: DrawingManager
  } | null>(null)
  const [forecast, setForecast] = useState<SmartTraderForecast | null>(null)
  const seededRef = useRef(false)

  useEffect(() => {
    if (seededRef.current) return
    seededRef.current = true

    const scenario = (new URLSearchParams(window.location.search).get('scenario') ?? 'up') as 'up' | 'down' | 'future'
    const candles = buildCandles(scenario)
    const n = candles.length

    // Swing anchors INSIDE the past data (the reported defect scenario).
    let loIdx = 190, hiIdx = 190
    for (let i = 190; i < 285; i++) {
      if (candles[i].low < candles[loIdx].low) loIdx = i
      if (candles[i].high > candles[hiIdx].high) hiIdx = i
    }
    let firstIdx: number, secondIdx: number, firstPrice: number, secondPrice: number
    if (scenario === 'down') {
      // 0 on the swing HIGH (earlier), 1 on the swing LOW (later) — down leg
      firstIdx = hiIdx < loIdx ? hiIdx : loIdx
      secondIdx = hiIdx < loIdx ? loIdx : hiIdx
      firstPrice = candles[firstIdx].high > candles[secondIdx].high ? candles[firstIdx].high : candles[hiIdx].high
      secondPrice = candles[secondIdx].low
    } else {
      // 0 on the swing LOW (earlier), 1 on the swing HIGH (later) — up leg
      const lowFirst = loIdx < hiIdx
      firstIdx = lowFirst ? loIdx : hiIdx
      secondIdx = lowFirst ? hiIdx : loIdx
      firstPrice = candles[firstIdx].low
      secondPrice = candles[secondIdx].high
    }
    if (scenario === 'future') {
      // anchor 1 dragged INTO the future (old workaround) — horizon extends
      secondIdx = n - 1 + 45
      secondPrice = candles[hiIdx].high
    }

    const engine = new LiveEngine()
    for (const c of candles) engine.pushCandle(c)

    const replay = new ReplayEngine()
    const drawings = new DrawingManager()

    // Seed the fib retracement exactly like the interactive flow does.
    const key = 'EURUSD-TEST:60'
    drawings.setKey(key, candles)
    drawings.setTool('fib-retracement')
    drawings.addDraftPoint({ logical: firstIdx, price: firstPrice }, candles)
    drawings.addDraftPoint({ logical: secondIdx, price: secondPrice }, candles)
    drawings.finishDraft(candles)
    drawings.setTool('cursor')

    setState({ engine, replay, drawings })
  }, [])

  if (!state) {
    return <div className="h-screen w-full bg-[#131722] text-[#787B86] flex items-center justify-center">seeding…</div>
  }

  return (
    <div className="h-screen w-full bg-[#131722] flex flex-col">
      <div className="h-8 px-3 flex items-center text-[11px] text-[#787B86] gap-4 border-b border-[#2A2E39]">
        <span className="text-[#D1D4DC] font-medium">FIB FORECAST VISUAL TEST</span>
        <span>scenario via ?scenario=up|down|future</span>
        {forecast && (
          <span className="ml-auto text-[#089981]">
            forecast: {forecast.direction} conf {forecast.confidence}% target {forecast.target.toFixed(5)}
          </span>
        )}
      </div>
      <div className="flex-1 min-h-0">
        <ChartWorkspace
          engine={state.engine}
          replay={state.replay}
          drawings={state.drawings}
          dark={true}
          marketName="EURUSD-TEST"
          activeId={1}
          candleSize={60}
          onForecast={setForecast}
        />
      </div>
    </div>
  )
}
