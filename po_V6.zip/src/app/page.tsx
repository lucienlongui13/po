'use client'

/**
 * PiracyChecker Trade — TradingView replica workspace.
 *
 * Layout (TradingView-exact):
 *   ┌──────────────────────────────────────────────────────┐
 *   │ TopBar: symbol · timeframes · chart type · fx · ⏱ · │
 *   ├───┬──────────────────────────────────────────┬───────┤
 *   │ D │   BIG CHART (7 styles, 55 indicators,     │ Right │
 *   │ r │   drawings, synced panes, replay…)        │ panel │
 *   │ a ├──────────────────────────────────────────┤ (coll │
 *   │ w │ Bottom: History | Notes | Strategy Tester│ apsib │
 *   │   │ (collapsed by default)                   │  le)  │
 *   └───┴──────────────────────────────────────────┴───────┘
 *
 * Pocket Option API wiring preserved end-to-end: login, assets,
 * live candles (LiveEngine S30), timeframes, CALL/PUT orders,
 * balance, positions, deals.
 */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Toaster, toast } from 'sonner'
import { ChevronDown, ChevronUp, Wallet as WalletIcon, Play, Square } from 'lucide-react'

import { TopBar } from '@/components/trading/top-bar'
import { Sidebar, type WatchItem } from '@/components/trading/sidebar'
import { DrawingToolbar } from '@/components/trading/chart/drawing-toolbar'
import { ChartWorkspace } from '@/components/trading/chart/chart-workspace'
import { IndicatorsMenu } from '@/components/trading/chart/indicators-menu'
import { SymbolSearch } from '@/components/trading/chart/symbol-search'
import { BacktestPanel } from '@/components/trading/chart/backtest-panel'
import { OrderPanel } from '@/components/trading/order-panel'
import { AutoTradePanel } from '@/components/trading/auto-trade-panel'
import { PositionsPanel, DealsPanel } from '@/components/trading/positions-panel'
import { AccountPanel } from '@/components/trading/account-panel'
import { PineScriptEditor } from '@/components/trading/chart/pine-script-editor'
import { LoginScreen } from '@/components/trading/login-screen'

import { usePocketOption } from '@/hooks/use-pocket-option'
import { ReplayEngine, type SimOrder } from '@/lib/replay-engine'
import { LucienProTraderBacktester } from '@/lib/lucien-backtest'
import { DrawingManager } from '@/lib/drawings'
import { useTVStore, type BottomTab } from '@/lib/tv-store'
import { MARKETS_CATALOG, type MarketInfo } from '@/lib/markets-catalog'
import { englishizeText } from '@/lib/english-ui'
import { TradeLogger } from '@/lib/trade-logger'

const BACKTEST_BALANCE_KEY = 'po-backtest-balance-v1'

/** Solde de départ du backtest persisté (défaut 1000 $). */
function loadBacktestBalance(): number {
  if (typeof window === 'undefined') return 1000
  try {
    const v = Number(window.localStorage.getItem(BACKTEST_BALANCE_KEY))
    return Number.isFinite(v) && v >= 1 ? v : 1000
  } catch {
    return 1000
  }
}


const DEFAULT_EMAIL = 'longuilcn@gmail.com'
const DEFAULT_PASSWORD = 'Jean-Paul@#1964'


function SectionHeader({ dark, open, onClick, label, badge }: {
  dark: boolean; open: boolean; onClick: () => void; label: string; badge?: string
}) {
  return (
    <button
      onClick={onClick}
      className="flex items-center justify-between w-full px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wide"
      style={{ color: dark ? '#D1D4DC' : '#131722' }}
    >
      <span className="flex items-center gap-1.5">
        {open ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />}
        {label}
      </span>
      {badge && (
        <span className="text-[9px] px-1.5 py-0.5 rounded-full font-normal" style={{ background: dark ? '#2A2E39' : '#F0F3FA', color: '#787B86' }}>
          {badge}
        </span>
      )}
    </button>
  )
}

export default function Home() {
  const po = usePocketOption()
  const status = po.status

  // ── v20 — THÈME : clair PAR DÉFAUT au démarrage (l'utilisateur peut
  //    basculer en sombre via le sélecteur du TopBar — non persisté).
  const [dark, setDark] = useState(false)
  const [replay] = useState<ReplayEngine>(() => new ReplayEngine())
  // v22 — Strategy Tester : backtesting AUTOMATIQUE L_Lucien ProTrader
  // (combinaisons + Candles Validation du panneau Auto Trade, expiration
  // convertie en nombre de bougies).
  const [lucienBacktester] = useState<LucienProTraderBacktester>(() => new LucienProTraderBacktester(replay))
  useEffect(() => () => lucienBacktester.dispose(), [lucienBacktester])
  // Journal des trades du Strategy Tester (« Log trades » → .logs/trade.jsonl).
  // Abonné au replay (ordres simulés réglés) ; la source de chaque ordre est
  // « manuel » sauf indication contraire.
  const [tradeLogger] = useState<TradeLogger>(() => new TradeLogger(replay))
  const [drawings] = useState<DrawingManager>(() => new DrawingManager())
  const [smartForecast, setSmartForecast] = useState<import('@/components/trading/chart/drawing-layer').SmartTraderForecast | null>(null)

  // ── v6.3 — PAYOUT GUARD : notification quand un asset est remplacé ──
  const lastSwapRef = useRef<string>('')
  useEffect(() => {
    const swap = po.lastPayoutSwap
    if (!swap) return
    const key = `${swap.from}->${swap.to}:${swap.fromPayout}`
    if (key === lastSwapRef.current) return
    lastSwapRef.current = key
    toast(`♻️ ${swap.from} → ${swap.to}`, {
      description: `Payout tombé à ${swap.fromPayout}% (< 92%) et dernier ordre = GAIN — remplacé automatiquement par ${swap.to} (${swap.toPayout}%).`,
    })
  }, [po.lastPayoutSwap])

  // store (workspace state)
  const hydrate = useTVStore((s) => s.hydrate)
  const rightPanelOpen = useTVStore((s) => s.rightPanelOpen)
  const bottomPanelOpen = useTVStore((s) => s.bottomPanelOpen)
  const setBottomPanelOpen = useTVStore((s) => s.setBottomPanelOpen)
  const bottomTab = useTVStore((s) => s.bottomTab)
  const setBottomTab = useTVStore((s) => s.setBottomTab)
  const replayActive = useTVStore((s) => s.replayActive)
  const symbolSearchOpen = useTVStore((s) => s.symbolSearchOpen)
  const setSymbolSearchOpen = useTVStore((s) => s.setSymbolSearchOpen)
  const alerts = useTVStore((s) => s.alerts)
  const addAlert = useTVStore((s) => s.addAlert)
  const removeAlert = useTVStore((s) => s.removeAlert)
  const markAlertTriggered = useTVStore((s) => s.markAlertTriggered)
  const notes = useTVStore((s) => s.notes)
  const setNotes = useTVStore((s) => s.setNotes)

  // right panel sections
  const [watchlistOpen, setWatchlistOpen] = useState(true)
  const [orderOpen, setOrderOpen] = useState(true)
  const [autoTradeOpen, setAutoTradeOpen] = useState(true)
  const [positionsOpen, setPositionsOpen] = useState(true)
  const [accountOpen, setAccountOpen] = useState(false)

  // ── Backtest : solde de départ persisté + reset trades ──
  const [backtestBalance, setBacktestBalance] = useState<number>(loadBacktestBalance)
  const backtestBalanceRef = useRef(backtestBalance)
  useEffect(() => { backtestBalanceRef.current = backtestBalance }, [backtestBalance])

  const handleSetBacktestBalance = useCallback((balance: number) => {
    setBacktestBalance(balance)
    try { window.localStorage.setItem(BACKTEST_BALANCE_KEY, String(balance)) } catch { /* quota */ }
    replay.setStartBalance(balance)
    toast.success(`Backtest start balance: $${balance.toFixed(2)} — trades reset.`)
  }, [replay])

  const handleResetTrades = useCallback(() => {
    replay.resetOrders()
    toast.success('Trades history reset — equity and stats cleared (balance kept).')
  }, [replay])

  useEffect(() => { hydrate() }, [hydrate])

  // Dark mode class toggle — v6.1 : bascule AUSSI la classe `light` pour que
  // globals.css puisse adapter la couleur du TEXTE des champs de saisie
  // (le corps de page héritait d'un texte quasi-blanc → invisible en clair).
  useEffect(() => {
    if (typeof document === 'undefined') return
    document.documentElement.classList.toggle('dark', dark)
    document.documentElement.classList.toggle('light', !dark)
    document.documentElement.style.colorScheme = dark ? 'dark' : 'light'
  }, [dark])

  const activeId = status?.market?.active_id ?? 0
  const candleSize = status?.config?.candleSize ?? po.defaultConfig.candleSize
  const marketName = status?.market?.name ?? ''
  const currentPrice = status?.lastTickPrice ?? 0

  // v22 — Le TF courant du graphique pilote la conversion expiration →
  // bougies du backtest auto L_Lucien ProTrader (Strategy Tester).
  useEffect(() => { lucienBacktester.configure({ candleSizeSec: candleSize }) }, [lucienBacktester, candleSize])

  // ── v1.6 — Trade History en REPLAY : deals SIMULÉS du backtest ──
  // Avant v1.6, l'onglet « Trade History » affichait TOUJOURS les deals réels
  // du backend (session socket) — même pendant un backtest — et « RESET
  // TRADES » ne pouvait pas les effacer : l'historique semblait « codé en
  // dur ». En replay, l'onglet liste maintenant les trades simulés réglés du
  // Strategy Tester : RESET TRADES les efface (onOrdersReset ci-dessous),
  // comme le tableau du Strategy Tester.
  const [simDeals, setSimDeals] = useState<Array<{
    id: number | string
    asset: string
    action: 'call' | 'put'
    amount: number
    openPrice: number
    closePrice: number
    closeTime: number
    profit: number
    isWin: boolean
  }>>([])
  useEffect(() => {
    // UPDATE-PRESSURE GUARD : onState fire à chaque bougie (jusqu'à ~33/s en
    // X80). On ne re-render que quand le CONTENU réglé change (un ordre
    // placé/réglé/reset modifie forcément l'une de ces valeurs).
    let lastSig = ''
    const sigOf = (os: SimOrder[]) =>
      [os.length,
        os.filter((o) => o.status === 'won').length,
        os.filter((o) => o.status === 'lost').length,
        os.filter((o) => o.status === 'refunded').length].join('|')
    const push = () => {
      const os = replay.allOrders
      const sig = sigOf(os)
      if (sig === lastSig) return
      lastSig = sig
      setSimDeals(
        os
          .filter((o) => o.status !== 'open')
          .slice(0, 50)
          .map((o) => ({
            id: o.id,
            asset: marketName || 'REPLAY',
            action: o.side,
            amount: o.amount,
            openPrice: o.entryPrice,
            closePrice: o.exitPrice ?? o.entryPrice,
            closeTime: o.exitTime ?? o.entryTime,
            profit: o.profit ?? 0,
            isWin: o.status === 'won',
          })),
      )
    }
    const unsub = replay.onState(() => push())
    // RESET TRADES / setStartBalance → l'historique simulé se vide aussitôt.
    const unsubReset = replay.onOrdersReset(() => {
      lastSig = ''
      setSimDeals([])
    })
    return () => { unsub(); unsubReset() }
    // marketName : ré-abonnement au changement d'actif (libellé des deals).
  }, [replay, marketName])

  // ── TRADE LOGGER : contexte (actif, TF) + nettoyage ──
  // Le provider ferme sur les valeurs courantes du rendu ; il est ré-armé à
  // chaque changement pertinent (assignation de closure — pas de re-render).
  useEffect(() => {
    tradeLogger.setContextProvider(() => ({
      asset: marketName || '',
      candleSize,
    }))
  }, [tradeLogger, marketName, candleSize])
  useEffect(() => () => tradeLogger.dispose(), [tradeLogger])


  // Auto-capture history on login + market/timeframe change
  const captureKey = `${status?.authenticated ? '1' : '0'}:${activeId}:${candleSize}`
  const lastCaptureKeyRef = useRef('')
  useEffect(() => {
    if (!status?.authenticated || activeId <= 0) return
    if (lastCaptureKeyRef.current === '') {
      po.fetchDeals()
      po.getAutoStatus()
    }
    if (lastCaptureKeyRef.current === captureKey) return
    lastCaptureKeyRef.current = captureKey
    po.captureHistory(status?.config?.historyCount, candleSize)
  }, [captureKey, status?.authenticated, status?.config?.historyCount, candleSize, po.captureHistory, po.setConfig, po.fetchDeals, po.getAutoStatus])

  // ── Changement d'actif initié par le BACKEND (auto-switch) ──
  // Doit être VISIBLE : sans cela, le graphique « change de prix » sans
  // explication et paraît endommagé.
  const lastSwitchTsRef = useRef(0)
  useEffect(() => {
    if (!po.marketSwitch || po.marketSwitch.ts === lastSwitchTsRef.current) return
    lastSwitchTsRef.current = po.marketSwitch.ts
    toast.info(`Asset changed by backend: ${po.marketSwitch.from} → ${po.marketSwitch.to}`, {
      description: englishizeText(`${po.marketSwitch.reason} — the chart now follows the new asset automatically.`, 'The chart now follows the new asset automatically.'),
    })
  }, [po.marketSwitch])

  // ── Watchlist: catalog (183 actifs du HAR) + données live du broker ──
  const watchlist: WatchItem[] = useMemo(() => {
    const catalogMap = new Map(MARKETS_CATALOG.map((m) => [m.name, m]))
    const liveMap = new Map(po.assetsList.map((a) => [a.name, a]))
    const merged: WatchItem[] = MARKETS_CATALOG.map((m) => {
      const live = liveMap.get(m.name)
      return {
        ticker: m.name,
        name: live?.longName ?? m.long_name,
        payout: live?.payout ?? m.payout,
        isOtc: live?.isOtc ?? m.name.includes('_otc'),
        ltp: 0,
        chg: 0,
        live: false,
      }
    })
    // Actifs live inconnus du catalogue statique (ajouts futurs côté Pocket Option)
    for (const a of po.assetsList) {
      if (catalogMap.has(a.name)) continue
      merged.push({
        ticker: a.name,
        name: a.longName ?? (a.type ? a.type.charAt(0).toUpperCase() + a.type.slice(1) : 'Asset'),
        payout: a.payout,
        isOtc: a.isOtc ?? false,
        ltp: 0,
        chg: 0,
        live: false,
      })
    }
    if (marketName) {
      const idx = merged.findIndex((w) => w.ticker === marketName)
      if (idx >= 0) {
        const candles = po.chartCandles
        if (candles.length > 0) {
          const last = candles[candles.length - 1]
          const ref = candles[Math.max(0, candles.length - 60)]
          const chg = ref && ref.close > 0 ? ((last.close - ref.close) / ref.close) * 100 : 0
          merged[idx] = { ...merged[idx], ltp: last.close, chg, live: true }
        }
      }
    }
    return merged
  }, [po.assetsList, po.chartCandles, marketName])

  // symbol search items
  const symbolItems = useMemo(
    () => watchlist.map((w) => ({ ticker: w.ticker, name: w.name, payout: w.payout, isOtc: w.isOtc })),
    [watchlist],
  )

  const stats = useMemo(() => {
    const c = po.chartCandles
    if (c.length === 0) return { ltp: currentPrice, changePct: 0, hasData: false }
    const last = c[c.length - 1]
    const ref = c[Math.max(0, c.length - 60)]
    const changePct = ref && ref.close > 0 ? ((last.close - ref.close) / ref.close) * 100 : 0
    return { ltp: last.close, changePct, hasData: true }
  }, [po.chartCandles, currentPrice])

  const balanceLabel = useMemo(() => {
    const b = status?.balance
    if (!b) return '—'
    const amount = b.is_cent ? b.amount / 100 : b.amount / (b.currency === 'USD' ? 100 : 1)
    const cur = b.currency === 'USD' ? '$' : `${b.currency} `
    return `${cur}${amount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
  }, [status?.balance])

  const payout = useMemo(() => {
    const live = po.assetsList.find((a) => a.name === marketName)
    if (live?.payout != null) return live.payout
    // Fallback : payout statique du catalogue (snapshot HAR)
    const cat = MARKETS_CATALOG.find((m) => m.name === marketName)
    return cat?.payout ?? null
  }, [po.assetsList, marketName])

  const assetNames = useMemo(() => {
    const m = new Map<number, string>()
    for (const a of po.assetsList) {
      const id = parseInt(a.id, 10)
      if (Number.isFinite(id)) m.set(id, a.name)
    }
    for (const mk of MARKETS_CATALOG) if (!m.has(mk.active_id)) m.set(mk.active_id, mk.name)
    return m
  }, [po.assetsList])

  // ── Price alerts check (~1 Hz batch) ──
  useEffect(() => {
    if (!marketName || po.chartCandles.length === 0) return
    const last = po.chartCandles[po.chartCandles.length - 1].close
    for (const a of alerts) {
      if (a.triggered || a.symbol !== marketName) continue
      if ((a.direction === 'above' && last >= a.price) || (a.direction === 'below' && last <= a.price)) {
        markAlertTriggered(a.id)
        toast(`🔔 Alert: ${marketName} ${a.direction === 'above' ? 'crossed ABOVE' : 'crossed BELOW'} ${a.price}`, {
          description: 'Price alert triggered',
        })
      }
    }
  }, [po.chartCandles, marketName, alerts, markAlertTriggered])

  // ── Replay ──
  // 10-day candle ceiling — the same cap the backend applies to explicit
  // history captures. This is what "replay from the beginning" can reach.
  const maxBarsBack = useMemo(
    () => Math.max(60, Math.ceil((10 * 86400) / Math.max(1, candleSize))),
    [candleSize],
  )

  const startReplay = async (barsBack: number) => {
    // Deep dataset first: the Pine buffer keeps up to 5,000 candles while the
    // visible chart window is capped at 300 — replay must use the deep one.
    let candles = po.engine.getPineCandles()
    const wanted = Math.max(40, barsBack + 30)

    // Replay is seeded from real historical data. Fetch a larger dataset BEFORE
    // entering replay whenever the deep buffer is too short.
    if (candles.length < wanted) {
      const result = await po.captureHistory(wanted, candleSize)
      if (result.ok && result.candles.length > candles.length) candles = result.candles
    }

    if (candles.length < 20) {
      toast.error(`Not enough history for replay (${candles.length}/20 candles)`)
      return
    }

    // barsBack may cover the whole fetched history (replay from bar 0).
    const safeBarsBack = Math.max(0, Math.min(barsBack, candles.length - 1))
    replay.start(candles, safeBarsBack, backtestBalanceRef.current)
    lucienBacktester.reset() // v22 — ré-arme la garde du backtest auto
    const st = useTVStore.getState()
    st.setReplayActive(true)
    st.setBottomTab('backtest')
    st.setBottomPanelOpen(true)
    toast.success(`Bar replay started — ${safeBarsBack.toLocaleString()} bars back (${candles.length.toLocaleString()} available).`)
  }

  const placeSimOrder = (opts: { action: 'call' | 'put'; amount: number; time: number }) => {
    const payoutVal = payout ?? 92
    const expiryBars = Math.max(1, Math.round(opts.time / candleSize))
    // v22 — CHAQUE ordre simulé porte son libellé (ici : ordre manuel).
    const order = replay.placeSim(opts.action, opts.amount, expiryBars, payoutVal, 'Manuel · Order panel')
    if (order) {
      toast(`Simulated ${opts.action.toUpperCase()} $${opts.amount} · ${expiryBars} bars · payout ${payoutVal}%`)
    } else {
      toast.error(`Simulated ${opts.action.toUpperCase()} refused — insufficient balance ($${replay.availableBalance.toFixed(2)} available for a $${opts.amount} stake).`)
    }
  }

  // v21 — BUG FIX « le refresh repart sur EURUSD_otc » : l'ancien effet
  // déclenchait selectMarket(DEFAULT_CONFIG.market = 'EURUSD_otc') à CHAQUE
  // (re)authentification — écrasant l'asset en cours (ex. CADJPY_otc) après
  // un simple refresh de la page. SUPPRIMÉ : le défaut codé en dur n'existe
  // plus ; la source de vérité de l'asset affiché est UNIQUEMENT le backend
  // (status 1 Hz → market/tradingMode.focus) — session restaurée, choix
  // manuel, ou sélection aléatoire d'un asset 92 % au démarrage du programme.

  // ────────────────────────────────────────────────────────────── screens
  if (!po.isAuthenticated) {
    return (
      <LoginScreen
        onLogin={po.login}
        loginResult={po.loggedOut ? null : po.loginResult}
        defaultEmail={DEFAULT_EMAIL}
        defaultPassword={DEFAULT_PASSWORD}
      />
    )
  }

  const loggingIn = !status?.authenticated
  const border = dark ? '#2A2E39' : '#E0E3EB'
  const bg = dark ? '#131722' : '#FFFFFF'

  const bottomTabs: Array<{ key: BottomTab; label: string }> = [
    { key: 'history', label: 'Trade History' },
    { key: 'notes', label: 'Notes' },
    { key: 'backtest', label: 'Strategy Tester' },
  ]

  return (
    <div className="h-screen w-full overflow-hidden flex flex-col" style={{ background: dark ? '#131722' : '#FFFFFF' }}>
      <Toaster theme={dark ? 'dark' : 'light'} position="bottom-right" richColors />

      <TopBar
        dark={dark}
        setDark={setDark}
        marketName={marketName}
        price={currentPrice || stats.ltp}
        changePct={stats.changePct}
        timeframe={candleSize}
        setTimeframe={(s) => po.setTimeframe(s, marketName)}
        onLogout={() => {
          replay.stop()
          useTVStore.getState().setReplayActive(false)
          po.logout()
        }}
        balanceLabel={balanceLabel}
        mode={status?.mode ?? 'demo'}
        liveActive={!!status?.liveActive}
        brokerConnected={!!status?.connected}
        brokerReconnecting={po.brokerConnection?.state === 'reconnecting' && !po.loggedOut}
        replayActive={replayActive}
        onStartReplay={startReplay}
        maxBarsBack={maxBarsBack}
        alertCount={alerts.filter((a) => !a.triggered).length}
        onAddAlert={(price, direction) => addAlert(marketName, price, direction)}
        onRemoveAlert={removeAlert}
        alerts={alerts}
      />

      <div className="flex flex-1 min-h-0">
        {/* left drawing toolbar */}
        <DrawingToolbar manager={drawings} dark={dark} />

        {/* center column: chart + bottom panel */}
        <div className="flex flex-col flex-1 min-w-0">
          <div className="flex-1 min-h-0">
            {loggingIn ? (
              <div className="h-full flex items-center justify-center" style={{ color: '#787B86' }}>
                <div className="text-center">
                  <div className="animate-spin h-8 w-8 border-4 rounded-full mx-auto mb-3"
                    style={{ borderColor: '#2962FF', borderTopColor: 'transparent' }} />
                  <div className="text-sm">Connecting to Pocket Option…</div>
                </div>
              </div>
            ) : (
              <ChartWorkspace
                key={`${marketName}:${po.chartRefreshSignal}`}
                engine={po.engine}
                replay={replay}
                drawings={drawings}
                dark={dark}
                marketName={marketName}
                activeId={activeId}
                candleSize={candleSize}
                tradeVisuals={po.tradeVisuals}
                onForecast={setSmartForecast}
                bosChochCisdActive={po.autoTradeStatus?.strategyId === 'l_lucien_protrader' || po.autoTradeStatus?.strategyId === 'ninja_protrader'}
              />
            )}
          </div>

          {/* bottom panel — COLLAPSED BY DEFAULT (Trade History, Notes, Strategy Tester) */}
          <div className="border-t shrink-0" style={{ borderColor: border, background: bg }}>
            <div className="flex items-center h-8 px-2 gap-0.5">
              {bottomTabs.map((t) => (
                <button
                  key={t.key}
                  onClick={() => {
                    if (bottomPanelOpen && bottomTab === t.key) {
                      setBottomPanelOpen(false)
                    } else {
                      setBottomTab(t.key)
                      setBottomPanelOpen(true)
                    }
                  }}
                  className="px-2.5 h-6 rounded text-[11px] font-medium transition-colors"
                  style={{
                    background: bottomPanelOpen && bottomTab === t.key ? (dark ? '#2A2E39' : '#F0F3FA') : 'transparent',
                    color: bottomPanelOpen && bottomTab === t.key ? (dark ? '#D1D4DC' : '#131722') : '#787B86',
                  }}
                >
                  {t.label}
                  {t.key === 'history' && (replayActive ? simDeals.length : po.closedDeals.length) > 0 && ` (${replayActive ? simDeals.length : po.closedDeals.length})`}
                  {t.key === 'backtest' && replayActive && ' ●'}
                </button>
              ))}
              <div className="ml-auto flex items-center gap-1">
                {replayActive && (
                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded text-white" style={{ background: '#FF6D00' }}>
                    REPLAY
                  </span>
                )}
                <button
                  onClick={() => setBottomPanelOpen(!bottomPanelOpen)}
                  className="p-1 rounded hover:bg-black/10"
                  title={bottomPanelOpen ? 'Collapse' : 'Expand'}
                >
                  {bottomPanelOpen ? <ChevronDown className="h-3.5 w-3.5" /> : <ChevronUp className="h-3.5 w-3.5" />}
                </button>
              </div>
            </div>

            {bottomPanelOpen && (
              <div className="border-t overflow-hidden" style={{ borderColor: border, height: 224 }}>
                {bottomTab === 'history' && (
                  <div className="h-full overflow-y-auto p-2">
                    {/* v1.6 — replay : trades SIMULÉS du backtest. « EFFACER »
                        fait exactement RESET TRADES (orders + equity + stats).
                        live : deals réels du backend (effacement local). */}
                    <DealsPanel
                      deals={replayActive ? simDeals : po.closedDeals}
                      sim={replayActive}
                      onClear={replayActive ? handleResetTrades : po.clearClosedDeals}
                    />
                  </div>
                )}
                {bottomTab === 'notes' && (
                  <textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Strategy notes, risk rules, trade journal…"
                    className="w-full h-full p-3 bg-transparent outline-none resize-none text-[12px] leading-5"
                    style={{ color: dark ? '#D1D4DC' : '#131722' }}
                  />
                )}
                {bottomTab === 'backtest' && (
                  <div className="h-full">
                    {replayActive ? (
                      <BacktestPanel
                replay={replay}
                dark={dark}
                candleSize={candleSize}
                startBalance={backtestBalance}
                onSetStartBalance={handleSetBacktestBalance}
                onResetTrades={handleResetTrades}
                tradeLogger={tradeLogger}
                lucienBacktester={lucienBacktester}
                onFetchHistory={async (days) => {
                  const count = Math.max(1, Math.ceil(days * 86400 / Math.max(1, candleSize)))
                  const result = await po.captureHistory(count, candleSize)
                  if (!result.ok) {
                    toast.error('Fetch History: no historical data received.')
                    return
                  }
                  // The broker history has now been ingested into the live
                  // engine. Rebuild the replay dataset from that fresh series
                  // so the fetched candles are immediately visible in the chart.
                  const fresh = result.candles
                  if (fresh.length < 20) {
                    toast.error(`Fetch History completed, but only ${fresh.length} candles are available.`)
                    return
                  }
                  // KEY FIX — the replayable range now covers the ENTIRE
                  // fetched history: restart from the very first candle so
                  // binary-option strategies can be tested over the whole
                  // deep series (previously the old barsBack was preserved
                  // and the fetched past stayed unreachable).
                  replay.start(fresh, fresh.length - 1, backtestBalanceRef.current)
                  toast.success(`History loaded: ${fresh.length.toLocaleString()} candles (${days} day${days > 1 ? 's' : ''}) — replay restarted from the beginning.`)
                }}
              />
                    ) : (
                      <div className="h-full flex flex-col items-center justify-center gap-2 text-[12px]" style={{ color: '#787B86' }}>
                        <WalletIcon className="h-5 w-5 opacity-50" />
                        <span>Strategy Tester runs during Bar Replay — press “Replay” in the top bar to start backtesting.</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* right panel — collapsible */}
        {rightPanelOpen && (
          <div className="hidden md:flex flex-col w-[300px] shrink-0 border-l overflow-y-auto"
            style={{ borderColor: border, background: dark ? '#0F1117' : '#FAFBFD' }}>
            <SectionHeader dark={dark} open={watchlistOpen} onClick={() => setWatchlistOpen(!watchlistOpen)} label="Watchlist" badge={`${watchlist.length}`} />
            {watchlistOpen && (
              <Sidebar
                list={watchlist}
                active={marketName}
                onSelect={(m) => po.selectMarket(m)}
              />
            )}

            <div className="border-t" style={{ borderColor: border }} />
            <SectionHeader dark={dark} open={orderOpen} onClick={() => setOrderOpen(!orderOpen)} label={replayActive ? 'Order · Simulated' : 'Order'} />
            {orderOpen && (
              <OrderPanel
                asset={marketName}
                currentPrice={currentPrice || stats.ltp}
                payout={payout}
                disabled={loggingIn || !marketName}
                onPlaceOrder={replayActive ? placeSimOrder : po.placeOrder}
                orderResult={po.orderPlaced}
                simMode={replayActive}
                candleSize={candleSize}
                smartForecast={smartForecast}
              />
            )}

            <div className="px-3 pb-2 space-y-2">
              <div className="flex items-center justify-between rounded-lg border px-2.5 py-2" style={{ borderColor: border }}>
                <div>
                  <div className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: dark ? '#D1D4DC' : '#131722' }}>Auto-switch assets</div>
                  <div className="text-[9px] text-zinc-500 dark:text-zinc-400 mt-0.5">Payout &lt; 92% + dernier ordre GAIN → asset 92%</div>
                </div>
                <button
                  type="button"
                  onClick={() => po.setConfig({ autoSwitchAssets: !(status?.config?.autoSwitchAssets === true) })}
                  disabled={loggingIn || !marketName}
                  aria-pressed={status?.config?.autoSwitchAssets === true}
                  className="relative w-12 h-6 rounded-full transition-colors disabled:opacity-50"
                  style={{ background: status?.config?.autoSwitchAssets === true ? '#089981' : '#71717a' }}
                  title="Switch automatique : dès que le payout de l'asset en cours passe sous 92% et que le dernier ordre est un gain → switch vers un asset à payout == 92%"
                >
                  <span className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all flex items-center justify-center" style={{ left: status?.config?.autoSwitchAssets === true ? '26px' : '2px' }}>
                    {status?.config?.autoSwitchAssets === true
                      ? <Play className="h-2.5 w-2.5" style={{ color: '#089981' }} />
                      : <Square className="h-2.5 w-2.5 text-zinc-500" />}
                  </span>
                </button>
              </div>
              {/* v21 — « Stay on Forex OTC Only » : placé SOUS Auto-switch assets.
                  ON = tout Auto Switch Assets ne choisit QUE des paires Forex OTC
                  (CADJPY_otc, AUDUSD_OTC…). */}
              <div className="flex items-center justify-between rounded-lg border px-2.5 py-2" style={{ borderColor: border }}>
                <div>
                  <div className="text-[10px] font-semibold uppercase tracking-wide" style={{ color: dark ? '#D1D4DC' : '#131722' }}>Stay on Forex OTC Only</div>
                  <div className="text-[9px] text-zinc-500 dark:text-zinc-400 mt-0.5">Auto-switch limité aux paires Forex OTC (CADJPY_otc, AUDUSD_OTC…)</div>
                </div>
                <button
                  type="button"
                  onClick={() => po.setConfig({ stayOnForexOtcOnly: !(status?.config?.stayOnForexOtcOnly === true) })}
                  disabled={loggingIn || !marketName}
                  aria-pressed={status?.config?.stayOnForexOtcOnly === true}
                  className="relative w-12 h-6 rounded-full transition-colors disabled:opacity-50"
                  style={{ background: status?.config?.stayOnForexOtcOnly === true ? '#089981' : '#71717a' }}
                  title="Stay on Forex OTC Only : lorsqu'il est ON, tout Auto Switch Assets ne choisira que les actifs Forex OTC (CADJPY_otc, AUDUSD_OTC…) — jamais métaux, cryptos, indices ni actions"
                >
                  <span className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all flex items-center justify-center" style={{ left: status?.config?.stayOnForexOtcOnly === true ? '26px' : '2px' }}>
                    {status?.config?.stayOnForexOtcOnly === true
                      ? <Play className="h-2.5 w-2.5" style={{ color: '#089981' }} />
                      : <Square className="h-2.5 w-2.5 text-zinc-500" />}
                  </span>
                </button>
              </div>
            </div>
            <div className="flex gap-2 px-3 pb-2">
              <button type="button" onClick={() => po.saveConfig()} className="flex-1 rounded border px-2 py-1.5 text-[9px] font-semibold hover:bg-white/5" style={{ borderColor: border }}>SAVE CONFIG</button>
              <button type="button" onClick={() => po.loadConfig()} className="flex-1 rounded border px-2 py-1.5 text-[9px] font-semibold hover:bg-white/5" style={{ borderColor: border }}>LOAD CONFIG</button>
            </div>

            <div className="border-t" style={{ borderColor: border }} />


            <div className="border-t" style={{ borderColor: border }} />
            <SectionHeader
              dark={dark}
              open={autoTradeOpen}
              onClick={() => setAutoTradeOpen(!autoTradeOpen)}
              label="Auto Trade"
              badge={po.autoTradeStatus?.enabled ? 'ON' : undefined}
            />
            {autoTradeOpen && (
              <AutoTradePanel
                asset={marketName}
                status={po.autoTradeStatus}
                disabled={loggingIn || !marketName}
                onToggle={po.setAutoTrade}
                onStrategyChange={po.setAutoStrategy}
                onConfigChange={po.setAutoConfig}
              />
            )}

            <div className="border-t" style={{ borderColor: border }} />
            <SectionHeader dark={dark} open={positionsOpen} onClick={() => setPositionsOpen(!positionsOpen)} label="Positions" badge={`${status?.openPositionsCount ?? 0}`} />
            {positionsOpen && (
              <PositionsPanel
                positions={status?.openPositions ?? []}
                currentPrice={currentPrice || stats.ltp}
                assetNames={assetNames}
              />
            )}

            <div className="border-t" style={{ borderColor: border }} />
            <SectionHeader dark={dark} open={accountOpen} onClick={() => setAccountOpen(!accountOpen)} label="Account" />
            {accountOpen && <AccountPanel status={status} balanceLabel={balanceLabel} />}

            <div className="mt-auto p-3 text-[10px]" style={{ color: '#787B86' }}>
              PiracyChecker Trade · TradingView-style workspace powered by the Pocket Option API —
              live candles, 55 indicators, 17 drawing tools, bar replay backtesting.
            </div>
          </div>
        )}
      </div>

      {/* modals */}
      <IndicatorsMenu dark={dark} />
      <PineScriptEditor dark={dark} engine={po.engine} replay={replay} replayActive={replayActive} marketName={marketName} candleSize={candleSize} />
      <SymbolSearch
        open={symbolSearchOpen}
        onClose={() => setSymbolSearchOpen(false)}
        onSelect={(t) => po.selectMarket(t)}
        items={symbolItems}
        active={marketName}
        dark={dark}
      />
    </div>
  )
}
