import { NextResponse } from 'next/server'
import { appendFile, mkdir, readFile } from 'node:fs/promises'
import { resolve } from 'node:path'

/**
 * POST /api/trade-log — append des entrées dans `.logs/trade.jsonl`.
 *
 * Reçoit UN objet ou un TABLEAU d'objets (batch du TradeLogger) ; chaque
 * objet devient UNE ligne JSON (format JSONL). Le dossier `.logs/` est
 * créé au besoin — le fichier vit côté serveur, à la racine du projet
 * (là où tourne `npm run dev` / `npm start`).
 *
 * GET /api/trade-log — état du journal (existence + nombre de lignes) pour
 * l'affichage du compteur dans le Strategy Tester.
 */

export const dynamic = 'force-dynamic'

const LOG_DIR = () => resolve(process.cwd(), '.logs')
const LOG_FILE = () => resolve(LOG_DIR(), 'trade.jsonl')

/** Garde-fous serveur : taille max d'un batch et d'une ligne. */
const MAX_BATCH = 100
const MAX_LINE_CHARS = 256 * 1024

export async function POST(req: Request) {
  let body: unknown
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ ok: false, error: 'Corps JSON invalide' }, { status: 400 })
  }
  const entries = (Array.isArray(body) ? body : [body]).slice(0, MAX_BATCH)
  const lines: string[] = []
  for (const e of entries) {
    if (!e || typeof e !== 'object' || !('trade' in e)) continue
    let line: string
    try {
      line = JSON.stringify(e)
    } catch {
      continue
    }
    if (line.length > MAX_LINE_CHARS) continue
    lines.push(line)
  }
  if (lines.length === 0) {
    return NextResponse.json({ ok: false, error: 'Aucune entrée valide' }, { status: 400 })
  }
  try {
    await mkdir(LOG_DIR(), { recursive: true })
    await appendFile(LOG_FILE(), lines.join('\n') + '\n', 'utf8')
    return NextResponse.json({ ok: true, appended: lines.length, file: '.logs/trade.jsonl' })
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err)
    return NextResponse.json({ ok: false, error: `Écriture impossible : ${message}` }, { status: 500 })
  }
}

export async function GET() {
  try {
    const raw = await readFile(LOG_FILE(), 'utf8')
    const lines = raw.split('\n').filter((l) => l.trim().length > 0)
    return NextResponse.json({ ok: true, exists: true, lines: lines.length, file: '.logs/trade.jsonl' })
  } catch {
    return NextResponse.json({ ok: true, exists: false, lines: 0, file: '.logs/trade.jsonl' })
  }
}
