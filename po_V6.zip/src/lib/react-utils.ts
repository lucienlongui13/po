/**
 * React key safety helpers.
 *
 * Why this exists:
 * - Pocket Option deal IDs can be UUID strings (e.g. "a1b2-...") OR numbers.
 * - The backend SDK used to call `Number(uuid)` which returns `NaN`.
 * - `String(NaN)` is `"NaN"`, so every position got `id="NaN"`.
 * - In React lists, `key={p.id ?? fallback}` does NOT trigger the fallback
 *   for `NaN` (because `??` only catches null/undefined), so React saw
 *   duplicate keys "NaN" and threw the warning:
 *   "Encountered two children with the same key, `NaN`".
 * - Later we discovered the backend was also producing composite keys
 *   like `"deal-NaN-ETHUSD_otc"` (openTime was NaN). safeKey now also
 *   detects the "NaN" SUBSTRING inside any string key and falls back.
 *
 * Use `safeKey(value, fallback)` for ANY .map() key that comes from
 * backend data (positions, deals, candles, assets, etc.) to guarantee
 * a unique, non-NaN, non-empty string key.
 */

/**
 * Returns true if a string key contains any "NaN"-like marker that would
 * make it non-unique (multiple deals with missing IDs all produce the
 * same "deal-NaN-..." composite key).
 */
function containsNaNMarker(s: string): boolean {
  return s.includes('NaN') || s.includes('null') || s.includes('undefined')
}

/**
 * Returns a safe React key string from any value.
 * Falls back to `fallback` when:
 *   - value is null/undefined
 *   - value is NaN/Infinity
 *   - value is empty string
 *   - value is a string containing "NaN" (composite key leak from backend)
 *
 * @example
 *   safeKey(p.id, `pos-${idx}`)            // UUID → UUID ; NaN → "pos-3"
 *   safeKey("deal-NaN-ETHUSD_otc", fb)     // → fb  (NaN substring detected)
 *   safeKey(candle.time, `c-${idx}`)       // 1234567890 → "1234567890"
 */
export function safeKey(value: unknown, fallback: string): string {
  if (value === null || value === undefined) return fallback
  if (typeof value === 'number') {
    if (Number.isNaN(value) || !Number.isFinite(value)) return fallback
    return String(value)
  }
  if (typeof value === 'string') {
    if (value.length === 0) return fallback
    if (containsNaNMarker(value)) return fallback
    return value
  }
  // For objects/arrays/etc., stringify defensively
  try {
    const s = String(value)
    if (s.length === 0 || containsNaNMarker(s)) return fallback
    return s
  } catch {
    return fallback
  }
}

/**
 * Returns true if the value would make a valid React key
 * (non-empty string, not NaN-like, does not contain "NaN" substring).
 */
export function isValidKey(value: unknown): boolean {
  if (value === null || value === undefined) return false
  if (typeof value === 'number') return Number.isFinite(value)
  if (typeof value === 'string') {
    return value.length > 0 && !containsNaNMarker(value)
  }
  return false
}

