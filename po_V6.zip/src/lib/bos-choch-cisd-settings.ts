/**
 * bos-choch-cisd-settings.ts — Réglages persistés de la stratégie
 * « L_Lucien ProTrader » (Auto Trade).
 * ====================================================================
 * Les MÊMES paramètres que le pack Pine (groupes « Labels » et
 * « Alerts ») : 6 couleurs de labels + couleur du texte + taille des
 * labels + 6 toggles d'événements. Persistance localStorage + API de
 * souscription — l'overlay graphique, l'adaptateur Strategy Tester et
 * le panneau Auto Trade partagent le même état.
 *
 * Côté backend (ordres réels), les 6 toggles voyagent en plus par la
 * config socket (clés bosChochCisd*) — voir use-pocket-option.ts.
 *
 * AFFICHAGE GRAPHIQUE : `showLabels` (défaut FALSE — masqué à
 * l'initialisation) contrôle la visibilité des tags et libellés de la
 * stratégie sur le graphique (switch du panneau Auto Trade). Les lignes
 * d'événements et de tendance restent indépendantes de ce réglage.
 */

import {
  BOS_CHOCH_CISD_DEFAULT_SETTINGS,
  DEFAULT_BOS_CHOCH_CISD_ORDER_RULES,
  normalizeCisdGuardConfig,
  type BosChochCisdSettings,
} from '../../shared/bos-choch-cisd'

const LS_KEY = 'bos-choch-cisd-settings-v3'
const LS_DISPLAY_KEY = 'l-lucien-protrader-display-v1'

/** Réglages d'affichage graphique de la stratégie (tags et libellés). */
export interface LucienProTraderDisplaySettings {
  /** Afficher les tags et libellés sur le graphique — DÉFAUT : false. */
  showLabels: boolean
}

export const DEFAULT_LUCIEN_PROTRADER_DISPLAY: LucienProTraderDisplaySettings = {
  showLabels: false,
}

type Listener = (settings: BosChochCisdSettings) => void
type DisplayListener = (settings: LucienProTraderDisplaySettings) => void
const listeners = new Set<Listener>()
const displayListeners = new Set<DisplayListener>()

function isBrowser(): boolean {
  return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined'
}

/** Réglages actuels (defaults du pack si rien de persisté). */
export function loadBosChochCisdSettings(): BosChochCisdSettings {
  if (!isBrowser()) return { ...BOS_CHOCH_CISD_DEFAULT_SETTINGS }
  try {
    const raw = window.localStorage.getItem(LS_KEY)
    if (!raw) return { ...BOS_CHOCH_CISD_DEFAULT_SETTINGS }
    const parsed = JSON.parse(raw) as Partial<BosChochCisdSettings>
    // v26 — MIGRATION §31/§32 : les règles Ninja absentes d'un ancien
    // localStorage sont initialisées comme COPIE des règles partagées
    // (comportement historique : les deux stratégies partageaient les
    // mêmes combinaisons) — l'utilisateur peut ensuite les diverger.
    const callRules = parsed.callRules ?? DEFAULT_BOS_CHOCH_CISD_ORDER_RULES.callRules
    const putRules = parsed.putRules ?? DEFAULT_BOS_CHOCH_CISD_ORDER_RULES.putRules
    const ninjaCallRules = Array.isArray(parsed.ninjaCallRules) ? parsed.ninjaCallRules : callRules.map((r) => ({ ...r, alerts: [...r.alerts] }))
    const ninjaPutRules = Array.isArray(parsed.ninjaPutRules) ? parsed.ninjaPutRules : putRules.map((r) => ({ ...r, alerts: [...r.alerts] }))
    return {
      ...BOS_CHOCH_CISD_DEFAULT_SETTINGS,
      ...parsed,
      callRules,
      putRules,
      ninjaCallRules,
      ninjaPutRules,
      // v24 — cases « Vérification CISD » : fusion profonde (les champs
      // absents d'un ancien localStorage retombent sur le défaut v23).
      cisdGuard: normalizeCisdGuardConfig(parsed.cisdGuard),
    }
  } catch {
    return { ...BOS_CHOCH_CISD_DEFAULT_SETTINGS }
  }
}

/** Persiste les réglages et notifie les souscripteurs (overlay, adaptateur). */
export function saveBosChochCisdSettings(patch: Partial<BosChochCisdSettings>): BosChochCisdSettings {
  const current = loadBosChochCisdSettings()
  const next = {
    ...current,
    ...patch,
    callRules: patch.callRules ?? current.callRules,
    putRules: patch.putRules ?? current.putRules,
    cisdGuard: patch.cisdGuard ?? current.cisdGuard,
  }
  if (isBrowser()) {
    try { window.localStorage.setItem(LS_KEY, JSON.stringify(next)) } catch { /* quota/private */ }
  }
  for (const l of listeners) l(next)
  return next
}

/** Réinitialise les réglages du pack (couleurs/taille par défaut + toggles ON). */
export function resetBosChochCisdSettings(): BosChochCisdSettings {
  const next = { ...BOS_CHOCH_CISD_DEFAULT_SETTINGS }
  if (isBrowser()) {
    try { window.localStorage.setItem(LS_KEY, JSON.stringify(next)) } catch { /* noop */ }
  }
  for (const l of listeners) l(next)
  return next
}

/** Souscrit aux changements (retourne la fonction de désabonnement). */
export function subscribeBosChochCisdSettings(listener: Listener): () => void {
  listeners.add(listener)
  return () => { listeners.delete(listener) }
}

/* ── Affichage graphique (tags et libellés) — défaut masqué ── */

/** Réglages d'affichage actuels (défaut : tags et libellés MASQUÉS). */
export function loadLucienProTraderDisplay(): LucienProTraderDisplaySettings {
  if (!isBrowser()) return { ...DEFAULT_LUCIEN_PROTRADER_DISPLAY }
  try {
    const raw = window.localStorage.getItem(LS_DISPLAY_KEY)
    if (!raw) return { ...DEFAULT_LUCIEN_PROTRADER_DISPLAY }
    const parsed = JSON.parse(raw) as Partial<LucienProTraderDisplaySettings>
    return { ...DEFAULT_LUCIEN_PROTRADER_DISPLAY, ...parsed }
  } catch {
    return { ...DEFAULT_LUCIEN_PROTRADER_DISPLAY }
  }
}

/** Persiste les réglages d'affichage et notifie les souscripteurs (overlay, panneau). */
export function saveLucienProTraderDisplay(patch: Partial<LucienProTraderDisplaySettings>): LucienProTraderDisplaySettings {
  const next = { ...loadLucienProTraderDisplay(), ...patch }
  if (isBrowser()) {
    try { window.localStorage.setItem(LS_DISPLAY_KEY, JSON.stringify(next)) } catch { /* quota/private */ }
  }
  for (const l of displayListeners) l(next)
  return next
}

/** Souscrit aux changements d'affichage (retourne la fonction de désabonnement). */
export function subscribeLucienProTraderDisplay(listener: DisplayListener): () => void {
  displayListeners.add(listener)
  return () => { displayListeners.delete(listener) }
}
