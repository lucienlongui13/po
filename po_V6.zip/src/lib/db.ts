import path from 'node:path'
import fs from 'node:fs'
import { PrismaClient } from '@prisma/client'

// ── FIX (audit v6.5) ────────────────────────────────────────────────────────
// Avant : DATABASE_URL="file:db/custom.db" était résolu par le moteur Prisma
// relativement à l'emplacement du client généré (node_modules/.prisma/client),
// ce qui provoquait « Error code 14: Unable to open the database file » dès
// que le projet était déplacé / exécuté hors de son répertoire d'origine.
// Maintenant : on absolutise le chemin SQLite par rapport à la racine du
// projet AVANT la première instanciation du client → portable sur toute
// machine, quel que soit le CWD du process.
function absolutizeSqliteUrl(): void {
  const raw = process.env.DATABASE_URL
  if (!raw?.startsWith('file:')) return
  const rel = raw.slice('file:'.length)
  if (path.isAbsolute(rel)) return
  const root = process.cwd()
  const abs = path.resolve(root, rel)
  if (fs.existsSync(path.dirname(abs))) {
    process.env.DATABASE_URL = `file:${abs}`
  }
}

absolutizeSqliteUrl()

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const db =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ['query'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
