/**
 * pine-time-axis.ts — CANONICAL TEMPORAL IDENTITY LAYER (v1.9).
 *
 * SINGLE SOURCE OF TRUTH for every seconds/milliseconds conversion, every
 * Pine→chart time mapping and every timeline validation in the project.
 *
 * ── WHY THIS MODULE EXISTS ─────────────────────────────────────────────────
 * The v1.8 "indicators drift away from candles" bug had several root causes,
 * but they all shared one symptom enabler: temporal logic was re-implemented
 * ad-hoc in six different files (`* 1000` here, `Math.round(x / 1000)` there,
 * positional tail-align fallbacks elsewhere). Two components could therefore
 * disagree about which candle a Pine value belongs to.
 *
 * ── THE RULE (absolute, project-wide) ──────────────────────────────────────
 * A candle's identity is its TIMESTAMP, never its array index.
 *
 *   timeSec = canonical timestamp used by Lightweight Charts (host candles)
 *   timeMs  = timestamp used by the Pine/Piner runtime (epoch milliseconds)
 *
 * One conversion in each direction — and ONLY here:
 *   toPineTime(timeSec)   => timeSec * 1000
 *   toChartTime(timeMs)   => Math.round(timeMs / 1000)
 *
 * ── WHAT LIVES HERE ────────────────────────────────────────────────────────
 *   - BarIdentity type + builders
 *   - pineTimeToChartTime / chartTimeToPineTime conversions
 *   - buildTimeIndex / findCandleByPineTime (timestamp lookup)
 *   - alignPineSeries (timestamp-keyed series alignment — the ONLY renderer
 *     path; never index-based, never tail-based)
 *   - validatePineTimeline (monotonicity, duplicates, length coherence,
 *     sec/ms unit sanity) → used to REFUSE drawing a misaligned result
 *   - diagnosePineAlignment (dev-only [PINE ALIGNMENT] heuristics:
 *     PINE_RESULT_STALE / PINE_MARKER_DESYNC / PINE_TIMELINE_LENGTH_MISMATCH)
 */

import type { CandleLike } from './indicators'
import type { PineExecutionResult } from './pine-engine'

// ══════════════════════════════════════════════ identity & conversions

/** The canonical identity of a bar: one timestamp, one bar — forever. */
export interface BarIdentity {
  /** Canonical chart timestamp (Lightweight Charts, epoch SECONDS). */
  timeSec: number
  /** Pine runtime timestamp (epoch MILLISECONDS). Same bar, Pine unit. */
  timeMs: number
}

export function barIdentityOf(candle: CandleLike): BarIdentity {
  const timeSec = Number(candle.time)
  return { timeSec, timeMs: timeSec * 1000 }
}

/** host seconds → Pine milliseconds (the ONLY sec→ms conversion). */
export function toPineTime(timeSec: number): number {
  return timeSec * 1000
}

/** Pine milliseconds → chart seconds (the ONLY ms→sec conversion). */
export function toChartTime(timeMs: number): number {
  return Math.round(timeMs / 1000)
}

/** Canonical renderer-facing alias (spec §27: every component uses THIS). */
export const pineTimeToChartTime = toChartTime

// ══════════════════════════════════════════════ timestamp lookup

/** Map<timeSec, CandleLike> — build once per render pass, lookup by timestamp. */
export function buildTimeIndex(candles: readonly CandleLike[]): Map<number, CandleLike> {
  const index = new Map<number, CandleLike>()
  for (const c of candles) index.set(Number(c.time), c)
  return index
}

/** Map<timeSec, arrayIndex> — for components that need the index after lookup. */
export function buildTimeToIndexMap(candles: readonly CandleLike[]): Map<number, number> {
  const index = new Map<number, number>()
  for (let i = 0; i < candles.length; i++) index.set(Number(candles[i].time), i)
  return index
}

/** Resolve a Pine timestamp (ms) to the host candle with that exact timestamp. */
export function findCandleByPineTime(
  timeMs: number,
  index: Map<number, CandleLike>,
): CandleLike | undefined {
  return index.get(pineTimeToChartTime(timeMs))
}

// ══════════════════════════════════════════════ series alignment

export interface AlignedPoint<T> {
  candle: CandleLike
  value: T
}

export type AlignIssueCode =
  | 'PINE_TIMELINE_MISSING'
  | 'PINE_TIMELINE_LENGTH_MISMATCH'
  | 'PINE_TIMELINE_NOT_MONOTONIC'
  | 'PINE_TIMELINE_DUPLICATE'
  | 'PINE_TIMELINE_UNIT_SUSPECT'

export interface AlignDiagnostic {
  code: AlignIssueCode
  detail: string
}

/**
 * Timestamp-keyed alignment of a Pine per-bar array against the host candles.
 *
 * This is the ONLY way a Pine output may be positioned (spec: "AUCUN output
 * Pine ne doit être positionné par index de tableau lorsque l'information
 * temporelle est disponible"). Points whose timestamp has no matching candle
 * are dropped; a missing/mismatched timeline returns no points plus an
 * explicit diagnostic instead of silently falling back to positional math.
 */
export function alignPineSeries<T>(
  values: readonly T[],
  pineTimesMs: readonly number[] | undefined,
  candles: readonly CandleLike[],
): { points: AlignedPoint<T>[]; issues: AlignDiagnostic[] } {
  const issues: AlignDiagnostic[] = []
  if (!pineTimesMs || pineTimesMs.length === 0) {
    issues.push({
      code: 'PINE_TIMELINE_MISSING',
      detail: `Pine timeline unavailable (${values.length} values) — refusing positional fallback`,
    })
    return { points: [], issues }
  }
  if (pineTimesMs.length !== values.length) {
    issues.push({
      code: 'PINE_TIMELINE_LENGTH_MISMATCH',
      detail: `timeline length ${pineTimesMs.length} !== data length ${values.length} — refusing positional fallback`,
    })
    return { points: [], issues }
  }

  const index = buildTimeIndex(candles)
  const points: AlignedPoint<T>[] = []
  for (let i = 0; i < values.length; i++) {
    const candle = index.get(pineTimeToChartTime(pineTimesMs[i]))
    if (candle) points.push({ candle, value: values[i] })
  }
  return { points, issues }
}

// ══════════════════════════════════════════════ timeline validation

export interface TimelineValidation {
  ok: boolean
  issues: AlignDiagnostic[]
}

/**
 * Validate a Pine execution timeline before its result may be drawn:
 *  - strictly increasing timestamps (chart requires it)
 *  - no duplicates
 *  - sec/ms unit sanity (Piner emits ms; a ms timeline below ~1e9 is suspect,
 *    a sec timeline above ~1e12 is suspect)
 *  - when `expectedBarCount` is provided: coherence with the snapshot
 */
export function validatePineTimeline(
  times: readonly number[] | undefined,
  expectedBarCount?: number,
): TimelineValidation {
  const issues: AlignDiagnostic[] = []
  if (!times || times.length === 0) {
    issues.push({ code: 'PINE_TIMELINE_MISSING', detail: 'empty or missing _times array' })
    return { ok: false, issues }
  }
  const first = times[0]
  // Plausible epoch-ms for market data: [1e12 (2001-09), 1e14 (year 5138)].
  // Anything below 1e12 is either a seconds-unit timeline or garbage — both
  // are alignment hazards and get flagged.
  if (!(first >= 1e12 && first < 1e14)) {
    issues.push({
      code: 'PINE_TIMELINE_UNIT_SUSPECT',
      detail: `first timestamp ${first} is neither a plausible epoch-ms nor epoch-sec value`,
    })
  }
  let prev = -Infinity
  for (let i = 0; i < times.length; i++) {
    const t = times[i]
    if (!(t > prev)) {
      issues.push({
        code: t === prev ? 'PINE_TIMELINE_DUPLICATE' : 'PINE_TIMELINE_NOT_MONOTONIC',
        detail: `timestamps not strictly increasing at index ${i} (${prev} → ${t})`,
      })
      break
    }
    prev = t
  }
  if (expectedBarCount != null && Math.abs(times.length - expectedBarCount) > 0) {
    issues.push({
      code: 'PINE_TIMELINE_LENGTH_MISMATCH',
      detail: `timeline has ${times.length} bars, dataset has ${expectedBarCount}`,
    })
  }
  return { ok: issues.length === 0, issues }
}

// ══════════════════════════════════════════════ dev-only diagnostics

export interface AlignmentProbeInput {
  scriptId: string
  scriptName?: string
  /** Pine result timeline (ms). */
  resultTimes: readonly number[] | undefined
  /** Current host dataset (sec). */
  candles: readonly CandleLike[]
  /** Current dataset revision (pine-store). */
  datasetRevision: number
  /** Revision the result was produced from (envelope). */
  resultRevision?: number
}

export interface AlignmentProbeReport {
  scriptId: string
  codes: string[]
  details: string[]
  lastCandleTimeSec: number | null
  resultLastTimeSec: number | null
}

/**
 * Heuristic alignment probe (spec §17). Dev-only: logs [PINE ALIGNMENT]
 * explicitly instead of letting a shifted layer render silently.
 *
 *   PINE_RESULT_STALE            result's last timestamp lags the newest candle
 *                                by ≥ 1 timeframe (stale execution displayed)
 *   PINE_MARKER_DESYNC           (checked by callers with marker arrays)
 *   PINE_TIMELINE_LENGTH_MISMATCH data/timeline length disagreement
 */
export function diagnosePineAlignment(input: AlignmentProbeInput): AlignmentProbeReport {
  const codes: string[] = []
  const details: string[] = []
  const n = input.candles.length
  const lastCandleTimeSec = n > 0 ? Number(input.candles[n - 1].time) : null
  const resultLastTimeSec = input.resultTimes?.length
    ? pineTimeToChartTime(input.resultTimes[input.resultTimes.length - 1])
    : null

  const tfSec = n > 1
    ? (Number(input.candles[n - 1].time) - Number(input.candles[0].time)) / (n - 1)
    : null

  if (lastCandleTimeSec != null && resultLastTimeSec != null && tfSec && tfSec > 0) {
    if (lastCandleTimeSec - resultLastTimeSec >= tfSec) {
      codes.push('PINE_RESULT_STALE')
      details.push(
        `result last bar ${resultLastTimeSec} is ${Math.round((lastCandleTimeSec - resultLastTimeSec) / tfSec)} bar(s) behind the chart's last bar ${lastCandleTimeSec}`,
      )
    }
  }
  if (input.resultRevision != null && input.resultRevision < input.datasetRevision) {
    // older-than-current revision is expected mid-execution; only report when
    // it is ALSO temporally stale, which the check above covers. Keep the info.
    details.push(`result revision ${input.resultRevision} < dataset revision ${input.datasetRevision}`)
  }
  return { scriptId: input.scriptId, codes, details, lastCandleTimeSec, resultLastTimeSec }
}

/** Emit a dev-only [PINE ALIGNMENT] diagnostic block. */
export function logPineAlignmentDiagnostics(reports: AlignmentProbeReport[]): void {
  if (typeof process !== 'undefined' && process.env?.NODE_ENV === 'production') return
  for (const r of reports) {
    if (!r.codes.length && !r.details.length) continue
    const tag = r.codes.length ? r.codes.join('+') : 'INFO'
    console.warn(`[PINE ALIGNMENT] ${tag} · ${r.scriptId}`, r.details.join(' · '))
  }
}
