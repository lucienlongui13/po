/**
 * markets-catalog.ts — Catalogue complet des actifs Pocket Option (frontend).
 * ======================================================================
 *
 * Source de vérité UNIQUE côté frontend : 183 actifs extraits du fichier
 * Assets.har (capture WebSocket réelle, event `updateAssets`), miroir exact
 * du MARKETS_CATALOG du backend (mini-services/iqoption-backend/markets-catalog.ts).
 *
 * Utilisé par : page.tsx (watchlist), watchlist (sélection
 * single/multi — §2 du cahier des charges : le catalogue DÉJÀ PRÉSENT dans
 * le projet, jamais une liste parallèle).
 */

export interface MarketInfo {
  name: string
  active_id: number
  long_name: string
  tv_symbol: string
  tv_exchange: string
  trading_hours: string
  always_on: boolean
  /** Payout en pourcentage (snapshot HAR — remplacé par la valeur live). */
  payout?: number
  /** Type d'actif Pocket Option (currency | stock | index | cryptocurrency | commodity). */
  type?: string
}

/** Catégorie d'affichage de la sélection d'assets (§2). */
export type AssetCategory = 'FOREX' | 'COMMODITIES' | 'CRYPTO' | 'STOCKS' | 'INDEX'

export const MARKETS_CATALOG: MarketInfo[] = [
  { name: 'AEDCNY_otc', active_id: 538, long_name: 'AED/CNY OTC', tv_symbol: 'FX:AEDCNY', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 92, type: 'currency' },
  { name: 'AUDCAD_otc', active_id: 67, long_name: 'AUD/CAD OTC', tv_symbol: 'FX:AUDCAD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 87, type: 'currency' },
  { name: 'AUDCHF_otc', active_id: 68, long_name: 'AUD/CHF OTC', tv_symbol: 'FX:AUDCHF', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 70, type: 'currency' },
  { name: 'AUDJPY_otc', active_id: 69, long_name: 'AUD/JPY OTC', tv_symbol: 'FX:AUDJPY', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 82, type: 'currency' },
  { name: 'AUDNZD_otc', active_id: 70, long_name: 'AUD/NZD OTC', tv_symbol: 'FX:AUDNZD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 56, type: 'currency' },
  { name: 'AUDUSD_otc', active_id: 71, long_name: 'AUD/USD OTC', tv_symbol: 'FX:AUDUSD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 87, type: 'currency' },
  { name: 'BHDCNY_otc', active_id: 536, long_name: 'BHD/CNY OTC', tv_symbol: 'FX:BHDCNY', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 32, type: 'currency' },
  { name: 'CADCHF_otc', active_id: 72, long_name: 'CAD/CHF OTC', tv_symbol: 'FX:CADCHF', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 35, type: 'currency' },
  { name: 'CADJPY_otc', active_id: 73, long_name: 'CAD/JPY OTC', tv_symbol: 'FX:CADJPY', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 66, type: 'currency' },
  { name: 'CHFJPY_otc', active_id: 74, long_name: 'CHF/JPY OTC', tv_symbol: 'FX:CHFJPY', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 92, type: 'currency' },
  { name: 'CHFNOK_otc', active_id: 457, long_name: 'CHF/NOK OTC', tv_symbol: 'FX:CHFNOK', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 70, type: 'currency' },
  { name: 'EURCHF_otc', active_id: 77, long_name: 'EUR/CHF OTC', tv_symbol: 'FX:EURCHF', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 90, type: 'currency' },
  { name: 'EURGBP_otc', active_id: 78, long_name: 'EUR/GBP OTC', tv_symbol: 'FX:EURGBP', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 81, type: 'currency' },
  { name: 'EURHUF_otc', active_id: 460, long_name: 'EUR/HUF OTC', tv_symbol: 'FX:EURHUF', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 89, type: 'currency' },
  { name: 'EURJPY_otc', active_id: 79, long_name: 'EUR/JPY OTC', tv_symbol: 'FX:EURJPY', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 92, type: 'currency' },
  { name: 'EURNZD_otc', active_id: 80, long_name: 'EUR/NZD OTC', tv_symbol: 'FX:EURNZD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 34, type: 'currency' },
  { name: 'EURRUB_otc', active_id: 200, long_name: 'EUR/RUB OTC', tv_symbol: 'FX:EURRUB', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 87, type: 'currency' },
  { name: 'EURTRY_otc', active_id: 468, long_name: 'EUR/TRY OTC', tv_symbol: 'FX:EURTRY', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 53, type: 'currency' },
  { name: 'EURUSD_otc', active_id: 66, long_name: 'EUR/USD OTC', tv_symbol: 'FX:EURUSD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 92, type: 'currency' },
  { name: 'GBPAUD_otc', active_id: 81, long_name: 'GBP/AUD OTC', tv_symbol: 'FX:GBPAUD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 26, type: 'currency' },
  { name: 'GBPJPY_otc', active_id: 84, long_name: 'GBP/JPY OTC', tv_symbol: 'FX:GBPJPY', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 85, type: 'currency' },
  { name: 'GBPUSD_otc', active_id: 86, long_name: 'GBP/USD OTC', tv_symbol: 'FX:GBPUSD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 75, type: 'currency' },
  { name: 'IRRUSD_otc', active_id: 548, long_name: 'IRR/USD OTC', tv_symbol: 'FX:IRRUSD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 77, type: 'currency' },
  { name: 'JODCNY_otc', active_id: 546, long_name: 'JOD/CNY OTC', tv_symbol: 'FX:JODCNY', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 59, type: 'currency' },
  { name: 'KESUSD_otc', active_id: 554, long_name: 'KES/USD OTC', tv_symbol: 'FX:KESUSD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 39, type: 'currency' },
  { name: 'LBPUSD_otc', active_id: 530, long_name: 'LBP/USD OTC', tv_symbol: 'FX:LBPUSD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 48, type: 'currency' },
  { name: 'MADUSD_otc', active_id: 534, long_name: 'MAD/USD OTC', tv_symbol: 'FX:MADUSD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 92, type: 'currency' },
  { name: 'NGNUSD_otc', active_id: 552, long_name: 'NGN/USD OTC', tv_symbol: 'FX:NGNUSD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 63, type: 'currency' },
  { name: 'NZDJPY_otc', active_id: 89, long_name: 'NZD/JPY OTC', tv_symbol: 'FX:NZDJPY', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 64, type: 'currency' },
  { name: 'NZDUSD_otc', active_id: 90, long_name: 'NZD/USD OTC', tv_symbol: 'FX:NZDUSD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 40, type: 'currency' },
  { name: 'OMRCNY_otc', active_id: 544, long_name: 'OMR/CNY OTC', tv_symbol: 'FX:OMRCNY', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 30, type: 'currency' },
  { name: 'QARCNY_otc', active_id: 542, long_name: 'QAR/CNY OTC', tv_symbol: 'FX:QARCNY', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 92, type: 'currency' },
  { name: 'SARCNY_otc', active_id: 540, long_name: 'SAR/CNY OTC', tv_symbol: 'FX:SARCNY', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 51, type: 'currency' },
  { name: 'SYPUSD_otc', active_id: 550, long_name: 'SYP/USD OTC', tv_symbol: 'FX:SYPUSD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 52, type: 'currency' },
  { name: 'TNDUSD_otc', active_id: 532, long_name: 'TND/USD OTC', tv_symbol: 'FX:TNDUSD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 77, type: 'currency' },
  { name: 'UAHUSD_otc', active_id: 558, long_name: 'UAH/USD OTC', tv_symbol: 'FX:UAHUSD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 50, type: 'currency' },
  { name: 'USDARS_otc', active_id: 506, long_name: 'USD/ARS OTC', tv_symbol: 'FX:USDARS', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 49, type: 'currency' },
  { name: 'USDBDT_otc', active_id: 500, long_name: 'USD/BDT OTC', tv_symbol: 'FX:USDBDT', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 73, type: 'currency' },
  { name: 'USDBRL_otc', active_id: 502, long_name: 'USD/BRL OTC', tv_symbol: 'FX:USDBRL', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 27, type: 'currency' },
  { name: 'USDCAD_otc', active_id: 91, long_name: 'USD/CAD OTC', tv_symbol: 'FX:USDCAD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 62, type: 'currency' },
  { name: 'USDCHF_otc', active_id: 92, long_name: 'USD/CHF OTC', tv_symbol: 'FX:USDCHF', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 92, type: 'currency' },
  { name: 'USDCLP_otc', active_id: 525, long_name: 'USD/CLP OTC', tv_symbol: 'FX:USDCLP', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 80, type: 'currency' },
  { name: 'USDCNH_otc', active_id: 467, long_name: 'USD/CNH OTC', tv_symbol: 'FX:USDCNH', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 56, type: 'currency' },
  { name: 'USDCOP_otc', active_id: 515, long_name: 'USD/COP OTC', tv_symbol: 'FX:USDCOP', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 42, type: 'currency' },
  { name: 'USDDZD_otc', active_id: 508, long_name: 'USD/DZD OTC', tv_symbol: 'FX:USDDZD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 56, type: 'currency' },
  { name: 'USDEGP_otc', active_id: 513, long_name: 'USD/EGP OTC', tv_symbol: 'FX:USDEGP', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 86, type: 'currency' },
  { name: 'USDIDR_otc', active_id: 504, long_name: 'USD/IDR OTC', tv_symbol: 'FX:USDIDR', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 73, type: 'currency' },
  { name: 'USDINR_otc', active_id: 202, long_name: 'USD/INR OTC', tv_symbol: 'FX:USDINR', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 92, type: 'currency' },
  { name: 'USDJPY_otc', active_id: 93, long_name: 'USD/JPY OTC', tv_symbol: 'FX:USDJPY', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 86, type: 'currency' },
  { name: 'USDMXN_otc', active_id: 509, long_name: 'USD/MXN OTC', tv_symbol: 'FX:USDMXN', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 20, type: 'currency' },
  { name: 'USDMYR_otc', active_id: 523, long_name: 'USD/MYR OTC', tv_symbol: 'FX:USDMYR', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 60, type: 'currency' },
  { name: 'USDPHP_otc', active_id: 511, long_name: 'USD/PHP OTC', tv_symbol: 'FX:USDPHP', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 61, type: 'currency' },
  { name: 'USDPKR_otc', active_id: 517, long_name: 'USD/PKR OTC', tv_symbol: 'FX:USDPKR', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 36, type: 'currency' },
  { name: 'USDRUB_otc', active_id: 199, long_name: 'USD/RUB OTC', tv_symbol: 'FX:USDRUB', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 29, type: 'currency' },
  { name: 'USDSGD_otc', active_id: 526, long_name: 'USD/SGD OTC', tv_symbol: 'FX:USDSGD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 76, type: 'currency' },
  { name: 'USDTHB_otc', active_id: 521, long_name: 'USD/THB OTC', tv_symbol: 'FX:USDTHB', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 65, type: 'currency' },
  { name: 'USDVND_otc', active_id: 519, long_name: 'USD/VND OTC', tv_symbol: 'FX:USDVND', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 92, type: 'currency' },
  { name: 'YERUSD_otc', active_id: 528, long_name: 'YER/USD OTC', tv_symbol: 'FX:YERUSD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 54, type: 'currency' },
  { name: 'ZARUSD_otc', active_id: 556, long_name: 'ZAR/USD OTC', tv_symbol: 'FX:ZARUSD', tv_exchange: 'FX', trading_hours: '24/7', always_on: true, payout: 33, type: 'currency' },
  { name: 'ADA-USD_otc', active_id: 473, long_name: 'Cardano OTC', tv_symbol: 'COINBASE:ADA-USD', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 49, type: 'cryptocurrency' },
  { name: 'AVAX_otc', active_id: 481, long_name: 'Avalanche OTC', tv_symbol: 'COINBASE:AVAX', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 88, type: 'cryptocurrency' },
  { name: 'BITB_otc', active_id: 494, long_name: 'Bitcoin ETF OTC', tv_symbol: 'COINBASE:BITB', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 60, type: 'cryptocurrency' },
  { name: 'BNB-USD_otc', active_id: 470, long_name: 'BNB OTC', tv_symbol: 'COINBASE:BNB-USD', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 78, type: 'cryptocurrency' },
  { name: 'BTCUSD_otc', active_id: 484, long_name: 'Bitcoin OTC', tv_symbol: 'COINBASE:BTCUSD', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 64, type: 'cryptocurrency' },
  { name: 'DOGE_otc', active_id: 485, long_name: 'Dogecoin OTC', tv_symbol: 'COINBASE:DOGE', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 75, type: 'cryptocurrency' },
  { name: 'DOTUSD_otc', active_id: 486, long_name: 'Polkadot OTC', tv_symbol: 'COINBASE:DOTUSD', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 64, type: 'cryptocurrency' },
  { name: 'ETHUSD_otc', active_id: 487, long_name: 'Ethereum OTC', tv_symbol: 'COINBASE:ETHUSD', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 70, type: 'cryptocurrency' },
  { name: 'LINK_otc', active_id: 478, long_name: 'Chainlink OTC', tv_symbol: 'COINBASE:LINK', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 62, type: 'cryptocurrency' },
  { name: 'LTCUSD_otc', active_id: 488, long_name: 'Litecoin OTC', tv_symbol: 'COINBASE:LTCUSD', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 35, type: 'cryptocurrency' },
  { name: 'MATIC_otc', active_id: 491, long_name: 'Polygon OTC', tv_symbol: 'COINBASE:MATIC', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 92, type: 'cryptocurrency' },
  { name: 'SOL-USD_otc', active_id: 472, long_name: 'Solana OTC', tv_symbol: 'COINBASE:SOL-USD', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 79, type: 'cryptocurrency' },
  { name: 'TON-USD_otc', active_id: 480, long_name: 'Toncoin OTC', tv_symbol: 'COINBASE:TON-USD', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 58, type: 'cryptocurrency' },
  { name: 'TRX-USD_otc', active_id: 476, long_name: 'TRON OTC', tv_symbol: 'COINBASE:TRX-USD', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 78, type: 'cryptocurrency' },
  { name: 'UKBrent_otc', active_id: 164, long_name: 'Brent Oil OTC', tv_symbol: 'TVC:UKOIL', tv_exchange: 'TVC', trading_hours: '24/7', always_on: true, payout: 80, type: 'commodity' },
  { name: 'USCrude_otc', active_id: 165, long_name: 'WTI Crude Oil OTC', tv_symbol: 'TVC:USOIL', tv_exchange: 'TVC', trading_hours: '24/7', always_on: true, payout: 80, type: 'commodity' },
  { name: 'XAGUSD_otc', active_id: 167, long_name: 'Silver OTC', tv_symbol: 'OANDA:XAGUSD', tv_exchange: 'OANDA', trading_hours: '24/7', always_on: true, payout: 80, type: 'commodity' },
  { name: 'XAUUSD_otc', active_id: 169, long_name: 'Gold OTC', tv_symbol: 'OANDA:XAUUSD', tv_exchange: 'OANDA', trading_hours: '24/7', always_on: true, payout: 80, type: 'commodity' },
  { name: 'XNGUSD_otc', active_id: 399, long_name: 'Natural Gas OTC', tv_symbol: 'TVC:XNGUSD', tv_exchange: 'TVC', trading_hours: '24/7', always_on: true, payout: 45, type: 'commodity' },
  { name: 'XPDUSD_otc', active_id: 401, long_name: 'Palladium spot OTC', tv_symbol: 'OANDA:XPDUSD', tv_exchange: 'OANDA', trading_hours: '24/7', always_on: true, payout: 45, type: 'commodity' },
  { name: 'XPTUSD_otc', active_id: 400, long_name: 'Platinum spot OTC', tv_symbol: 'OANDA:XPTUSD', tv_exchange: 'OANDA', trading_hours: '24/7', always_on: true, payout: 45, type: 'commodity' },
  { name: '#AAPL_otc', active_id: 170, long_name: 'Apple OTC', tv_symbol: 'NASDAQ:AAPL', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 75, type: 'stock' },
  { name: '#AXP_otc', active_id: 291, long_name: 'American Express OTC', tv_symbol: 'NASDAQ:AXP', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 67, type: 'stock' },
  { name: '#BA_otc', active_id: 292, long_name: 'Boeing Company OTC', tv_symbol: 'NASDAQ:BA', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 31, type: 'stock' },
  { name: '#CSCO_otc', active_id: 427, long_name: 'Cisco OTC', tv_symbol: 'NASDAQ:CSCO', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 69, type: 'stock' },
  { name: '#FB_otc', active_id: 187, long_name: 'FACEBOOK INC OTC', tv_symbol: 'NASDAQ:FB', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 30, type: 'stock' },
  { name: '#INTC_otc', active_id: 190, long_name: 'Intel OTC', tv_symbol: 'NASDAQ:INTC', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 68, type: 'stock' },
  { name: '#JNJ_otc', active_id: 296, long_name: 'Johnson & Johnson OTC', tv_symbol: 'NASDAQ:JNJ', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 71, type: 'stock' },
  { name: '#MSFT_otc', active_id: 176, long_name: 'Microsoft OTC', tv_symbol: 'NASDAQ:MSFT', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 69, type: 'stock' },
  { name: '#PFE_otc', active_id: 297, long_name: 'Pfizer Inc OTC', tv_symbol: 'NASDAQ:PFE', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 54, type: 'stock' },
  { name: '#TSLA_otc', active_id: 196, long_name: 'Tesla OTC', tv_symbol: 'NASDAQ:TSLA', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 71, type: 'stock' },
  { name: '#XOM_otc', active_id: 426, long_name: 'ExxonMobil OTC', tv_symbol: 'NASDAQ:XOM', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 88, type: 'stock' },
  { name: 'AMD_otc', active_id: 568, long_name: 'Advanced Micro Devices OTC', tv_symbol: 'NASDAQ:AMD', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 92, type: 'stock' },
  { name: 'AMZN_otc', active_id: 412, long_name: 'Amazon OTC', tv_symbol: 'NASDAQ:AMZN', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 92, type: 'stock' },
  { name: 'BABA_otc', active_id: 428, long_name: 'Alibaba OTC', tv_symbol: 'NASDAQ:BABA', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 24, type: 'stock' },
  { name: 'CITI_otc', active_id: 413, long_name: 'Citigroup Inc OTC', tv_symbol: 'NASDAQ:CITI', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 77, type: 'stock' },
  { name: 'COIN_otc', active_id: 570, long_name: 'Coinbase Global OTC', tv_symbol: 'NASDAQ:COIN', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 56, type: 'stock' },
  { name: 'FDX_otc', active_id: 414, long_name: 'FedEx OTC', tv_symbol: 'NASDAQ:FDX', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 68, type: 'stock' },
  { name: 'GME_otc', active_id: 566, long_name: 'GameStop Corp OTC', tv_symbol: 'NASDAQ:GME', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 87, type: 'stock' },
  { name: 'MARA_otc', active_id: 572, long_name: 'Marathon Digital Holdings OTC', tv_symbol: 'NASDAQ:MARA', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 92, type: 'stock' },
  { name: 'NFLX_otc', active_id: 429, long_name: 'Netflix OTC', tv_symbol: 'NASDAQ:NFLX', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 68, type: 'stock' },
  { name: 'PLTR_otc', active_id: 562, long_name: 'Palantir Technologies OTC', tv_symbol: 'NASDAQ:PLTR', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 27, type: 'stock' },
  { name: 'VISA_otc', active_id: 416, long_name: 'VISA OTC', tv_symbol: 'NASDAQ:VISA', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 69, type: 'stock' },
  { name: 'VIX_otc', active_id: 560, long_name: 'VIX OTC', tv_symbol: 'NASDAQ:VIX', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 59, type: 'stock' },
  { name: '#MCD_otc', active_id: 175, long_name: "McDonald's OTC", tv_symbol: 'NASDAQ:MCD', tv_exchange: 'NASDAQ', trading_hours: '24/7', always_on: true, payout: 77, type: 'stock' },
  { name: '100GBP_otc', active_id: 403, long_name: '100GBP OTC', tv_symbol: 'TVC:100GBP', tv_exchange: 'TVC', trading_hours: '24/7', always_on: true, payout: 45, type: 'index' },
  { name: 'AUS200_otc', active_id: 306, long_name: 'AUS 200 OTC', tv_symbol: 'TVC:AUS200', tv_exchange: 'TVC', trading_hours: '24/7', always_on: true, payout: 67, type: 'index' },
  { name: 'D30EUR_otc', active_id: 406, long_name: 'D30EUR OTC', tv_symbol: 'TVC:D30EUR', tv_exchange: 'TVC', trading_hours: '24/7', always_on: true, payout: 45, type: 'index' },
  { name: 'DJI30_otc', active_id: 409, long_name: 'DJI30 OTC', tv_symbol: 'TVC:DJI30', tv_exchange: 'TVC', trading_hours: '24/7', always_on: true, payout: 45, type: 'index' },
  { name: 'E35EUR_otc', active_id: 402, long_name: 'E35EUR OTC', tv_symbol: 'TVC:E35EUR', tv_exchange: 'TVC', trading_hours: '24/7', always_on: true, payout: 45, type: 'index' },
  { name: 'E50EUR_otc', active_id: 407, long_name: 'E50EUR OTC', tv_symbol: 'TVC:E50EUR', tv_exchange: 'TVC', trading_hours: '24/7', always_on: true, payout: 45, type: 'index' },
  { name: 'F40EUR_otc', active_id: 404, long_name: 'F40EUR OTC', tv_symbol: 'TVC:F40EUR', tv_exchange: 'TVC', trading_hours: '24/7', always_on: true, payout: 45, type: 'index' },
  { name: 'JPN225_otc', active_id: 405, long_name: 'JPN225 OTC', tv_symbol: 'TVC:JPN225', tv_exchange: 'TVC', trading_hours: '24/7', always_on: true, payout: 45, type: 'index' },
  { name: 'NASUSD_otc', active_id: 410, long_name: 'US100 OTC', tv_symbol: 'TVC:NASUSD', tv_exchange: 'TVC', trading_hours: '24/7', always_on: true, payout: 45, type: 'index' },
  { name: 'SP500_otc', active_id: 408, long_name: 'SP500 OTC', tv_symbol: 'TVC:SP500', tv_exchange: 'TVC', trading_hours: '24/7', always_on: true, payout: 45, type: 'index' },
  { name: 'AUDCAD', active_id: 36, long_name: 'AUD/CAD', tv_symbol: 'FX:AUDCAD', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 41, type: 'currency' },
  { name: 'AUDCHF', active_id: 37, long_name: 'AUD/CHF', tv_symbol: 'FX:AUDCHF', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'currency' },
  { name: 'AUDJPY', active_id: 38, long_name: 'AUD/JPY', tv_symbol: 'FX:AUDJPY', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'currency' },
  { name: 'AUDUSD', active_id: 40, long_name: 'AUD/USD', tv_symbol: 'FX:AUDUSD', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'currency' },
  { name: 'CADCHF', active_id: 41, long_name: 'CAD/CHF', tv_symbol: 'FX:CADCHF', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 43, type: 'currency' },
  { name: 'CADJPY', active_id: 42, long_name: 'CAD/JPY', tv_symbol: 'FX:CADJPY', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'currency' },
  { name: 'CHFJPY', active_id: 43, long_name: 'CHF/JPY', tv_symbol: 'FX:CHFJPY', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'currency' },
  { name: 'EURAUD', active_id: 44, long_name: 'EUR/AUD', tv_symbol: 'FX:EURAUD', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'currency' },
  { name: 'EURCAD', active_id: 45, long_name: 'EUR/CAD', tv_symbol: 'FX:EURCAD', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 49, type: 'currency' },
  { name: 'EURCHF', active_id: 46, long_name: 'EUR/CHF', tv_symbol: 'FX:EURCHF', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 56, type: 'currency' },
  { name: 'EURGBP', active_id: 47, long_name: 'EUR/GBP', tv_symbol: 'FX:EURGBP', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'currency' },
  { name: 'EURJPY', active_id: 48, long_name: 'EUR/JPY', tv_symbol: 'FX:EURJPY', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 58, type: 'currency' },
  { name: 'EURUSD', active_id: 1, long_name: 'EUR/USD', tv_symbol: 'FX:EURUSD', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'currency' },
  { name: 'GBPAUD', active_id: 51, long_name: 'GBP/AUD', tv_symbol: 'FX:GBPAUD', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'currency' },
  { name: 'GBPCAD', active_id: 52, long_name: 'GBP/CAD', tv_symbol: 'FX:GBPCAD', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'currency' },
  { name: 'GBPCHF', active_id: 53, long_name: 'GBP/CHF', tv_symbol: 'FX:GBPCHF', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'currency' },
  { name: 'GBPJPY', active_id: 54, long_name: 'GBP/JPY', tv_symbol: 'FX:GBPJPY', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 58, type: 'currency' },
  { name: 'GBPUSD', active_id: 56, long_name: 'GBP/USD', tv_symbol: 'FX:GBPUSD', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'currency' },
  { name: 'USDCAD', active_id: 61, long_name: 'USD/CAD', tv_symbol: 'FX:USDCAD', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'currency' },
  { name: 'USDCHF', active_id: 62, long_name: 'USD/CHF', tv_symbol: 'FX:USDCHF', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'currency' },
  { name: 'USDJPY', active_id: 63, long_name: 'USD/JPY', tv_symbol: 'FX:USDJPY', tv_exchange: 'FX', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'currency' },
  { name: 'BCHEUR', active_id: 450, long_name: 'BCH/EUR', tv_symbol: 'COINBASE:BCHEUR', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 15, type: 'cryptocurrency' },
  { name: 'BCHGBP', active_id: 451, long_name: 'BCH/GBP', tv_symbol: 'COINBASE:BCHGBP', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 15, type: 'cryptocurrency' },
  { name: 'BCHJPY', active_id: 452, long_name: 'BCH/JPY', tv_symbol: 'COINBASE:BCHJPY', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 15, type: 'cryptocurrency' },
  { name: 'BTCGBP', active_id: 453, long_name: 'BTC/GBP', tv_symbol: 'COINBASE:BTCGBP', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 15, type: 'cryptocurrency' },
  { name: 'BTCJPY', active_id: 454, long_name: 'BTC/JPY', tv_symbol: 'COINBASE:BTCJPY', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 15, type: 'cryptocurrency' },
  { name: 'BTCUSD', active_id: 197, long_name: 'Bitcoin', tv_symbol: 'COINBASE:BTCUSD', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 15, type: 'cryptocurrency' },
  { name: 'DASH_USD', active_id: 209, long_name: 'Dash', tv_symbol: 'COINBASE:DASH_USD', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 25, type: 'cryptocurrency' },
  { name: 'ETHUSD', active_id: 272, long_name: 'Ethereum', tv_symbol: 'COINBASE:ETHUSD', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 40, type: 'cryptocurrency' },
  { name: 'LNKUSD', active_id: 464, long_name: 'Chainlink', tv_symbol: 'COINBASE:LNKUSD', tv_exchange: 'COINBASE', trading_hours: '24/7', always_on: true, payout: 15, type: 'cryptocurrency' },
  { name: 'UKBrent', active_id: 50, long_name: 'Brent Oil', tv_symbol: 'TVC:UKOIL', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'commodity' },
  { name: 'USCrude', active_id: 64, long_name: 'WTI Crude Oil', tv_symbol: 'TVC:USOIL', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'commodity' },
  { name: 'XAGEUR', active_id: 103, long_name: 'XAG/EUR', tv_symbol: 'TVC:XAGEUR', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'commodity' },
  { name: 'XAGUSD', active_id: 65, long_name: 'Silver', tv_symbol: 'OANDA:XAGUSD', tv_exchange: 'OANDA', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'commodity' },
  { name: 'XAUEUR', active_id: 102, long_name: 'XAU/EUR', tv_symbol: 'TVC:XAUEUR', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'commodity' },
  { name: 'XAUUSD', active_id: 2, long_name: 'Gold', tv_symbol: 'OANDA:XAUUSD', tv_exchange: 'OANDA', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'commodity' },
  { name: 'XNGUSD', active_id: 311, long_name: 'Natural Gas', tv_symbol: 'TVC:XNGUSD', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'commodity' },
  { name: 'XPDUSD', active_id: 313, long_name: 'Palladium spot', tv_symbol: 'OANDA:XPDUSD', tv_exchange: 'OANDA', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'commodity' },
  { name: 'XPTUSD', active_id: 312, long_name: 'Platinum spot', tv_symbol: 'OANDA:XPTUSD', tv_exchange: 'OANDA', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'commodity' },
  { name: '#AAPL', active_id: 5, long_name: 'Apple', tv_symbol: 'NASDAQ:AAPL', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'stock' },
  { name: '#AXP', active_id: 140, long_name: 'American Express', tv_symbol: 'NASDAQ:AXP', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'stock' },
  { name: '#BA', active_id: 8, long_name: 'Boeing Company', tv_symbol: 'NASDAQ:BA', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'stock' },
  { name: '#CSCO', active_id: 154, long_name: 'Cisco', tv_symbol: 'NASDAQ:CSCO', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'stock' },
  { name: '#FB', active_id: 177, long_name: 'FACEBOOK INC', tv_symbol: 'NASDAQ:FB', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'stock' },
  { name: '#INTC', active_id: 180, long_name: 'Intel', tv_symbol: 'NASDAQ:INTC', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 25, type: 'stock' },
  { name: '#JNJ', active_id: 144, long_name: 'Johnson & Johnson', tv_symbol: 'NASDAQ:JNJ', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'stock' },
  { name: '#JPM', active_id: 20, long_name: 'JPMorgan Chase & Co', tv_symbol: 'NASDAQ:JPM', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'stock' },
  { name: '#MSFT', active_id: 24, long_name: 'Microsoft', tv_symbol: 'NASDAQ:MSFT', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'stock' },
  { name: '#PFE', active_id: 147, long_name: 'Pfizer Inc', tv_symbol: 'NASDAQ:PFE', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'stock' },
  { name: '#TSLA', active_id: 186, long_name: 'Tesla', tv_symbol: 'NASDAQ:TSLA', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'stock' },
  { name: '#XOM', active_id: 153, long_name: 'ExxonMobil', tv_symbol: 'NASDAQ:XOM', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'stock' },
  { name: 'BABA', active_id: 183, long_name: 'Alibaba', tv_symbol: 'NASDAQ:BABA', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'stock' },
  { name: 'CITI', active_id: 326, long_name: 'Citigroup Inc', tv_symbol: 'NASDAQ:CITI', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'stock' },
  { name: 'NFLX', active_id: 182, long_name: 'Netflix', tv_symbol: 'NASDAQ:NFLX', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 50, type: 'stock' },
  { name: '#MCD', active_id: 23, long_name: "McDonald's", tv_symbol: 'NASDAQ:MCD', tv_exchange: 'NASDAQ', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 71, type: 'stock' },
  { name: '100GBP', active_id: 315, long_name: '100GBP', tv_symbol: 'TVC:100GBP', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'index' },
  { name: 'AEX25', active_id: 449, long_name: 'AEX 25', tv_symbol: 'TVC:AEX25', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'index' },
  { name: 'AUS200', active_id: 305, long_name: 'AUS 200', tv_symbol: 'TVC:AUS200', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 37, type: 'index' },
  { name: 'CAC40', active_id: 455, long_name: 'CAC 40', tv_symbol: 'TVC:CAC40', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'index' },
  { name: 'D30EUR', active_id: 318, long_name: 'D30/EUR', tv_symbol: 'TVC:D30EUR', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'index' },
  { name: 'DJI30', active_id: 322, long_name: 'DJI30', tv_symbol: 'TVC:DJI30', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'index' },
  { name: 'E35EUR', active_id: 314, long_name: 'E35EUR', tv_symbol: 'TVC:E35EUR', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'index' },
  { name: 'E50EUR', active_id: 319, long_name: 'E50/EUR', tv_symbol: 'TVC:E50EUR', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'index' },
  { name: 'F40EUR', active_id: 316, long_name: 'F40/EUR', tv_symbol: 'TVC:F40EUR', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'index' },
  { name: 'H33HKD', active_id: 463, long_name: 'HONG KONG 33', tv_symbol: 'TVC:H33HKD', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'index' },
  { name: 'JPN225', active_id: 317, long_name: 'JPN225', tv_symbol: 'TVC:JPN225', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'index' },
  { name: 'NASUSD', active_id: 323, long_name: 'US100', tv_symbol: 'TVC:NASUSD', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'index' },
  { name: 'SMI20', active_id: 466, long_name: 'SMI 20', tv_symbol: 'TVC:SMI20', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'index' },
  { name: 'SP500', active_id: 321, long_name: 'SP500', tv_symbol: 'TVC:SP500', tv_exchange: 'TVC', trading_hours: 'Mon–Fri (market hours)', always_on: false, payout: 45, type: 'index' },
]


/** Catégorie d'affichage d'un actif (groupes de catalogue). */
export function assetCategory(m: MarketInfo): AssetCategory {
  const t = m.type ?? ''
  if (t === 'cryptocurrency' || /^(BTC|ETH|LTC|XRP|DOGE|SOL|ADA|DOT)/.test(m.name)) return 'CRYPTO'
  if (t === 'commodity' || /^(XAU|XAG|XPT|XPD)/.test(m.name) || m.name.includes('Brent')) return 'COMMODITIES'
  if (t === 'stock' || m.name.startsWith('#')) return 'STOCKS'
  if (t === 'index') return 'INDEX'
  return 'FOREX'
}

/** Ordre d'affichage des catégories (FOREX d'abord, comme la spécification §2). */
export const CATEGORY_ORDER: AssetCategory[] = ['FOREX', 'COMMODITIES', 'CRYPTO', 'STOCKS', 'INDEX']

/** Regroupe le catalogue par catégorie pour la watchlist. */
export function catalogByCategory(): Array<{ category: AssetCategory; items: MarketInfo[] }> {
  const groups = new Map<AssetCategory, MarketInfo[]>()
  for (const m of MARKETS_CATALOG) {
    const cat = assetCategory(m)
    const arr = groups.get(cat) ?? []
    arr.push(m)
    groups.set(cat, arr)
  }
  return CATEGORY_ORDER
    .filter(c => groups.has(c))
    .map(category => ({ category, items: groups.get(category)! }))
}

/** Limite maximale d'assets simultanés (miroir du backend — v6.3 : 24). */
export const MAX_SELECTED_ASSETS = 24
