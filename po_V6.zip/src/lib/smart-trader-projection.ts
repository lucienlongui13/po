/**
 * smart-trader-projection.ts — AI Smart Trader forecast engine (Fibonacci Retracement).
 *
 * Extracted from drawing-layer.tsx so the exact production code can be
 * evaluated offline by scripts/eval-smart-trader.ts (no React/Canvas needed).
 *
 * Pipeline (v2):
 *   1. Market signature construction (noise-filtered, ATR-normalized,
 *      multi-feature: smoothed deltas, raw deltas, position-in-window,
 *      volatility ratio, lag-1 autocorrelation)
 *   2. Historical analogue search (constrained DTW + Pearson correlation +
 *      tail agreement + regime-feature distance, softmax weighting)
 *   3. Weighted reconstruction of future OHLC candles inside the Fib corridor
 *      (weighted-median ensemble path, robust to dissenting analogues)
 *   4. Directional edge score (young-move tail momentum + analogue consensus +
 *      position fade), sustained-displacement onset + onset heatmap
 *
 * v0 (the original production implementation) is kept exported for A/B
 * evaluation; the app imports the v2 `smartTraderProjection`.
 */

import type { CandleLike } from './indicators'

export interface SmartTraderProjectionResult {
  /** Normalised projection path: t in [0,1] → price. */
  out: Array<{ t: number; p: number }>
  /** 1 bullish, -1 bearish, 0 no clear edge. */
  direction: 1 | -1 | 0
  /** Terminal projected price. */
  target: number
  /** Index (from last real candle) of the first sustained directional bar. */
  onsetBar: number
  /** 30..95 display confidence. */
  confidence: number
  /** Predicted future OHLC candles (open/high/low/close, price units). */
  predictedBodies: Array<{ open: number; high: number; low: number; close: number }>
  /**
   * Retracement-principled price corridor the path lives in: the pullback
   * side stops at the swing origin (level 0, small overshoot allowance)
   * while the continuation side may reach the 1.272 extension beyond the
   * swing END. fibTop/fibBottom are the 0/1 box; the corridor extends
   * beyond it on the continuation side only.
   */
  corridorBottom: number
  corridorTop: number
  /** Normalised bullish onset frequency per forecast bar (0..1). */
  heatUp: number[]
  /** Normalised bearish onset frequency per forecast bar (0..1). */
  heatDown: number[]
}

// ---------------------------------------------------------------------------
// Shared math
// ---------------------------------------------------------------------------

function clamp(v: number, lo: number, hi: number): number {
  return v < lo ? lo : v > hi ? hi : v
}

function trueRange(c: CandleLike, prevClose: number): number {
  return Math.max(c.high, prevClose) - Math.min(c.low, prevClose)
}

/** Simple ATR (SMA of true ranges) over `len` bars ending at `end` (inclusive). */
function atrAt(candles: CandleLike[], end: number, len = 14): number {
  const start = Math.max(1, end - len + 1)
  let sum = 0
  let count = 0
  for (let i = start; i <= end; i++) {
    sum += trueRange(candles[i], candles[i - 1].close)
    count++
  }
  return Math.max(Number.EPSILON, sum / Math.max(1, count))
}

function emaSeries(x: number[], alpha: number): number[] {
  const out: number[] = []
  let e = x.length ? x[0] : 0
  for (const v of x) {
    e = alpha * v + (1 - alpha) * e
    out.push(e)
  }
  return out
}

/** Pearson correlation of two same-length series. */
function pearson(a: number[], b: number[]): number {
  const n = Math.min(a.length, b.length)
  if (n < 2) return 0
  let ma = 0, mb = 0
  for (let i = 0; i < n; i++) { ma += a[i]; mb += b[i] }
  ma /= n; mb /= n
  let sa = 0, sb = 0, sab = 0
  for (let i = 0; i < n; i++) {
    const x = a[i] - ma
    const y = b[i] - mb
    sa += x * x; sb += y * y; sab += x * y
  }
  const denom = Math.sqrt(sa * sb)
  return denom < 1e-12 ? 0 : sab / denom
}

/** Constrained DTW distance (Sakoe-Chiba band), normalised by path length. */
function dtwBand(a: number[], b: number[], band: number): number {
  const n = a.length
  const m = b.length
  if (!n || !m) return 0
  const INF = Number.POSITIVE_INFINITY
  let prev = new Array<number>(m + 1).fill(INF)
  let cur = new Array<number>(m + 1).fill(INF)
  prev[0] = 0
  for (let i = 1; i <= n; i++) {
    cur.fill(INF)
    const jStart = Math.max(1, i - band)
    const jEnd = Math.min(m, i + band)
    for (let j = jStart; j <= jEnd; j++) {
      const cost = Math.abs(a[i - 1] - b[j - 1])
      const best = Math.min(prev[j], cur[j - 1], prev[j - 1])
      if (best < INF) cur[j] = cost + best
    }
    const tmp = prev
    prev = cur
    cur = tmp
  }
  return prev[m] === INF ? INF : prev[m] / n
}

/** Weighted median (robust central estimate that dissent cannot drag). */
function weightedMedian(values: number[], weights: number[]): number {
  if (!values.length) return 0
  const pairs = values.map((v, i) => [v, weights[i]] as [number, number])
  pairs.sort((x, y) => x[0] - y[0])
  const total = pairs.reduce((s, p) => s + p[1], 0)
  if (total <= 0) return pairs[Math.floor(pairs.length / 2)][0]
  let acc = 0
  for (const [v, w] of pairs) {
    acc += w
    if (acc >= total / 2) return v
  }
  return pairs[pairs.length - 1][0]
}

// ---------------------------------------------------------------------------
// v2 — market signature (noise filtering)
// ---------------------------------------------------------------------------

/**
 * A signature is a scale-independent fingerprint of the recent market:
 *   - smooth : EMA(0.4) of ATR-normalised close deltas (trend shape, noise-reduced)
 *   - raw    : ATR-normalised close deltas (micro structure)
 *   - pos    : close position inside the last W bars' swing, 0..1
 *   - volRatio: ATR(5) / ATR(30) — volatility expansion vs contraction
 *   - autocorr: lag-1 autocorrelation of raw deltas (trend vs range regime)
 *   - atr    : local price scale
 */
interface Signature {
  end: number
  smooth: number[]
  raw: number[]
  pos: number
  volRatio: number
  autocorr: number
  atr: number
}

function buildSignature(candles: CandleLike[], end: number, L: number, W: number): Signature {
  const start = end - L + 1
  const raw: number[] = []
  for (let i = start; i <= end; i++) {
    const d = candles[i].close - candles[i - 1].close
    raw.push(d)
  }
  const atr = atrAt(candles, end, Math.min(14, Math.max(5, L)))
  const norm = raw.map(d => d / atr)
  const smooth = emaSeries(norm, 0.4)

  // position within the last W bars' swing
  const wStart = Math.max(0, end - W + 1)
  let lo = Number.POSITIVE_INFINITY
  let hi = Number.NEGATIVE_INFINITY
  for (let i = wStart; i <= end; i++) {
    if (candles[i].low < lo) lo = candles[i].low
    if (candles[i].high > hi) hi = candles[i].high
  }
  const pos = clamp((candles[end].close - lo) / Math.max(Number.EPSILON, hi - lo), 0, 1)

  const volRatio = clamp(atrAt(candles, end, 5) / Math.max(Number.EPSILON, atrAt(candles, end, 30)), 0.2, 4)

  const a1 = norm.slice(0, Math.max(1, norm.length - 1))
  const a2 = norm.slice(1)
  const autocorr = pearson(a1, a2)

  return { end, smooth, raw: norm, pos, volRatio, autocorr, atr }
}

// ---------------------------------------------------------------------------
// v2 — analogue search (DTW + correlation + tail + regime)
// ---------------------------------------------------------------------------

interface Analogue {
  end: number
  score: number
  weight: number
  /** Future cumulative displacement (rescaled to today's ATR), index 1..H. */
  futureCum: number[]
  /** Future per-step delta rescaled (index 1..H). */
  futureDelta: number[]
  /** Blended candle range rescaled (index 1..H). */
  futureRange: number[]
  atr: number
}

function searchAnalogues(
  candles: CandleLike[],
  current: Signature,
  L: number,
  W: number,
  H: number,
  atrNow: number,
): Analogue[] {
  const n = candles.length
  const firstCandidate = L + 10
  const lastCandidate = n - H - 1
  if (lastCandidate - firstCandidate < 2) return []

  const tailLen = Math.min(10, Math.max(4, Math.floor(L * 0.42)))
  const band = Math.max(2, Math.ceil(0.15 * L))
  const scored: Array<{ end: number; score: number }> = []

  for (let end = firstCandidate; end <= lastCandidate; end++) {
    const sig = buildSignature(candles, end, L, W)

    // 1. DTW on the noise-reduced trend shape (allows small time warping)
    const dDTW = clamp(dtwBand(current.smooth, sig.smooth, band) / 1.4, 0, 4)

    // 2. Pearson correlation on the raw normalised deltas (co-directionality)
    const corr = pearson(current.raw, sig.raw)
    const dCorr = (1 - corr) / 1.5

    // 3. Tail agreement — the young move/turn is what matters most for both
    //    the direction and the onset, so it carries the largest share.
    let tailErr = 0
    for (let j = 0; j < tailLen; j++) {
      const a = current.raw[current.raw.length - tailLen + j]
      const b = sig.raw[sig.raw.length - tailLen + j]
      tailErr += Math.abs(a - b)
    }
    const dTail = (tailErr / tailLen) * 1.8

    // 4. Regime feature distance (position, volatility, autocorrelation)
    const dRegime =
      0.7 * Math.abs(current.pos - sig.pos) +
      0.9 * Math.abs(Math.log(current.volRatio) - Math.log(sig.volRatio)) +
      0.6 * Math.abs(current.autocorr - sig.autocorr)

    const score = 0.28 * dDTW + 0.20 * dCorr + 0.30 * dTail + 0.22 * dRegime
    if (Number.isFinite(score)) scored.push({ end, score })
  }

  scored.sort((a, b) => a.score - b.score)

  // Greedy selection with minimum spacing so analogues are not all clustered
  const selected: Array<{ end: number; score: number }> = []
  const minSpacing = 3
  for (const cand of scored) {
    if (selected.length >= 12) break
    const tooClose = selected.some(s => Math.abs(s.end - cand.end) < minSpacing)
    if (!tooClose) selected.push(cand)
  }
  // fallback: relax spacing if too few
  if (selected.length < 5) {
    for (const cand of scored) {
      if (selected.length >= 12) break
      if (!selected.some(s => s.end === cand.end)) selected.push(cand)
    }
  }
  if (selected.length < 3) return []

  // Softmax weights (temperature 0.16) + mild recency bonus
  const maxScore = selected[0].score
  const span = Math.max(1, lastCandidate - firstCandidate)
  const analogues: Analogue[] = selected.map(m => {
    const scaleRatio = clamp(atrNow / Math.max(Number.EPSILON, atrAt(candles, m.end, 14)), 0.5, 2.0)
    const futureCum: number[] = [0]
    const futureDelta: number[] = [0]
    const futureRange: number[] = [0]
    let cum = 0
    for (let h = 1; h <= H; h++) {
      const idx = Math.min(n - 1, m.end + h)
      const d = (candles[idx].close - candles[idx - 1].close) * scaleRatio
      cum += d
      futureCum.push(cum)
      futureDelta.push(d)
      futureRange.push(Math.max(Number.EPSILON, trueRange(candles[idx], candles[idx - 1].close)) * scaleRatio)
    }
    const recency = 1 + 0.20 * clamp((m.end - firstCandidate) / span, 0, 1)
    return {
      end: m.end,
      score: m.score,
      weight: Math.exp(-(m.score - maxScore) / 0.16) * recency,
      futureCum,
      futureDelta,
      futureRange,
      atr: atrAt(candles, m.end, 14),
    }
  })
  return analogues
}

// ---------------------------------------------------------------------------
// v2 — main projection (internals exposed for diagnostics/calibration)
// ---------------------------------------------------------------------------

export interface ProjectionInternals {
  L: number
  K: number
  atr: number
  pos: number
  volRatio: number
  autocorr: number
  trendiness: number
  rangeFactor: number
  tailMean: number
  tailTanh: number
  tailConsistency: number
  volExpansion: number
  impulse: number
  persistence: number
  drive: number
  momentumW: number
  consensusW: number
  fadeW: number
  consensus: number
  medianDispATR: number
  meanDispATR: number
  voteUp: number
  voteDown: number
  edge: number
  theta: number
  analogues: Array<{ end: number; score: number; weight: number; endpointATR: number }>
}

/**
 * Impulse direction of the anchored leg, inferred from the data when the
 * caller cannot provide it: within the recent window, the leg runs from the
 * earlier swing extreme to the later one (low-then-high → up leg).
 */
function inferImpulseDir(candles: CandleLike[], end: number, W: number, anchorA: number, anchorB: number): 1 | -1 {
  const start = Math.max(0, end - W + 1)
  let idxHi = start
  let idxLo = start
  for (let i = start; i <= end; i++) {
    if (candles[i].high >= candles[idxHi].high) idxHi = i
    if (candles[i].low <= candles[idxLo].low) idxLo = i
  }
  if (idxLo !== idxHi) return idxHi > idxLo ? 1 : -1
  return anchorB >= anchorA ? 1 : -1
}

function computeProjection(
  candles: CandleLike[],
  horizonBars: number,
  anchorA: number,
  anchorB: number,
  impulseHint?: 1 | -1,
): { result: SmartTraderProjectionResult | null; internals: ProjectionInternals | null } {
  const n = candles.length
  const H = horizonBars
  if (H < 2 || n < 30) return { result: null, internals: null }

  // Adaptive signature length: long enough for shape, short enough for speed
  const L = clamp(Math.floor(H * 0.8), 10, 24)
  const W = clamp(Math.round(L * 2.5), 30, 60)
  if (n < L + H + 15) return { result: null, internals: null }

  const fibTop = Math.max(anchorA, anchorB)
  const fibBottom = Math.min(anchorA, anchorB)
  const fibRange = Math.max(fibTop - fibBottom, Number.EPSILON)
  const lastClose = candles[n - 1].close

  // ---- 0. retracement corridor -------------------------------------------
  // The 0/1 box is the retracement zone. The forecast respects the fib
  // principle: the pullback may at most fully retrace to the origin (level 0,
  // small overshoot allowance for reversal cases), while the continuation of
  // the impulse may extend up to the classic 1.272 level beyond the swing END.
  const impulseDir = impulseHint === 1 || impulseHint === -1
    ? impulseHint
    : inferImpulseDir(candles, n - 1, W, anchorA, anchorB)
  const extSpan = 0.272 * fibRange
  const retraceSlack = 0.10 * fibRange
  const corridorTop = impulseDir > 0 ? fibTop + extSpan : fibTop + retraceSlack
  const corridorBottom = impulseDir > 0 ? fibBottom - retraceSlack : fibBottom - extSpan

  // ---- 1. market signature (noise-filtered) -------------------------------
  const current = buildSignature(candles, n - 1, L, W)
  const atrNow = current.atr

  // ---- 2. analogue search (DTW / correlation) ------------------------------
  const analogues = searchAnalogues(candles, current, L, W, H, atrNow)
  if (analogues.length < 3) return { result: null, internals: null }
  const wsum = analogues.reduce((s, a) => s + a.weight, 0) || 1

  // ---- 3. ensemble evidence + weighted path --------------------------------
  // Endpoint displacement per analogue (price units, rescaled to today's ATR)
  const endpoints = analogues.map(a => a.futureCum[H])
  const medianDisp = weightedMedian(endpoints, analogues.map(a => a.weight))
  const meanDisp = endpoints.reduce((s, d, i) => s + d * analogues[i].weight, 0) / wsum
  const voteUp = analogues.reduce((s, a, i) => s + (endpoints[i] > 0 ? a.weight : 0), 0) / wsum
  const voteDown = analogues.reduce((s, a, i) => s + (endpoints[i] < 0 ? a.weight : 0), 0) / wsum

  // Per-step robust path: weighted median blended with weighted mean
  const path: number[] = [lastClose]
  const perStepRange: number[] = [atrNow]
  for (let h = 1; h <= H; h++) {
    const med = weightedMedian(analogues.map(a => a.futureCum[h]), analogues.map(a => a.weight))
    const mean = analogues.reduce((s, a) => s + a.futureCum[h] * a.weight, 0) / wsum
    let disp = 0.62 * med + 0.38 * mean

    // Retracement corridor: pullback side capped at the origin level,
    // continuation side free up to the 1.272 extension.
    const next = lastClose + disp
    disp = clamp(next, corridorBottom, corridorTop) - lastClose

    // small decaying micro-structure so the curve bends like a real path
    const wiggle = Math.sin(h * 1.7 + current.raw[current.raw.length - 1] * 9)
      * atrNow * 0.045 * Math.exp(-h / (H * 1.6))
    path.push(clamp(lastClose + disp + wiggle, corridorBottom, corridorTop))
    perStepRange.push(analogues.reduce((s, a) => s + a.futureRange[h] * a.weight, 0) / wsum)
  }

  // ---- 4. directional edge score -------------------------------------------
  // (a) young-move momentum: exponentially-weighted mean of the last K normalised
  //     deltas (K is short so the TURN dominates the older push into the level)
  const K = clamp(Math.floor(L / 6), 3, 4)
  const tailWeights: number[] = []
  for (let j = 0; j < K; j++) tailWeights.push(Math.pow(1.4, j))
  const tailWsum = tailWeights.reduce((s, v) => s + v, 0)
  let tailSum = 0
  for (let j = 0; j < K; j++) {
    tailSum += current.raw[L - K + j] * tailWeights[j]
  }
  const tailMean = tailSum / tailWsum
  const tailTanh = Math.tanh(tailMean / 0.9)
  // directional persistence: share of the last K deltas agreeing with the tail sign
  const tailSign = Math.sign(tailMean) || 1
  let agreeCount = 0
  for (let j = 0; j < K; j++) {
    if (Math.sign(current.raw[L - K + j]) === tailSign) agreeCount++
  }
  const tailConsistency = agreeCount / K
  // (b) regime: trendiness of the whole signature window
  const windowSum = current.raw.reduce((s, v) => s + v, 0)
  const trendiness = clamp(Math.abs(windowSum) / (L * 0.85), 0, 1)
  const rangeFactor = 1 - trendiness
  // (c) consensus: analogue median endpoint in ATR units
  const consensus = Math.tanh(medianDisp / (atrNow * 2.5))
  // (d) drive = evidence that a NEW move is underway:
  //     - impulse: volatility expansion × directional persistence (breakout)
  //     - persistence: |tail| × consistency without vol expansion (young trend)
  //     When a young move is established, the visible history holds no true
  //     precedent for it, so momentum must override the old regime's consensus
  //     and the position-fade prior (both reflect the PREVIOUS regime).
  const volExpansion = clamp((current.volRatio - 1.0) / 0.5, 0, 1.5)
  const impulse = clamp(1.3 * volExpansion * tailConsistency * Math.abs(tailTanh), 0, 1)
  const persistence = clamp(1.6 * Math.abs(tailTanh) * tailConsistency, 0, 1)
  const drive = clamp(Math.max(impulse, persistence), 0, 1)

  const momentumW = 0.45 * (1 - 0.35 * rangeFactor) * (1 + 0.5 * drive)
  const consensusW = 0.22 * (1 - 0.75 * drive)
  const fadeW = 0.32 * (0.45 + 0.6 * rangeFactor) * (1 - 0.8 * drive)
  const edge = momentumW * tailTanh + consensusW * consensus + fadeW * (0.5 - current.pos)

  const THETA = 0.07
  const direction = (edge > THETA ? 1 : edge < -THETA ? -1 : 0) as 1 | -1 | 0

  // ---- confidence -----------------------------------------------------------
  const voteStrength = direction > 0 ? voteUp : direction < 0 ? voteDown : 0.5
  const meanScore = analogues.reduce((s, a) => s + a.score, 0) / analogues.length
  const simFactor = clamp(1 - meanScore / 1.2, 0, 1)
  let confidence: number
  if (direction === 0) {
    confidence = Math.round(30 + 40 * clamp(1 - Math.abs(edge) / THETA, 0, 1) * 0.3)
  } else {
    confidence = Math.round(
      34 +
      46 * clamp(Math.abs(edge) / 0.40, 0, 1) +
      24 * clamp((voteStrength - 0.5) * 2, 0, 1) +
      14 * simFactor,
    )
  }
  confidence = clamp(Math.round(confidence), 30, 95)

  // ---- onset: first SUSTAINED displacement bar ------------------------------
  // Onset is measured relative to the PROJECTED total displacement (same
  // 30%-of-total convention the harness uses for the actual onset), with a
  // small ATR floor so degenerate ~zero forecasts do not trigger instantly.
  let onsetBar = 0
  if (direction !== 0) {
    const finalDisp = Math.abs(path[H] - lastClose)
    const threshold = Math.max(0.30 * finalDisp, 0.22 * atrNow, fibRange * 0.006)
    for (let h = 1; h <= H - 2; h++) {
      const d0 = (path[h] - lastClose) * direction
      const d1 = (path[h + 1] - lastClose) * direction
      if (d0 >= threshold && d1 >= threshold * 0.8) {
        onsetBar = h
        break
      }
    }
  }

  // ---- onset heatmap from the analogue ensemble -----------------------------
  const heatUp = new Array<number>(H).fill(0)
  const heatDown = new Array<number>(H).fill(0)
  for (const a of analogues) {
    const localScale = atrNow
    for (const dir of [1, -1] as const) {
      let onset = -1
      let cum = 0
      for (let h = 1; h <= H - 2; h++) {
        const d1 = a.futureDelta[h]
        const d2 = a.futureDelta[h + 1]
        const d3 = a.futureDelta[h + 2]
        cum += d1
        const same = dir > 0 ? d1 > 0 && d2 > 0 && d3 > 0 : d1 < 0 && d2 < 0 && d3 < 0
        if (same && Math.abs(cum) >= 0.30 * localScale) { onset = h - 1; break }
      }
      if (onset >= 0) {
        const bin = clamp(onset, 0, H - 1)
        if (dir > 0) heatUp[bin] += a.weight
        else heatDown[bin] += a.weight
      }
    }
  }
  const heatUpTotal = heatUp.reduce((s, v) => s + v, 0)
  const heatDownTotal = heatDown.reduce((s, v) => s + v, 0)
  for (let i = 0; i < H; i++) {
    heatUp[i] = heatUpTotal > 0 ? heatUp[i] / heatUpTotal : 0
    heatDown[i] = heatDownTotal > 0 ? heatDown[i] / heatDownTotal : 0
  }

  // ---- predicted OHLC candles ----------------------------------------------
  const predictedBodies: Array<{ open: number; high: number; low: number; close: number }> = []
  for (let h = 1; h <= H; h++) {
    const open = path[h - 1]
    const close = path[h]
    const wick = Math.max(0.18 * perStepRange[h], 0.22 * atrNow)
    predictedBodies.push({
      open,
      close,
      high: Math.max(open, close) + wick,
      low: Math.min(open, close) - wick,
    })
  }

  const out = path.map((p, i) => ({ t: i / H, p }))
  const result: SmartTraderProjectionResult = {
    out,
    direction,
    target: path[H],
    onsetBar,
    confidence,
    predictedBodies,
    heatUp,
    heatDown,
    corridorBottom,
    corridorTop,
  }
  const internals: ProjectionInternals = {
    L,
    K,
    atr: atrNow,
    pos: current.pos,
    volRatio: current.volRatio,
    autocorr: current.autocorr,
    trendiness,
    rangeFactor,
    tailMean,
    tailTanh,
    tailConsistency,
    volExpansion,
    impulse,
    persistence,
    drive,
    momentumW,
    consensusW,
    fadeW,
    consensus,
    medianDispATR: medianDisp / atrNow,
    meanDispATR: meanDisp / atrNow,
    voteUp,
    voteDown,
    edge,
    theta: THETA,
    analogues: analogues.map(a => ({
      end: a.end,
      score: a.score,
      weight: a.weight / wsum,
      endpointATR: a.futureCum[H] / atrNow,
    })),
  }
  return { result, internals }
}

// ---------------------------------------------------------------------------
// v3 — deterministic market-direction anticipation
// ---------------------------------------------------------------------------
// This replaces the analogue/heatmap path used by the interactive drawing
// layer. It is deliberately deterministic: 30 recent bars, trend + momentum
// + directional persistence, ATR-normalised extension, and no random/noise
// term. The goal is anticipation of the current market regime, not a claim of
// certainty about a future timestamp.
function anticipateMarketDirection(
  candles: CandleLike[],
  horizonBars: number,
  anchorA: number,
  anchorB: number,
  impulseHint?: 1 | -1,
  lookback = 30,
): SmartTraderProjectionResult | null {
  const n = candles.length
  const rawLookback = Number(lookback)
  const L = Number.isFinite(rawLookback) ? Math.max(1, Math.round(rawLookback)) : 30
  if (n < L + 2) return null
  const H = Math.max(2, Math.min(12, Math.round(horizonBars)))
  const start = Math.max(1, n - L)
  const recent = candles.slice(start)
  if (recent.length < 1) return null

  const closes = recent.map(c => c.close)
  const ranges = recent.map(c => Math.max(1e-12, c.high - c.low))
  const tr = recent.map((c, i) => {
    if (start + i === 0) return c.high - c.low
    const prev = candles[start + i - 1]
    return Math.max(c.high - c.low, Math.abs(c.high - prev.close), Math.abs(c.low - prev.close))
  })
  const atr = tr.slice(-14).reduce((a,b) => a+b,0) / Math.max(1, Math.min(14, tr.length))
  const last = closes[closes.length - 1]
  const first = closes[0]

  const sx = (closes.length - 1) * closes.length / 2
  const sx2 = closes.reduce((a,_,i) => a + i*i, 0)
  const sy = closes.reduce((a,v) => a+v,0)
  const sxy = closes.reduce((a,v,i) => a+i*v,0)
  const denom = closes.length * sx2 - sx*sx
  const slope = denom !== 0 ? (closes.length * sxy - sx*sy) / denom : 0
  const slopeAtr = slope / Math.max(atr, 1e-12)

  const ema = (period: number) => {
    const alpha = 2 / (period + 1)
    let e = closes[0]
    for (let i = 1; i < closes.length; i++) e = alpha * closes[i] + (1 - alpha) * e
    return e
  }
  const ema8 = ema(8), ema21 = ema(Math.min(21, closes.length))
  const emaBias = (ema8 - ema21) / Math.max(atr, 1e-12)
  // Symmetric short-term evidence. Do NOT let the Fibonacci anchor direction
  // force a bullish result: the drawing defines price levels, while the recent
  // market structure defines direction.
  const bodyPressure = recent.slice(-6).reduce((sum, c) => {
    const range = Math.max(1e-12, c.high - c.low)
    return sum + (c.close - c.open) / range
  }, 0) / Math.max(1, Math.min(6, recent.length))
  const lastDeltas = closes.slice(-8).slice(1).map((v,i) => v - closes[closes.length-8+i])
  const directional = lastDeltas.reduce((s,d) => s + Math.sign(d), 0) / Math.max(1,lastDeltas.length)
  const recent3 = closes.slice(-4)
  const recentMomentum = recent3.length >= 2
    ? (recent3[recent3.length - 1] - recent3[0]) / Math.max(atr, 1e-12)
    : 0

  // The score is deliberately balanced for both sides. `impulseHint` is only
  // a secondary confirmation and can never manufacture a bullish direction.
  const score =
    0.34 * Math.tanh(slopeAtr * 4) +
    0.23 * Math.tanh(emaBias / 2) +
    0.18 * directional +
    0.17 * clamp(bodyPressure, -1, 1) +
    0.08 * Math.tanh(recentMomentum)

  let direction: 1 | -1 | 0 = score > 0.11 ? 1 : score < -0.11 ? -1 : 0
  // Preserve a detectable bearish/bullish regime when the weighted score is
  // modest but several recent structure measures agree on the same side.
  if (direction === 0) {
    const structureBias =
      0.50 * Math.sign(slopeAtr) +
      0.30 * Math.sign(emaBias) +
      0.20 * Math.sign(bodyPressure)
    if (structureBias >= 0.66) direction = 1
    else if (structureBias <= -0.66) direction = -1
  }

  // An anchor hint may confirm the selected direction, but it is never allowed
  // to flip a bearish market into bullish (or vice versa).
  if (direction !== 0 && (impulseHint === 1 || impulseHint === -1) && impulseHint === direction) {
    // no-op: explicit confirmation only
  }

  const strength = Math.min(1, Math.abs(score) * 1.8 + Math.min(0.35, Math.abs(slopeAtr)) * 0.8)
  const confidence = Math.round(Math.max(30, Math.min(95, 38 + strength * 57)))
  const onsetBar = direction === 0 ? 0 : Math.max(1, Math.min(H, Math.round(1 + (1 - Math.min(1, Math.abs(score))) * 2)))

  const fibTop = Math.max(anchorA, anchorB)
  const fibBottom = Math.min(anchorA, anchorB)
  const fibRange = Math.max(atr * 1.5, fibTop - fibBottom, 1e-12)
  const extension = 0.272 * fibRange
  const corridorTop = direction > 0 ? fibTop + extension : fibTop + 0.10 * fibRange
  const corridorBottom = direction < 0 ? fibBottom - extension : fibBottom - 0.10 * fibRange

  // Continuation distance grows with directional strength but is bounded by a
  // fraction of the active swing/ATR corridor. No random wiggle is applied.
  const maxMove = Math.min(fibRange * 0.24, Math.max(atr * 0.65, fibRange * (0.08 + 0.16 * strength)))
  const signedMove = direction === 0 ? 0 : direction * maxMove
  const decay = Math.max(0.55, 1 - 0.45 * strength)
  const predictedBodies: Array<{open:number; high:number; low:number; close:number}> = []
  const out: Array<{t:number;p:number}> = [{ t: 0, p: last }]
  let prevClose = last
  for (let i = 1; i <= H; i++) {
    const t = i / H
    const progress = direction === 0 ? 0 : (1 - Math.pow(decay, i)) / (1 - decay) / ((1 - Math.pow(decay, H)) / (1 - decay))
    const target = last + signedMove * progress
    const open = prevClose
    const close = target
    const body = Math.abs(close - open)
    const wick = Math.max(atr * 0.14, body * 0.18)
    const high = Math.max(open, close) + wick
    const low = Math.min(open, close) - wick
    predictedBodies.push({ open, high, low, close })
    out.push({ t, p: close })
    prevClose = close
  }

  const heatUp = new Array(H + 1).fill(0)
  const heatDown = new Array(H + 1).fill(0)
  for (let i = onsetBar; i <= H; i++) {
    if (direction > 0) heatUp[i] = Math.min(1, 0.35 + strength * 0.65)
    if (direction < 0) heatDown[i] = Math.min(1, 0.35 + strength * 0.65)
  }
  return { out, direction, target: prevClose, onsetBar, confidence, predictedBodies, corridorBottom, corridorTop, heatUp, heatDown }
}

export function smartTraderProjection(
  candles: CandleLike[],
  horizonBars: number,
  anchorA: number,
  anchorB: number,
  impulseHint?: 1 | -1,
  lookback = 30,
): SmartTraderProjectionResult | null {
  return anticipateMarketDirection(candles, horizonBars, anchorA, anchorB, impulseHint, lookback)
}

/** Full diagnostics (identical pipeline, internals exposed for calibration). */
export function smartTraderProjectionDiagnostics(
  candles: CandleLike[],
  horizonBars: number,
  anchorA: number,
  anchorB: number,
  impulseHint?: 1 | -1,
): { result: SmartTraderProjectionResult | null; internals: ProjectionInternals | null } {
  return computeProjection(candles, horizonBars, anchorA, anchorB, impulseHint)
}

// ---------------------------------------------------------------------------
// v0 — BASELINE (original production implementation, kept for A/B tests)
// ---------------------------------------------------------------------------

export function smartTraderProjectionV0(
  candles: CandleLike[],
  horizonBars: number,
  anchorA: number,
  anchorB: number,
): SmartTraderProjectionResult | null {
  const n = candles.length
  const lookback = Math.min(20, Math.max(10, Math.floor(horizonBars * 0.8)))
  if (n < lookback + horizonBars + 12) return null

  const fibTop = Math.max(anchorA, anchorB)
  const fibBottom = Math.min(anchorA, anchorB)
  const fibRange = Math.max(fibTop - fibBottom, Number.EPSILON)
  const corridorBottom = fibBottom
  const corridorTop = fibTop
  const lastClose = candles[n - 1].close

  const candleRange = (c: CandleLike) => Math.max(Number.EPSILON, c.high - c.low)
  const body = (c: CandleLike) => c.close - c.open
  const bodyRatio = (c: CandleLike) => body(c) / candleRange(c)
  const closeDelta = (i: number) => candles[i].close - candles[i - 1].close

  const makeSignature = (end: number, count: number) => {
    const start = end - count + 1
    const deltas: number[] = []
    const shapes: number[] = []
    const ranges: number[] = []
    for (let i = start; i <= end; i++) {
      deltas.push(closeDelta(i))
      shapes.push(bodyRatio(candles[i]))
      ranges.push(candleRange(candles[i]))
    }
    const scale = Math.max(
      Number.EPSILON,
      ranges.reduce((a, b) => a + b, 0) / ranges.length,
      deltas.reduce((a, b) => a + Math.abs(b), 0) / deltas.length,
    )
    return {
      deltas: deltas.map(v => v / scale),
      shapes,
      ranges: ranges.map(v => v / scale),
      scale,
    }
  }

  const current = makeSignature(n - 1, lookback)
  const latestCandidate = n - horizonBars - 1
  const candidates: Array<{ score: number; end: number }> = []

  for (let end = lookback; end <= latestCandidate; end++) {
    const hist = makeSignature(end, lookback)
    let shapeErr = 0
    let dirErr = 0
    let magErr = 0
    for (let j = 0; j < lookback; j++) {
      const hd = hist.deltas[j]
      const cd = current.deltas[j]
      shapeErr += Math.abs(hist.shapes[j] - current.shapes[j])
      dirErr += hd === 0 || cd === 0 ? 0.15 : (Math.sign(hd) === Math.sign(cd) ? 0 : 1)
      magErr += Math.abs(Math.abs(hd) - Math.abs(cd))
    }
    const tail = Math.min(3, lookback)
    let tailErr = 0
    for (let j = lookback - tail; j < lookback; j++) {
      tailErr += Math.abs(hist.deltas[j] - current.deltas[j]) * 1.5
    }
    const score =
      shapeErr / lookback * 0.20 +
      dirErr / lookback * 0.30 +
      magErr / lookback * 0.20 +
      tailErr / tail * 0.30
    candidates.push({ score, end })
  }

  candidates.sort((a, b) => a.score - b.score)
  const selected = candidates.slice(0, Math.min(10, candidates.length))
  if (!selected.length) return null

  const weights = selected.map((m, i) =>
    Math.exp(-m.score * 4.0) * (1 / (1 + i * 0.16)),
  )
  const wsum = weights.reduce((a, b) => a + b, 0) || 1

  const path: number[] = [lastClose]
  const predictedBodies: Array<{ open: number; high: number; low: number; close: number }> = []
  const directionVotes: number[] = []
  for (let step = 1; step <= horizonBars; step++) {
    let delta = 0
    let signed = 0
    let rangeBlend = 0
    let bodyBlend = 0
    for (let k = 0; k < selected.length; k++) {
      const m = selected[k]
      const weight = weights[k]
      const idx = Math.min(n - 1, m.end + step)
      const prevIdx = Math.max(0, idx - 1)
      const raw = candles[idx].close - candles[prevIdx].close
      const histScale = Math.max(Number.EPSILON, makeSignature(m.end, lookback).scale)
      const scaleRatio = Math.min(2.4, Math.max(0.42, current.scale / histScale))
      const move = raw * scaleRatio
      delta += weight * move
      signed += weight * Math.sign(move)
      rangeBlend += weight * candleRange(candles[idx]) * scaleRatio
      bodyBlend += weight * Math.abs(body(candles[idx])) * scaleRatio
    }
    delta /= wsum
    const agreement = Math.abs(signed / wsum)
    const damping = 0.98 - 0.22 * ((step - 1) / Math.max(1, horizonBars - 1))
    const prior = path[path.length - 1]
    let next = prior + delta * damping

    const corridorPadding = fibRange * 0.035
    const minP = fibBottom + corridorPadding
    const maxP = fibTop - corridorPadding
    if (next < minP) next = minP + (minP - next) * 0.16
    if (next > maxP) next = maxP - (next - maxP) * 0.16

    const phaseSource = current.deltas[(step - 1) % current.deltas.length] || 0
    const micro = Math.sin(step * 1.41 + phaseSource * 7) * current.scale * 0.11 * Math.exp(-step / (horizonBars * 1.4))
    next += micro

    next = Math.max(fibBottom, Math.min(fibTop, next))
    if (agreement < 0.34) next = prior + (next - prior) * 0.54

    path.push(next)
    directionVotes.push(Math.sign(delta))

    const predictedOpen = prior
    const span = Math.max(Number.EPSILON, rangeBlend / wsum)
    const bodySpan = Math.max(Number.EPSILON, bodyBlend / wsum)
    const wick = Math.max(span * 0.22, bodySpan * 0.55)
    predictedBodies.push({
      open: predictedOpen,
      close: next,
      high: Math.max(predictedOpen, next) + wick,
      low: Math.min(predictedOpen, next) - wick,
    })
  }

  const heatUp = new Array(horizonBars).fill(0) as number[]
  const heatDown = new Array(horizonBars).fill(0) as number[]
  for (let k = 0; k < selected.length; k++) {
    const m = selected[k]
    const weight = weights[k]
    const localScale = Math.max(Number.EPSILON, makeSignature(m.end, lookback).scale)
    for (const dir of [1, -1] as const) {
      let onset = -1
      let cumulative = 0
      for (let step = 1; step <= horizonBars - 2; step++) {
        const i0 = Math.min(n - 1, m.end + step)
        const i1 = Math.min(n - 1, m.end + step + 1)
        const i2 = Math.min(n - 1, m.end + step + 2)
        const d1 = candles[i0].close - candles[Math.max(0, i0 - 1)].close
        const d2 = candles[i1].close - candles[i0].close
        const d3 = candles[i2].close - candles[i1].close
        const same = dir > 0 ? d1 > 0 && d2 > 0 && d3 > 0 : d1 < 0 && d2 < 0 && d3 < 0
        cumulative += d1
        if (same && Math.abs(cumulative) >= localScale * 0.28) { onset = step - 1; break }
      }
      if (onset >= 0) {
        if (dir > 0) heatUp[Math.min(horizonBars - 1, onset)] += weight
        else heatDown[Math.min(horizonBars - 1, onset)] += weight
      }
    }
  }
  const heatUpMax = heatUp.reduce((a, b) => a + b, 0) || 1
  const heatDownMax = heatDown.reduce((a, b) => a + b, 0) || 1
  for (let i = 0; i < horizonBars; i++) {
    heatUp[i] /= heatUpMax
    heatDown[i] /= heatDownMax
  }

  const net = path[path.length - 1] - lastClose
  const localMove = Math.max(current.scale * 0.35, fibRange * 0.018)
  const direction = net > localMove ? 1 : net < -localMove ? -1 : 0

  let onsetBar = 0
  if (direction !== 0) {
    const displacementThreshold = Math.max(current.scale * 0.28, fibRange * 0.010)
    for (let i = 1; i <= horizonBars - 2; i++) {
      const d1 = path[i] - path[i - 1]
      const d2 = path[i + 1] - path[i]
      const d3 = path[i + 2] - path[i + 1]
      const sameDirection = direction > 0
        ? d1 > 0 && d2 > 0 && d3 > 0
        : d1 < 0 && d2 < 0 && d3 < 0
      const displacement = Math.abs(path[i + 2] - lastClose)
      const voteStart = Math.max(0, i - 1)
      const voteEnd = Math.min(directionVotes.length, i + 2)
      const votes = directionVotes.slice(voteStart, voteEnd)
      const voteAgreement = votes.length
        ? votes.filter(v => v === direction).length / votes.length
        : 0
      if (sameDirection && displacement >= displacementThreshold && voteAgreement >= 0.60) {
        onsetBar = i
        break
      }
    }
  }

  const selectedAgreement = selected.reduce((sum, m, i) => sum + weights[i] * Math.exp(-m.score * 2), 0) / wsum
  const confidence = Math.max(30, Math.min(95, Math.round(48 + selectedAgreement * 42)))
  const out = path.map((p, i) => ({ t: i / horizonBars, p }))
  return { out, direction, target: path[path.length - 1], onsetBar, confidence, predictedBodies, heatUp, heatDown, corridorBottom, corridorTop }
}
