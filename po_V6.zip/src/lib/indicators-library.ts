/**
 * indicators-library.ts — TradingView-style indicator registry
 * =============================================================
 *
 * 55+ indicators organized in TradingView categories, each with:
 *  - editable numeric params (TradingView settings dialog parity)
 *  - plot definitions (line / histogram, colors, optional displacement)
 *  - reference levels (RSI 30/70, Stoch 80/20, CCI ±100 …)
 *  - `compute()` returning index-aligned series (null while warming up)
 *
 * All formulas follow the standard TradingView/Pine definitions.
 */

import type { CandleLike } from './indicators'
import { computeFractalCustomLive } from '../../shared/fractal-custom-live'
import { computeFractalCustomLiveBis } from '../../shared/fractal-custom-live-bis'
import { computeFractalTrigonometricForecast } from '../../shared/fractal-trigonometric-forecast'

export type Series = (number | null)[]

export type IndicatorCategory =
  | 'moving-averages'
  | 'trend'
  | 'momentum'
  | 'volatility'
  | 'volume'
  | 'bill-williams'
  | 'oscillators'

export interface IndicatorParam {
  key: string
  label: string
  default: number
  min: number
  max: number
  step: number
}

export interface IndicatorPlot {
  key: string
  label: string
  type: 'line' | 'histogram'
  color: string
  color2?: string          // histogram negative / falling color
  lineWidth?: 1 | 2 | 3 | 4
  dashed?: boolean
  /** Histogram coloring strategy. */
  histMode?: 'sign' | 'direction'
  /** Shift the plot N bars to the right (negative = left). */
  displacement?: number
  /** Marker-only plot (no line); rendered as a chart marker. */
  marker?: 'arrowUp' | 'arrowDown'
}

// Some indicators operate on the main candlestick colors instead of drawing
// a conventional line/marker series. The chart renderer handles these
// definitions specially.


export interface IndicatorLevel {
  value: number
  color: string
  dashed?: boolean
  title?: string
}

export interface IndicatorDef {
  id: string
  name: string
  short: string
  category: IndicatorCategory
  pane: 'main' | 'separate'
  params: IndicatorParam[]
  plots: IndicatorPlot[]
  levels?: IndicatorLevel[]
  candleColoring?: 'engulfing'
  compute(candles: CandleLike[], p: Record<string, number>): Record<string, Series>
}

export const CATEGORY_LABELS: Record<IndicatorCategory, string> = {
  'moving-averages': 'Moving Averages',
  trend: 'Trend',
  momentum: 'Momentum',
  volatility: 'Volatility',
  volume: 'Volume',
  'bill-williams': 'Bill Williams',
  oscillators: 'Oscillators',
}

// ---------------------------------------------------------------------------
// TradingView default palette
// ---------------------------------------------------------------------------
export const TV = {
  blue: '#2962FF',
  navy: '#1E53E5',
  orange: '#FF6D00',
  green: '#089981',
  red: '#F23645',
  teal: '#00BCD4',
  purple: '#9C27B0',
  yellow: '#F57F17',
  gray: '#787B86',
  aqua: '#26C6DA',
  pink: '#E040FB',
  lime: '#8BC34A',
}

// ---------------------------------------------------------------------------
// Math helpers (self-contained, Pine-compatible)
// ---------------------------------------------------------------------------

const nulls = (n: number): Series => new Array<number | null>(n).fill(null)

export function sma(src: number[], len: number): Series {
  const out = nulls(src.length)
  if (len <= 0) return out
  let sum = 0
  for (let i = 0; i < src.length; i++) {
    sum += src[i]
    if (i >= len) sum -= src[i - len]
    if (i >= len - 1) out[i] = sum / len
  }
  return out
}

export function ema(src: number[], len: number): Series {
  const out = nulls(src.length)
  if (src.length === 0 || len <= 0) return out
  const k = 2 / (len + 1)
  let prev = src[0]
  let seed = 0
  for (let i = 0; i < src.length; i++) {
    if (i === 0) { prev = src[0]; seed += src[0] }
    else prev = src[i] * k + prev * (1 - k)
    if (i < len - 1) seed += src[i]
    // seed with SMA for Pine parity (ta.ema seeds internally with SMA-like)
    if (i >= len - 1) {
      if (i === len - 1 && len > 1) {
        // first value = SMA of first len values
        let s = 0
        for (let j = 0; j < len; j++) s += src[j]
        prev = s / len
      }
      out[i] = prev
    }
  }
  return out
}

export function rma(src: number[], len: number): Series {
  const out = nulls(src.length)
  if (src.length === 0 || len <= 0) return out
  let prev = 0
  for (let i = 0; i < src.length; i++) {
    if (i < len - 1) { prev += src[i]; continue }
    if (i === len - 1) {
      prev = (prev + src[i]) / len
    } else {
      prev = (prev * (len - 1) + src[i]) / len
    }
    out[i] = prev
  }
  return out
}

export function wma(src: number[], len: number): Series {
  const out = nulls(src.length)
  const denom = (len * (len + 1)) / 2
  for (let i = len - 1; i < src.length; i++) {
    let sum = 0
    for (let j = 0; j < len; j++) sum += src[i - j] * (len - j)
    out[i] = sum / denom
  }
  return out
}

function stdev(src: number[], len: number): Series {
  const out = nulls(src.length)
  for (let i = len - 1; i < src.length; i++) {
    let mean = 0
    for (let j = 0; j < len; j++) mean += src[i - j]
    mean /= len
    let v = 0
    for (let j = 0; j < len; j++) v += (src[i - j] - mean) ** 2
    out[i] = Math.sqrt(v / len)
  }
  return out
}

function highest(src: number[], len: number): Series {
  const out = nulls(src.length)
  for (let i = len - 1; i < src.length; i++) {
    let h = -Infinity
    for (let j = 0; j < len; j++) h = Math.max(h, src[i - j])
    out[i] = h
  }
  return out
}

function lowest(src: number[], len: number): Series {
  const out = nulls(src.length)
  for (let i = len - 1; i < src.length; i++) {
    let l = Infinity
    for (let j = 0; j < len; j++) l = Math.min(l, src[i - j])
    out[i] = l
  }
  return out
}

/** True range. */
function trueRange(c: CandleLike[]): number[] {
  const tr: number[] = []
  for (let i = 0; i < c.length; i++) {
    if (i === 0) { tr.push(c[0].high - c[0].low); continue }
    tr.push(Math.max(
      c[i].high - c[i].low,
      Math.abs(c[i].high - c[i - 1].close),
      Math.abs(c[i].low - c[i - 1].close),
    ))
  }
  return tr
}

function atr(c: CandleLike[], len: number): Series {
  return rma(trueRange(c), len)
}

/** Replace leading nulls, keep arrays aligned. */
function lineread(s: Series): number[] { return s.map((v) => (v == null ? NaN : v)) }

/** Apply SMA on an arbitrary Series (null-aware). */
function smaSeries(src: Series, len: number): Series {
  const clean = lineread(src)
  const out = nulls(src.length)
  let sum = 0, count = 0
  const win: number[] = []
  for (let i = 0; i < clean.length; i++) {
    if (Number.isFinite(clean[i])) {
      win.push(clean[i]); sum += clean[i]; count++
      if (win.length > len) { sum -= win.shift()!; count-- }
      if (count === len) out[i] = sum / len
    } else if (i >= len) {
      out[i] = out[i - 1] // extend across gaps
    }
  }
  return out
}

/** EMA over a Series with warm-up nulls (starts at first non-null). */
function emaSeries(src: Series, len: number): Series {
  const out = nulls(src.length)
  const k = 2 / (len + 1)
  let prev: number | null = null
  let warm = 0
  let seedSum = 0
  for (let i = 0; i < src.length; i++) {
    const v = src[i]
    if (v == null) continue
    if (prev == null) {
      seedSum += v; warm++
      if (warm === 1) prev = v
      if (warm >= len) {
        // SMA seed
        prev = seedSum / warm
        out[i] = prev
      }
    } else {
      prev = v * k + prev * (1 - k)
      out[i] = prev
    }
  }
  return out
}

/** RMA over a Series with warm-up nulls. */
function rmaSeries(src: Series, len: number): Series {
  const out = nulls(src.length)
  let prev: number | null = null
  let warm = 0
  let seedSum = 0
  for (let i = 0; i < src.length; i++) {
    const v = src[i]
    if (v == null) continue
    if (prev == null) {
      seedSum += v; warm++
      if (warm === 1) prev = v
      if (warm >= len) {
        prev = seedSum / warm
        out[i] = prev
      }
    } else {
      prev = (prev * (len - 1) + v) / len
      out[i] = prev
    }
  }
  return out
}

const closes = (c: CandleLike[]) => c.map((x) => x.close)
const highs = (c: CandleLike[]) => c.map((x) => x.high)
const lows = (c: CandleLike[]) => c.map((x) => x.low)
const opens = (c: CandleLike[]) => c.map((x) => x.open)
const volumes = (c: CandleLike[]) => c.map((x) => x.volume)
const hl2 = (c: CandleLike[]) => c.map((x) => (x.high + x.low) / 2)
const hlc3 = (c: CandleLike[]) => c.map((x) => (x.high + x.low + x.close) / 3)
const ohlc4 = (c: CandleLike[]) => c.map((x) => (x.open + x.high + x.low + x.close) / 4)

function sub(a: Series, b: Series): Series {
  return a.map((v, i) => (v == null || b[i] == null ? null : v - (b[i] as number)))
}
function add(a: Series, b: Series): Series {
  return a.map((v, i) => (v == null || b[i] == null ? null : v + (b[i] as number)))
}
function mulS(a: Series, k: number): Series {
  return a.map((v) => (v == null ? null : v * k))
}
function absS(a: Series): Series {
  return a.map((v) => (v == null ? null : Math.abs(v)))
}
function nz(v: number | null, d = 0): number { return v == null ? d : v }

/** Change between value and value `len` bars ago. */
function change(src: Series, len = 1): Series {
  return src.map((v, i) => (i < len || v == null || src[i - len] == null ? null : v - (src[i - len] as number)))
}

function dayKey(ts: number): number {
  return Math.floor(ts / 86400)
}

// ---------------------------------------------------------------------------
// Registry
// ---------------------------------------------------------------------------
export const INDICATORS: IndicatorDef[] = []
export const INDICATOR_MAP = new Map<string, IndicatorDef>()

function register(def: IndicatorDef) {
  INDICATORS.push(def)
  INDICATOR_MAP.set(def.id, def)
}


// ── Candlestick patterns (main pane) ───────────────────────────────────────
register({
  id: 'engulfing',
  name: 'Engulfing Candles',
  short: 'ENG',
  category: 'trend',
  pane: 'main',
  candleColoring: 'engulfing',
  params: [
    { key: 'wickMode', label: 'Wicks (0=ignore, 1=full, 2=one side)', default: 0, min: 0, max: 2, step: 1 },
    { key: 'minExpansion', label: 'Large body / small body', default: 1.20, min: 1.00, max: 3.00, step: 0.05 },
    { key: 'minLargeBodyPct', label: 'Large body / range', default: 0.55, min: 0.25, max: 0.95, step: 0.05 },
    { key: 'maxSmallBodyPct', label: 'Small body / range', default: 0.60, min: 0.15, max: 0.95, step: 0.05 },
    { key: 'minPenetration', label: 'Body penetration', default: 0.02, min: 0.00, max: 0.35, step: 0.01 },
    { key: 'minOppositeBodyPct', label: 'Opposite candle body / range', default: 0.15, min: 0.00, max: 0.70, step: 0.05 },
  ],
  plots: [
    { key: 'shortCandle', label: 'Short candle', type: 'line', color: '#FDD835', lineWidth: 1 },
    { key: 'longCandle', label: 'Long candle', type: 'line', color: '#000000', lineWidth: 1 },
  ],
  compute(candles, p) {
    const shortCandle = nulls(candles.length)
    const longCandle = nulls(candles.length)
    const wickMode = Math.round(p.wickMode ?? 0)
    const expansion = Math.max(1, p.minExpansion ?? 1.2)
    const minLargeBodyPct = Math.max(0, Math.min(1, p.minLargeBodyPct ?? 0.55))
    const maxSmallBodyPct = Math.max(0, Math.min(1, p.maxSmallBodyPct ?? 0.60))
    const penetration = Math.max(0, p.minPenetration ?? 0.02)
    const minOppositeBodyPct = Math.max(0, Math.min(1, p.minOppositeBodyPct ?? 0.15))

    const b = (c: CandleLike) => Math.abs(c.close - c.open)
    const r = (c: CandleLike) => Math.max(1e-12, c.high - c.low)
    const green = (c: CandleLike) => c.close > c.open
    const red = (c: CandleLike) => c.close < c.open
    const bodyPct = (c: CandleLike) => b(c) / r(c)
    const bullBody = (a: CandleLike, c: CandleLike) =>
      green(c) && red(a) && c.open <= a.close - r(a) * penetration && c.close >= a.open + r(a) * penetration
    const bearBody = (a: CandleLike, c: CandleLike) =>
      red(c) && green(a) && c.open >= a.close + r(a) * penetration && c.close <= a.open - r(a) * penetration
    const wickMatch = (a: CandleLike, c: CandleLike) => {
      const top = c.high >= a.high
      const bottom = c.low <= a.low
      return wickMode === 1 ? (top && bottom) : wickMode === 2 ? (top || bottom) : true
    }

    for (let i = 1; i < candles.length; i++) {
      const a = candles[i - 1], c = candles[i]
      const prevBody = b(a), currBody = b(c)
      if (prevBody <= 0 || currBody <= 0) continue // reject doji-as-engulfed false positives
      if (bodyPct(a) < minOppositeBodyPct || bodyPct(c) < minLargeBodyPct) continue
      if (currBody < prevBody * expansion) continue
      if (prevBody / r(a) > maxSmallBodyPct) continue

      const bodyMatch = bullBody(a, c) || bearBody(a, c)
      if (!bodyMatch || !wickMatch(a, c)) continue

      // Only one role per bar. In a pathological overlap, the newer/longer
      // candle has precedence over an earlier short role during rendering.
      shortCandle[i - 1] = 1
      longCandle[i] = 1
    }
    return { shortCandle, longCandle }
  },
})

// ── Moving averages (main pane) ────────────────────────────────────────────

register({
  id: 'sma', name: 'Moving Average Simple', short: 'SMA', category: 'moving-averages', pane: 'main',
  params: [{ key: 'length', label: 'Length', default: 20, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'sma', label: 'SMA', type: 'line', color: TV.blue, lineWidth: 2 }],
  compute(c, p) { return { sma: sma(closes(c), p.length) } },
})

register({
  id: 'ema', name: 'Moving Average Exponential', short: 'EMA', category: 'moving-averages', pane: 'main',
  params: [{ key: 'length', label: 'Length', default: 20, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'ema', label: 'EMA', type: 'line', color: TV.blue, lineWidth: 2 }],
  compute(c, p) { return { ema: ema(closes(c), p.length) } },
})

register({
  id: 'wma', name: 'Moving Average Weighted', short: 'WMA', category: 'moving-averages', pane: 'main',
  params: [{ key: 'length', label: 'Length', default: 20, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'wma', label: 'WMA', type: 'line', color: TV.blue, lineWidth: 2 }],
  compute(c, p) { return { wma: wma(closes(c), p.length) } },
})

register({
  id: 'hma', name: 'Hull Moving Average', short: 'HMA', category: 'moving-averages', pane: 'main',
  params: [{ key: 'length', label: 'Length', default: 20, min: 4, max: 500, step: 1 }],
  plots: [{ key: 'hma', label: 'HMA', type: 'line', color: TV.blue, lineWidth: 2 }],
  compute(c, p) {
    const n = Math.max(2, Math.floor(p.length / 2))
    const sqrtLen = Math.max(1, Math.floor(Math.sqrt(p.length)))
    const half = wma(closes(c), n)
    const full = wma(closes(c), p.length)
    const raw = sub(mulS(half, 2), full)
    return { hma: wma(lineread(raw).map((v) => (Number.isFinite(v) ? v : 0)), sqrtLen) }
  },
})

register({
  id: 'vwma', name: 'Volume Weighted Moving Average', short: 'VWMA', category: 'moving-averages', pane: 'main',
  params: [{ key: 'length', label: 'Length', default: 20, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'vwma', label: 'VWMA', type: 'line', color: TV.blue, lineWidth: 2 }],
  compute(c, p) {
    const out = nulls(c.length)
    let pv = 0, vv = 0
    const pvW: number[] = [], vvW: number[] = []
    for (let i = 0; i < c.length; i++) {
      const pvv = c[i].close * c[i].volume
      pvW.push(pvv); vvW.push(c[i].volume)
      pv += pvv; vv += c[i].volume
      if (pvW.length > p.length) { pv -= pvW.shift()!; vv -= vvW.shift()! }
      if (pvW.length === p.length && vv !== 0) out[i] = pv / vv
    }
    return { vwma: out }
  },
})

register({
  id: 'dema', name: 'Double EMA', short: 'DEMA', category: 'moving-averages', pane: 'main',
  params: [{ key: 'length', label: 'Length', default: 20, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'dema', label: 'DEMA', type: 'line', color: TV.blue, lineWidth: 2 }],
  compute(c, p) {
    const e1 = ema(closes(c), p.length)
    const e2 = emaSeries(e1, p.length)
    return { dema: sub(mulS(e1, 2), e2) }
  },
})

register({
  id: 'tema', name: 'Triple EMA', short: 'TEMA', category: 'moving-averages', pane: 'main',
  params: [{ key: 'length', label: 'Length', default: 20, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'tema', label: 'TEMA', type: 'line', color: TV.blue, lineWidth: 2 }],
  compute(c, p) {
    const e1 = ema(closes(c), p.length)
    const e2 = emaSeries(e1, p.length)
    const e3 = emaSeries(e2, p.length)
    const t1 = sub(mulS(e1, 3), mulS(e2, 3))
    return { tema: add(t1, e3) }
  },
})

register({
  id: 'lsma', name: 'Least Squares Moving Average', short: 'LSMA', category: 'moving-averages', pane: 'main',
  params: [{ key: 'length', label: 'Length', default: 25, min: 2, max: 500, step: 1 }],
  plots: [{ key: 'lsma', label: 'LSMA', type: 'line', color: TV.blue, lineWidth: 2 }],
  compute(c, p) {
    const src = closes(c)
    const out = nulls(c.length)
    const n = p.length
    for (let i = n - 1; i < src.length; i++) {
      let sx = 0, sy = 0, sxy = 0, sxx = 0
      for (let j = 0; j < n; j++) {
        const x = j, y = src[i - n + 1 + j]
        sx += x; sy += y; sxy += x * y; sxx += x * x
      }
      const slope = (n * sxy - sx * sy) / (n * sxx - sx * sx)
      const intercept = (sy - slope * sx) / n
      out[i] = intercept + slope * (n - 1)
    }
    return { lsma: out }
  },
})

// ── Bands & channels (main pane) ───────────────────────────────────────────

register({
  id: 'bb', name: 'Bollinger Bands', short: 'BB', category: 'trend', pane: 'main',
  params: [
    { key: 'length', label: 'Length', default: 20, min: 1, max: 500, step: 1 },
    { key: 'mult', label: 'StdDev', default: 2, min: 0.1, max: 10, step: 0.1 },
  ],
  plots: [
    { key: 'upper', label: 'Upper', type: 'line', color: TV.blue },
    { key: 'basis', label: 'Basis', type: 'line', color: TV.orange, dashed: true },
    { key: 'lower', label: 'Lower', type: 'line', color: TV.blue },
  ],
  compute(c, p) {
    const src = closes(c)
    const basis = sma(src, p.length)
    const dev = mulS(stdev(src, p.length), p.mult)
    return {
      basis,
      upper: add(basis, dev),
      lower: sub(basis, dev),
    }
  },
})

register({
  id: 'kc', name: 'Keltner Channels', short: 'KC', category: 'trend', pane: 'main',
  params: [
    { key: 'length', label: 'Length', default: 20, min: 1, max: 500, step: 1 },
    { key: 'mult', label: 'Multiplier', default: 2, min: 0.1, max: 10, step: 0.1 },
  ],
  plots: [
    { key: 'upper', label: 'Upper', type: 'line', color: TV.teal },
    { key: 'basis', label: 'Basis', type: 'line', color: TV.orange, dashed: true },
    { key: 'lower', label: 'Lower', type: 'line', color: TV.teal },
  ],
  compute(c, p) {
    const basis = ema(closes(c), p.length)
    const rng = mulS(atr(c, p.length), p.mult)
    return {
      basis,
      upper: add(basis, rng),
      lower: sub(basis, rng),
    }
  },
})

register({
  id: 'dc', name: 'Donchian Channels', short: 'DC', category: 'trend', pane: 'main',
  params: [{ key: 'length', label: 'Length', default: 20, min: 1, max: 500, step: 1 }],
  plots: [
    { key: 'upper', label: 'Upper', type: 'line', color: TV.blue },
    { key: 'basis', label: 'Basis', type: 'line', color: TV.orange, dashed: true },
    { key: 'lower', label: 'Lower', type: 'line', color: TV.blue },
  ],
  compute(c, p) {
    const upper = highest(highs(c), p.length)
    const lower = lowest(lows(c), p.length)
    return { upper, lower, basis: (function () {
      const out = nulls(c.length)
      for (let i = 0; i < c.length; i++) {
        if (upper[i] != null && lower[i] != null) out[i] = ((upper[i] as number) + (lower[i] as number)) / 2
      }
      return out
    })() }
  },
})

register({
  id: 'env', name: 'Envelopes', short: 'ENV', category: 'trend', pane: 'main',
  params: [
    { key: 'length', label: 'Length', default: 20, min: 1, max: 500, step: 1 },
    { key: 'percent', label: 'Percent', default: 10, min: 0.1, max: 100, step: 0.1 },
  ],
  plots: [
    { key: 'upper', label: 'Upper', type: 'line', color: TV.blue },
    { key: 'basis', label: 'Basis', type: 'line', color: TV.orange, dashed: true },
    { key: 'lower', label: 'Lower', type: 'line', color: TV.blue },
  ],
  compute(c, p) {
    const basis = sma(closes(c), p.length)
    const k = p.percent / 100
    const up = basis.map((v) => (v == null ? null : v * (1 + k)))
    const lo = basis.map((v) => (v == null ? null : v * (1 - k)))
    return { basis, upper: up, lower: lo }
  },
})

register({
  id: 'supertrend', name: 'SuperTrend', short: 'ST', category: 'trend', pane: 'main',
  params: [
    { key: 'atrPeriod', label: 'ATR Length', default: 10, min: 1, max: 100, step: 1 },
    { key: 'factor', label: 'Factor', default: 3, min: 0.1, max: 20, step: 0.1 },
  ],
  plots: [
    { key: 'up', label: 'Up', type: 'line', color: TV.green, lineWidth: 2 },
    { key: 'down', label: 'Down', type: 'line', color: TV.red, lineWidth: 2 },
  ],
  compute(c, p) {
    const n = c.length
    const up = nulls(n), down = nulls(n)
    const a = atr(c, p.atrPeriod)
    let trend = 1
    let prevUp = Infinity, prevDown = -Infinity
    for (let i = 0; i < n; i++) {
      if (a[i] == null) continue
      const hl2v = (c[i].high + c[i].low) / 2
      const band = p.factor * (a[i] as number)
      let upv = hl2v + band
      let dnv = hl2v - band
      if (i > 0 && a[i - 1] != null) {
        upv = (c[i - 1].close > prevUp) ? upv : Math.min(upv, prevUp)
        dnv = (c[i - 1].close < prevDown) ? dnv : Math.max(dnv, prevDown)
        if (c[i].close > prevUp) trend = 1
        else if (c[i].close < prevDown) trend = -1
      }
      prevUp = upv; prevDown = dnv
      if (trend === 1) { up[i] = dnv; down[i] = null }
      else { up[i] = null; down[i] = upv }
    }
    return { up, down }
  },
})

register({
  id: 'psar', name: 'Parabolic SAR', short: 'PSAR', category: 'trend', pane: 'main',
  params: [
    { key: 'start', label: 'Start', default: 0.02, min: 0.001, max: 0.5, step: 0.001 },
    { key: 'increment', label: 'Increment', default: 0.02, min: 0.001, max: 0.5, step: 0.001 },
    { key: 'max', label: 'Max Value', default: 0.2, min: 0.01, max: 1, step: 0.01 },
  ],
  plots: [{ key: 'psar', label: 'PSAR', type: 'line', color: TV.teal, lineWidth: 1 }],
  compute(c, p) {
    const n = c.length
    const out = nulls(n)
    if (n < 2) return { psar: out }
    let bull = c[1].close >= c[0].close
    let af = p.start
    let ep = bull ? c[0].high : c[0].low
    let sar = bull ? c[0].low : c[0].high
    for (let i = 1; i < n; i++) {
      sar = sar + af * (ep - sar)
      if (bull) {
        sar = Math.min(sar, c[i - 1].low, i > 1 ? c[i - 2].low : c[i - 1].low)
        if (c[i].high > ep) { ep = c[i].high; af = Math.min(p.max, af + p.increment) }
        if (c[i].low < sar) { bull = false; sar = ep; ep = c[i].low; af = p.start }
      } else {
        sar = Math.max(sar, c[i - 1].high, i > 1 ? c[i - 2].high : c[i - 1].high)
        if (c[i].low < ep) { ep = c[i].low; af = Math.min(p.max, af + p.increment) }
        if (c[i].high > sar) { bull = true; sar = ep; ep = c[i].high; af = p.start }
      }
      out[i] = sar
    }
    return { psar: out }
  },
})

register({
  id: 'ichimoku', name: 'Ichimoku Cloud', short: 'Ichimoku', category: 'trend', pane: 'main',
  params: [
    { key: 'conversion', label: 'Conversion Line', default: 9, min: 1, max: 200, step: 1 },
    { key: 'base', label: 'Base Line', default: 26, min: 1, max: 400, step: 1 },
    { key: 'spanB', label: 'Leading Span B', default: 52, min: 1, max: 600, step: 1 },
    { key: 'displacement', label: 'Lagging Span', default: 26, min: 1, max: 200, step: 1 },
  ],
  plots: [
    { key: 'tenkan', label: 'Conversion', type: 'line', color: TV.blue },
    { key: 'kijun', label: 'Base', type: 'line', color: TV.red },
    { key: 'senkouA', label: 'Span A', type: 'line', color: TV.green, displacement: 26 },
    { key: 'senkouB', label: 'Span B', type: 'line', color: TV.orange, displacement: 26 },
    { key: 'chikou', label: 'Lagging', type: 'line', color: TV.teal, displacement: -26 },
  ],
  compute(c, p) {
    const n = c.length
    const mid = (len: number): Series => {
      const out = nulls(n)
      const h = highest(highs(c), len)
      const l = lowest(lows(c), len)
      for (let i = 0; i < n; i++) {
        if (h[i] != null && l[i] != null) out[i] = ((h[i] as number) + (l[i] as number)) / 2
      }
      return out
    }
    const tenkan = mid(p.conversion)
    const kijun = mid(p.base)
    const spanB = mid(p.spanB)
    const senkouA = nulls(n)
    for (let i = 0; i < n; i++) {
      if (tenkan[i] != null && kijun[i] != null) senkouA[i] = ((tenkan[i] as number) + (kijun[i] as number)) / 2
    }
    const chikou = nulls(n)
    for (let i = 0; i < n; i++) {
      if (i + p.displacement < n) chikou[i] = c[i + p.displacement].close
    }
    return { tenkan, kijun, senkouA, senkouB: spanB, chikou }
  },
})

register({
  id: 'pivots', name: 'Pivot Points Standard', short: 'Pivot', category: 'trend', pane: 'main',
  params: [{ key: 'lookback', label: 'Bars per period', default: 96, min: 8, max: 2000, step: 1 }],
  plots: [
    { key: 'pp', label: 'PP', type: 'line', color: TV.blue },
    { key: 'r1', label: 'R1', type: 'line', color: TV.gray, dashed: true },
    { key: 's1', label: 'S1', type: 'line', color: TV.gray, dashed: true },
    { key: 'r2', label: 'R2', type: 'line', color: TV.gray, dashed: true },
    { key: 's2', label: 'S2', type: 'line', color: TV.gray, dashed: true },
  ],
  compute(c, p) {
    const n = c.length
    const mk = () => nulls(n)
    const out: Record<string, Series> = { pp: mk(), r1: mk(), s1: mk(), r2: mk(), s2: mk() }
    const per = Math.max(1, Math.floor(p.lookback))
    let periodStart = 0
    let H = -Infinity, L = Infinity, C = 0
    let piv: Record<string, number> | null = null
    for (let i = 0; i < n; i++) {
      const idxInPeriod = i - periodStart
      if (idxInPeriod > 0 && idxInPeriod % per === 0) {
        // close previous period → compute pivots for the new period
        const pp = (H + L + C) / 3
        piv = { pp, r1: 2 * pp - L, s1: 2 * pp - H, r2: pp + (H - L), s2: pp - (H - L) }
        periodStart = i
        H = -Infinity; L = Infinity
      }
      H = Math.max(H, c[i].high); L = Math.min(L, c[i].low); C = c[i].close
      if (piv) for (const k of Object.keys(piv)) out[k][i] = piv[k]
    }
    return out
  },
})

register({
  id: 'alligator', name: 'Alligator', short: 'Alligator', category: 'bill-williams', pane: 'main',
  params: [
    { key: 'jaw', label: 'Jaw Length', default: 13, min: 1, max: 200, step: 1 },
    { key: 'teeth', label: 'Teeth Length', default: 8, min: 1, max: 200, step: 1 },
    { key: 'lips', label: 'Lips Length', default: 5, min: 1, max: 200, step: 1 },
  ],
  plots: [
    { key: 'jaw', label: 'Jaw', type: 'line', color: TV.blue, displacement: 8 },
    { key: 'teeth', label: 'Teeth', type: 'line', color: TV.red, displacement: 5 },
    { key: 'lips', label: 'Lips', type: 'line', color: TV.green, displacement: 3 },
  ],
  compute(c, p) {
    const src = hl2(c)
    return {
      jaw: rma(src, p.jaw),
      teeth: rma(src, p.teeth),
      lips: rma(src, p.lips),
    }
  },
})

register({
  id: 'vwap', name: 'VWAP', short: 'VWAP', category: 'volume', pane: 'main',
  params: [{ key: 'anchor', label: 'Anchor (bars, 0=session)', default: 0, min: 0, max: 500, step: 1 }],
  plots: [{ key: 'vwap', label: 'VWAP', type: 'line', color: TV.blue, lineWidth: 2 }],
  compute(c, p) {
    const n = c.length
    const out = nulls(n)
    let pv = 0, vv = 0, lastDay = -1, bars = 0
    for (let i = 0; i < n; i++) {
      const day = dayKey(c[i].time)
      if (day !== lastDay) { lastDay = day; pv = 0; vv = 0; bars = 0 }
      if (p.anchor > 0 && bars >= p.anchor) { pv = 0; vv = 0; bars = 0 }
      const tp = (c[i].high + c[i].low + c[i].close) / 3
      pv += tp * c[i].volume
      vv += c[i].volume
      bars++
      if (vv > 0) out[i] = pv / vv
    }
    return { vwap: out }
  },
})

register({
  id: 'zigzag', name: 'ZigZag', short: 'ZigZag', category: 'trend', pane: 'main',
  params: [{ key: 'deviation', label: 'Deviation %', default: 5, min: 0.1, max: 50, step: 0.1 }],
  plots: [{ key: 'zz', label: 'ZigZag', type: 'line', color: TV.teal, lineWidth: 2 }],
  compute(c, p) {
    const n = c.length
    const out = nulls(n)
    if (n === 0) return { zz: out }
    const dev = p.deviation / 100
    out[0] = c[0].close
    let lastPivotIdx = 0
    let lastPivotVal = c[0].close
    let dir = 0 // 0 unknown, 1 up, -1 down
    for (let i = 1; i < n; i++) {
      const price = c[i].close
      if (dir === 0) {
        if (price >= lastPivotVal * (1 + dev)) { dir = 1; out[lastPivotIdx] = lastPivotVal; lastPivotIdx = i; lastPivotVal = price; out[i] = price }
        else if (price <= lastPivotVal * (1 - dev)) { dir = -1; out[lastPivotIdx] = lastPivotVal; lastPivotIdx = i; lastPivotVal = price; out[i] = price }
        else if ((dir === 0) && (price > lastPivotVal)) { lastPivotIdx = i; lastPivotVal = price }
        else if ((dir === 0) && (price < lastPivotVal)) { lastPivotIdx = i; lastPivotVal = price }
      } else if (dir === 1) {
        if (price > lastPivotVal) { lastPivotIdx = i; lastPivotVal = price }
        else if (price <= lastPivotVal * (1 - dev)) {
          out[lastPivotIdx] = lastPivotVal
          dir = -1; lastPivotIdx = i; lastPivotVal = price; out[i] = price
        }
      } else {
        if (price < lastPivotVal) { lastPivotIdx = i; lastPivotVal = price }
        else if (price >= lastPivotVal * (1 + dev)) {
          out[lastPivotIdx] = lastPivotVal
          dir = 1; lastPivotIdx = i; lastPivotVal = price; out[i] = price
        }
      }
    }
    // project live leg
    out[lastPivotIdx] = lastPivotVal
    out[n - 1] = c[n - 1].close
    return { zz: out }
  },
})

// ── Oscillators (separate panes) ───────────────────────────────────────────

function rsiCalc(src: number[], len: number): Series {
  const out = nulls(src.length)
  if (src.length === 0) return out
  let avgGain = 0, avgLoss = 0
  for (let i = 1; i < src.length; i++) {
    const ch = src[i] - src[i - 1]
    const g = ch > 0 ? ch : 0
    const l = ch < 0 ? -ch : 0
    if (i <= len) {
      avgGain = (avgGain * (i - 1) + g) / i
      avgLoss = (avgLoss * (i - 1) + l) / i
      if (i === len) out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss)
    } else {
      avgGain = (avgGain * (len - 1) + g) / len
      avgLoss = (avgLoss * (len - 1) + l) / len
      out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss)
    }
  }
  return out
}

register({
  id: 'rsi', name: 'Relative Strength Index', short: 'RSI', category: 'momentum', pane: 'separate',
  params: [{ key: 'length', label: 'Length', default: 14, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'rsi', label: 'RSI', type: 'line', color: TV.purple, lineWidth: 2 }],
  levels: [
    { value: 70, color: TV.red, dashed: true },
    { value: 50, color: TV.gray, dashed: true },
    { value: 30, color: TV.green, dashed: true },
  ],
  compute(c, p) { return { rsi: rsiCalc(closes(c), p.length) } },
})

register({
  id: 'stoch', name: 'Stochastic', short: 'Stoch', category: 'momentum', pane: 'separate',
  params: [
    { key: 'k', label: '%K Length', default: 14, min: 1, max: 500, step: 1 },
    { key: 'smooth', label: '%K Smoothing', default: 3, min: 1, max: 100, step: 1 },
    { key: 'd', label: '%D Smoothing', default: 3, min: 1, max: 100, step: 1 },
  ],
  plots: [
    { key: 'k', label: '%K', type: 'line', color: TV.blue, lineWidth: 2 },
    { key: 'd', label: '%D', type: 'line', color: TV.orange },
  ],
  levels: [
    { value: 80, color: TV.gray, dashed: true },
    { value: 20, color: TV.gray, dashed: true },
  ],
  compute(c, p) {
    const hh = highest(highs(c), p.k)
    const ll = lowest(lows(c), p.k)
    const raw: Series = c.map((_, i) =>
      hh[i] != null && ll[i] != null && (hh[i] as number) !== (ll[i] as number)
        ? 100 * (c[i].close - (ll[i] as number)) / ((hh[i] as number) - (ll[i] as number))
        : 50)
    const k = smaSeries(raw, p.smooth)
    return { k, d: smaSeries(k, p.d) }
  },
})

register({
  id: 'stochrsi', name: 'Stochastic RSI', short: 'Stoch RSI', category: 'momentum', pane: 'separate',
  params: [
    { key: 'rsiLen', label: 'RSI Length', default: 14, min: 1, max: 500, step: 1 },
    { key: 'stochLen', label: 'Stochastic Length', default: 14, min: 1, max: 500, step: 1 },
    { key: 'k', label: '%K', default: 3, min: 1, max: 100, step: 1 },
    { key: 'd', label: '%D', default: 3, min: 1, max: 100, step: 1 },
  ],
  plots: [
    { key: 'k', label: '%K', type: 'line', color: TV.blue, lineWidth: 2 },
    { key: 'd', label: '%D', type: 'line', color: TV.orange },
  ],
  levels: [
    { value: 80, color: TV.gray, dashed: true },
    { value: 20, color: TV.gray, dashed: true },
  ],
  compute(c, p) {
    const r = rsiCalc(closes(c), p.rsiLen)
    const hh = highestSeries(r, p.stochLen)
    const ll = lowestSeries(r, p.stochLen)
    const raw: Series = r.map((v, i) => {
      const h = hh[i], l = ll[i]
      if (v == null || h == null || l == null || h === l) return null
      return 100 * (v - l) / (h - l)
    })
    const k = smaSeries(raw, p.k)
    return { k, d: smaSeries(k, p.d) }
  },
})

function highestSeries(src: Series, len: number): Series {
  const out = nulls(src.length)
  for (let i = 0; i < src.length; i++) {
    if (src[i] == null) continue
    let started = false
    let h = -Infinity
    for (let j = Math.max(0, i - len + 1); j <= i; j++) {
      if (src[j] == null) break
      h = Math.max(h, src[j] as number); started = true
    }
    if (started && i - len + 1 >= 0) out[i] = h
  }
  return out
}

function lowestSeries(src: Series, len: number): Series {
  const out = nulls(src.length)
  for (let i = 0; i < src.length; i++) {
    if (src[i] == null) continue
    let started = false
    let l = Infinity
    for (let j = Math.max(0, i - len + 1); j <= i; j++) {
      if (src[j] == null) break
      l = Math.min(l, src[j] as number); started = true
    }
    if (started && i - len + 1 >= 0) out[i] = l
  }
  return out
}

register({
  id: 'macd', name: 'MACD', short: 'MACD', category: 'oscillators', pane: 'separate',
  params: [
    { key: 'fast', label: 'Fast Length', default: 12, min: 1, max: 500, step: 1 },
    { key: 'slow', label: 'Slow Length', default: 26, min: 1, max: 500, step: 1 },
    { key: 'signal', label: 'Signal Smoothing', default: 9, min: 1, max: 100, step: 1 },
  ],
  plots: [
    { key: 'macd', label: 'MACD', type: 'line', color: TV.blue, lineWidth: 2 },
    { key: 'signal', label: 'Signal', type: 'line', color: TV.orange },
    { key: 'hist', label: 'Histogram', type: 'histogram', color: TV.green, color2: TV.red, histMode: 'sign' },
  ],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const src = closes(c)
    const fast = ema(src, p.fast)
    const slow = ema(src, p.slow)
    const macd = sub(fast, slow)
    const signal = emaSeries(macd, p.signal)
    return { macd, signal, hist: sub(macd, signal) }
  },
})

register({
  id: 'ppo', name: 'Price Oscillator (Percentage)', short: 'PPO', category: 'oscillators', pane: 'separate',
  params: [
    { key: 'fast', label: 'Fast Length', default: 12, min: 1, max: 500, step: 1 },
    { key: 'slow', label: 'Slow Length', default: 26, min: 1, max: 500, step: 1 },
    { key: 'signal', label: 'Signal Smoothing', default: 9, min: 1, max: 100, step: 1 },
  ],
  plots: [
    { key: 'ppo', label: 'PPO', type: 'line', color: TV.blue, lineWidth: 2 },
    { key: 'signal', label: 'Signal', type: 'line', color: TV.orange },
    { key: 'hist', label: 'Histogram', type: 'histogram', color: TV.green, color2: TV.red, histMode: 'sign' },
  ],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const src = closes(c)
    const fast = ema(src, p.fast)
    const slow = ema(src, p.slow)
    const ppo: Series = src.map((_, i) => {
      if (fast[i] == null || slow[i] == null || (slow[i] as number) === 0) return null
      return 100 * ((fast[i] as number) - (slow[i] as number)) / (slow[i] as number)
    })
    const signal = emaSeries(ppo, p.signal)
    return { ppo, signal, hist: sub(ppo, signal) }
  },
})

register({
  id: 'apo', name: 'Absolute Price Oscillator', short: 'APO', category: 'oscillators', pane: 'separate',
  params: [
    { key: 'fast', label: 'Fast Length', default: 12, min: 1, max: 500, step: 1 },
    { key: 'slow', label: 'Slow Length', default: 26, min: 1, max: 500, step: 1 },
  ],
  plots: [{ key: 'apo', label: 'APO', type: 'line', color: TV.blue, lineWidth: 2 }],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const src = closes(c)
    return { apo: sub(ema(src, p.fast), ema(src, p.slow)) }
  },
})

register({
  id: 'cci', name: 'Commodity Channel Index', short: 'CCI', category: 'oscillators', pane: 'separate',
  params: [{ key: 'length', label: 'Length', default: 20, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'cci', label: 'CCI', type: 'line', color: TV.blue, lineWidth: 2 }],
  levels: [
    { value: 100, color: TV.gray, dashed: true },
    { value: 0, color: TV.gray, dashed: true },
    { value: -100, color: TV.gray, dashed: true },
  ],
  compute(c, p) {
    const tp = hlc3(c)
    const ma = sma(tp, p.length)
    const out = nulls(c.length)
    for (let i = p.length - 1; i < c.length; i++) {
      let md = 0
      for (let j = 0; j < p.length; j++) md += Math.abs(tp[i - j] - (ma[i] as number))
      md /= p.length
      out[i] = md === 0 ? 0 : (tp[i] - (ma[i] as number)) / (0.015 * md)
    }
    return { cci: out }
  },
})

register({
  id: 'willr', name: 'Williams %R', short: '%R', category: 'momentum', pane: 'separate',
  params: [{ key: 'length', label: 'Length', default: 14, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'wr', label: '%R', type: 'line', color: TV.blue, lineWidth: 2 }],
  levels: [
    { value: -20, color: TV.gray, dashed: true },
    { value: -80, color: TV.gray, dashed: true },
  ],
  compute(c, p) {
    const hh = highest(highs(c), p.length)
    const ll = lowest(lows(c), p.length)
    const out = nulls(c.length)
    for (let i = 0; i < c.length; i++) {
      const h = hh[i], l = ll[i]
      if (h == null || l == null || h === l) continue
      out[i] = -100 * ((h as number) - c[i].close) / ((h as number) - (l as number))
    }
    return { wr: out }
  },
})

register({
  id: 'roc', name: 'Rate of Change', short: 'ROC', category: 'momentum', pane: 'separate',
  params: [{ key: 'length', label: 'Length', default: 9, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'roc', label: 'ROC', type: 'line', color: TV.blue, lineWidth: 2 }],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const src = closes(c)
    const out = nulls(c.length)
    for (let i = p.length; i < c.length; i++) {
      const prev = src[i - p.length]
      if (prev !== 0) out[i] = 100 * (src[i] - prev) / prev
    }
    return { roc: out }
  },
})

register({
  id: 'mom', name: 'Momentum', short: 'Mom', category: 'momentum', pane: 'separate',
  params: [{ key: 'length', label: 'Length', default: 10, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'mom', label: 'Mom', type: 'line', color: TV.blue, lineWidth: 2 }],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const src = closes(c)
    const out = nulls(c.length)
    for (let i = p.length; i < c.length; i++) out[i] = src[i] - src[i - p.length]
    return { mom: out }
  },
})

register({
  id: 'uo', name: 'Ultimate Oscillator', short: 'UO', category: 'momentum', pane: 'separate',
  params: [
    { key: 'fast', label: 'Fast Period', default: 7, min: 1, max: 100, step: 1 },
    { key: 'mid', label: 'Middle Period', default: 14, min: 1, max: 200, step: 1 },
    { key: 'slow', label: 'Slow Period', default: 28, min: 1, max: 400, step: 1 },
  ],
  plots: [{ key: 'uo', label: 'UO', type: 'line', color: TV.purple, lineWidth: 2 }],
  levels: [
    { value: 70, color: TV.red, dashed: true },
    { value: 50, color: TV.gray, dashed: true },
    { value: 30, color: TV.green, dashed: true },
  ],
  compute(c, p) {
    const n = c.length
    const out = nulls(n)
    if (n === 0) return { uo: out }
    const bp: number[] = [0], tr: number[] = [c[0].high - c[0].low]
    for (let i = 1; i < n; i++) {
      const prevClose = c[i - 1].close
      bp.push(c[i].close - Math.min(c[i].low, prevClose))
      tr.push(Math.max(c[i].high, prevClose) - Math.min(c[i].low, prevClose))
    }
    const sumRange = (arr: number[], from: number, to: number): number => {
      let s = 0
      for (let i = Math.max(0, from); i <= to; i++) s += arr[i]
      return s
    }
    for (let i = p.slow - 1; i < n; i++) {
      const a1 = sumRange(bp, i - p.fast + 1, i) / sumRange(tr, i - p.fast + 1, i)
      const a2 = sumRange(bp, i - p.mid + 1, i) / sumRange(tr, i - p.mid + 1, i)
      const a3 = sumRange(bp, i - p.slow + 1, i) / sumRange(tr, i - p.slow + 1, i)
      out[i] = 100 * (a1 * 4 + a2 * 2 + a3) / 7
    }
    return { uo: out }
  },
})

register({
  id: 'ao', name: 'Awesome Oscillator', short: 'AO', category: 'bill-williams', pane: 'separate',
  params: [
    { key: 'fast', label: 'Fast Length', default: 5, min: 1, max: 200, step: 1 },
    { key: 'slow', label: 'Slow Length', default: 34, min: 1, max: 400, step: 1 },
  ],
  plots: [{ key: 'ao', label: 'AO', type: 'histogram', color: TV.green, color2: TV.red, histMode: 'direction' }],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const src = hl2(c)
    return { ao: sub(sma(src, p.fast), sma(src, p.slow)) }
  },
})

register({
  id: 'ac', name: 'Acceleration Oscillator', short: 'AC', category: 'bill-williams', pane: 'separate',
  params: [
    { key: 'fast', label: 'Fast Length', default: 5, min: 1, max: 200, step: 1 },
    { key: 'slow', label: 'Slow Length', default: 34, min: 1, max: 400, step: 1 },
  ],
  plots: [{ key: 'ac', label: 'AC', type: 'histogram', color: TV.green, color2: TV.red, histMode: 'direction' }],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const src = hl2(c)
    const ao = sub(sma(src, p.fast), sma(src, p.slow))
    return { ac: sub(ao, smaSeries(ao, 5)) }
  },
})

register({
  id: 'trix', name: 'TRIX', short: 'TRIX', category: 'oscillators', pane: 'separate',
  params: [
    { key: 'length', label: 'Length', default: 18, min: 1, max: 500, step: 1 },
    { key: 'signal', label: 'Signal Length', default: 9, min: 1, max: 100, step: 1 },
  ],
  plots: [
    { key: 'trix', label: 'TRIX', type: 'line', color: TV.blue, lineWidth: 2 },
    { key: 'signal', label: 'Signal', type: 'line', color: TV.orange },
  ],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const e1 = ema(closes(c), p.length)
    const e2 = emaSeries(e1, p.length)
    const e3 = emaSeries(e2, p.length)
    const trix: Series = e3.map((v, i) => {
      if (v == null || e2[i] == null || i === 0) return null
      const prev = e2[i - 1]
      if (prev == null || prev === 0) return null
      return 100 * (v - prev) / prev
    })
    void e1
    return { trix, signal: emaSeries(trix, p.signal) }
  },
})

register({
  id: 'bbp', name: 'Bull Bear Power', short: 'Bull/Bear', category: 'momentum', pane: 'separate',
  params: [{ key: 'length', label: 'Length', default: 13, min: 1, max: 500, step: 1 }],
  plots: [
    { key: 'bull', label: 'Bull', type: 'histogram', color: TV.green },
    { key: 'bear', label: 'Bear', type: 'histogram', color: TV.red },
  ],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const e = ema(closes(c), p.length)
    const bull: Series = c.map((x, i) => (e[i] == null ? null : x.high - (e[i] as number)))
    const bear: Series = c.map((x, i) => (e[i] == null ? null : x.low - (e[i] as number)))
    return { bull, bear }
  },
})

register({
  id: 'cmo', name: 'Chande Momentum Oscillator', short: 'CMO', category: 'oscillators', pane: 'separate',
  params: [{ key: 'length', label: 'Length', default: 9, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'cmo', label: 'CMO', type: 'line', color: TV.blue, lineWidth: 2 }],
  levels: [
    { value: 50, color: TV.gray, dashed: true },
    { value: 0, color: TV.gray, dashed: true },
    { value: -50, color: TV.gray, dashed: true },
  ],
  compute(c, p) {
    const src = closes(c)
    const out = nulls(src.length)
    for (let i = p.length; i < src.length; i++) {
      let su = 0, sd = 0
      for (let j = i - p.length + 1; j <= i; j++) {
        const d = src[j] - src[j - 1]
        if (d > 0) su += d; else sd -= d
      }
      out[i] = (su + sd) === 0 ? 0 : 100 * (su - sd) / (su + sd)
    }
    return { cmo: out }
  },
})

register({
  id: 'dmi', name: 'Directional Movement Index', short: 'DMI', category: 'trend', pane: 'separate',
  params: [
    { key: 'diLen', label: 'DI Length', default: 14, min: 1, max: 100, step: 1 },
    { key: 'adxSmoothing', label: 'ADX Smoothing', default: 14, min: 1, max: 100, step: 1 },
  ],
  plots: [
    { key: 'plusDI', label: '+DI', type: 'line', color: TV.green, lineWidth: 2 },
    { key: 'minusDI', label: '-DI', type: 'line', color: TV.red, lineWidth: 2 },
    { key: 'adx', label: 'ADX', type: 'line', color: TV.orange, lineWidth: 2 },
  ],
  levels: [{ value: 25, color: TV.gray, dashed: true }],
  compute(c, p) {
    const n = c.length
    const plusDM: number[] = [0], minusDM: number[] = [0]
    for (let i = 1; i < n; i++) {
      const up = c[i].high - c[i - 1].high
      const dn = c[i - 1].low - c[i].low
      plusDM.push(up > dn && up > 0 ? up : 0)
      minusDM.push(dn > up && dn > 0 ? dn : 0)
    }
    const tr = trueRange(c)
    const trS = rma(tr, p.diLen)
    const plusS = rma(plusDM, p.diLen)
    const minusS = rma(minusDM, p.diLen)
    const plusDI: Series = nulls(n), minusDI: Series = nulls(n), dx: Series = nulls(n)
    for (let i = 0; i < n; i++) {
      if (trS[i] == null || (trS[i] as number) === 0) continue
      plusDI[i] = 100 * (plusS[i] as number) / (trS[i] as number)
      minusDI[i] = 100 * (minusS[i] as number) / (trS[i] as number)
      const s = (plusDI[i] as number) + (minusDI[i] as number)
      dx[i] = s === 0 ? 0 : 100 * Math.abs((plusDI[i] as number) - (minusDI[i] as number)) / s
    }
    return { plusDI, minusDI, adx: rmaSeries(dx, p.adxSmoothing) }
  },
})

register({
  id: 'aroon', name: 'Aroon', short: 'Aroon', category: 'trend', pane: 'separate',
  params: [{ key: 'length', label: 'Length', default: 14, min: 1, max: 200, step: 1 }],
  plots: [
    { key: 'up', label: 'Up', type: 'line', color: TV.green, lineWidth: 2 },
    { key: 'down', label: 'Down', type: 'line', color: TV.red, lineWidth: 2 },
  ],
  levels: [
    { value: 70, color: TV.gray, dashed: true },
    { value: 30, color: TV.gray, dashed: true },
  ],
  compute(c, p) {
    const n = c.length
    const up = nulls(n), down = nulls(n)
    const hh = highest(highs(c), p.length)
    const ll = lowest(lows(c), p.length)
    for (let i = p.length - 1; i < n; i++) {
      let bsHigh = 0, bsLow = 0
      for (let j = 0; j < p.length; j++) {
        if (c[i - j].high === hh[i]) bsHigh = j
        if (c[i - j].low === ll[i]) bsLow = j
      }
      up[i] = 100 * (p.length - bsHigh) / p.length
      down[i] = 100 * (p.length - bsLow) / p.length
    }
    return { up, down }
  },
})

register({
  id: 'bop', name: 'Balance of Power', short: 'BOP', category: 'oscillators', pane: 'separate',
  params: [{ key: 'length', label: 'Smoothing Length', default: 14, min: 1, max: 200, step: 1 }],
  plots: [{ key: 'bop', label: 'BOP', type: 'histogram', color: TV.green, color2: TV.red, histMode: 'sign' }],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const raw: Series = c.map((x) => {
      const range = x.high - x.low
      return range === 0 ? 0 : (x.close - x.open) / range
    })
    return { bop: smaSeries(raw, p.length) }
  },
})

register({
  id: 'rvgi', name: 'Relative Vigor Index', short: 'RVGI', category: 'oscillators', pane: 'separate',
  params: [{ key: 'length', label: 'Length', default: 10, min: 1, max: 200, step: 1 }],
  plots: [
    { key: 'rvgi', label: 'RVGI', type: 'line', color: TV.blue, lineWidth: 2 },
    { key: 'signal', label: 'Signal', type: 'line', color: TV.orange },
  ],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const n = c.length
    const rvgi = nulls(n), signal = nulls(n)
    const calc = (i: number): number => {
      let co = 0, hl = 0
      for (let j = 0; j < p.length; j++) {
        const k = i - j
        co += c[k].close - c[k].open
        hl += c[k].high - c[k].low
      }
      return hl === 0 ? 0 : co / hl
    }
    for (let i = p.length - 1; i < n; i++) rvgi[i] = calc(i)
    for (let i = p.length + 2; i < n; i++) {
      const v1 = rvgi[i], v2 = rvgi[i - 1], v3 = rvgi[i - 2], v4 = rvgi[i - 3]
      if (v1 == null || v2 == null || v3 == null || v4 == null) continue
      signal[i] = (v1 + 2 * v2 + 2 * v3 + v4) / 6
    }
    return { rvgi, signal }
  },
})

// ── Volume indicators ──────────────────────────────────────────────────────

register({
  id: 'volume', name: 'Volume', short: 'Vol', category: 'volume', pane: 'main',
  params: [
    { key: 'maLength', label: 'MA Length', default: 20, min: 1, max: 200, step: 1 },
    { key: 'maType', label: 'MA Type (0=SMA 1=EMA)', default: 0, min: 0, max: 1, step: 1 },
  ],
  plots: [
    { key: 'vol', label: 'Volume', type: 'histogram', color: 'rgba(100, 181, 246, 0.55)' },
    { key: 'ma', label: 'Vol MA', type: 'line', color: TV.yellow, lineWidth: 1 },
  ],
  compute(c, p) {
    const v = volumes(c)
    return {
      vol: v as Series,
      ma: p.maType === 1 ? ema(v, p.maLength) : sma(v, p.maLength),
    }
  },
})

register({
  id: 'obv', name: 'On Balance Volume', short: 'OBV', category: 'volume', pane: 'separate',
  params: [],
  plots: [{ key: 'obv', label: 'OBV', type: 'line', color: TV.blue, lineWidth: 2 }],
  compute(c) {
    const out = nulls(c.length)
    let v = 0
    for (let i = 0; i < c.length; i++) {
      if (i > 0) {
        if (c[i].close > c[i - 1].close) v += c[i].volume
        else if (c[i].close < c[i - 1].close) v -= c[i].volume
      } else v = c[0].volume
      out[i] = v
    }
    return { obv: out }
  },
})

register({
  id: 'mfi', name: 'Money Flow Index', short: 'MFI', category: 'volume', pane: 'separate',
  params: [{ key: 'length', label: 'Length', default: 14, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'mfi', label: 'MFI', type: 'line', color: TV.purple, lineWidth: 2 }],
  levels: [
    { value: 80, color: TV.red, dashed: true },
    { value: 50, color: TV.gray, dashed: true },
    { value: 20, color: TV.green, dashed: true },
  ],
  compute(c, p) {
    const n = c.length
    const out = nulls(n)
    const tp = hlc3(c)
    for (let i = p.length; i < n; i++) {
      let pos = 0, neg = 0
      for (let j = i - p.length + 1; j <= i; j++) {
        const flow = tp[j] * c[j].volume
        if (tp[j] > tp[j - 1]) pos += flow
        else if (tp[j] < tp[j - 1]) neg += flow
      }
      out[i] = neg === 0 ? 100 : 100 - 100 / (1 + pos / neg)
    }
    return { mfi: out }
  },
})

register({
  id: 'cmf', name: 'Chaikin Money Flow', short: 'CMF', category: 'volume', pane: 'separate',
  params: [{ key: 'length', label: 'Length', default: 20, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'cmf', label: 'CMF', type: 'line', color: TV.blue, lineWidth: 2 }],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const n = c.length
    const out = nulls(n)
    for (let i = p.length - 1; i < n; i++) {
      let mfv = 0, vol = 0
      for (let j = i - p.length + 1; j <= i; j++) {
        const range = c[j].high - c[j].low
        const mult = range === 0 ? 0 : ((c[j].close - c[j].low) - (c[j].high - c[j].close)) / range
        mfv += mult * c[j].volume
        vol += c[j].volume
      }
      out[i] = vol === 0 ? 0 : mfv / vol
    }
    return { cmf: out }
  },
})

register({
  id: 'chaikinosc', name: 'Chaikin Oscillator', short: 'Chaikin Osc', category: 'volume', pane: 'separate',
  params: [
    { key: 'fast', label: 'Fast Length', default: 3, min: 1, max: 100, step: 1 },
    { key: 'slow', label: 'Slow Length', default: 10, min: 1, max: 200, step: 1 },
  ],
  plots: [{ key: 'co', label: 'Chaikin Osc', type: 'line', color: TV.blue, lineWidth: 2 }],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const n = c.length
    const adl: Series = nulls(n)
    let cum = 0
    for (let i = 0; i < n; i++) {
      const range = c[i].high - c[i].low
      const mult = range === 0 ? 0 : ((c[i].close - c[i].low) - (c[i].high - c[i].close)) / range
      cum += mult * c[i].volume
      adl[i] = cum
    }
    return { co: sub(emaSeries(adl, p.fast), emaSeries(adl, p.slow)) }
  },
})

register({
  id: 'volosc', name: 'Volume Oscillator', short: 'Vol Osc', category: 'volume', pane: 'separate',
  params: [
    { key: 'fast', label: 'Fast Length', default: 5, min: 1, max: 200, step: 1 },
    { key: 'slow', label: 'Slow Length', default: 10, min: 1, max: 400, step: 1 },
  ],
  plots: [{ key: 'vo', label: 'Vol Osc %', type: 'histogram', color: TV.green, color2: TV.red, histMode: 'sign' }],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const v = volumes(c)
    const f = ema(v, p.fast), s = ema(v, p.slow)
    const out: Series = v.map((_, i) => {
      if (f[i] == null || s[i] == null || (s[i] as number) === 0) return null
      return 100 * ((f[i] as number) - (s[i] as number)) / (s[i] as number)
    })
    return { vo: out }
  },
})

register({
  id: 'klinger', name: 'Klinger Volume Oscillator', short: 'KVO', category: 'volume', pane: 'separate',
  params: [
    { key: 'fast', label: 'Fast EMA', default: 34, min: 1, max: 200, step: 1 },
    { key: 'slow', label: 'Slow EMA', default: 55, min: 1, max: 400, step: 1 },
    { key: 'signal', label: 'Signal EMA', default: 13, min: 1, max: 100, step: 1 },
  ],
  plots: [
    { key: 'kvo', label: 'KVO', type: 'line', color: TV.blue, lineWidth: 2 },
    { key: 'signal', label: 'Signal', type: 'line', color: TV.orange },
  ],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const n = c.length
    const vf: number[] = []
    for (let i = 0; i < n; i++) {
      if (i === 0) { vf.push(0); continue }
      const trend = (c[i].high + c[i].low) > (c[i - 1].high + c[i - 1].low) ? 1 : -1
      const dm = c[i].high - c[i].low
      vf.push(trend * dm * c[i].volume * 100)
    }
    const fast = ema(vf, p.fast), slow = ema(vf, p.slow)
    const kvo = sub(fast, slow)
    return { kvo, signal: emaSeries(kvo, p.signal) }
  },
})

register({
  id: 'netvolume', name: 'Net Volume', short: 'Net Vol', category: 'volume', pane: 'separate',
  params: [],
  plots: [{ key: 'nv', label: 'Net Volume', type: 'histogram', color: TV.green, color2: TV.red, histMode: 'sign' }],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c) {
    const out: Series = c.map((x) => x.close >= x.open ? x.volume : -x.volume)
    return { nv: out }
  },
})

register({
  id: 'bwmfi', name: 'Market Facilitation Index', short: 'BW MFI', category: 'bill-williams', pane: 'separate',
  params: [],
  plots: [{ key: 'mfi', label: 'BW MFI', type: 'histogram', color: TV.teal }],
  compute(c) {
    const out: Series = c.map((x) => {
      const range = x.high - x.low
      return range === 0 ? 0 : range / (x.volume === 0 ? 1 : x.volume) * 1e6
    })
    return { mfi: out }
  },
})

register({
  id: 'gator', name: 'Gator Oscillator', short: 'Gator', category: 'bill-williams', pane: 'separate',
  params: [
    { key: 'jaw', label: 'Jaw Length', default: 13, min: 1, max: 200, step: 1 },
    { key: 'teeth', label: 'Teeth Length', default: 8, min: 1, max: 200, step: 1 },
    { key: 'lips', label: 'Lips Length', default: 5, min: 1, max: 200, step: 1 },
  ],
  plots: [
    { key: 'up', label: 'Upper', type: 'histogram', color: TV.green },
    { key: 'down', label: 'Lower', type: 'histogram', color: TV.red },
  ],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const src = hl2(c)
    const jaw = rma(src, p.jaw)
    const teeth = rma(src, p.teeth)
    const lips = rma(src, p.lips)
    const up = absS(sub(jaw, teeth))
    const down = mulS(absS(sub(teeth, lips)), -1)
    return { up, down }
  },
})

// ── Volatility indicators ──────────────────────────────────────────────────

register({
  id: 'atr', name: 'Average True Range', short: 'ATR', category: 'volatility', pane: 'separate',
  params: [{ key: 'length', label: 'Length', default: 14, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'atr', label: 'ATR', type: 'line', color: TV.blue, lineWidth: 2 }],
  compute(c, p) { return { atr: atr(c, p.length) } },
})

register({
  id: 'stddev', name: 'Standard Deviation', short: 'StdDev', category: 'volatility', pane: 'separate',
  params: [{ key: 'length', label: 'Length', default: 20, min: 1, max: 500, step: 1 }],
  plots: [{ key: 'sd', label: 'StdDev', type: 'line', color: TV.blue, lineWidth: 2 }],
  compute(c, p) { return { sd: stdev(closes(c), p.length) } },
})

register({
  id: 'hv', name: 'Historical Volatility', short: 'HV', category: 'volatility', pane: 'separate',
  params: [
    { key: 'length', label: 'Length', default: 10, min: 1, max: 500, step: 1 },
    { key: 'annualize', label: 'Annualization (bars/yr)', default: 252, min: 1, max: 100000, step: 1 },
  ],
  plots: [{ key: 'hv', label: 'HV', type: 'line', color: TV.blue, lineWidth: 2 }],
  compute(c, p) {
    const n = c.length
    const logret: Series = nulls(n)
    for (let i = 1; i < n; i++) {
      if (c[i - 1].close > 0) logret[i] = Math.log(c[i].close / c[i - 1].close)
    }
    const sd = stdev(lineread(logret).map((v) => (Number.isFinite(v) ? v : 0)), p.length)
    const k = Math.sqrt(p.annualize)
    return { hv: mulS(sd, 100 * k) }
  },
})

register({
  id: 'chaikinvol', name: 'Chaikin Volatility', short: 'Chaikin Vol', category: 'volatility', pane: 'separate',
  params: [
    { key: 'length', label: 'EMA Length', default: 10, min: 1, max: 200, step: 1 },
    { key: 'roc', label: 'ROC Length', default: 10, min: 1, max: 200, step: 1 },
  ],
  plots: [{ key: 'cv', label: 'Chaikin Vol', type: 'line', color: TV.blue, lineWidth: 2 }],
  levels: [{ value: 0, color: TV.gray, dashed: true }],
  compute(c, p) {
    const hl = c.map((x) => x.high - x.low)
    const e = ema(hl, p.length)
    const out: Series = nulls(c.length)
    for (let i = p.length + p.roc - 1; i < c.length; i++) {
      const prev = e[i - p.roc]
      if (prev == null || prev === 0 || e[i] == null) continue
      out[i] = 100 * ((e[i] as number) - prev) / prev
    }
    return { cv: out }
  },
})

register({
  id: 'massindex', name: 'Mass Index', short: 'MI', category: 'volatility', pane: 'separate',
  params: [{ key: 'length', label: 'Length', default: 25, min: 1, max: 200, step: 1 }],
  plots: [{ key: 'mi', label: 'MI', type: 'line', color: TV.blue, lineWidth: 2 }],
  levels: [{ value: 27, color: TV.gray, dashed: true }],
  compute(c, p) {
    const n = c.length
    const hl = c.map((x) => x.high - x.low)
    const e1 = ema(hl, 9)
    const e2 = emaSeries(e1, 9)
    const ratio: Series = e1.map((v, i) => {
      if (v == null || e2[i] == null || (e2[i] as number) === 0) return null
      return v / (e2[i] as number)
    })
    const out = nulls(n)
    for (let i = 0; i < n; i++) {
      let s = 0, ok = true
      for (let j = 0; j < p.length; j++) {
        const r = ratio[i - j]
        if (i - j < 0 || r == null) { ok = false; break }
        s += r
      }
      if (ok) out[i] = s
    }
    return { mi: out }
  },
})


register({
  id: 'wave-trend-resonance',
  name: 'WaveTrend Resonance',
  short: 'WTR',
  category: 'oscillators',
  // WTR is a causal NEXT-CANDLE predictor. The arrow drawn on candle i is
  // computed only from candles <= i-1, i.e. from information available when
  // candle i opens. No future candle participates in the prediction.
  pane: 'main',
  params: [
    { key: 'channelPeriod', label: 'WT Channel', default: 10, min: 3, max: 50, step: 1 },
    { key: 'signalPeriod', label: 'WT Signal', default: 4, min: 2, max: 12, step: 1 },
    { key: 'neighbors', label: 'Similar Setups', default: 17, min: 5, max: 40, step: 1 },
    { key: 'historyWindow', label: 'Learning Window', default: 320, min: 80, max: 800, step: 20 },
    { key: 'threshold', label: 'Confidence Threshold', default: 0.62, min: 0.51, max: 0.90, step: 0.01 },
  ],
  plots: [
    { key: 'buy', label: 'WTR CALL • NEXT CANDLE', type: 'line', color: TV.green, marker: 'arrowUp' },
    { key: 'sell', label: 'WTR PUT • NEXT CANDLE', type: 'line', color: TV.red, marker: 'arrowDown' },
  ],
  compute(c, p) {
    const n = c.length
    const buy = nulls(n)
    const sell = nulls(n)

    const cp = Math.max(3, Math.round(p.channelPeriod))
    const sp = Math.max(2, Math.round(p.signalPeriod))
    const kNeighbors = Math.max(5, Math.round(p.neighbors))
    const history = Math.max(80, Math.round(p.historyWindow))
    const threshold = Math.min(0.90, Math.max(0.51, Number(p.threshold ?? 0.62)))

    // We need enough bars for WaveTrend + a meaningful historical sample.
    const minWarm = Math.max(40, cp * 4 + sp * 3)
    if (n < minWarm + 2) return { buy, sell }

    // -----------------------------------------------------------------------
    // 1) Standard WaveTrend oscillator.
    //    This is materially closer to the canonical WT construction than the
    //    previous "close - EMA(midprice)" shortcut:
    //    TP -> ESA -> deviation -> CI -> WT1/WT2.
    // -----------------------------------------------------------------------
    const tp = c.map(x => (x.high + x.low + x.close) / 3)
    const esa = ema(tp, cp)
    const absDev = tp.map((v, i) => esa[i] == null ? null : Math.abs(v - (esa[i] as number)))
    const dev = emaSeries(absDev, cp)
    const ci: Series = nulls(n)
    for (let i = 0; i < n; i++) {
      if (esa[i] == null || dev[i] == null) continue
      const d = Math.max(Math.abs(dev[i] as number), 1e-12)
      ci[i] = (tp[i] - (esa[i] as number)) / (0.015 * d)
    }
    const wt1 = emaSeries(ci, sp)
    const wt2 = smaSeries(wt1, 4)

    // -----------------------------------------------------------------------
    // 2) Causal feature extraction.
    //    Feature at bar j only uses candles <= j.
    // -----------------------------------------------------------------------
    const closes = c.map(x => x.close)
    const opens = c.map(x => x.open)
    const ranges = c.map(x => Math.max(x.high - x.low, 1e-12))
    const tr = trueRange(c)
    const atr14 = ema(tr, 14)
    const ema8 = ema(closes, 8)
    const ema21 = ema(closes, 21)

    const rsiSeries = (len: number): Series => {
      const out = nulls(n)
      if (n <= len) return out
      let gain = 0
      let loss = 0
      for (let i = 1; i < n; i++) {
        const d = closes[i] - closes[i - 1]
        const g = Math.max(0, d)
        const l = Math.max(0, -d)
        if (i <= len) {
          gain += g
          loss += l
          if (i === len) {
            gain /= len
            loss /= len
            const rs = loss <= 1e-12 ? 100 : gain / loss
            out[i] = 100 - (100 / (1 + rs))
          }
        } else {
          gain = (gain * (len - 1) + g) / len
          loss = (loss * (len - 1) + l) / len
          const rs = loss <= 1e-12 ? 100 : gain / loss
          out[i] = 100 - (100 / (1 + rs))
        }
      }
      return out
    }
    const rsi14 = rsiSeries(14)

    type Feature = number[]
    const featureAt = (j: number): Feature | null => {
      if (j < minWarm) return null
      const a = Math.max(atr14[j] ?? 0, 1e-12)
      const r = ranges[j]
      const body = closes[j] - opens[j]
      const upper = Math.max(0, c[j].high - Math.max(opens[j], closes[j]))
      const lower = Math.max(0, Math.min(opens[j], closes[j]) - c[j].low)
      const ret = (lag: number) => {
        const k = j - lag
        return k >= 0 && Math.abs(closes[k]) > 1e-12 ? closes[j] / closes[k] - 1 : 0
      }
      const wt = wt1[j] ?? 0
      const sig = wt2[j] ?? wt
      const wtSlope = j > 0 ? (wt1[j - 1] == null ? 0 : wt - (wt1[j - 1] as number)) : 0
      const wtSpread = wt - sig
      const e8 = ema8[j] ?? closes[j]
      const e21 = ema21[j] ?? closes[j]
      const e8Prev = j > 0 ? (ema8[j - 1] ?? e8) : e8
      const volRatio = r / a
      const closePos = (closes[j] - c[j].low) / r
      const rsi = rsi14[j] == null ? 50 : (rsi14[j] as number)

      return [
        Math.tanh(wt / 150),
        Math.tanh(wtSpread / 60),
        Math.tanh(wtSlope / 50),
        Math.tanh((tp[j] - (esa[j] ?? tp[j])) / a),
        Math.tanh((e8 - e21) / a),
        Math.tanh((e8 - e8Prev) / a),
        Math.tanh(ret(1) / Math.max(a / Math.max(closes[j], 1e-12), 1e-6)),
        Math.tanh(ret(2) / Math.max(a / Math.max(closes[j], 1e-12), 1e-6)),
        Math.tanh(ret(3) / Math.max(a / Math.max(closes[j], 1e-12), 1e-6)),
        Math.tanh(ret(5) / Math.max(a / Math.max(closes[j], 1e-12), 1e-6)),
        Math.tanh(body / a),
        upper / r,
        lower / r,
        closePos * 2 - 1,
        Math.tanh(volRatio - 1),
        (rsi - 50) / 50,
      ]
    }

    const features: Array<Feature | null> = new Array(n).fill(null)
    for (let i = minWarm; i < n; i++) features[i] = featureAt(i)

    // -----------------------------------------------------------------------
    // 3) Similar-setup learning (causal kNN).
    //
    // Training sample j is:
    //   X_j = state visible at close(j)
    //   y_j = direction of candle(j+1)
    //
    // Therefore, when predicting candle i we only train on j <= i-2. This
    // prevents the current candle i from leaking into its own prediction.
    // -----------------------------------------------------------------------
    const predictionForOpen = (i: number): number | null => {
      const source = i - 1 // last fully closed candle
      if (source < minWarm) return null
      const current = features[source]
      if (!current) return null

      const begin = Math.max(minWarm, source - history + 1)
      const training: Array<{ d: number; y: number; age: number }> = []

      // Standardize each feature using ONLY the eligible training history.
      const dims = current.length
      const means = new Array<number>(dims).fill(0)
      const vars = new Array<number>(dims).fill(0)
      let count = 0

      for (let j = begin; j <= source - 1; j++) {
        const f = features[j]
        if (!f || j + 1 >= n) continue
        for (let d = 0; d < dims; d++) means[d] += f[d]
        count++
      }
      if (count < Math.max(30, kNeighbors * 2)) return null
      for (let d = 0; d < dims; d++) means[d] /= count

      for (let j = begin; j <= source - 1; j++) {
        const f = features[j]
        if (!f || j + 1 >= n) continue
        for (let d = 0; d < dims; d++) {
          const z = f[d] - means[d]
          vars[d] += z * z
        }
      }
      for (let d = 0; d < dims; d++) vars[d] = Math.max(Math.sqrt(vars[d] / Math.max(count - 1, 1)), 1e-6)

      for (let j = begin; j <= source - 1; j++) {
        const f = features[j]
        if (!f || j + 1 >= n) continue
        let dist2 = 0
        for (let d = 0; d < dims; d++) {
          const z = (f[d] - means[d]) / vars[d]
          dist2 += z * z
        }
        const y = Math.sign(closes[j + 1] - closes[j])
        if (y === 0) continue

        // Mild recency preference: recent market regimes matter more, but the
        // similarity score remains the dominant criterion.
        const age = source - j
        training.push({ d: Math.sqrt(dist2), y, age })
      }

      if (training.length < Math.max(30, kNeighbors * 2)) return null
      training.sort((a, b) => a.d - b.d)
      const k = Math.min(kNeighbors, training.length)

      let bull = 0
      let bear = 0
      let weightSum = 0
      let neighborAgree = 0

      for (let z = 0; z < k; z++) {
        const item = training[z]
        const similarity = 1 / (1 + item.d * item.d)
        const recency = Math.exp(-item.age / Math.max(history * 0.65, 1))
        const w = similarity * (0.75 + 0.25 * recency)
        if (item.y > 0) bull += w
        else bear += w
        weightSum += w
      }

      if (weightSum <= 0) return null

      let pBull = bull / weightSum

      // A small independent WT prior stabilizes the prediction when the local
      // neighbor sample is close to 50/50. It is intentionally weak so the
      // model does not collapse back into "oscillator direction = prediction".
      const cw = current[0]
      const cs = current[1]
      const trendPrior = Math.max(-1, Math.min(1,
        0.55 * cw +
        0.30 * cs +
        0.15 * current[2]
      ))
      pBull = 0.84 * pBull + 0.16 * (0.5 + 0.5 * trendPrior)

      const confidence = Math.max(pBull, 1 - pBull)

      // Agreement bonus requires actual top-neighbor consensus rather than a
      // persistent lastDirection latch.
      for (let z = 0; z < k; z++) {
        if ((pBull >= 0.5 && training[z].y > 0) || (pBull < 0.5 && training[z].y < 0)) {
          neighborAgree++
        }
      }
      const agreement = neighborAgree / Math.max(k, 1)
      const finalConfidence = 0.78 * confidence + 0.22 * agreement

      if (finalConfidence < threshold) return 0.5
      return pBull >= 0.5 ? finalConfidence : 1 - finalConfidence
    }

    // -----------------------------------------------------------------------
    // 4) Emit an arrow on candle i = the candle being predicted.
    //    The value itself is only a visual anchor; the direction is decided
    //    before candle i has a close.
    // -----------------------------------------------------------------------
    for (let i = minWarm + 1; i < n; i++) {
      const prediction = predictionForOpen(i)
      if (prediction == null || prediction === 0.5) continue

      if (prediction > 0.5) buy[i] = c[i].low
      else sell[i] = c[i].high
    }

    return { buy, sell }
  },
})

register({
  id: 'fractal-trigonometric-forecast',
  name: 'Fractal Trigonometric Forecast',
  short: 'FTFP',
  category: 'bill-williams',
  pane: 'main',
  params: [
    { key: 'threshold', label: 'Seuil trigonométrique', default: 0.45, min: 0.10, max: 1.20, step: 0.05 },
    { key: 'projection', label: 'Projection phase', default: 1.00, min: 0.10, max: 2.00, step: 0.10 },
  ],
  plots: [
    { key: 'ema13', label: 'FTFP EMA 13', type: 'line', color: '#00E676', lineWidth: 2 },
    { key: 'ema34', label: 'FTFP EMA 34', type: 'line', color: '#FFB300', lineWidth: 2 },
    { key: 'visual', label: 'FTFP FORECAST', type: 'line', color: '#00B0FF', lineWidth: 2 },
    { key: 'predict', label: 'FTFP TRIGONOMETRIC WAVE', type: 'line', color: '#E040FB', lineWidth: 1 },
    { key: 'call', label: 'FTFP CALL', type: 'line', color: '#00E676', marker: 'arrowUp' },
    { key: 'put', label: 'FTFP PUT', type: 'line', color: '#FF1744', marker: 'arrowDown' },
  ],
  compute(c, p) {
    // Les résultats typés (shared/*) n'exposent pas de signature d'index :
    // cast explicite — les clés correspondent exactement aux `plots` ci-dessus.
    return computeFractalTrigonometricForecast(c, p.threshold, p.projection) as unknown as Record<string, Series>
  }
})

register({
  id: 'fractal', name: 'Fractal', short: 'Fractal', category: 'bill-williams', pane: 'main',
  params: [
    { key: 'period', label: 'Period', default: 2, min: 1, max: 20, step: 1 },
  ],
  plots: [
    { key: 'up', label: 'Fractal High', type: 'line', color: TV.red, marker: 'arrowDown' },
    { key: 'down', label: 'Fractal Low', type: 'line', color: TV.lime, marker: 'arrowUp' },
  ],
  compute(c, p) {
    const n = c.length, k = Math.max(1, Math.round(p.period))
    const up = nulls(n), down = nulls(n)
    // Confirmed fractal: requires bars on both sides. The marker is placed
    // on the actual pivot candle (TradingView-style, hence the apparent lag).
    for (let i = k; i < n - k; i++) {
      let hi = true, lo = true
      for (let j = 1; j <= k; j++) {
        if (c[i].high <= c[i-j].high || c[i].high <= c[i+j].high) hi = false
        if (c[i].low >= c[i-j].low || c[i].low >= c[i+j].low) lo = false
      }
      if (hi) up[i] = c[i].high
      if (lo) down[i] = c[i].low
    }
    return { up, down }
  },
})

register({
  id: 'fractal-custom', name: 'Fractal Custom — Live', short: 'Fractal Live', category: 'bill-williams', pane: 'main',
  params: [
    { key: 'period', label: 'Lookback', default: 2, min: 1, max: 20, step: 1 },
    { key: 'strict', label: 'Strictness', default: 1, min: 0, max: 1, step: 1 },
  ],
  plots: [
    { key: 'up', label: 'Live Up', type: 'line', color: TV.lime, marker: 'arrowUp' },
    { key: 'down', label: 'Live Down', type: 'line', color: TV.red, marker: 'arrowDown' },
  ],
  compute(c, p) {
    return computeFractalCustomLive(c, p.period, p.strict) as unknown as Record<string, Series>
  },
})

register({
  id: 'fractal-custom-bis', name: 'Fractal Live Custom BIS', short: 'Fractal Live BIS', category: 'bill-williams', pane: 'main',
  params: [
    { key: 'period', label: 'Lookback', default: Number.NaN, min: 1, max: 20, step: 1 },
    { key: 'bodyMin', label: 'Min body ratio', default: Number.NaN, min: 0.50, max: 0.98, step: 0.01 },
    { key: 'wickMax', label: 'Max wick ratio', default: Number.NaN, min: 0.01, max: 0.25, step: 0.01 },
  ],
  plots: [
    { key: 'up', label: 'BIS Marubozu Up', type: 'line', color: TV.lime, marker: 'arrowUp' },
    { key: 'down', label: 'BIS Marubozu Down', type: 'line', color: TV.red, marker: 'arrowDown' },
  ],
  compute(c, p) {
    return computeFractalCustomLiveBis(c, p.period, p.bodyMin, p.wickMax) as unknown as Record<string, Series>
  },
})

register({
  id: 'fractal-live-precision-pro', name: 'Fractal Live Precision Pro', short: 'Precision Pro', category: 'bill-williams', pane: 'main',
  params: [
    { key: 'period', label: 'Lookback', default: 3, min: 2, max: 10, step: 1 },
    { key: 'strict', label: 'Strictness', default: 2, min: 1, max: 5, step: 1 },
    { key: 'threshold', label: 'Seuil de confluence', default: 0.72, min: 0.60, max: 0.92, step: 0.01 },
  ],
  plots: [
    { key: 'up', label: 'Precision Pro Up', type: 'line', color: TV.lime, marker: 'arrowUp' },
    { key: 'down', label: 'Precision Pro Down', type: 'line', color: TV.red, marker: 'arrowDown' },
  ],
  compute(c, p) {
    const n=c.length, k=Math.max(2,Math.min(10,Math.round(p.period||3))), up=nulls(n), down=nulls(n)
    const clamp=(v:number,a:number,b:number)=>Math.max(a,Math.min(b,v))
    for(let i=k+1;i<n;i++){
      let ph=-Infinity,pl=Infinity
      for(let j=1;j<=k;j++){ph=Math.max(ph,c[i-j].high);pl=Math.min(pl,c[i-j].low)}
      const x=c[i],prev=c[i-1],range=Math.max(x.high-x.low,Number.EPSILON),body=Math.abs(x.close-x.open),upper=Math.max(0,x.high-Math.max(x.open,x.close)),lower=Math.max(0,Math.min(x.open,x.close)-x.low),pos=clamp((x.close-x.low)/range,0,1)
      const su=x.low<pl&&x.close>pl,sd=x.high>ph&&x.close<ph,du=x.close>x.open&&body/range>=.58&&pos>=.70,dd=x.close<x.open&&body/range>=.58&&pos<=.30,ru=lower/range>=.35&&x.close>=x.open,rd=upper/range>=.35&&x.close<=x.open,stu=x.close>prev.high||(x.close>prev.close&&x.low>=prev.low),std=x.close<prev.low||(x.close<prev.close&&x.high<=prev.high)
      let us=0,ds=0
      if(su)us+=.38;if(du)us+=.24;if(ru)us+=.12;if(stu)us+=.16;if(pos>=.62)us+=.10
      if(sd)ds+=.38;if(dd)ds+=.24;if(rd)ds+=.12;if(std)ds+=.16;if(pos<=.38)ds+=.10
      const strict=clamp(Math.round(p.strict||2),1,5),thr=clamp(Number(p.threshold??.72)+(strict-2)*.025,.60,.95),delta=Math.abs(us-ds)
      if(us>=thr&&us>ds&&delta>=.08&&(su||(du&&stu)))up[i]=x.low
      if(ds>=thr&&ds>us&&delta>=.08&&(sd||(dd&&std)))down[i]=x.high
    }
    return {up,down}
  },
})

register({
  id: 'live-fractal-ninja', name: 'Live Fractal Ninja', short: 'Fractal Ninja', category: 'bill-williams', pane: 'main',
  params: [
    { key: 'period', label: 'Lookback', default: 3, min: 2, max: 8, step: 1 },
    { key: 'trendFast', label: 'EMA rapide', default: 8, min: 5, max: 20, step: 1 },
    { key: 'trendSlow', label: 'EMA lente', default: 21, min: 12, max: 55, step: 1 },
    { key: 'threshold', label: 'Seuil Ninja', default: 0.62, min: 0.5, max: 0.9, step: 0.01 },
  ],
  plots: [
    { key: 'up', label: 'Ninja CALL', type: 'line', color: TV.lime, marker: 'arrowUp' },
    { key: 'down', label: 'Ninja PUT', type: 'line', color: TV.red, marker: 'arrowDown' },
  ],
  compute(c, p) {
    const n=c.length,k=Math.max(2,Math.min(8,Math.round(p.period))),up=nulls(n),down=nulls(n)
    const fast=Math.max(5,Math.round(p.trendFast||8)),slow=Math.max(fast+4,Math.round(p.trendSlow||21)),thr=Math.max(.5,Math.min(.9,Number(p.threshold)||.62))
    const ema=(xs:number[],m:number)=>{if(!xs.length)return 0;const q=2/(m+1);let e=xs[0];for(let z=1;z<xs.length;z++)e=xs[z]*q+e*(1-q);return e}
    const mean=(xs:number[])=>xs.length?xs.reduce((a,b)=>a+b,0)/xs.length:0
    for(let i=Math.max(12,k);i<n;i++){
      // IMPORTANT: calculate each historical bar using data <= i only.
      // This prevents future leakage/repainting of old Ninja arrows.
      const hist=c.slice(0,i+1), closes=hist.map(x=>x.close), prev=hist[i-1],x=hist[i]
      const ef=ema(closes.slice(-Math.min(closes.length,slow*3)),fast),es=ema(closes.slice(-Math.min(closes.length,slow*3)),slow)
      const pc=closes.slice(0,-1),ef0=ema(pc.slice(-Math.min(pc.length,slow*3)),fast),es0=ema(pc.slice(-Math.min(pc.length,slow*3)),slow)
      const ranges=hist.slice(-20).map(q=>Math.max(q.high-q.low,Math.abs(q.high-q.close),Math.abs(q.low-q.close))),atr=Math.max(1e-9,mean(ranges))
      const trend=Math.max(-1,Math.min(1,((ef-es)/atr)*.55+(((ef-ef0)+(es-es0))*.5/atr)*2.1)),at=Math.abs(trend)
      let ph=-Infinity,pl=Infinity;for(let j=1;j<=k;j++){ph=Math.max(ph,hist[i-j].high);pl=Math.min(pl,hist[i-j].low)}
      const body=Math.abs(x.close-x.open),uw=Math.max(0,x.high-Math.max(x.open,x.close)),lw=Math.max(0,Math.min(x.open,x.close)-x.low)
      const ub=x.low<=pl&&x.close>x.open,db=x.high>=ph&&x.close<x.open
      const ur=lw>body*.9&&x.close>x.open,dr=uw>body*.9&&x.close<x.open
      const mom=Math.max(-1,Math.min(1,(x.close-closes[Math.max(0,i-4)])/atr*.7+((x.close-x.open)/atr)*.6))
      const su=x.close>prev.close&&x.low>=prev.low,sd=x.close<prev.close&&x.high<=prev.high
      const pu=x.low<=ef+atr*.35&&x.close>=ef-atr*.15,pd=x.high>=ef-atr*.35&&x.close<=ef+atr*.15
      let us=0,ds=0
      if(trend>0)us+=.34*at;else ds+=.34*at
      if(mom>0)us+=.20*mom;else ds+=.20*Math.abs(mom)
      if(su)us+=.12;if(sd)ds+=.12;if(ub)us+=.22;if(db)ds+=.22;if(pu)us+=.08;if(pd)ds+=.08;if(ur)us+=.08;if(dr)ds+=.08
      // Hard directional lock in strong trends: reversal is not a Ninja signal.
      if(trend<-.34)us=0;if(trend>.34)ds=0
      const sc=Math.max(us,ds),au=trend>.18,ad=trend<-.18
      if(us>ds&&au&&(ub||ur)&&sc>=thr)up[i]=x.low
      else if(ds>us&&ad&&(db||dr)&&sc>=thr)down[i]=x.high
    }
    return {up,down}
  },
})

// ---------------------------------------------------------------------------
// Helpers for the UI
// ---------------------------------------------------------------------------

export function defaultParams(def: IndicatorDef): Record<string, number> {
  const out: Record<string, number> = {}
  for (const p of def.params) out[p.key] = p.default
  return out
}

/** Legend title, e.g. "EMA 20" or "MACD 12 26 9" (TradingView style). */
export function indicatorTitle(def: IndicatorDef, params: Record<string, number>): string {
  if (def.params.length === 0) return def.short
  return `${def.short} ${def.params.map((p) => Number.isFinite(params[p.key]) ? params[p.key] : '').join(' ')}`
}

/** Search across name / short / category. */
export function searchIndicators(query: string): IndicatorDef[] {
  const q = query.trim().toLowerCase()
  if (!q) return INDICATORS
  return INDICATORS.filter((d) =>
    d.name.toLowerCase().includes(q)
    || d.short.toLowerCase().includes(q)
    || CATEGORY_LABELS[d.category].toLowerCase().includes(q))
}

export function formatIndicatorValue(v: number | null | undefined): string {
  if (v == null || !Number.isFinite(v)) return '—'
  const abs = Math.abs(v)
  if (abs >= 1e9) return `${(v / 1e9).toFixed(2)}B`
  if (abs >= 1e6) return `${(v / 1e6).toFixed(2)}M`
  if (abs >= 1e4) return v.toLocaleString(undefined, { maximumFractionDigits: 1 })
  if (abs >= 100) return v.toFixed(2)
  if (abs >= 1) return v.toFixed(3)
  return v.toFixed(5)
}
