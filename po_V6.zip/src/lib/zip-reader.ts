'use client'

/**
 * Minimal dependency-free ZIP reader for the Pine multi-library import.
 *
 * Parses the End-Of-Central-Directory record + central directory, then decodes
 * each entry with either no compression (method 0 / store) or DEFLATE
 * (method 8) through the platform's native `DecompressionStream('deflate-raw')`
 * — available in every modern browser and Node ≥ 18. No JSZip/fflate
 * dependency, no bundler configuration.
 *
 * Only TEXT payloads are returned (UTF-8 decoded): community script packs are
 * .pine/.txt sources. Binary entries are skipped rather than decoded so a
 * mixed archive (screenshots, PDFs…) still imports cleanly.
 */

export interface ZipEntry {
  /** Full path inside the archive, e.g. "Market_structures_scripts/libs/PubLibSwing.pine". */
  name: string
  /** Uncompressed byte length. */
  size: number
  /** UTF-8 decoded payload (empty string for skipped binary entries). */
  text: string
  /** True when the entry could not be UTF-8 decoded as text (binary payload). */
  binary: boolean
}

const EOCD_SIGNATURE = 0x06054b50
const CENTRAL_SIGNATURE = 0x02014b50
const LOCAL_SIGNATURE = 0x04034b50
const METHOD_STORE = 0
const METHOD_DEFLATE = 8
/** EOCD is 22 bytes + up to 64 KiB of trailing comment. */
const EOCD_SCAN_WINDOW = 22 + 65_536

function u16(view: DataView, offset: number): number { return view.getUint16(offset, true) }
function u32(view: DataView, offset: number): number { return view.getUint32(offset, true) }

/** Locate the End-Of-Central-Directory record; returns its byte offset. */
function findEocd(bytes: Uint8Array): number {
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength)
  const min = Math.max(0, bytes.length - EOCD_SCAN_WINDOW)
  for (let i = bytes.length - 22; i >= min; i--) {
    if (u32(view, i) === EOCD_SIGNATURE) return i
  }
  throw new Error('ZIP invalide : enregistrement de fin de répertoire introuvable (fichier corrompu ou non-ZIP).')
}

/** Inflate a raw-DEFLATE payload. Native on browsers and Node ≥ 18. */
async function inflateRaw(data: Uint8Array): Promise<Uint8Array> {
  if (typeof DecompressionStream === 'undefined') {
    throw new Error(
      'Décompression DEFLATE indisponible sur ce navigateur (DecompressionStream manquant). ' +
      'Ré-archivez les sources en ZIP non compressé (méthode « stockage ») et réessayez.',
    )
  }
  const stream = new Blob([data as BlobPart]).stream().pipeThrough(new DecompressionStream('deflate-raw'))
  const buffer = await new Response(stream).arrayBuffer()
  return new Uint8Array(buffer)
}

function looksBinary(bytes: Uint8Array): boolean {
  // A NUL byte in the first 8 KiB is the classic text/binary discriminator.
  const limit = Math.min(bytes.length, 8192)
  for (let i = 0; i < limit; i++) if (bytes[i] === 0) return true
  return false
}

/**
 * Extract every regular file of a ZIP archive as a text entry.
 * Directories, macOS metadata (__MACOSX/, .DS_Store) and dotfiles are skipped.
 */
export async function readZipEntries(data: ArrayBuffer | Uint8Array): Promise<ZipEntry[]> {
  const bytes = data instanceof Uint8Array ? data : new Uint8Array(data)
  if (bytes.length < 22) throw new Error('ZIP vide ou tronqué.')

  const eocd = findEocd(bytes)
  const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength)
  const entryCount = u16(view, eocd + 10)
  let cdOffset = u32(view, eocd + 16)
  if (cdOffset === 0xffffffff || entryCount === 0xffff) {
    throw new Error('ZIP64 non supporté — ré-archivez les sources (archives < 4 Go).')
  }

  const decoder = new TextDecoder('utf-8', { fatal: false })
  const entries: ZipEntry[] = []

  for (let i = 0; i < entryCount; i++) {
    if (cdOffset + 46 > bytes.length || u32(view, cdOffset) !== CENTRAL_SIGNATURE) {
      throw new Error(`ZIP invalide : entrée de répertoire #${i + 1} corrompue.`)
    }
    const method = u16(view, cdOffset + 10)
    const compressedSize = u32(view, cdOffset + 20)
    const uncompressedSize = u32(view, cdOffset + 24)
    const nameLen = u16(view, cdOffset + 28)
    const extraLen = u16(view, cdOffset + 30)
    const commentLen = u16(view, cdOffset + 32)
    const localOffset = u32(view, cdOffset + 42)
    const name = decoder.decode(bytes.subarray(cdOffset + 46, cdOffset + 46 + nameLen))
    cdOffset += 46 + nameLen + extraLen + commentLen

    const base = name.split('/').pop() ?? ''
    if (!base || base.startsWith('.') || name.includes('__MACOSX')) continue // dir, dotfile, macOS junk

    if (localOffset + 30 > bytes.length || u32(view, localOffset) !== LOCAL_SIGNATURE) {
      throw new Error(`ZIP invalide : en-tête local de "${name}" corrompu.`)
    }
    // The LOCAL header's name/extra lengths can differ from the central ones —
    // always recompute the payload offset from the local header itself.
    const localNameLen = u16(view, localOffset + 26)
    const localExtraLen = u16(view, localOffset + 28)
    const payloadStart = localOffset + 30 + localNameLen + localExtraLen
    const payload = bytes.subarray(payloadStart, payloadStart + compressedSize)

    let raw: Uint8Array
    if (method === METHOD_STORE) raw = payload
    else if (method === METHOD_DEFLATE) raw = await inflateRaw(payload)
    else continue // unsupported compression → skip silently (e.g. LZMA rare packs)

    if (looksBinary(raw)) {
      entries.push({ name, size: uncompressedSize, text: '', binary: true })
      continue
    }
    entries.push({ name, size: uncompressedSize, text: decoder.decode(raw), binary: false })
  }
  return entries
}
