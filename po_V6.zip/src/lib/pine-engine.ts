'use client'

/**
 * Pine v5/v6 execution bridge (rewritten 2026-09-11).
 *
 * Root cause of the historical "Pine executed successfully but produced no
 * visual/alert output" error: real TradingView scripts draw through drawing
 * objects (line.new / label.new / box.new / polyline.new / table.new /
 * linefill.new) rather than plot() calls. Piner exposes those through
 * `engine.drawings`, which the previous bridge never read — so scripts whose
 * visuals were 100% drawings were reported as "no output".
 *
 * This bridge now normalizes the complete Visual IR:
 *   engine.outputs → plots, markers, candles (plotcandle/plotbar), hlines,
 *                    fills, barColors, bgColors, alerts
 *   engine.drawings → line / label / box / table / polyline / linefill
 *   engine.strategy → full backtest report (PnL, trades, equity, drawdown)
 *
 * All x-coordinates are resolved to epoch MILLISECONDS at this layer
 * (bar_index → time via the Pine bar array, extrapolating negative or
 * beyond-history indexes) so renderers never need Pine index math again.
 */

import type { CandleLike } from './indicators'
import { compileAsync, Engine, ArrayFeed } from '@heyphat/piner'
import { upgradeLegacyPine, isLegacyPine } from './pine-upgrade'
import { asPinerRegistry, listLibraries } from './pine-libraries'

export interface PineBar {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export type PinePlotStyle =
  | 'line' | 'stepline' | 'histogram' | 'columns' | 'area' | 'circles'
  | 'cross' | 'linebr' | 'areabr' | 'unknown'

export interface PinePlotOutput {
  id: number
  title: string
  overlay: boolean
  style: PinePlotStyle
  color?: string
  colors?: Array<string | null>
  linewidth?: number
  data: Array<number | null>
}

export interface PineMarkerOutput {
  id: number
  title: string
  kind: 'shape' | 'char' | 'arrow'
  location: string
  glyph: string
  data: Array<{ color?: string | null; text?: string } | null>
}

export interface PineHLineOutput {
  id: number
  title: string
  price: number
}

export interface PineFillOutput {
  id: number
  title: string
  plot1: number
  plot2: number
  color: string | null
  colors: Array<string | null>
}

export interface PineCandleOutput {
  id: number
  title: string
  overlay: boolean
  data: Array<{ open: number; high: number; low: number; close: number } | null>
  colors: Array<string | null>
  wickColors: Array<string | null>
  borderColors: Array<string | null>
}

// ─── Drawing objects (line/label/box/polyline/table/linefill) ───────────────

export interface PineLineDrawing {
  kind: 'line'
  /** piner drawing-pool id — referenced by linefill objects */
  id?: number
  x1: number; y1: number; x2: number; y2: number
  color?: string
  width?: number
  style?: string
  extend?: string
}

export interface PineLabelDrawing {
  kind: 'label'
  x: number
  y: number | null
  yloc: 'price' | 'abovebar' | 'belowbar'
  text: string
  color?: string
  textcolor?: string
  style?: string
  size?: string
}

export interface PineBoxDrawing {
  kind: 'box'
  left: number; top: number; right: number; bottom: number
  bgcolor?: string
  borderColor?: string
  borderWidth?: number
  borderStyle?: string
  text?: string
  textColor?: string
  textSize?: string
  textHalign?: string
  textValign?: string
}

export interface PinePolylineDrawing {
  kind: 'polyline'
  points: Array<{ time: number; price: number }>
  lineColor?: string
  lineWidth?: number
  lineStyle?: string
}

export interface PineTableCell {
  text?: string
  textColor?: string
  bgcolor?: string
  textSize?: string
  textHalign?: string
  /** merged range when the cell spans several grid slots */
  merged?: { startRow: number; startCol: number; endRow: number; endCol: number }
}

export interface PineTableDrawing {
  kind: 'table'
  position: string
  columns: number
  rows: number
  /** keyed "row,col" */
  cells: Record<string, PineTableCell>
}

export interface PineLineFillDrawing {
  kind: 'linefill'
  line1: number
  line2: number
  color?: string
}

export type PineDrawing =
  | PineLineDrawing
  | PineLabelDrawing
  | PineBoxDrawing
  | PinePolylineDrawing
  | PineTableDrawing
  | PineLineFillDrawing

export interface PineAlertOutput {
  title?: string
  message: string
  time?: number
}

export interface PineStrategyTrade {
  dir: number
  qty: number
  entryPrice: number
  exitPrice: number
  entryTime: number
  exitTime: number
  profit: number
  cumProfit: number
  commission: number
}

export interface PineStrategyReport {
  initialCapital: number
  netProfit: number
  grossProfit: number
  grossLoss: number
  wins: number
  losses: number
  evens: number
  winRate: number
  profitFactor: number
  maxDrawdown: number
  maxDrawdownPercent: number
  totalCommission: number
  openPosition: number
  closedTrades: PineStrategyTrade[]
  equityCurve: Array<{ time: number; value: number }>
}

export interface PineExecutionResult {
  title: string
  overlay: boolean
  plots: PinePlotOutput[]
  markers: PineMarkerOutput[]
  hlines: PineHLineOutput[]
  fills: PineFillOutput[]
  candles: PineCandleOutput[]
  drawings: PineDrawing[]
  barColors: Array<Array<string | null>>
  bgColors: Array<Array<string | null>>
  /** exact millisecond timeline used by the Pine engine */
  _times?: number[]
  alerts: PineAlertOutput[]
  strategy?: PineStrategyReport
}

export interface PineExecutionError {
  message: string
  stage: 'loader' | 'compiler' | 'runtime'
  line?: number
  column?: number
}

export type PineExecutionResponse =
  | { ok: true; result: PineExecutionResult }
  | { ok: false; error: PineExecutionError }

export interface PineScriptMeta {
  version: 5 | 6
  declaration: 'indicator' | 'strategy' | 'library' | 'unknown'
  title: string
  overlay: boolean
}

/** One `input.*` declaration — the settings-panel schema (mirrors piner's InputDecl). */
export interface PineInputDecl {
  /** Override key: the input's title, else an auto id `input_<n>`. */
  key: string
  kind: 'int' | 'float' | 'bool' | 'string' | 'color' | 'source' | 'price' | 'timeframe' | 'symbol' | 'session' | 'time' | 'text_area' | 'enum'
  title?: string
  default: number | boolean | string | null
  minval?: number
  maxval?: number
  step?: number
  options?: (string | number)[]
  group?: string
  tooltip?: string
}

export interface PineInputSchema {
  inputs: PineInputDecl[]
  error: string | null
}

/**
 * Transparent legacy (v1–v4) source upgrade — see pine-upgrade.ts. Every
 * entry point that compiles Pine must pass through this so pasted v3/v4
 * scripts (bare builtins, study(), old input()) run on the v6 engine.
 */
function effectivePineSource(source: string): string {
  return upgradeLegacyPine(source).source
}

export function inspectPineSource(source: string): PineScriptMeta {
  const upgraded = isLegacyPine(source)
  const effective = upgraded ? effectivePineSource(source) : source
  const versionMatch = effective.match(/\/\/\s*@version\s*=\s*(\d+)/i)
  const version = Number(versionMatch?.[1] ?? 6) >= 6 ? 6 : 5
  const declarationMatch = effective.match(/\b(indicator|strategy|library)\s*\(([^)]*)\)/i)
  const declaration = (declarationMatch?.[1]?.toLowerCase() ?? 'unknown') as PineScriptMeta['declaration']
  const args = declarationMatch?.[2] ?? ''
  const titleMatch = args.match(/^\s*["']([^"']+)["']/)
  const overlayMatch = args.match(/\boverlay\s*=\s*(true|false)/i)
  return {
    version,
    declaration,
    title: titleMatch?.[1] ?? 'Pine Script',
    overlay: declarationMatch ? overlayMatch?.[1]?.toLowerCase() !== 'false' : true,
  }
}

/**
 * Convert the host's candle size (seconds) into a Pine timeframe string
 * accepted by parsePineTimeframe: second multipliers are only valid at
 * 1/5/10/15/30/45 — everything else is expressed in minutes, days or ranges.
 */
export function toPineTimeframe(seconds: number): string {
  const s = Math.max(1, Math.round(seconds))
  if (s < 60) {
    const validSeconds = [1, 5, 10, 15, 30, 45]
    const nearest = validSeconds.reduce((a, b) => Math.abs(b - s) < Math.abs(a - s) ? b : a, validSeconds[0])
    return `${nearest}S`
  }
  if (s % 86_400 === 0) return `${s / 86_400}D`
  return `${Math.round(s / 60)}`
}

function toPineBars(candles: CandleLike[]): PineBar[] {
  return candles.map((c) => ({
    time: Number(c.time) * 1000,
    open: Number(c.open),
    high: Number(c.high),
    low: Number(c.low),
    close: Number(c.close),
    volume: Number.isFinite(Number(c.volume)) ? Number(c.volume) : 0,
  }))
}

function normalizePlotStyle(value: unknown): PinePlotStyle {
  const text = String(value ?? '').toLowerCase()
  if (text.includes('histogram')) return 'histogram'
  if (text.includes('column')) return 'columns'
  if (text.includes('stepline')) return 'stepline'
  if (text.includes('area')) return text.includes('abr') ? 'areabr' : 'area'
  if (text.includes('circle')) return 'circles'
  if (text.includes('cross')) return 'cross'
  if (text.includes('linebr')) return 'linebr'
  if (text.includes('line')) return 'line'
  return 'unknown'
}

function normalizePlotData(raw: unknown): Array<number | null> {
  if (!Array.isArray(raw)) return []
  return raw.map((item) => {
    if (item == null) return null
    if (typeof item === 'number') return Number.isFinite(item) ? item : null
    if (typeof item === 'object' && item !== null) {
      const value = (item as { value?: unknown }).value
      const n = Number(value)
      return Number.isFinite(n) ? n : null
    }
    const n = Number(item)
    return Number.isFinite(n) ? n : null
  })
}

/** Piner represents `na` as { __na: true } objects inside drawing props. */
function isNa(value: unknown): boolean {
  if (value == null) return true
  if (typeof value === 'number') return !Number.isFinite(value)
  if (typeof value === 'object') {
    const na = (value as { __na?: boolean }).__na
    if (na === true) return true
    const n = Number((value as { value?: unknown }).value)
    if (Number.isFinite(n)) return false
    return true
  }
  return !Number.isFinite(Number(value))
}

function asNumber(value: unknown): number | null {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null
  if (typeof value === 'object' && value !== null) {
    const inner = (value as { value?: unknown }).value
    if (typeof inner === 'number' && Number.isFinite(inner)) return inner
    return null
  }
  const n = Number(value)
  return Number.isFinite(n) ? n : null
}

function asString(value: unknown): string | undefined {
  return typeof value === 'string' ? value : undefined
}

function normalizeColor(value: unknown): string | undefined {
  if (typeof value === 'string') return value
  if (value == null) return undefined
  if (typeof value === 'object') {
    const v = (value as { hex?: unknown; css?: unknown; value?: unknown })
    if (typeof v.hex === 'string') return v.hex
    if (typeof v.css === 'string') return v.css
    if (typeof v.value === 'string') return v.value
  }
  return undefined
}

/** Smallest decimal precision at which `v` round-trips (FP-noise tolerant). */
function decimalsOfValue(v: number): number {
  const a = Math.abs(v)
  if (!Number.isFinite(a) || a === 0) return 0
  for (let d = 0; d <= 8; d++) {
    const scaled = a * 10 ** d
    if (Math.abs(scaled - Math.round(scaled)) < 1e-6 * Math.max(1, scaled / 1e6)) return d
  }
  return 8
}

/**
 * Derive the symbol's mintick (`syminfo.mintick`) from the live candle data.
 *
 * WHY THIS EXISTS (v1.8): Piner defaults `syminfo.mintick` to 0.01. Real
 * TradingView scripts scale label/line offsets with it — e.g. Market
 * Structure packs compute `base_offset = math.max(atr * 0.30, syminfo.mintick * 10)`.
 * With the 0.01 default on EURUSD (mintick 0.00001) the offsets came out
 * 1000× too large and every drawing floated 10–30 cents away from the candles
 * (the "indicators move away from candles" bug). Hosts that know the real
 * mintick must pass `runtime.mintick`; this derivation is the automatic
 * fallback so no call path can ever run with the raw default again.
 *
 * Strategy: observe the smallest non-zero price movement between consecutive
 * closes (prices move in whole ticks, so with enough samples the minimum
 * converges to the mintick), floored to a clean power of ten to absorb
 * floating-point noise. Falls back to the decimals present in the price
 * representation when the market is too quiet to observe a movement.
 */
export function deriveMintick(candles: CandleLike[]): number | undefined {
  const sample = candles.slice(-400)
  if (sample.length < 3) return undefined

  let maxDecimals = 0
  for (const c of sample.slice(-80)) {
    maxDecimals = Math.max(
      maxDecimals,
      decimalsOfValue(c.close),
      decimalsOfValue(c.high),
      decimalsOfValue(c.low),
    )
  }

  const deltas: number[] = []
  for (let i = 1; i < sample.length; i++) {
    const d = Math.abs(Number(sample[i].close) - Number(sample[i - 1].close))
    if (d > 1e-12 && Number.isFinite(d)) deltas.push(d)
  }

  let tick: number
  if (deltas.length >= 8) {
    deltas.sort((a, b) => a - b)
    // median of the 5 smallest — robust against a single FP-noise outlier
    const probe = deltas.slice(0, Math.min(5, deltas.length))
    const med = probe[Math.floor(probe.length / 2)]
    // floor to a power of ten with an epsilon so 9.9999…e-6 stays 1e-5
    const exp = Math.floor(Math.log10(med) + 1e-9)
    tick = 10 ** Math.min(0, Math.max(-8, exp))
  } else {
    tick = 10 ** -Math.min(8, maxDecimals)
  }

  // Sanity clamp: a mintick can never exceed ~0.5 % of the price (that would
  // be a derivation failure, e.g. a frozen feed) — fall back to decimals.
  const price = Math.abs(Number(sample[sample.length - 1].close)) || 1
  if (!(tick > 0) || !Number.isFinite(tick) || tick > price * 0.005) {
    tick = 10 ** -Math.min(8, maxDecimals)
  }
  if (!(tick > 0) || !Number.isFinite(tick) || tick > price * 0.005) return undefined
  return tick
}

/** Execute a complete Pine source against the provided OHLCV dataset. */
export async function runPineScript(
  source: string,
  candles: CandleLike[],
  runtime?: { symbol?: string; timeframe?: string; mintick?: number; inputs?: Record<string, unknown> },
): Promise<PineExecutionResponse> {
  if (!source.trim()) {
    return { ok: false, error: { stage: 'loader', message: 'Pine source is empty.' } }
  }
  if (candles.length < 2) {
    return { ok: false, error: { stage: 'loader', message: 'Not enough candles to execute Pine Script.' } }
  }

  const meta = inspectPineSource(source)
  // v1.10 — legacy upgrade: v1–v4 sources are rewritten to v6-compatible
  // form before compilation (bare builtins silently produce `na` otherwise).
  const compileSource = effectivePineSource(source)

  try {
    let compiled = compiledCache.get(compileSource)
    if (!compiled) {
      try {
        // Async compile resolves `import author/lib/version` statements from
        // the user-managed library registry (see pine-libraries.ts).
        compiled = await compileAsync(compileSource, {
          libraries: asPinerRegistry(),
          resolveLibrary: (identity) => asPinerRegistry().find((l) => l.key === identity.canonical)?.source,
        })
        compiledCache.set(compileSource, compiled)
      } catch (err) {
        return { ok: false, error: normalizePineError(err, 'compiler') }
      }
    }

    try {
      const pineBars = toPineBars(candles)
      const feed = new ArrayFeed(pineBars)
      // v1.8 — THE ALIGNMENT FIX: never let `syminfo.mintick` fall back to
      // Piner's 0.01 default. Scripts scale drawing offsets with it
      // (`math.max(atr * x, syminfo.mintick * n)` is a TradingView idiom), so a
      // wrong mintick displaces every label/line far from the candles. An
      // explicit runtime mintick always wins; otherwise it is derived from the
      // candle data itself (smallest observed price increment).
      const mintick = runtime?.mintick ?? deriveMintick(candles)
      // v1.3 — THE settings fix: user overrides from the Réglages panel are
      // forwarded to the engine (keyed by input title). Without this line,
      // every run executed with default values and the settings menu was dead.
      const engine = new Engine(compiled as any, feed as any, runtime?.inputs ? { inputs: runtime.inputs } : undefined)
      await engine.run({
        symbol: runtime?.symbol || 'CUSTOM',
        timeframe: runtime?.timeframe || '1',
        ...(mintick ? { mintick } : {}),
      })
      const result = normalizeEngineResult(engine, meta, pineBars)
      const outputCount =
        result.plots.length + result.markers.length + result.hlines.length +
        result.fills.length + result.candles.length + result.drawings.length +
        result.barColors.length + result.bgColors.length + result.alerts.length
      if (outputCount === 0) {
        return {
          ok: false,
          error: {
            stage: 'runtime',
            message:
              'Pine executed successfully but produced no visual/alert output. ' +
              'The script has no plot()/plotshape()/label/line/box/table/alert calls reachable ' +
              'on the current dataset (conditions may never have triggered).',
          },
        }
      }
      return { ok: true, result }
    } catch (err) {
      return { ok: false, error: normalizePineError(err, 'runtime') }
    }
  } catch (err) {
    return {
      ok: false,
      error: {
        stage: 'loader',
        message: err instanceof Error ? `Pine runtime load failed: ${err.message}` : `Pine runtime load failed: ${String(err)}`,
      },
    }
  }
}

function eachOutput(store: unknown, cb: (value: any, index: number) => void): void {
  if (!store) return
  if (typeof (store as any).forEach === 'function') {
    let i = 0
    ;(store as any).forEach((value: any) => cb(value, i++))
    return
  }
  if (Array.isArray(store)) (store as any[]).forEach(cb)
}

/** bar_index → epoch ms, extrapolating outside the known history. */
function timeResolver(bars: PineBar[]) {
  const times = bars.map((b) => b.time)
  const n = times.length
  const interval = n >= 2 ? times[1] - times[0] : 60_000
  return (index: number): number | null => {
    const i = Math.round(index)
    if (i >= 0 && i < n) return times[i]
    if (i < 0) return n ? times[0] + i * interval : null
    return n ? times[n - 1] + (i - (n - 1)) * interval : null
  }
}

/** Resolve a drawing x-coordinate (bar index OR epoch ms) to epoch ms. */
function resolveX(raw: unknown, xloc: string | undefined, resolveIndex: (i: number) => number | null): number | null {
  if (isNa(raw)) return null
  if (xloc === 'bar_time') {
    const n = asNumber(raw)
    return n != null && n > 0 ? n : null
  }
  const n = asNumber(raw)
  if (n == null) return null
  return resolveIndex(n)
}

function normalizeDrawings(rawDrawings: unknown, resolveIndex: (i: number) => number | null): PineDrawing[] {
  const list: PineDrawing[] = []
  if (!Array.isArray(rawDrawings)) return list
  for (const obj of rawDrawings as Array<{ id?: number; type?: string; props?: Record<string, unknown> }>) {
    const type = obj?.type
    const p = obj?.props ?? {}
    if (!type || !p) continue

    if (type === 'line') {
      const x1 = resolveX(p.x1, asString(p.xloc), resolveIndex)
      const x2 = resolveX(p.x2, asString(p.xloc), resolveIndex)
      const y1 = asNumber(p.y1)
      const y2 = asNumber(p.y2)
      if (x1 == null || x2 == null || y1 == null || y2 == null) continue
      list.push({
        kind: 'line',
        id: asNumber(obj.id ?? undefined) ?? undefined,
        x1, y1, x2, y2,
        color: normalizeColor(p.color),
        width: asNumber(p.width) ?? 1,
        style: asString(p.style),
        extend: asString(p.extend),
      })
      continue
    }

    if (type === 'label') {
      const x = resolveX(p.x, asString(p.xloc), resolveIndex)
      const y = asNumber(p.y)
      const ylocRaw = asString(p.yloc) ?? 'price'
      const yloc = ylocRaw === 'abovebar' || ylocRaw === 'belowbar' ? ylocRaw : 'price'
      if (x == null || (yloc === 'price' && y == null)) continue
      list.push({
        kind: 'label',
        x,
        y: yloc === 'price' ? y : y,
        yloc,
        text: String(p.text ?? ''),
        color: normalizeColor(p.color),
        textcolor: normalizeColor(p.textcolor),
        style: asString(p.style) ?? 'label_up',
        size: asString(p.size) ?? 'small',
      })
      continue
    }

    if (type === 'box') {
      const left = resolveX(p.left, asString(p.xloc), resolveIndex)
      const right = resolveX(p.right, asString(p.xloc), resolveIndex)
      const top = asNumber(p.top)
      const bottom = asNumber(p.bottom)
      if (left == null || right == null || top == null || bottom == null) continue
      list.push({
        kind: 'box',
        left, top, right, bottom,
        bgcolor: normalizeColor(p.bgcolor),
        borderColor: normalizeColor(p.border_color),
        borderWidth: asNumber(p.border_width) ?? 1,
        borderStyle: asString(p.border_style),
        text: asString(p.text),
        textColor: normalizeColor(p.text_color),
        textSize: asString(p.text_size) ?? 'small',
        textHalign: asString(p.text_halign),
        textValign: asString(p.text_valign),
      })
      continue
    }

    if (type === 'polyline') {
      const rawPoints = Array.isArray(p.points) ? p.points : []
      const points: Array<{ time: number; price: number }> = []
      for (const pt of rawPoints as Array<{ time?: unknown; index?: unknown; price?: unknown }>) {
        const price = asNumber(pt?.price)
        if (price == null) continue
        // polyline points carry either `time` (ms) or `index` (bar index).
        let t: number | null = null
        if (typeof pt?.time === 'number' && pt.time > 0) t = pt.time
        else {
          const idx = asNumber(pt?.index)
          if (idx != null) t = resolveIndex(idx)
        }
        if (t == null) continue
        points.push({ time: t, price })
      }
      if (points.length < 2) continue
      list.push({
        kind: 'polyline',
        points,
        lineColor: normalizeColor(p.line_color) ?? normalizeColor(p.color),
        lineWidth: asNumber(p.line_width) ?? 1,
        lineStyle: asString(p.line_style),
      })
      continue
    }

    if (type === 'table') {
      const cells: Record<string, PineTableCell> = {}
      const rawCells = (p.cells ?? {}) as Record<string, Record<string, unknown>>
      for (const [slot, cell] of Object.entries(rawCells)) {
        if (!cell || typeof cell !== 'object') continue
        const mergedRaw = cell.merged as { start_column?: unknown; start_row?: unknown; end_column?: unknown; end_row?: unknown } | undefined
        const merged = mergedRaw
          ? {
              startRow: Number(mergedRaw.start_row ?? 0),
              startCol: Number(mergedRaw.start_column ?? 0),
              endRow: Number(mergedRaw.end_row ?? 0),
              endCol: Number(mergedRaw.end_column ?? 0),
            }
          : undefined
        cells[slot] = {
          text: typeof cell.text === 'string' ? cell.text : '',
          textColor: normalizeColor(cell.text_color),
          bgcolor: normalizeColor(cell.bgcolor),
          textSize: asString(cell.text_size) ?? 'small',
          textHalign: asString(cell.text_halign),
          merged,
        }
      }
      list.push({
        kind: 'table',
        position: asString(p.position) ?? 'top_right',
        columns: Number(p.columns ?? 0),
        rows: Number(p.rows ?? 0),
        cells,
      })
      continue
    }

    if (type === 'linefill') {
      const line1 = asNumber(p.line1)
      const line2 = asNumber(p.line2)
      if (line1 == null || line2 == null) continue
      list.push({ kind: 'linefill', line1, line2, color: normalizeColor(p.color) ?? undefined })
      continue
    }
  }
  return list
}

function normalizeEngineResult(
  engine: any,
  meta: PineScriptMeta,
  bars: PineBar[],
): PineExecutionResult & { _times?: number[] } {
  const outputs = engine?.outputs
  const resolveIndex = timeResolver(bars)
  const plots: PinePlotOutput[] = []
  const markers: PineMarkerOutput[] = []
  const hlines: PineHLineOutput[] = []
  const fills: PineFillOutput[] = []
  const candlesOut: PineCandleOutput[] = []
  const barColors: Array<Array<string | null>> = []
  const bgColors: Array<Array<string | null>> = []

  eachOutput(outputs?.plots, (plot: any, index) => {
    const options = plot?.options ?? {}
    const rawColors = Array.isArray(plot?.colors) ? plot.colors : []
    plots.push({
      id: Number(plot?.id ?? index),
      title: String(plot?.title ?? options?.title ?? `Plot ${index + 1}`),
      overlay: Boolean(plot?.overlay ?? options?.force_overlay ?? meta.overlay),
      style: normalizePlotStyle(plot?.style ?? options?.style),
      color: normalizeColor(plot?.color ?? options?.color),
      colors: rawColors.map((c: unknown) => normalizeColor(c) ?? null),
      linewidth: Number(plot?.linewidth ?? options?.linewidth ?? 1),
      data: normalizePlotData(plot?.data),
    })
  })

  eachOutput(outputs?.markers, (marker: any, index) => {
    const data = Array.isArray(marker?.data)
      ? marker.data.map((v: any) => v == null ? null : ({
          color: normalizeColor(v?.color),
          text: typeof v?.text === 'string' ? v.text : undefined,
        }))
      : []
    markers.push({
      id: Number(marker?.id ?? index),
      title: String(marker?.title ?? `Marker ${index + 1}`),
      kind: (marker?.kind === 'char' || marker?.kind === 'arrow') ? marker.kind : 'shape',
      location: String(marker?.location ?? 'abovebar'),
      glyph: String(marker?.glyph ?? marker?.shape ?? ''),
      data,
    })
  })

  eachOutput(outputs?.hlines, (line: any, index) => {
    const price = Number(line?.price)
    if (Number.isFinite(price)) hlines.push({ id: Number(line?.id ?? index), title: String(line?.title ?? `HLine ${index + 1}`), price })
  })

  eachOutput(outputs?.fills, (fill: any, index) => {
    fills.push({
      id: Number(fill?.id ?? index),
      title: String(fill?.title ?? `Fill ${index + 1}`),
      plot1: Number(fill?.plot1 ?? -1),
      plot2: Number(fill?.plot2 ?? -1),
      color: normalizeColor(fill?.color) ?? null,
      colors: Array.isArray(fill?.colors) ? fill.colors.map((c: unknown) => normalizeColor(c) ?? null) : [],
    })
  })

  // plotcandle / plotbar outputs.
  eachOutput(outputs?.candles, (candle: any, index) => {
    const data = Array.isArray(candle?.data)
      ? candle.data.map((v: any) => {
          if (v == null) return null
          const o = asNumber(v.open), h = asNumber(v.high), l = asNumber(v.low), c = asNumber(v.close)
          if (o == null || h == null || l == null || c == null) return null
          return { open: o, high: h, low: l, close: c }
        })
      : []
    candlesOut.push({
      id: Number(candle?.id ?? index),
      title: String(candle?.title ?? `Candles ${index + 1}`),
      overlay: Boolean(candle?.overlay ?? meta.overlay),
      data,
      colors: Array.isArray(candle?.colors) ? candle.colors.map((c: unknown) => normalizeColor(c) ?? null) : [],
      wickColors: Array.isArray(candle?.wickColors) ? candle.wickColors.map((c: unknown) => normalizeColor(c) ?? null) : [],
      borderColors: Array.isArray(candle?.borderColors) ? candle.borderColors.map((c: unknown) => normalizeColor(c) ?? null) : [],
    })
  })

  const collectColorMap = (store: any, target: Array<Array<string | null>>) => {
    eachOutput(store, (layer: any, index) => {
      if (Array.isArray(layer)) target[index] = layer.map((c: unknown) => normalizeColor(c) ?? null)
      else if (Array.isArray(layer?.data)) target[Number(layer?.id ?? index)] = layer.data.map((c: unknown) => normalizeColor(c) ?? null)
    })
  }
  collectColorMap(outputs?.barColors, barColors)
  collectColorMap(outputs?.bgColors, bgColors)

  // Alerts carry a bar index — resolve to the bar's epoch ms.
  const rawAlerts: Array<{ bar?: number; message?: string }> = Array.isArray(outputs?.alerts) ? outputs.alerts : []
  const alerts: PineAlertOutput[] = rawAlerts
    .map((a) => {
      const barIdx = asNumber(a?.bar)
      const time = barIdx != null ? resolveIndex(barIdx) ?? undefined : undefined
      return { message: String(a?.message ?? ''), time }
    })
    .filter((a) => a.message)

  // ── Drawing objects: the visuals most real TradingView scripts produce ──
  const drawings = normalizeDrawings(engine?.drawings, resolveIndex)

  // ── Strategy report ──
  const rawStrategy = typeof engine?.strategy === 'object' ? engine.strategy : undefined
  let strategy: PineStrategyReport | undefined
  if (rawStrategy) {
    const closed: PineStrategyTrade[] = (Array.isArray(rawStrategy.closedTrades) ? rawStrategy.closedTrades : [])
      .map((t: any) => ({
        dir: Number(t?.dir ?? 0),
        qty: Number(t?.qty ?? 0),
        entryPrice: Number(t?.entryPrice ?? 0),
        exitPrice: Number(t?.exitPrice ?? 0),
        entryTime: Number(t?.entryTime ?? 0),
        exitTime: Number(t?.exitTime ?? 0),
        profit: Number(t?.profit ?? 0),
        cumProfit: Number(t?.cumProfit ?? 0),
        commission: Number(t?.commission ?? 0),
      }))
    const wins = Number(rawStrategy.wins ?? 0)
    const losses = Number(rawStrategy.losses ?? 0)
    const grossProfit = Number(rawStrategy.grossProfit ?? 0)
    const grossLoss = Math.abs(Number(rawStrategy.grossLoss ?? 0))
    strategy = {
      initialCapital: Number(rawStrategy.initialCapital ?? 0),
      netProfit: Number(rawStrategy.netProfit ?? 0),
      grossProfit,
      grossLoss,
      wins,
      losses,
      evens: Number(rawStrategy.evens ?? 0),
      winRate: wins + losses > 0 ? (wins / (wins + losses)) * 100 : 0,
      profitFactor: grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Infinity : 0,
      maxDrawdown: Number(rawStrategy.maxDrawdown ?? 0),
      maxDrawdownPercent: Number(rawStrategy.maxDrawdownPercent ?? 0),
      totalCommission: Number(rawStrategy.totalCommission ?? 0),
      openPosition: Number(rawStrategy.openPosition?.qty ?? rawStrategy.openPosition ?? 0),
      closedTrades: closed,
      equityCurve: (Array.isArray(rawStrategy.equityCurve) ? rawStrategy.equityCurve : [])
        .map((e: any) => ({ time: Number(e?.time ?? 0), value: Number(e?.value ?? 0) })),
    }
  }

  return {
    _times: bars.map((b) => b.time),
    title: meta.title,
    overlay: meta.overlay,
    plots,
    markers,
    hlines,
    fills,
    candles: candlesOut,
    drawings,
    barColors,
    bgColors,
    alerts,
    strategy,
  }
}

const compiledCache = new Map<string, unknown>()

/** Invalidate compiled caches when the library registry changes. */
export function invalidatePineCaches(): void {
  compiledCache.clear()
}

/**
 * Compile (cached) a Pine source and return its `input.*` settings schema so
 * the editor can build the Réglages panel WITHOUT executing the script.
 * Keys are the override keys accepted by runPineScript({ inputs }).
 */
export async function getPineInputSchema(source: string): Promise<PineInputSchema> {
  if (!source.trim()) return { inputs: [], error: 'Pine source is empty.' }
  const compileSource = effectivePineSource(source)
  try {
    let compiled = compiledCache.get(compileSource)
    if (!compiled) {
      compiled = await compileAsync(compileSource, {
        libraries: asPinerRegistry(),
        resolveLibrary: (identity) => asPinerRegistry().find((l) => l.key === identity.canonical)?.source,
      })
      compiledCache.set(compileSource, compiled)
    }
    const inputs = ((compiled as { metadata?: { inputs?: PineInputDecl[] } })?.metadata?.inputs ?? []) as PineInputDecl[]
    return { inputs, error: null }
  } catch (err) {
    return { inputs: [], error: err instanceof Error ? err.message : String(err) }
  }
}

function normalizePineError(err: unknown, stage: PineExecutionError['stage']): PineExecutionError {
  const message = err instanceof Error ? err.message : String(err)
  const m = message.match(/(?:line|at)\s+(\d+)(?:[:],\s*(\d+))?/i)
  let friendly = message
  const missingLib = message.match(/library\s+"([^"]+)"(?:\s+imported by\s+"([^"]+)")?\s+is not present in the library registry/i)
  if (missingLib) {
    const via = missingLib[2] ? ` (importée par la bibliothèque « ${missingLib[2]} »)` : ''
    friendly =
      `This script needs the community library "${missingLib[1]}"${via}, which is not registered locally. ` +
      `Import the whole pack at once: open the Pine editor → Libraries → « Importer ZIP / fichiers » and drop the ` +
      `archive containing the main script and its libs/ folder — every key is derived automatically from the pack's ` +
      `import statements. You can also paste a single library source with the import path "${missingLib[1]}" as the key. `
    // v1.8 — near-match hint: the SAME library (name + version) may already be
    // registered under a different author (community republishes). Suggest the
    // exact key so the user can register the alias in one paste.
    const wanted = missingLib[1].split('/')
    if (wanted.length === 3) {
      const [, name, version] = wanted
      const near = listLibraries().find((l) => {
        const parts = l.key.split('/')
        return parts.length === 3 && parts[1] === name && parts[2] === version && l.key !== missingLib[1]
      })
      if (near) {
        friendly +=
          `NOTE: the same library "${name}" v${version} is already registered under the author key ` +
          `"${near.key}" — if that is the same source, open Libraries → Ajout manuel and register it a second ` +
          `time under the key "${missingLib[1]}" to satisfy this script's import. `
      }
    }
    friendly += `Original error: ${message}`
  }
  return {
    stage,
    message: friendly,
    line: m ? Number(m[1]) : undefined,
    column: m?.[2] ? Number(m[2]) : undefined,
  }
}
