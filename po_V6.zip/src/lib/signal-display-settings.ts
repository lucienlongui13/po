/**
 * signal-display-settings.ts — Persistance des filtres d'affichage des
 * signaux (§22-24, §29, §31, §33).
 * ====================================================================
 * Switch MASTER « Tags & labels », taille des labels (Small/Normal/
 * Large/Huge — défaut Large), filtres de visibilité par groupe et par
 * signal (73 patterns candle individuellement masquables), masters
 * bullish/bearish/neutral des candles, presets d'affichage.
 *
 * MIGRATION : l'ancien switch « Tags & labels » (clé
 * l-lucien-protrader-display-v1, champ showLabels) devient le MASTER du
 * nouveau registre — sa valeur est reprise telle quelle.
 *
 * EXIGENCE ABSOLUE (§33) : ces réglages n'affectent QUE le rendu — la
 * détection (moteur 73 patterns + BOS/CHoCH/CISD) et le Rule Engine
 * (Auto Trade / Strategy Tester) ne consultent JAMAIS ce store.
 */

import {
  DEFAULT_SIGNAL_DISPLAY,
  applySignalDisplayPreset,
  normalizeSignalDisplayFilters,
  type SignalDisplayFilters,
  type SignalDisplayPreset,
} from '../../shared/signal-registry'

const LS_KEY = 'signal-display-filters-v1'
/** Ancienne clé v18-v24 : switch unique showLabels. */
const LEGACY_LS_KEY = 'l-lucien-protrader-display-v1'

type Listener = (filters: SignalDisplayFilters) => void
const listeners = new Set<Listener>()

function isBrowser(): boolean {
  return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined'
}

/** Filtres actuels (défauts + MIGRATION de l'ancien switch showLabels). */
export function loadSignalDisplayFilters(): SignalDisplayFilters {
  if (!isBrowser()) return normalizeSignalDisplayFilters(null)
  try {
    const raw = window.localStorage.getItem(LS_KEY)
    if (!raw) {
      // MIGRATION — reprendre l'ancien switch « Tags & labels ».
      try {
        const legacy = window.localStorage.getItem(LEGACY_LS_KEY)
        if (legacy) {
          const parsed = JSON.parse(legacy) as { showLabels?: unknown }
          const migrated = normalizeSignalDisplayFilters(null)
          if (typeof parsed.showLabels === 'boolean') migrated.showLabels = parsed.showLabels
          return migrated
        }
      } catch { /* legacy illisible — défauts */ }
      return normalizeSignalDisplayFilters(null)
    }
    return normalizeSignalDisplayFilters(JSON.parse(raw))
  } catch {
    return normalizeSignalDisplayFilters(null)
  }
}

/** Persiste les filtres et notifie les souscripteurs (overlay, panneau). */
export function saveSignalDisplayFilters(patch: Partial<SignalDisplayFilters>): SignalDisplayFilters {
  const current = loadSignalDisplayFilters()
  const next = normalizeSignalDisplayFilters({ ...current, ...patch, ...('showLabels' in patch ? {} : {}) } as unknown)
  if (patch.showLabels === undefined) next.showLabels = current.showLabels
  if (isBrowser()) {
    try { window.localStorage.setItem(LS_KEY, JSON.stringify(next)) } catch { /* quota/private */ }
  }
  for (const l of listeners) l(next)
  return next
}

/** Applique un preset (§24 — affichage seul) et persiste. */
export function saveSignalDisplayPreset(preset: SignalDisplayPreset): SignalDisplayFilters {
  const current = loadSignalDisplayFilters()
  const next = applySignalDisplayPreset(current, preset)
  if (isBrowser()) {
    try { window.localStorage.setItem(LS_KEY, JSON.stringify(next)) } catch { /* quota/private */ }
  }
  for (const l of listeners) l(next)
  return next
}

/** Souscrit aux changements (retourne la fonction de désabonnement). */
export function subscribeSignalDisplayFilters(listener: Listener): () => void {
  listeners.add(listener)
  return () => { listeners.delete(listener) }
}
