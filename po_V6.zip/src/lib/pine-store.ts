'use client'

import { create } from 'zustand'
import type { PineExecutionResult, PineScriptMeta } from './pine-engine'

/**
 * Coherence envelope around a Pine execution result (v1.9 — spec §12/§25).
 * Every result committed to the store carries the identity of the dataset it
 * was computed from. A result may only be RENDERED while its context still
 * matches the live dataset context; the store refuses any commit whose
 * revision is older than the newest committed revision (latest-result-wins).
 */
export interface PineExecutionEnvelope {
  /** Monotonic dataset revision the script was executed against. */
  revision: number
  asset: string
  /** Candle size in seconds. */
  timeframe: number
  /** Dataset first bar (epoch sec). */
  firstBarTime: number
  /** Dataset last bar (epoch sec). */
  lastBarTime: number
  /** Number of candles the script consumed. */
  barCount: number
  committedAt: number
}

export interface PineExecutionEnvelopeInput {
  revision: number
  asset: string
  timeframe: number
  firstBarTime: number
  lastBarTime: number
  barCount: number
}

/** Identity of the dataset the whole app should currently be looking at. */
export interface PineDatasetContext {
  revision: number
  asset: string
  timeframe: number
  lastBarTime: number
  barCount: number
}

export interface PineScriptInstance {
  id: string
  name: string
  source: string
  meta: PineScriptMeta
  enabled: boolean
  result: PineExecutionResult | null
  /** Coherence metadata for `result` (null ⇔ result is null). */
  envelope: PineExecutionEnvelope | null
  error: string | null
  updatedAt: number
  /** User overrides keyed by input title (PineInputDecl.key). `{}` = defaults. */
  inputValues: Record<string, unknown>
}

const uid = () => `pine-${Math.random().toString(36).slice(2, 10)}`

function isProduction(): boolean {
  return typeof process !== 'undefined' && process.env?.NODE_ENV === 'production'
}

/**
 * Sources (never results — plot arrays are too large for localStorage) are
 * persisted so loaded scripts survive a page reload. Execution re-runs
 * automatically once the chart has ≥2 candles. Since v1.3 the per-script
 * settings (inputValues) are persisted too, so the Réglages panel survives
 * reloads.
 */
const STORAGE_KEY = 'pine-scripts-v1'

interface PersistedScript {
  id: string
  name: string
  source: string
  meta: PineScriptMeta
  enabled: boolean
  inputValues?: Record<string, unknown>
}

function loadPersisted(): PersistedScript[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw) as PersistedScript[]
    return Array.isArray(parsed)
      ? parsed.filter((s) => s && typeof s.source === 'string' && typeof s.id === 'string')
      : []
  } catch { return [] }
}

function persist(scripts: PineScriptInstance[]): void {
  if (typeof window === 'undefined') return
  try {
    const light: PersistedScript[] = scripts.map((s) => ({
      id: s.id, name: s.name, source: s.source, meta: s.meta, enabled: s.enabled,
      inputValues: s.inputValues && Object.keys(s.inputValues).length ? s.inputValues : undefined,
    }))
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(light))
  } catch { /* quota exceeded — keep in-memory only */ }
}

const withInputValues = (s: PersistedScript): PineScriptInstance => ({
  ...s,
  inputValues: s.inputValues && typeof s.inputValues === 'object' ? s.inputValues : {},
  result: null,
  envelope: null,
  error: null,
  updatedAt: Date.now(),
})

const EMPTY_DATASET: PineDatasetContext = {
  revision: 0,
  asset: '',
  timeframe: 0,
  lastBarTime: 0,
  barCount: 0,
}

interface PineStore {
  scripts: PineScriptInstance[]
  activeId: string | null
  /** Increments on every settings change so effects re-run Pine immediately. */
  settingsRev: number
  /** Current dataset identity — bumped by the execution coordinator on
   * every accepted snapshot (new bar / forming recalc / dataset replace). */
  dataset: PineDatasetContext
  addScript: (source: string, name?: string) => string
  removeScript: (id: string) => void
  setActive: (id: string | null) => void
  updateScript: (id: string, source: string, meta: PineScriptMeta) => void
  /** Legacy single-script commit — DEPRECATED: bypasses freshness guards.
   * Retained for ad-hoc/manual paths; the coordinator uses commitExecution. */
  setExecution: (id: string, result: PineExecutionResult | null, error: string | null) => void
  /** Publish the dataset context of the CURRENT snapshot (coordinator only). */
  publishDataset: (ctx: PineDatasetContext) => void
  /** Drop every stored result (asset/timeframe switch — spec §23/§24: no
   *  result from a previous market may remain displayed on the new one). */
  clearAllResults: () => void
  /** Atomic grouped commit (spec §15): all scripts of one snapshot land in a
   * single store update; entries whose revision/context are stale are
   * REFUSED so an obsolete async result can never rewrite a newer one. */
  commitExecution: (entries: Array<CommitEntry>) => void
  toggle: (id: string) => void
  setInputValue: (id: string, key: string, value: unknown) => void
  resetInputValues: (id: string) => void
}

export interface CommitEntry {
  id: string
  result: PineExecutionResult | null
  error: string | null
  envelope: PineExecutionEnvelopeInput
}

export const usePineStore = create<PineStore>((set, get) => ({
  scripts: loadPersisted().map(withInputValues),
  activeId: loadPersisted()[0]?.id ?? null,
  settingsRev: 0,
  dataset: EMPTY_DATASET,
  addScript: (source, name) => {
    const id = uid()
    const meta = { version: 6, declaration: 'unknown', title: name || 'Untitled Pine Script', overlay: true } as PineScriptMeta
    set((s) => {
      const scripts = [...s.scripts, { id, name: name || meta.title, source, meta, enabled: true, result: null, envelope: null, error: null, updatedAt: Date.now(), inputValues: {} }]
      persist(scripts)
      return { scripts, activeId: id }
    })
    return id
  },
  removeScript: (id) => set((s) => {
    const scripts = s.scripts.filter((x) => x.id !== id)
    persist(scripts)
    return { scripts, activeId: s.activeId === id ? (scripts.at(-1)?.id ?? null) : s.activeId }
  }),
  setActive: (id) => set({ activeId: id }),
  updateScript: (id, source, meta) => set((s) => {
    const scripts = s.scripts.map((x) => x.id === id ? { ...x, source, meta, name: meta.title || x.name, error: null, updatedAt: Date.now() } : x)
    persist(scripts)
    return { scripts }
  }),
  setExecution: (id, result, error) => set((s) => ({
    scripts: s.scripts.map((x) => x.id === id ? { ...x, result, error, updatedAt: Date.now() } : x),
  })),
  publishDataset: (ctx) => {
    const cur = get().dataset
    // Monotonic: a late `publishDataset` for an older revision must not roll
    // the dataset context back (coordinator is single-flight, this is a belt).
    if (ctx.revision < cur.revision) return
    if (ctx.revision === cur.revision
      && ctx.asset === cur.asset
      && ctx.timeframe === cur.timeframe
      && ctx.lastBarTime === cur.lastBarTime
      && ctx.barCount === cur.barCount) return
    set({ dataset: ctx })
  },
  clearAllResults: () => set((s) => ({
    scripts: s.scripts.map((x) =>
      x.result == null && x.envelope == null ? x : { ...x, result: null, envelope: null, updatedAt: Date.now() }),
  })),
  commitExecution: (entries) => {
    if (!entries.length) return
    const state = get()
    const dataset = state.dataset
    // FRESHNESS GUARD (spec §4/§12): refuse any entry that targets a dataset
    // context older than the one the store already displays results for.
    const accepted = entries.filter((e) => {
      if (e.result == null && e.error == null) return false
      if (e.envelope.revision < dataset.revision) {
        if (!isProduction()) {
          console.warn(
            `[pine-store] REFUSED stale commit for ${e.id}: revision ${e.envelope.revision} < current ${dataset.revision}`,
          )
        }
        return false
      }
      // Context switch (asset/timeframe change) invalidates everything older.
      if (dataset.revision > 0
        && (e.envelope.asset !== dataset.asset || e.envelope.timeframe !== dataset.timeframe)) {
        if (!isProduction()) {
          console.warn(
            `[pine-store] REFUSED foreign-context commit for ${e.id}: ${e.envelope.asset}/${e.envelope.timeframe}s vs current ${dataset.asset}/${dataset.timeframe}s`,
          )
        }
        return false
      }
      return true
    })
    if (!accepted.length) return
    const byId = new Map(accepted.map((e) => [e.id, e]))
    set((s) => ({
      scripts: s.scripts.map((x) => {
        const e = byId.get(x.id)
        if (!e) return x
        const envelope: PineExecutionEnvelope = { ...e.envelope, committedAt: Date.now() }
        return { ...x, result: e.result, envelope, error: e.error, updatedAt: Date.now() }
      }),
    }))
  },
  toggle: (id) => set((s) => {
    const scripts = s.scripts.map((x) => x.id === id ? { ...x, enabled: !x.enabled } : x)
    persist(scripts)
    return { scripts }
  }),
  setInputValue: (id, key, value) => set((s) => {
    const scripts = s.scripts.map((x) => {
      if (x.id !== id) return x
      const inputValues = { ...x.inputValues, [key]: value }
      return { ...x, inputValues, updatedAt: Date.now() }
    })
    persist(scripts)
    return { scripts, settingsRev: s.settingsRev + 1 }
  }),
  resetInputValues: (id) => set((s) => {
    const scripts = s.scripts.map((x) => x.id === id ? { ...x, inputValues: {}, updatedAt: Date.now() } : x)
    persist(scripts)
    return { scripts, settingsRev: s.settingsRev + 1 }
  }),
}))
