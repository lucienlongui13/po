'use client'

/**
 * Pine community-library registry — v1.7 multi-library edition.
 *
 * `@heyphat/piner` compiles `import author/libName/version` statements only
 * from an in-memory registry — it never fetches anything. TradingView
 * community scripts routinely import SEVERAL libraries at once (and those
 * libraries import each other): e.g. the "BOS, CHoCH and CISD" pack is
 * Main.pine → { PubLibSwing/3 → PubLibCandleTrend/2, PubLibTrend/3 → PubLibSwing/3,
 * PubLibUtility/2 }.
 *
 * This module therefore provides:
 *   • a localStorage-backed registry the user can populate one-by-one (legacy
 *     "Libraries" form) OR in bulk (ZIP archive / multi-file upload);
 *   • automatic registry-key derivation: library files declare themselves with
 *     `library("Name")` but the canonical key is `author/name/version`, which
 *     is only written in the IMPORT statements of the other files — so the
 *     bundle importer cross-references every `import` found in the pack to
 *     recover each library's exact key;
 *   • transitive dependency validation: walks import → library → import… so
 *     the editor can list every STILL-missing path with its importer chain;
 *   • built-in compat shims for known transitive dependencies that are not
 *     redistributed inside community packs (overridable by the user).
 */

const STORAGE_KEY = 'pine-libraries-v1'

export interface PineLibraryEntry {
  /** Canonical import path: author/name/version */
  key: string
  source: string
  addedAt: number
  /** True for code-shipped compat shims (not deletable, overridable). */
  builtin?: boolean
  /** Short explanation shown in the UI for built-in shims. */
  note?: string
}

type RegistryMap = Map<string, PineLibraryEntry>

let cache: RegistryMap | null = null

/**
 * Compat ships for transitive dependencies commonly NOT included in community
 * packs. `PubLibSwing/3` imports `PiracyChecker/PubLibCandleTrend/2` but packs
 * built around it (BOS/CHoCH/CISD…) ship only their three direct libraries —
 * without this shim the pack cannot compile offline. The two exports actually
 * consumed by PubLibSwing are `gc()` / `rc()`, whose semantics are fixed by
 * usage (Main.pine itself defines green_candle = close >= open). Registering a
 * user source under the same key replaces the shim entirely.
 */
const BUILTIN_COMPAT_LIBRARIES: PineLibraryEntry[] = [
  {
    key: 'PiracyChecker/PubLibCandleTrend/2',
    addedAt: 0,
    builtin: true,
    note: 'Shim compat — gc()/rc() uniquement. Remplaçable par la source officielle.',
    source: `// Compat shim (pine_v6_engine v1.7) — transitive dependency of PubLibSwing/3.
// The official library ("PubLibCandleTrend" by theEccentricTrader / mirrored by
// PiracyChecker) exports many more conditions; this shim provides exactly the
// two functions PubLibSwing consumes, with the semantics fixed by usage:
// Main.pine defines green_candle = close >= open and red_candle = close < open.
// Register the official source under this same key to replace the shim.
//@version=6
library('PubLibCandleTrend')

// @function green candle condition
// @returns bool
export gc() =>
    close >= open

// @function red candle condition
// @returns bool
export rc() =>
    close < open
`,
  },
]

function builtinByKey(key: string): PineLibraryEntry | undefined {
  return BUILTIN_COMPAT_LIBRARIES.find((b) => b.key === key)
}

function load(): RegistryMap {
  if (cache) return cache
  cache = new Map()
  if (typeof window === 'undefined') return cache
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    if (!raw) return cache
    const parsed = JSON.parse(raw) as PineLibraryEntry[]
    for (const entry of Array.isArray(parsed) ? parsed : []) {
      if (entry && typeof entry.key === 'string' && typeof entry.source === 'string') {
        cache.set(entry.key, { key: entry.key, source: entry.source, addedAt: Number(entry.addedAt) || Date.now() })
      }
    }
  } catch { /* corrupted storage — start fresh */ }
  return cache
}

function persist(): void {
  if (typeof window === 'undefined') return
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify([...load().values()]))
  } catch { /* quota exceeded — keep memory copy */ }
}

/** User-registered libraries (most recent first), then built-in compat shims
 *  NOT shadowed by a user entry under the same key. */
export function listLibraries(): PineLibraryEntry[] {
  const user = [...load().values()].sort((a, b) => b.addedAt - a.addedAt)
  const userKeys = new Set(user.map((e) => e.key))
  const builtins = [...BUILTIN_COMPAT_LIBRARIES]
    .filter((b) => !userKeys.has(b.key))
    .sort((a, b) => a.key.localeCompare(b.key))
  return [...user, ...builtins]
}

export function addLibrary(key: string, source: string): { ok: boolean; error?: string } {
  const normalized = key.trim().replace(/^\/+|\/+$/g, '')
  const parts = normalized.split('/')
  if (parts.length !== 3 || parts.some((p) => !p)) {
    return { ok: false, error: 'Library path must be author/name/version (e.g. TradingView/ZigZag/7)' }
  }
  if (!/@version\s*=\s*6/i.test(source) && !/@version\s*=\s*5/i.test(source)) {
    return { ok: false, error: 'Library source must start with a //@version=5 or //@version=6 annotation' }
  }
  if (!/\blibrary\s*\(/i.test(source)) {
    return { ok: false, error: 'Library source must declare itself with library("name", …)' }
  }
  load().set(normalized, { key: normalized, source, addedAt: Date.now() })
  persist()
  return { ok: true }
}

/**
 * Removes a user-registered library. Deleting from the user map never touches
 * the built-in compat shims (they live in a separate array, not in the map):
 * deleting a user entry that shadowed a builtin key simply RESTORES the shim.
 */
export function removeLibrary(key: string): void {
  load().delete(key)
  persist()
}

/** User source first, then the built-in compat shim for that key. */
export function getLibrarySource(key: string): string | undefined {
  return load().get(key)?.source ?? builtinByKey(key)?.source
}

/**
 * Registry form accepted by piner's compile()/compileAsync(). User-registered
 * sources take precedence over built-in shims on the same canonical key — and
 * duplicates are impossible because piner rejects registries with two entries
 * normalizing to the same identity.
 */
export function asPinerRegistry(): Array<{ key: string; source: string }> {
  const seen = new Set<string>()
  const out: Array<{ key: string; source: string }> = []
  for (const entry of load().values()) {
    if (seen.has(entry.key)) continue
    seen.add(entry.key)
    out.push({ key: entry.key, source: entry.source })
  }
  for (const builtin of BUILTIN_COMPAT_LIBRARIES) {
    if (seen.has(builtin.key)) continue
    seen.add(builtin.key)
    out.push({ key: builtin.key, source: builtin.source })
  }
  return out
}

// ─────────────────────────────────────────────────────────────────────────────
// Source inspection & import cross-referencing
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Extract the `import author/lib/version as alias` statements of a Pine source.
 * Works for main scripts AND for libraries (a library may import other
 * libraries — piner resolves the whole graph).
 */
export function extractImports(source: string): Array<{ path: string; alias: string }> {
  const out: Array<{ path: string; alias: string }> = []
  const re = /^[ \t]*import\s+([A-Za-z0-9_.\-]+\/[A-Za-z0-9_.\-]+\/[A-Za-z0-9_.\-]+)\s+as\s+([A-Za-z_][A-Za-z0-9_]*)/gm
  let m: RegExpExecArray | null
  while ((m = re.exec(source)) !== null) out.push({ path: m[1], alias: m[2] })
  return out
}

/** Legacy helper — unique import paths only (kept for existing callers). */
export function extractImportPaths(source: string): string[] {
  return [...new Set(extractImports(source).map((i) => i.path))]
}

export interface SourceKind {
  /** 'library' | 'indicator' | 'strategy' | 'unknown' */
  declaration: 'library' | 'indicator' | 'strategy' | 'unknown'
  /** Title from the declaration call — for libraries, the name used by `import` matching. */
  title: string
}

/** Local mirror of inspectPineSource (avoids a pine-engine ↔ pine-libraries cycle). */
export function inspectSourceKind(source: string): SourceKind {
  const decl = source.match(/\b(library|indicator|strategy)\s*\(([^)]*)\)/i)
  if (!decl) return { declaration: 'unknown', title: '' }
  const args = decl[2] ?? ''
  const title = args.match(/^\s*["']([^"']+)["']/)?.[1] ?? ''
  return { declaration: decl[1].toLowerCase() as SourceKind['declaration'], title }
}

/** The library-name segment of a canonical `author/name/version` path. */
function libSegment(path: string): string {
  const parts = path.split('/')
  return parts.length === 3 ? parts[1] : ''
}

/** Version as a comparable number (non-numeric → 0), for "highest version wins". */
function versionRank(path: string): number {
  const v = Number(path.split('/')[2])
  return Number.isFinite(v) ? v : 0
}

// ─────────────────────────────────────────────────────────────────────────────
// Bundle import (ZIP / multi-file)
// ─────────────────────────────────────────────────────────────────────────────

export interface BundleFile {
  /** File name or archive path — used for messages and filename fallbacks. */
  name: string
  source: string
}

export interface DerivedLibrary {
  file: BundleFile
  libName: string
  /** Primary canonical registry key derived for this file. */
  key: string
  /**
   * Additional canonical keys under which the SAME file must also be
   * registered. Community packs are frequently MIRRORED: the pack's Main
   * imports «PiracyChecker/PubLibSwing/3» while a bundled library still
   * imports the original «theEccentricTrader/PubLibSwing/3» — one file,
   * two import paths. Without alias registration the transitive import
   * stays unresolved and compilation fails.
   */
  aliases: string[]
  /** 'import' = recovered from an import statement of the bundle; 'fallback' = guessed. */
  matched: 'import' | 'fallback'
}

export interface DerivedMainScript {
  file: BundleFile
  title: string
  declaration: 'indicator' | 'strategy' | 'unknown'
}

export interface DerivedBundle {
  libraries: DerivedLibrary[]
  mainScripts: DerivedMainScript[]
  skipped: Array<{ file: BundleFile; reason: string }>
}

/**
 * Classify the files of an uploaded pack and derive each library's registry
 * key(s) by cross-referencing every `import author/name/version` statement found
 * across ALL files of the pack (a library's own key never appears in its own
 * source — it is only written by whoever imports it).
 *
 * Identity model:
 *   • A library file's authoritative identity is its `library("Name")` title
 *     (the stem is only a fallback when the declaration carries no title).
 *   • Every import path whose NAME segment equals that identity references the
 *     same file. The highest version (then lexicographic order) becomes the
 *     PRIMARY key; the other paths become ALIASES — mirrored packs routinely
 *     import one library under two publishers (e.g. «PiracyChecker/PubLibSwing/3»
 *     from the Main script AND «theEccentricTrader/PubLibSwing/3» from PubLibTrend).
 *   • When SEVERAL files of the pack share the same identity (two same-named
 *     libraries), files and paths are PAIRED in sorted order — each file gets
 *     its own path, no aliasing, extras fall back to `local/<stem>/1`.
 *
 * References are also collected from the ALREADY-REGISTERED libraries, so a
 * partial import (libs without the Main) still recovers every canonical path.
 */
export function deriveLibraryKeys(files: BundleFile[]): DerivedBundle {
  // Collect canonical paths referenced across the bundle…
  const refsByName = new Map<string, Set<string>>()
  const recordRef = (name: string, path: string) => {
    const k = name.toLowerCase()
    const set = refsByName.get(k) ?? new Set<string>()
    set.add(path)
    refsByName.set(k, set)
  }
  for (const file of files) {
    for (const imp of extractImports(file.source)) {
      const seg = libSegment(imp.path)
      if (seg) recordRef(seg, imp.path)
    }
  }
  // …and across already-registered libraries (a new file may complete an
  // existing registry — e.g. pasting the missing CandleTrend later).
  for (const entry of listLibraries()) {
    for (const imp of extractImports(entry.source)) {
      const seg = libSegment(imp.path)
      if (seg) recordRef(seg, imp.path)
    }
  }

  const pathOrder = (a: string, b: string) => versionRank(b) - versionRank(a) || (a < b ? -1 : a > b ? 1 : 0)

  const libraries: DerivedLibrary[] = []
  const mainScripts: DerivedMainScript[] = []
  const skipped: Array<{ file: BundleFile; reason: string }> = []

  // Pass 1 — classify: libraries (staged by identity) vs main scripts.
  const staged: Array<{ file: BundleFile; libName: string; stem: string }> = []
  for (const file of files) {
    if (!file.source.trim()) {
      skipped.push({ file, reason: 'fichier vide' })
      continue
    }
    const kind = inspectSourceKind(file.source)
    if (kind.declaration === 'library') {
      const stem = (file.name.split('/').pop() ?? file.name)
      const libName = kind.title || stem.replace(/\.(pine|txt)$/i, '')
      staged.push({ file, libName, stem })
    } else {
      // indicator / strategy / header-less snippet → candidate main script
      mainScripts.push({ file, title: kind.title || (file.name.split('/').pop() ?? file.name).replace(/\.(pine|txt)$/i, ''), declaration: kind.declaration === 'unknown' ? 'unknown' : kind.declaration })
    }
  }

  // Pass 2 — group staged files by identity, then assign paths per group.
  const groups = new Map<string, typeof staged>()
  for (const s of staged) {
    const g = groups.get(s.libName.toLowerCase()) ?? []
    g.push(s)
    groups.set(s.libName.toLowerCase(), g)
  }
  for (const [seg, group] of groups) {
    // Deterministic order on both sides, whatever the upload order was.
    group.sort((a, b) => (a.file.name < b.file.name ? -1 : a.file.name > b.file.name ? 1 : 0))
    const paths = [...(refsByName.get(seg) ?? [])].sort(pathOrder)

    if (group.length === 1) {
      // Single owner of the identity → it answers EVERY referenced path
      // (primary = highest version; the rest are author aliases).
      const s = group[0]
      const keys = paths.length ? paths : [fallbackKey(s.stem)]
      libraries.push({ file: s.file, libName: s.libName, key: keys[0], aliases: keys.slice(1), matched: paths.length ? 'import' : 'fallback' })
    } else {
      // Several same-named files → 1:1 pairing, no aliasing.
      group.forEach((s, i) => {
        const path = paths[i]
        if (path) {
          libraries.push({ file: s.file, libName: s.libName, key: path, aliases: [], matched: 'import' })
        } else {
          libraries.push({ file: s.file, libName: s.libName, key: fallbackKey(s.stem), aliases: [], matched: 'fallback' })
        }
      })
    }
  }
  // Stable, readable output order.
  libraries.sort((a, b) => (a.libName < b.libName ? -1 : a.libName > b.libName ? 1 : 0))
  return { libraries, mainScripts, skipped }
}

function fallbackKey(stem: string): string {
  const cleaned = (stem.replace(/\.(pine|txt)$/i, '').replace(/[^A-Za-z0-9_.\-]/g, '-') || 'Library')
  return `local/${cleaned}/1`
}

export interface ImportBundleReport {
  /** Libraries registered into the persistent registry (one entry per FILE —
   * `keys` lists every canonical path it now answers to, aliases included). */
  registered: Array<{ fileName: string; libName: string; key: string; keys: string[]; matched: 'import' | 'fallback'; replacedBuiltin?: boolean; replacedUser?: boolean }>
  /** Aliases completed ACROSS imports: a path imported by the bundle's main
   * scripts (or by an already-registered library) that resolved to nothing but
   * whose name+version matches a registered library published under another
   * key — e.g. libs imported first, Main.pine loaded afterwards. */
  aliased: Array<{ path: string; from: string }>
  /** Non-library files the caller may add to the Pine editor. */
  mainScripts: DerivedMainScript[]
  skipped: Array<{ file: BundleFile; reason: string }>
  /** Still-missing transitive dependencies (computed AFTER registration). */
  missing: MissingLibrary[]
}

/**
 * Register every library file of a pack with its derived canonical key, then
 * complete cross-import aliases, then validate the transitive import closure
 * of the pack's main scripts (and of the registered libraries themselves).
 * Pure registry operation — the caller decides what to do with `mainScripts`.
 */
export function importLibraryBundle(files: BundleFile[]): ImportBundleReport {
  const derived = deriveLibraryKeys(files)
  const registered: ImportBundleReport['registered'] = []

  for (const lib of derived.libraries) {
    const previousUser = load().get(lib.key)
    const previousBuiltin = builtinByKey(lib.key)
    const res = addLibrary(lib.key, lib.file.source)
    if (!res.ok) {
      derived.skipped.push({ file: lib.file, reason: res.error ?? 'validation échouée' })
      continue
    }
    // Author aliasing — the same file also answers to every mirrored path so
    // libraries importing the ORIGINAL publisher keep resolving.
    const keys = [lib.key]
    for (const alias of lib.aliases) {
      const aliasRes = addLibrary(alias, lib.file.source)
      if (aliasRes.ok) keys.push(alias)
    }
    registered.push({
      fileName: lib.file.name.split('/').pop() ?? lib.file.name,
      libName: lib.libName,
      key: lib.key,
      keys,
      matched: lib.matched,
      replacedBuiltin: !previousUser && Boolean(previousBuiltin),
      replacedUser: Boolean(previousUser),
    })
  }

  // ── Cross-import alias completion ──
  // Walk the imports of the bundle's main scripts AND of every registered
  // library; for each path that resolves to nothing, look for a registered
  // library of the SAME name and version published under a different key and
  // register the path as an alias of it. This glues together partial imports
  // (libs pack first, Main.pine loaded later — or the reverse).
  const aliased: ImportBundleReport['aliased'] = []
  const rootsForAliases = [
    ...derived.mainScripts.map((m) => m.file.source),
    ...[...load().values()].map((e) => e.source),
  ]
  const seenCompletion = new Set<string>()
  for (const rootSource of rootsForAliases) {
    for (const imp of extractImports(rootSource)) {
      if (seenCompletion.has(imp.path)) continue
      seenCompletion.add(imp.path)
      if (getLibrarySource(imp.path)) continue // already resolves
      const seg = libSegment(imp.path).toLowerCase()
      if (!seg) continue
      for (const entry of [...load().values()]) {
        const entrySeg = libSegment(entry.key)
        const sameName = entrySeg.toLowerCase() === seg || inspectSourceKind(entry.source).title.toLowerCase() === seg
        // A `local/…` fallback key carries no authoritative version (we invented
        // it when nothing referenced the file) — matching by name is then the
        // only available signal, so the version guard must not block completion.
        const entryIsFallback = entry.key.startsWith('local/')
        const sameVersion = entryIsFallback || versionRank(entry.key) === versionRank(imp.path)
        if (sameName && sameVersion) {
          addLibrary(imp.path, entry.source)
          aliased.push({ path: imp.path, from: entry.key })
          break
        }
      }
    }
  }

  const roots = [
    ...derived.mainScripts.map((m) => m.file.source),
    ...registered.map((r) => r.key).map((key) => load().get(key)?.source ?? builtinByKey(key)?.source ?? ''),
  ].filter(Boolean)

  return {
    registered,
    aliased,
    mainScripts: derived.mainScripts,
    skipped: derived.skipped,
    missing: computeMissingLibraries(roots),
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Transitive dependency validation
// ─────────────────────────────────────────────────────────────────────────────

export interface MissingLibrary {
  /** Canonical `author/name/version` path that resolves to nothing. */
  path: string
  /** Who imports it — 'script principal' or the importing library's key. */
  importers: string[]
}

/**
 * Walk the full import graph (root script → libraries → their imports → …)
 * against the registry (user + built-ins) and list every path that cannot be
 * resolved, with the chain of importers. Cycle-safe.
 */
export function computeMissingLibraries(roots: string | string[]): MissingLibrary[] {
  const queue: Array<{ source: string; importer: string }> = (Array.isArray(roots) ? roots : [roots])
    .filter((s) => typeof s === 'string' && s.trim())
    .map((source) => ({ source, importer: 'script principal' }))
  const walked = new Set<string>()
  const missing = new Map<string, Set<string>>()

  while (queue.length) {
    const item = queue.shift()!
    for (const imp of extractImports(item.source)) {
      const resolved = load().get(imp.path)?.source ?? builtinByKey(imp.path)?.source
      if (!resolved) {
        const importers = missing.get(imp.path) ?? new Set<string>()
        importers.add(item.importer)
        missing.set(imp.path, importers)
        continue
      }
      if (walked.has(imp.path)) continue
      walked.add(imp.path)
      queue.push({ source: resolved, importer: imp.path })
    }
  }

  return [...missing.entries()]
    .map(([path, importers]) => ({ path, importers: [...importers] }))
    .sort((a, b) => a.path.localeCompare(b.path))
}
