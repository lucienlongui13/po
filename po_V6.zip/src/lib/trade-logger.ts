/**
 * trade-logger.ts — Journalisation des trades du Strategy Tester.
 * ==============================================================
 *
 * Switch « Log trades » (Strategy Tester) : quand il est ON, CHAQUE trade
 * simulé (CALL/PUT) réglé par le backtest replay est journalisé dans le
 * fichier `.logs/trade.jsonl` (une ligne JSON par trade) avec :
 *
 *   - le trade complet (côté, mise, payout, entrée/sortie, résultat, P&L) ;
 *   - la source de l'ordre (manuelle — ordre placé depuis le panneau Order
 *     en mode replay) ;
 *   - les bougies OHLC autour de l'entrée et jusqu'au règlement ;
 *   - le contexte (actif, timeframe, solde, P&L, vitesse de replay).
 *
 * Quand le switch est OFF : RIEN n'est collecté ni envoyé (les trades
 * réglés pendant OFF ne sont jamais loggés).
 *
 * L'écriture passe par l'API Next.js `POST /api/trade-log` qui append les
 * lignes dans `.logs/trade.jsonl` (créé au besoin). La préférence ON/OFF
 * est persistée (localStorage `trade-logger-enabled-v1`).
 */

import type { CandleLike } from './indicators'
import type { ReplayEngine, SimOrder, BacktestStats, ReplayState } from './replay-engine'

const STORAGE_KEY = 'trade-logger-enabled-v1'
/** Garde-fou mémoire : au-delà, les plus vieilles entrées en attente sont jetées. */
const MAX_QUEUE = 200
/** Taille max d'une ligne JSON (les bougies pendant un trade très long). */
const MAX_LINE_CHARS = 256 * 1024

/* ────────────────────────────────────────────────────────── types publics */

export interface TradeLoggerContext {
  asset: string
  candleSize: number
}

export interface TradeLogCandle {
  time: number
  open: number
  high: number
  low: number
  close: number
}

export interface TradeLogEntry {
  type: 'trade'
  loggedAt: string
  trade: {
    id: string
    side: 'call' | 'put'
    amount: number
    payout: number
    entry: { idx: number; time: number; price: number }
    exit: { idx: number; time: number; price: number } | null
    expiryCandles: number
    status: 'won' | 'lost' | 'refunded'
    profit: number
  }
  source: {
    kind: 'manual'
    label: string
  }
  /** Bougies OHLC de la fenêtre avant le trade. */
  candlesBefore: TradeLogCandle[]
  /** Bougies OHLC pendant le trade (après l'entrée, jusqu'au règlement). */
  candlesDuring: TradeLogCandle[]
  context: {
    asset: string
    candleSize: number
    balance: number
    netProfit: number
    replaySpeedMs: number
    mode: 'replay'
  }
}

export type TradeLoggerListener = () => void

/* ────────────────────────────────────────────────────────── helpers */

function toLogCandle(c: CandleLike): TradeLogCandle {
  return { time: c.time, open: c.open, high: c.high, low: c.low, close: c.close }
}

/* ────────────────────────────────────────────────────────── TradeLogger */

export class TradeLogger {
  private replay: ReplayEngine
  private endpoint: string
  private fetchImpl: typeof fetch

  private _enabled = false
  /** orderId → dernier statut vu (détection des transitions open → réglé). */
  private seen = new Map<string, string>()
  /** orderIds déjà journalisés (anti-doublon après reset partiel). */
  private logged = new Set<string>()
  private queue: TradeLogEntry[] = []
  private flushing = false
  private retryTimer: ReturnType<typeof setTimeout> | null = null
  private _loggedCount = 0
  private _lastError: string | null = null
  private contextProvider: (() => TradeLoggerContext) | null = null
  private listeners = new Set<TradeLoggerListener>()
  private unsubs: Array<() => void> = []

  constructor(
    replay: ReplayEngine,
    opts?: { endpoint?: string; fetchImpl?: typeof fetch },
  ) {
    this.replay = replay
    this.endpoint = opts?.endpoint ?? '/api/trade-log'
    this.fetchImpl = opts?.fetchImpl ?? ((...a: Parameters<typeof fetch>) => fetch(...a))

    // Préférence persistée (défaut : OFF — on ne log rien tant que
    // l'utilisateur n'a pas activé le switch).
    if (typeof window !== 'undefined') {
      try { this._enabled = window.localStorage.getItem(STORAGE_KEY) === '1' } catch { /* quota */ }
    }

    this.unsubs.push(
      replay.onState((state, stats, orders) => this.handleState(state, stats, orders)),
    )
    this.unsubs.push(
      replay.onOrdersReset(() => {
        // Les ordres référencés n'existent plus → tout l'état de suivi est
        // obsolète.
        this.seen.clear()
        this.logged.clear()
        this.emit()
      }),
    )
  }

  /* ───────────────────────────── API publique ───────────────────────────── */

  get enabled(): boolean { return this._enabled }
  get loggedCount(): number { return this._loggedCount }
  get queuedCount(): number { return this.queue.length }
  get lastError(): string | null { return this._lastError }

  setEnabled(v: boolean): void {
    if (this._enabled === v) return
    this._enabled = v
    if (typeof window !== 'undefined') {
      try { window.localStorage.setItem(STORAGE_KEY, v ? '1' : '0') } catch { /* quota */ }
    }
    if (!v) {
      // OFF → on jette tout ce qui était en attente (« on ne log rien »).
      if (this.retryTimer !== null) { clearTimeout(this.retryTimer); this.retryTimer = null }
      this.queue = []
      this._lastError = null
    } else if (this.queue.length > 0) {
      void this.flush()
    }
    this.emit()
  }

  setContextProvider(fn: (() => TradeLoggerContext) | null): void {
    this.contextProvider = fn
  }

  subscribe(listener: TradeLoggerListener): () => void {
    this.listeners.add(listener)
    return () => { this.listeners.delete(listener) }
  }

  dispose(): void {
    for (const u of this.unsubs) { try { u() } catch { /* déjà parti */ } }
    this.unsubs = []
    if (this.retryTimer !== null) { clearTimeout(this.retryTimer); this.retryTimer = null }
    this.listeners.clear()
  }

  /* ───────────────────────────── internes ───────────────────────────── */

  private emit(): void {
    for (const l of this.listeners) {
      try { l() } catch (e) { console.error('[TradeLogger] listener', e) }
    }
  }

  private handleState(_state: ReplayState, stats: BacktestStats, orders: SimOrder[]): void {
    for (const o of orders) {
      if (o.status === 'open') {
        this.seen.set(o.id, 'open')
        continue
      }
      // Réglé (won / lost / refunded) et pas encore journalisé → logger une
      // seule fois, au moment où le règlement devient visible.
      if (this.logged.has(o.id)) continue
      this.logged.add(o.id)
      this.seen.set(o.id, o.status)
      if (this._enabled) this.enqueue(o, stats, _state)
    }
  }

  private enqueue(order: SimOrder, stats: BacktestStats, state: ReplayState): void {
    try {
      const entry = this.buildEntry(order, stats, state)
      if (!entry) return
      this.queue.push(entry)
      if (this.queue.length > MAX_QUEUE) this.queue.splice(0, this.queue.length - MAX_QUEUE)
      void this.flush()
    } catch (e) {
      console.error('[TradeLogger] build entry', e)
    }
  }

  /** Construit l'entrée JSONL d'un trade réglé (bougies avant / pendant). */
  private buildEntry(order: SimOrder, stats: BacktestStats, state: ReplayState): TradeLogEntry | null {
    const visible = this.replay.getVisible()
    if (visible.length === 0) return null
    const ctx = this.contextProvider?.() ?? { asset: '', candleSize: 0 }
    const entryIdx = Math.max(0, Math.min(order.entryIdx, visible.length - 1))
    const exitIdx = Math.min(order.expiryIdx, visible.length - 1)

    /* — bougies AVANT le trade : fenêtre de contexte sur [0..entryIdx] — */
    const beforeWin = 10
    const candlesBefore = visible.slice(Math.max(0, entryIdx + 1 - beforeWin), entryIdx + 1).map(toLogCandle)

    /* — bougies PENDANT le trade : après l'entrée → règlement — */
    const candlesDuring = visible.slice(entryIdx + 1, exitIdx + 1).map(toLogCandle)

    return {
      type: 'trade',
      loggedAt: new Date().toISOString(),
      trade: {
        id: order.id,
        side: order.side,
        amount: order.amount,
        payout: order.payout,
        entry: { idx: order.entryIdx, time: order.entryTime, price: order.entryPrice },
        exit: order.exitTime != null && order.exitPrice != null
          ? { idx: exitIdx, time: order.exitTime, price: order.exitPrice }
          : null,
        expiryCandles: order.expiryCandles,
        status: order.status as 'won' | 'lost' | 'refunded',
        profit: order.profit ?? 0,
      },
      source: {
        kind: 'manual',
        label: 'Ordre manuel (replay)',
      },
      candlesBefore,
      candlesDuring,
      context: {
        asset: ctx.asset,
        candleSize: ctx.candleSize,
        balance: Math.round(stats.balance * 100) / 100,
        netProfit: Math.round(stats.netProfit * 100) / 100,
        replaySpeedMs: state.speedMs,
        mode: 'replay',
      },
    }
  }

  /** Envoie la file vers l'API (batch). Réessaie au prochain trade ou après 10 s. */
  private async flush(): Promise<void> {
    if (this.flushing || this.queue.length === 0 || !this._enabled) return
    this.flushing = true
    const batch = this.queue.splice(0, this.queue.length)
      .filter((e) => JSON.stringify(e).length <= MAX_LINE_CHARS)
    try {
      const res = await this.fetchImpl(this.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(batch),
      })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      this._loggedCount += batch.length
      this._lastError = null
    } catch (e) {
      this._lastError = e instanceof Error ? e.message : String(e)
      // Remet le batch en tête de file (jusqu'à MAX_QUEUE) pour retry.
      this.queue.unshift(...batch)
      if (this.queue.length > MAX_QUEUE) this.queue.length = MAX_QUEUE
      if (this.retryTimer === null) {
        this.retryTimer = setTimeout(() => {
          this.retryTimer = null
          void this.flush()
        }, 10_000)
      }
    } finally {
      this.flushing = false
      this.emit()
    }
  }
}
