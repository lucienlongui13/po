/**
 * drawings.ts — TradingView-style drawing engine (data + interaction model)
 * ========================================================================
 *
 * Shapes are anchored in chart space: { logical, price } per point.
 * Logical indexes stay stable under appends (prefix growth), so drawings
 * remain glued to their candles during live streaming AND replay.
 *
 * The canvas rendering lives in drawing-layer.tsx; this module owns:
 *  - tool metadata (required anchor count, kind)
 *  - per-(market:timeframe) shape storage with localStorage persistence
 *  - draft lifecycle (multi-click tools), selection, translate, delete
 *  - dataset-change renormalization (history reloads with a different
 *    first candle → exact time-based shift)
 */

import type { CandleLike } from './indicators'

export type DrawingTool =
  | 'cursor' | 'trend-line' | 'info-line' | 'trend-angle' | 'ray' | 'extended-line' | 'horizontal-line' | 'horizontal-ray' | 'vertical-line' | 'cross-line'
  | 'arrow' | 'arrow-mark' | 'parallel-channel' | 'regression-trend' | 'flat-top-bottom' | 'disjoint-channel' | 'rectangle' | 'rotated-rectangle' | 'path' | 'curve' | 'double-curve' | 'triangle' | 'ellipse' | 'circle' | 'arc' | 'sector' | 'polyline' | 'brush' | 'highlighter'
  | 'fib-retracement' | 'fib-extension' | 'fib-channel' | 'fib-spiral' | 'fib-time-zone' | 'fib-speed-resistance-arc' | 'fib-speed-resistance-fan' | 'fib-circles' | 'fib-wedge' | 'trend-fib-extension' | 'trend-fib-time'
  | 'gann-box' | 'gann-fan' | 'gann-square' | 'pitchfork' | 'schiff-pitchfork' | 'modified-schiff-pitchfork' | 'inside-pitchfork' | 'pitchfan'
  | 'abcd' | 'time-cycles' | 'sine-line' | 'three-drives' | 'head-shoulders' | 'xabcd' | 'triangle-pattern' | 'elliott-wave' | 'cyclic-lines'
  | 'forecast' | 'projection' | 'date-range' | 'price-range' | 'bar-pattern' | 'long-position' | 'short-position' | 'anchored-vwap' | 'fixed-range-volume-profile' | 'anchored-volume-profile'
  | 'flag-mark' | 'price-note' | 'pin' | 'signpost' | 'callout' | 'comment' | 'text' | 'note' | 'table' | 'emoji' | 'image' | 'x-posts-ideas' | 'price-label' | 'ghost-feed' | 'measure'

export interface DrawingPoint {
  logical: number
  price: number
}

export interface DrawingShape {
  id: string
  tool: DrawingTool
  points: DrawingPoint[]
  text?: string
  color: string
  /** User-configurable stroke width in CSS pixels. */
  strokeWidth?: number
  locked?: boolean
  /** Fibonacci display/forecast customisation persisted with the drawing. */
  fibLevels?: number[]
  fibFlipped?: boolean
  forecastLookback?: number
  createdAt: number
}

export interface ToolMeta {
  label: string
  /** Number of anchor points (Infinity for freehand). */
  points: number
  /** Price-independent tools anchor on logical only (vertical line). */
  logicalOnly?: boolean
  /** Price-only tools anchor on price only (horizontal lines). */
  priceOnly?: boolean
}

export const TOOL_META: Record<DrawingTool, ToolMeta> = {
  cursor:{label:'Cursor',points:0},'trend-line':{label:'Trend Line',points:2},'info-line':{label:'Info Line',points:2},'trend-angle':{label:'Trend Angle',points:2},ray:{label:'Ray',points:2},'extended-line':{label:'Extended Line',points:2},'horizontal-line':{label:'Horizontal Line',points:2},'horizontal-ray':{label:'Horizontal Ray',points:1,priceOnly:true},'vertical-line':{label:'Vertical Line',points:2},'cross-line':{label:'Cross Line',points:1},arrow:{label:'Arrow',points:2},'arrow-mark':{label:'Arrow Mark',points:2},'parallel-channel':{label:'Parallel Channel',points:3},'flat-top-bottom':{label:'Flat Top/Bottom',points:3},'disjoint-channel':{label:'Disjoint Channel',points:4},'regression-trend':{label:'Regression Trend',points:2},rectangle:{label:'Rectangle',points:2},'rotated-rectangle':{label:'Rotated Rectangle',points:2},path:{label:'Path',points:Infinity},curve:{label:'Curve',points:Infinity},'double-curve':{label:'Double Curve',points:Infinity},triangle:{label:'Triangle',points:3},ellipse:{label:'Ellipse',points:2},circle:{label:'Circle',points:2},arc:{label:'Arc',points:3},sector:{label:'Sector',points:3},polyline:{label:'Polyline',points:Infinity},brush:{label:'Brush',points:Infinity},highlighter:{label:'Highlighter',points:Infinity},'fib-retracement':{label:'AI Smart Trader · Fibonacci',points:2},'fib-extension':{label:'Fib Extension',points:3},'fib-channel':{label:'Fib Channel',points:3},'fib-spiral':{label:'Fib Spiral',points:2},'fib-time-zone':{label:'Fib Time Zone',points:2,logicalOnly:true},'fib-speed-resistance-arc':{label:'Fib Speed Resistance Arc',points:2},'fib-speed-resistance-fan':{label:'Fib Speed Resistance Fan',points:2},'fib-circles':{label:'Fib Circles',points:2},'fib-wedge':{label:'Fib Wedge',points:3},'trend-fib-extension':{label:'Trend-based Fib Extension',points:3},'trend-fib-time':{label:'Trend-based Fib Time',points:3},'gann-box':{label:'Gann Box',points:2},'gann-fan':{label:'Gann Fan',points:2},'gann-square':{label:'Gann Square',points:2},pitchfork:{label:'Pitchfork',points:3},'schiff-pitchfork':{label:'Schiff Pitchfork',points:3},'modified-schiff-pitchfork':{label:'Modified Schiff Pitchfork',points:3},'inside-pitchfork':{label:'Inside Pitchfork',points:3},pitchfan:{label:'Pitchfan',points:3},abcd:{label:'ABCD Pattern',points:4},'three-drives':{label:'Three Drives',points:6},'head-shoulders':{label:'Head & Shoulders',points:5},xabcd:{label:'XABCD Pattern',points:5},'triangle-pattern':{label:'Triangle Pattern',points:3},'elliott-wave':{label:'Elliott Wave',points:6},'cyclic-lines':{label:'Cyclic Lines',points:2,logicalOnly:true},'time-cycles':{label:'Time Cycles',points:2,logicalOnly:true},'sine-line':{label:'Sine Line',points:3},forecast:{label:'Forecast',points:2},projection:{label:'Projection',points:3},'date-range':{label:'Date Range',points:2,logicalOnly:true},'price-range':{label:'Price Range',points:2},'bar-pattern':{label:'Bar Pattern',points:2},'long-position':{label:'Long Position',points:2},'short-position':{label:'Short Position',points:2},'anchored-vwap':{label:'Anchored VWAP',points:1,priceOnly:true},'fixed-range-volume-profile':{label:'Fixed Range Volume Profile',points:2},'anchored-volume-profile':{label:'Anchored Volume Profile',points:1},'flag-mark':{label:'Flag Mark',points:1},'price-note':{label:'Price Note',points:1,priceOnly:true},'pin':{label:'Pin',points:1},'signpost':{label:'Signpost',points:1},'price-label':{label:'Price Label',points:1,priceOnly:true},'ghost-feed':{label:'Ghost Feed',points:2},callout:{label:'Callout',points:1},comment:{label:'Comment',points:1},text:{label:'Text',points:1},note:{label:'Note',points:1},table:{label:'Table',points:2},emoji:{label:'Emoji',points:1},image:{label:'Image',points:1},'x-posts-ideas':{label:'X Posts & Ideas',points:1},measure:{label:'Measure',points:2},
}


export const FIB_LEVELS = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1] as const
export const FIB_EXT_LEVELS = [0, 0.382, 0.5, 0.618, 1, 1.618, 2.618] as const
export const FIB_COLORS = ['#787B86', '#F23645', '#FF9800', '#4CAF50', '#009688', '#00BCD4', '#787B86']
export const DEFAULT_DRAWING_COLOR = '#2962FF'
export const DEFAULT_DRAWING_WIDTH = 4
export const MIN_DRAWING_WIDTH = 1
export const MAX_DRAWING_WIDTH = 16

const STORAGE_KEY = 'pc-trade-drawings-v1'
const uid = () => Math.random().toString(36).slice(2, 10)

type ChangeListener = () => void

export class DrawingManager {
  private store: Record<string, DrawingShape[]> = {}
  private key = ''
  private firstTimeByLoad: number | null = null

  activeTool: DrawingTool = 'cursor'
  magnet = false
  lockAll = false
  hideAll = false
  autoPatterns = false
  selectedId: string | null = null
  private toolStyles: Partial<Record<DrawingTool, { color: string; width: number }>> = {}

  /** In-progress shape being placed (multi-click tools). */
  draft: DrawingShape | null = null

  private listeners = new Set<ChangeListener>()

  constructor() {
    this.load()
  }

  // ──────────────────────────────────────────────── persistence

  private load(): void {
    if (typeof localStorage === 'undefined') return
    try {
      const raw = localStorage.getItem(STORAGE_KEY)
      if (raw) this.store = JSON.parse(raw)
    } catch { this.store = {} }
  }

  private persist(): void {
    if (typeof localStorage === 'undefined') return
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.store))
    } catch { /* quota — ignore */ }
  }

  subscribe(listener: ChangeListener): () => void {
    this.listeners.add(listener)
    return () => { this.listeners.delete(listener) }
  }

  private emit(): void {
    for (const l of this.listeners) {
      try { l() } catch { /* noop */ }
    }
  }

  // ──────────────────────────────────────────────── key / dataset

  setKey(key: string, candles: CandleLike[]): void {
    if (key === this.key) {
      this.renormalize(candles)
      return
    }
    this.key = key
    this.draft = null
    this.selectedId = null
    this.firstTimeByLoad = candles[0]?.time ?? null
    this.emit()
  }

  get shapes(): DrawingShape[] {
    return this.store[this.key] ?? []
  }

  /**
   * Dataset changed under the same key (history reload). If the first
   * candle time changed, shift logicals so drawings stay on their candles.
   */
  renormalize(candles: CandleLike[]): void {
    if (candles.length === 0) return
    const newFirst = candles[0].time
    const prevFirst = this.firstTimeByLoad
    this.firstTimeByLoad = newFirst
    if (prevFirst == null || prevFirst === newFirst) return

    // IMPORTANT: the continuity firewall can legitimately remove the old
    // first candle (or a whole prefix). The previous exact-match algorithm
    // then returned early, leaving drawing logical indexes attached to the
    // old dataset. After a reload this made the Fibonacci forecast appear to
    // run from right -> left. Use the actual timeframe spacing to translate
    // logical indexes even when prevFirst is no longer present.
    let interval = 0
    const samples = Math.min(candles.length - 1, 20)
    for (let i = 1; i <= samples; i++) {
      const d = candles[i].time - candles[i - 1].time
      if (Number.isFinite(d) && d > 0) interval += d
    }
    interval = samples > 0 ? interval / samples : 0
    if (!(interval > 0)) return

    // Positive delta means the new dataset starts later: its logical index 0
    // corresponds to an old index delta, so every stored logical must move
    // left by delta. Negative delta means history was prepended and the
    // anchors move right by the corresponding amount.
    const deltaLogical = Math.round((newFirst - prevFirst) / interval)
    if (!Number.isFinite(deltaLogical) || deltaLogical === 0) return

    const list = this.store[this.key]
    if (!list) return
    for (const s of list) {
      for (const point of s.points) point.logical -= deltaLogical
    }
    this.persist()
    this.emit()
  }

  // ──────────────────────────────────────────────── tool selection

  get activeStyle(): { color: string; width: number } {
    const selected = this.selectedId ? this.byId(this.selectedId) : null
    if (selected) return { color: selected.color, width: selected.strokeWidth ?? DEFAULT_DRAWING_WIDTH }
    const style = this.toolStyles[this.activeTool]
    return { color: style?.color ?? DEFAULT_DRAWING_COLOR, width: style?.width ?? DEFAULT_DRAWING_WIDTH }
  }

  setStyleForActiveTool(color: string, width: number): void {
    this.toolStyles[this.activeTool] = {
      color: color || DEFAULT_DRAWING_COLOR,
      width: Math.max(MIN_DRAWING_WIDTH, Math.min(MAX_DRAWING_WIDTH, Number(width) || DEFAULT_DRAWING_WIDTH)),
    }
    this.emit()
  }

  updateSelectedStyle(patch: { color?: string; width?: number }): void {
    if (this.selectedId) {
      const shape = this.byId(this.selectedId)
      if (shape && !shape.locked && !this.lockAll) {
        if (patch.color) shape.color = patch.color
        if (patch.width != null) shape.strokeWidth = Math.max(MIN_DRAWING_WIDTH, Math.min(MAX_DRAWING_WIDTH, Number(patch.width) || DEFAULT_DRAWING_WIDTH))
        this.persist()
        this.emit()
        return
      }
    }
    this.setStyleForActiveTool(
      patch.color ?? this.activeStyle.color,
      patch.width ?? this.activeStyle.width,
    )
  }

  setTool(tool: DrawingTool): void {
    this.activeTool = tool
    this.draft = null
    if (tool === 'cursor') this.selectedId = null
    this.emit()
  }

  toggleMagnet(): void { this.magnet = !this.magnet; this.emit() }
  toggleLockAll(): void { this.lockAll = !this.lockAll; this.emit() }
  toggleHideAll(): void { this.hideAll = !this.hideAll; this.emit() }
  toggleAutoPatterns(): void { this.autoPatterns = !this.autoPatterns; this.emit() }

  // ──────────────────────────────────────────────── draft lifecycle

  /** Returns true when the tool finished collecting points. */
  addDraftPoint(pt: DrawingPoint, candles: CandleLike[]): boolean {
    const meta = TOOL_META[this.activeTool]
    if (!meta || meta.points === 0) return false

    if (this.activeTool === 'brush') {
      if (!this.draft) {
        const style = this.activeStyle
        this.draft = {
          id: uid(), tool: 'brush',
          points: [pt], color: style.color, strokeWidth: style.width, createdAt: Date.now(),
        }
      } else {
        const last = this.draft.points[this.draft.points.length - 1]
        // thin the path slightly
        if (Math.abs(pt.logical - last.logical) > 0.35 || Math.abs(pt.price - last.price) > 0) {
          this.draft.points.push(pt)
        }
      }
      this.emit()
      return false
    }

    if (!this.draft) {
      const style = this.activeStyle
      this.draft = {
        id: uid(), tool: this.activeTool,
        points: [pt], color: style.color, strokeWidth: style.width, createdAt: Date.now(),
        ...(this.activeTool === 'fib-retracement' ? { fibLevels: [...FIB_LEVELS], fibFlipped: false, forecastLookback: 30 } : {}),
      }
      // one-point tools finish immediately
      if (meta.points === 1) return true
      this.emit()
      return false
    }

    if (this.activeTool === 'horizontal-line') {
      const first = this.draft.points[0]
      this.draft.points.push({ logical: pt.logical, price: first.price })
    } else if (this.activeTool === 'vertical-line') {
      const first = this.draft.points[0]
      this.draft.points.push({ logical: first.logical, price: pt.price })
    } else {
      this.draft.points.push(pt)
    }
    if (this.draft.points.length >= meta.points) return true
    this.emit()
    return false
  }

  finishDraft(candles: CandleLike[]): void {
    if (!this.draft) return
    const shape = this.draft
    this.draft = null
    const list = this.store[this.key] ?? []
    list.push(shape)
    this.store[this.key] = list
    this.persist()
    this.selectedId = shape.id
    this.emit()
  }

  cancelDraft(): void {
    if (!this.draft) return
    this.draft = null
    this.emit()
  }

  // ──────────────────────────────────────────────── editing

  select(id: string | null): void {
    this.selectedId = id
    this.emit()
  }

  deleteShape(id: string): void {
    const list = this.store[this.key]
    if (!list) return
    this.store[this.key] = list.filter((s) => s.id !== id)
    if (this.selectedId === id) this.selectedId = null
    this.persist()
    this.emit()
  }

  deleteSelected(): void {
    if (this.selectedId) this.deleteShape(this.selectedId)
  }

  deleteAll(): void {
    this.store[this.key] = []
    this.selectedId = null
    this.persist()
    this.emit()
  }

  /** Hit-test against pixel-space anchors provided by the layer. */
  hitTest(px: number, py: number, anchors: Array<{ id: string; pts: Array<{ x: number; y: number }> }>): string | null {
    const threshold = 14
    for (const a of anchors) {
      // point handles first (priority)
      for (const p of a.pts) {
        if (Math.hypot(p.x - px, p.y - py) <= threshold + 4) return a.id
      }
    }
    // segment proximity
    for (const a of anchors) {
      if (a.pts.length >= 2) {
        for (let i = 0; i < a.pts.length - 1; i++) {
          if (distToSegment(px, py, a.pts[i], a.pts[i + 1]) <= threshold) return a.id
        }
      } else if (a.pts.length === 1) {
        if (Math.hypot(a.pts[0].x - px, a.pts[0].y - py) <= threshold) return a.id
      }
    }
    return null
  }

  /** Which point-handle of the selected shape is under the cursor (pixel space). */
  hitPointHandle(px: number, py: number, pts: Array<{ x: number; y: number }>): number {
    for (let i = 0; i < pts.length; i++) {
      if (Math.hypot(pts[i].x - px, pts[i].y - py) <= 32) return i
    }
    return -1
  }

  movePoint(id: string, idx: number, pt: DrawingPoint): void {
    const s = this.byId(id)
    if (!s || s.locked || this.lockAll) return
    const meta = TOOL_META[s.tool]
    if (s.tool === 'horizontal-line' && s.points.length >= 2) {
      s.points[idx] = { logical: pt.logical, price: pt.price }
      const other = idx === 0 ? 1 : 0
      s.points[other].price = pt.price
    } else if (s.tool === 'vertical-line' && s.points.length >= 2) {
      s.points[idx] = { logical: pt.logical, price: pt.price }
      const other = idx === 0 ? 1 : 0
      s.points[other].logical = pt.logical
    } else if (meta.priceOnly) s.points[idx] = { logical: 0, price: pt.price }
    else if (meta.logicalOnly) s.points[idx] = { logical: pt.logical, price: 0 }
    else s.points[idx] = pt
    this.persist()
    this.emit()
  }

  translate(id: string, dLogical: number, dPrice: number): void {
    const s = this.byId(id)
    if (!s || s.locked || this.lockAll) return
    const meta = TOOL_META[s.tool]
    for (const p of s.points) {
      if (!meta.priceOnly) p.logical += dLogical
      if (!meta.logicalOnly) p.price += dPrice
    }
    this.persist()
    this.emit()
  }

  updateSelectedFibSettings(patch: { fibLevels?: number[]; fibFlipped?: boolean; forecastLookback?: number }): void {
    if (!this.selectedId) return
    const s = this.byId(this.selectedId)
    if (!s || s.tool !== 'fib-retracement' || s.locked || this.lockAll) return
    if (patch.fibLevels) s.fibLevels = [...patch.fibLevels]
    if (patch.fibFlipped !== undefined) s.fibFlipped = patch.fibFlipped
    if (patch.forecastLookback !== undefined) {
      const value = Number(patch.forecastLookback)
      if (Number.isFinite(value)) s.forecastLookback = Math.max(1, Math.round(value))
    }
    this.persist()
    this.emit()
  }

  updateText(id: string, text: string): void {
    const s = this.byId(id)
    if (!s) return
    s.text = text
    this.persist()
    this.emit()
  }

  byId(id: string): DrawingShape | null {
    return this.shapes.find((s) => s.id === id) ?? null
  }

  get count(): number { return this.shapes.length }
}

function distToSegment(px: number, py: number, a: { x: number; y: number }, b: { x: number; y: number }): number {
  const dx = b.x - a.x
  const dy = b.y - a.y
  const lenSq = dx * dx + dy * dy
  if (lenSq === 0) return Math.hypot(px - a.x, py - a.y)
  let t = ((px - a.x) * dx + (py - a.y) * dy) / lenSq
  t = Math.max(0, Math.min(1, t))
  return Math.hypot(px - (a.x + t * dx), py - (a.y + t * dy))
}
