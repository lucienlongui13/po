/**
 * replay-engine.ts — Bar Replay + Strategy Backtesting
 * ====================================================
 *
 * TradingView "Bar Replay" equivalent driven by real Pocket Option history:
 *
 *   full history ──▶ cursor (last visible candle)
 *                     │
 *     play/pause/step/seek/speed
 *                     │
 *                     ├── onAdvance → chart (incremental series.update)
 *                     │               indicators recompute on the prefix
 *                     └── onState   → React panels (stats, controls)
 *
 * Simulated binary orders settle against replayed candles:
 *   CALL wins if close(expiry) > close(entry), PUT if lower, tie → refund.
 */

import type { CandleLike } from './indicators'

export interface SimOrder {
  id: string
  side: 'call' | 'put'
  amount: number
  payout: number            // percent
  entryIdx: number
  entryPrice: number
  expiryCandles: number
  expiryIdx: number
  status: 'open' | 'won' | 'lost' | 'refunded'
  exitPrice?: number
  profit?: number
  entryTime: number
  exitTime?: number
  /**
   * v22 — LIBELLÉ D'ORDRE : stratégie + combinaison qui a placé l'ordre +
   * règle de validation (ex. « L_Lucien ProTrader · CALL ▲ · call-1
   * [BOS Up] · validation RGRR »). Les ordres manuels portent
   * « Manuel · Order panel » — CHAQUE ordre a son libellé.
   */
  label?: string
}

export interface EquityPoint {
  time: number
  value: number
}

export interface ReplayState {
  active: boolean
  playing: boolean
  cursor: number
  total: number
  startIdx: number
  speedMs: number
  currentPrice: number
  currentTime: number
}

export interface BacktestStats {
  startBalance: number
  balance: number
  /** Solde disponible pour de nouvelles mises (balance − mises en cours). */
  availableBalance: number
  netProfit: number
  totalTrades: number
  openTrades: number
  wins: number
  losses: number
  refunds: number
  winRate: number            // % over decided trades
  grossProfit: number
  grossLoss: number
  profitFactor: number
  volumeStaked: number
  maxDrawdown: number
  equityCurve: EquityPoint[]
}

export interface AdvanceInfo {
  /** The candle appended by this advance (null on seek/step-back). */
  appended: CandleLike | null
  /** True when the dataset was replaced (seek) → full setData required. */
  seeked: boolean
}

export type AdvanceListener = (candles: CandleLike[], info: AdvanceInfo) => void
export type StateListener = (state: ReplayState, stats: BacktestStats, orders: SimOrder[]) => void
export type OrdersResetListener = () => void

const uid = () => Math.random().toString(36).slice(2, 10)

export class ReplayEngine {
  private full: CandleLike[] = []
  private cursor = 0
  private startIdx = 0
  private _active = false
  private _playing = false
  private speedMs = 1000
  private timer: ReturnType<typeof setInterval> | null = null

  private startBalance = 1000
  private orders: SimOrder[] = []
  private equity: EquityPoint[] = []
  private peakEquity = 1000
  private maxDrawdown = 0

  private advanceListeners = new Set<AdvanceListener>()
  private stateListeners = new Set<StateListener>()
  private ordersResetListeners = new Set<OrdersResetListener>()
  private disposed = false

  // ────────────────────────────────────────────────────────────── lifecycle

  start(full: CandleLike[], barsBack: number, startBalance = 1000): void {
    this.stopTimer()
    this.full = full.slice()
    if (this.full.length < 2) return
    // barsBack may legitimately cover the ENTIRE dataset ("replay from the
    // beginning of the fetched history"): keep a single warm-up bar so the
    // very first candle is always replayable (startIdx can reach 0).
    const back = Math.max(0, Math.min(barsBack, this.full.length - 1))
    this.startIdx = this.full.length - 1 - back
    this.cursor = this.startIdx
    this._active = true
    this._playing = false
    this.startBalance = startBalance
    this.orders = []
    this.peakEquity = startBalance
    this.maxDrawdown = 0
    this.equity = [{ time: this.full[this.cursor].time, value: startBalance }]
    this.emitAdvance({ appended: null, seeked: true })
    this.emitState()
  }

  stop(): void {
    this.stopTimer()
    this._active = false
    this._playing = false
    this.full = []
    this.orders = []
    this.equity = []
    this.emitState()
  }

  get active(): boolean { return this._active }
  get playing(): boolean { return this._playing }

  // ────────────────────────────────────────────────────────────── transport

  play(): void {
    if (!this._active || this._playing) return
    if (this.cursor >= this.full.length - 1) return // at live edge
    this._playing = true
    this.startTimer()
    this.emitState()
  }

  pause(): void {
    if (!this._playing) return
    this._playing = false
    this.stopTimer()
    this.emitState()
  }

  toggle(): void {
    if (this._playing) this.pause()
    else this.play()
  }

  stepForward(): void {
    if (!this._active || this.cursor >= this.full.length - 1) return
    this.pause()
    this.advance()
  }

  stepBack(): void {
    if (!this._active || this.cursor <= this.startIdx) return
    this.pause()
    this.cursor -= 1
    // open orders beyond the cursor become pending again
    this.emitAdvance({ appended: null, seeked: true })
    this.emitState()
  }

  /** Jump the cursor to an absolute index (scrub). */
  seek(idx: number): void {
    if (!this._active) return
    this.pause()
    const clamped = Math.max(this.startIdx, Math.min(idx, this.full.length - 1))
    if (clamped === this.cursor) return
    this.cursor = clamped
    this.emitAdvance({ appended: null, seeked: true })
    this.emitState()
  }

  setSpeed(ms: number): void {
    this.speedMs = Math.max(30, ms)
    if (this._playing) { this.stopTimer(); this.startTimer() }
    this.emitState()
  }

  // ────────────────────────────────────────────────────────────── simulated orders

  placeSim(side: 'call' | 'put', amount: number, expiryCandles: number, payout: number, label?: string): SimOrder | null {
    if (!this._active || amount <= 0 || expiryCandles < 1) return null
    // Garde de ruine : impossible de miser plus que le solde disponible
    // (startBalance + P&L réglé − mises en cours). Retourne null → le UI
    // stoppe le backtest / notifie l'utilisateur.
    if (amount > this.availableBalance) return null
    const c = this.full[this.cursor]
    if (!c) return null
    const order: SimOrder = {
      id: uid(),
      side,
      amount,
      payout: Math.max(0, Math.min(100, payout)),
      entryIdx: this.cursor,
      entryPrice: c.close,
      expiryCandles,
      expiryIdx: this.cursor + expiryCandles,
      status: 'open',
      entryTime: c.time,
      // v22 — libellé de l'ordre (combinaison + validation pour la
      // stratégie auto, « Manuel · Order panel » sinon).
      label,
    }
    this.orders.unshift(order)
    this.emitState()
    return order
  }

  get openOrders(): SimOrder[] { return this.orders.filter((o) => o.status === 'open') }
  get allOrders(): SimOrder[] { return this.orders.slice() }

  /**
   * Remise à zéro de l'historique des trades simulés (orders + equity +
   * drawdown). Le replay continue là où il est ; le solde de départ est
   * conservé. Notifie les consommateurs (panneau stratégie : les émissions
   * référencent des ordres supprimés → reset).
   */
  resetOrders(): void {
    this.orders = []
    this.peakEquity = this.startBalance
    this.maxDrawdown = 0
    this.equity = [{ time: this.full[this.cursor]?.time ?? 0, value: this.startBalance }]
    this.emitState()
    for (const l of this.ordersResetListeners) {
      try { l() } catch (e) { console.error('[ReplayEngine] ordersReset listener', e) }
    }
  }

  /**
   * Nouveau solde de départ pour le backtest. Réinitialise l'historique des
   * trades (cohérence stats/equity) — toast côté UI pour avertir l'utilisateur.
   */
  setStartBalance(balance: number): void {
    this.startBalance = Math.max(0.01, Number.isFinite(balance) ? balance : 1000)
    this.resetOrders()
  }

  /** Solde courant (startBalance + P&L réglé) — mises en cours non déduites. */
  get currentBalance(): number { return this.getStats().balance }

  /** Solde disponible pour une nouvelle mise (mises en cours déduites). */
  get availableBalance(): number {
    const settled = this.orders
      .filter((o) => o.status === 'won')
      .reduce((s, o) => s + (o.amount * o.payout) / 100, 0)
      - this.orders.filter((o) => o.status === 'lost').reduce((s, o) => s + o.amount, 0)
    const openStake = this.orders.filter((o) => o.status === 'open').reduce((s, o) => s + o.amount, 0)
    return this.startBalance + settled - openStake
  }

  private settleOrders(prevCursor: number): void {
    let changed = false
    for (const o of this.orders) {
      if (o.status !== 'open') continue
      if (this.cursor >= o.expiryIdx) {
        const exit = this.full[Math.min(o.expiryIdx, this.full.length - 1)]
        const exitPrice = exit.close
        const exitTime = exit.time
        if (exitPrice === o.entryPrice) {
          o.status = 'refunded'
          o.profit = 0
        } else {
          const won = o.side === 'call' ? exitPrice > o.entryPrice : exitPrice < o.entryPrice
          o.status = won ? 'won' : 'lost'
          o.profit = won ? (o.amount * o.payout) / 100 : -o.amount
        }
        o.exitPrice = exitPrice
        o.exitTime = exitTime
        changed = true
      }
    }
    if (!changed) return
    // rebuild equity from scratch (cheap, orders ≤ few hundred)
    this.rebuildEquity()
  }

  private rebuildEquity(): void {
    const settled = this.orders
      .filter((o) => o.status !== 'open')
      .slice()
      .sort((a, b) => (a.exitTime ?? 0) - (b.exitTime ?? 0))
    let bal = this.startBalance
    this.equity = [{ time: this.full[this.startIdx]?.time ?? 0, value: bal }]
    this.peakEquity = bal
    this.maxDrawdown = 0
    for (const o of settled) {
      bal += o.profit ?? 0
      this.equity.push({ time: o.exitTime ?? 0, value: bal })
      this.peakEquity = Math.max(this.peakEquity, bal)
      this.maxDrawdown = Math.max(this.maxDrawdown, this.peakEquity - bal)
    }
  }

  // ────────────────────────────────────────────────────────────── state

  getState(): ReplayState {
    const c = this.full[this.cursor]
    return {
      active: this._active,
      playing: this._playing,
      cursor: this.cursor,
      total: this.full.length,
      startIdx: this.startIdx,
      speedMs: this.speedMs,
      currentPrice: c?.close ?? 0,
      currentTime: c?.time ?? 0,
    }
  }

  getStats(): BacktestStats {
    const decided = this.orders.filter((o) => o.status === 'won' || o.status === 'lost')
    const wins = this.orders.filter((o) => o.status === 'won')
    const losses = this.orders.filter((o) => o.status === 'lost')
    const refunds = this.orders.filter((o) => o.status === 'refunded')
    const open = this.orders.filter((o) => o.status === 'open')
    const grossProfit = wins.reduce((s, o) => s + (o.amount * o.payout) / 100, 0)
    const grossLoss = losses.reduce((s, o) => s + o.amount, 0)
    const netProfit = grossProfit - grossLoss
    const balance = this.startBalance + netProfit
    const openStake = open.reduce((s, o) => s + o.amount, 0)
    return {
      startBalance: this.startBalance,
      balance,
      availableBalance: balance - openStake,
      netProfit,
      totalTrades: this.orders.length,
      openTrades: open.length,
      wins: wins.length,
      losses: losses.length,
      refunds: refunds.length,
      winRate: decided.length > 0 ? (wins.length / decided.length) * 100 : 0,
      grossProfit,
      grossLoss,
      profitFactor: grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? Infinity : 0,
      volumeStaked: this.orders.reduce((s, o) => s + o.amount, 0),
      maxDrawdown: this.maxDrawdown,
      equityCurve: this.equity.slice(),
    }
  }

  /** The visible dataset (prefix of full). */
  getVisible(): CandleLike[] { return this.full.slice(0, this.cursor + 1) }

  // ────────────────────────────────────────────────────────────── listeners

  onAdvance(listener: AdvanceListener): () => void {
    this.advanceListeners.add(listener)
    return () => { this.advanceListeners.delete(listener) }
  }

  onState(listener: StateListener): () => void {
    this.stateListeners.add(listener)
    return () => { this.stateListeners.delete(listener) }
  }

  /** Notifié à chaque resetOrders / setStartBalance (ordres supprimés). */
  onOrdersReset(listener: OrdersResetListener): () => void {
    this.ordersResetListeners.add(listener)
    return () => { this.ordersResetListeners.delete(listener) }
  }

  dispose(): void {
    this.disposed = true
    this.stopTimer()
    this.advanceListeners.clear()
    this.stateListeners.clear()
  }

  // ────────────────────────────────────────────────────────────── internals

  private startTimer(): void {
    this.stopTimer()
    this.timer = setInterval(() => {
      if (this.disposed || !this._active) { this.stopTimer(); return }
      if (this.cursor >= this.full.length - 1) { this.pause(); return }
      this.advance()
    }, this.speedMs)
  }

  private stopTimer(): void {
    if (this.timer !== null) { clearInterval(this.timer); this.timer = null }
  }

  private advance(): void {
    const prev = this.cursor
    this.cursor = Math.min(this.cursor + 1, this.full.length - 1)
    this.settleOrders(prev)
    this.emitAdvance({ appended: this.full[this.cursor], seeked: false })
    this.emitState()
    if (this.cursor >= this.full.length - 1) this.pause()
  }

  private emitAdvance(info: AdvanceInfo): void {
    const slice = this.getVisible()
    for (const l of this.advanceListeners) {
      try { l(slice, info) } catch (e) { console.error('[ReplayEngine] advance listener', e) }
    }
  }

  private emitState(): void {
    const state = this.getState()
    const stats = this.getStats()
    const orders = this.orders.slice(0, 100)
    for (const l of this.stateListeners) {
      try { l(state, stats, orders) } catch (e) { console.error('[ReplayEngine] state listener', e) }
    }
  }
}

/** Speed presets (ms per candle) — TradingView-like replay speeds. */
export const REPLAY_SPEEDS: Array<{ label: string; ms: number }> = [
  { label: '0.5x', ms: 2000 },
  { label: '1x', ms: 1000 },
  { label: '2x', ms: 500 },
  { label: '4x', ms: 250 },
  { label: '10x', ms: 100 },
  { label: '20x', ms: 50 },
  { label: '40x', ms: 25 },
  { label: '80x', ms: 12 },
]
