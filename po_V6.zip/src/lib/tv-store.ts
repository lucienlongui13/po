'use client'

/**
 * tv-store.ts — shared workspace state (TradingView replica)
 *
 * Zustand store shared by the top bar, chart workspace, drawing toolbar
 * and side panels: chart style, indicator instances, replay flag, price
 * alerts, panel collapse states, notes. Persisted subsets rehydrate from
 * localStorage after mount (SSR-safe defaults).
 */

import { create } from 'zustand'
import { INDICATOR_MAP, defaultParams } from './indicators-library'

export type ChartStyle =
  | 'candles' | 'hollow' | 'bars' | 'line' | 'area' | 'baseline' | 'heikin-ashi'

export interface IndicatorPlotSettings {
  visible: boolean
  color: string
}

export interface IndicatorInstance {
  uid: string
  defId: string
  params: Record<string, number>
  visible: boolean
  plotSettings: Record<string, IndicatorPlotSettings>
  cloudVisible?: boolean
}

export interface PriceAlert {
  id: string
  symbol: string
  price: number
  direction: 'above' | 'below'
  createdAt: number
  triggered: boolean
}

export type BottomTab = 'history' | 'notes' | 'backtest'

const uid = () => Math.random().toString(36).slice(2, 10)

const PERSIST_KEY = 'pc-trade-workspace-v1'

function makeIndicator(defId: string): IndicatorInstance | null {
  const def = INDICATOR_MAP.get(defId)
  if (!def) return null
  const plotSettings: Record<string, IndicatorPlotSettings> = {}
  for (const plot of def.plots) plotSettings[plot.key] = { visible: true, color: plot.color }
  return { uid: uid(), defId, params: defaultParams(def), visible: true, plotSettings, cloudVisible: defId === 'ichimoku' ? true : undefined }
}

function defaultIndicators(): IndicatorInstance[] {
  // v20 — AUCUN indicateur actif par défaut au démarrage : l'utilisateur
  // choisit lui-même ceux qu'il active (menu Indicators). (v19 et avant :
  // Volume était activé d'office.)
  return []
}

interface TVStore {
  // ── chart ──
  chartStyle: ChartStyle
  setChartStyle: (s: ChartStyle) => void
  logScale: boolean
  toggleLogScale: () => void

  // ── indicators ──
  indicators: IndicatorInstance[]
  addIndicator: (defId: string) => void
  removeIndicator: (uid: string) => void
  updateIndicatorParams: (uid: string, params: Record<string, number>) => void
  updateIndicatorPlotSettings: (uid: string, settings: Record<string, IndicatorPlotSettings>) => void
  setIndicatorCloudVisible: (uid: string, visible: boolean) => void
  toggleIndicatorVisible: (uid: string) => void
  indicatorsMenuOpen: boolean
  setIndicatorsMenuOpen: (v: boolean) => void

  // ── symbol search ──
  symbolSearchOpen: boolean
  setSymbolSearchOpen: (v: boolean) => void

  // ── replay / backtest ──
  replayActive: boolean
  setReplayActive: (v: boolean) => void
  replayBarsBack: number
  setReplayBarsBack: (n: number) => void

  // ── alerts ──
  alerts: PriceAlert[]
  addAlert: (symbol: string, price: number, direction: 'above' | 'below') => void
  removeAlert: (id: string) => void
  markAlertTriggered: (id: string) => void

  // ── layout ──
  rightPanelOpen: boolean
  toggleRightPanel: () => void
  bottomPanelOpen: boolean
  setBottomPanelOpen: (v: boolean) => void
  bottomTab: BottomTab
  setBottomTab: (t: BottomTab) => void

  // ── notes ──
  notes: string
  setNotes: (v: string) => void

  // ── misc ──
  drawingsVersion: number
  bumpDrawings: () => void
  hydrate: () => void
}

export const useTVStore = create<TVStore>((set, get) => ({
  chartStyle: 'candles',
  setChartStyle: (s) => {
    set({ chartStyle: s })
    persist(get())
  },
  logScale: false,
  toggleLogScale: () => {
    set({ logScale: !get().logScale })
    persist(get())
  },

  indicators: defaultIndicators(),
  addIndicator: (defId) => {
    const inst = makeIndicator(defId)
    if (!inst) return
    set({ indicators: [...get().indicators, inst] })
    persist(get())
  },
  removeIndicator: (uid) => {
    set({ indicators: get().indicators.filter((i) => i.uid !== uid) })
    persist(get())
  },
  updateIndicatorParams: (uid, params) => {
    set({
      indicators: get().indicators.map((i) => (i.uid === uid ? { ...i, params } : i)),
    })
    persist(get())
  },
  updateIndicatorPlotSettings: (uid, settings) => {
    set({
      indicators: get().indicators.map((i) => (i.uid === uid ? { ...i, plotSettings: settings } : i)),
    })
    persist(get())
  },
  setIndicatorCloudVisible: (uid, visible) => {
    set({ indicators: get().indicators.map((i) => (i.uid === uid ? { ...i, cloudVisible: visible } : i)) })
    persist(get())
  },

  toggleIndicatorVisible: (uid) => {
    set({
      indicators: get().indicators.map((i) => (i.uid === uid ? { ...i, visible: !i.visible } : i)),
    })
    persist(get())
  },
  indicatorsMenuOpen: false,
  setIndicatorsMenuOpen: (v) => set({ indicatorsMenuOpen: v }),

  symbolSearchOpen: false,
  setSymbolSearchOpen: (v) => set({ symbolSearchOpen: v }),

  replayActive: false,
  setReplayActive: (v) => set({ replayActive: v }),
  replayBarsBack: 300,
  setReplayBarsBack: (n) => set({ replayBarsBack: n }),

  alerts: [],
  addAlert: (symbol, price, direction) => {
    set({
      alerts: [
        ...get().alerts,
        { id: uid(), symbol, price, direction, createdAt: Date.now(), triggered: false },
      ],
    })
  },
  removeAlert: (id) => set({ alerts: get().alerts.filter((a) => a.id !== id) }),
  markAlertTriggered: (id) => {
    set({ alerts: get().alerts.map((a) => (a.id === id ? { ...a, triggered: true } : a)) })
  },

  rightPanelOpen: true,
  toggleRightPanel: () => set({ rightPanelOpen: !get().rightPanelOpen }),
  bottomPanelOpen: false,
  setBottomPanelOpen: (v) => set({ bottomPanelOpen: v }),
  bottomTab: 'history',
  setBottomTab: (t) => set({ bottomTab: t }),

  notes: '',
  setNotes: (v) => {
    set({ notes: v })
    persist(get())
  },

  drawingsVersion: 0,
  bumpDrawings: () => set({ drawingsVersion: get().drawingsVersion + 1 }),

  hydrate: () => {
    if (typeof localStorage === 'undefined') return
    try {
      const raw = localStorage.getItem(PERSIST_KEY)
      if (!raw) return
      const saved = JSON.parse(raw) as {
        chartStyle?: ChartStyle
        indicators?: IndicatorInstance[]
        notes?: string
      }
      // v20 — Ancien défaut [Volume] : une sauvegarde qui ne contient QUE le
      // Volume n'est PAS un choix utilisateur (c'était l'activation d'office
      // d'avant v20) → on repart de la liste vide. Toute autre combinaison
      // est un choix explicite de l'utilisateur → conservée.
      const isLegacyDefaultVolume =
        Array.isArray(saved.indicators) &&
        saved.indicators.length === 1 &&
        saved.indicators[0]?.defId === 'volume'
      const restoredIndicators = isLegacyDefaultVolume
        ? []
        : (saved.indicators?.length ? saved.indicators.map((i) => ({
            ...i,
            plotSettings: i.plotSettings ?? (() => {
              const def = INDICATOR_MAP.get(i.defId)
              const out: Record<string, IndicatorPlotSettings> = {}
              for (const plot of def?.plots ?? []) out[plot.key] = { visible: true, color: plot.color }
              return out
            })(),
            cloudVisible: i.cloudVisible ?? (i.defId === 'ichimoku' ? true : undefined),
          })) : get().indicators)
      set({
        chartStyle: saved.chartStyle ?? get().chartStyle,
        indicators: restoredIndicators,
        notes: saved.notes ?? get().notes,
      })
    } catch { /* ignore corrupted state */ }
  },
}))

function persist(s: TVStore): void {
  if (typeof localStorage === 'undefined') return
  try {
    localStorage.setItem(PERSIST_KEY, JSON.stringify({
      chartStyle: s.chartStyle,
      indicators: s.indicators,
      notes: s.notes,
    }))
  } catch { /* quota */ }
}
