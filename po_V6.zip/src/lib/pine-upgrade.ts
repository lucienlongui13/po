/**
 * pine-upgrade.ts — transparent legacy Pine Script (v1–v4) → v6 source upgrader.
 *
 * WHY: the execution engine (piner) is a clean-room Pine v6 engine. Scripts
 * written for TradingView v1–v4 use pre-namespace builtins that either fail
 * to resolve (`red`, `stepline`, `integer`, `isintraday`, `interval`) or —
 * far worse — resolve to nothing and silently produce `na` at runtime
 * (`sma()`, `ema()`, `min()`, `macd()`, `change()` … every bare ta/math call).
 *
 * This module upgrades legacy sources to v6-compatible form BEFORE
 * compilation. It is a pure, deterministic, line-preserving source-to-source
 * transform — v5/v6 sources pass through untouched.
 *
 * Applied rules (all string/comment aware, see tokenize()):
 *   1. `study(`                     → `indicator(`            (call position)
 *   2. `security(`                  → `request.security(`     (call position)
 *   3. bare ta/math function calls  → `ta.*` / `math.*`       (call position)
 *   4. bare color names             → `color.*`               (value position)
 *   5. plot styles `style=stepline` → `plot.style_stepline`
 *   6. legacy timeframe globals     → `timeframe.*`            (value position)
 *   7. legacy `input(..., type=…)`  → named-arg dropped (the engine infers
 *      the input kind from the defval literal and already supports defval/
 *      minval/maxval/options on the generic input())
 *   8. `transp=` named args         → dropped; non-zero transparency is
 *      re-expressed in place as color.new(...) on the call's color argument
 *   9. `iff(a, b, c)`               → `(a ? b : c)`
 *  10. `rising(len)` / `falling(len)` single-arg v3 form → `ta.rising(close, len)`
 *
 * Known limitations (documented, non-blocking):
 *   - `interval` maps to `timeframe.multiplier`: identical on minute-based
 *     intraday charts (the v3 use case); differs on second/daily charts.
 *   - A v3 script shadowing a builtin color name with its own variable would
 *     be renamed too — impossible in valid v3 (reserved builtins).
 */

/** v3/v4 ta builtins → engine-supported v6 names. Only names verified to
 *  work under the engine are mapped (see scripts/probe6-ns-targets.ts). */
const TA_FNS = new Set([
  'sma', 'ema', 'wma', 'vwma', 'rma', 'hma', 'swma', 'alma', 'linreg',
  'sar', 'atr', 'tr', 'highest', 'lowest', 'barssince', 'valuewhen',
  'change', 'mom', 'roc', 'rsi', 'stoch', 'cci', 'cmo', 'cog',
  'correlation', 'cross', 'crossover', 'crossunder', 'falling', 'rising',
  'pivothigh', 'pivotlow', 'vwap', 'cum', 'dev', 'stdev', 'variance',
  'percentrank', 'median', 'range', 'trange', 'macd',
])

/** v3/v4 math builtins → engine-supported v6 names. */
const MATH_FNS = new Set([
  'abs', 'ceil', 'cos', 'exp', 'floor', 'log', 'log10', 'max', 'min',
  'pow', 'round', 'sign', 'sin', 'sqrt', 'sum', 'tan', 'todegrees',
  'toradians', 'random', 'avg',
])

/** The 17 basic v3 color constants → v6 color namespace. */
const COLORS = new Set([
  'aqua', 'black', 'blue', 'fuchsia', 'gray', 'green', 'lime', 'maroon',
  'navy', 'olive', 'orange', 'purple', 'red', 'silver', 'teal', 'white', 'yellow',
])

/** v3 plot style constants (value position, after `style=`). */
const PLOT_STYLES: Record<string, string> = {
  line: 'plot.style_line',
  stepline: 'plot.style_stepline',
  circles: 'plot.style_circles',
  cross: 'plot.style_cross',
  area: 'plot.style_area',
  columns: 'plot.style_columns',
  histogram: 'plot.style_histogram',
  linebr: 'plot.style_linebr',
}

/** v3 timeframe/built-in globals → v6 equivalents (runtime-verified). */
const TF_GLOBALS: Record<string, string> = {
  isintraday: 'timeframe.isintraday',
  isdwm: 'timeframe.isdwm',
  isdaily: 'timeframe.isdaily',
  isweekly: 'timeframe.isweekly',
  ismonthly: 'timeframe.ismonthly',
  interval: 'timeframe.multiplier',
}

/** Calls whose argument list gets surgical rewrites. */
const ARG_SURGERY_CALLS = new Set([
  'plot', 'plotshape', 'plotchar', 'plotarrow', 'plotcandle', 'plotbar',
  'hline', 'bgcolor', 'fill', 'barcolor', 'input', 'iff',
  'ta.rising', 'ta.falling',
])

type TokKind = 'comment' | 'string' | 'ident' | 'raw'
interface Tok { text: string; kind: TokKind }

/** Split source into comments / strings / identifiers / single-char raw
 *  tokens. All transforms only ever touch `ident` tokens, so string literals
 *  and comments (titles, option lists, doc text) are structurally immune. */
function tokenize(src: string): Tok[] {
  const toks: Tok[] = []
  const n = src.length
  let i = 0
  while (i < n) {
    const ch = src[i]
    if (ch === '/' && src[i + 1] === '/') {
      const e = src.indexOf('\n', i)
      const end = e === -1 ? n : e
      toks.push({ text: src.slice(i, end), kind: 'comment' })
      i = end
      continue
    }
    if (ch === '"' || ch === "'") {
      let j = i + 1
      while (j < n && src[j] !== ch) { if (src[j] === '\\') j++; j++ }
      toks.push({ text: src.slice(i, Math.min(j + 1, n)), kind: 'string' })
      i = j + 1
      continue
    }
    if (/[A-Za-z_]/.test(ch)) {
      let j = i
      while (j < n && /[A-Za-z0-9_]/.test(src[j])) j++
      toks.push({ text: src.slice(i, j), kind: 'ident' })
      i = j
      continue
    }
    toks.push({ text: ch, kind: 'raw' })
    i++
  }
  return toks
}

/** Detect the //@version annotation. TradingView only honours it on comment
 *  lines before any code — mirror that rule. */
export function detectPineVersion(src: string): number | null {
  for (const line of src.split('\n')) {
    const t = line.trim()
    if (t === '') continue
    if (t.startsWith('//')) {
      const m = /^\/\/\s*@version\s*=\s*(\d+)/.exec(t)
      if (m) return Number(m[1])
      continue
    }
    break
  }
  return null
}

/** Does this source need the legacy upgrade? */
export function isLegacyPine(src: string): boolean {
  const v = detectPineVersion(src)
  if (v != null) return v <= 4
  // No annotation: v1/v2 scripts — legacy only if they declare study().
  const toks = tokenize(src)
  for (let i = 0; i < toks.length; i++) {
    if (toks[i].kind === 'ident' && toks[i].text === 'study') {
      let j = i + 1
      while (j < toks.length && toks[j].text.trim() === '') j++
      if (j < toks.length && toks[j].text === '(') return true
    }
  }
  return false
}

export interface PineUpgradeResult {
  source: string
  upgraded: boolean
  version: number | null
}

/** Upgrade a legacy (v1–v4) Pine source to v6-compatible form.
 *  v5/v6 sources are returned untouched. */
export function upgradeLegacyPine(src: string): PineUpgradeResult {
  const version = detectPineVersion(src)
  if (!isLegacyPine(src)) return { source: src, upgraded: false, version }

  const toks = tokenize(src)
  const N = toks.length

  const isWsTok = (t: Tok) => t.kind === 'raw' && (t.text === ' ' || t.text === '\n' || t.text === '\t' || t.text === '\r')
  const nextSig = (i: number): number => { for (let j = i + 1; j < N; j++) if (!isWsTok(toks[j])) return j; return -1 }
  const prevSig = (i: number): number => { for (let j = i - 1; j >= 0; j--) if (!isWsTok(toks[j])) return j; return -1 }

  // --- pass 1: identifier-level rewrites ----------------------------------
  for (let i = 0; i < N; i++) {
    const t = toks[i]
    if (t.kind !== 'ident') continue
    const name = t.text
    const nIdx = nextSig(i)
    const pIdx = prevSig(i)
    if (pIdx >= 0 && toks[pIdx].text.trim().endsWith('.')) continue // member access
    const isCall = nIdx >= 0 && toks[nIdx].text === '('

    if (isCall) {
      if (name === 'study') { toks[i] = { text: 'indicator', kind: 'ident' }; continue }
      if (name === 'security') { toks[i] = { text: 'request.security', kind: 'ident' }; continue }
      if (TA_FNS.has(name)) { toks[i] = { text: 'ta.' + name, kind: 'ident' }; continue }
      if (MATH_FNS.has(name)) { toks[i] = { text: 'math.' + name, kind: 'ident' }; continue }
      continue
    }

    // value position
    if (COLORS.has(name)) { toks[i] = { text: 'color.' + name, kind: 'ident' }; continue }
    if (TF_GLOBALS[name]) { toks[i] = { text: TF_GLOBALS[name], kind: 'ident' }; continue }
    // plot styles: previous significant tokens are `=` then `style`
    if (PLOT_STYLES[name]) {
      const ppIdx = prevSig(pIdx)
      if (pIdx >= 0 && toks[pIdx].text === '=' && ppIdx >= 0 && toks[ppIdx].kind === 'ident' && toks[ppIdx].text === 'style') {
        toks[i] = { text: PLOT_STYLES[name], kind: 'ident' }
      }
    }
  }

  // --- pass 2: call-argument surgery ---------------------------------------
  const stack: Array<{ name: string; open: number }> = []
  for (let i = 0; i < toks.length; i++) {
    const t = toks[i]
    if (t.kind !== 'raw') continue
    if (t.text === '(') {
      const pIdx = prevSig(i)
      const name = pIdx >= 0 && toks[pIdx].kind === 'ident' ? toks[pIdx].text : ''
      stack.push({ name, open: i })
    } else if (t.text === ')' && stack.length) {
      const call = stack.pop()!
      if (call.name && ARG_SURGERY_CALLS.has(call.name)) {
        const removed = surgeryCall(toks, call.name, call.open, i)
        // splices happened at indices < i — every token from here on moved
        // left by `removed`; keep the scan aligned.
        i -= removed
      }
    }
  }

  return { source: toks.map((t) => t.text).join(''), upgraded: true, version }
}

/** One argument of a call: [start, end) token range + separator index. */
interface ArgSpan { start: number; end: number; sep: number }

/** Split the arguments of the call spanning tokens (openParen, closeParen). */
function argSpans(toks: Tok[], open: number, close: number): ArgSpan[] {
  const spans: ArgSpan[] = []
  let depth = 0
  let start = open + 1
  for (let i = open + 1; i < close; i++) {
    const t = toks[i]
    if (t.kind === 'string' || t.kind === 'comment') continue
    if (t.text === '(' || t.text === '[') depth++
    else if (t.text === ')' || t.text === ']') depth--
    else if (t.text === ',' && depth === 0) { spans.push({ start, end: i, sep: i }); start = i + 1 }
  }
  if (start < close) spans.push({ start, end: close, sep: -1 })
  return spans
}

/** When the arg span is `name = <expr>`, return name + the `=` token index.
 *  Spans may begin with separator whitespace — skip it first. */
function namedArg(toks: Tok[], sp: ArgSpan): { name: string; eq: number } | null {
  let s = sp.start
  while (s < sp.end && toks[s].kind === 'raw' && toks[s].text.trim() === '') s++
  if (!(s < sp.end) || toks[s].kind !== 'ident') return null
  let i = s + 1
  while (i < sp.end && toks[i].text.trim() === '') i++
  if (i >= sp.end || toks[i].text !== '=') return null
  return { name: toks[s].text, eq: i }
}

/** Rewrite one call's argument list in place (length-preserving edits +
 *  descending-order splices so recorded indices stay valid). Returns the
 *  number of tokens REMOVED so the caller can keep its scan index in
 *  sync (splices shift every later token to the left). */
function surgeryCall(toks: Tok[], name: string, open: number, close: number): number {
  const spans = argSpans(toks, open, close)
  if (!spans.length) return 0
  const drop = new Set<number>()

  /** Drop every token of `sp` plus its adjacent separator comma (trailing
   *  comma when last, leading comma otherwise). */
  const dropArg = (sp: ArgSpan) => {
    for (let k = sp.start; k < sp.end; k++) drop.add(k)
    if (sp.sep >= 0) drop.add(sp.sep)
    else {
      const idx = spans.indexOf(sp)
      if (idx > 0 && spans[idx - 1].sep >= 0) drop.add(spans[idx - 1].sep)
    }
  }

  // --- iff(a, b, c) → (a ? b : c) -----------------------------------------
  if (name === 'iff') {
    if (spans.length !== 3) return 0
    // `?` replaces the comma ending arg1, `:` the comma ending arg2.
    const sepQ = spans[0].sep
    const sepC = spans[1].sep
    if (sepQ < 0 || sepC < 0) return 0
    toks[sepQ] = { text: '?', kind: 'raw' }
    toks[sepC] = { text: ':', kind: 'raw' }
    // blank the callee identifier (the `(` and `)` stay → parenthesised expr)
    let c = open - 1
    while (c >= 0 && toks[c].text.trim() === '') c--
    if (c >= 0 && toks[c].kind === 'ident') toks[c] = { text: '', kind: 'raw' }
    return 0
  }

  // --- rising(len)/falling(len) arity fix ----------------------------------
  if (name === 'ta.rising' || name === 'ta.falling') {
    if (spans.length === 1) {
      const argText = toks.slice(spans[0].start, spans[0].end).map((t) => t.text).join('').trim()
      // Only rewrite when the single argument is a plain numeric/ident
      // length (not a source expression with a comma-less binary form).
      if (/^[A-Za-z0-9_.\s+\-*/]+$/.test(argText) && !/[()]/.test(argText) && argText.length > 0) {
        // length-preserving: fold `close,` into the open-paren token
        toks[open] = { text: '(close,', kind: 'raw' }
      }
    }
    return 0
  }

  // --- input(...): drop `type = <ident>` named args ------------------------
  if (name === 'input') {
    for (const sp of spans) {
      const na = namedArg(toks, sp)
      if (na && na.name === 'type') {
        // value must be a bare (possibly dotted) identifier — guards against
        // ever eating a `type == x` comparison in a legacy expression.
        let w = na.eq + 1
        let sawIdent = false
        while (w < sp.end) {
          const tt = toks[w]
          if (tt.kind === 'ident') { sawIdent = true; w++; continue }
          if (tt.text.trim() === '.' && sawIdent) { w++; continue }
          if (tt.text.trim() === '') { w++; continue }
          break
        }
        if (sawIdent && w === sp.end) {
          dropArg(sp)
        }
      }
    }
  }

  // --- plot family: `transp = N` -------------------------------------------
  if (name !== 'input') {
    let transpValue: number | null = null
    let transpSpan: ArgSpan | null = null
    let colorSpan: ArgSpan | null = null
    for (const sp of spans) {
      const na = namedArg(toks, sp)
      if (na && na.name === 'transp') {
        const valText = toks.slice(na.eq + 1, sp.end).map((t) => t.text).join('').trim()
        if (/^-?\d+(\.\d+)?$/.test(valText)) { transpValue = Number(valText); transpSpan = sp }
      } else if (na && na.name === 'color') {
        colorSpan = sp
      }
    }
    if (transpSpan) {
      if (transpValue != null && transpValue > 0) {
        // v6 removed `transp` — re-express as color.new(color, transp)
        if (colorSpan) {
          const na2 = namedArg(toks, colorSpan)
          if (na2) {
            // expression = value only (AFTER the `=`), not the named pair
            const expr = toks.slice(na2.eq + 1, colorSpan.end).map((t) => t.text).join('').trim()
            replaceSpan(toks, colorSpan, `color=color.new(${expr}, ${transpValue})`)
          }
        } else {
          // no explicit color: reuse the transp span in place (keeps commas)
          replaceSpan(toks, transpSpan, `color=color.new(color.blue, ${transpValue})`)
          transpSpan = null // consumed — do not drop
        }
      }
      if (transpSpan) {
        dropArg(transpSpan)
      }
    }
  }

  // apply drops (descending: each splice only affects higher indices)
  if (drop.size) {
    const idx = [...drop].sort((a, b) => b - a)
    for (const i of idx) toks.splice(i, 1)
  }
  return drop.size
}

/** Replace the tokens of span sp with a single ident token holding `text`
 *  (length-preserving: the remaining tokens are blanked). */
function replaceSpan(toks: Tok[], sp: ArgSpan, text: string): void {
  toks[sp.start] = { text, kind: 'ident' }
  for (let i = sp.start + 1; i < sp.end; i++) toks[i] = { text: '', kind: 'raw' }
}
