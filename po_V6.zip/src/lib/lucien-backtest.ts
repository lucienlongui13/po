/**
 * lucien-backtest.ts — Strategy Tester : backtesting AUTOMATIQUE des
 * stratégies « L_Lucien ProTrader » et « Ninja ProTrader » sur le Bar
 * Replay (v26).
 * ====================================================================
 *
 * STRATÉGIE SÉLECTIONNABLE (§18) : le Tester utilise le MÊME Rule Engine
 * que l'Auto Trade (Architecture : Shared Rule Engine → Auto Trade →
 * Strategy Tester — §19) avec SES règles par stratégie (§31) :
 *
 *   L_Lucien ProTrader : signal CONFIRMÉ À LA CLÔTURE — chaque bougie
 *   clôturée est évaluée (règle Candles Validation ancrée sur la bougie
 *   signalée : rule[0] = bougie signalée).
 *
 *   Ninja ProTrader    : signal EN FORMATION — en replay, chaque bougie
 *   est évaluée telle qu'elle vient de se clore mais avec la SÉMANTIQUE
 *   Ninja : la Candles Validation est ancrée sur la bougie CLÔTURÉE
 *   PRÉCÉDENTE (validationSkipForming — la bougie « en formation »
 *   n'est jamais validée). Adaptation documentée : le replay ne connaît
 *   pas l'évolution intra-bougie, la détection porte la forme finale de
 *   la bougie.
 *
 * RÈGLES MIXTES (v26) : conditions BOS/CHoCH/CISD + 73 patterns candle
 * (logique AND, §12) + Candles Validation (§14) + CISD Guard (§ conservé).
 *
 * EXPIRATION EN BOUGIES (§15/§16) : expiryIndex = entryIndex +
 * expiryCandles. Modes par règle :
 *   'seconds'   → conversion secondes → bougies via le timeframe (v22) ;
 *   'candles'   → expirationCandles utilisé DIRECTEMENT (§16) ;
 *   'remaining' → v25 — en replay, l'horloge intra-bougie n'existe pas :
 *   l'ordre vit jusqu'à la clôture de la bougie SUIVANTE (≈ le compteur
 *   au moment du signal en live) → 1 bougie, approximation documentée.
 *
 * Garde anti re-trade : UNE mise par bougie clôturée (même sémantique que
 * le backend live). Le reset des trades ré-arme la garde.
 */

import {
  createCisdGuardState,
  evaluateBosChochCisdOrderRules,
  normalizeCandlesValidation,
  normalizeCisdGuardConfig,
  type BosChochCisdCandle,
  type BosChochCisdOrderRule,
  type BosChochCisdSettings,
  type BosChochCisdSignal,
  type CisdGuardState,
} from '../../shared/bos-choch-cisd'
import { signalLabel } from '../../shared/signal-registry'
import { loadBosChochCisdSettings, subscribeBosChochCisdSettings } from './bos-choch-cisd-settings'
import type { ReplayEngine, SimOrder } from './replay-engine'

/** Stratégies disponibles dans le Strategy Tester (§18). */
export type BacktestStrategyId = 'l_lucien_protrader' | 'ninja_protrader'

export const BACKTEST_STRATEGIES: Array<{ id: BacktestStrategyId; name: string; description: string }> = [
  { id: 'l_lucien_protrader', name: 'L_Lucien ProTrader', description: 'Signal confirmé à la clôture de la bougie' },
  { id: 'ninja_protrader', name: 'Ninja ProTrader', description: 'Signal sur la bougie en formation — détection avant clôture' },
]

/** État public du backtester (rendu par le panneau Strategy Tester). */
export interface LucienBacktestState {
  enabled: boolean
  /** Stratégie active (§18). */
  strategyId: BacktestStrategyId
  /** Mise fixe appliquée à chaque ordre simulé ($). */
  stake: number
  /** Payout appliqué aux gains (%). */
  payout: number
  /** Dernier signal évalué (reason complet, CALL/PUT/HOLD). */
  lastSignal: string | null
  /** Nombre d'ordres placés par la stratégie depuis le reset. */
  placedCount: number
}

/** Convertit l'expiration (s) d'une règle en nombre de bougies du TF courant. */
export function expirySecondsToCandles(expirationSeconds: number, candleSizeSec: number): number {
  const tf = Math.max(1, Math.round(candleSizeSec))
  return Math.max(1, Math.round(expirationSeconds / tf))
}

/** Construit le libellé d'un ordre simulé (§21 : stratégie + conditions + validation + expiration).
 * `strategyName` optionnel — défaut « L_Lucien ProTrader » (compat v22-v24). */
export function buildLucienBacktestOrderLabel(
  sig: BosChochCisdSignal,
  rules: BosChochCisdOrderRule[],
  strategyName: string = 'L_Lucien ProTrader',
): string {
  const matched = rules.find((r) => r.id === sig.matchedRuleId)
  const validation = normalizeCandlesValidation(matched?.candlesValidation)
  const conditions = (sig.matchedRuleConditions ?? matched?.alerts ?? []).map((a) => signalLabel(a)).join(' + ')
  const mode = sig.expirationMode ?? 'seconds'
  const expiryTxt = mode === 'candles'
    ? `EXP: ${sig.expirationCandles ?? matched?.expirationCandles ?? '?'} bougie(s)`
    : mode === 'remaining'
      ? 'EXP: remaining Time Before Candle Closure (≈ 1 bougie en replay)'
      : `EXP: ${sig.expirationSeconds ?? matched?.expirationSeconds ?? '?'}s`
  const cisd = sig.cisdConfirmation
  return [
    strategyName,
    sig.action === 'CALL' ? 'CALL ▲' : 'PUT ▼',
    matched ? `${matched.id} [${conditions}]` : (sig.matchedRuleId ?? '—'),
    validation ? `validation ${validation}` : 'sans validation',
    expiryTxt,
    ...(cisd ? [`${cisd.direction === 'up' ? 'CISD Up' : 'CISD Down'} confirmé (armé bougie ${cisd.armedCandleTime}, swing ${cisd.swingPrice} ${cisd.swingMode === 'violated' ? 'violé' : cisd.swingMode === 'none' ? 'non vérifié (étape ignorée)' : 'intact'})`] : []),
  ].join(' · ')
}

export class LucienProTraderBacktester {
  private replay: ReplayEngine
  /** Réglages partagés du panneau Auto Trade (règles par stratégie + gardes). */
  private settings: BosChochCisdSettings
  private candleSizeSec = 60
  private _enabled = false
  private strategy: BacktestStrategyId = 'l_lucien_protrader'
  private stake = 1
  private payout = 92
  /** Bougies déjà tradées (garde une-mise-par-bougie). */
  private traded = new Set<number>()
  /** État de la vérification CISD — UN PAR STRATÉGIE (§31). */
  private cisdGuards: Record<BacktestStrategyId, CisdGuardState> = {
    l_lucien_protrader: createCisdGuardState(),
    ninja_protrader: createCisdGuardState(),
  }
  private lastSignal: string | null = null
  private placedCount = 0
  private lastSignalKey = ''
  private listeners = new Set<() => void>()
  private unsubAdvance: (() => void) | null = null
  private unsubReset: (() => void) | null = null
  private unsubSettings: (() => void) | null = null

  constructor(replay: ReplayEngine) {
    this.replay = replay
    this.settings = loadBosChochCisdSettings()
    // Chaque bougie clôturée qui apparaît pendant le replay est évaluée.
    this.unsubAdvance = replay.onAdvance((candles, info) => { this.onAdvance(candles, info) })
    // RESET TRADES / nouveau solde → la garde est ré-armée.
    this.unsubReset = replay.onOrdersReset(() => { this.traded.clear() })
    // Les règles/validations/gardes ÉDITÉES dans le panneau Auto Trade
    // s'appliquent immédiatement au backtest (Shared Rule Engine §19).
    this.unsubSettings = subscribeBosChochCisdSettings((s) => {
      const prevGuard = normalizeCisdGuardConfig(this.settings.cisdGuard)
      const nextGuard = normalizeCisdGuardConfig(s.cisdGuard)
      if (JSON.stringify(prevGuard) !== JSON.stringify(nextGuard)) {
        this.cisdGuards = {
          l_lucien_protrader: createCisdGuardState(),
          ninja_protrader: createCisdGuardState(),
        }
      }
      this.settings = s
    })
  }

  /** Timeframe courant du graphique (pour la conversion expiration → bougies). */
  configure(opts: { candleSizeSec?: number; stake?: number; payout?: number }): void {
    if (Number.isFinite(opts.candleSizeSec) && (opts.candleSizeSec ?? 0) >= 1) {
      this.candleSizeSec = Math.max(1, Math.round(opts.candleSizeSec as number))
    }
    if (Number.isFinite(opts.stake) && (opts.stake ?? 0) >= 0.01) {
      this.stake = Math.max(0.01, opts.stake as number)
    }
    if (Number.isFinite(opts.payout) && (opts.payout ?? 0) > 0 && (opts.payout ?? 0) <= 100) {
      this.payout = Math.min(100, opts.payout as number)
    }
    this.notify()
  }

  setEnabled(enabled: boolean): void {
    this._enabled = enabled
    this.notify()
  }

  /** v26 — §18 : choix de la stratégie testée (L_Lucien | Ninja). */
  setStrategy(strategyId: BacktestStrategyId): void {
    if (strategyId !== 'l_lucien_protrader' && strategyId !== 'ninja_protrader') return
    this.strategy = strategyId
    this.traded.clear()
    this.lastSignal = null
    this.lastSignalKey = ''
    this.notify()
  }

  /** Reset complet (nouveau replay / relance) : garde + compteurs. */
  reset(): void {
    this.traded.clear()
    this.placedCount = 0
    this.lastSignal = null
    this.lastSignalKey = ''
    this.cisdGuards = {
      l_lucien_protrader: createCisdGuardState(),
      ninja_protrader: createCisdGuardState(),
    }
    this.notify()
  }

  getState(): LucienBacktestState {
    return {
      enabled: this._enabled,
      strategyId: this.strategy,
      stake: this.stake,
      payout: this.payout,
      lastSignal: this.lastSignal,
      placedCount: this.placedCount,
    }
  }

  /** Règles de la stratégie active (§31 — règles PROPRES par stratégie). */
  getRulesSummary(): { callRules: number; putRules: number; validatedRules: number } {
    const isNinja = this.strategy === 'ninja_protrader'
    const call = isNinja ? (this.settings.ninjaCallRules ?? this.settings.callRules) : this.settings.callRules
    const put = isNinja ? (this.settings.ninjaPutRules ?? this.settings.putRules) : this.settings.putRules
    return {
      callRules: call.length,
      putRules: put.length,
      validatedRules: [...call, ...put].filter((r) => normalizeCandlesValidation(r.candlesValidation)).length,
    }
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener)
    return () => { this.listeners.delete(listener) }
  }

  dispose(): void {
    this.unsubAdvance?.()
    this.unsubReset?.()
    this.unsubSettings?.()
    this.listeners.clear()
  }

  private notify(): void {
    for (const l of this.listeners) {
      try { l() } catch { /* best-effort */ }
    }
  }

  private onAdvance(candles: BosChochCisdCandle[], info: { appended: unknown; seeked: boolean }): void {
    if (!this._enabled) return
    // Uniquement les avancées réelles (une NOUVELLE bougie vient de se
    // clôturer) — jamais les seek/step-back qui rejouent d'anciennes bougies.
    if (info.seeked || !info.appended) return
    if (!candles || candles.length < 5) return

    const isNinja = this.strategy === 'ninja_protrader'
    const strategyName = isNinja ? 'Ninja ProTrader' : 'L_Lucien ProTrader'
    const callRules = isNinja ? (this.settings.ninjaCallRules ?? this.settings.callRules) : this.settings.callRules
    const putRules = isNinja ? (this.settings.ninjaPutRules ?? this.settings.putRules) : this.settings.putRules

    const sig = evaluateBosChochCisdOrderRules(
      candles,
      callRules,
      putRules,
      {
        // v23/v24 — vérification CISD incluse (état PAR STRATÉGIE §31).
        cisdGuard: { state: this.cisdGuards[this.strategy], config: this.settings.cisdGuard },
        // §18 — Ninja : la bougie évaluée est traitée comme la bougie
        // « en formation » : la Candles Validation s'ancre sur la bougie
        // CLÔTURÉE PRÉCÉDENTE (jamais la bougie signalée).
        // L_Lucien : la bougie signalée EST l'ancre (règle[0]).
        ...(isNinja ? { validationSkipForming: true } : {}),
        // v26 — conversion broker candles → secondes (§17) : le TF du
        // graphique sert au libellé d'expiration résolu.
        timeframeSeconds: this.candleSizeSec,
      },
    )
    // Dernier signal (diagnostic du panneau) — notifié seulement au changement.
    if (sig.reason !== this.lastSignalKey) {
      this.lastSignalKey = sig.reason
      this.lastSignal = sig.action === 'HOLD' ? `HOLD — ${sig.reason}` : `${sig.action === 'CALL' ? 'CALL ▲' : 'PUT ▼'} — ${sig.reason}`
    }
    if (sig.action === 'HOLD') { this.notify(); return }

    const lastCandle = candles[candles.length - 1]
    // Garde une-mise-par-bougie clôturée (sémantique backend).
    if (this.traded.has(lastCandle.time)) { this.notify(); return }
    this.traded.add(lastCandle.time)

    /* v25/v26 — EXPIRATION EN BOUGIES (§15/§16) :
     *   mode 'candles'   → expirationCandles DIRECTEMENT (expiryIndex =
     *                      entryIndex + expiryCandles, §16) ;
     *   mode 'seconds'   → conversion via le TF (v22) ;
     *   mode 'remaining' → 1 bougie en replay (l'horloge intra-bougie du
     *                      live n'existe pas — approximation documentée). */
    const mode = sig.expirationMode ?? 'seconds'
    let expiryCandles: number
    if (mode === 'candles') {
      expiryCandles = Math.max(1, Math.round(sig.expirationCandles ?? 1))
    } else if (mode === 'remaining') {
      expiryCandles = 1
    } else {
      if (!(typeof sig.expirationSeconds === 'number' && Number.isFinite(sig.expirationSeconds) && sig.expirationSeconds >= 3)) {
        this.notify()
        return
      }
      expiryCandles = expirySecondsToCandles(sig.expirationSeconds, this.candleSizeSec)
    }

    const label = buildLucienBacktestOrderLabel(sig, [...callRules, ...putRules], strategyName)
    const order: SimOrder | null = this.replay.placeSim(
      sig.action === 'CALL' ? 'call' : 'put',
      this.stake,
      expiryCandles,
      this.payout,
      label,
    )
    if (order) this.placedCount++
    this.notify()
  }
}
