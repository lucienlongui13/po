/**
 * live-engine.ts — Live Engine S30
 * ============================================================
 *
 * UNIQUE autorité de données entre le WebSocket et le graphique.
 *
 *   Pocket Option WebSocket ('candle')
 *          │
 *          ▼
 *   Tick Buffer (mémoire mutable — AUCUN setState React)
 *          │
 *          ├── bougie courante (révisions in-place)
 *          ├── nouvelles bougies (détection t = période)
 *          └── dernier prix
 *          │
 *          ▼   coalescence requestAnimationFrame (1 dispatch / frame max)
 *   Candle Stream Controller
 *          │
 *          ├── onCandle  → chart : series.update() + volume + indicateurs
 *          │               incrémentaux (JAMAIS de setData pendant les ticks)
 *          └── onBatch   → page  : snapshot throttlé (~1 Hz + nouvelle bougie)
 *                          pour les calculs lourds asynchrones (prédictions)
 *
 * Règles d'or respectées :
 *   1. 1 mise à jour de bougie = 1 update() graphique
 *   2. défilement horizontal géré par le composant chart UNIQUEMENT à la
 *      nouvelle bougie S30 (jamais pendant les ticks)
 *   3. aucun setState React par tick
 */

import type { CandleLike } from './indicators'

/** Candle brut tel qu'arrivant du backend (champs redondants inclus). */
export interface RawCandleEvent {
  time?: number
  from?: number
  open?: number
  high?: number
  max?: number
  low?: number
  min?: number
  close?: number
  volume?: number
  active_id?: number
  size?: number
  [k: string]: unknown
}

/** Un dispatch coalescé par rAF, destiné au graphique. */
export interface CandleFlush {
  /** Bougies qui se sont OUVERTES depuis le flush précédent, dans l'ordre
   *  chronologique, chacune dans son état au moment du push. La dernière
   *  entrée a le même time que `latest` (état final de la frame). */
  appended: CandleLike[]
  /** État le plus récent de la bougie la plus neuve (révision in-place
   *  pendant les ticks, ou ouverture d'une nouvelle période). */
  latest: CandleLike
  /** Vrai si au moins une nouvelle période de bougie s'est ouverte depuis
   *  le flush précédent. C'est LE signal de déclenchement du décalage
   *  horizontal (un seul pas) côté chart. */
  isNewCandle: boolean
  /** Dernier prix échangé (close de `latest`). */
  lastPrice: number
}

export type CandleListener = (flush: CandleFlush) => void
export type BatchListener = (candles: CandleLike[]) => void
export type HistoryListener = (candles: CandleLike[], key: string) => void

/** Convertit un événement brut du backend en CandleLike normalisé. */
export function parseCandleEvent(raw: RawCandleEvent): CandleLike | null {
  const time = Math.floor(Number(raw.time ?? raw.from ?? 0))
  const open = Number(raw.open ?? 0)
  const high = Number(raw.high ?? raw.max ?? 0)
  const low = Number(raw.low ?? raw.min ?? 0)
  const close = Number(raw.close ?? 0)
  const volume = Number(raw.volume ?? 0)
  if (!Number.isFinite(time) || time <= 0) return null
  if (!Number.isFinite(open) || !Number.isFinite(close)) return null
  if (!Number.isFinite(high) || !Number.isFinite(low)) return null
  return { time, open, high, low, close, volume: Number.isFinite(volume) ? volume : 0 }
}

/** Médiane des closes des `window` dernières bougies (référence de prix). */
function medianClose(candles: CandleLike[], window = 200): number {
  const closes: number[] = []
  for (let i = candles.length - 1; i >= 0 && closes.length < window; i--) {
    const c = candles[i]
    if (Number.isFinite(c.close) && c.close > 0) closes.push(c.close)
  }
  if (closes.length === 0) return 0
  closes.sort((a, b) => a - b)
  return closes[Math.floor(closes.length / 2)]
}

/**
 * DÉFENSE MULTI-ACTIFS — une bougie est-elle plausible pour CE dataset ?
 *
 * Le backend peut (dans des fenêtres de course) diffuser des bougies d'un
 * autre actif : EURUSD ~1.16 mêlé à XAUUSD ~4400 étale l'échelle de prix du
 * graphique sur plusieurs ordres de grandeur → bougies « éclatées » en
 * grappes illisibles. Aucun instrument OTC ne bouge de ×10 en 90 jours :
 * tout écart de plus d'une décade de la médiane récente est un actif
 * étranger → REJET.
 */
function isPlausibleCandle(candle: CandleLike, refPrice: number, maxDecades = 1): boolean {
  if (!Number.isFinite(candle.open) || !Number.isFinite(candle.high)
    || !Number.isFinite(candle.low) || !Number.isFinite(candle.close)) return false
  if (candle.close <= 0) return false
  if (refPrice <= 0) return true // dataset vide — première bougie acceptée
  return Math.abs(Math.log10(candle.close) - Math.log10(refPrice)) <= maxDecades
}


/** Rejette les cassures de régime de prix sur une bougie individuelle. */
function isContinuousPriceStep(candle: CandleLike, previousClose: number, maxRelativeStep = 0.05): boolean {
  if (!Number.isFinite(previousClose) || previousClose <= 0) return true
  if (!Number.isFinite(candle.close) || candle.close <= 0) return false
  return Math.abs(candle.close / previousClose - 1) <= maxRelativeStep
}

/**
 * LiveEngine — buffer live côté frontend.
 *
 * - Absorbe les événements 'candle' du socket sans déclencher de render React.
 * - Coalesce les mises à jour via requestAnimationFrame (max ~60 dispatchs/s,
 *   en pratique 1 par frame contenant des ticks).
 * - Détecte l'ouverture d'une nouvelle période (nouvelle bougie S30).
 */
export class LiveEngine {
  private candles: CandleLike[] = []
  private byTime = new Map<number, CandleLike>()
  // Extended retention for Pine Script. The visible chart remains windowed
  // for performance, while Pine can request up to its max_bars_back range.
  private pineCandles: CandleLike[] = []
  private readonly pineMaxCandles = 5000
  private maxCandles: number

  /** Filtre marché/période : les bougies d'autres actifs ou tailles sont ignorées. */
  private filter: { activeId: number; size: number } | null = null
  private lastFilterKey = ''

  // ----- état pending pour la coalescence rAF -----
  private pendingAppended: CandleLike[] = []
  private pendingLatest: CandleLike | null = null
  private pendingNew = false
  private rafId: number | null = null
  private timerId: ReturnType<typeof setTimeout> | null = null

  /** Rejets consécutifs anti-multi-actifs : si le flux live insiste sur un
   *  autre régime de prix, c'est le DATASET qui est contaminé → auto-reset. */
  private foreignRejectStreak = 0

  private lastBatchTs = 0
  private batchIntervalMs: number

  private candleListeners = new Set<CandleListener>()
  private batchListeners = new Set<BatchListener>()
  private historyListeners = new Set<HistoryListener>()

  private disposed = false

  constructor(opts: { maxCandles?: number; batchIntervalMs?: number } = {}) {
    this.maxCandles = Math.max(1, Math.min(300, opts.maxCandles ?? 300))
    this.batchIntervalMs = opts.batchIntervalMs ?? 1000
  }

  // ------------------------------------------------------------------
  // API — entrée de données
  // ------------------------------------------------------------------

  /** Injecte un événement bougie brut (déjà filtré par marché/période côté appelant ou ici). */
  pushRaw(raw: RawCandleEvent): void {
    if (this.disposed) return
    if (this.filter) {
      const activeId = Number(raw.active_id)
      const size = Number(raw.size)
      if (activeId !== this.filter.activeId || size !== this.filter.size) return
    }
    const candle = parseCandleEvent(raw)
    if (!candle) return
    this.pushCandle(candle)
  }

  /** Injecte une bougie normalisée. */
  pushCandle(candle: CandleLike): void {
    if (this.disposed) return
    // DÉFENSE MULTI-ACTIFS : une bougie à prix aberrant (autre actif diffusée
    // par erreur) ne doit JAMAIS entrer dans le dataset du graphique.
    // AUTO-GUÉRISON : si le flux live insiste (≥ 10 bougies consécutives)
    // sur un autre régime de prix, c'est le DATASET qui est contaminé (ex.
    // historique chargé avec des bougies d'un autre actif) → on adopte le
    // régime de prix du flux et le dataset repart propre.
    if (this.candles.length >= 30) {
      const ref = medianClose(this.candles, 60)
      if (!isPlausibleCandle(candle, ref)) {
        this.foreignRejectStreak++
        if (this.foreignRejectStreak >= 10) {
          console.warn('[LiveEngine] auto-guérison : le flux live persiste sur un autre régime de prix — dataset réinitialisé sur le prix du flux',
            { ref, close: candle.close })
          this.candles = [candle]
          this.byTime = new Map([[candle.time, candle]])
          this.pineCandles = [candle]
          this.pendingAppended = [candle]
          this.pendingLatest = candle
          this.pendingNew = true
          this.foreignRejectStreak = 0
          this.schedule()
          this.emitBatch()
          return
        }
        if (typeof console !== 'undefined') {
          console.warn('[LiveEngine] bougie rejetée (prix incohérent avec le dataset — actif étranger ?)',
            { time: candle.time, close: candle.close, ref })
        }
        return
      }
      this.foreignRejectStreak = 0
    }
    const last = this.candles[this.candles.length - 1]

    // CONTINUITY FIREWALL : un changement instantané >5 % par rapport à la
    // dernière clôture est traité comme une contamination / mauvaise couture.
    // On rejette la bougie au lieu de déplacer toute l'échelle du graphique.
    if (last && candle.time > last.time && !isContinuousPriceStep(candle, last.close, 0.05)) {
      console.warn('[LiveEngine] bougie rejetée : cassure de régime de prix >5 %', {
        time: candle.time, previousClose: last.close, close: candle.close,
      })
      return
    }

    if (!last || candle.time > last.time) {
      // ── NOUVELLE bougie (nouvelle période S30 ou catch-up) ──
      this.candles.push(candle)
      this.byTime.set(candle.time, candle)
      this.pineCandles.push(candle)
      if (this.pineCandles.length > this.pineMaxCandles) this.pineCandles.shift()
      if (this.candles.length > this.maxCandles) {
        const removed = this.candles.shift()
        if (removed) this.byTime.delete(removed.time)
      }
      this.pendingAppended.push(candle)
      this.pendingNew = true
      this.pendingLatest = candle
    } else if (candle.time === last.time) {
      // ── TICK : révision in-place de la bougie en formation ──
      this.candles[this.candles.length - 1] = candle
      this.byTime.set(candle.time, candle)
      if (this.pineCandles.length && this.pineCandles[this.pineCandles.length - 1].time === candle.time) {
        this.pineCandles[this.pineCandles.length - 1] = candle
      }
      // Si la bougie vient d'être ouverte dans CE frame, remplace l'entrée
      // pending obsolète pour garder des données cohérentes par flush.
      if (this.pendingAppended.length > 0
          && this.pendingAppended[this.pendingAppended.length - 1].time === candle.time) {
        this.pendingAppended[this.pendingAppended.length - 1] = candle
      }
      this.pendingLatest = candle
    } else {
      // ── Correction sur une bougie CLÔURÉE (plus ancienne que la dernière) ──
      // series.update() interdit les temps antérieurs : on met à jour le
      // dataset (visible aux prochains full reset) sans toucher au flux live.
      const idx = this.indexOfTime(candle.time)
      if (idx >= 0) {
        this.candles[idx] = candle
        this.byTime.set(candle.time, candle)
        const pineIdx = this.pineCandles.findIndex((c) => c.time === candle.time)
        if (pineIdx >= 0) this.pineCandles[pineIdx] = candle
      } else {
        // temps inconnu (gap) : insertion triée — sera visible aux resets
        let insertAt = this.candles.length
        for (let i = this.candles.length - 1; i >= 0; i--) {
          if (this.candles[i].time < candle.time) { insertAt = i + 1; break }
          insertAt = 0
        }
        this.candles.splice(insertAt, 0, candle)
        this.byTime.set(candle.time, candle)
        const pineExists = this.pineCandles.some((c) => c.time === candle.time)
        if (pineExists) {
          const pineIdx = this.pineCandles.findIndex((c) => c.time === candle.time)
          if (pineIdx >= 0) this.pineCandles[pineIdx] = candle
        } else {
          this.pineCandles.push(candle)
          this.pineCandles.sort((a, b) => a.time - b.time)
          while (this.pineCandles.length > this.pineMaxCandles) this.pineCandles.shift()
        }
      }
    }

    this.schedule()
  }

  /** Remplace le dataset par un historique (changement de marché / capture).
   *  Si un filtre est actif et que la clé ne correspond pas (historique
   *  périmé d'un autre marché/période arrivé tard), l'appel est ignoré.
   *
   *  DÉFENSE MULTI-ACTIFS : les bougies dont le prix s'écarte de plus de
   *  ×10 de la médiane des bougies RÉCENTES (l'actif streamé) sont écartées
   *  — un historique contaminé ne peut plus éclater l'échelle du graphique.
   *  Si plus de 30 % des bougies sont écartées, l'historique entier est
   *  rejeté (série globalement incohérente). */
  resetHistory(candles: CandleLike[], key: string): void {
    if (this.disposed) return
    if (this.filter && this.lastFilterKey !== '' && key !== this.lastFilterKey) {
      return // historique périmé : conservons le dataset courant
    }
    const seen = new Map<number, CandleLike>()
    for (const c of candles) {
      const parsed = parseCandleEvent(c as unknown as RawCandleEvent)
      if (!parsed) continue
      seen.set(parsed.time, parsed) // dernier gagne
    }
    let clean = Array.from(seen.values()).sort((a, b) => a.time - b.time)

    // Sanitisation prix — DÉFENSE MULTI-ACTIFS.
    // Référence = médiane des bougies récentes du DATASET EXISTANT s'il est
    // sain (un historique rafraîchi pour le MÊME actif doit être cohérent
    // avec ce que le graphique affiche déjà) ; sinon médiane de l'historique
    // entrant lui-même (changement d'actif légitime : le dataset vient d'être
    // vidé par setFilter, l'historique du NOUVEL actif devient la référence).
    if (clean.length > 0) {
      const existingRef = this.candles.length >= 30 ? medianClose(this.candles, 200) : 0
      const ref = existingRef > 0 ? existingRef : medianClose(clean, 200)
      const kept = clean.filter((c) => isPlausibleCandle(c, ref))
      const regime = kept.length > 1
        ? kept.reduce((acc, c, i) => {
            if (i === 0) return [c]
            const prev = acc[acc.length - 1]
            if (prev && Math.abs(c.close / prev.close - 1) > 0.05) {
              // Une rupture de régime : on conserve le suffixe le plus récent.
              return [c]
            }
            return [...acc, c]
          }, [] as CandleLike[])
        : kept
      const dropped = clean.length - regime.length
      clean = regime
      if (dropped > 0) {
        const denominator = Math.max(1, clean.length)
        if (dropped / denominator > 0.3) {
          console.warn(`[LiveEngine] historique ${key} : continuity firewall actif — ${dropped} bougies écartées; conservation du dernier régime cohérent`,
            { ref })
        } else {
          console.warn(`[LiveEngine] historique ${key} : ${dropped} bougies écartées (régime de prix discontinu neutralisé)`,
            { ref })
        }
      }
    }
    // Keep a separate extended dataset for Pine while the chart keeps its
    // small visible window. Pine v6 max_bars_back allows up to 5000 bars.
    const pineClean = clean.slice(Math.max(0, clean.length - this.pineMaxCandles))
    const visibleClean = clean.slice(Math.max(0, clean.length - this.maxCandles))

    this.pineCandles = pineClean
    this.candles = visibleClean
    this.byTime = new Map(visibleClean.map((c) => [c.time, c]))
    this.cancelPending()

    for (const l of this.historyListeners) {
      try { l(clean, key) } catch (e) { console.error('[LiveEngine] history listener', e) }
    }
    // Snapshot immédiat pour que la page relance les calculs lourds.
    this.emitBatch()
  }

  /**
   * Définit le filtre (marché actif + taille de bougie). Un changement de
   * filtre vide le dataset : les anciennes bougies n'ont plus de sens.
   */
  setFilter(activeId: number, size: number): void {
    if (this.disposed) return
    const key = `${activeId}:${size}`
    if (key === this.lastFilterKey) return
    this.lastFilterKey = key
    this.filter = { activeId, size }
    this.clear()
  }

  /** Vide le dataset et notifie les listeners (full reset côté chart). */
  clear(): void {
    this.candles = []
    this.pineCandles = []
    this.byTime.clear()
    this.foreignRejectStreak = 0
    this.cancelPending()
    for (const l of this.historyListeners) {
      try { l([], '__cleared__') } catch (e) { console.error('[LiveEngine] history listener', e) }
    }
  }

  // ------------------------------------------------------------------
  // API — lecture
  // ------------------------------------------------------------------

  /** Copie défensive du dataset complet (rare : resets, worker). */
  getCandles(): CandleLike[] {
    return this.candles.slice()
  }

  /**
   * Extended OHLCV history reserved for Pine Script execution. This is kept
   * separately from the visible chart window so scripts using lookbacks such
   * as 400/1000/5000 bars can calculate normally without enlarging the chart.
   */
  getPineCandles(): CandleLike[] {
    return this.pineCandles.slice()
  }

  getLastCandle(): CandleLike | null {
    return this.candles.length > 0 ? this.candles[this.candles.length - 1] : null
  }

  /** Les `n` dernières bougies (les plus récentes en dernier). */
  getLastCandles(n: number): CandleLike[] {
    if (n <= 0 || this.candles.length === 0) return []
    return this.candles.slice(Math.max(0, this.candles.length - n))
  }

  get length(): number {
    return this.candles.length
  }

  // ------------------------------------------------------------------
  // API — abonnements
  // ------------------------------------------------------------------

  /** Dispatch par frame (chart). Retourne la fonction de désabonnement. */
  onCandle(listener: CandleListener): () => void {
    this.candleListeners.add(listener)
    return () => { this.candleListeners.delete(listener) }
  }

  /** Snapshot throttlé ~1 Hz + à chaque nouvelle bougie (page / worker). */
  onBatch(listener: BatchListener): () => void {
    this.batchListeners.add(listener)
    return () => { this.batchListeners.delete(listener) }
  }

  /** Full resets (historique reçu, filtre changé, dataset vidé). */
  onHistory(listener: HistoryListener): () => void {
    this.historyListeners.add(listener)
    return () => { this.historyListeners.delete(listener) }
  }

  dispose(): void {
    this.disposed = true
    this.cancelPending()
    this.candleListeners.clear()
    this.batchListeners.clear()
    this.historyListeners.clear()
  }

  // ------------------------------------------------------------------
  // interne
  // ------------------------------------------------------------------

  private indexOfTime(time: number): number {
    // recherche binaire (dataset trié par time)
    let lo = 0
    let hi = this.candles.length - 1
    while (lo <= hi) {
      const mid = (lo + hi) >> 1
      const t = this.candles[mid].time
      if (t === time) return mid
      if (t < time) lo = mid + 1
      else hi = mid - 1
    }
    return -1
  }

  private schedule(): void {
    if (this.rafId !== null || this.timerId !== null) return
    if (typeof requestAnimationFrame === 'function') {
      this.rafId = requestAnimationFrame(() => {
        this.rafId = null
        this.flush()
      })
    } else {
      // Fallback (tests / environnements sans rAF)
      this.timerId = setTimeout(() => {
        this.timerId = null
        this.flush()
      }, 16)
    }
  }

  private cancelPending(): void {
    if (this.rafId !== null && typeof cancelAnimationFrame === 'function') {
      cancelAnimationFrame(this.rafId)
    }
    if (this.timerId !== null) clearTimeout(this.timerId)
    this.rafId = null
    this.timerId = null
    this.pendingAppended = []
    this.pendingLatest = null
    this.pendingNew = false
  }

  private flush(): void {
    if (this.disposed) return
    const latest = this.pendingLatest
    const appended = this.pendingAppended
    const isNew = this.pendingNew
    this.pendingLatest = null
    this.pendingAppended = []
    this.pendingNew = false

    if (latest) {
      const flush: CandleFlush = {
        appended,
        latest,
        isNewCandle: isNew,
        lastPrice: latest.close,
      }
      for (const l of this.candleListeners) {
        try { l(flush) } catch (e) { console.error('[LiveEngine] candle listener', e) }
      }
    }

    const now = Date.now()
    if (isNew || now - this.lastBatchTs >= this.batchIntervalMs) {
      this.lastBatchTs = now
      this.emitBatch()
    }
  }

  private emitBatch(): void {
    if (this.batchListeners.size === 0) return
    const snapshot = this.candles.slice()
    for (const l of this.batchListeners) {
      try { l(snapshot) } catch (e) { console.error('[LiveEngine] batch listener', e) }
    }
  }
}
