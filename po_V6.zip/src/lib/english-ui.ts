/** Runtime normalization for user-facing broker text. */
const pairs: Array<[string,string]> = [
  ["Pas assez d'historique pour le replay","Not enough history for replay"],
  ["aucune donnée historique reçue","no historical data received"],
  ["Fetch History terminé, mais seulement","Fetch History completed, but only"],
  ["Historique chargé","History loaded"], ["Payout tombé à","Payout dropped to"],
  ["remplacé automatiquement par","automatically replaced by"], ["Actif changé par le backend","Asset changed by backend"],
  ["le graphique suit automatiquement le nouvel actif","the chart now follows the new asset automatically"],
  ["Après chaque trade","After each trade"], ["En dessous","Below"], ["changement d’actif","asset change"],
  ["refresh obligatoire","mandatory refresh"],
  ["Zones visibles","Zones visible"], ["Zones masquées","Zones hidden"],
  ["Aucun ordre social reçu","No social orders received"], ["En attente du backend","Waiting for backend"],
  ["Temps restant","Time remaining"], ["HAUSSIÈRE","BULLISH"], ["BAISSIÈRE","BEARISH"], ["INDÉCISE","UNDECIDED"],
  ["Haussière","Bullish"], ["Baissière","Bearish"], ["Indécise","Undecided"], ["Hausse","Up"], ["Baisse","Down"],
  ["prochaines bougies","next candles"], ["prochaine bougie","next candle"], ["dernière bougie","latest candle"],
  ["bougies","candles"], ["bougie","candle"], ["début","start"], ["Début","Start"], ["confiance","confidence"],
  ["cible","target"], ["probabilité","probability"], ["prix","price"], ["niveau","level"], ["niveaux","levels"],
  ["figure","pattern"], ["figures","patterns"], ["zones","zones"], ["zone","zone"], ["historique","history"],
  ["chargement","loading"], ["chargé","loaded"], ["données","data"], ["donnée","data"], ["attente","waiting"],
  ["exécution","execution"], ["entrée","entry"], ["sortie","exit"], ["ordre","order"], ["ordres","orders"],
  ["signal","signal"], ["signaux","signals"], ["mise","stake"], ["solde","balance"], ["gain","profit"], ["perte","loss"],
  ["raison","reason"], ["raisons","reasons"], ["bloqueurs","blockers"], ["erreur","error"], ["Échec","Failed"],
  ["réussi","successful"], ["terminé","completed"], ["paramètres","parameters"], ["paramètre","parameter"],
  ["réglages","settings"], ["réglage","setting"], ["pression","pressure"], ["contexte","context"],
  ["surveillance","monitoring"], ["déclenchement","trigger"], ["observation","observation"], ["incertitude","uncertainty"],
  ["prévision","forecast"], ["prédiction","prediction"], ["prédite","predicted"], ["prédit","predicted"], ["prédire","predict"],
  ["projection","projection"], ["cassure","break"], ["cassures","breaks"], ["rejet","rejection"], ["actualiser","refresh"],
  ["rafraîchir","refresh"], ["obligatoire","required"], ["facultatif","optional"], ["précision","precision"],
  ["précis","precise"], ["courante","current"], ["courant","current"], ["ancienne","old"], ["ancien","old"],
  ["précédente","previous"], ["précédentes","previous"], ["suivant","next"], ["suivante","next"], ["suivantes","next"],
  ["fenêtre","window"], ["plus tôt","earlier"], ["plus tard","later"], ["davantage","more"], ["moins","less"],
  ["uniquement","only"], ["avec","with"], ["sans","without"], ["pour","for"], ["dans","in"], ["sur","on"],
  ["par défaut","by default"], ["après","after"], ["avant","before"], ["chaque","each"], ["clôture","close"],
  ["clôturée","closed"], ["attendre","wait"], ["attend","waits"], ["peut","can"], ["doit","must"], ["nécessaire","required"],
  ["valeur","value"], ["valeurs","values"], ["jour(s)","day(s)"], ["jours","days"], ["jour","day"],
  ["heures","hours"], ["heure","hour"], ["minutes","minutes"], ["minute","minute"], ["secondes","seconds"], ["seconde","second"],
  ["entrez","enter"], ["demandées","requested"], ["demandée","requested"], ["Lun–Ven (heures de marché)","Mon–Fri (market hours)"],
  ["heures de marché","market hours"], ["marché","market"], ["marchés","markets"], ["actifs","assets"], ["actif","asset"],
  ["outil","tool"], ["outils","tools"], ["capturer","capture"], ["préremplit","pre-fills"], ["préselectionne","preselects"],
  ["correspondant","corresponding"], ["ACHETER","BUY"], ["VENDRE","SELL"], ["ATTENDRE","WAIT"], ["NEUTRE","NEUTRAL"], ["MÊME","SAME"], ["Même","Same"], ["conséc.","consecutive"], ["chauffe du moteur","engine warm-up"], ["chaud","warm"], ["puissant","powerful"], ["puissante","powerful"], ["fausse cassure","fake breakout"],
];
const ordered=[...pairs].sort((a,b)=>b[0].length-a[0].length);
const rx=new RegExp('(?<![A-Za-zÀ-ÿ])(?:'+ordered.map(([s])=>s.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|')+')(?![A-Za-zÀ-ÿ])','giu');
const dict=new Map(ordered.map(([a,b])=>[a.toLowerCase(),b]));
const leftovers=/[àâäéèêëîïôöùûüÿçÀÂÄÉÈÊËÎÏÔÖÙÛÜŸÇ]|\b(?:aucun|aucune|avec|sans|pour|dans|sur|mais|donc|une|un|des|du|de|la|le|les|est|sont|être|chaque|dernière|dernier|prochain|même|décision|acheter|vendre|attendre|neutre|valeur|paramètre|stratégie|bougie|marché|actif|historique|attente|entrée|sortie|niveau|zone|signal|signaux|pression|volume|confiance|cible|probabilité|figure|exécution|configuration|erreur|début|temps|jusqu|vers|pendant|selon|utilisateur|utilisées|utilisée|référence|définit|détermine|contrôle|impose|permet|exige|accepte|tolère|réagit|détectée|considéré|considérée|supérieur|inférieur|fort|faible|plus|moins|souvent|généralement|seulement|rapidement|lentement|maintenant|encore|ici|là)\b/i;
export function englishizeText(value: unknown, fallback = 'No English description available.'): string {
  if(value==null) return '';
  const out=String(value).replace(rx,m=>dict.get(m.toLowerCase()) ?? m);
  return leftovers.test(out) ? (fallback || 'English text') : out;
}
