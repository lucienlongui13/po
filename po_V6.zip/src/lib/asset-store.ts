/**
 * asset-store.ts — Store observable PAR ASSET (§38 performance).
 * ==============================================================
 *
 * Problème : avec 10 assets live, un unique state React re-renderait TOUTES
 * les cartes à chaque tick d'un seul asset.
 *
 * Solution : un store par asset hors de React. Chaque AssetTradingCard
 * s'abonne UNIQUEMENT aux mises à jour de SON asset via useSyncExternalStore
 * → un tick EURUSD ne re-render QUE la carte EURUSD (BTCUSD/XAUUSD/GBPUSD
 * ne bougent pas).
 *
 * Le graphique de chaque carte s'abonne directement à SON LiveEngine
 * (buffer mémoire + coalescence rAF — zéro setState React par tick).
 */

import { useEffect, useState, useSyncExternalStore } from 'react'
import type { LiveEngine } from '@/lib/live-engine'
import type {
  ClosedDeal,
  AssetStatusEntry,
  AssetAutoTradeEntry,
} from '@/hooks/use-pocket-option'
import type { CandleLike } from '@/lib/indicators'

/** Instantané des données de trading d'UN asset (§25 — autoportant). */
export interface AssetData {
  asset: string
  /** LiveEngine dédié à cet asset (§22 — jamais un moteur unique). */
  engine: LiveEngine | null
  /** Données du statut 1 Hz (prix, payout, positions, mise, stats). */
  status: AssetStatusEntry | null
  /** Statut auto-trade de CET asset (stats/martingale/fibonacci isolées). */
  autoStatus: AssetAutoTradeEntry | null
  /** Deals fermés de cet asset (les plus récents d'abord). */
  trades: ClosedDeal[]
  /** Timestamp de la dernière mise à jour (debug). */
  updatedAt: number
}

function emptyAssetData(asset: string): AssetData {
  return {
    asset,
    engine: null,
    status: null,
    autoStatus: null,
    trades: [],
    updatedAt: 0,
  }
}

/**
 * Store observable par asset.
 * - `update(asset, patch)` fusionne et notifie UNIQUEMENT les abonnés de cet
 *   asset (isolation des re-renders §38) ;
 * - `attachEngine(asset, engine)` lie le LiveEngine dédié ;
 * - `remove(asset)` libère la carte d'un asset désélectionné (§30) ;
 * - `getSnapshot(asset)` retourne une référence STABLE entre les updates
 *   (exigence de useSyncExternalStore).
 */
export class AssetStore {
  private data = new Map<string, AssetData>()
  private listeners = new Map<string, Set<() => void>>()
  private globalListeners = new Set<() => void>()

  getSnapshot(asset: string): AssetData {
    return this.data.get(asset) ?? emptyAssetData(asset)
  }

  subscribe(asset: string, onChange: () => void): () => void {
    let set = this.listeners.get(asset)
    if (!set) {
      set = new Set()
      this.listeners.set(asset, set)
    }
    set.add(onChange)
    return () => {
      set!.delete(onChange)
      if (set!.size === 0) this.listeners.delete(asset)
    }
  }

  /** Abonnement global (changement de liste d'assets). */
  subscribeAll(onChange: () => void): () => void {
    this.globalListeners.add(onChange)
    return () => this.globalListeners.delete(onChange)
  }

  private notify(asset: string): void {
    const set = this.listeners.get(asset)
    if (set) for (const cb of set) cb()
    for (const cb of this.globalListeners) cb()
  }

  /** Fusionne un patch dans les données de l'asset et notifie ses abonnés. */
  update(asset: string, patch: Partial<AssetData>): void {
    const prev = this.data.get(asset) ?? emptyAssetData(asset)
    const next: AssetData = { ...prev, ...patch, asset, updatedAt: Date.now() }
    this.data.set(asset, next)
    this.notify(asset)
  }

  /** Met à jour la liste des assets (ajoute les manquants, retire les partis). */
  setAssets(assets: string[], engines: Map<string, LiveEngine>): void {
    const keep = new Set(assets)
    for (const asset of [...this.data.keys()]) {
      if (!keep.has(asset)) {
        this.data.delete(asset)               // §30 — libération mémoire
        this.listeners.delete(asset)
        this.notify(asset)
      }
    }
    for (const asset of assets) {
      if (!this.data.has(asset)) {
        this.update(asset, { engine: engines.get(asset) ?? null })
      } else {
        const cur = this.data.get(asset)!
        if (cur.engine !== engines.get(asset)) {
          this.update(asset, { engine: engines.get(asset) ?? null })
        }
      }
    }
    for (const cb of this.globalListeners) cb()
  }

  /** Ajoute un deal fermé à l'historique de SON asset (§17). */
  pushTrade(asset: string, deal: ClosedDeal): void {
    const cur = this.getSnapshot(asset)
    if (cur.trades.some((d) => String(d.id) === String(deal.id))) return
    this.update(asset, { trades: [deal, ...cur.trades].slice(0, 40) })
  }

}

// ────────────────────────────────────────────────────────────────────────
//  Hooks React — abonnement ISOLÉ par asset (§38)
// ────────────────────────────────────────────────────────────────────────

/**
 * Lit les données d'UN asset avec un re-render limité à CET asset.
 * Un tick d'un autre asset ne déclenche AUCUN re-render ici.
 */
export function useAssetData(store: AssetStore, asset: string): AssetData {
  return useSyncExternalStore(
    (cb) => store.subscribe(asset, cb),
    () => store.getSnapshot(asset),
    () => emptyAssetData(asset),
  )
}

/**
 * Snapshot throttlé (~1 Hz) des bougies d'UN asset, pour les panneaux React
 * (stats/P&L de la carte). Le graphique lui-même s'abonne au LiveEngine
 * (voir AssetChart) — zéro render par tick.
 */
export function useAssetCandles(engine: LiveEngine | null): import('@/lib/indicators').CandleLike[] {
  const [candles, setCandles] = useState<import('@/lib/indicators').CandleLike[]>(
    () => (engine ? engine.getCandles() : []),
  )

  // FIX (audit v6.5) — plus de setState synchrone dans le corps de l'effet
  // (cascades de rendus, règle react-hooks/set-state-in-effect). On utilise le
  // pattern officiel « ajustement d'état pendant le rendu » : quand l'engine
  // change, on resynchronise le snapshot immédiatement (rendu pur, lecture
  // seule), puis l'effet ne gère QUE l'abonnement au flux externe.
  const [prevEngine, setPrevEngine] = useState<LiveEngine | null>(engine)
  if (engine !== prevEngine) {
    setPrevEngine(engine)
    setCandles(engine ? engine.getCandles() : [])
  }

  // FIX (audit v6.5) — les resets d'historique (onHistory : nouvel historique,
  // changement de filtre, dataset vidé) n'étaient PAS couverts : la carte
  // affichait des bougies obsolètes jusqu'au prochain batch. onHistory
  // resynchronise désormais le snapshot complet.
  useEffect(() => {
    if (!engine) return
    const unsubBatch = engine.onBatch((batch) => setCandles(batch))
    const unsubHistory = engine.onHistory(() => setCandles(engine.getCandles()))
    return () => {
      unsubBatch()
      unsubHistory()
    }
  }, [engine])
  return engine ? candles : []
}
