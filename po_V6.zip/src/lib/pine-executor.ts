/**
 * pine-executor.ts — Pine EXECUTION COORDINATOR (v1.9).
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * WHY THIS MODULE EXISTS — the v1.8 cumulative-drift bug
 * ═══════════════════════════════════════════════════════════════════════════
 * The old pipeline re-executed Pine through a React effect debounced by a
 * 350 ms setTimeout whose cleanup ran on EVERY new `candles` array reference.
 * During live streaming the engine pushes a fresh array per rAF flush (up to
 * 60×/s), so the timer was cancelled over and over and NEVER fired: Pine
 * results stayed frozen on the initial history while every new candle pushed
 * the chart forward — indicators appeared to slide one candle to the left per
 * new candle, cumulatively. Replay at X40/X80 (200 ms coalescing < 350 ms)
 * starved the same way.
 *
 * ═══════════════════════════════════════════════════════════════════════════
 * THE NEW MODEL (spec §3–§6, §13–§15, §26)
 * ═══════════════════════════════════════════════════════════════════════════
 *  - IMMUTABLE SNAPSHOT: every dataset submitted for execution is frozen
 *    (readonly candles + identity: revision, asset, timeframe, first/last bar
 *    time, bar count). Revision is monotonic — a new bar or a dataset replace
 *    bumps it immediately, BEFORE the execution even starts.
 *  - SINGLE-FLIGHT SCHEDULER: at most ONE batch executes at a time. Events
 *    arriving during a batch only keep the LATEST snapshot (trailing) — an
 *    infinite queue of recalcs can never pile up.
 *  - EXECUTION TOKEN (latest-result-wins): each batch carries a token; the
 *    commit is performed ONLY if the token is still the latest AND the
 *    snapshot revision/context still match the current dataset. A stale
 *    async result can therefore NEVER rewrite the store.
 *  - ALL SCRIPTS ON THE SAME SNAPSHOT: one batch runs every enabled script
 *    against the SAME immutable candle list (spec §14) and commits them
 *    ATOMICALLY (spec §15) — a mixed chart drawn from different dataset
 *    revisions is impossible.
 *  - PRIORITY POLICY (spec §26): NEW BAR / DATASET REPLACE / SETTINGS /
 *    MANUAL / LIBRARIES → immediate scheduling. FORMING BAR (tick updates of
 *    the current candle) → throttled trailing recalculation (default 1000 ms);
 *    the forming bar keeps its barTime (one bar = one timestamp).
 *
 * The coordinator is module-scoped (like pine-engine's compiled cache): it is
 * shared by the editor, the chart and the tests, and never depends on React
 * render timing.
 */

import type { CandleLike } from './indicators'
import { runPineScript, toPineTimeframe, type PineExecutionResponse } from './pine-engine'
import { usePineStore, type PineExecutionEnvelopeInput } from './pine-store'
import { validatePineTimeline } from './pine-time-axis'

// ══════════════════════════════════════════════ types

export type DatasetChangeReason = 'new-bar' | 'forming' | 'replace' | 'init' | 'manual'

export interface PineDatasetContextInput {
  asset: string
  /** Candle size in SECONDS (host unit). */
  timeframe: number
}

/** Immutable dataset submitted to the coordinator. */
export interface PineExecutionSnapshot {
  revision: number
  asset: string
  timeframe: number
  firstBarTime: number
  lastBarTime: number
  barCount: number
  candles: readonly CandleLike[]
  reason: DatasetChangeReason
  createdAt: number
}

export interface CoordinatorStats {
  revision: number
  executing: boolean
  queued: boolean
  batchesStarted: number
  batchesCommitted: number
  batchesRefused: number
  lastCommitAt: number
  lastError: string | null
}

// ══════════════════════════════════════════════ coordinator

/** Minimum gap between forming-bar recalculations (ms). */
const FORMING_THROTTLE_MS = 1000

class PineExecutionCoordinator {
  private revision = 0
  private token = 0

  private currentSnapshot: PineExecutionSnapshot | null = null
  private pendingSnapshot: PineExecutionSnapshot | null = null
  private executing = false

  private ctx: PineDatasetContextInput = { asset: '', timeframe: 0 }
  private ctxSeen = false

  private formingTimer: ReturnType<typeof setTimeout> | null = null
  private formingSnapshot: PineExecutionSnapshot | null = null

  private batchesStarted = 0
  private batchesCommitted = 0
  private batchesRefused = 0
  private lastCommitAt = 0
  private lastError: string | null = null
  /** Resolved when the coordinator goes fully idle (UI waiters). */
  private idleWaiters: Array<() => void> = []
  /** @internal — test seam: deterministic execution timing (slow/fast
   * batches, controlled completion order). Production code NEVER sets it. */
  private testRunner: typeof runPineScript | null = null

  // ── context ────────────────────────────────────────────────────────────

  /** Declare the market context (asset + timeframe). A change invalidates
   *  every previous snapshot and result (spec §23/§24). */
  setContext(ctx: PineDatasetContextInput): void {
    const changed = this.ctxSeen && (ctx.asset !== this.ctx.asset || ctx.timeframe !== this.ctx.timeframe)
    this.ctx = { asset: ctx.asset, timeframe: ctx.timeframe }
    this.ctxSeen = true
    if (changed) {
      // Invalidate any queued/deferred work from the previous market.
      this.pendingSnapshot = null
      this.clearFormingTimer()
      this.formingSnapshot = null
      // CONTEXT BARRIER (spec §23/§24): publish the new context immediately
      // with a fresh monotonic revision. From this instant the store refuses
      // ANY commit for the previous asset/timeframe — even one carrying a
      // future revision — so no result from the old market can ever remain
      // displayed (or land late) on the new one.
      this.revision += 1
      usePineStore.getState().publishDataset({
        revision: this.revision,
        asset: ctx.asset,
        timeframe: ctx.timeframe,
        lastBarTime: 0,
        barCount: 0,
      })
      usePineStore.getState().clearAllResults()
    }
  }

  context(): PineDatasetContextInput {
    return { ...this.ctx }
  }

  // ── dataset ingestion ──────────────────────────────────────────────────

  /**
   * Submit a dataset change.
   *
   *  reason='new-bar'  → revision++ immediately, schedule NOW (max priority)
   *  reason='replace'  → revision++ immediately, schedule NOW (history reload,
   *                      asset/timeframe switch, replay seek)
   *  reason='init'     → first dataset of a context, schedule NOW
   *  reason='forming'  → same barTime, throttled trailing recalc; a later
   *                      new-bar/replace supersedes it
   *
   * The `candles` array is copied (frozen) so later in-place mutations by the
   * LiveEngine can never leak into a running execution (spec §3).
   */
  notifyDataset(candles: readonly CandleLike[], reason: DatasetChangeReason): void {
    if (!this.ctxSeen) return
    if (candles.length < 2) return

    const snapshot = this.buildSnapshot(candles, reason)

    if (reason === 'forming') {
      // A pending snapshot (any kind) already supersedes this forming update.
      if (this.pendingSnapshot) return
      // Forming recalculation is ALWAYS throttled (spec §6/§26): same
      // barTime, trailing snapshot, max one recalc per throttle window.
      this.formingSnapshot = snapshot
      this.scheduleForming()
      return
    }

    // new-bar / replace / init: cancel any deferred forming recalc — this
    // snapshot supersedes it.
    this.clearFormingTimer()
    this.formingSnapshot = null

    if (this.executing) {
      // Keep ONLY the latest snapshot (spec §26 — never queue infinitely).
      this.pendingSnapshot = snapshot
      return
    }
    void this.startBatch(snapshot)
  }

  /** Request an immediate re-run on the CURRENT snapshot (settings change,
   *  manual Run, library import). Keeps single-flight semantics. */
  requestImmediate(reason: DatasetChangeReason = 'manual'): boolean {
    const base = this.pendingSnapshot ?? this.currentSnapshot
    if (!base || base.candles.length < 2) return false
    const snapshot = { ...base, reason, createdAt: Date.now() }
    if (this.executing) {
      this.pendingSnapshot = snapshot
      return true
    }
    void this.startBatch(snapshot)
    return true
  }

  /** requestImmediate + resolves once the triggered work has fully settled
   *  (no batch running AND no trailing snapshot pending). UI feedback for
   *  the Run button; correctness never depends on callers awaiting this. */
  async requestImmediateAndWait(reason: DatasetChangeReason = 'manual'): Promise<void> {
    const started = this.requestImmediate(reason)
    if (!started) return
    if (!this.executing && !this.pendingSnapshot && !this.formingTimer) return
    await new Promise<void>((resolve) => {
      this.idleWaiters.push(resolve)
    })
  }

  /** The latest accepted snapshot (for callers that need the exact list the
   *  next/current batch consumes — e.g. manual Run after editing source). */
  snapshotCandles(): readonly CandleLike[] {
    return (this.pendingSnapshot ?? this.currentSnapshot)?.candles ?? []
  }

  stats(): CoordinatorStats {
    return {
      revision: this.revision,
      executing: this.executing,
      queued: this.pendingSnapshot != null,
      batchesStarted: this.batchesStarted,
      batchesCommitted: this.batchesCommitted,
      batchesRefused: this.batchesRefused,
      lastCommitAt: this.lastCommitAt,
      lastError: this.lastError,
    }
  }

  /** Test/diagnostic hook: force-clear internal state. */
  resetForTests(): void {
    this.clearFormingTimer()
    this.pendingSnapshot = null
    this.formingSnapshot = null
    this.currentSnapshot = null
    this.executing = false
    this.lastError = null
  }

  /** @internal — test seam (see field doc). `null` restores production. */
  setRunnerForTests(runner: typeof runPineScript | null): void {
    this.testRunner = runner
  }

  // ── internals ──────────────────────────────────────────────────────────

  private buildSnapshot(candles: readonly CandleLike[], reason: DatasetChangeReason): PineExecutionSnapshot {
    const prev = this.currentSnapshot
    const first = Number(candles[0].time)
    const last = Number(candles[candles.length - 1].time)
    // Same SHAPE = same asset/timeframe/barCount/first/last bar. Forming-bar
    // recalcs keep the same shape (same barTime — one bar, one timestamp);
    // their content (last candle OHLC) may differ, which still deserves a new
    // revision so results stay distinguishable.
    const sameShape = prev
      && prev.asset === this.ctx.asset
      && prev.timeframe === this.ctx.timeframe
      && prev.barCount === candles.length
      && prev.firstBarTime === first
      && prev.lastBarTime === last

    // Revision policy (spec §5/§6) — MONOTONIC, never decreasing:
    //  - new bar (shape changed) / dataset replace / first dataset → bump
    //  - forming recalc → bump (content changed, same bar identity)
    //  - identical re-submission of the same dataset → keep (idempotent)
    const bump = !sameShape || reason !== 'new-bar'
    if (bump) this.revision += 1

    return {
      revision: this.revision,
      asset: this.ctx.asset,
      timeframe: this.ctx.timeframe,
      firstBarTime: first,
      lastBarTime: last,
      barCount: candles.length,
      // Freeze: copy so later in-place mutation of the source array (the
      // LiveEngine mutates its buffers) cannot contaminate this execution.
      candles: Object.freeze(candles.slice()) as readonly CandleLike[],
      reason,
      createdAt: Date.now(),
    }
  }

  private scheduleForming(): void {
    if (this.formingTimer != null) return
    this.formingTimer = setTimeout(() => {
      this.formingTimer = null
      const snapshot = this.formingSnapshot
      this.formingSnapshot = null
      if (!snapshot) return
      // A pending or running newer snapshot always supersedes a forming recalc.
      if (this.pendingSnapshot) return
      if (this.executing) {
        this.pendingSnapshot = snapshot
        return
      }
      void this.startBatch(snapshot)
    }, FORMING_THROTTLE_MS)
  }

  private clearFormingTimer(): void {
    if (this.formingTimer != null) {
      clearTimeout(this.formingTimer)
      this.formingTimer = null
    }
  }

  private async startBatch(snapshot: PineExecutionSnapshot): Promise<void> {
    // Single-flight: the caller checked `executing === false`.
    this.executing = true
    const token = ++this.token
    this.batchesStarted += 1
    this.currentSnapshot = snapshot
    // Any forming recalc queued before this batch started is superseded.
    this.formingSnapshot = null

    // Publish the dataset context IMMEDIATELY (before results land): the
    // store's freshness guard then knows the current revision/context and
    // can refuse anything older (spec §12).
    usePineStore.getState().publishDataset({
      revision: snapshot.revision,
      asset: snapshot.asset,
      timeframe: snapshot.timeframe,
      lastBarTime: snapshot.lastBarTime,
      barCount: snapshot.barCount,
    })

    try {
      const entries: Array<{
        id: string
        result: import('./pine-engine').PineExecutionResult | null
        error: string | null
        envelope: PineExecutionEnvelopeInput
      }> = []

      // ALL enabled scripts run against the SAME immutable snapshot (spec §14).
      const scripts = usePineStore.getState().scripts.filter((s) => s.enabled)
      for (const script of scripts) {
        const envelope: PineExecutionEnvelopeInput = {
          revision: snapshot.revision,
          asset: snapshot.asset,
          timeframe: snapshot.timeframe,
          firstBarTime: snapshot.firstBarTime,
          lastBarTime: snapshot.lastBarTime,
          barCount: snapshot.barCount,
        }
        try {
          const overrides = script.inputValues && Object.keys(script.inputValues).length > 0
            ? script.inputValues
            : undefined
          const runner = this.testRunner ?? runPineScript
          const response = await runner(script.source, snapshot.candles as CandleLike[], {
            symbol: snapshot.asset,
            timeframe: toPineTimeframe(snapshot.timeframe),
            inputs: overrides,
          })
          if (response.ok) {
            // Timeline validation (spec §8): refuse to draw a result whose
            // own timeline is incoherent — commit it as an explicit error
            // instead of letting a potentially shifted layer render.
            const v = validatePineTimeline(response.result._times, snapshot.barCount)
            if (!v.ok) {
              const codes = v.issues.map((i) => i.code).join(', ')
              entries.push({
                id: script.id,
                result: null,
                error: `runtime: Pine timeline validation failed (${codes}) — result refused to prevent misalignment.`,
                envelope,
              })
              continue
            }
            entries.push({ id: script.id, result: response.result, error: null, envelope })
          } else {
            entries.push({
              id: script.id,
              result: null,
              error: `${response.error.stage}: ${response.error.message}`,
              envelope,
            })
          }
        } catch (err) {
          entries.push({
            id: script.id,
            result: null,
            error: err instanceof Error ? err.message : String(err),
            envelope,
          })
        }
      }

      // ── FRESHNESS CHECK before commit (spec §4) ──
      // The commit goes through ONLY if this batch is still the latest
      // started execution AND its snapshot is still the current dataset.
      const isLatestToken = token === this.token
      const stillCurrent =
        this.currentSnapshot === snapshot
        || (this.currentSnapshot?.revision ?? -1) <= snapshot.revision
      const contextStillValid =
        this.ctx.asset === snapshot.asset && this.ctx.timeframe === snapshot.timeframe

      if (!isLatestToken || !stillCurrent || !contextStillValid) {
        this.batchesRefused += 1
        if (!isProduction()) {
          console.warn(
            `[pine-executor] REFUSED stale batch rev ${snapshot.revision} ` +
              `(token ${token}/${this.token}, current rev ${this.currentSnapshot?.revision ?? '-'})`,
          )
        }
        return
      }

      // Atomic grouped commit (spec §15) — the store re-checks freshness.
      usePineStore.getState().commitExecution(entries)
      this.batchesCommitted += 1
      this.lastCommitAt = Date.now()
      this.lastError = null
    } catch (err) {
      this.lastError = err instanceof Error ? err.message : String(err)
    } finally {
      this.executing = false
      // Trailing: run the LATEST pending snapshot if one accumulated.
      const next = this.pendingSnapshot
      this.pendingSnapshot = null
      if (next) {
        // Defer to a microtask so `finally` completes first.
        void Promise.resolve().then(() => {
          if (!this.executing) void this.startBatch(next)
          else this.pendingSnapshot = next
        })
      } else {
        // Fully idle — resolve UI waiters (only when nothing is deferred).
        const waiters = this.idleWaiters
        this.idleWaiters = []
        for (const w of waiters) w()
      }
    }
  }
}

function isProduction(): boolean {
  return typeof process !== 'undefined' && process.env?.NODE_ENV === 'production'
}

/** Module-scoped singleton — one coordinator for the whole app. */
export const pineCoordinator = new PineExecutionCoordinator()
